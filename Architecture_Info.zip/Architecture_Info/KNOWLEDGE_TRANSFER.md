# BSC PROVIDER CONTRACT INTELLIGENCE — KNOWLEDGE TRANSFER DOCUMENT

> **Document**: KNOWLEDGE_TRANSFER.md  
> **Version**: 1.0  
> **Project**: Provider Contract Intelligence Platform  
> **Workspace**: `adb-640321604414221.1.azuredatabricks.net`  
> **Schema**: `dev_adb.raw`  
> **Generated**: May 2026  
> **Classification**: INTERNAL — TECHNICAL REFERENCE

---

## TABLE OF CONTENTS

1. [Executive Summary](#1-executive-summary)
2. [Business Context](#2-business-context)
3. [Architecture Overview](#3-architecture-overview)
4. [End-to-End Pipeline](#4-end-to-end-pipeline)
5. [Component-by-Component Breakdown](#5-component-by-component-breakdown)
6. [Table-by-Table Breakdown](#6-table-by-table-breakdown)
7. [Notebook-by-Notebook Breakdown](#7-notebook-by-notebook-breakdown)
8. [Folder-by-Folder Breakdown](#8-folder-by-folder-breakdown)
9. [Operational Guide](#9-operational-guide)
10. [Troubleshooting Guide](#10-troubleshooting-guide)
11. [Monitoring Guide](#11-monitoring-guide)
12. [Deployment Guide](#12-deployment-guide)
13. [Scaling Guide](#13-scaling-guide)
14. [FAQ](#14-faq)
15. [Glossary](#15-glossary)
16. [Future Enhancements](#16-future-enhancements)

---

## 1. EXECUTIVE SUMMARY

### 1.1 What This Platform Does

The Provider Contract Intelligence Platform converts Blue Shield of California's provider contract PDF corpus (10,372 documents, 27.3 GB) into structured, queryable data accessible via natural language. It enables contracting analysts, finance teams, and executives to ask questions like "What is Sharp Memorial's per diem rate?" and receive validated answers in 10 seconds — a task that previously required 2-4 hours of manual document search.

### 1.2 Key Metrics

| Metric | Value |
|---|---|
| Source documents | 10,372 PDFs (27.3 GB) |
| Documents processed | 3,416 (33%) |
| JSON extractions generated | 6,481 files |
| Facilities covered | 284 canonical providers |
| Rate lines extracted | 81,892 |
| Contract terms/clauses | 87,085 |
| Delta tables produced | 44 named tables + 10 serving |
| Total cost to build | $7,864 |
| Monthly operating cost | $1,326 |
| Query response time | 10 seconds (Genie) |

### 1.3 Technology Stack

| Layer | Technology |
|---|---|
| Cloud | Azure (ADLS Gen2) |
| Platform | Databricks (Unity Catalog, Serverless) |
| Storage | Delta Lake (Parquet + transaction log) |
| LLM | Claude Sonnet 4.5 (via REST API) |
| Embeddings | GTE-Large (via Foundation Model API) |
| Search | Databricks Vector Search |
| Governance | Unity Catalog (ACLs, lineage, tags) |
| Serving | Genie Space + SQL Dashboard |
| Language | Python (extraction), SQL (analytics) |
| Runtime | DBR 18.0+ (Serverless) |

### 1.4 Current State & Readiness

| Dimension | Status | Score |
|---|---|---|
| Extraction pipeline | ✅ Production-ready | 95% |
| Data quality | ✅ Validated (8 checks) | 90% |
| Genie serving layer | ✅ Operational | 85% |
| Governance | ⚠️ Needs hardening | 40% |
| Orchestration | ❌ Manual execution | 30% |
| Full corpus | ❌ 33% complete | 33% |
| Multi-plan ready | ❌ Architecture designed | 20% |

---

## 2. BUSINESS CONTEXT

### 2.1 The Business Problem

Blue Shield of California (BSC) contracts with ~500 provider facilities across the state. These contracts:
- Define reimbursement rates (per diem, case rates, capitation, % of charges)
- Are modified by amendments (up to 15+ per contract)
- Contain legal clauses, medical codes, financial protections
- Span 30+ years of history
- Are stored as PDF documents in a file share

**The problem**: All contract intelligence is locked in PDFs. Analysts spend 60%+ of their time finding information, not analyzing it.

### 2.2 Business Stakeholders

| Stakeholder | Need | How Platform Serves |
|---|---|---|
| VP of Contracting | Portfolio visibility, benchmarking | Genie queries + dashboard |
| Contract Analysts | Rate lookup, negotiation prep | Genie Space (10-sec answers) |
| Finance/Actuarial | Rate modeling, budget forecasting | Rate tables + program analysis |
| Network Management | Provider adequacy, coverage | Provider profile + program data |
| Legal/Compliance | Clause verification, audit readiness | Contract terms view |
| Operations | Amendment tracking, expiration | Amendment timeline |
| IT/Architecture | Platform maintenance, scaling | This KT document |

### 2.3 Document Taxonomy

| Document Type | Count | Content | Example |
|---|---|---|---|
| Base Agreement (new) | 76 | Original contract, all terms | Fee-for-service hospital agreement |
| Base Agreement (renewal) | 903 | Renewed terms, updated rates | Renewal with 3-year term |
| 1st-9th Amendment | 1,251 | Rate changes, clause modifications | Rate exhibit replacement |
| Amendment + Cover Memo | 604 | Summary + formal modification | CM summarizing rate changes |
| Cover Memo only | 416 | Executive summary of changes | Non-binding summary |
| Settlement | 57 | Financial resolution | Disputed payment resolution |
| Other | 109 | LRAs, LOAs, misc | Letter of agreement |

### 2.4 Rate Structure

BSC contracts use multiple reimbursement methodologies:

| Rate Type | Mechanism | Example |
|---|---|---|
| Per diem | Fixed $/day by service line | $5,027/day ICU |
| Case rate | Fixed $ per admission type | $18,511 per DRG case |
| Capitation (PMPM) | Per-member-per-month | $128.74 PMPM all services |
| % of charges | Percentage of billed charges | 65% of Medicare allowable |
| Fee schedule | Per-procedure pricing | $1,264 per outpatient surgical tier |

### 2.5 Amendment Supersession Model

Contracts evolve through amendments that supersede earlier terms:

```
Base Agreement (2017)
  └── 1st Amendment (2019): Replaces Exhibit C (rates)
       └── 2nd Amendment (2020): Modifies Section 5.12 (stop-loss)
            └── 3rd Amendment (2022): Replaces Exhibit C again (new rates)
                 └── 4th Amendment (2024): Adds CalPERS rates
                      └── 5th Amendment (2025): Modifies outpatient tiers

Current State = Base + cumulative amendments (latest supersedes earlier)
```

---

## 3. ARCHITECTURE OVERVIEW

### 3.1 High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    PROVIDER CONTRACT INTELLIGENCE PLATFORM                    │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │ LAYER 4: SERVING (Genie + Dashboard + Notebooks)                    │    │
│  │   tbl_genie_* (4 objects) → Genie Space → Natural Language          │    │
│  │   tbl_serving_* (10 objects) → Dashboard → Visual Analytics         │    │
│  │   Contract_Intelligence_Demo.ipynb → Notebook → Walkthrough         │    │
│  └───────────────────────────────────────────────────────────────────── │    │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │ LAYER 3: INTELLIGENCE (platform/04-11)                              │    │
│  │   Legal Chunking → Vector Search → Retrieval → Reranking           │    │
│  │   Benchmarks → Savings → Leverage → Scenarios → Evaluation          │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │ LAYER 2: ANALYTICS (platform/01-03 + extraction/08-15)             │    │
│  │   State Engine → Contract Registry → Amendment Registry             │    │
│  │   Reimbursement Rules → Rate Tables → Terms → Financial Protections │    │
│  │   Genie Layer Build → Serving Layer Build → Quality Audit → Gap Fill│    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │ LAYER 1: EXTRACTION (extraction/01-06)                              │    │
│  │   PDF Discovery → OCR (3-tier) → Metadata Parse → LLM Prompts      │    │
│  │   → LLM Extraction (REST API, 3 workers) → Validation (8 checks)   │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │ LAYER 0: SOURCE                                                     │    │
│  │   UC Volume: /Volumes/prod_adb/default/ext-data-volume-stmlz/...    │    │
│  │   597 provider folders → 10,372 PDFs → 27.3 GB                     │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 3.2 Modified Medallion Architecture

This platform uses a **modified medallion** approach — all tables reside in a single schema (`dev_adb.raw`) rather than separate bronze/silver/gold schemas:

| Logical Layer | Physical Location | Tables | Purpose |
|---|---|---|---|
| Bronze (raw extracts) | `dev_adb.raw` | JSON files in workspace | Raw LLM output |
| Silver (structured) | `dev_adb.raw` | `tbl_contract_*`, `tbl_v2_*` | Validated, typed tables |
| Gold (serving) | `dev_adb.raw` | `tbl_genie_*`, `tbl_serving_*` | Pre-aggregated for consumption |

**Why single schema?**: Development velocity — avoids cross-schema permission management during rapid iteration. Production recommendation: separate into `bronze`, `silver`, `gold` schemas.

### 3.3 Key Architecture Decisions

| Decision | Choice | Alternative Considered | Rationale |
|---|---|---|---|
| LLM API | Direct REST API | Spark `ai_query()` | 7× faster; no batch cascade failures |
| Model | Claude Sonnet 4.5 | GPT-4o, Haiku | Best quality for legal text extraction |
| Concurrency | 3 workers | 1, 5, 10 | Sweet spot: rate limit vs throughput |
| Output format | JSON (structured) | Markdown, text | Machine-parseable, Delta-ready |
| max_tokens | 65,536 | 32,768 | Larger contracts truncated at 32K |
| Chunking | 80K chars/segment | 50K, 150K | Fits context with system prompt |
| Checkpointing | Per-batch (file-level) | Per-provider, none | Resume after failure; no re-processing |
| Table format | Delta Lake | Parquet, Iceberg | Native Databricks; ACID, time travel |
| Search | Vector Search (hybrid) | LIKE/ILIKE only | Semantic similarity >> keyword |
| Serving | Genie Space | Custom UI, chatbot | Zero-code setup; enterprise governed |

### 3.4 Data Flow Diagram

```
/Volumes/.../Provider_Contracts/
    │
    ├── 597 provider folders
    │     └── providerID_name_contractID_docType_version.pdf
    │
    ▼ [extraction/01_file_discovery]
File Inventory (10,372 entries)
    │
    ▼ [extraction/02_ocr_extraction]
OCR Text (per-file, in-memory)
    │
    ▼ [extraction/03_metadata_parsing]
Metadata (provider_id, doc_type, version)
    │
    ▼ [extraction/04_llm_prompts + 05_llm_extraction]
JSON Extractions → data/json_extract/ (6,481 files)
    │
    ▼ [extraction/06_validation]
Validated + Quarantined extractions
    │
    ├──▼ [extraction/08-10] ─────────────────────────────────┐
    │  Rate Tables → tbl_contract_rates_all (81,892)        │
    │  Clauses/Terms → tbl_contract_clauses_terms (53,390)  │
    │  Documents → tbl_contract_documents_master (3,416)    │
    │  Codes → tbl_contract_codes_events (22,704)           │
    │  Parties → tbl_contract_parties                        │
    │  Financial → tbl_contract_financial_protections (5,278)│
    │                                                        │
    ├──▼ [platform/01-02] ──────────────────────────────────┤
    │  DDL → tbl_v2_contract_registry (1,948)               │
    │  DDL → tbl_v2_amendment_registry (1,563)              │
    │                                                        │
    ├──▼ [platform/03] ─────────────────────────────────────┤
    │  Migration → tbl_reimb_rate_rules (11,486)            │
    │  Migration → tbl_reimb_stop_loss (1,104)              │
    │                                                        │
    ├──▼ [platform/04-07] ──────────────────────────────────┤
    │  Chunking → tbl_retrieval_legal_units (75,306)        │
    │  Retrieval → hybrid 4-channel search                   │
    │  Citation → verification + telemetry                   │
    │                                                        │
    ├──▼ [platform/08] ─────────────────────────────────────┤
    │  Intelligence → tbl_intel_benchmark_results (711)     │
    │                                                        │
    ├──▼ [extraction/11-12] ────────────────────────────────┤
    │  Enrichment → dim_provider_canonical (489)            │
    │  Genie Build → tbl_genie_* (4 objects)               │
    │                                                        │
    └──▼ [extraction/13] ──────────────────────────────────┘
       Serving Build → tbl_serving_* (10 objects)
       
    ▼ [Genie Space + Dashboard]
End Users (Natural Language Queries)
```

---

## 4. END-TO-END PIPELINE

### 4.1 Pipeline Stages (Ordered Execution)

| Stage | Notebook(s) | Input | Output | Duration | Dependencies |
|---|---|---|---|---|---|
| **S1: Discovery** | `extraction/01` | UC Volume (PDFs) | File inventory DataFrame | 2 min | None |
| **S2: OCR** | `extraction/02` | PDF files | Text strings (in-memory) | Integrated with S4 | S1 |
| **S3: Metadata** | `extraction/03` | Filenames | provider_id, doc_type, version | <1 min | S1 |
| **S4: Prompts** | `extraction/04` | Doc type | Prompt text (4 types) | Config only | None |
| **S5: LLM Extract** | `extraction/05` | OCR text + prompts | JSON files (6,481) | 121 hours (full) | S2, S3, S4 |
| **S6: Validation** | `extraction/06` | JSON files | Validated JSONs + quarantine | 5 min | S5 |
| **S7: Build Rates** | `extraction/08` | Validated JSONs | tbl_contract_rates_all | 3 min | S6 |
| **S8: Build Terms** | `extraction/09` | Validated JSONs | tbl_contract_clauses_terms | 3 min | S6 |
| **S9: Build Docs** | `extraction/10` | Validated JSONs | tbl_contract_documents_master | 2 min | S6 |
| **S10: Enrich** | `extraction/11` | Core tables | dim_provider_canonical | 3 min | S7, S8, S9 |
| **S11: State Engine** | `platform/01-02` | Documents master | Contract + amendment registries | 2 min | S9 |
| **S12: Reimbursement** | `platform/03` | Rates table | tbl_reimb_rate_rules | 3 min | S7, S11 |
| **S13: Legal Chunk** | `platform/04` | Terms table | tbl_retrieval_legal_units | 5 min | S8 |
| **S14: Intelligence** | `platform/08` | Rate rules + registry | tbl_intel_* | 3 min | S12 |
| **S15: Genie Build** | `extraction/12` | All core tables | tbl_genie_* (4 objects) | 3 min | S7-S11 |
| **S16: Serving Build** | `extraction/13` | Genie + core tables | tbl_serving_* (10 objects) | 3 min | S15 |
| **S17: Quality Audit** | `extraction/14` | All tables | Audit scores + reports | 5 min | S15 |
| **S18: Gap Fill** | `extraction/15` | Audit results | Targeted re-extraction | Variable | S17 |
| **S19: Evaluation** | `platform/11` | Golden queries | Evaluation results | 2 min | S15 |

### 4.2 Execution Order (DAG)

```
S1 ──→ S2 ──→ S3 ──→ S5 ──→ S6 ──┬──→ S7 ──┬──→ S10 ──→ S15 ──→ S16
       │                           ├──→ S8 ──┤            │
       └──→ S4 (config)           ├──→ S9 ──┘            ├──→ S17 ──→ S18
                                   │                      │
                                   └──→ S11 ──→ S12 ──→ S14
                                        │
                                        └──→ S13 ──→ S19
```

### 4.3 Checkpointing Strategy

| Checkpoint | Location | Format | Purpose |
|---|---|---|---|
| File list | `data/checkpoints/file_inventory.json` | JSON | Resume after restart |
| Extraction progress | `data/checkpoints/extraction_progress.json` | JSON | Track processed files |
| Batch results | `data/checkpoints/batch_*.json` | JSON | Per-batch success/failure |
| Consolidated JSONs | `data/json_consolidated/` | JSON | Provider-level merged outputs |

**Resume Logic**: On restart, the pipeline reads `extraction_progress.json`, identifies unprocessed files, and continues from where it left off. No re-processing of successful files.

### 4.4 Error Handling

| Error Type | Handling | Recovery |
|---|---|---|
| LLM API timeout (1800s) | Logged, file skipped, retry next batch | Re-run pipeline (auto-skips processed) |
| LLM output truncation | `_repair_truncated_json()` closes brackets | Partial extraction saved, flagged |
| OCR failure | Fallback to lower-tier OCR | Tier 1 → Tier 2 → skip with log |
| JSON parse error | Logged to quarantine | Manual review + re-extract |
| Delta write failure | Transaction rollback (ACID) | Re-run specific stage |
| Rate limit (429) | Exponential backoff (30s base, 1 retry) | Automatic |
| Context window exceeded | Chunking at 80K chars | Segments merged post-extraction |

### 4.5 Feature Flags

```python
# platform/00_config.py
CLAIMS_AVAILABLE = False       # No claims feed connected
RERANKER_DEPLOYED = False      # Cross-encoder not yet deployed
FULL_CORPUS_PROCESSED = False  # 33% complete
VS_ENDPOINT_ACTIVE = True      # Vector Search is running
GENIE_SPACE_ACTIVE = True      # Genie Space is serving
```


---

## 5. COMPONENT-BY-COMPONENT BREAKDOWN

### 5.1 Component: OCR Engine (extraction/02)

| Attribute | Detail |
|---|---|
| **What it does** | Extracts text from PDF files using a 3-tier OCR strategy |
| **Why it exists** | PDFs contain both native text and scanned images; single method fails on ~40% |
| **Inputs** | PDF file bytes from UC Volume |
| **Outputs** | Unicode text string per file |
| **Dependencies** | PyMuPDF (fitz), Tesseract OCR |
| **Downstream impact** | All extraction quality depends on OCR quality |
| **Failure scenarios** | Corrupted PDF (skip), Image-only without Tesseract (empty text), Password-protected (skip) |

**Tier Strategy**:
- Tier 1 (60%): PyMuPDF native text extraction — instant, free
- Tier 2 (30%): PyMuPDF renders page → Tesseract OCR — 2-5 sec/page
- Tier 3 (10%): Complex layouts requiring commercial OCR — not yet implemented

### 5.2 Component: LLM Extraction Engine (extraction/04-05)

| Attribute | Detail |
|---|---|
| **What it does** | Sends OCR text to Claude Sonnet 4.5 with document-type-specific prompts |
| **Why it exists** | Converts unstructured legal text into V6 structured JSON schema |
| **Inputs** | OCR text + document metadata + system prompt |
| **Outputs** | Structured JSON (V6 schema) saved to `data/json_extract/` |
| **Dependencies** | Databricks serving endpoint, network access, API tokens |
| **Downstream impact** | Every downstream table depends on extraction quality |
| **Failure scenarios** | API timeout (1800s), rate limit (429), context overflow, output truncation |

**CRITICAL**: Uses direct REST API, NOT `ai_query()`. Chosen after `ai_query()` caused 10+ hour stalls due to Spark batch-level cascade failures.

### 5.3 Component: 4-Prompt Router (extraction/04)

| Prompt | Target | Tokens | Focus |
|---|---|---|---|
| `BASE_PROMPT` | Base agreements (new/renewal) | ~3,900 | Full V6 schema: all 20 sections |
| `AMENDMENT_PROMPT` | Amendments (1st through Nth) | ~2,800 | Rate changes + supersession + impact |
| `COVER_MEMO_PROMPT` | Cover memos | ~1,000 | Summary extraction only |
| `SETTLEMENT_PROMPT` | Settlement agreements | ~900 | Financial terms + dispute resolution |

### 5.4 Component: Validation Pipeline (extraction/06)

| Check | Method | Catches |
|---|---|---|
| 1. Medical code regex | Pattern matching (ICD-10, CPT, HCPCS, Revenue) | Invalid code formats |
| 2. Date verification | Multi-format parsing (12 patterns) | Impossible dates, hallucinations |
| 3. Rate verification | OCR-aware numeric matching | Fabricated dollar amounts |
| 4. rate_numeric post-processing | Type coercion + range checks | Non-numeric strings |
| 5. Delta readiness | Schema conformance check | Missing required fields |
| 6. Coverage scoring | V6 section completeness (%) | Under-extraction |
| 7. Classification validation | Document type vs content match | Misclassified documents |
| 8. Quarantine rules | Multi-signal threshold | Critical failures isolated |

### 5.5 Component: State Engine (platform/01-02)

| Attribute | Detail |
|---|---|
| **What it does** | Builds contract and amendment registries with lifecycle tracking |
| **Why it exists** | Contracts have state (ACTIVE/EXPIRED/TERMINATED) and amendments form chains |
| **Inputs** | `tbl_contract_documents_master` |
| **Outputs** | `tbl_v2_contract_registry`, `tbl_v2_amendment_registry` |
| **Dependencies** | DDL from `sql/state_engine_ddl.sql` |
| **Downstream impact** | All supersession logic depends on correct state computation |
| **Failure scenarios** | Duplicate contract_id (dedup handles), missing base agreement (orphan amendments) |

### 5.6 Component: Reimbursement Migration (platform/03)

| Attribute | Detail |
|---|---|
| **What it does** | Transforms raw extracted rates into normalized reimbursement rules |
| **Why it exists** | Raw rates are heterogeneous; rules need standardized structure for querying |
| **Inputs** | `tbl_contract_rates_all`, `tbl_v2_contract_registry`, taxonomy dimensions |
| **Outputs** | `tbl_reimb_rate_rules`, `tbl_reimb_stop_loss`, `tbl_reimb_lesser_of`, `tbl_reimb_carve_outs` |
| **Dependencies** | `sql/reimbursement_ddl.sql`, `sql/taxonomy_seed.sql` |
| **Downstream impact** | Intelligence benchmarks, savings analysis |
| **Failure scenarios** | Unmapped rate types (classified as 'other'), string-to-numeric cast failures |

### 5.7 Component: Vector Search / Legal Chunking (platform/04)

| Attribute | Detail |
|---|---|
| **What it does** | Chunks contract terms into retrieval-optimized units and indexes for semantic search |
| **Why it exists** | Enables semantic clause search beyond keyword matching |
| **Inputs** | `tbl_contract_terms_vs_ready` (69K rows) |
| **Outputs** | `tbl_retrieval_legal_units` (75K-83K units), VS index |
| **Dependencies** | `databricks-vectorsearch` SDK, VS endpoint |
| **Downstream impact** | Retrieval quality for clause-type questions |
| **Failure scenarios** | VS endpoint cold start (30-60s), embedding API rate limits, index sync lag |

### 5.8 Component: Intelligence Engine (platform/08)

| Attribute | Detail |
|---|---|
| **What it does** | Generates benchmarks, savings opportunities, leverage scores |
| **Why it exists** | Transforms rate data into actionable negotiation intelligence |
| **Inputs** | `tbl_reimb_rate_rules`, `tbl_v2_contract_registry`, dimensions |
| **Outputs** | `tbl_intel_benchmark_results`, `tbl_intel_renewal_priority` |
| **Dependencies** | Reimbursement migration complete |
| **Failure scenarios** | Insufficient data for percentile calc (min 5 providers per group) |

### 5.9 Component: Genie Layer Build (extraction/12)

| Attribute | Detail |
|---|---|
| **What it does** | Creates 4 purpose-built objects optimized for natural language queries |
| **Why it exists** | Shields business users from 30+ tables; adds NL-friendly column comments |
| **Inputs** | All core tables + dim_provider_canonical |
| **Outputs** | `tbl_genie_provider_profile`, `tbl_genie_rates_current`, `tbl_genie_amendment_timeline`, `vw_genie_contract_terms` |
| **Downstream impact** | Genie Space accuracy; column comments drive SQL generation |
| **Failure scenarios** | Canonicalization gaps (duplicates), dedup residuals (3.7%) |

### 5.10 Component: Quality Audit (extraction/14)

| Attribute | Detail |
|---|---|
| **What it does** | LLM-based second pass reviewing extraction quality (scores 1-10) |
| **Why it exists** | Identifies systematic extraction gaps for targeted remediation |
| **Inputs** | Extracted JSON + original OCR text (sample) |
| **Outputs** | Audit scores, gap identification, remediation targets |
| **Dependencies** | Claude Sonnet 4.5 (additional cost: $0.045/file) |
| **Downstream impact** | Triggers gap-fill pass for low-scoring extractions |

---

## 6. TABLE-BY-TABLE BREAKDOWN

### 6.1 Contract Core Tables

#### `tbl_contract_rates_all` (81,892 rows)
| Attribute | Detail |
|---|---|
| **Purpose** | Master table of all extracted rate lines across all documents |
| **Grain** | One row per rate line per source document |
| **Primary key** | (source_filename, rate_category, service_category, program, effective_date) |
| **Key columns** | provider_id, rate_text, rate_numeric, rate_type_detail, amendment_order, status, is_latest_version |
| **Upstream** | extraction/08_build_rates ← json_extract/ |
| **Downstream** | tbl_genie_rates_current, tbl_reimb_rate_rules, intelligence |

#### `tbl_contract_clauses_terms` (53,390 rows)
| Attribute | Detail |
|---|---|
| **Purpose** | All extracted clauses, definitions, sections |
| **Grain** | One row per clause/term per source document |
| **Key columns** | provider_id, content_type, topic, title, content_text, source_filename |
| **Downstream** | vw_genie_contract_terms, tbl_retrieval_legal_units |

#### `tbl_contract_documents_master` (3,416 rows)
| Attribute | Detail |
|---|---|
| **Purpose** | Document-level metadata: one row per processed PDF |
| **Grain** | One row per source_filename |
| **Key columns** | provider_id, document_type, amendment_order, effective_date_parsed, rate_count, v6_coverage_pct |
| **Downstream** | tbl_v2_contract_registry, tbl_genie_amendment_timeline |

#### `tbl_contract_financial_protections` (5,278 rows)
| **Purpose** | Stop-loss, lesser-of, carve-out, corridor financial protections |
| **Key columns** | provider_id, protection_type, threshold_numeric, reimbursement_pct_numeric |
| **Note** | `aggregate_cap` and `corridor` are STRING (need try_cast to FLOAT) |

#### `tbl_contract_codes_events` (22,704 rows)
| **Purpose** | Medical codes (ICD-10, CPT, HCPCS, Revenue), HACs, never events |
| **Key columns** | provider_id, content_type, code_value, condition_name, adjustment_rule |

### 6.2 State Engine Tables

#### `tbl_v2_contract_registry` (1,853 rows)
| **Purpose** | Contract lifecycle: one row per contract with status tracking |
| **Grain** | One row per contract_id |
| **Key columns** | contract_id, provider_id, status, effective_from, effective_to, total_amendments |
| **Partitioning** | Liquid clustering on (provider_id, status) |

#### `tbl_v2_amendment_registry` (1,563 rows)
| **Purpose** | Amendment tracking: position in chain, supersession |
| **Key columns** | contract_id, amendment_order, effective_date, supersedes, status |

### 6.3 Reimbursement Tables

#### `tbl_reimb_rate_rules` (11,486 rows)
| **Purpose** | Normalized reimbursement rules with formula JSON |
| **Grain** | One row per rule (contract x service_line x program) |
| **Key columns** | rule_id, contract_id, provider_id, rate_domain, formula_type, formula_json, rate_numeric |

#### `tbl_reimb_stop_loss` (1,104 rows)
| **Purpose** | Stop-loss provisions with threshold and reimbursement terms |

### 6.4 Genie Serving Tables

| Table | Rows | Grain | Column Comments |
|---|---|---|---|
| `tbl_genie_provider_profile` | 284 | 1 per canonical facility | 18/18 (100%) |
| `tbl_genie_rates_current` | 6,677 | 1 per deduped rate line | 15/15 (100%) |
| `tbl_genie_amendment_timeline` | 3,416 | 1 per document in chain | 25/25 (100%) |
| `vw_genie_contract_terms` | 87,085 | 1 per clause/code/party | 3/10 (30%) — GAP |

### 6.5 Dimension Tables

| Table | Rows | Purpose |
|---|---|---|
| `dim_provider_canonical` | 489 | Facility identity resolution (many IDs → one) |
| `dim_service_line_taxonomy` | 50 | Standard service line hierarchy |
| `dim_service_line_patterns` | 45 | Regex patterns for service line classification |
| `dim_network` | ~10 | Network tier definitions |
| `dim_service_category` | ~30 | Service category standardization |

### 6.6 Intelligence Tables

| Table | Rows | Purpose |
|---|---|---|
| `tbl_intel_benchmark_results` | 711 | Rate percentiles by service_line x domain |
| `tbl_intel_renewal_priority` | ~1,478 | Contracts ranked by renewal urgency |
| `tbl_retrieval_legal_units` | 75,306 | Chunked legal text for vector search |
| `tbl_eval_golden_queries` | 20 | Golden query evaluation set |

### 6.7 Serving Tables (tbl_serving_*)

| Table | Purpose |
|---|---|
| `tbl_serving_rate_card` | Pre-normalized, deduplicated rate card |
| `tbl_serving_provider_summary` | Rebuilt provider profile with corrected aggregates |
| `tbl_serving_amendment_history` | Parsed amendment timeline with computed ordering |
| `tbl_serving_capitation_card` | Flat capitation rates (age_gender_band, pmpm_rate) |
| `tbl_serving_case_rate_card` | Inpatient case rates by DRG category |
| `tbl_serving_outpatient_card` | Outpatient rates by tier/category |
| `tbl_serving_stop_loss` | Stop-loss provisions with computed fields |
| `tbl_serving_parties` | Contract parties (plan, provider, TPA) |
| `tbl_serving_services_coverage` | Services scope per contract |
| `tbl_serving_regional_factors` | Geographic rate adjustments |

---

## 7. NOTEBOOK-BY-NOTEBOOK BREAKDOWN

### 7.1 Extraction Notebooks (`extraction/`)

| # | File | Size | Purpose | Run After | Creates |
|---|---|---|---|---|---|
| 01 | `01_file_discovery.py` | 10 KB | Scans UC Volume, builds file inventory DataFrame | None | File list in memory |
| 02 | `02_ocr_extraction.py` | 15 KB | 3-tier OCR: PyMuPDF → Tesseract → (Tier 3 future) | 01 | Text in memory |
| 03 | `03_metadata_parsing.py` | 5 KB | Parses filename into provider_id, doc_type, version | 01 | Metadata DataFrame |
| 04 | `04_llm_prompts.py` | 26 KB | Defines 4 document-type-specific prompts (V6 schema) | None (config) | Prompt strings |
| 05 | `05_llm_extraction.py` | 32 KB | REST API extraction with 3 concurrent workers | 02, 03, 04 | `data/json_extract/*.json` |
| 06 | `06_validation.py` | 60 KB | 8-check validation pipeline | 05 | Validated JSONs + quarantine |
| 08 | `08_build_rates.py` | 31 KB | Builds tbl_contract_rates_all from validated JSONs | 06 | `tbl_contract_rates_all` |
| 09 | `09_build_terms.py` | 19 KB | Builds clauses, codes, parties tables | 06 | `tbl_contract_clauses_terms`, `tbl_contract_codes_events` |
| 10 | `10_build_documents.py` | 18 KB | Builds document master from extraction metadata | 06 | `tbl_contract_documents_master` |
| 11 | `11_enrich_tables.py` | 22 KB | Canonical provider resolution + enrichment | 08, 09, 10 | `dim_provider_canonical` |
| 12 | `12_build_genie.py` | 27 KB | Builds 4 Genie serving objects | All above | `tbl_genie_*` (4 tables) |
| 13 | `13_build_serving.py` | 27 KB | Builds 10 serving tables (pre-normalized) | 12 | `tbl_serving_*` (10 tables) |
| 14 | `14_quality_audit.py` | 35 KB | LLM-based quality audit pass | 12 | Audit scores |
| 15 | `15_gap_filler.py` | 33 KB | Targeted re-extraction for low-scoring files | 14 | Updated JSONs |
| — | `_config.py` | 2 KB | Shared constants (CATALOG, SCHEMA, paths) | — | Config |

### 7.2 Platform Modules (`platform/`)

| # | File | Size | Purpose | Run After | Creates |
|---|---|---|---|---|---|
| 00 | `00_config.py` | 10 KB | Constants, utilities, feature flags | None (config) | Config namespace |
| 01 | `01_execute_ddl.py` | 5 KB | Executes DDL from sql/ folder | None | Tables (DDL) |
| 02 | `02_state_engine.py` | 12 KB | Populates contract + amendment registries | 01, extraction/10 | `tbl_v2_*` registry tables |
| 03 | `03_reimbursement_migration.py` | 28 KB | Migrates rates → normalized rules | 02, extraction/08 | `tbl_reimb_*` tables |
| 04 | `04_legal_chunking.py` | 9 KB | Chunks terms into 83K legal retrieval units | extraction/09 | `tbl_retrieval_legal_units` |
| 05 | `05_retrieval_engine.py` | 31 KB | 4-channel hybrid retrieval + Reciprocal Rank Fusion | 04 | Retrieval functions |
| 07 | `07_citation_verification.py` | 8 KB | 6-check verification engine + telemetry | 05 | Verified results + telemetry |
| 08 | `08_intelligence.py` | 10 KB | Benchmarks, spend, savings, renewal scoring | 03 | `tbl_intel_*` tables |
| 11 | `11_evaluation_harness.py` | 12 KB | Golden query set + regression testing | 12 (genie build) | `tbl_eval_golden_queries` |
| — | `run_platform_modules_orchestrator.ipynb` | 4 KB | Sequential execution coordinator | All platform modules | Orchestration |

### 7.3 SQL Files (`sql/`)

| File | Size | Purpose | Used By |
|---|---|---|---|
| `state_engine_ddl.sql` | 20 KB | CREATE TABLE for contract/amendment registries | platform/01 |
| `reimbursement_ddl.sql` | 17 KB | CREATE TABLE for rate rules, stop-loss, carve-outs | platform/01 |
| `taxonomy_seed.sql` | 14 KB | INSERT seed data for dimensions | platform/01 |

**Important**: SQL files use semicolons as statement separators, but COMMENT strings may contain semicolons. The DDL executor uses quote-aware splitting.

---

## 8. FOLDER-BY-FOLDER BREAKDOWN

### 8.1 Project Root

```
/Workspace/Users/adixit01@blueshieldca.com/Contract_Codification_Pipeline/
├── README.md                          (7.7 KB)  Entry-point documentation
├── Contract_Intelligence_Demo.ipynb   (132 KB)  Full demo notebook
├── extraction/                        (15 files) Core extraction pipeline
├── platform/                          (10 files) Intelligence platform
├── sql/                               (3 files)  DDL definitions
├── data/                              (3 dirs)   Intermediate data
├── docs/                              (26 files) Design documentation
└── Architecture_Info/                 (6 files)  Architecture review docs
```

### 8.2 `extraction/` — Core Extraction Pipeline

**Purpose**: Converts raw PDFs into structured Delta tables.
**Execution order**: 01 → 02 → 03 → 04 → 05 → 06 → 08 → 09 → 10 → 11 → 12 → 13 → 14 → 15
**Total size**: ~380 KB of Python code
**Key patterns**: Checkpoint-resume, batch processing, REST API calls, Delta CTAS

### 8.3 `platform/` — Intelligence Platform

**Purpose**: Post-extraction analytics, search, intelligence.
**Execution order**: 00 (config) → 01 (DDL) → 02 (state) → 03 (reimb) → 04 (chunk) → 05 (retrieval) → 07 (citation) → 08 (intel) → 11 (eval)
**Total size**: ~145 KB of Python code
**Key patterns**: SQL-heavy transforms, Vector Search SDK, formula parsing

### 8.4 `data/` — Intermediate Data

```
data/
├── json_extract/          (6,481 files)  Raw LLM output per PDF
│   └── {source_filename}.json           V6 structured extraction
├── json_consolidated/     (456 files)    Provider-level merged JSONs
│   └── {provider_id}_consolidated.json  All docs for one provider
└── checkpoints/           (4 files)      Pipeline resume state
    ├── file_inventory.json              Complete file list
    ├── extraction_progress.json         Processed file tracking
    └── batch_*.json                     Per-batch results
```

### 8.5 `docs/` — Design Documentation

```
docs/
├── contract_corpus_summary.md          Corpus analysis (10,372 files)
├── state_engine/                       (6 docs)
│   ├── contract_state_engine_design.md
│   ├── amendment_graph_architecture.md
│   ├── bitemporal_state_model.md
│   ├── governing_state_computation_plan.md
│   ├── point_in_time_query_design.md
│   └── supercession_resolution_algorithms.md
├── reimbursement/                      (7 docs)
│   ├── computable_reimbursement_architecture.md
│   ├── reimbursement_model.md
│   ├── rate_rule_engine_design.md
│   ├── service_line_normalization.md
│   ├── migration_reference.sql
│   ├── validation_reference.sql
│   └── views_reference.sql
├── retrieval/                          (5 docs)
│   ├── retrieval_architecture.md
│   ├── legal_grounding_architecture.md
│   ├── reranking_pipeline_design.md
│   ├── citation_verification_framework.md
│   └── retrieval_evaluation_framework.md
└── intelligence/                       (5 docs)
    ├── contract_leverage_framework.md
    ├── negotiation_intelligence.md
    ├── renewal_intelligence.md
    ├── scenario_modeling_engine.md
    └── spend_weighted_analytics.md
```

### 8.6 `Architecture_Info/` — Architecture Review Documents

```
Architecture_Info/
├── ARCHITECTURE_REVIEW.md             (121 KB)  Full architecture review
├── AI_LLM_PIPELINE_REVIEW.md          (61 KB)   AI/LLM deep analysis
├── GENIE_SPACE_ANALYSIS.md            (62 KB)   Genie Space analysis
├── COST_ANALYSIS_FINOPS.md            (52 KB)   Cost & FinOps review
├── LEADERSHIP_DEMO_GUIDE.md           (50 KB)   Demo & presentation guide
└── KNOWLEDGE_TRANSFER.md              (this file)
```

### 8.7 Source Data Location

```
/Volumes/prod_adb/default/ext-data-volume-stmlz/Health_Plan_Ops_Transformation/Provider_Contracts/
├── 597 provider folders
│   └── {providerID}_{providerName}_{contractID}_{docType}_{version}.pdf
└── Total: 10,372 PDFs (27.3 GB)
```

---

## 9. OPERATIONAL GUIDE

### 9.1 Running the Pipeline (First Time)

```
Step 1: Configure
  → Open extraction/_config.py
  → Set CATALOG = "dev_adb", SCHEMA = "raw"
  → Verify Volume path accessible

Step 2: Extract (Long-running — ~121 hours for full corpus)
  → Run extraction/01_file_discovery.py
  → Run extraction/05_llm_extraction.py (includes 02, 03, 04 internally)
  → Monitor: data/checkpoints/extraction_progress.json

Step 3: Validate & Build Tables
  → Run extraction/06_validation.py
  → Run extraction/08_build_rates.py
  → Run extraction/09_build_terms.py
  → Run extraction/10_build_documents.py
  → Run extraction/11_enrich_tables.py

Step 4: Build Intelligence Layer
  → Run platform/01_execute_ddl.py
  → Run platform/02_state_engine.py
  → Run platform/03_reimbursement_migration.py
  → Run platform/04_legal_chunking.py
  → Run platform/08_intelligence.py

Step 5: Build Serving Layer
  → Run extraction/12_build_genie.py
  → Run extraction/13_build_serving.py
  → Run platform/11_evaluation_harness.py
```

### 9.2 Running an Incremental Update

When new PDFs are added to the Volume:
1. Run `extraction/01_file_discovery.py` — detects new files
2. Run `extraction/05_llm_extraction.py` — processes only unprocessed files (checkpoint-aware)
3. Run `extraction/06_validation.py` through `extraction/13_build_serving.py`
4. Genie tables are rebuilt (CREATE OR REPLACE)

### 9.3 Monitoring the Extraction

| What to Monitor | How | Normal Range |
|---|---|---|
| Files processed | `data/checkpoints/extraction_progress.json` | Increment by batch size |
| Extraction rate | Notebook cell output | 1.4 files/minute (3 workers) |
| API errors | Extraction log output | <5% failure rate |
| JSON quality | `data/json_extract/` file sizes | 50-200 KB per file |
| Token usage | Foundation Model API metrics | ~67K tokens/file |

### 9.4 Daily Operations Checklist

- [ ] Verify Genie Space is responding (ask 1 test question)
- [ ] Check SQL warehouse is set to auto-start
- [ ] Review any extraction job failures (if running)
- [ ] Confirm VS endpoint is healthy (if active)

### 9.5 Weekly Operations

- [ ] Run `OPTIMIZE` on large tables (rates_all, clauses_terms, retrieval_legal_units)
- [ ] Review extraction progress toward full corpus
- [ ] Check Delta table sizes (DESCRIBE DETAIL)
- [ ] Validate golden queries pass rate

---

## 10. TROUBLESHOOTING GUIDE

### 10.1 Common Issues & Resolutions

| Issue | Symptoms | Root Cause | Resolution |
|---|---|---|---|
| **LLM extraction stall** | No progress for >30 min | API rate limit or endpoint down | Check serving endpoint status; reduce concurrency to 1 |
| **Truncated JSON output** | File ends mid-object | max_tokens hit (65K) | `_repair_truncated_json()` auto-fixes; re-extract if critical |
| **Empty OCR text** | JSON has no rate/clause data | Image-only PDF, Tier 1 failed | Check if Tier 2 (Tesseract) activated; manual check PDF |
| **Duplicate rates in Genie** | Same rate shows 2-3 times | 3.7% residual dedup failure | Manual review; adjust dedup window logic |
| **Wrong provider canonical** | "Sharp" maps to wrong facility | Canonicalization clustering error | Update dim_provider_canonical manually |
| **Delta write fails** | `DELTA_INVALID_SCHEMA` error | Column type mismatch | Check STRING vs INT; use try_cast |
| **VS endpoint cold** | First query takes 30-60 sec | Endpoint was scaled to zero | Pre-warm with test query before demo |
| **Genie wrong answer** | Incorrect SQL generated | Missing/wrong column comment | Fix column comment; rebuild Genie layer |
| **Checkpoint corrupted** | Pipeline re-processes old files | JSON parse error in checkpoint | Delete checkpoint; pipeline re-scans (skips existing JSONs) |
| **SQL DDL fails** | CREATE TABLE error | DEFAULT column not supported | Retry with DEFAULT stripped (fallback in 01_execute_ddl) |

### 10.2 Emergency Recovery Procedures

#### Scenario: Extraction Pipeline Fails Mid-Run
```
1. Check data/checkpoints/extraction_progress.json for last successful file
2. Check data/json_extract/ for the last written JSON
3. Re-run extraction/05_llm_extraction.py — auto-resumes from checkpoint
4. No data loss: checkpoint + existing JSONs prevent re-processing
```

#### Scenario: Genie Space Returns Incorrect Data
```
1. Verify in SQL: query tbl_genie_rates_current directly
2. If table data is wrong: re-run extraction/12_build_genie.py
3. If table data is correct but Genie misinterprets: fix column comments
4. Test with golden query from tbl_eval_golden_queries
```

#### Scenario: Need to Reprocess a Specific Provider
```
1. Delete JSONs: rm data/json_extract/{provider_id}*.json
2. Update checkpoint to remove those files from "processed" list
3. Re-run extraction pipeline — picks up only deleted files
4. Re-run build stages (08-13) to rebuild tables
```

### 10.3 Known Limitations & Workarounds

| Limitation | Workaround |
|---|---|
| `ai_query()` timeouts on large files | Use REST API (already implemented) |
| Correlated EXISTS not supported on runtime | Rewrite as JOIN |
| Delta DEFAULT columns need feature flag | Strip DEFAULT in DDL fallback |
| `exhibits_replaced_count` is STRING array | Use JSON parse, not direct INT cast |
| `prior_rates_superseded` is STRING 'True'/'False' | Use `= 'True'` not `= TRUE` |
| VS SDK needs pip install on shared compute | `%pip install databricks-vectorsearch` + restart |

---

## 11. MONITORING GUIDE

### 11.1 Key Health Metrics

| Metric | Table/Source | Target | Alert If |
|---|---|---|---|
| Total rows (rates) | `SELECT COUNT(*) FROM tbl_contract_rates_all` | Growing | Sudden drop >10% |
| Genie response time | Query latency (observed) | <15 seconds | >30 seconds |
| Null rate_numeric % | `tbl_genie_rates_current` | <10% | >15% |
| Provider count | `tbl_genie_provider_profile` | Growing | Drop |
| Extraction success | Checkpoint JSON | >95% | <90% |
| Golden query pass | `tbl_eval_golden_queries` vs results | >80% | <70% |

### 11.2 Recommended Monitoring Queries

```sql
-- Health check: row counts
SELECT 'rates_all' AS tbl, COUNT(*) FROM dev_adb.raw.tbl_contract_rates_all
UNION ALL SELECT 'genie_rates', COUNT(*) FROM dev_adb.raw.tbl_genie_rates_current
UNION ALL SELECT 'genie_profile', COUNT(*) FROM dev_adb.raw.tbl_genie_provider_profile
UNION ALL SELECT 'docs_master', COUNT(*) FROM dev_adb.raw.tbl_contract_documents_master;

-- Quality check: null rates
SELECT 
  COUNT(*) AS total,
  COUNT(rate_numeric) AS has_numeric,
  ROUND(100.0 * COUNT(rate_numeric) / COUNT(*), 1) AS pct_numeric
FROM dev_adb.raw.tbl_genie_rates_current;

-- Freshness check: latest processed doc
SELECT MAX(effective_date_parsed) AS latest_doc
FROM dev_adb.raw.tbl_genie_amendment_timeline;
```

### 11.3 Future: Lakehouse Monitoring Setup

When implemented, configure Databricks Lakehouse Monitoring on:
- `tbl_genie_rates_current` — profile drift on rate_numeric distribution
- `tbl_genie_provider_profile` — row count monitoring
- `tbl_contract_rates_all` — schema drift detection

---

## 12. DEPLOYMENT GUIDE

### 12.1 Current Deployment Model

**Environment**: Single workspace, single schema, manual execution
**No CI/CD pipeline exists**. All deployment is manual notebook execution.

### 12.2 Recommended Production Deployment

#### Phase 1: Lakeflow Jobs (Immediate)
```
Job 1: "Contract Extraction" (weekly or on-demand)
  Task 1: extraction/01_file_discovery
  Task 2: extraction/05_llm_extraction
  Task 3: extraction/06_validation
  Task 4: extraction/08-10 (parallel: rates, terms, docs)
  Task 5: extraction/11_enrich_tables
  Cluster: Single-node DS3_v2 (extraction is I/O bound)

Job 2: "Platform Build" (daily or post-extraction)
  Task 1: platform/01_execute_ddl
  Task 2: platform/02_state_engine
  Task 3: platform/03_reimbursement_migration
  Task 4: platform/04_legal_chunking (parallel with 03)
  Task 5: platform/08_intelligence
  Task 6: extraction/12_build_genie
  Task 7: extraction/13_build_serving
  Cluster: Small serverless SQL + single-node for chunking
```

#### Phase 2: Environment Promotion
```
DEV:  dev_adb.raw     (current — development + testing)
STG:  stg_adb.silver  (staging — validation before prod)
PROD: prod_adb.gold   (production — Genie Space + dashboard)
```

#### Phase 3: CI/CD (Declarative Automation Bundles)
```yaml
# bundle.yml (conceptual)
resources:
  jobs:
    contract_extraction:
      tasks:
        - task_key: file_discovery
          notebook_task:
            notebook_path: extraction/01_file_discovery.py
        - task_key: llm_extraction
          depends_on: [file_discovery]
          notebook_task:
            notebook_path: extraction/05_llm_extraction.py
    platform_build:
      schedule:
        quartz_cron_expression: "0 0 6 * * ?"  # Daily 6 AM
```

### 12.3 Rollback Procedure

Delta Lake provides time travel for instant rollback:
```sql
-- Rollback to previous version
RESTORE TABLE dev_adb.raw.tbl_genie_rates_current TO VERSION AS OF 237;

-- Check history
DESCRIBE HISTORY dev_adb.raw.tbl_genie_rates_current;
```

---

## 13. SCALING GUIDE

### 13.1 Scaling Dimensions

| Dimension | Current | Full Corpus | Multi-Plan (5x) |
|---|---|---|---|
| PDFs | 3,416 processed | 10,372 | 51,860 |
| Providers | 284 canonical | ~450 | ~2,000 |
| Rate lines | 81,892 | ~240,000 | ~1.2M |
| Clause items | 87,085 | ~255,000 | ~1.2M |
| Users | 5 (dev) | 200 | 500+ |
| Plans | 1 (BSC-CA) | 1 | 5 |

### 13.2 Scaling Bottlenecks

| Bottleneck | Trigger | Mitigation |
|---|---|---|
| LLM API throughput | >3 concurrent workers | Increase quota; multi-model routing |
| vw_genie_contract_terms LIKE queries | >200K rows | Materialize view; add bloom filters |
| SQL warehouse concurrency | >50 simultaneous users | Upgrade to Medium/Large serverless |
| VS index size | >500K vectors | Enable sharding |
| Extraction time (121 hours full) | Full corpus | 10 workers = 12 hours |

### 13.3 Multi-Plan Scaling Pattern

```
Per new Blue plan:
1. Create schema: CREATE SCHEMA {plan}_contracts
2. Copy extraction pipeline (same code, plan-specific config)
3. Process PDFs (4-6 weeks for ~10K files)
4. Build Genie serving tables (same DDL)
5. Create plan-specific Genie Space
6. Copy column comments + semantic instructions
7. Grant access to plan user groups
```

### 13.4 Performance Optimization

| Action | When | Impact |
|---|---|---|
| `OPTIMIZE` on large tables | Weekly | 50% fewer files, faster scans |
| `VACUUM RETAIN 7 DAYS` | Weekly | Reclaim old file versions |
| Liquid clustering on provider_id | At creation | Targeted scans for single-provider queries |
| Bloom filters on content_text | At scale (>100K rows) | 2-5x LIKE acceleration |
| Materialized aggregate tables | When query latency >5s | Eliminate runtime computation |

---

## 14. FAQ

### 14.1 General

**Q: How long does it take to process the full corpus?**
A: At current throughput (1.4 files/minute with 3 workers), full corpus takes ~121 hours (5 days). With 10 workers: ~12 hours.

**Q: What happens if the LLM hallucinates a rate?**
A: The 8-check validation pipeline catches most issues. Specifically, rate verification cross-references against OCR text. If a rate doesn't appear in the source PDF text, it's flagged as unverified.

**Q: Can I re-run the pipeline without reprocessing everything?**
A: Yes. The checkpoint system (`data/checkpoints/extraction_progress.json`) tracks processed files. Re-running skips already-processed files automatically.

**Q: What if a provider's name changes?**
A: Update `dim_provider_canonical` with the new name mapping. Then re-run `extraction/12_build_genie.py` to propagate.

**Q: How often should the data be refreshed?**
A: After each extraction batch. For production: daily rebuild of serving tables, weekly extraction of new PDFs.

### 14.2 Technical

**Q: Why REST API instead of ai_query()?**
A: `ai_query()` wraps calls in Spark SQL, adding Spark overhead and batch-level failure cascading. For 100+ page PDFs needing 60-sec LLM calls, Spark timeouts caused 10+ hour stalls. Direct REST API gives per-file control, explicit timeouts, and 7× faster throughput.

**Q: Why max_tokens = 65,536?**
A: The previous 32,768 caused truncation on complex contracts with many rate tables. Observed peak output is ~48K tokens. Setting 65K provides headroom without waste (output stops at natural completion).

**Q: Why 3 concurrent workers?**
A: Balances throughput vs rate limits. 1 worker = too slow. 5+ workers = frequent 429 errors requiring backoff. 3 workers achieved 1.4 files/minute with <5% rate-limit events.

**Q: Why single schema (dev_adb.raw) instead of medallion?**
A: Development velocity. During rapid iteration, cross-schema permissions were friction. Production recommendation: separate into `bronze`/`silver`/`gold` schemas.

**Q: What's a sentinel value (amendment_order >= 100)?**
A: Documents that couldn't be reliably ordered in the amendment chain are assigned order 100+ to exclude them from sequential ordering. Genie tables filter these out for accurate amendment counts.

### 14.3 Business

**Q: Which providers have the most complete data?**
A: St Joseph's Medical Center (3,001 rates), Greater Newport Physicians (2,830), UC Davis (2,722), Hoag Memorial (2,247). Use these for demos.

**Q: What programs are covered?**
A: 8 canonical programs: Commercial (68%), Medicare (10%), Medi-Cal (9%), All Programs (8%), CalPERS (3%), Other (1%), Commercial Trio (<1%), Dual Eligible (<1%).

**Q: What rate types are most common?**
A: Outpatient other (35%), Capitation (34%), Inpatient per diem (11%), Inpatient case rate (8%), Inpatient other (6%), Outpatient surgical (4%).

---

## 15. GLOSSARY

| Term | Definition |
|---|---|
| **Amendment** | A document that modifies an existing contract (rates, terms, or both) |
| **Amendment chain** | The ordered sequence of amendments for a single contract |
| **Base agreement** | The original contract document establishing the relationship |
| **Canonical name** | The resolved facility-level name (e.g., "Sharp Memorial Hospital") |
| **Capitation** | Per-member-per-month payment regardless of services rendered |
| **Carve-out** | Services excluded from the main payment arrangement |
| **Case rate** | Fixed payment per admission/case regardless of length of stay |
| **Cover memo** | Non-binding summary document accompanying an amendment |
| **DRG** | Diagnosis-Related Group — classification system for inpatient stays |
| **Fee-for-service (FFS)** | Payment per individual service rendered |
| **Genie Space** | Databricks AI/BI natural language interface for querying tables |
| **Golden queries** | Pre-defined test questions with expected answers for evaluation |
| **HAC** | Hospital-Acquired Condition — CMS penalty program |
| **Lesser-of** | Payment rule: pay the lesser of two rate schedules |
| **Liquid clustering** | Delta Lake optimization: data co-located by specified columns |
| **Never event** | Serious patient safety event that should never occur |
| **OCR** | Optical Character Recognition — converting images to text |
| **Per diem** | Daily rate for inpatient services |
| **PMPM** | Per Member Per Month — capitation payment unit |
| **Provider canonical** | The resolved facility identity across multiple provider_ids |
| **Rate_numeric** | The extracted dollar amount as DOUBLE (NULL for formula rates) |
| **Rate_text** | The original text representation of the rate from the contract |
| **Sentinel value** | amendment_order >= 100 indicating unordered documents |
| **Stop-loss** | Financial protection triggered when costs exceed a threshold |
| **Supersession** | When a newer amendment replaces terms from an earlier one |
| **UC** | Unity Catalog — Databricks governance and metadata layer |
| **V6 schema** | The current extraction output JSON schema (20 sections) |
| **Vector Search** | Databricks semantic search using embedding similarity |
| **VS endpoint** | The running instance of Vector Search index |

---

## 16. FUTURE ENHANCEMENTS

### 16.1 Immediate (1-4 Weeks)

| Enhancement | Owner | Impact |
|---|---|---|
| Complete full corpus extraction (remaining 6,900 PDFs) | Data Engineering | Full coverage |
| Add column comments to vw_genie_contract_terms (6 missing) | Data Engineering | Genie accuracy |
| Implement column masking on rate_numeric | Platform/Security | Governance |
| Transfer table ownership to service principal | Platform | Bus factor |
| Create Lakeflow Jobs for orchestration | Data Engineering | Automation |

### 16.2 Short-Term (1-3 Months)

| Enhancement | Owner | Impact |
|---|---|---|
| Row-level security by provider group | Platform/Security | Multi-user isolation |
| Lakehouse Monitoring on Genie tables | Data Engineering | Data quality alerts |
| Rate trend table (historical snapshots) | Data Engineering | Temporal queries |
| Multi-model LLM strategy (tiered by doc type) | Data Engineering | 45% cost reduction |
| User training and champion program | Business | Adoption |
| VS endpoint business-hours scheduling | Platform | 67% cost savings |

### 16.3 Medium-Term (3-6 Months)

| Enhancement | Owner | Impact |
|---|---|---|
| Claims data integration | Data Engineering + Actuary | Cost-to-rate correlation |
| Multi-plan schema architecture | Architecture | Blue plan expansion |
| Cross-encoder reranker deployment | ML Engineering | Retrieval quality |
| Scenario engine integration with Genie | Data Engineering | What-if queries |
| Provider-specific Genie instructions | Data Engineering | Per-provider accuracy |
| Auto-refresh pipeline on new PDF ingestion | Data Engineering | Real-time updates |

### 16.4 Long-Term (6-12 Months)

| Enhancement | Owner | Impact |
|---|---|---|
| Multi-Blue-plan federation | Architecture + Business | 36-plan scaling |
| Predictive contract termination model | ML Engineering | Risk mitigation |
| AI-assisted negotiation brief generation | AI/ML | Analyst productivity |
| Provider-facing read-only portal | Product + Security | Provider self-service |
| Natural language to PDF citation (page-level) | Data Engineering | Source verification |
| Regulatory change impact analysis | AI/ML + Compliance | Proactive compliance |

---

## APPENDIX A: KEY CONTACTS & RESOURCES

| Resource | Location |
|---|---|
| **Workspace** | `adb-640321604414221.1.azuredatabricks.net` |
| **Pipeline folder** | `/Users/adixit01@blueshieldca.com/Contract_Codification_Pipeline/` |
| **Genie Space** | Space ID: `01f14d360bd51f8d801452065b2df600` |
| **Dashboard** | ID: `01f153b41dc51de8bb4e0a3cf16bb7e1` |
| **Schema** | `dev_adb.raw` |
| **Source Volume** | `/Volumes/prod_adb/default/ext-data-volume-stmlz/...` |
| **LLM Endpoint** | `databricks-claude-sonnet-4-5` |
| **VS Endpoint** | `contract_intelligence_vs_endpoint` |
| **Owner** | `adixit01@blueshieldca.com` |

---

## APPENDIX B: QUICK START (NEW ENGINEER)

### Day 1: Orientation
1. Read this KT document (sections 1-4)
2. Read `README.md` in project root
3. Browse `extraction/_config.py` and `platform/00_config.py`
4. Run `SELECT COUNT(*) FROM dev_adb.raw.tbl_genie_rates_current` — verify access

### Day 2: Pipeline Understanding
1. Read `extraction/05_llm_extraction.py` — understand REST API pattern
2. Read `extraction/06_validation.py` — understand 8 checks
3. Read `extraction/12_build_genie.py` — understand serving layer
4. Open Genie Space — ask 5 test questions

### Day 3: Hands-On
1. Run `extraction/01_file_discovery.py` — see file inventory
2. Pick one small PDF — trace it through extraction → JSON → tables
3. Run `platform/11_evaluation_harness.py` — see golden queries
4. Modify one column comment — rebuild Genie layer — test impact

### Week 1: Contribution
1. Pick a P1 enhancement from section 16
2. Implement in dev branch
3. Test against golden queries
4. Document in Architecture_Info/

---

*End of Document*

**Document Statistics**:
- Total sections: 16 + 2 appendices
- Notebooks documented: 25
- Tables documented: 44+
- Components documented: 10
- Troubleshooting items: 10
- FAQ items: 12
- Glossary terms: 30
- Future enhancements: 20+
