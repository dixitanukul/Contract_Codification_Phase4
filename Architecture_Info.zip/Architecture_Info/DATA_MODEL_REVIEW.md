# BSC Provider Contract Intelligence — Complete Data Model & Lineage Review

**Document Classification**: Internal — Data Architecture Assessment  
**Author**: Data Model Review (Automated)  
**Date**: May 2026  
**Version**: 1.0  
**Catalog**: `dev_adb` | **Schema**: `raw`  
**Total Tables**: 30+ managed Delta tables  
**Total Rows**: ~300K+ across all tables

---

## Table of Contents

1. [Complete Data Dictionary](#1-complete-data-dictionary)
2. [Lineage Mapping](#2-lineage-mapping)
3. [Relationship Mapping](#3-relationship-mapping)
4. [Entity Relationship Analysis](#4-entity-relationship-analysis)
5. [Medallion Layer Analysis](#5-medallion-layer-analysis)
6. [Serving Layer Analysis](#6-serving-layer-analysis)
7. [Semantic Layer Analysis](#7-semantic-layer-analysis)
8. [Genie Consumption Layer Analysis](#8-genie-consumption-layer-analysis)
9. [Data Quality Review](#9-data-quality-review)
10. [Governance Review](#10-governance-review)
11. [Optimization Review](#11-optimization-review)
12. [Partitioning/Performance Review](#12-partitioningperformance-review)
13. [Scalability Assessment](#13-scalability-assessment)
14. [Refactoring Recommendations](#14-refactoring-recommendations)

---

## 1. Complete Data Dictionary

### 1.1 Table Classification Summary

| Classification | Tables | Purpose |
|---------------|--------|---------|
| **Extraction Output** (Bronze) | tbl_contract_rates_all, tbl_contract_financial_protections, tbl_contract_regional_factors, tbl_contract_terms_all, tbl_contract_clauses_all, tbl_contract_documents_master, tbl_contract_parties_all, tbl_contract_terms_vs_ready | Direct JSON-to-Delta table builds |
| **Dimension** | dim_provider_canonical, dim_service_line_taxonomy, dim_service_line_patterns | Reference/lookup tables |
| **Foundation / State Engine** (Silver) | tbl_v2_contract_registry, tbl_v2_amendment_registry, tbl_v2_rate_facts_bitemporal, tbl_v2_document_lineage, tbl_v2_state_computation_log | Normalized registries with state machine |
| **Reimbursement Engine** (Silver) | tbl_reimb_rate_rules, tbl_reimb_formula_components, tbl_reimb_stop_loss, tbl_reimb_carve_outs, tbl_reimb_escalators, tbl_reimb_conditions, tbl_reimb_lesser_of | Normalized rate computation model |
| **Retrieval** (Silver) | tbl_retrieval_legal_units, tbl_retrieval_telemetry | Legal text chunking + search telemetry |
| **Intelligence** (Gold) | tbl_intel_benchmark_results, tbl_intel_provider_spend_summary, tbl_intel_savings_opportunity, tbl_intel_renewal_priority, tbl_intel_leverage_scores, tbl_intel_scenario_results | Computed analytics |
| **Serving / Genie** (Gold) | tbl_genie_provider_profile, tbl_genie_rates_current, vw_genie_contract_terms, tbl_genie_amendment_timeline, tbl_serving_capitation_card | Pre-joined for NL queries |
| **Operational / Audit** | tbl_pipeline_telemetry, tbl_extraction_quality_audit, tbl_extraction_quality_gaps, tbl_eval_golden_queries | Observability + quality |

### 1.2 Detailed Table Catalog

#### EXTRACTION OUTPUT TABLES (Bronze Layer)

| Table | Rows | Grain | PK | Business Meaning |
|-------|------|-------|-----|------------------|
| `tbl_contract_rates_all` | 39,549 | One row per rate line item per document | (provider_id, source_filename, rate_category, service_category, rate_text) | ALL rate history including superseded. Contains inpatient per-diem, outpatient surgical, capitation, case rates. Filter status='current' for active rates. |
| `tbl_contract_financial_protections` | 2,077 | One row per protection provision per document | (provider_id, source_filename, protection_type) | Stop-loss, outlier, risk corridor provisions. Threshold amounts and reimbursement percentages. |
| `tbl_contract_regional_factors` | 5,710 | One row per county per provider | (provider_id, county) | Geographic adjustment multipliers by county for rate calculations. |
| `tbl_contract_terms_all` | ~45,000 | One row per clause/provision per document | (provider_id, source_filename, topic, title) | All clauses, definitions, sections extracted from contracts. Content in content_text field. |
| `tbl_contract_clauses_all` | ~3,000 | One row per verbatim clause | (provider_id, source_filename, clause_type) | Full clause text copied verbatim from PDF (full_clause_text requirement). |
| `tbl_contract_documents_master` | ~3,500 | One row per PDF processed | source_filename | Document metadata: provider_id, contract_id, doc_category, amendment_order, amendment_depth, effective_date_parsed, is_latest_version. |
| `tbl_contract_parties_all` | ~7,000 | One row per party per document | (source_filename, party_name) | Contract parties: health_plan + provider details (name, type, tax_id, NPI). |
| `tbl_contract_terms_vs_ready` | ~69,000 | One row per searchable text unit | (provider_name, content_text hash) | Pre-processed text units ready for Vector Search indexing. Richest source for legal chunking. |

#### DIMENSION TABLES

| Table | Rows | Grain | PK | Business Meaning |
|-------|------|-------|-----|------------------|
| `dim_provider_canonical` | ~400 | One row per provider_id | provider_id | Identity resolution: maps 456 provider_ids to 278 facilities. canonical_name, primary_provider_id, is_primary_id. Solves many-to-one provider ID problem. |
| `dim_service_line_taxonomy` | 50 | One row per service line | service_line_code | Master taxonomy of service lines (Inpatient Med/Surg, ICU, Outpatient Surgery, etc.). Seed data. |
| `dim_service_line_patterns` | 45 | One row per classification pattern | (pattern, service_line_id) | Regex patterns mapping raw LLM-extracted service categories to canonical service lines. |

#### FOUNDATION / STATE ENGINE TABLES (Silver)

| Table | Rows | Grain | PK | Business Meaning |
|-------|------|-------|-----|------------------|
| `tbl_v2_contract_registry` | 1,948 | One row per legal agreement | contract_id | Contract-level state machine. Status: ACTIVE/EXPIRED/TERMINATED/SUPERSEDED. Links base agreement to amendments. Clustered by (provider_id, status). |
| `tbl_v2_amendment_registry` | 1,570 | One row per amendment document | (contract_id, source_filename) | Amendment classification: scope_type (FULL_REPLACEMENT, TARGETED, TERM_EXTENSION), amendment_order, effective_date. Critical for supersession logic. |
| `tbl_v2_rate_facts_bitemporal` | - | One row per rate per time period | (contract_id, rate_domain, service_line, valid_from, valid_to) | [PLANNED] Bitemporal rate tracking (system time + business time). |
| `tbl_v2_document_lineage` | - | One row per document in chain | (contract_id, source_filename) | [PLANNED] Full document provenance chain. |
| `tbl_v2_state_computation_log` | - | One row per state computation | (computation_id) | [PLANNED] Audit log of state transitions. |

#### REIMBURSEMENT ENGINE TABLES (Silver)

| Table | Rows | Grain | PK | Business Meaning |
|-------|------|-------|-----|------------------|
| `tbl_reimb_rate_rules` | 21,074 | One row per contractual rate provision | rule_id | Master rate rules with computable formula_json expression trees. Normalized from V1 rates. Clustered by (provider_id, rate_domain). 17,046 FFS + 4,028 capitation. |
| `tbl_reimb_formula_components` | - | One row per formula component | (rule_id, component_id) | Decomposed rate formula elements (base_amount, multiplier, factor). |
| `tbl_reimb_stop_loss` | 741 | One row per stop-loss provision | (provider_id, contract_id) | Stop-loss thresholds, per-diem rates, attachment levels. |
| `tbl_reimb_carve_outs` | - | One row per carve-out | (provider_id, service) | Services excluded from standard rate schedule. |
| `tbl_reimb_escalators` | - | One row per annual escalator | (provider_id, year) | Year-over-year rate increase provisions. |
| `tbl_reimb_conditions` | - | One row per rate condition | (rule_id, condition_id) | Preconditions for rate applicability (e.g., "if length of stay > 30 days"). |
| `tbl_reimb_lesser_of` | 20 | One row per lesser-of provision | (provider_id) | "Lesser of charges or scheduled rate" provisions. |

#### RETRIEVAL TABLES (Silver)

| Table | Rows | Grain | PK | Business Meaning |
|-------|------|-------|-----|------------------|
| `tbl_retrieval_legal_units` | 83,008 | One row per atomic legal text unit | unit_id | Chunked legal text for Vector Search. unit_type: definition, clause, rate_entry, section. Embedded via GTE-Large-EN. |
| `tbl_retrieval_telemetry` | Variable | One row per retrieval query | (query_id, timestamp) | Query performance: channels used, confidence, latency, should_refuse decisions. |

#### INTELLIGENCE TABLES (Gold)

| Table | Rows | Grain | PK | Business Meaning |
|-------|------|-------|-----|------------------|
| `tbl_intel_benchmark_results` | 1,399 | One row per (rate_domain, service_line, formula_type) | benchmark_id | Percentile rate benchmarks (P10/P25/P50/P75/P90) computed from tbl_reimb_rate_rules. Foundation for savings analysis. |
| `tbl_intel_provider_spend_summary` | 348 | One row per provider | provider_id | Provider-level spend aggregation. [ESTIMATED - needs claims feed for real data] |
| `tbl_intel_savings_opportunity` | 500 | One row per savings opportunity | (provider_id, service_line) | Pareto-ranked savings opportunities comparing provider rates to benchmark medians. |
| `tbl_intel_renewal_priority` | 1,478 | One row per contract | contract_id | Renewal scoring based on expiry dates, amendment count, rate competitiveness. Recommended action: URGENT/PROACTIVE/MONITOR/OPTIMAL. |
| `tbl_intel_leverage_scores` | 348 | One row per provider | provider_id | Bilateral leverage: plan_leverage vs provider_leverage. Strategy postures. [Needs claims for volume weights] |
| `tbl_intel_scenario_results` | 5 | One row per simulation | scenario_id | What-if results: rate_change, termination, budget_backward scenarios. |

#### SERVING / GENIE TABLES (Gold)

| Table | Rows | Grain | PK | Business Meaning |
|-------|------|-------|-----|------------------|
| `tbl_genie_provider_profile` | 271 | One row per canonical facility | provider_id (primary) | Executive dashboard: agreement_type, payment_type, total_documents, total_amendments, current_rates, avg_inpatient_per_diem, has_stop_loss. Sentinel-safe (no nulls in key fields). |
| `tbl_genie_rates_current` | 6,683 | One row per current rate per provider | (provider_name, rate_category, service_category, rate_numeric) | Deduplicated current rates only. Amendment-aware dedup (V8). program_normalized for aggregation. |
| `vw_genie_contract_terms` | 45,718 | One row per term/clause per provider | (provider_name, content_type, topic, title) | VIEW joining terms + clauses + parties + codes. is_from_latest_doc flag for recency filtering. Content types: definition, section, party, medical_code, clause, hac, never_event. |
| `tbl_genie_amendment_timeline` | 2,254 | One row per document in provider timeline | (provider_name, source_filename) | Document chain with doc_category, amendment_order, summary_of_changes, effective_date. |
| `tbl_serving_capitation_card` | ~200 | One row per age-gender band | (provider_id, age_gender_band) | Capitation PMPM rates by age/gender demographic category. |

#### OPERATIONAL / AUDIT TABLES

| Table | Rows | Grain | PK | Business Meaning |
|-------|------|-------|-----|------------------|
| `tbl_pipeline_telemetry` | Variable | One row per telemetry event | (run_id, step, timestamp) | Pipeline execution observability: step, check, result, severity, metrics. |
| `tbl_extraction_quality_audit` | Variable | One row per audited file | filename | LLM quality audit results: overall_quality_score (1-10), gap counts by severity. |
| `tbl_extraction_quality_gaps` | Variable | One row per gap per file | (filename, section, gap_type) | Individual extraction gaps: section, severity, gap_type, description, pdf_evidence. |
| `tbl_eval_golden_queries` | 20 | One row per test query | query_id | Hand-curated evaluation set: query, expected_answer, source_doc for regression testing. |

### 1.3 Key Column Details — Core Tables

#### tbl_contract_rates_all (39,549 rows)

| Column | Type | Nullable | Business Meaning |
|--------|------|----------|------------------|
| provider_id | STRING | Yes | BSC provider identifier (join to dim_provider_canonical) |
| provider_name | STRING | Yes | Raw provider name from extraction |
| source_filename | STRING | Yes | PDF filename (lineage key to documents_master) |
| document_type | STRING | Yes | Base/Amendment/Cover Memo/Settlement |
| rate_category | STRING | Yes | inpatient_per_diem, outpatient_surgical, capitation, case_rate |
| service_category | STRING | Yes | Specific service line (Medical/Surgical, ICU, NICU, etc.) |
| rate_type_detail | STRING | Yes | per_diem, case_rate, percentage_of_charges, pmpm |
| rate_text | STRING | Yes | Original rate text from contract ("$5,748") |
| rate_numeric | DOUBLE | Yes | Parsed numeric value (5748.00). 95% populated. |
| revenue_codes | STRING | Yes | Billing codes (comma-separated: "0200-0204, 0274") |
| effective_date | STRING | Yes | When rate takes effect (varied string formats) |
| program | STRING | Yes | Commercial, Medicare, Medi-Cal, All Programs |
| network | STRING | Yes | PPO, HMO, Value Network, All Networks |
| formula | STRING | Yes | Rate formula for non-flat rates (CF x multiplier) |
| amendment_order | STRING | Yes | Position in amendment chain (0=base, 1=first amend) |
| status | STRING | Yes | current / superseded (scope-aware logic) |
| superseded_by | STRING | Yes | source_filename of superseding document |
| is_latest_version | BOOLEAN | Yes | TRUE if from highest version file |
| program_normalized | STRING | Yes | 8 canonical buckets (Commercial, Medicare, Medi-Cal, CalPERS, etc.) |
| is_valid_rate | BOOLEAN | Yes | FALSE for negative/zero rates |
| effective_date_parsed | DATE | Yes | Parsed DATE from effective_date string |
| canonical_provider_id | STRING | Yes | Resolved primary_provider_id from dim_provider_canonical |

#### tbl_v2_contract_registry (1,948 rows)

| Column | Type | Nullable | Business Meaning |
|--------|------|----------|------------------|
| contract_id | STRING | NOT NULL | Deterministic hash: sha256(provider_id\|base_agreement_doc) |
| provider_id | STRING | NOT NULL | Provider ID (clustered) |
| provider_name | STRING | NOT NULL | Canonical provider name |
| agreement_type | STRING | Yes | fee_for_service, capitation, settlement, mixed |
| payment_model | STRING | Yes | per_diem, case_rate, percentage, pmpm, mixed |
| network_scope | STRING | Yes | commercial, medicare, medi_cal, all |
| status | STRING | NOT NULL | ACTIVE, TERMINATED, EXPIRED, SUPERSEDED (clustered) |
| effective_from | DATE | Yes | Original contract start date |
| effective_to | DATE | Yes | NULL if active; populated on termination/expiry |
| auto_renewal | BOOLEAN | Yes | Whether contract auto-renews |
| term_years | FLOAT | Yes | Contract term length in years |
| base_agreement_doc | STRING | NOT NULL | source_filename of originating base agreement |
| total_amendments | INT | Yes | Count of linked amendments |
| latest_amendment_date | DATE | Yes | Effective date of most recent amendment |
| latest_amendment_doc | STRING | Yes | source_filename of most recent amendment |
| state_computed_at | TIMESTAMP | Yes | When state was last computed |
| state_version | INT | Yes | Version counter for optimistic concurrency |
| computation_rule | STRING | Yes | Which rule determined current status |

#### tbl_reimb_rate_rules (21,074 rows)

| Column | Type | Nullable | Business Meaning |
|--------|------|----------|------------------|
| rule_id | STRING | NOT NULL | Unique UUID |
| contract_id | STRING | NOT NULL | FK to tbl_v2_contract_registry |
| provider_id | STRING | NOT NULL | Provider ID (clustered) |
| provider_name | STRING | NOT NULL | Canonical name |
| rate_domain | STRING | NOT NULL | INPATIENT, OUTPATIENT, CAPITATION, PROFESSIONAL (clustered) |
| service_line | STRING | NOT NULL | FK to dim_service_line_taxonomy |
| service_category_raw | STRING | Yes | Original LLM-extracted text |
| formula_type | STRING | NOT NULL | FIXED, PER_DIEM, PERCENTAGE, DRG_WEIGHTED, CONVERSION_FACTOR, etc. |
| formula_json | STRING | NOT NULL | Full expression tree as JSON |
| rate_numeric | FLOAT | Yes | Best single-number representation |
| rate_text | STRING | Yes | Original rate text from PDF |
| rate_unit | STRING | Yes | day, case, visit, member_month, procedure |
| program | STRING | Yes | Commercial, Medicare, Medi-Cal, All |
| network | STRING | Yes | HMO, PPO, All Networks |
| effective_from | DATE | Yes | Rate effective start |
| effective_to | DATE | Yes | Rate expiry (null if current) |
| source_filename | STRING | Yes | Originating PDF |
| amendment_order | INT | Yes | Amendment chain position |
| is_current | BOOLEAN | Yes | Whether this is the active rate |
| migrated_from | STRING | Yes | V1 source table |
| migrated_at | TIMESTAMP | Yes | Migration timestamp |

#### dim_provider_canonical (400 rows)

| Column | Type | Nullable | Business Meaning |
|--------|------|----------|------------------|
| provider_id | STRING | Yes | Every known BSC provider_id (JOIN key) |
| canonical_name | STRING | Yes | Single resolved facility name |
| primary_provider_id | STRING | Yes | Representative ID for facility |
| is_primary_id | BOOLEAN | Yes | TRUE = this row IS the representative |
| rank_in_facility | INT | Yes | Rank by doc_count within facility group |
| doc_count | BIGINT | Yes | Documents for this specific provider_id |
| total_rate_count | BIGINT | Yes | Rate rows for this provider_id |
| latest_effective_date | STRING | Yes | Most recent effective date |
| ids_in_facility | BIGINT | Yes | Count of provider_ids in this facility |
| facility_total_docs | BIGINT | Yes | Total docs across all IDs in facility |
| facility_total_rates | BIGINT | Yes | Total rates across all IDs |
| all_names_used | ARRAY<STRING> | Yes | All name variants observed |


---

## 2. Lineage Mapping

### 2.1 End-to-End Data Flow

```
┌─────────────────────────────────────────────────────────────────────────────────────────────┐
│                           PDF → DELTA LAKE LINEAGE MAP                                       │
├─────────────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                              │
│  SOURCE (External)                                                                           │
│  ┌──────────────────────────────────────────────────────────┐                               │
│  │ /Volumes/prod_adb/default/ext-data-volume-stmlz/         │                               │
│  │   Health_Plan_Ops_Transformation/Provider_Contracts/      │                               │
│  │   597 folders / 10,372 PDFs / 27.3 GB                    │                               │
│  └─────────────┬────────────────────────────────────────────┘                               │
│                │                                                                             │
│  STAGE 1: OCR + METADATA (extraction/01-03)                                                 │
│                ▼                                                                             │
│  ┌──────────────────────────────────────────────────────────┐                               │
│  │ 3-Tier OCR: PyPDF2 → pdfplumber → EasyOCR               │                               │
│  │ Filename Parsing: provider_id, doc_type, version         │                               │
│  │ Output: In-memory text + metadata dict                   │                               │
│  └─────────────┬────────────────────────────────────────────┘                               │
│                │                                                                             │
│  STAGE 2: LLM EXTRACTION (extraction/04-05)                                                 │
│                ▼                                                                             │
│  ┌──────────────────────────────────────────────────────────┐                               │
│  │ Claude Sonnet 4.5 via REST API                           │                               │
│  │ 4 prompts: BASE / AMENDMENT / COVER_MEMO / SETTLEMENT   │                               │
│  │ V6 Schema: 20 sections × 200K context window            │                               │
│  │ Output: json_extract/*.json (3,519 files processed)      │                               │
│  └─────────────┬────────────────────────────────────────────┘                               │
│                │                                                                             │
│  STAGE 3: VALIDATION + LOAD (extraction/06-09)                                              │
│                ▼                                                                             │
│  ┌──────────────────────────────────────────────────────────┐                               │
│  │ 8-Check Validation Pipeline:                             │                               │
│  │   1. Medical code regex    5. Delta schema readiness     │                               │
│  │   2. Date verification     6. Coverage scoring           │                               │
│  │   3. Rate verification     7. Document classification    │                               │
│  │   4. rate_numeric post-proc 8. Quarantine routing        │                               │
│  │                                                           │                               │
│  │ Table Build (CREATE OR REPLACE TABLE):                    │                               │
│  │   → tbl_contract_rates_all (39,549)                      │                               │
│  │   → tbl_contract_financial_protections (2,077)           │                               │
│  │   → tbl_contract_regional_factors (5,710)                │                               │
│  │   → tbl_contract_terms_all (~45,000)                     │                               │
│  │   → tbl_contract_clauses_all (~3,000)                    │                               │
│  │   → tbl_contract_documents_master (~3,500)               │                               │
│  │   → tbl_contract_parties_all (~7,000)                    │                               │
│  │   → tbl_contract_terms_vs_ready (~69,000)                │                               │
│  └─────────────┬────────────────────────────────────────────┘                               │
│                │                                                                             │
│  STAGE 4: PLATFORM BUILD (platform/00-11)                                                   │
│                ▼                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────────────────┐        │
│  │  DIMENSIONS               STATE ENGINE             REIMBURSEMENT ENGINE          │        │
│  │  ┌────────────────┐      ┌──────────────────┐     ┌──────────────────┐          │        │
│  │  │ dim_provider_   │      │ tbl_v2_contract_ │     │ tbl_reimb_       │          │        │
│  │  │   canonical     │      │   registry       │     │   rate_rules     │          │        │
│  │  │ dim_service_    │      │ tbl_v2_amendment_│     │ tbl_reimb_       │          │        │
│  │  │   line_taxonomy │      │   registry       │     │   stop_loss      │          │        │
│  │  │ dim_service_    │      │ tbl_v2_document_ │     │ tbl_reimb_       │          │        │
│  │  │   line_patterns │      │   lineage        │     │   lesser_of      │          │        │
│  │  └────────────────┘      └──────────────────┘     └──────────────────┘          │        │
│  │                                                                                   │        │
│  │  RETRIEVAL                INTELLIGENCE                                            │        │
│  │  ┌────────────────┐      ┌──────────────────────────────────────────────┐        │        │
│  │  │ tbl_retrieval_  │      │ tbl_intel_benchmark_results (1,399)          │        │        │
│  │  │   legal_units   │      │ tbl_intel_provider_spend_summary (348)       │        │        │
│  │  │   (83,008)      │      │ tbl_intel_savings_opportunity (500)          │        │        │
│  │  │ tbl_retrieval_  │      │ tbl_intel_renewal_priority (1,478)           │        │        │
│  │  │   telemetry     │      │ tbl_intel_leverage_scores (348)              │        │        │
│  │  └────────────────┘      │ tbl_intel_scenario_results (5)               │        │        │
│  │                           └──────────────────────────────────────────────┘        │        │
│  └─────────────┬────────────────────────────────────────────────────────────────────┘        │
│                │                                                                             │
│  STAGE 5: SERVING LAYER (extraction/13-15, platform/11)                                     │
│                ▼                                                                             │
│  ┌──────────────────────────────────────────────────────────────────────────┐               │
│  │  tbl_genie_provider_profile (271)     — Provider summary cards           │               │
│  │  tbl_genie_rates_current (6,683)      — Deduplicated current rates       │               │
│  │  vw_genie_contract_terms (45,718)     — Searchable terms (VIEW)          │               │
│  │  tbl_genie_amendment_timeline (2,254) — Document history                 │               │
│  │  tbl_serving_capitation_card (~200)   — Capitation demographics          │               │
│  │                                                                           │               │
│  │  → Genie Space (01f14d360bd51f8d801452065b2df600)                        │               │
│  │  → Dashboard (01f153b41dc51de8bb4e0a3cf16bb7e1)                          │               │
│  │  → Vector Search Index (contract_intelligence_vs_endpoint)                │               │
│  └──────────────────────────────────────────────────────────────────────────┘               │
│                                                                                              │
└─────────────────────────────────────────────────────────────────────────────────────────────┘
```

### 2.2 Table-Level Lineage Graph

```
json_extract/*.json
    │
    ├──► tbl_contract_rates_all ────────────────────────► tbl_genie_rates_current
    │        │                                                     │
    │        └──► tbl_reimb_rate_rules ────────────────► tbl_intel_benchmark_results
    │                    │                                         │
    │                    └──► tbl_intel_savings_opportunity ◄──────┘
    │                    └──► tbl_intel_provider_spend_summary
    │                    └──► tbl_intel_leverage_scores
    │
    ├──► tbl_contract_financial_protections ──► tbl_reimb_stop_loss
    │                                          tbl_reimb_lesser_of
    │
    ├──► tbl_contract_terms_all ────────────────────────► vw_genie_contract_terms
    │                                                            │
    │                                                            ▼
    ├──► tbl_contract_terms_vs_ready ──────────► tbl_retrieval_legal_units
    │                                                            │
    │                                                            ▼
    │                                               Vector Search Index
    │
    ├──► tbl_contract_documents_master ────────► tbl_v2_contract_registry
    │        │                                          │
    │        └──► tbl_v2_amendment_registry ◄───────────┘
    │                    │
    │                    └──► tbl_intel_renewal_priority
    │
    ├──► tbl_contract_parties_all ─────────────► vw_genie_contract_terms
    │
    ├──► tbl_contract_clauses_all ─────────────► vw_genie_contract_terms
    │
    └──► dim_provider_canonical ──► ALL downstream tables (canonical_provider_id)
              │
              └──► tbl_genie_provider_profile
```

### 2.3 Column-Level Lineage (Critical Paths)

| Destination Column | Source Table | Source Column(s) | Transformation |
|-------------------|-------------|-----------------|----------------|
| tbl_genie_rates_current.rate_numeric | tbl_contract_rates_all.rate_numeric | rate_numeric | WHERE status='current', amendment dedup V8 |
| tbl_genie_rates_current.program_normalized | tbl_contract_rates_all.program | program | CASE mapping to 8 canonical buckets |
| tbl_v2_contract_registry.contract_id | tbl_contract_documents_master | provider_id + base_agreement_doc | sha256(provider_id\|base_doc) |
| tbl_v2_contract_registry.status | tbl_v2_amendment_registry | effective_from, effective_to | State machine: amendment chain → status |
| tbl_reimb_rate_rules.formula_json | tbl_contract_rates_all | rate_text, rate_numeric, formula | Expression tree builder |
| tbl_reimb_rate_rules.service_line | tbl_contract_rates_all.service_category | dim_service_line_patterns regex match |
| dim_provider_canonical.primary_provider_id | tbl_contract_rates_all | provider_id, provider_name | Facility grouping by name similarity |
| tbl_intel_benchmark_results.p50_rate | tbl_reimb_rate_rules.rate_numeric | Grouped PERCENTILE_APPROX(0.5) |
| tbl_genie_provider_profile.total_rates | tbl_contract_rates_all | COUNT WHERE status='current' |
| vw_genie_contract_terms.is_from_latest_doc | tbl_contract_documents_master | is_latest_version propagated to each term |

---

## 3. Relationship Mapping

### 3.1 Primary Key → Foreign Key Relationships

```
┌────────────────────────────────────────────────────────────────────────────────────┐
│                         ENTITY RELATIONSHIP MAP                                     │
├────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                     │
│  dim_provider_canonical (PK: provider_id)                                          │
│       │                                                                             │
│       ├─── 1:N ──► tbl_contract_rates_all (FK: provider_id)                        │
│       ├─── 1:N ──► tbl_v2_contract_registry (FK: provider_id)                      │
│       ├─── 1:N ──► tbl_reimb_rate_rules (FK: provider_id)                          │
│       ├─── 1:1 ──► tbl_genie_provider_profile (FK: provider_id)                    │
│       ├─── 1:N ──► tbl_genie_rates_current (FK: provider_id)                       │
│       ├─── 1:N ──► tbl_intel_provider_spend_summary (FK: provider_id)              │
│       └─── 1:N ──► tbl_intel_leverage_scores (FK: provider_id)                     │
│                                                                                     │
│  tbl_v2_contract_registry (PK: contract_id)                                        │
│       │                                                                             │
│       ├─── 1:N ──► tbl_v2_amendment_registry (FK: contract_id)                     │
│       ├─── 1:N ──► tbl_reimb_rate_rules (FK: contract_id)                          │
│       ├─── 1:1 ──► tbl_intel_renewal_priority (FK: contract_id)                    │
│       └─── 1:N ──► tbl_reimb_stop_loss (FK: contract_id)                           │
│                                                                                     │
│  tbl_contract_documents_master (PK: source_filename)                               │
│       │                                                                             │
│       ├─── 1:N ──► tbl_contract_rates_all (FK: source_filename)                    │
│       ├─── 1:N ──► tbl_contract_terms_all (FK: source_filename)                    │
│       ├─── 1:N ──► tbl_contract_financial_protections (FK: source_filename)        │
│       ├─── 1:N ──► tbl_contract_parties_all (FK: source_filename)                  │
│       ├─── 1:N ──► tbl_contract_clauses_all (FK: source_filename)                  │
│       └─── 1:N ──► tbl_genie_amendment_timeline (FK: source_filename)              │
│                                                                                     │
│  tbl_reimb_rate_rules (PK: rule_id)                                                │
│       │                                                                             │
│       ├─── 1:0..1 ──► tbl_reimb_stop_loss (FK: stop_loss_id)                      │
│       ├─── 1:0..1 ──► tbl_reimb_carve_outs (FK: carve_out_id)                     │
│       ├─── 1:0..1 ──► tbl_reimb_escalators (FK: escalator_id)                     │
│       ├─── 1:0..1 ──► tbl_reimb_conditions (FK: condition_id)                     │
│       └─── 1:0..1 ──► tbl_reimb_lesser_of (FK: lesser_of_id)                      │
│                                                                                     │
│  dim_service_line_taxonomy (PK: service_line_code)                                 │
│       │                                                                             │
│       └─── 1:N ──► tbl_reimb_rate_rules (FK: service_line)                         │
│       └─── 1:N ──► dim_service_line_patterns (FK: service_line_id)                 │
│                                                                                     │
└────────────────────────────────────────────────────────────────────────────────────┘
```

### 3.2 Join Paths (Operational)

| From | To | Join Key | Cardinality | Notes |
|------|----|----------|-------------|-------|
| Any table | dim_provider_canonical | provider_id | N:1 | Use for facility rollup |
| tbl_reimb_rate_rules | tbl_v2_contract_registry | contract_id | N:1 | Rate → Contract |
| tbl_v2_amendment_registry | tbl_v2_contract_registry | contract_id | N:1 | Amendment → Contract |
| tbl_contract_rates_all | tbl_contract_documents_master | source_filename | N:1 | Rate → Document |
| tbl_reimb_rate_rules | dim_service_line_taxonomy | service_line = service_line_code | N:1 | Classification lookup |
| tbl_genie_rates_current | tbl_genie_provider_profile | provider_id | N:1 | Serving layer join |
| tbl_intel_renewal_priority | tbl_v2_contract_registry | contract_id | 1:1 | Priority → Contract |
| tbl_intel_savings_opportunity | tbl_intel_benchmark_results | (rate_domain, service_line) | N:1 | Savings → Benchmark |

### 3.3 Logical Relationship Issues

| Issue | Tables | Impact | Recommendation |
|-------|--------|--------|----------------|
| **No FK constraints** | All | Orphan records possible | Implement validation checks in pipeline |
| **String-typed FKs** | All | No referential integrity enforcement | UC does not support FK constraints; validate in code |
| **provider_id fragmentation** | tbl_contract_rates_all | 456 distinct IDs map to 278 facilities | ALWAYS join through dim_provider_canonical |
| **contract_id not present in rates** | tbl_contract_rates_all ↔ tbl_v2_contract_registry | Cannot directly join rates to contracts without source_filename bridge | Add contract_id column to tbl_contract_rates_all |
| **source_filename inconsistency** | Some tables | Mixed case/path formats | Standardize to lowercase basename |

---

## 4. Entity Relationship Analysis

### 4.1 Core Business Entities

#### ENTITY: Provider (Facility)
- **Canonical Reference**: dim_provider_canonical
- **Identity Problem**: A single facility (e.g., "John Muir Medical Center") may have 3-5 provider_id values across documents due to department IDs, historical IDs, or data entry variants.
- **Resolution**: dim_provider_canonical.primary_provider_id provides the representative ID per facility
- **Cardinality**: 456 raw IDs → 278 canonical facilities → 271 in Genie (after data cleaning)

#### ENTITY: Contract
- **Registry**: tbl_v2_contract_registry
- **Identity**: contract_id = sha256(provider_id | base_agreement_doc)
- **Lifecycle**: DRAFT → ACTIVE → EXPIRED/TERMINATED/SUPERSEDED
- **Composition**: 1 base agreement + 0..N amendments
- **Statistics**: 1,948 contracts (1,280 ACTIVE, 469 EXPIRED, 182 TERMINATED, 17 SUPERSEDED)

#### ENTITY: Amendment
- **Registry**: tbl_v2_amendment_registry
- **Relationship**: N:1 to Contract via contract_id
- **Types**: FULL_REPLACEMENT, TARGETED, TERM_EXTENSION
- **Ordering**: amendment_order (integer, 0=base, 1=first amendment)
- **Supersession**: scope_type + effective_date determines which rates are superseded

#### ENTITY: Rate Rule
- **Registry**: tbl_reimb_rate_rules
- **Relationship**: N:1 to Contract, N:1 to Service Line Taxonomy
- **Types**: FIXED (11,432), PER_DIEM (3,890), PERCENTAGE (2,107), CONVERSION_FACTOR (1,845), DRG_WEIGHTED (900), OTHER (900)
- **State**: is_current flag; effective_from/effective_to for temporal validity
- **Formula**: formula_json stores full expression tree for rate computation

#### ENTITY: Legal Text Unit
- **Registry**: tbl_retrieval_legal_units
- **Relationship**: N:1 to source document (source_filename)
- **Types**: definition (12K), clause (18K), rate_entry (21K), section (32K)
- **Usage**: Embedded via GTE-Large-EN → Vector Search for retrieval

### 4.2 Business Process Chains

```
CONTRACT LIFECYCLE:
  Provider → Signs Base Agreement → [Contract Created: ACTIVE]
                                          │
                                    Amendment Filed → [Amendment Registered]
                                          │              │
                                    Rate Superseded     Terms Updated
                                          │              │
                                    New Rate Active     New Terms Active
                                          │
                                    Contract Expires → [Status: EXPIRED]
                                          OR
                                    Provider Terminates → [Status: TERMINATED]

RATE COMPUTATION:
  Rate Rule → formula_json → { base_amount, multiplier, factor } → Computed Rate
       ├── Stop Loss check (tbl_reimb_stop_loss)
       ├── Lesser Of check (tbl_reimb_lesser_of)
       ├── Escalator applied (tbl_reimb_escalators)
       └── Carve-out exclusion (tbl_reimb_carve_outs)

RETRIEVAL + ANSWER:
  User Query → Genie Space → NL→SQL → tbl_genie_* tables
       OR
  User Query → Retrieval Engine → Vector Search → tbl_retrieval_legal_units
                     → Rerank → Cite → Answer with Source
```

---

## 5. Medallion Layer Analysis

### 5.1 Current State: Flat Schema

All 30+ tables reside in `dev_adb.raw` — a single schema with no physical medallion separation.

```
dev_adb.raw/
├── tbl_contract_*        (Bronze: extraction output)
├── dim_*                 (Dimension: reference data)
├── tbl_v2_*              (Silver: state engine)
├── tbl_reimb_*           (Silver: reimbursement)
├── tbl_retrieval_*       (Silver: search)
├── tbl_intel_*           (Gold: intelligence)
├── tbl_genie_*           (Gold: serving)
├── tbl_serving_*         (Gold: serving)
├── vw_genie_*            (Gold: serving view)
├── tbl_pipeline_*        (Operational)
├── tbl_extraction_*      (Operational)
└── tbl_eval_*            (Operational)
```

### 5.2 Implied Layers (Based on Naming + Dependencies)

| Layer | Prefix | Tables | Refresh Strategy | Characteristics |
|-------|--------|--------|------------------|-----------------|
| **Bronze** | `tbl_contract_*` | 8 tables | CREATE OR REPLACE from JSON | Extraction output; minimal transforms; append-only from new PDFs |
| **Silver** | `tbl_v2_*`, `tbl_reimb_*`, `tbl_retrieval_*` | ~12 tables | Recomputed from Bronze | Normalized, typed, validated; business logic applied |
| **Gold** | `tbl_intel_*`, `tbl_genie_*`, `tbl_serving_*`, `vw_*` | ~12 tables | Derived from Silver | Pre-aggregated, deduplicated, sentinel-safe; optimized for consumption |
| **Dimension** | `dim_*` | 3 tables | Seed data + computed | Reference/master data; low cardinality; slow-changing |
| **Operational** | `tbl_pipeline_*`, `tbl_extraction_*`, `tbl_eval_*` | ~4 tables | Append per pipeline run | Telemetry, audit, evaluation |

### 5.3 Medallion Maturity Assessment

| Criteria | Score | Evidence |
|----------|-------|----------|
| Physical schema separation | ❌ 1/5 | All in dev_adb.raw |
| Clear naming convention | ✅ 4/5 | Prefixes are consistent and meaningful |
| Dependency ordering | ✅ 4/5 | Clear extraction → platform → serving flow |
| Idempotent refresh | ⚠️ 3/5 | CREATE OR REPLACE (full refresh); no incremental MERGE |
| Error isolation | ⚠️ 2/5 | No staging tables; direct write to target |
| Schema enforcement | ✅ 4/5 | All tables typed; some have CHECK constraints |
| Data quality gates | ⚠️ 3/5 | Validation exists but not blocking (quarantine, not fail) |

### 5.4 Recommended Medallion Refactoring

```
PROPOSED SCHEMA SEPARATION:

dev_adb.bronze/           (Extraction outputs — raw from LLM)
  tbl_contract_rates_raw
  tbl_contract_terms_raw
  tbl_contract_documents_raw
  tbl_contract_financial_raw
  ...

dev_adb.silver/           (Normalized, validated, typed)
  tbl_contract_registry
  tbl_amendment_registry
  tbl_rate_rules
  tbl_stop_loss
  tbl_legal_units
  dim_provider_canonical
  dim_service_line_taxonomy

dev_adb.gold/             (Pre-aggregated, consumption-ready)
  tbl_intel_benchmarks
  tbl_intel_savings
  tbl_intel_renewal
  tbl_genie_provider_profile
  tbl_genie_rates_current
  vw_genie_contract_terms
  tbl_genie_amendment_timeline

dev_adb.operational/      (Telemetry, audit, evaluation)
  tbl_pipeline_telemetry
  tbl_extraction_quality_audit
  tbl_eval_golden_queries
```

**Migration Cost**: Medium (rename + re-point queries). Genie Space and Dashboard would need dataset query updates.


---

## 6. Serving Layer Analysis

### 6.1 Serving Architecture

The serving layer implements a **4-table + 1-view** design pattern optimized for two consumption channels:

| Consumer | Tables | Pattern |
|----------|--------|---------|
| **Genie Space** (NL→SQL) | tbl_genie_provider_profile, tbl_genie_rates_current, vw_genie_contract_terms, tbl_genie_amendment_timeline | Wide denormalized tables with 67 column comments |
| **Dashboard** (BI) | Same Genie tables | Pre-aggregated metrics for charting |
| **Vector Search** (Retrieval) | tbl_retrieval_legal_units | Chunked embeddings for semantic search |
| **API** (Future) | tbl_serving_capitation_card | Structured payloads per use case |

### 6.2 Serving Layer Design Decisions

| Decision | Rationale | Trade-off |
|----------|-----------|-----------|
| Denormalized wide tables | Genie performs best with flat schemas; no JOINs needed | Storage duplication ~30% |
| VIEW for terms (vw_genie_contract_terms) | Avoids materializing 45K row UNION | Query-time compute cost |
| Sentinel-safe values | Replace NULL with "Not specified" / 0.0 | Genie NL→SQL generates cleaner WHERE clauses |
| Current-only rates | Filter status='current' in materialization | Simpler queries; historical requires source tables |
| Amendment dedup V8 | Scope-aware supersession logic | Complex but accurate; base rates preserved when amendment doesn't touch them |

### 6.3 Serving Layer Performance Profile

| Table | Rows | Avg Query Latency | Storage | Optimization |
|-------|------|-------------------|---------|--------------|
| tbl_genie_provider_profile | 271 | <100ms | ~50KB | Small; always full scan |
| tbl_genie_rates_current | 6,683 | ~200ms | ~2MB | Liquid clustered (provider_name) |
| vw_genie_contract_terms | 45,718 | ~500ms | VIEW (no storage) | Depends on source table optimization |
| tbl_genie_amendment_timeline | 2,254 | ~150ms | ~500KB | Small; always full scan |
| tbl_serving_capitation_card | ~200 | <50ms | ~20KB | Tiny; in-memory eligible |

### 6.4 Serving Layer Refresh Strategy

| Component | Strategy | Frequency | Trigger |
|-----------|----------|-----------|---------|
| tbl_genie_provider_profile | CREATE OR REPLACE | Per batch run | New PDFs processed |
| tbl_genie_rates_current | CREATE OR REPLACE | Per batch run | Rate extraction complete |
| vw_genie_contract_terms | Auto (VIEW) | Real-time | Source tables updated |
| tbl_genie_amendment_timeline | CREATE OR REPLACE | Per batch run | Documents master updated |
| tbl_serving_capitation_card | CREATE OR REPLACE | Per batch run | Capitation rates extracted |

**Observation**: All materializations are full-refresh (CREATE OR REPLACE). At 10K+ PDFs, this becomes expensive. Recommend MERGE-based incremental for rates and timeline.

---

## 7. Semantic Layer Analysis

### 7.1 Column-Level Business Documentation

The Genie-serving tables implement comprehensive column comments as a semantic layer:

```sql
-- Example from tbl_genie_provider_profile:
COMMENT ON COLUMN provider_id IS 
  'Unique BSC provider facility identifier used to look up all contract details';
COMMENT ON COLUMN avg_inpatient_per_diem IS 
  'Average daily rate paid for inpatient hospital stays (dollars per day)';
COMMENT ON COLUMN has_stop_loss IS 
  'Whether this provider contract includes financial stop-loss protection (TRUE/FALSE)';
```

**Total Column Comments**: 67 across 4 Genie tables

### 7.2 Semantic Coverage Analysis

| Table | Columns | Commented | Coverage | Quality |
|-------|---------|-----------|----------|---------|
| tbl_genie_provider_profile | 18 | 18 | 100% | Business-friendly descriptions |
| tbl_genie_rates_current | 15 | 15 | 100% | Rate-specific context |
| vw_genie_contract_terms | 9 | 9 | 100% | Content-type explanations |
| tbl_genie_amendment_timeline | 8 | 8 | 100% | Timeline-specific context |
| tbl_v2_contract_registry | 18 | 0 | 0% | ❌ No comments |
| tbl_reimb_rate_rules | 29 | 0 | 0% | ❌ No comments |
| dim_provider_canonical | 12 | 0 | 0% | ❌ No comments |

**Key Gap**: Only Genie-facing tables have semantic documentation. Silver/Bronze tables lack comments entirely.

### 7.3 Canonical Value Domains

| Column | Table | Domain Values | Purpose |
|--------|-------|---------------|---------|
| `program_normalized` | tbl_genie_rates_current | Commercial, Medicare, Medi-Cal, CalPERS, Workers Comp, All Programs, Multiple, Other | 8-bucket program classification |
| `rate_category` | tbl_contract_rates_all | inpatient_per_diem, outpatient_surgical, capitation, case_rate, observation, professional, emergency, rehabilitation | Rate categorization |
| `agreement_type` | tbl_v2_contract_registry | fee_for_service, capitation, settlement, mixed | Payment model class |
| `status` | tbl_v2_contract_registry | ACTIVE, EXPIRED, TERMINATED, SUPERSEDED | Contract lifecycle |
| `formula_type` | tbl_reimb_rate_rules | FIXED, PER_DIEM, PERCENTAGE, DRG_WEIGHTED, CONVERSION_FACTOR, TIERED, PMPM | Rate computation method |
| `rate_domain` | tbl_reimb_rate_rules | INPATIENT, OUTPATIENT, CAPITATION, PROFESSIONAL | Service domain |
| `doc_category` | tbl_genie_amendment_timeline | base_agreement, amendment, cover_memo, settlement, addendum | Document classification |
| `content_type` | vw_genie_contract_terms | definition, section, party, medical_code, clause, hac, never_event | Term content classification |

### 7.4 Semantic Layer Recommendations

1. **Add column comments to ALL tables** — not just Genie-facing ones
2. **Create a `dim_business_glossary` table** documenting canonical value domains
3. **Implement table-level comments** (COMMENT ON TABLE) for discoverability
4. **Add UC Tags** for classification: `domain:provider_contracts`, `layer:bronze`, `pii:false`
5. **Document derived metric formulas** in table properties

---

## 8. Genie Consumption Layer Analysis

### 8.1 Genie Space Architecture

**Space ID**: `01f14d360bd51f8d801452065b2df600`  
**Tables Registered**: 4 (tbl_genie_provider_profile, tbl_genie_rates_current, vw_genie_contract_terms, tbl_genie_amendment_timeline)

### 8.2 NL→SQL Optimization Patterns

| Pattern | Implementation | Genie Benefit |
|---------|---------------|---------------|
| **Wide denormalized tables** | Provider profile has 18 columns pre-joined | No multi-table JOINs needed |
| **Sentinel-safe nulls** | "Not specified" instead of NULL | `WHERE program = 'Commercial'` works; NULL comparisons eliminated |
| **Canonical buckets** | program_normalized (8 values) | Genie can enumerate options in SQL |
| **Column comments** | 67 business-friendly descriptions | NL→SQL grounding: Genie reads comments to understand column semantics |
| **Consistent naming** | snake_case, descriptive | Reduces NL→column ambiguity |
| **Current-only rates** | Pre-filtered from 39K → 6.6K | Simpler queries; no status filter needed |
| **Pre-computed metrics** | avg_inpatient_per_diem, total_amendments | Aggregation-free answers |

### 8.3 Genie Data Quality for NL→SQL

| Quality Dimension | Score | Evidence |
|-------------------|-------|----------|
| Completeness (no nulls in key fields) | ✅ 5/5 | Sentinel values replace all NULLs |
| Consistency (uniform formats) | ✅ 4/5 | Dates as DATE, numerics as DOUBLE |
| Uniqueness (no duplicates) | ✅ 5/5 | V8 amendment dedup; ROW_NUMBER partitioned |
| Accuracy (correct values) | ⚠️ 4/5 | 95% rate_numeric; 37% full_clause_text |
| Discoverability (comments) | ✅ 5/5 | 100% column documentation |
| Queryability (simple predicates) | ✅ 5/5 | Flat schema; canonical values; no JOINs |

### 8.4 Genie Query Patterns (Top 20 Expected)

| Query Category | Example NL | SQL Pattern |
|---------------|------------|-------------|
| Rate lookup | "What is the per diem rate for John Muir?" | `SELECT rate_numeric FROM tbl_genie_rates_current WHERE provider_name LIKE '%John Muir%' AND rate_category = 'inpatient_per_diem'` |
| Provider summary | "Tell me about Sutter Health" | `SELECT * FROM tbl_genie_provider_profile WHERE provider_name LIKE '%Sutter%'` |
| Comparison | "Compare ER rates across all providers" | `SELECT provider_name, rate_numeric FROM tbl_genie_rates_current WHERE service_category LIKE '%emergency%'` |
| Timeline | "What amendments has Kaiser had?" | `SELECT * FROM tbl_genie_amendment_timeline WHERE provider_name LIKE '%Kaiser%' ORDER BY amendment_order` |
| Terms search | "Find stop-loss clauses" | `SELECT * FROM vw_genie_contract_terms WHERE content_type = 'clause' AND topic LIKE '%stop%loss%'` |
| Aggregation | "Average inpatient per diem by program" | `SELECT program_normalized, AVG(rate_numeric) FROM tbl_genie_rates_current WHERE rate_category = 'inpatient_per_diem' GROUP BY 1` |

### 8.5 Genie Space Gaps

| Gap | Impact | Fix |
|-----|--------|-----|
| No sample queries / instructions in Space | Genie may generate suboptimal SQL | Add 10-20 verified sample Q&A pairs |
| vw_genie_contract_terms is 45K rows | Slow for content_text searches | Add LIKE examples in instructions |
| No date range support | "Contracts from 2023" requires parsing | Add effective_date to Genie tables |
| No rate benchmarking view | Common ask: "Is this rate above average?" | Add benchmark columns to rates table |
| No amendment summary | "What changed in amendment 3?" | summary_of_changes column exists but sparse |

---

## 9. Data Quality Review

### 9.1 Quality Dimensions Assessment

| Dimension | Overall Score | Critical Issues |
|-----------|--------------|-----------------|
| **Completeness** | 78% | 37% full_clause_text populated; effective_date_parsed has gaps |
| **Accuracy** | 88% | 99.7% date accuracy; 95% rate_numeric correct |
| **Consistency** | 82% | program field has 40+ variants before normalization |
| **Timeliness** | 70% | 34% of corpus processed; stale at 3,519/10,372 PDFs |
| **Uniqueness** | 90% | V8 dedup handles amendments; some residual multi-ID issues |
| **Validity** | 85% | Schema enforcement solid; some unverified rates |

### 9.2 Column-Level Quality Metrics

| Table | Column | Populated % | Verified % | Issues |
|-------|--------|-------------|------------|--------|
| tbl_contract_rates_all | rate_numeric | 95% | 85% | 5% null; 10% unverified (complex formulas) |
| tbl_contract_rates_all | effective_date_parsed | 78% | 99.7% | 22% unparseable string dates |
| tbl_contract_rates_all | revenue_codes | 42% | 90% | Many contracts don't specify codes |
| tbl_contract_rates_all | full_clause_text | 37% | 95% | LLM extraction doesn't always capture verbatim |
| tbl_contract_rates_all | formula | 28% | 80% | Only complex rates have formulas |
| tbl_v2_contract_registry | effective_from | 72% | 95% | Some contracts lack explicit start dates |
| tbl_v2_contract_registry | effective_to | 45% | 90% | Active contracts correctly NULL |
| tbl_reimb_rate_rules | formula_json | 100% | 75% | All have formulas but 25% are simplified |
| tbl_genie_provider_profile | avg_inpatient_per_diem | 65% | 90% | 35% providers have no inpatient rates |
| tbl_retrieval_legal_units | embedding (VS) | 100% | N/A | All units embedded via GTE-Large |

### 9.3 Validation Pipeline Coverage

| Check | Applied To | Success Rate | Failure Handling |
|-------|-----------|--------------|------------------|
| Medical code regex | revenue_codes, cpt_codes | 98% valid | Flag as unverified |
| Date format verification | effective_date (12 formats) | 99.7% accurate | Keep string; mark unverified |
| Rate sign verification | rate_numeric | 99.5% positive | Flag negative rates |
| Rate magnitude check | rate_numeric | 97% reasonable | Flag outliers (>$100K/day) |
| Delta schema readiness | All JSON fields | 100% | Reject malformed JSON |
| Coverage scoring | v6_coverage_pct | Avg 72% | Below 40% → quarantine |
| Document classification | doc_category routing | 95% correct | Fallback to "base_agreement" |
| Quarantine routing | Severe failures | <2% quarantined | Separate review queue |

### 9.4 Data Quality Flags in Schema

| Flag Column | Table | Meaning |
|-------------|-------|---------|
| `is_valid_rate` | tbl_contract_rates_all | FALSE = negative/zero rate |
| `is_latest_version` | tbl_contract_rates_all | TRUE = from highest-version doc |
| `status` | tbl_contract_rates_all | 'current' vs 'superseded' |
| `is_from_latest_doc` | vw_genie_contract_terms | TRUE = from most recent amendment |
| `is_primary_id` | dim_provider_canonical | TRUE = representative ID for facility |
| `is_current` | tbl_reimb_rate_rules | TRUE = active rate (not superseded) |

### 9.5 Quality Gaps Requiring Attention

| Priority | Gap | Impact | Remediation |
|----------|-----|--------|-------------|
| 🔴 HIGH | 66% corpus unprocessed | Missing 6,853 PDFs | Scale extraction to 10K+ |
| 🔴 HIGH | No data freshness SLA | Users don't know data currency | Add `last_refreshed_at` column |
| 🟡 MED | 22% dates unparsed | Temporal queries incomplete | Expand date format patterns |
| 🟡 MED | 37% clause_text empty | Legal retrieval gaps | Enhance LLM prompt for verbatim |
| 🟡 MED | No cross-table consistency checks | Orphan rates possible | Implement referential integrity validation |
| 🟢 LOW | 10% rates unverified | Minor accuracy risk | LLM audit covers these |


---

## 10. Governance Review

### 10.1 Unity Catalog Governance Posture

| Governance Feature | Current State | Recommended |
|--------------------|---------------|-------------|
| **Catalog/Schema hierarchy** | Single catalog (dev_adb), single schema (raw) | Separate dev/staging/prod catalogs; bronze/silver/gold schemas |
| **Table access controls** | Workspace-level only | Row-level security for PII (provider tax_id, NPI) |
| **Column masking** | None | Mask tax_id, NPI in tbl_contract_parties_all |
| **UC Tags** | None applied | layer:bronze/silver/gold, domain:contracts, pii:true/false |
| **Table comments** | Genie tables only (67 column comments) | All tables need TABLE and COLUMN comments |
| **Data classification** | Manual prefix convention | Automated classification via UC tags |
| **Audit logging** | UC system tables capture access | Additional pipeline audit in tbl_pipeline_telemetry |
| **Lineage tracking** | Manual (documented in notebooks) | UC lineage auto-captured for SQL; notebook lineage gaps |
| **Retention policies** | None configured | 30-day history for bronze; 90-day for gold |
| **Change data feed** | Not enabled | Enable CDF on contract_registry for downstream sync |

### 10.2 PII Assessment

| Table | PII Columns | Risk Level | Mitigation |
|-------|-------------|------------|------------|
| tbl_contract_parties_all | tax_id, npi, party_name, contact info | 🔴 HIGH | Column masking required |
| tbl_contract_rates_all | provider_name (indirect PII) | 🟡 MEDIUM | Acceptable for internal use |
| tbl_genie_provider_profile | provider_name, provider_id | 🟡 MEDIUM | Indirect identifier |
| dim_provider_canonical | all_names_used (array) | 🟢 LOW | Organizational names only |
| tbl_retrieval_legal_units | content_text may contain PII | 🟡 MEDIUM | Scan for SSN/tax_id patterns |

### 10.3 Governance Recommendations

1. **Apply UC Tags immediately**:
   ```sql
   ALTER TABLE dev_adb.raw.tbl_contract_parties_all 
     SET TAGS ('pii' = 'true', 'domain' = 'provider_contracts', 'layer' = 'bronze');
   ```

2. **Implement column masking for PII**:
   ```sql
   CREATE FUNCTION mask_tax_id(tax_id STRING) 
     RETURNS STRING
     RETURN CASE WHEN is_member('contract_admin') THEN tax_id ELSE 'XXX-XX-' || RIGHT(tax_id, 4) END;
   
   ALTER TABLE dev_adb.raw.tbl_contract_parties_all 
     ALTER COLUMN tax_id SET MASK mask_tax_id;
   ```

3. **Enable Change Data Feed** on critical tables:
   ```sql
   ALTER TABLE dev_adb.raw.tbl_v2_contract_registry SET TBLPROPERTIES (delta.enableChangeDataFeed = true);
   ```

4. **Create data access groups**:
   - `contract_viewer` — read access to gold/serving tables
   - `contract_analyst` — read access to silver tables + gold
   - `contract_admin` — full access including PII columns
   - `contract_pipeline` — service principal for pipeline execution

### 10.4 Compliance Considerations

| Requirement | Current Compliance | Gap |
|-------------|-------------------|-----|
| Data retention | No policy | Need 7-year retention for healthcare contracts |
| Access audit | UC system tables | Sufficient for current scale |
| Data lineage | Partial (notebook-based) | Need full UC lineage for compliance reporting |
| PII protection | None | Column masking + row-level security needed |
| Change tracking | CREATE OR REPLACE loses history | CDF or temporal tables needed |
| Disaster recovery | Delta versioning only | Need cross-region backup for production |

---

## 11. Optimization Review

### 11.1 Current Optimization State

| Table | Liquid Clustering | OPTIMIZE Run | VACUUM Run | Z-ORDER | Statistics |
|-------|------------------|-------------|------------|---------|------------|
| tbl_v2_contract_registry | ✅ (provider_id, status) | Manual | None scheduled | N/A (liquid) | Auto |
| tbl_reimb_rate_rules | ✅ (provider_id, rate_domain) | Manual | None scheduled | N/A (liquid) | Auto |
| tbl_contract_rates_all | ❌ | None | None | None | Auto |
| tbl_genie_rates_current | ❌ | None | None | None | Auto |
| tbl_retrieval_legal_units | ❌ | None | None | None | Auto |
| vw_genie_contract_terms | N/A (VIEW) | N/A | N/A | N/A | N/A |

### 11.2 Optimization Recommendations

#### A. Liquid Clustering (Priority Tables)

```sql
-- Already applied (good):
-- tbl_v2_contract_registry CLUSTER BY (provider_id, status)
-- tbl_reimb_rate_rules CLUSTER BY (provider_id, rate_domain)

-- RECOMMENDED additions:
ALTER TABLE dev_adb.raw.tbl_contract_rates_all CLUSTER BY (provider_id, status);
ALTER TABLE dev_adb.raw.tbl_genie_rates_current CLUSTER BY (provider_name, rate_category);
ALTER TABLE dev_adb.raw.tbl_retrieval_legal_units CLUSTER BY (provider_name, unit_type);
ALTER TABLE dev_adb.raw.tbl_genie_amendment_timeline CLUSTER BY (provider_name);
ALTER TABLE dev_adb.raw.tbl_contract_terms_all CLUSTER BY (provider_id, topic);
```

#### B. OPTIMIZE + VACUUM Schedule

```sql
-- Weekly maintenance job (recommended):
OPTIMIZE dev_adb.raw.tbl_contract_rates_all;
OPTIMIZE dev_adb.raw.tbl_reimb_rate_rules;
OPTIMIZE dev_adb.raw.tbl_retrieval_legal_units;
OPTIMIZE dev_adb.raw.tbl_genie_rates_current;

-- Monthly vacuum (safe after 7-day default retention):
VACUUM dev_adb.raw.tbl_contract_rates_all RETAIN 168 HOURS;
VACUUM dev_adb.raw.tbl_reimb_rate_rules RETAIN 168 HOURS;
```

#### C. Bloom Filters (For High-Cardinality Lookups)

```sql
-- source_filename lookups are common for lineage queries:
CREATE BLOOMFILTER INDEX ON TABLE dev_adb.raw.tbl_contract_rates_all FOR COLUMNS (source_filename);
CREATE BLOOMFILTER INDEX ON TABLE dev_adb.raw.tbl_contract_terms_all FOR COLUMNS (source_filename);
```

#### D. Materialized View Opportunities

| Current VIEW | Rows | Recommendation |
|-------------|------|----------------|
| vw_genie_contract_terms | 45,718 | Materialize as table if query latency exceeds 1s at scale |

### 11.3 Storage Optimization

| Table | Current Strategy | Issue | Recommendation |
|-------|-----------------|-------|----------------|
| All tables | CREATE OR REPLACE | Full rewrite on every refresh | MERGE for incremental updates |
| tbl_contract_rates_all | No partitioning | 39K rows (small, OK for now) | Cluster by provider_id when >200K rows |
| tbl_retrieval_legal_units | No partitioning | 83K rows | Cluster by unit_type when >500K rows |
| JSON extracts | Files on DBFS | Raw JSON not in Delta | Load to bronze Delta table for full lineage |

---

## 12. Partitioning/Performance Review

### 12.1 Current Partitioning Analysis

| Table | Partitioning | Clustering | Observation |
|-------|-------------|------------|-------------|
| tbl_v2_contract_registry | None | Liquid: (provider_id, status) | ✅ Optimal for contract lookups |
| tbl_reimb_rate_rules | None | Liquid: (provider_id, rate_domain) | ✅ Optimal for rate queries |
| tbl_contract_rates_all | None | None | ⚠️ Needs clustering |
| tbl_genie_rates_current | None | None | ⚠️ Small enough for now |
| tbl_retrieval_legal_units | None | None | ⚠️ Will need at scale |
| tbl_intel_benchmark_results | None | None | OK (1,399 rows, always full scan) |

### 12.2 Query Access Patterns

| Access Pattern | Frequency | Tables | Optimal Strategy |
|---------------|-----------|--------|------------------|
| Provider lookup by name/ID | Very High | All Genie tables | Cluster by provider_id/name |
| Rate category filter | High | rates_all, genie_rates | Cluster by rate_category |
| Status filter (current/active) | High | rates_all, registry | Cluster by status |
| Source document lineage | Medium | All extraction tables | Bloom filter on source_filename |
| Date range filter | Medium | registry, rates | Cluster by effective_date |
| Service line aggregation | Medium | reimb_rate_rules, benchmarks | Cluster by rate_domain |
| Full table scan (analytics) | Low | intel_* tables | No partitioning needed (small) |

### 12.3 Performance Projections at Scale

| Table | Current Rows | At Full Corpus (10K PDFs) | At 50K PDFs | Recommendation |
|-------|-------------|---------------------------|-------------|----------------|
| tbl_contract_rates_all | 39,549 | ~115,000 | ~575,000 | Liquid cluster (provider_id, status) |
| tbl_reimb_rate_rules | 21,074 | ~63,000 | ~315,000 | Already clustered ✅ |
| tbl_retrieval_legal_units | 83,008 | ~240,000 | ~1,200,000 | Liquid cluster (provider_name, unit_type) |
| tbl_contract_terms_all | ~45,000 | ~130,000 | ~650,000 | Liquid cluster (provider_id) |
| vw_genie_contract_terms | 45,718 | ~130,000 | ~650,000 | Materialize at >200K rows |
| tbl_genie_rates_current | 6,683 | ~19,000 | ~95,000 | Cluster at >50K |
| tbl_intel_benchmark_results | 1,399 | ~4,000 | ~20,000 | Small; no action needed |

### 12.4 Critical Performance Risks

| Risk | Trigger Point | Current Headroom | Mitigation |
|------|--------------|------------------|------------|
| vw_genie_contract_terms scan | >200K rows (6x growth) | ~3x headroom | Materialize or add bloom filters |
| CREATE OR REPLACE latency | >500K rows in any table | ~4x headroom | Switch to MERGE for incremental |
| Vector Search index rebuild | >500K legal units | ~6x headroom | Incremental index sync |
| Genie SQL generation timeout | Complex JOINs at scale | Currently no JOINs (safe) | Maintain denormalized pattern |
| Pipeline extraction time | 10K PDFs × 20s/file = 56 hrs | Fan-out to 10 workers = 6 hrs | Implement parallel extraction |

---

## 13. Scalability Assessment

### 13.1 Current → Target Growth Matrix

| Metric | Current (34%) | Full Corpus (100%) | Future (50K PDFs) |
|--------|--------------|-------------------|-------------------|
| PDFs processed | 3,519 | 10,372 | 50,000+ |
| Total rate rows | 39,549 | ~115,000 | ~575,000 |
| Legal units | 83,008 | ~240,000 | ~1,200,000 |
| Contracts | 1,948 | ~5,500 | ~27,500 |
| Providers | 271 (canonical) | ~800 | ~4,000 |
| Storage (Delta) | ~2 GB | ~6 GB | ~30 GB |
| VS index size | ~500 MB | ~1.5 GB | ~7.5 GB |

### 13.2 Scalability Bottleneck Analysis

| Component | Bottleneck | Current Limit | Breaking Point | Solution |
|-----------|-----------|---------------|----------------|----------|
| LLM extraction | Sequential (3 concurrent) | 20s/file = 12 hrs for 2K files | 10K files = 56 hrs | Fan-out: 10 workers, parallel notebooks |
| JSON → Delta | CREATE OR REPLACE | 39K rows in 45s | >500K rows = minutes | MERGE incremental |
| Vector Search rebuild | Full re-embed on each run | 83K units = ~30 min | 500K = 3+ hrs | Incremental sync via Delta CDF |
| Genie query latency | Full scan on small tables | <500ms | >200K rows in view = 2s+ | Materialize view; add clustering |
| State computation | Single-threaded contract iteration | 1,948 contracts in seconds | 27K = minutes | Spark parallelization already built in |
| Dashboard refresh | Query all Genie tables | <2s total | May degrade at >100K rates | Pre-computed aggregates |

### 13.3 Scalability Roadmap

| Phase | Target | Key Actions |
|-------|--------|-------------|
| **Phase 1** (Now → Full Corpus) | 10K PDFs | Parallel extraction (10 workers); MERGE for rates; clustering on key tables |
| **Phase 2** (Multi-payer) | 50K PDFs | Schema-per-payer; shared dimensions; partitioned by payer_id; multi-model LLM |
| **Phase 3** (Real-time) | Continuous ingest | Auto Loader for new PDFs; streaming Delta ingestion; near-real-time Genie refresh |

### 13.4 Capacity Planning

| Resource | Current Usage | Full Corpus | 50K PDFs | Action |
|----------|-------------|-------------|----------|--------|
| Claude API cost | ~$8K (extraction) | ~$24K | ~$120K | Multi-model: Haiku for simple, Sonnet for complex |
| Compute (extraction) | Single 4-core cluster | Same cluster, 10x time | 10-node cluster | Lakeflow Jobs with autoscaling |
| Storage (Delta) | ~2 GB | ~6 GB | ~30 GB | Within default limits |
| VS endpoint | Standard (2-4 nodes) | May need scaling | Dedicated endpoint | Monitor P95 latency |
| Genie queries | <100/day (dev) | 500-1000/day (prod) | 5000/day | SQL warehouse autoscaling |

---

## 14. Refactoring Recommendations

### 14.1 Priority-Ordered Refactoring Plan

| Priority | Recommendation | Effort | Impact | Dependencies |
|----------|---------------|--------|--------|--------------|
| 🔴 P0 | **Schema separation** (bronze/silver/gold) | 2 days | Clarity, governance, access control | None |
| 🔴 P0 | **Enable CDF** on contract_registry + rate_rules | 1 hour | Incremental downstream refresh | None |
| 🔴 P0 | **Add table/column comments** to all tables | 1 day | Discoverability, Genie improvement | None |
| 🟡 P1 | **MERGE instead of CREATE OR REPLACE** for rates | 3 days | Incremental refresh, versioning | CDF enabled |
| 🟡 P1 | **Liquid clustering** on 5 key tables | 2 hours | Query performance | None |
| 🟡 P1 | **Add contract_id to tbl_contract_rates_all** | 4 hours | Direct rate→contract join | None |
| 🟡 P1 | **UC Tags** for all tables | 2 hours | Governance, classification | None |
| 🟡 P1 | **Column masking** for PII | 4 hours | Compliance | Access groups defined |
| 🟢 P2 | **Materialize vw_genie_contract_terms** | 2 hours | Query latency at scale | Monitor usage first |
| 🟢 P2 | **OPTIMIZE/VACUUM scheduled job** | 1 hour | Storage efficiency | Lakeflow Jobs |
| 🟢 P2 | **Load raw JSON into bronze Delta** | 1 day | Full lineage in Delta | Schema design |
| 🟢 P2 | **dim_business_glossary** table | 4 hours | Self-documenting schema | None |
| 🟢 P2 | **Bloom filters** on source_filename | 30 min | Lineage query performance | None |
| 🔵 P3 | **Bitemporal rate tracking** (tbl_v2_rate_facts_bitemporal) | 1 week | Full rate history with system time | MERGE pattern |
| 🔵 P3 | **Multi-catalog** (dev/staging/prod) | 3 days | Environment isolation | CI/CD pipeline |
| 🔵 P3 | **Streaming ingestion** via Auto Loader | 1 week | Near-real-time processing | Lakeflow SDP |

### 14.2 Data Model Anti-Patterns to Fix

| Anti-Pattern | Current Instance | Recommended Fix |
|--------------|-----------------|-----------------|
| **Flat schema** | All tables in dev_adb.raw | Separate into bronze/silver/gold schemas |
| **Full refresh everywhere** | CREATE OR REPLACE on every run | MERGE with match keys for incremental |
| **String-typed dates** | effective_date (VARCHAR) alongside effective_date_parsed (DATE) | Drop string column; use DATE only |
| **Implicit relationships** | No FK columns between rates and contracts | Add explicit contract_id FK |
| **Overloaded status field** | status in rates = 'current'/'superseded'; in registry = 'ACTIVE'/'EXPIRED'/etc. | Use distinct column names: rate_status, contract_status |
| **Mixed granularity** | tbl_contract_rates_all mixes current + historical | Separate into rates_history (bronze) + rates_current (gold) |
| **No soft deletes** | Records removed via full refresh | Add is_deleted flag; retain history |
| **View as primary serving** | vw_genie_contract_terms (45K rows) | Materialize when latency matters |

### 14.3 Schema Evolution Recommendations

```
CURRENT STATE:
  dev_adb.raw (30+ tables, flat)

TARGET STATE (3 months):
  dev_adb.bronze    — Raw extraction output (source of truth)
  dev_adb.silver    — Normalized, validated, business logic applied
  dev_adb.gold      — Pre-aggregated, Genie-serving, dashboard
  dev_adb.ops       — Pipeline telemetry, audit, evaluation

FUTURE STATE (6 months):
  prod_adb.bronze   — Production extraction pipeline
  prod_adb.silver   — Production normalized data
  prod_adb.gold     — Production serving layer
  dev_adb.*         — Development/testing only
  staging_adb.*     — Pre-production validation
```

### 14.4 Migration Path

| Step | Action | Validation | Rollback |
|------|--------|------------|----------|
| 1 | Create new schemas (bronze, silver, gold, ops) | SHOW SCHEMAS | DROP SCHEMA |
| 2 | CREATE TABLE ... AS SELECT ... for each table in new schema | Row count match | Original tables still exist |
| 3 | Update Genie Space dataset queries to gold schema | Test NL queries | Revert dataset SQL |
| 4 | Update Dashboard queries | Visual verification | Revert queries |
| 5 | Update notebook references | Full pipeline test | Git revert |
| 6 | Apply UC tags + column comments to new tables | DESCRIBE EXTENDED | N/A (additive) |
| 7 | Deprecate dev_adb.raw tables (retain 30 days) | Monitor access patterns | Restore from Delta history |
| 8 | DROP deprecated tables after validation | Final count check | UNDROP TABLE |

---

## Appendix A: Table Refresh Dependency Order

```
EXECUTION ORDER (must be sequential):

STAGE 1: Extraction (notebooks 01-09)
  ① tbl_contract_documents_master
  ② tbl_contract_rates_all
  ③ tbl_contract_terms_all
  ④ tbl_contract_clauses_all
  ⑤ tbl_contract_financial_protections
  ⑥ tbl_contract_regional_factors
  ⑦ tbl_contract_parties_all
  ⑧ tbl_contract_terms_vs_ready

STAGE 2: Dimensions (independent, can run in parallel)
  ⑨ dim_provider_canonical (depends on: rates_all, documents_master)
  ⑩ dim_service_line_taxonomy (seed data, rarely changes)
  ⑪ dim_service_line_patterns (seed data, rarely changes)

STAGE 3: State Engine (depends on Stage 1 + 2)
  ⑫ tbl_v2_contract_registry (depends on: documents_master, dim_provider_canonical)
  ⑬ tbl_v2_amendment_registry (depends on: contract_registry, documents_master)

STAGE 4: Reimbursement (depends on Stage 2 + 3)
  ⑭ tbl_reimb_rate_rules (depends on: rates_all, contract_registry, dim_service_line)
  ⑮ tbl_reimb_stop_loss (depends on: financial_protections, rate_rules)
  ⑯ tbl_reimb_lesser_of (depends on: financial_protections)

STAGE 5: Intelligence (depends on Stage 4)
  ⑰ tbl_intel_benchmark_results (depends on: rate_rules)
  ⑱ tbl_intel_savings_opportunity (depends on: rate_rules, benchmarks)
  ⑲ tbl_intel_renewal_priority (depends on: contract_registry, amendment_registry)
  ⑳ tbl_intel_leverage_scores (depends on: rate_rules, benchmarks)

STAGE 6: Serving (depends on all above)
  ㉑ tbl_genie_provider_profile (depends on: rates_all, documents_master, dim_canonical)
  ㉒ tbl_genie_rates_current (depends on: rates_all, dim_canonical, V8 dedup)
  ㉓ vw_genie_contract_terms (VIEW - auto-refreshes from terms + clauses + parties)
  ㉔ tbl_genie_amendment_timeline (depends on: documents_master)
  ㉕ tbl_serving_capitation_card (depends on: rates_all WHERE capitation)

STAGE 7: Retrieval (independent path)
  ㉖ tbl_retrieval_legal_units (depends on: terms_vs_ready)
  ㉗ Vector Search Index (depends on: legal_units + embedding)
```

---

## Appendix B: Data Model Maturity Scorecard

| Category | Weight | Score | Weighted |
|----------|--------|-------|----------|
| Schema Design | 20% | 3.5/5 | 0.70 |
| Data Quality | 20% | 3.8/5 | 0.76 |
| Governance | 15% | 2.0/5 | 0.30 |
| Performance Optimization | 15% | 3.0/5 | 0.45 |
| Scalability | 15% | 3.2/5 | 0.48 |
| Documentation | 10% | 3.5/5 | 0.35 |
| Operability | 5% | 2.5/5 | 0.13 |
| **TOTAL** | **100%** | | **3.17/5 (63%)** |

**Verdict**: Data model is **well-designed for MVP** with strong extraction-to-serving flow, but needs governance hardening, schema separation, and incremental refresh patterns for production readiness.

---

## Appendix C: Quick Reference — Table-to-Notebook Map

| Table | Creating Notebook | Layer |
|-------|------------------|-------|
| tbl_contract_rates_all | extraction/06_build_tables.py | Bronze |
| tbl_contract_financial_protections | extraction/06_build_tables.py | Bronze |
| tbl_contract_regional_factors | extraction/06_build_tables.py | Bronze |
| tbl_contract_terms_all | extraction/06_build_tables.py | Bronze |
| tbl_contract_clauses_all | extraction/06_build_tables.py | Bronze |
| tbl_contract_documents_master | extraction/06_build_tables.py | Bronze |
| tbl_contract_parties_all | extraction/06_build_tables.py | Bronze |
| tbl_contract_terms_vs_ready | extraction/09_vector_search_prep.py | Bronze |
| dim_provider_canonical | platform/01_dimensions.py | Dimension |
| dim_service_line_taxonomy | platform/02_service_taxonomy.py | Dimension |
| dim_service_line_patterns | platform/02_service_taxonomy.py | Dimension |
| tbl_v2_contract_registry | platform/03_state_engine.py | Silver |
| tbl_v2_amendment_registry | platform/03_state_engine.py | Silver |
| tbl_reimb_rate_rules | platform/04_reimbursement.py | Silver |
| tbl_reimb_stop_loss | platform/05_financial_protections.py | Silver |
| tbl_reimb_lesser_of | platform/05_financial_protections.py | Silver |
| tbl_intel_benchmark_results | platform/06_benchmarks.py | Gold |
| tbl_intel_savings_opportunity | platform/07_savings.py | Gold |
| tbl_intel_renewal_priority | platform/08_renewals.py | Gold |
| tbl_intel_leverage_scores | platform/09_leverage.py | Gold |
| tbl_genie_provider_profile | extraction/13_genie_build.py | Gold/Serving |
| tbl_genie_rates_current | extraction/14_genie_rates.py | Gold/Serving |
| vw_genie_contract_terms | extraction/15_genie_terms.py | Gold/Serving |
| tbl_genie_amendment_timeline | extraction/13_genie_build.py | Gold/Serving |
| tbl_retrieval_legal_units | platform/10_retrieval.py | Silver |
| tbl_pipeline_telemetry | platform/00_telemetry.py | Operational |
| tbl_extraction_quality_audit | extraction/10_quality_audit.py | Operational |
| tbl_extraction_quality_gaps | extraction/11_gap_fill.py | Operational |
| tbl_eval_golden_queries | extraction/12_evaluation.py | Operational |

---

*End of Document*
