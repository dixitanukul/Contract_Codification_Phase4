# BSC Provider Contract Intelligence Platform — Enterprise Architecture Review

**Document Classification**: Internal — Architecture Assessment  
**Author**: Architecture Review (Automated)  
**Date**: May 2026  
**Version**: 1.0  
**Scope**: End-to-end analysis of the Provider Contract Intelligence Platform  
**Schema**: `dev_adb.raw` | **Runtime**: DBR 18.0 | **Cloud**: Azure Databricks

---

## Table of Contents

1. [Executive Summary](#1-executive-summary)
2. [Current State Architecture](#2-current-state-architecture)
3. [Architecture Diagrams](#3-architecture-diagrams)
4. [Data Flow Analysis](#4-data-flow-analysis)
5. [Stage-by-Stage Deep Dive](#5-stage-by-stage-deep-dive)
6. [Technology Assessment](#6-technology-assessment)
7. [Architecture Decisions Analysis](#7-architecture-decisions-analysis)
8. [Risk Heatmap & Failure Points](#8-risk-heatmap--failure-points)
9. [Scalability Bottlenecks](#9-scalability-bottlenecks)
10. [Ideal Future State Architecture](#10-ideal-future-state-architecture)
11. [Simplified Leadership View](#11-simplified-leadership-view)
12. [Technical Architecture View](#12-technical-architecture-view)
13. [Business Capability Mapping](#13-business-capability-mapping)
14. [Critical Dependencies](#14-critical-dependencies)
15. [Cost Optimization Recommendations](#15-cost-optimization-recommendations)
16. [Architecture Improvement Roadmap](#16-architecture-improvement-roadmap)

---

## 1. Executive Summary

### What This Platform Does

The BSC Provider Contract Intelligence Platform is an end-to-end AI/ML system that converts 10,372 unstructured provider contract PDFs (27.3 GB) into a structured, queryable intelligence layer serving natural-language analytics, negotiation support, and portfolio-level decisioning for Blue Shield of California's Provider Contracting division.

### Key Metrics

| Metric | Value |
|--------|-------|
| Source PDFs | 10,372 (597 provider folders) |
| Total Data Volume | 27.3 GB raw PDF |
| PDFs Processed (current) | ~3,519 (34%) |
| Delta Tables Created | 30+ analytical tables |
| Legal Units Indexed | 83,008 |
| Rate Rules Extracted | 21,074 |
| Providers Covered | 348 (271 canonical facilities) |
| Genie Space Tables | 4 AI-optimized serving tables |
| Intelligence Outputs | Benchmarks, renewals, leverage, scenarios |

### Architecture Classification

**Pattern**: Batch ETL + AI Extraction + Semantic Serving  
**Paradigm**: Modified Medallion (Bronze→Silver→Gold with AI enrichment at Silver)  
**Orchestration**: Manual notebook chaining (no automated DAG currently)  
**AI Layer**: Claude Sonnet 4.5 via REST API + Vector Search + GTE-Large embeddings  
**Serving**: Genie Space (NL queries) + Lakeview Dashboard + Retrieval Engine

### Overall Assessment

| Dimension | Grade | Notes |
|-----------|-------|-------|
| Extraction Quality | A- | 100% success rate on processed files; V6 schema well-designed |
| Architecture Clarity | B+ | Clean separation of concerns; well-documented |
| Production Readiness | C+ | Manual orchestration, no automated scheduling, incomplete corpus |
| Scalability | B- | Works at current scale; REST API concurrency limits at 10K |
| Observability | B | Telemetry table + progress files; lacks alerting/dashboarding |
| Cost Efficiency | C | LLM costs not optimized; no tiered extraction strategy |
| Governance | B+ | Unity Catalog, column comments, table comments throughout |
| Resilience | B | Checkpoint-resumable; but no automated retry on failure |

---

## 2. Current State Architecture

### 2.1 System Boundary Diagram

```
┌─────────────────────────────────────────────────────────────────────────────────────────┐
│                         BSC PROVIDER CONTRACT INTELLIGENCE PLATFORM                       │
│                                                                                          │
│  ┌──────────────────────────────────────────────────────────────────────────────────┐   │
│  │ LAYER 1: EXTRACTION (extraction/ — 15 notebooks)                                  │   │
│  │                                                                                    │   │
│  │  [Unity Catalog Volume]     [Local NVMe SSD]     [Databricks Serving]              │   │
│  │  /Volumes/prod_adb/...  →   /local_disk0/tmp  →   Claude Sonnet 4.5               │   │
│  │  10,372 PDFs (27 GB)        Prefetch cache         REST API (3 workers)            │   │
│  │                                                                                    │   │
│  │  Outputs: json_extract/ (3,519 files) + 12 Delta tables in dev_adb.raw            │   │
│  └──────────────────────────────┬───────────────────────────────────────────────────┘   │
│                                  │                                                       │
│  ┌──────────────────────────────▼───────────────────────────────────────────────────┐   │
│  │ LAYER 2: FOUNDATION (platform/ 00-03)                                             │   │
│  │                                                                                    │   │
│  │  [DDL Execution]  →  [State Engine]  →  [Reimbursement Migration]                  │   │
│  │  18 tables created    1,948 contracts     21K rate rules, 741 stop-loss            │   │
│  │  + taxonomy seed      1,570 amendments    50 service lines                         │   │
│  └──────────────────────────────┬───────────────────────────────────────────────────┘   │
│                                  │                                                       │
│  ┌──────────────────────────────▼───────────────────────────────────────────────────┐   │
│  │ LAYER 3: INTELLIGENCE (platform/ 04-11)                                           │   │
│  │                                                                                    │   │
│  │  [Legal Chunking]  →  [Retrieval]  →  [Reranking]  →  [Citation Verification]     │   │
│  │  83K units + VS index  4-channel RRF    3-stage         6-check engine             │   │
│  │                                                                                    │   │
│  │  [Benchmarks]  →  [Scenarios]  →  [Leverage]  →  [Evaluation]                     │   │
│  │  1,399 groups      5 templates     348 providers   20 golden queries               │   │
│  └──────────────────────────────┬───────────────────────────────────────────────────┘   │
│                                  │                                                       │
│  ┌──────────────────────────────▼───────────────────────────────────────────────────┐   │
│  │ LAYER 4: SERVING                                                                  │   │
│  │                                                                                    │   │
│  │  [Genie Space]          [Lakeview Dashboard]       [Retrieval API]                 │   │
│  │  NL contract queries    Portfolio analytics         Citation-grounded Q&A           │   │
│  │  4 optimized tables     Provider overview           Legal unit search               │   │
│  └──────────────────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────────────────┘

EXTERNAL DEPENDENCIES:
  • Azure Blob → UC Volume (prod_adb/default/ext-data-volume-stmlz)
  • Databricks Model Serving (Claude Sonnet 4.5, GTE-Large-EN)
  • Databricks Vector Search (contract_intelligence_vs_endpoint)
  • [Future] Enterprise Claims Warehouse
  • [Future] Cross-encoder Reranker (bge-reranker-v2-m3)
```

### 2.2 Component Inventory

| Component | Type | Count | Location |
|-----------|------|-------|----------|
| Extraction Notebooks | Databricks Notebook | 15 | extraction/ |
| Platform Modules | Python Files | 12 | platform/ |
| SQL DDL Scripts | SQL Files | 3 | sql/ |
| Design Documents | Markdown | 26 | docs/ |
| JSON Extractions | File Artifacts | 3,519 | data/json_extract/ |
| Consolidated JSONs | File Artifacts | 456 | data/json_consolidated/ |
| Checkpoint Files | Parquet | ~5 | data/checkpoints/ |
| Delta Tables (V1) | UC Managed Tables | 12+ | dev_adb.raw.tbl_contract_* |
| Delta Tables (V2) | UC Managed Tables | 10+ | dev_adb.raw.tbl_v2_*, tbl_reimb_*, tbl_intel_* |
| Genie Tables | UC Managed Tables | 4 | dev_adb.raw.tbl_genie_*, vw_genie_* |
| Serving Tables | UC Managed Tables | 4 | dev_adb.raw.tbl_serving_* |
| Dimension Tables | UC Managed Tables | 3 | dev_adb.raw.dim_* |
| Vector Search Index | VS Index | 1 | idx_legal_units_v2 |
| Genie Space | AI/BI Space | 1 | BSC Provider Contract Intelligence |
| Dashboard | Lakeview | 1 | Portfolio Overview |

---

## 3. Architecture Diagrams

### 3.1 Contract Ingestion Flow

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        CONTRACT INGESTION FLOW                                │
└─────────────────────────────────────────────────────────────────────────────┘

  SOURCE                    DISCOVERY                  PREFETCH
  ───────                   ─────────                  ────────
  /Volumes/prod_adb/        01_file_discovery          NVMe SSD
  └── Provider_Contracts/   ├── os.walk() scan         /local_disk0/tmp/
      ├── Provider_A/       ├── Registry parquet       ├── Provider_A/
      │   ├── base.pdf      │   (10,372 entries)       │   ├── base.pdf
      │   └── amend_1.pdf   ├── Checkpoint recovery    │   └── amend_1.pdf
      ├── Provider_B/       │   (skip already done)    ├── Provider_B/
      │   └── ...           └── File selection          │   └── ...
      └── 597 folders           (sample or full)       └── 32-thread copy
                                                            (27 GB → SSD)

  METADATA PARSING              FILE NAMING CONVENTION
  ────────────────              ──────────────────────
  03_metadata_parsing           {providerID}_{providerName}_{contractID}_{docType}_{version}.pdf
  ├── Parse filename fields     
  │   (provider_id, contract_id,     Document Types:
  │    doc_type, version)             ├── BaseAgmt (3,304)
  ├── Determine document type         ├── Amendment (6,754 incl CM)
  │   (187 unique raw types)          ├── Settlement (93)
  └── Build step2 checkpoint          └── Other (221)
```

### 3.2 Extraction Flow (OCR + LLM)

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           EXTRACTION FLOW                                     │
└─────────────────────────────────────────────────────────────────────────────┘

  PDF INPUT                TIER 1: pypdf              TIER 2: ai_parse_document
  ─────────                ──────────────             ────────────────────────
  file_registry            ProcessPoolExecutor        Spark SQL UDF
  (10,372 files)           14 processes (GIL-free)    Batch of 25
                           30s internal timeout       20 concurrent partitions
                           ↓                          ↓
                           ~82% success               ~18% (scanned/complex)
                           ↓                          ↓
                           MIN_GOOD_CHARS check       Binary → Spark DF
                           (500 chars minimum)        → ai_parse_document()
                           ↓                          ↓
                           ┌──────────────────────────┘
                           ↓
                    step1_parsed_v2.parquet
                    (full_text per PDF, incremental checkpoint)
                           ↓
  ┌────────────────────────────────────────────────────────────────────────┐
  │ LLM EXTRACTION ENGINE (05_llm_extraction)                              │
  │                                                                        │
  │  ┌─────────────┐     ┌──────────────────┐     ┌──────────────────┐   │
  │  │ Prompt       │     │ REST API Call      │     │ Response Parse   │   │
  │  │ Selection    │     │                    │     │                  │   │
  │  │             │     │ Claude Sonnet 4.5  │     │ clean_json()     │   │
  │  │ 4 prompts:  │────▶│ 200K context       │────▶│ repair_truncated │   │
  │  │ • Base      │     │ 65K output tokens  │     │ validate()       │   │
  │  │ • Amendment │     │ temp=0.0           │     │ score()          │   │
  │  │ • Cover Memo│     │ 3 parallel workers │     │                  │   │
  │  │ • Settlement│     │ 1800s timeout      │     └────────┬─────────┘   │
  │  └─────────────┘     └──────────────────┘              │              │
  │                                                         ↓              │
  │  ADAPTIVE CONCURRENCY          CHUNKING (>150K chars)                  │
  │  ─────────────────────         ──────────────────────                  │
  │  • Starts at 3 workers         • Split into 80K segments               │
  │  • Throttle on 429/rate        • 2K char overlap                       │
  │  • Exponential backoff          • Results merged post-extraction        │
  │  • Re-ramp after cooldown      • Largest: 46K in + 48K out             │
  │                                                         ↓              │
  │                            json_extract/{base_filename}.json            │
  │                            (V6 Delta-Ready Schema)                     │
  └────────────────────────────────────────────────────────────────────────┘
```

### 3.3 Validation Flow

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           VALIDATION FLOW                                     │
└─────────────────────────────────────────────────────────────────────────────┘

  json_extract/*.json
        │
        ▼
  ┌─────────────────────────────────────────────────────────────────────┐
  │ 06_validation — 8 Validation Checks                                 │
  │                                                                     │
  │  1. MEDICAL CODE EXTRACTION                                         │
  │     Regex: CPT (5-digit), HCPCS (alpha+4), ICD-10 (alpha+N),      │
  │     Revenue codes (4-digit 0xxx)                                    │
  │     → 2,545 codes extracted across corpus                           │
  │                                                                     │
  │  2. DATE VERIFICATION                                               │
  │     Compare extracted dates against source PDF text                  │
  │     Multiple format variants (MM/DD/YYYY, Month DD, YYYY, etc.)     │
  │     → Flag unverified dates (possible hallucinations)               │
  │     → 36 unverified dates detected                                  │
  │                                                                     │
  │  3. RATE VERIFICATION (OCR-aware fuzzy matching)                    │
  │     Compare rate amounts against source text                         │
  │     OCR artifacts: comma/period confusion, whitespace, precision     │
  │     → 76% → ~30% unverified after OCR-aware matching                │
  │                                                                     │
  │  4. RATE_NUMERIC POST-PROCESSING                                    │
  │     Parse rate strings where LLM missed rate_numeric                 │
  │     $5,748 → 5748.00 | 88.9% → 88.9                               │
  │     → 63% → ~95% rate_numeric coverage                             │
  │                                                                     │
  │  5. DELTA READINESS CHECK                                           │
  │     V6 schema compliance: rate_numeric, full_clause_text,           │
  │     amendments_impact presence                                       │
  │                                                                     │
  │  6. COVERAGE SCORING                                                │
  │     Doc-type-specific weighting                                      │
  │     Section-level completeness metrics                               │
  │                                                                     │
  │  7. DOCUMENT CLASSIFICATION                                         │
  │     Content bucket + document_subtype assignment                     │
  │     Stub detection for minimal-content docs                          │
  │                                                                     │
  │  8. QUARANTINE                                                       │
  │     Critical failures → quarantined flag (excluded from table builds)│
  └─────────────────────────────┬───────────────────────────────────────┘
                                │
                                ▼
                    json_extract/*.json (enriched in-place)
                    + Pipeline quality report (exit codes 0/1/2)
```

### 3.4 Normalization & Table Build Flow

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                      NORMALIZATION & TABLE BUILD FLOW                         │
└─────────────────────────────────────────────────────────────────────────────┘

  json_extract/                 VERSION DEDUPLICATION
  (3,519 files)                 ─────────────────────
        │                       Keep highest version per
        │                       (provider_id, contract_id,
        │                        doc_type, effective_date)
        ▼
  ┌──────────────────────────────────────────────────────────────────────────┐
  │ TABLE BUILD PIPELINE (notebooks 08-13)                                   │
  │                                                                          │
  │  08_build_rates                                                          │
  │  ├── tbl_contract_rates_all (39,549 rows)                               │
  │  │   └── Post-fix: status supersession, program normalization            │
  │  │       (148 variants → 8 canonical: Commercial, Medicare, Medi-Cal,   │
  │  │        CalPERS, All Programs, Commercial Trio, Dual Eligible, Other)  │
  │  ├── tbl_contract_regional_factors (5,710 rows)                          │
  │  └── tbl_contract_financial_protections (2,077 rows)                     │
  │                                                                          │
  │  09_build_terms                                                          │
  │  ├── tbl_contract_terms_all (clauses + provisions)                       │
  │  └── tbl_contract_clauses_all                                            │
  │                                                                          │
  │  10_build_documents                                                      │
  │  ├── tbl_contract_documents_master (amendment_order, doc_category)        │
  │  └── tbl_contract_parties_all                                            │
  │                                                                          │
  │  11_enrich_tables                                                        │
  │  ├── dim_provider_canonical (facility-level resolution)                   │
  │  ├── is_latest_version flags                                             │
  │  └── Amendment depth computation                                          │
  │                                                                          │
  │  12_build_genie (SERVING LAYER v5)                                       │
  │  ├── tbl_genie_provider_profile (271 facilities)                          │
  │  ├── tbl_genie_rates_current (6,683 deduped rates)                       │
  │  ├── vw_genie_contract_terms (45,718 rows, latest-doc flag)              │
  │  ├── tbl_genie_amendment_timeline (2,254 documents)                      │
  │  └── 67 column comments applied (100% Genie coverage)                    │
  │                                                                          │
  │  13_build_serving                                                        │
  │  ├── tbl_serving_capitation_card                                          │
  │  └── tbl_contract_terms_vs_ready (69K structured rows)                   │
  └──────────────────────────────────────────────────────────────────────────┘
```

### 3.5 Orchestration Flow

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        ORCHESTRATION FLOW                                     │
│                    (Current: Manual | Future: Lakeflow Jobs DAG)              │
└─────────────────────────────────────────────────────────────────────────────┘

  EXTRACTION PIPELINE (Sequential — must run in order)
  ═══════════════════════════════════════════════════

  _config (shared)
     │
     ├── 01_file_discovery ──────────── [Idempotent, 5-10 min]
     │       Registry scan, prefetch, checkpoint recovery
     │
     ├── 02_ocr_extraction ──────────── [CPU-bound, 30-120 min depending on new files]
     │       2-tier: pypdf(14 proc) → ai_parse_document(batch)
     │
     ├── 03_metadata_parsing ────────── [Fast, <5 min]
     │       Filename parsing + document type classification
     │
     ├── 04_llm_prompts ─────────────── [In-memory only, <1 min]
     │       Prompt template selection logic
     │
     ├── 05_llm_extraction ──────────── [CRITICAL PATH: 1-10 hrs depending on volume]
     │       Claude REST API, 3 workers, 1800s/file timeout
     │       REBUILD GATE: skip if no new files + force_rebuild=false
     │
     ├── 06_validation ──────────────── [10-20 min]
     │       8 checks, enrichment in-place, quarantine
     │
     ├── 08_build_rates ─────────────── [5-15 min]
     │       3 rate tables from JSON
     │
     ├── 09_build_terms ─────────────── [5-10 min]
     │       Terms + clauses tables
     │
     ├── 10_build_documents ─────────── [5-10 min]
     │       Documents master + parties
     │
     ├── 11_enrich_tables ───────────── [10-20 min]
     │       Provider canonical, version flags, depth
     │
     ├── 12_build_genie ─────────────── [5-10 min, depends on 08-11]
     │       4 serving tables + 67 column comments
     │
     ├── 13_build_serving ───────────── [5 min]
     │       Capitation card + VS-ready table
     │
     ├── 14_quality_audit ───────────── [5 min]
     │       Final quality report
     │
     └── 15_gap_filler ──────────────── [Variable, optional]
             Re-extract low-quality files

  PLATFORM PIPELINE (Sequential — depends on extraction outputs)
  ═════════════════════════════════════════════════════════════

  00_config.py ─────────────────── [Session initialization]
     │
     ├── 01_execute_ddl.py ─────── [Create 18 tables + seed taxonomy]
     │
     ├── 02_state_engine.py ────── [Contract + amendment registries]
     │       INSERT OVERWRITE (atomic), MAX_BY deterministic
     │
     ├── 03_reimbursement_migration.py ── [V1→V2 rate rules]
     │       21K FFS + capitation → normalized rate_rules table
     │
     ├── 04_legal_chunking.py ──── [83K legal units + VS index build]
     │       bootstrap from tbl_contract_terms_vs_ready
     │
     ├── 05_retrieval_engine.py ── [4-channel hybrid retrieval]
     │       semantic + lexical + metadata + structural
     │
     ├── 06_reranking_service.py ─ [3-stage: BM25→signals→cross-encoder]
     │       (cross-encoder PENDING: RERANKER_DEPLOYED=False)
     │
     ├── 07_citation_verification.py ── [6-check answer verification]
     │       Source confirmation + date + numeric + scope + contradiction
     │
     ├── 08_intelligence.py ────── [Benchmarks + renewal priority]
     │       (Spend/savings/leverage REMOVED — needs claims feed)
     │
     ├── 09_scenario_engine.py ──── [What-if simulations]
     │       rate_change | termination | budget_backward templates
     │
     ├── 10_leverage_scoring.py ── [Bilateral leverage analysis]
     │       (PENDING: needs claims data for volume weights)
     │
     └── 11_evaluation_harness.py ── [20 golden queries + monitoring]
             Correctness scoring against known answers
```

### 3.6 Lineage Flow

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           DATA LINEAGE FLOW                                   │
└─────────────────────────────────────────────────────────────────────────────┘

  SOURCE (Bronze)                    EXTRACTION (Silver)
  ══════════════                     ═══════════════════
  /Volumes/prod_adb/.../             json_extract/*.json (3,519)
  Provider_Contracts/                      │
  (10,372 PDFs)                           │
       │                                   ▼
       │                    ┌─────────────────────────────────────┐
       └───── OCR ─────────▶│ step1_parsed_v2.parquet             │
                            │ step2_with_metadata_v2.parquet      │
                            └──────────────┬──────────────────────┘
                                           │
                     TABLE BUILD           │
                     ═══════════           ▼
  ┌────────────────────────────────────────────────────────────────────────┐
  │ BASE TABLES (V1)                                                       │
  │ ├── tbl_contract_rates_all ←─── json_extract/*/inpatient_rates,       │
  │ │                                outpatient_rates, capitation_table     │
  │ ├── tbl_contract_financial_protections ←── stop_loss_reinsurance       │
  │ ├── tbl_contract_regional_factors ←── regional_factors                 │
  │ ├── tbl_contract_terms_all ←── sections, key_provisions               │
  │ ├── tbl_contract_clauses_all ←── clauses (full_clause_text)           │
  │ ├── tbl_contract_documents_master ←── file_metadata + contract_overview│
  │ ├── tbl_contract_parties_all ←── parties (health_plan, provider)       │
  │ └── dim_provider_canonical ←── provider_id deduplication               │
  └───────────────────────────────────────┬────────────────────────────────┘
                                          │
                  STATE ENGINE            │       REIMBURSEMENT
                  ════════════            ▼       ═════════════
  ┌────────────────────────────────────────────────────────────────────────┐
  │ FOUNDATION TABLES (V2)                                                 │
  │ ├── tbl_v2_contract_registry ←── documents_master (base agreements)    │
  │ ├── tbl_v2_amendment_registry ←── documents_master (amendments)        │
  │ ├── tbl_reimb_rate_rules ←── rates_all (normalized + taxonomy join)    │
  │ ├── tbl_reimb_stop_loss ←── financial_protections                      │
  │ ├── tbl_reimb_lesser_of ←── financial_protections (lesser-of rules)    │
  │ ├── dim_service_line_taxonomy (50 rows, seed data)                     │
  │ └── dim_service_line_patterns (45 rows, regex patterns)                │
  └───────────────────────────────────────┬────────────────────────────────┘
                                          │
               INTELLIGENCE               │       RETRIEVAL
               ════════════               ▼       ═════════
  ┌────────────────────────────────────────────────────────────────────────┐
  │ INTELLIGENCE + RETRIEVAL TABLES                                        │
  │ ├── tbl_retrieval_legal_units (83K) ←── tbl_contract_terms_vs_ready   │
  │ ├── idx_legal_units_v2 (VS index) ←── tbl_retrieval_legal_units       │
  │ ├── tbl_intel_benchmark_results ←── tbl_reimb_rate_rules              │
  │ ├── tbl_intel_renewal_priority ←── tbl_v2_contract_registry           │
  │ └── tbl_eval_golden_queries (20 hand-curated)                          │
  └───────────────────────────────────────┬────────────────────────────────┘
                                          │
                   GENIE SERVING           ▼
                   ════════════
  ┌────────────────────────────────────────────────────────────────────────┐
  │ SERVING TABLES (Gold — optimized for Genie Space)                      │
  │ ├── tbl_genie_provider_profile ←── dim_provider_canonical + rates +    │
  │ │                                   documents_master + protections      │
  │ ├── tbl_genie_rates_current ←── tbl_contract_rates_all (deduped)       │
  │ ├── vw_genie_contract_terms ←── terms_all + clauses_all + parties +    │
  │ │                                 codes + is_from_latest_doc flag       │
  │ └── tbl_genie_amendment_timeline ←── documents_master + enrichment     │
  └────────────────────────────────────────────────────────────────────────┘
```

### 3.7 Serving Flow (Business Consumption)

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                          SERVING & CONSUMPTION FLOW                           │
└─────────────────────────────────────────────────────────────────────────────┘

  ┌─────────────────────────────────────────────────────────────────┐
  │ GENIE SPACE (Natural Language Interface)                         │
  │ "BSC Provider Contract Intelligence"                             │
  │                                                                  │
  │ User asks: "What is Cedars-Sinai's inpatient per diem rate?"    │
  │                    ↓                                             │
  │ Tables Available:                                                │
  │   • tbl_genie_provider_profile (271 facilities)                 │
  │   • tbl_genie_rates_current (6,683 current rates)               │
  │   • vw_genie_contract_terms (45,718 clause rows)                │
  │   • tbl_genie_amendment_timeline (2,254 docs)                   │
  │   • dim_provider_canonical (facility dedup)                      │
  │                                                                  │
  │ SQL Generated → Executed → Results returned with citation        │
  └─────────────────────────────────────────────────────────────────┘

  ┌─────────────────────────────────────────────────────────────────┐
  │ LAKEVIEW DASHBOARD (Portfolio Analytics)                         │
  │ "BSC Provider Contract Intelligence - Portfolio Overview"        │
  │                                                                  │
  │ Widgets:                                                         │
  │   • Provider count + rate summary counters                       │
  │   • Rate distribution by program (bar chart)                     │
  │   • Amendment timeline (line chart)                              │
  │   • Contract terms by content type (pie chart)                   │
  │   • Financial protections overview                               │
  └─────────────────────────────────────────────────────────────────┘

  ┌─────────────────────────────────────────────────────────────────┐
  │ RETRIEVAL ENGINE (Citation-Grounded Q&A)                        │
  │                                                                  │
  │ Query → Parse → 4-Channel Retrieval → RRF Fusion → Rerank      │
  │   → Citation Verification → Grounded Answer                      │
  │                                                                  │
  │ Channels:                                                        │
  │   1. Semantic: Vector Search (GTE-Large embeddings)              │
  │   2. Lexical: ILIKE/RLIKE on legal_units                         │
  │   3. Metadata: Direct SQL on rate_rules/stop_loss               │
  │   4. Structural: Section-aware expansion                         │
  │                                                                  │
  │ Verification (6 checks):                                         │
  │   Source confirmation, date, numeric, scope, contradiction,      │
  │   confidence scoring                                             │
  └─────────────────────────────────────────────────────────────────┘

  ┌─────────────────────────────────────────────────────────────────┐
  │ INTELLIGENCE ENGINE (Negotiation Support)                        │
  │                                                                  │
  │ Outputs:                                                         │
  │   • Benchmark percentiles (P10/P25/P50/P75/P90 by service line) │
  │   • Renewal priority scoring (expiry-based)                      │
  │   • [Future] Provider spend summaries (needs claims)             │
  │   • [Future] Savings opportunities (needs claims)                │
  │   • [Future] Leverage scores (needs claims + market share)       │
  │   • Scenario simulations (rate change, termination, budget)      │
  └─────────────────────────────────────────────────────────────────┘
```

### 3.8 Genie Space Interaction Flow

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                     GENIE SPACE INTERACTION FLOW                              │
└─────────────────────────────────────────────────────────────────────────────┘

  USER QUERY                    GENIE PROCESSING                  RESPONSE
  ──────────                    ────────────────                  ────────

  "Show me all providers     →  Query Understanding:            →  SQL Generated:
   with stop-loss above         • Table: tbl_genie_provider_       SELECT provider_name,
   $500K"                         profile                           stop_loss_threshold
                                • Column: stop_loss_threshold     FROM tbl_genie_provider_
                                • Filter: > 500000                  profile
                                • Comment-guided column choice     WHERE stop_loss_threshold
                                                                    > 500000
                                                                    ORDER BY ...

  "What amendment changed    →  Query Understanding:            →  SQL Generated:
   rates for Providence?"       • Table: tbl_genie_amendment_      SELECT source_filename,
                                  timeline                          summary_of_changes,
                                • JOIN: provider_name               effective_date
                                • Content: summary_of_changes     FROM tbl_genie_amendment_
                                                                    timeline
                                                                  WHERE provider_name
                                                                    ILIKE '%Providence%'

  COLUMN COMMENTS (67 total) — Critical for Genie accuracy:
  ──────────────────────────
  • provider_name: "Canonical facility name (resolved from dim_provider_canonical)"
  • rate_numeric: "Numeric rate value in dollars (parsed from rate string)"
  • program_normalized: "Canonical program bucket: Commercial|Medicare|Medi-Cal|..."
  • is_from_latest_doc: "TRUE if from the most recent document for this provider"
  • content_text: "Full text content of the clause, section, or definition"
```


---

## 4. Data Flow Analysis

### 4.1 Data Volume Progression

| Stage | Records | Volume | Format | Storage |
|-------|---------|--------|--------|---------|
| Raw PDFs | 10,372 files | 27.3 GB | PDF (binary) | UC Volume (Azure Blob) |
| Prefetch Cache | 10,372 files | 27.3 GB | PDF (binary) | Local NVMe SSD |
| OCR Output | 10,372 rows | ~8 GB text | Parquet (checkpoint) | Workspace filesystem |
| JSON Extractions | 3,519 files | ~2.5 GB | JSON | Workspace filesystem |
| Rate Tables | 39,549 rows | ~50 MB | Delta | dev_adb.raw |
| Terms Tables | 45,718 rows | ~200 MB | Delta | dev_adb.raw |
| Legal Units | 83,008 rows | ~500 MB | Delta | dev_adb.raw |
| Genie Tables | ~55K rows total | ~100 MB | Delta | dev_adb.raw |
| VS Index | 83,008 vectors | ~1 GB | Vector Index | Databricks VS |

### 4.2 Data Quality Gates

```
  PDF Input → [Gate 1: Size > 0 bytes] → OCR
                                           │
  OCR Output → [Gate 2: text_length >= 500 chars] → LLM Extraction
                                                      │
  LLM Output → [Gate 3: Valid JSON + required sections] → Validation
                                                            │
  Validation → [Gate 4: v6_coverage_pct scoring] → Table Build
                 │                                      │
                 └── [Quarantine: critical failures] ──→ gap_filler (re-extract)
                                                            │
  Table Build → [Gate 5: Version deduplication] → Genie Layer
                                                      │
  Genie Layer → [Gate 6: NULL sentinel safety] → Serving
```

### 4.3 Checkpoint Strategy

| Checkpoint | File | Purpose | Recovery |
|------------|------|---------|----------|
| File Registry | `file_registry_v2.parquet` | Avoid re-scanning 597 folders | Stale check vs actual count |
| OCR Results | `step1_parsed_v2.parquet` | Skip already-parsed PDFs | Incremental append |
| Metadata | `step2_with_metadata_v2.parquet` | Parsed filename fields | Full rebuild from step1 |
| Extraction Scores | `extraction_scores.parquet` | Track quality scores | Used for re-extraction decisions |
| Progress | `_progress.json` | Real-time monitoring | External consumers can poll |
| JSON per file | `json_extract/{name}.json` | Per-file extraction | Individual re-extraction |

---

## 5. Stage-by-Stage Deep Dive

### 5.1 Stage: File Discovery (01_file_discovery)

| Attribute | Detail |
|-----------|--------|
| **Purpose** | Scan UC Volume, build file registry, prefetch to local SSD, select files for processing |
| **Inputs** | `/Volumes/prod_adb/default/ext-data-volume-stmlz/Health_Plan_Ops_Transformation/Provider_Contracts` |
| **Outputs** | `file_registry` dict (in-memory), `valid_files` list, `file_registry_v2.parquet` |
| **Technologies** | Python `os.walk()`, Pandas Parquet, `shutil.copy2`, `ThreadPoolExecutor(32)` |
| **Dependencies** | UC Volume mounted and accessible, local NVMe disk available |
| **Scaling** | 32-thread parallel copy; linear with file count; 27GB takes ~5-10min |
| **Failure Scenarios** | Volume unmounted, disk full, permission denied |
| **Retry Logic** | Stale cache detection (compare cached count vs actual); error-tolerant copy |
| **Observability** | Progress logging every 1000 files; `pipe_log` structured logging |
| **Logging** | `pipe_log.info()` with file counts and timing |
| **Governance** | Source data stays in prod_adb Volume; processing in dev_adb schema |
| **Optimization** | Could use Delta Sharing or mount point; NVMe prefetch is optimal for single-node |

### 5.2 Stage: OCR Extraction (02_ocr_extraction)

| Attribute | Detail |
|-----------|--------|
| **Purpose** | Extract text from PDFs using 2-tier strategy (free → paid fallback) |
| **Inputs** | `file_registry` (in-memory), PDF files on local SSD |
| **Outputs** | `step1_parsed_v2.parquet` (full_text, num_pages, extraction_method per file) |
| **Technologies** | pypdf (Tier 1, 14 ProcessPoolExecutor workers), `ai_parse_document` (Tier 2, Spark SQL) |
| **Dependencies** | pypdf installed; Databricks SQL runtime for ai_parse_document |
| **Scaling** | Tier 1: 14 CPU processes (GIL-free); Tier 2: 20 Spark partitions; ~82%/18% split |
| **Failure Scenarios** | Encrypted PDFs (handled), corrupted files (empty result), timeout (30s limit) |
| **Retry Logic** | Tier 1 failures automatically fall through to Tier 2; no explicit retry |
| **Observability** | Progress every 500 files; tier split reporting; timeout counting |
| **Logging** | `pipe_log.info()` with extraction method stats |
| **Governance** | Text stored transiently in Parquet checkpoint (not materialized to Delta) |
| **Optimization** | pytesseract removed (150+ hrs → ai_parse_document minutes); ProcessPoolExecutor vs threads (5.1x speedup) |

### 5.3 Stage: LLM Extraction (05_llm_extraction)

| Attribute | Detail |
|-----------|--------|
| **Purpose** | Convert unstructured PDF text into V6 Delta-ready structured JSON using Claude Sonnet 4.5 |
| **Inputs** | `step2_with_metadata_v2.parquet` (text + metadata), 4 prompt templates |
| **Outputs** | `json_extract/{filename}.json` (one per PDF, V6 schema) |
| **Technologies** | Claude Sonnet 4.5 via REST API (not Spark SQL), ThreadPoolExecutor(3), AdaptiveConcurrency |
| **Dependencies** | Databricks Model Serving endpoint `databricks-claude-sonnet-4-5` |
| **Scaling** | 3 concurrent workers; adaptive throttling on 429s; 24h time budget |
| **Failure Scenarios** | Rate limiting (429), timeout (1800s), truncated output, malformed JSON |
| **Retry Logic** | 1 retry with 30s backoff; JSON repair for truncated output; re-extract on low scores |
| **Observability** | `_progress.json` real-time file; AdaptiveConcurrency state logging |
| **Logging** | Per-file: tokens, duration, errors; aggregate: success rate, throughput |
| **Governance** | PII stays in source text → extracted to structured fields in dev_adb |
| **Optimization** | REST API vs Spark SQL (10+ hr → 93 min for 133 files); chunking at 150K chars; max_tokens 65536 |

**Critical Design Decision**: REST API instead of `ai_query()`.
- `ai_query()` via Spark SQL caused 10+ hour stalls due to batch-level cascade failures
- Direct REST API with per-file HTTP timeout (1800s) isolates failures
- ThreadPoolExecutor(3) with adaptive concurrency handles rate limiting gracefully
- This is the single most important architectural decision in the pipeline

### 5.4 Stage: Validation (06_validation)

| Attribute | Detail |
|-----------|--------|
| **Purpose** | Verify extraction quality, detect hallucinations, enrich with derived fields |
| **Inputs** | `json_extract/*.json`, source text from step1/step2 parquet |
| **Outputs** | Enriched JSON files (validation key added in-place), quality report |
| **Technologies** | Python regex, fuzzy string matching, OCR-aware rate verification |
| **Dependencies** | json_extract files exist; source text available for cross-reference |
| **Scaling** | Sequential per-file; ~50 files/second; 3,519 files in ~70s |
| **Failure Scenarios** | Corrupt JSON (skip), missing source text (skip verification) |
| **Retry Logic** | Checkpoint-aware (skips files already at v6.2b); idempotent |
| **Observability** | Progress every 50 files; aggregate stats; exit code (0/1/2) |
| **Logging** | Per-file validation stats; aggregate pipeline quality report |
| **Governance** | Hallucination detection prevents fabricated data from reaching tables |
| **Optimization** | OCR-aware fuzzy matching (76% → 30% unverified rates); rate_numeric post-processor (63% → 95%) |

### 5.5 Stage: Table Build — Rates (08_build_rates)

| Attribute | Detail |
|-----------|--------|
| **Purpose** | Build 3 core rate tables directly from JSON files (zero table dependencies) |
| **Inputs** | `json_extract/*.json` (inpatient_rates, outpatient_rates, capitation, stop_loss, regional) |
| **Outputs** | `tbl_contract_rates_all` (39K), `tbl_contract_regional_factors` (5.7K), `tbl_contract_financial_protections` (2K) |
| **Technologies** | Python + Pandas for JSON parsing; PySpark for Delta write; SQL for post-fix |
| **Dependencies** | None (reads directly from JSON files) |
| **Scaling** | Reads all JSONs into memory (~2.5 GB); pandas DataFrame assembly; one Spark write |
| **Failure Scenarios** | OOM on driver (unlikely at 3.5K files); schema mismatch (handled by safe_str) |
| **Retry Logic** | Full rebuild each time (CREATE OR REPLACE TABLE) |
| **Observability** | Row count reporting; timing |
| **Logging** | Step-level print statements |
| **Governance** | Schema enforced on write; rate_numeric validated; is_valid_rate flag |
| **Optimization** | Version deduplication before table build; post-fix runs as single SQL overwrite |

### 5.6 Stage: Genie Layer (12_build_genie)

| Attribute | Detail |
|-----------|--------|
| **Purpose** | Build 4 AI-optimized tables with pre-joins, deduplication, and 67 column comments |
| **Inputs** | 8 base tables + dim_provider_canonical |
| **Outputs** | tbl_genie_provider_profile, tbl_genie_rates_current, vw_genie_contract_terms, tbl_genie_amendment_timeline |
| **Technologies** | Spark SQL (complex CTEs, window functions), COMMENT DDL |
| **Dependencies** | All base tables (08-11) must be built first |
| **Scaling** | SQL execution on Spark cluster; queries are <100s each |
| **Failure Scenarios** | Missing base table (fails with clear error); schema drift |
| **Retry Logic** | Full rebuild (CREATE OR REPLACE); idempotent |
| **Observability** | Row counts per table; dedup quality metrics; timing |
| **Logging** | Detailed per-table progress; dedup improvement metrics |
| **Governance** | 67 column comments (100% coverage); table-level comments; sentinel-safe NULLs |
| **Optimization** | V8 dedup fix (27.6% → 1.3% residual duplicates); rate_numeric partition key |

### 5.7 Stage: State Engine (platform/02_state_engine)

| Attribute | Detail |
|-----------|--------|
| **Purpose** | Build contract and amendment registries with deterministic state computation |
| **Inputs** | `tbl_contract_documents_master` (from extraction layer) |
| **Outputs** | `tbl_v2_contract_registry` (1,948), `tbl_v2_amendment_registry` (1,570) |
| **Technologies** | Spark SQL, INSERT OVERWRITE (atomic), MAX_BY for deterministic tie-breaking |
| **Dependencies** | 01_execute_ddl.py (tables must exist), extraction layer complete |
| **Scaling** | Single INSERT OVERWRITE per table; sub-minute execution |
| **Failure Scenarios** | Source table missing; schema mismatch post DDL change |
| **Retry Logic** | INSERT OVERWRITE is idempotent; safe to re-run |
| **Observability** | `log_step()` with SUCCESS/FAILED status |
| **Logging** | Structured logging with timestamps |
| **Governance** | Scope classification (FULL_REPLACEMENT, TARGETED, TERM_EXTENSION); status FSM |
| **Optimization** | Replaced 3 correlated subqueries with single GROUP BY CTE (5,844 scans → 1 scan) |

### 5.8 Stage: Retrieval Engine (platform/05_retrieval_engine)

| Attribute | Detail |
|-----------|--------|
| **Purpose** | 4-channel hybrid retrieval with query understanding and Reciprocal Rank Fusion |
| **Inputs** | User query (natural language) |
| **Outputs** | `RetrievalResult` (scored chunks, confidence, should_refuse flag) |
| **Technologies** | Databricks Vector Search, Spark SQL, Claude (query understanding), RRF algorithm |
| **Dependencies** | VS endpoint running, idx_legal_units_v2 synced, tbl_retrieval_legal_units populated |
| **Scaling** | Per-query latency: ~2-5s; VS endpoint handles concurrent queries |
| **Failure Scenarios** | VS index not ready (cached 60s TTL check); LLM timeout for query understanding |
| **Retry Logic** | VS readiness check with cache; graceful fallback if semantic channel unavailable |
| **Observability** | `tbl_retrieval_telemetry` captures per-query metrics |
| **Logging** | Channel-level scores, fusion results, confidence |
| **Governance** | should_refuse=True when evidence insufficient; prevents hallucinated answers |
| **Optimization** | P1-14: VS readiness verification with 60s TTL cache avoids repeated API calls |

### 5.9 Stage: Intelligence (platform/08_intelligence)

| Attribute | Detail |
|-----------|--------|
| **Purpose** | Compute negotiation intelligence: benchmarks and renewal priority |
| **Inputs** | `tbl_reimb_rate_rules`, `tbl_v2_contract_registry` |
| **Outputs** | `tbl_intel_benchmark_results` (1,399), `tbl_intel_renewal_priority` (1,478) |
| **Technologies** | Spark SQL, percentile_approx(), window functions, INSERT OVERWRITE |
| **Dependencies** | Reimbursement migration complete; contract registry populated |
| **Scaling** | Pure SQL aggregation; <30s execution |
| **Failure Scenarios** | Empty source tables (produces empty benchmarks) |
| **Retry Logic** | INSERT OVERWRITE (idempotent) |
| **Observability** | Row count output; computed_at timestamp in results |
| **Logging** | Step-level reporting |
| **Governance** | Source field tracks 'estimated' vs 'claims_weighted'; CDF enabled for auditing |
| **Optimization** | Trimmed to only real-data outputs; fabricated tables (spend, savings, leverage) removed pending claims feed |

---

## 6. Technology Assessment

### 6.1 Technology Stack

| Layer | Technology | Version/Model | Purpose |
|-------|-----------|---------------|---------|
| Compute | Databricks DBR 18.0 | Serverless | Notebook execution |
| Cloud | Azure | - | Infrastructure |
| Storage | Delta Lake | - | ACID tables, time travel |
| Catalog | Unity Catalog | - | Governance, lineage |
| LLM | Claude Sonnet 4.5 | databricks-claude-sonnet-4-5 | Extraction + query understanding |
| Embeddings | GTE-Large-EN | databricks-gte-large-en | Vector Search |
| Vector Search | Databricks VS | - | Semantic retrieval |
| OCR | pypdf + ai_parse_document | - | Text extraction |
| Orchestration | Manual / Notebook %run | - | Pipeline sequencing |
| NL Interface | Genie Space | - | Business user queries |
| Dashboard | Lakeview | - | Portfolio analytics |
| Monitoring | Custom telemetry table | - | Pipeline health |

### 6.2 Architecture Patterns Used

| Pattern | Implementation | Assessment |
|---------|---------------|------------|
| **Medallion Architecture** | Modified: Raw PDFs → JSON (Bronze) → Base Tables (Silver) → Genie Tables (Gold) | Appropriate; AI enrichment at Silver is justified |
| **Checkpoint-Resume** | Parquet checkpoints at each stage | Good for long-running LLM extraction |
| **Adaptive Concurrency** | Dynamic worker scaling on rate limits | Excellent for external API dependencies |
| **Document-Type Routing** | 4 specialized prompts per doc type | Improves extraction quality significantly |
| **Version Deduplication** | Keep highest version per document identity | Correct for amendment-heavy corpus |
| **Facility Canonicalization** | dim_provider_canonical maps IDs to facilities | Necessary for multi-ID providers |
| **Sentinel-Safe NULLs** | Genie tables replace NULLs with defaults | Required for Genie column-comment accuracy |
| **Rebuild Gate** | Skip processing if no new files | Good cost optimization for scheduled runs |

### 6.3 What's NOT Used (Notable Absences)

| Technology | Status | Impact |
|-----------|--------|--------|
| **Lakeflow Spark Declarative Pipelines** | Not used | No declarative ETL, no auto-retry, no data quality expectations |
| **Lakeflow Jobs** | Not configured | No automated scheduling; manual execution |
| **Structured Streaming** | Not used | Batch-only; acceptable for contract corpus |
| **Auto Loader** | Not used | Could simplify new-file detection |
| **Delta Live Tables Expectations** | Not used | Quality checks are custom Python |
| **MLflow** | Not used | No model tracking, no experiment logging |
| **Feature Store** | Not used | Intelligence features stored as raw tables |
| **Model Serving (custom)** | Not deployed | Reranker pending; retrieval runs in-notebook |



---

## 7. Architecture Decisions Analysis

### 7.1 Why This Architecture Was Chosen

The architecture reflects an **exploratory-to-production evolution** — it started as a data science exploration and grew into a platform. This is evident from:

1. **Notebook-first development**: All extraction logic lives in notebooks (not Python packages)
2. **Sequential numbering**: Clear development chronology (01→15, 00→11)
3. **Manual orchestration**: No job DAG — developers run notebooks in sequence
4. **Iterative schema evolution**: V1 → V2 → V6 → V8 fixes applied incrementally
5. **Mixed Python + SQL**: Heavy use of PySpark for data loading, SQL for transformations

**Justification**: For a first-of-its-kind AI extraction pipeline with unknown failure modes, the notebook-first approach was correct. It allowed rapid iteration, visual debugging, and easy re-runs of individual stages.

### 7.2 Batch vs Streaming Analysis

| Factor | Batch (Current) | Streaming (Alternative) | Verdict |
|--------|----------------|------------------------|---------|
| Source update frequency | Contracts change monthly/quarterly | No real-time feed | **Batch is correct** |
| Processing time tolerance | Hours acceptable | Minutes not needed | **Batch is correct** |
| LLM API pattern | Per-file REST calls | N/A for streaming | **Batch is correct** |
| Table rebuild pattern | Full rebuild (CREATE OR REPLACE) | Incremental merge | **Batch is simpler but wasteful** |
| New file detection | Checkpoint comparison | Auto Loader | **Auto Loader would be better** |
| Cost | Pay per notebook run | Continuous cluster cost | **Batch is cheaper** |

**Verdict**: Batch processing is the correct paradigm for this workload. The contract corpus updates infrequently, LLM extraction is inherently per-document, and cost optimization favors on-demand compute.

**However**: Auto Loader should replace the manual `os.walk()` scan for incremental file detection, and MERGE should replace CREATE OR REPLACE for table updates.

### 7.3 Delta Live Tables (SDP) Analysis

**Why SDP is NOT used:**
- The extraction pipeline requires Python logic (OCR, REST API calls, JSON parsing) that doesn't fit the declarative SQL/Python UDF model
- Adaptive concurrency and per-file retry logic needs imperative control flow
- Checkpoint files (Parquet on workspace filesystem) are non-standard DLT sources

**Where SDP WOULD add value:**
- Table build layer (08-13): Pure SQL transformations that read JSON/tables and write Delta
- Genie layer rebuild: Declarative definitions with data quality expectations
- Platform foundation (02-03): SQL-heavy registry population

**Recommendation**: Convert notebooks 08-13 + platform 02-03 into a SDP pipeline for the downstream transformation layer, while keeping extraction (01-06) as imperative notebooks.

### 7.4 Unity Catalog Assessment

**Current Usage (GOOD):**
- All tables in `dev_adb.raw` with proper catalog.schema.table naming
- Source PDFs in UC Volume (`prod_adb/default/ext-data-volume-stmlz`)
- Column comments (67) and table comments applied consistently
- Delta table properties set (CDF enabled, column mapping mode)

**Gaps:**
- Single schema (`dev_adb.raw`) for all layers — no medallion separation
- No row-level security or column masking on PII fields
- No tags for data classification
- No lifecycle management (no retention policies)
- `dev_adb` catalog suggests development — no prod catalog exists

**Recommendation**: 
- Separate schemas: `dev_adb.bronze` (raw extractions), `dev_adb.silver` (normalized tables), `dev_adb.gold` (Genie/serving)
- Add UC tags for PII columns (provider names, tax IDs)
- Create `prod_adb.gold` for production serving tables

### 7.5 Medallion Layering Assessment

**Current State**: Flat schema — everything in `dev_adb.raw`

```
CURRENT (Flat):
  dev_adb.raw.*  (all 30+ tables)

RECOMMENDED (Medallion):
  dev_adb.bronze.tbl_extraction_*     ← JSON-derived base tables
  dev_adb.silver.tbl_v2_*             ← Normalized registries + rate rules
  dev_adb.silver.tbl_reimb_*          ← Reimbursement engine
  dev_adb.silver.tbl_retrieval_*      ← Legal units + telemetry
  dev_adb.gold.tbl_genie_*            ← Serving tables
  dev_adb.gold.tbl_intel_*            ← Intelligence outputs
  dev_adb.gold.vw_genie_*             ← Serving views
  dev_adb.gold.dim_*                  ← Dimension tables
```

**Tradeoff**: The flat schema simplifies development (no cross-schema references) but sacrifices governance clarity and access control granularity.

### 7.6 Delta Optimization Assessment

**What's Done Well:**
- `delta.enableChangeDataFeed = true` on intelligence tables (audit trail)
- `delta.columnMapping.mode = name` (allows column renames/drops)
- INSERT OVERWRITE for atomic full-table refreshes (state engine)
- CREATE OR REPLACE TABLE for idempotent rebuilds

**What's Missing:**
- No OPTIMIZE / ZORDER configured (important for rate tables with provider_id filters)
- No liquid clustering defined
- No VACUUM schedule (tombstone file cleanup)
- No table statistics maintenance (ANALYZE TABLE)
- No bloom filters on high-cardinality text columns

**Recommendations:**
```sql
-- Rate tables: cluster by provider_id (most common filter)
ALTER TABLE tbl_contract_rates_all CLUSTER BY (provider_id);

-- Genie tables: cluster by provider_name (Genie query pattern)
ALTER TABLE tbl_genie_rates_current CLUSTER BY (provider_name);

-- Weekly OPTIMIZE + VACUUM
OPTIMIZE dev_adb.raw.tbl_contract_rates_all;
VACUUM dev_adb.raw.tbl_contract_rates_all RETAIN 168 HOURS;
```

### 7.7 Contract Amendment/Version Handling

**Current Strategy (Sophisticated):**

1. **File-level versioning**: Filename contains `_v{N}` suffix → keep highest version per identity
2. **Amendment ordering**: `amendment_order` computed from filename parsing
3. **Scope classification**: `FULL_REPLACEMENT`, `TARGETED`, `TERM_EXTENSION` types
4. **Rate supersession**: Scope-aware logic determines current vs superseded rates
5. **Document lineage**: `is_from_latest_doc` flag for temporal filtering

**Assessment**: This is one of the strongest architectural elements. The scope-aware supersession logic correctly handles the real-world complexity of provider contract amendments where:
- A FULL_REPLACEMENT supersedes all prior rates
- A TARGETED amendment only supersedes specific service lines
- A TERM_EXTENSION keeps all existing rates current

**Risk**: The logic depends on correct `amendment_order` parsing from filenames. If filenames don't follow the convention, ordering is incorrect.

### 7.8 AI Extraction Architecture

**Design Choices:**

| Decision | Choice | Rationale |
|----------|--------|-----------|
| LLM Model | Claude Sonnet 4.5 | Best performance on structured extraction from legal text |
| API Pattern | REST (not ai_query) | Isolation of per-file failures; 10+ hr → 93 min |
| Concurrency | 3 workers | Balance throughput vs rate limiting |
| Chunking | 80K chars per segment | Fit within 200K token context (with output budget) |
| Output format | JSON (V6 schema) | Structured, parseable, Delta-ready |
| Prompt design | 4 doc-type-specific | Higher quality than one-size-fits-all |
| Temperature | 0.0 | Deterministic, reproducible extractions |
| Max output | 65,536 tokens | Full clause text requires large output |
| JSON repair | Auto-close brackets | Handles truncation gracefully |

**Strengths:**
- Document-type routing (Base/Amendment/Cover Memo/Settlement) is excellent
- Adaptive concurrency handles rate limiting without manual intervention
- Chunking with overlap handles oversized documents
- JSON repair prevents data loss from output truncation

**Weaknesses:**
- No output caching (re-running re-extracts even unchanged files)
- No incremental extraction (can't extract specific sections)
- No multi-model fallback (if Claude is down, pipeline stops)
- No cost tracking per extraction (token usage recorded but not aggregated)

### 7.9 Structured Extraction Methods

**V6 Schema Design:**

```json
{
  "contract_overview": { ... },      // Core metadata
  "parties": { ... },                // Health plan + provider
  "signatories": [ ... ],            // Named signers
  "sections": [ ... ],               // Document structure
  "financial_terms": { ... },        // Payment details
  "inpatient_rates": [ ... ],        // Rate rows (rate_numeric + context)
  "outpatient_rates": [ ... ],       // Rate rows
  "capitation_table": [ ... ],       // Capitation rates
  "covered_services": { ... },       // Service scope
  "stop_loss_reinsurance": { ... },  // Financial protections
  "termination": { ... },            // Exit provisions
  "compliance_and_regulatory": { ... },
  "dispute_resolution": { ... },
  "quality_and_performance": { ... },
  "confidentiality_and_records": { ... },
  "amendments_impact": { ... },       // V6 Change C: supersession
  "settlement_terms": { ... }         // Settlement-specific
}
```

**Key V6 Innovations:**
- `rate_numeric` on every rate row (eliminates post-hoc parsing for 63% → 95%)
- `full_clause_text` for clauses (37% present — needs improvement)
- `amendments_impact` for supersession tracking (98% present)
- Context fields alongside rates (for audit trail)

### 7.10 Semantic Serving Layer

**Architecture:**

```
  tbl_retrieval_legal_units (83K units)
        │
        ├── Vector Search Index (GTE-Large embeddings, 1024 dim)
        │   └── Semantic channel: cosine similarity
        │
        ├── Lexical search (ILIKE/RLIKE on unit_text)
        │   └── Lexical channel: keyword matching
        │
        ├── Metadata queries (direct SQL on rate_rules)
        │   └── Metadata channel: structured lookup
        │
        └── Section expansion (related units by section_type)
            └── Structural channel: contextual broadening
                    │
                    ▼
            Reciprocal Rank Fusion (RRF)
                    │
                    ▼
            3-Stage Reranking
            ├── BM25 re-score
            ├── Legal signal scoring (6 dimensions)
            └── Cross-encoder [PENDING: bge-reranker-v2-m3]
                    │
                    ▼
            Citation Verification (6 checks)
            ├── Source text confirmation
            ├── Date validation
            ├── Numeric validation
            ├── Scope validation
            ├── Contradiction detection
            └── Confidence scoring
                    │
                    ▼
            Grounded Answer (with citations + confidence)
```

### 7.11 Alternative Architectures Considered

| Alternative | Pros | Cons | Why Not Chosen |
|-------------|------|------|----------------|
| **Document Intelligence (Azure)** | Native PDF parsing, pre-built models | Less customizable, vendor lock-in, lower accuracy on complex contracts | Claude + custom prompts outperformed |
| **LangChain pipeline** | Framework support, composability | Overhead, debugging difficulty, version instability | Direct REST API is simpler and more reliable |
| **Spark UDF + ai_query()** | Distributed processing | Batch-level cascade failures; 10+ hour stalls | REST API with per-file isolation was 7x faster |
| **Document-per-table** | One table per contract | Too many tables; can't aggregate across providers | Columnar tables with join keys is correct |
| **Graph database** | Natural for contract relationships | Additional infrastructure; learning curve | Delta tables + SQL joins are sufficient |
| **Event-driven (Kafka)** | Real-time updates | Contracts don't arrive in real-time; over-engineering | Batch with checkpoints is simpler |

### 7.12 Where Complexity is Justified

1. **4-channel retrieval + RRF**: Justified — no single retrieval method handles all query types (rate lookups vs clause searches vs comparisons)
2. **Scope-aware supersession**: Justified — FULL_REPLACEMENT vs TARGETED amendments have fundamentally different semantics
3. **3-tier OCR (pypdf → ai_parse_document)**: Justified — 82% success rate on free tier saves significant cost
4. **Adaptive concurrency**: Justified — rate limiting is unpredictable and bursty
5. **V6 schema with doc-type prompts**: Justified — contract document types have genuinely different structures
6. **Citation verification (6 checks)**: Justified — hallucinated contract terms could have legal/financial consequences

### 7.13 Where Complexity is Unnecessary

1. **JSON file intermediary stage**: The workspace filesystem JSON files add complexity. These should be Delta tables directly.
2. **Version deduplication at read time**: Should be enforced at write time (during extraction) to avoid repeated computation.
3. **Separate V1 and V2 table sets**: The platform layer re-derives V2 from V1 — could consolidate.
4. **Custom telemetry buffering**: Should use Delta table streaming append instead of in-memory buffer + batch flush.
5. **Manual orchestration**: The sequential notebook chain is error-prone. A Lakeflow Job DAG would eliminate human coordination.
6. **Full table rebuilds**: CREATE OR REPLACE for tables that mostly don't change — MERGE would be more efficient.



---

## 8. Risk Heatmap & Failure Points

### 8.1 Risk Heatmap

```
                        LIKELIHOOD
                 Low          Medium         High
            ┌────────────┬────────────┬────────────┐
    High    │            │ LLM API    │ Manual     │
            │            │ downtime   │ orchestrtn │
            │            │ during run │ human error│
  IMPACT    ├────────────┼────────────┼────────────┤
    Med     │ VS index   │ Rate limit │ Schema     │
            │ corruption │ cascade    │ drift      │
            │            │ stalls     │ on updates │
            ├────────────┼────────────┼────────────┤
    Low     │ PDF corrupt│ Checkpoint │ Column     │
            │ (quarantin)│ stale      │ comment    │
            │            │            │ out of sync│
            └────────────┴────────────┴────────────┘
```

### 8.2 Critical Failure Points

| # | Failure Point | Probability | Impact | Mitigation (Current) | Mitigation (Recommended) |
|---|--------------|-------------|--------|----------------------|--------------------------|
| 1 | **LLM endpoint unavailable** | Medium | Critical — extraction stops entirely | None (manual re-run) | Multi-model fallback (Claude → GPT-4o → Llama) |
| 2 | **Rate limiting cascade** | Medium | High — hours of stalled processing | Adaptive concurrency, 30s backoff | Queue-based extraction with dead-letter |
| 3 | **Manual orchestration error** | High | High — wrong notebook run order | Numbered naming convention | Lakeflow Jobs DAG with dependencies |
| 4 | **Schema drift after extraction** | Medium | Medium — downstream tables break | Version in schema (v6.2b) | Schema registry + contract testing |
| 5 | **Workspace filesystem failure** | Low | Critical — JSON files lost | Checkpoint parquets + JSON per file | Store extractions in Delta table |
| 6 | **VS index sync failure** | Low | Medium — retrieval degraded | Cached readiness check (60s TTL) | Monitoring alert + auto-rebuild |
| 7 | **OOM on large corpus** | Medium | Medium — table build fails | Version dedup reduces count | Streaming/chunked table builds |
| 8 | **Hallucinated rates in tables** | Low | High — incorrect business decisions | Date/rate verification + quarantine | Human-in-the-loop for flagged extractions |
| 9 | **PII exposure** | Low | Critical — compliance violation | UC governance (schema-level) | Column masking + row filters on tax_id/NPI |
| 10 | **Single developer dependency** | High | High — knowledge loss, bus factor | README + 26 design docs | Runbook + cross-training + automated tests |

### 8.3 Failure Scenario Deep Dive

**Scenario A: LLM Extraction Fails Mid-Run (2,000 of 3,500 files processed)**

```
Current Recovery:
  1. Developer notices failure (manual check)
  2. Re-runs 05_llm_extraction notebook
  3. Checkpoint: existing JSONs detected → only remaining 1,500 processed
  4. Total recovery time: ~5-8 hours (including detection delay)

Recommended Recovery:
  1. Lakeflow Job detects task failure immediately
  2. Auto-retry with exponential backoff (3 attempts)
  3. If persistent: alert via email/Slack
  4. Dead-letter queue captures failed files for investigation
  5. Downstream tasks wait (dependency-aware)
  6. Total recovery time: <30 minutes (automated)
```

**Scenario B: Rate Table Has Incorrect Supersession Logic**

```
Current Recovery:
  1. Business user reports wrong rate in Genie Space
  2. Developer investigates amendment_order + scope_type
  3. Fixes logic in 08_build_rates post-fix cell
  4. Full table rebuild (CREATE OR REPLACE)
  5. Genie queries immediately reflect fix
  6. No historical tracking of the error

Recommended Recovery:
  1. Data quality expectation catches anomaly during build
  2. Alert triggers before data reaches Gold layer
  3. Fix applied to Silver → automatically propagates to Gold
  4. Delta time travel provides audit trail
  5. CDF captures before/after for regulatory compliance
```

---

## 9. Scalability Bottlenecks

### 9.1 Current Scale vs Target Scale

| Dimension | Current | Target (Full Corpus) | Growth Factor |
|-----------|---------|---------------------|---------------|
| PDFs Processed | 3,519 | 10,372 | 2.9x |
| JSON Files | 3,519 | 10,372 | 2.9x |
| Rate Rows | 39,549 | ~115,000 | 2.9x |
| Legal Units | 83,008 | ~240,000 | 2.9x |
| VS Index Vectors | 83,008 | ~240,000 | 2.9x |
| LLM Extraction Time | ~40 hrs | ~120 hrs | 2.9x |
| JSON in Memory | ~2.5 GB | ~7.5 GB | 2.9x |

### 9.2 Identified Bottlenecks

| # | Bottleneck | Current Impact | At Full Scale | Mitigation |
|---|-----------|---------------|---------------|------------|
| 1 | **LLM extraction throughput** | ~40 hrs for 3.5K files | ~120 hrs for 10K+ | Increase concurrency (5-10 workers); larger compute |
| 2 | **JSON files loaded into memory** | 2.5 GB (fits driver) | 7.5 GB (may OOM on standard) | Stream from Delta table or use Spark to read JSONs |
| 3 | **Full table rebuilds** | <2 min (39K rows) | ~5 min (115K rows) | MERGE for incremental updates |
| 4 | **VS index rebuild** | 83K vectors, ~10 min | 240K vectors, ~30 min | Incremental sync (supported by Databricks VS) |
| 5 | **Single-node OCR** | 14 processes, adequate | Same (NVMe SSD bounded) | Distribute across cluster with Spark UDFs |
| 6 | **Sequential notebook execution** | ~2 hrs total (post-extraction) | ~4 hrs | Parallelize independent stages (08, 09, 10 can run concurrently) |

### 9.3 Scalability Architecture (for 50K+ documents — future M&A scenario)

```
  Current: Single-threaded pipeline, single node
  ───────────────────────────────────────────────
  [Node 1]─── OCR → LLM → Build → Serve

  Recommended at 50K+: Distributed extraction with queue
  ──────────────────────────────────────────────────────
  [Queue (Delta table)] → [Worker Pool (5-10 jobs)]
         │                        │
         │                        ├── Worker 1: 1000 files
         │                        ├── Worker 2: 1000 files
         │                        ├── ...
         │                        └── Worker N: 1000 files
         │                                │
         ▼                                ▼
  [Dead Letter Table]        [Extraction Delta Table]
                                          │
                                          ▼
                             [Spark Job: Build Tables]
                                          │
                                          ▼
                             [VS Sync: Incremental]
```

---

## 10. Ideal Future State Architecture

### 10.1 Target Architecture (6-month horizon)

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│                   FUTURE STATE: PRODUCTION ARCHITECTURE                               │
│                                                                                       │
│  ┌─────────────────────────────────────────────────────────────────────────────────┐ │
│  │ INGESTION (Auto Loader + Lakeflow Job)                                          │ │
│  │                                                                                  │ │
│  │  [Auto Loader]          [OCR Cluster]        [Extraction Queue]                  │ │
│  │  New PDF detection  →   Distributed OCR  →   Delta table queue                   │ │
│  │  (cloudFiles source)    (multi-node)          (per-file status)                  │ │
│  └─────────────────────────────────────┬───────────────────────────────────────────┘ │
│                                         │                                             │
│  ┌─────────────────────────────────────▼───────────────────────────────────────────┐ │
│  │ EXTRACTION (Lakeflow Job — Multi-Task Fan-Out)                                  │ │
│  │                                                                                  │ │
│  │  [Task Fan-Out]         [LLM Workers (5-10)]      [Result Collector]             │ │
│  │  Partition by provider → Parallel REST API    →   MERGE into Delta               │ │
│  │                          Multi-model fallback      (bronze.extractions)           │ │
│  │                          Dead-letter on failure                                   │ │
│  └─────────────────────────────────────┬───────────────────────────────────────────┘ │
│                                         │                                             │
│  ┌─────────────────────────────────────▼───────────────────────────────────────────┐ │
│  │ TRANSFORMATION (SDP Pipeline — Declarative)                                     │ │
│  │                                                                                  │ │
│  │  [Bronze→Silver]              [Silver→Gold]          [Expectations]              │ │
│  │  Normalize + deduplicate  →   Genie tables       →   Data quality checks         │ │
│  │  State engine logic           + intelligence          per materialized view       │ │
│  │  Rate normalization           + serving tables                                   │ │
│  └─────────────────────────────────────┬───────────────────────────────────────────┘ │
│                                         │                                             │
│  ┌─────────────────────────────────────▼───────────────────────────────────────────┐ │
│  │ SERVING (Multi-Channel)                                                         │ │
│  │                                                                                  │ │
│  │  [Genie Space]    [Dashboard]    [Retrieval API]    [Intelligence API]           │ │
│  │  NL queries       Portfolio      Citation Q&A       Negotiation support          │ │
│  │                                                                                  │ │
│  │  [Model Serving]              [Monitoring]                                       │ │
│  │  Cross-encoder reranker       Golden query eval + alerting                       │ │
│  └─────────────────────────────────────────────────────────────────────────────────┘ │
│                                                                                       │
│  ┌─────────────────────────────────────────────────────────────────────────────────┐ │
│  │ GOVERNANCE & OBSERVABILITY                                                       │ │
│  │                                                                                  │ │
│  │  [UC Tags]           [Lineage]         [Alerts]          [Cost Dashboard]        │ │
│  │  PII classification  Auto-tracked      Quality failures  Per-provider cost        │ │
│  │  Column masking      End-to-end        LLM errors        Token burn rate          │ │
│  └─────────────────────────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────────────────────────────┘
```

### 10.2 Key Differences from Current State

| Dimension | Current State | Future State |
|-----------|--------------|--------------|
| Orchestration | Manual notebook chaining | Lakeflow Jobs DAG with dependencies |
| New file detection | os.walk() + checkpoint comparison | Auto Loader (cloudFiles) |
| Extraction storage | Workspace filesystem JSON files | Bronze Delta table (ACID, versioned) |
| Table updates | CREATE OR REPLACE (full rebuild) | MERGE (incremental) |
| Transformation | Imperative notebooks | SDP (declarative, auto-retry) |
| Quality checks | Custom Python (06_validation) | SDP Expectations (built-in) |
| Monitoring | Custom telemetry table | Lakehouse Monitoring + alerts |
| Multi-model | Claude only | Claude → GPT-4o → Llama fallback chain |
| Schema separation | Flat (dev_adb.raw) | Medallion (bronze/silver/gold) |
| Prod deployment | None (dev only) | CI/CD with Declarative Automation Bundles |
| Cost visibility | None | Per-provider extraction cost tracking |
| Reranker | Pending | Deployed on Model Serving |
| Claims integration | Feature flag = False | Connected, enables spend/savings/leverage |

---

## 11. Simplified Leadership View

### 11.1 Business Value Summary

```
┌─────────────────────────────────────────────────────────────────────────┐
│              PROVIDER CONTRACT INTELLIGENCE PLATFORM                      │
│                    — Executive Summary —                                  │
│                                                                          │
│  WHAT:  AI system that reads 10,000+ provider contracts and makes        │
│         their contents searchable, comparable, and actionable.           │
│                                                                          │
│  WHY:   • 80% faster contract analysis (days → hours)                   │
│         • Rate benchmarking across 348 providers                         │
│         • Automated renewal prioritization                               │
│         • Natural language access for non-technical staff                │
│                                                                          │
│  HOW:   PDF → AI Extraction → Structured Database → Genie Queries       │
│                                                                          │
│  STATUS: MVP Complete (34% corpus, 4 serving interfaces)                 │
│  NEXT:   Full corpus processing + claims integration + production        │
│                                                                          │
│  RISK:   Manual operation; single developer; no automated scheduling     │
│  ASK:    Lakeflow Job automation + cross-training + claims data feed     │
└─────────────────────────────────────────────────────────────────────────┘
```

### 11.2 Capability Maturity

```
  ┌────────────────────────┬─────────┬─────────┬─────────┬─────────┐
  │ Capability             │ Level 1 │ Level 2 │ Level 3 │ Level 4 │
  │                        │ Initial │ Managed │Optimized│ Leading │
  ├────────────────────────┼─────────┼─────────┼─────────┼─────────┤
  │ Contract extraction    │         │         │   ██    │         │
  │ Rate benchmarking      │         │    ██   │         │         │
  │ NL query access        │         │         │   ██    │         │
  │ Amendment tracking     │         │         │   ██    │         │
  │ Renewal prioritization │         │    ██   │         │         │
  │ Negotiation support    │    ██   │         │         │         │
  │ Claims-based analytics │ (pending)        │         │         │
  │ Production automation  │    ██   │         │         │         │
  │ Cost management        │    ██   │         │         │         │
  └────────────────────────┴─────────┴─────────┴─────────┴─────────┘
```

---

## 12. Technical Architecture View (for Engineers)

### 12.1 Component Interaction Diagram

```
┌──────────────────────────────────────────────────────────────────────────────────┐
│ COMPUTE LAYER                                                                     │
│                                                                                   │
│  ┌─────────────┐   ┌──────────────┐   ┌───────────────┐   ┌──────────────────┐ │
│  │ Serverless  │   │ ProcessPool  │   │ ThreadPool    │   │ Spark SQL        │ │
│  │ Notebook    │   │ Executor(14) │   │ Executor(3)   │   │ Engine           │ │
│  │ Driver      │   │ (OCR tier 1) │   │ (LLM REST)    │   │ (Table builds)   │ │
│  └──────┬──────┘   └──────┬───────┘   └──────┬────────┘   └───────┬──────────┘ │
│         │                  │                   │                     │            │
│         └──────────────────┴───────────────────┴─────────────────────┘            │
└─────────────────────────────────────────────┬────────────────────────────────────┘
                                              │
┌─────────────────────────────────────────────▼────────────────────────────────────┐
│ STORAGE LAYER                                                                     │
│                                                                                   │
│  ┌───────────────────┐  ┌───────────────────┐  ┌─────────────────────────────┐  │
│  │ UC Volume          │  │ Workspace FS      │  │ Delta Lake (dev_adb.raw)    │  │
│  │ (prod_adb)        │  │ (data/)           │  │                             │  │
│  │                    │  │                    │  │ 30+ tables                  │  │
│  │ 10,372 PDFs       │  │ json_extract/      │  │ CDF enabled                 │  │
│  │ 27.3 GB           │  │ checkpoints/       │  │ Column mapping = name       │  │
│  │                    │  │ 3,519 JSON files   │  │                             │  │
│  └───────────────────┘  └───────────────────┘  └─────────────────────────────┘  │
│                                                                                   │
│  ┌───────────────────┐  ┌───────────────────┐  ┌─────────────────────────────┐  │
│  │ Local NVMe SSD    │  │ Vector Search     │  │ Model Serving               │  │
│  │ /local_disk0/tmp  │  │ Endpoint          │  │                             │  │
│  │                    │  │                    │  │ Claude Sonnet 4.5           │  │
│  │ PDF prefetch      │  │ idx_legal_units_v2│  │ GTE-Large-EN                │  │
│  │ (ephemeral)       │  │ 83K vectors       │  │ [Future: bge-reranker]      │  │
│  └───────────────────┘  └───────────────────┘  └─────────────────────────────┘  │
└──────────────────────────────────────────────────────────────────────────────────┘
```

### 12.2 Key Technical Specifications

| Spec | Value | Notes |
|------|-------|-------|
| Max file size handled | 270K chars (~78K tokens) | Covers all corpus files |
| Chunking threshold | 150K chars | Above this: split into 80K segments |
| Chunk overlap | 2,000 chars | Prevents context loss at boundaries |
| LLM temperature | 0.0 | Deterministic extractions |
| LLM max output tokens | 65,536 | V6 full_clause_text needs large output |
| Per-file timeout | 1,800s (30 min) | Handles largest files |
| REST concurrency | 3 (adaptive) | Scales down on 429, up on success |
| OCR concurrency (Tier 1) | 14 processes | Matches CPU cores |
| OCR timeout | 30s internal per page | Bails out gracefully |
| Prefetch concurrency | 32 threads | I/O bound; threads appropriate |
| Embedding model | GTE-Large-EN (1024 dim) | Best balance of quality/speed |
| VS similarity | Cosine | Standard for text embeddings |
| RRF k parameter | 60 (standard) | Balances early and late results |
| Golden queries | 20 | Evaluation harness coverage |

### 12.3 Error Handling Matrix

| Error Type | Detection | Response | Recovery |
|-----------|-----------|----------|----------|
| Encrypted PDF | pypdf raises exception | Log + empty result | Tier 2 won't help; quarantine |
| OCR timeout (30s) | Internal timer check | Return partial text | Tier 2 fallback |
| LLM rate limit (429) | HTTP status code | Adaptive throttle + backoff | Auto-ramp after cooldown |
| LLM timeout (1800s) | HTTP timeout | Log error, mark failed | 1 retry with 30s backoff |
| Truncated JSON | output_tokens == max_tokens | `_repair_truncated_json()` | Auto-close brackets |
| Invalid JSON | json.loads() fails | Log + skip | Re-extract via gap_filler |
| Missing required sections | validate_extraction() | Score reduction | Flag but don't quarantine |
| Hallucinated date | Not found in source text | `unverified_dates` count | Flag for human review |
| Schema mismatch | Spark write error | Exception raised | Fix schema, re-run |
| VS index not ready | Readiness check (60s cache) | Skip semantic channel | Graceful degradation |

---

## 13. Business Capability Mapping

### 13.1 Business Capabilities Enabled

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    BUSINESS CAPABILITY MAP                                    │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  STRATEGIC PLANNING                    │  OPERATIONAL EFFICIENCY             │
│  ────────────────────                  │  ──────────────────────             │
│  • Rate benchmarking (P10-P90)         │  • NL contract queries (Genie)     │
│  • Renewal prioritization              │  • Portfolio dashboard              │
│  • [Future] Savings opportunity        │  • Amendment tracking               │
│  • [Future] Leverage analysis          │  • Document search                  │
│                                        │                                     │
│  RISK MANAGEMENT                       │  COMPLIANCE & AUDIT                 │
│  ────────────────                      │  ────────────────────               │
│  • Stop-loss tracking                  │  • Full clause text retrieval       │
│  • Contract expiry alerts              │  • Citation-grounded answers        │
│  • Financial protection analysis       │  • Source document traceability     │
│  • [Future] Termination scenarios      │  • Amendment chain audit trail      │
│                                        │                                     │
│  NEGOTIATION SUPPORT                   │  DATA FOUNDATION                    │
│  ───────────────────                   │  ────────────────                   │
│  • Provider comparison                 │  • 348 provider profiles            │
│  • Rate history/trends                 │  • 21K reimbursement rules          │
│  • What-if simulations                 │  • 83K searchable legal units       │
│  • [Future] Leverage scoring           │  • 39K rate line items              │
│                                        │                                     │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 13.2 User Personas Served

| Persona | Interface | Primary Use Cases |
|---------|-----------|-------------------|
| **Contract Analyst** | Genie Space | "What's the per diem rate for Provider X?", "Show amendments for Provider Y" |
| **Director, Provider Relations** | Dashboard | Portfolio overview, renewal pipeline, rate distributions |
| **VP, Provider Contracting** | Dashboard + Intelligence | Benchmarking, savings opportunities, strategic priorities |
| **Legal/Compliance** | Retrieval Engine | "Does Provider X have an anti-assignment clause?", citation-grounded |
| **Finance** | Genie Space + Intelligence | Stop-loss analysis, capitation summaries, budget scenarios |
| **Data Engineering** | Platform modules | Pipeline maintenance, quality monitoring, evaluation harness |

---

## 14. Critical Dependencies

### 14.1 Dependency Map

```
                    EXTERNAL DEPENDENCIES
  ┌──────────────────────────────────────────────────────────────┐
  │                                                              │
  │  ┌─────────────────┐        ┌─────────────────────────────┐│
  │  │ Claude Sonnet 4.5│        │ Azure Blob Storage           ││
  │  │ (Model Serving)  │        │ (UC Volume backend)          ││
  │  │                  │        │                              ││
  │  │ RISK: Single LLM │        │ RISK: Volume unmount         ││
  │  │ No fallback      │        │ MITIGATION: Local prefetch  ││
  │  └────────┬─────────┘        └──────────────┬──────────────┘│
  │           │                                  │              │
  │  ┌────────▼─────────┐        ┌──────────────▼──────────────┐│
  │  │ GTE-Large-EN     │        │ Vector Search Endpoint       ││
  │  │ (Embedding model)│        │ (contract_intelligence_vs)   ││
  │  │                  │        │                              ││
  │  │ RISK: Model update│       │ RISK: Index sync failure     ││
  │  │ changes vectors   │       │ MITIGATION: Readiness check  ││
  │  └──────────────────┘        └──────────────────────────────┘│
  │                                                              │
  │  ┌─────────────────────────────────────────────────────────┐│
  │  │ [FUTURE] Enterprise Claims Warehouse                     ││
  │  │ • Enables: spend summaries, savings, leverage            ││
  │  │ • Feature flag: CLAIMS_AVAILABLE = False                 ││
  │  │ • RISK: Unknown schema, data quality, refresh frequency  ││
  │  └─────────────────────────────────────────────────────────┘│
  └──────────────────────────────────────────────────────────────┘
```

### 14.2 Internal Dependencies

| Dependency | Provider | Consumer | Failure Impact |
|-----------|----------|----------|----------------|
| `_config` notebook | extraction/ | All 15 notebooks | Total pipeline failure |
| `file_registry_v2.parquet` | 01_file_discovery | 02_ocr_extraction | Cannot proceed |
| `step1_parsed_v2.parquet` | 02_ocr_extraction | 03_metadata_parsing | Cannot extract |
| `step2_with_metadata_v2.parquet` | 03_metadata_parsing | 05_llm_extraction | Cannot extract |
| `json_extract/*.json` | 05_llm_extraction | 06_validation, 08-13 | No tables built |
| `tbl_contract_documents_master` | 10_build_documents | 02_state_engine, 11_enrich | Foundation breaks |
| `dim_provider_canonical` | 11_enrich_tables | 12_build_genie | Genie tables wrong |
| `tbl_contract_rates_all` | 08_build_rates | 12_build_genie, 03_reimbursement | Missing rates |
| `tbl_contract_terms_vs_ready` | 13_build_serving | 04_legal_chunking | No retrieval |
| `tbl_reimb_rate_rules` | 03_reimbursement | 08_intelligence | No benchmarks |

### 14.3 Dependency Risk Assessment

| Dependency | Substitutability | Blast Radius | Recovery Time |
|-----------|-----------------|--------------|---------------|
| Claude Sonnet 4.5 | Low (prompt engineering locked in) | 100% extraction | Hours (retune prompts) |
| Databricks VS | Low (no alternative in platform) | Retrieval only | Minutes (re-sync) |
| UC Volume access | None | 100% ingestion | Minutes (IAM fix) |
| pypdf | High (ai_parse_document fallback) | Cost increase only | Immediate |
| NVMe SSD | Medium (can skip prefetch) | 5x slower OCR | None (degrade) |
| Workspace filesystem | Low (JSON storage) | Extraction data loss | Hours (re-extract) |



---

## 15. Cost Optimization Recommendations

### 15.1 Current Cost Profile (Estimated)

| Cost Category | Monthly Estimate | % of Total | Notes |
|--------------|-----------------|------------|-------|
| LLM Tokens (Claude) | $3,000-5,000 | 45-55% | ~500M tokens for full corpus extraction |
| Compute (Serverless) | $1,500-2,500 | 25-30% | Notebook execution, table builds |
| Vector Search Endpoint | $400-600 | 8-10% | Always-on endpoint |
| Storage (Delta + Volume) | $200-300 | 4-5% | ~30 GB Delta + 27 GB PDF |
| ai_parse_document (Tier 2 OCR) | $300-500 | 5-8% | ~18% of files use paid OCR |
| **Total (extraction phase)** | **$5,400-8,900** | **100%** | One-time for full corpus |
| **Total (steady state/month)** | **$600-1,000** | - | Incremental updates only |

### 15.2 Cost Optimization Strategies

| # | Strategy | Savings Estimate | Effort | Risk |
|---|---------|-----------------|--------|------|
| 1 | **Tiered LLM extraction** | 30-40% LLM cost | Medium | Lower quality for simple docs |
|   | Use cheaper model (Llama 3.1 70B) for simple amendments, Claude for complex base agreements | | | |
| 2 | **Skip re-extraction of unchanged files** | 50%+ on re-runs | Low | None (already partially done) |
|   | Store content hash → only re-extract if PDF content changed | | | |
| 3 | **Reduce output token budget** | 15-20% LLM cost | Low | Truncation for long docs |
|   | 65K max_tokens → 32K for amendments (they're shorter); keep 65K for base only | | | |
| 4 | **Batch table builds** | 20% compute cost | Low | None |
|   | Run 08-11 in parallel (no dependencies between them) | | | |
| 5 | **VS endpoint auto-scaling** | 30% VS cost | Low | Cold start latency |
|   | Scale to 0 when not in use; scale up on query | | | |
| 6 | **Replace full rebuilds with MERGE** | 40% compute on updates | Medium | Merge logic complexity |
|   | Only update rows that changed (based on source_filename hash) | | | |
| 7 | **Optimize prompt length** | 10-15% LLM cost | Low | None if prompts stay effective |
|   | Current prompts include full schema template (~700 tokens); compress to key fields only | | | |
| 8 | **Local embedding cache** | 20% embedding cost | Medium | Stale cache risk |
|   | Cache VS queries for repeated questions (retrieval engine) | | | |

### 15.3 Token Budget Analysis

| Document Type | Count | Avg Input Tokens | Avg Output Tokens | Total Tokens | Cost @ $3/M input, $15/M output |
|--------------|-------|-----------------|------------------|--------------|------|
| Base Agreements | 3,304 | ~25,000 | ~20,000 | ~150M | ~$5,000 |
| Amendments | 6,754 | ~8,000 | ~8,000 | ~108M | ~$2,800 |
| Cover Memos | ~500 | ~3,000 | ~3,000 | ~3M | ~$100 |
| Settlements | 93 | ~15,000 | ~12,000 | ~2.5M | ~$90 |
| **Total** | **10,372** | - | - | **~263M** | **~$8,000** |

**Optimization opportunity**: Amendments at 65% of volume but simpler → use cheaper model.

### 15.4 Compute Optimization

```
CURRENT:
  • Full corpus extraction: single notebook, single cluster, ~120 hrs
  • Table builds: sequential, ~2 hrs
  • Platform modules: sequential, ~30 min

OPTIMIZED:
  • Extraction: Fan-out to 5 parallel jobs (24 hrs each → 24 hrs total, 5x speedup)
  • Table builds: Parallel (08 || 09 || 10), then 11→12→13 (1 hr)
  • Platform: 02 || 03 parallel, then 04→05→06→07 (20 min)
  • Total time: 24 hrs extraction + 1.5 hrs transformation = 25.5 hrs
    vs current: 120 hrs + 2.5 hrs = 122.5 hrs
    → 4.8x improvement
```

---

## 16. Architecture Improvement Roadmap

### 16.1 Phase 1: Production Hardening (Month 1-2)

| # | Initiative | Priority | Effort | Impact |
|---|-----------|----------|--------|--------|
| 1.1 | Create Lakeflow Jobs DAG for extraction pipeline | P0 | 2 weeks | Eliminates manual orchestration; auto-retry on failure |
| 1.2 | Move JSON extractions to Delta table (bronze.extractions) | P0 | 1 week | ACID guarantees; no workspace filesystem dependency |
| 1.3 | Add Auto Loader for new PDF detection | P1 | 3 days | Automatic trigger on new files; no manual scans |
| 1.4 | Implement MERGE instead of CREATE OR REPLACE | P1 | 1 week | Incremental updates; faster steady-state runs |
| 1.5 | Add Delta OPTIMIZE + VACUUM schedule | P2 | 1 day | Storage efficiency; query performance |
| 1.6 | Configure liquid clustering on Genie tables | P2 | 1 day | Faster Genie queries (cluster by provider_name) |

### 16.2 Phase 2: Scalability & Resilience (Month 2-4)

| # | Initiative | Priority | Effort | Impact |
|---|-----------|----------|--------|--------|
| 2.1 | Process remaining 7K PDFs (full corpus) | P0 | 3 weeks | Complete data coverage |
| 2.2 | Multi-model fallback for extraction | P1 | 1 week | Resilience against Claude downtime |
| 2.3 | Fan-out extraction to parallel workers | P1 | 1 week | 5x throughput improvement |
| 2.4 | Convert table builds (08-13) to SDP pipeline | P1 | 2 weeks | Auto-retry, expectations, lineage |
| 2.5 | Deploy cross-encoder reranker on Model Serving | P2 | 3 days | Improved retrieval accuracy |
| 2.6 | Implement dead-letter queue for failed extractions | P2 | 3 days | No silent failures |

### 16.3 Phase 3: Intelligence & Integration (Month 4-6)

| # | Initiative | Priority | Effort | Impact |
|---|-----------|----------|--------|--------|
| 3.1 | Connect enterprise claims warehouse | P0 | 3 weeks | Enables spend/savings/leverage analytics |
| 3.2 | Build claims-weighted benchmarks | P1 | 1 week | More accurate than estimated benchmarks |
| 3.3 | Productionize leverage scoring | P1 | 1 week | Negotiation support for 348 providers |
| 3.4 | Build scenario simulation API | P2 | 2 weeks | Rate change impact analysis |
| 3.5 | Automated golden query monitoring | P2 | 1 week | Regression detection on data updates |
| 3.6 | Separate schemas (bronze/silver/gold) | P2 | 1 week | Governance clarity + access control |

### 16.4 Phase 4: Enterprise Scale (Month 6-12)

| # | Initiative | Priority | Effort | Impact |
|---|-----------|----------|--------|--------|
| 4.1 | Prod deployment (prod_adb catalog) | P0 | 2 weeks | Production readiness |
| 4.2 | CI/CD with Declarative Automation Bundles | P1 | 2 weeks | Automated deployment |
| 4.3 | UC tags + column masking for PII | P1 | 1 week | Compliance |
| 4.4 | Lakehouse Monitoring + alerting | P1 | 1 week | Proactive quality management |
| 4.5 | Cross-training documentation | P2 | 2 weeks | Reduce bus factor |
| 4.6 | Self-serve Genie Spaces (per business unit) | P2 | 1 week | Broader adoption |
| 4.7 | Real-time contract amendment processing | P3 | 4 weeks | Event-driven updates |

### 16.5 Roadmap Timeline

```
Month 1     Month 2     Month 3     Month 4     Month 5     Month 6
────────    ────────    ────────    ────────    ────────    ────────
[===P1: Production Hardening===]
  Jobs DAG ─┤
  Delta extractions ──┤
  Auto Loader ─┤
  MERGE ────────┤
            [========P2: Scalability========]
              Full corpus ─────────────────┤
              Multi-model ───┤
              Fan-out ───────┤
              SDP pipeline ──────────┤
              Reranker ──┤
                        [========P3: Intelligence========]
                          Claims connect ─────────────┤
                          Benchmarks v2 ──┤
                          Leverage ────────┤
                          Scenarios ────────────┤
                                            [====P4: Enterprise====→
                                              Prod deploy ─────┤
                                              CI/CD ───────────┤
                                              Tags/Masking ──┤
```

---

## Appendix A: Table Catalog

### A.1 Complete Table Inventory

| Table | Layer | Rows | Purpose | Key Columns |
|-------|-------|------|---------|-------------|
| tbl_contract_rates_all | Silver | 39,549 | All rate line items | provider_id, rate_category, rate_numeric, status |
| tbl_contract_regional_factors | Silver | 5,710 | Geographic adjustments | provider_id, county, factor |
| tbl_contract_financial_protections | Silver | 2,077 | Stop-loss, outliers | provider_id, threshold_numeric, has_stop_loss_bool |
| tbl_contract_terms_all | Silver | ~45K | Clauses and provisions | provider_id, content_text, topic |
| tbl_contract_clauses_all | Silver | ~3K | Full clause text | provider_id, clause_text |
| tbl_contract_documents_master | Silver | ~3.5K | Document metadata | provider_id, amendment_order, doc_category |
| tbl_contract_parties_all | Silver | ~7K | Contract parties | provider_id, party_name, party_type |
| tbl_contract_terms_vs_ready | Silver | ~69K | VS-optimized terms | provider_name, content_text, effective_date |
| dim_provider_canonical | Dimension | ~400 | Facility resolution | provider_id, canonical_name, is_primary_id |
| dim_service_line_taxonomy | Dimension | 50 | Service line categories | service_line_id, service_line_name |
| dim_service_line_patterns | Dimension | 45 | Regex classification | pattern, service_line_id |
| tbl_v2_contract_registry | Silver | 1,948 | Contract state machine | contract_id, provider_id, status, effective_from |
| tbl_v2_amendment_registry | Silver | 1,570 | Amendment classification | source_filename, scope_type, amendment_order |
| tbl_reimb_rate_rules | Silver | 21,074 | Normalized rate rules | rate_domain, service_line, formula_type, rate_numeric |
| tbl_reimb_stop_loss | Silver | 741 | Stop-loss provisions | provider_id, threshold, reimbursement_pct |
| tbl_reimb_lesser_of | Silver | 20 | Lesser-of rules | provider_id, comparison_basis |
| tbl_retrieval_legal_units | Silver | 83,008 | Chunked legal text | unit_id, unit_text, unit_type, provider_name |
| tbl_intel_benchmark_results | Gold | 1,399 | Rate percentiles | rate_domain, service_line, p10-p90 |
| tbl_intel_renewal_priority | Gold | 1,478 | Renewal scoring | contract_id, priority_score, recommended_action |
| tbl_genie_provider_profile | Gold | 271 | Provider summary | provider_name, total_rates, avg_inpatient_per_diem |
| tbl_genie_rates_current | Gold | 6,683 | Current rates (deduped) | provider_name, rate_numeric, program_normalized |
| vw_genie_contract_terms | Gold | 45,718 | Terms view | provider_name, content_text, is_from_latest_doc |
| tbl_genie_amendment_timeline | Gold | 2,254 | Amendment chain | provider_name, document_type, summary_of_changes |
| tbl_serving_capitation_card | Gold | ~200 | Capitation summary | age_gender_band, pmpm_rate |
| tbl_pipeline_telemetry | Ops | Variable | Pipeline observability | step, check, result, timestamp |
| tbl_retrieval_telemetry | Ops | Variable | Query metrics | query, channels, confidence, latency |
| tbl_eval_golden_queries | Ops | 20 | Evaluation harness | query, expected_answer, source_doc |

### A.2 Feature Flag Reference

| Flag | Current | Dependencies | Enables |
|------|---------|--------------|---------|
| CLAIMS_AVAILABLE | False | Claims warehouse connection | Spend, savings, leverage, weighted benchmarks |
| RERANKER_DEPLOYED | False | bge-reranker-v2-m3 on Model Serving | 3rd stage cross-encoder reranking |
| FULL_CORPUS_PROCESSED | False | Complete 10K PDF extraction | Full provider coverage |

---

## Appendix B: Glossary

| Term | Definition |
|------|-----------|
| **Amendment order** | Numeric position of a document in the amendment chain (0 = base agreement) |
| **Scope classification** | Whether an amendment replaces all terms (FULL_REPLACEMENT) or modifies specific items (TARGETED) |
| **Rate supersession** | Logic determining which rates are "current" vs "superseded" by later amendments |
| **Canonical name** | Deduplicated facility name (resolves multiple provider_ids to one facility) |
| **Legal unit** | Atomic chunk of contract text (definition, clause, rate entry, section) for retrieval |
| **RRF (Reciprocal Rank Fusion)** | Algorithm combining ranked lists from multiple retrieval channels |
| **Sentinel-safe** | NULL values replaced with meaningful defaults for Genie query accuracy |
| **V6 schema** | Sixth iteration of the JSON extraction schema (current production version) |
| **Golden queries** | Manually curated question-answer pairs for retrieval quality evaluation |
| **Rebuild gate** | Logic that skips expensive processing when no new files are detected |

---

## Appendix C: Architecture Decision Records (ADRs)

### ADR-001: REST API over ai_query() for LLM Extraction

**Status**: Accepted  
**Date**: May 2026  
**Context**: Spark SQL `ai_query()` caused 10+ hour stalls due to batch-level cascade timeouts.  
**Decision**: Use direct REST API calls via `requests.post()` to the serving endpoint.  
**Consequences**: 7x performance improvement (10+ hrs → 93 min for 133 files); per-file isolation; manual retry logic needed.

### ADR-002: Workspace Filesystem for JSON Storage

**Status**: Accepted (to be superseded)  
**Date**: April 2026  
**Context**: JSON files need per-file addressability for incremental extraction and validation.  
**Decision**: Store in workspace filesystem (`data/json_extract/`).  
**Consequences**: Simple file I/O; but no ACID, no versioning, no access control, workspace-bound.  
**Planned supersession**: Move to Delta table with one row per file (bronze.extractions).

### ADR-003: Single Schema (dev_adb.raw) for All Layers

**Status**: Accepted (to be superseded)  
**Date**: April 2026  
**Context**: Rapid prototyping required minimal infrastructure overhead.  
**Decision**: All tables in one schema.  
**Consequences**: Simple cross-references; but poor governance, no access control layers.  
**Planned supersession**: Medallion schema separation in Phase 3.

### ADR-004: ProcessPoolExecutor for pypdf OCR

**Status**: Accepted  
**Date**: May 2026  
**Context**: pypdf is pure Python; GIL makes ThreadPoolExecutor 0.9x (slower than sequential).  
**Decision**: Use ProcessPoolExecutor with 14 workers (matching CPU cores).  
**Consequences**: 5.1x speedup over sequential; each process has independent GIL.

### ADR-005: Four Document-Type-Specific Prompts

**Status**: Accepted  
**Date**: May 2026  
**Context**: A single prompt produced lower quality extraction for amendments and settlements.  
**Decision**: Four specialized prompts: Base Agreement, Amendment, Cover Memo, Settlement.  
**Consequences**: Higher extraction quality; maintenance of 4 prompt versions; routing logic needed.

### ADR-006: Column Comments for Genie Accuracy

**Status**: Accepted  
**Date**: May 2026  
**Context**: Genie Space generates better SQL when column semantics are explicit.  
**Decision**: Apply 67 column comments across all Genie-facing tables; sentinel-safe NULL handling.  
**Consequences**: 100% Genie coverage; maintenance overhead when schema changes.

---

*End of Architecture Review Document*

---
**Document Control**

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | May 2026 | Architecture Review | Initial comprehensive review |

