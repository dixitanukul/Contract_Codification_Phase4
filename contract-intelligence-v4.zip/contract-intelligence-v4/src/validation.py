"""Extraction validation for V6 schema outputs.

Validates LLM extraction JSON against expected schema:
- Required sections present
- Field types correct
- Dates in valid range
- rate_numeric within bounds
- No hallucinated structure
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
from datetime import date
import re


@dataclass
class ValidationResult:
    """Result of validating an extraction output."""
    valid: bool
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    sections_found: List[str] = field(default_factory=list)
    rates_count: int = 0
    rates_with_numeric: int = 0
    dates_count: int = 0
    dates_valid: int = 0


# V6 Schema: expected top-level sections by document type
EXPECTED_SECTIONS = {
    "base_agreement": [
        "contract_info", "parties", "term_dates", 
        "reimbursement_rates", "services_covered"
    ],
    "amendment": [
        "amendment_info", "effective_dates", 
        "rates_modified", "supersession"
    ],
    "cover_memo": [
        "memo_info", "referenced_documents", "key_dates"
    ],
    "settlement": [
        "settlement_info", "resolution_terms", "financial_terms"
    ],
}

# Reasonable date range for healthcare contracts
MIN_DATE = date(1990, 1, 1)
MAX_DATE = date(2035, 12, 31)

# Rate bounds (sanity check)
MAX_RATE_NUMERIC = 500_000  # No single per-diem/case rate should exceed $500K
MIN_RATE_NUMERIC = 0.0


def validate_extraction(data: dict, document_type: str = "base_agreement") -> ValidationResult:
    """Validate a V6 extraction JSON output.
    
    Args:
        data: Parsed extraction dictionary
        document_type: Expected document type for section validation
    
    Returns:
        ValidationResult with errors and warnings
    """
    result = ValidationResult(valid=True)
    
    if not data or not isinstance(data, dict):
        result.valid = False
        result.errors.append("Extraction output is empty or not a dictionary")
        return result
    
    # Check required sections
    expected = EXPECTED_SECTIONS.get(document_type, EXPECTED_SECTIONS["base_agreement"])
    for section in expected:
        if section in data:
            result.sections_found.append(section)
        else:
            # Check case-insensitive and underscore variants
            found = False
            for key in data.keys():
                if key.lower().replace('-', '_') == section.lower():
                    result.sections_found.append(key)
                    found = True
                    break
            if not found:
                result.warnings.append(f"Expected section '{section}' not found")
    
    # Validate rates if present
    rates = _find_rates(data)
    result.rates_count = len(rates)
    for rate in rates:
        if isinstance(rate, dict):
            rn = rate.get("rate_numeric")
            if rn is not None:
                result.rates_with_numeric += 1
                if not _validate_rate_numeric(rn, result):
                    pass  # error already added
    
    # Validate dates
    dates = _find_dates(data)
    result.dates_count = len(dates)
    for date_str in dates:
        if _validate_date(date_str):
            result.dates_valid += 1
        else:
            result.warnings.append(f"Potentially invalid date: {date_str}")
    
    # Critical validation: if no sections found at all, it's likely a hallucination
    if len(result.sections_found) == 0 and len(data) > 0:
        result.errors.append("No expected sections found — possible hallucinated structure")
        result.valid = False
    
    # If there are errors, mark invalid
    if result.errors:
        result.valid = False
    
    return result


def _find_rates(data: dict, _depth: int = 0) -> List[dict]:
    """Recursively find rate objects in extraction output."""
    if _depth > 10:  # Prevent infinite recursion
        return []
    
    rates = []
    for key, value in data.items():
        if 'rate' in key.lower() and isinstance(value, list):
            for item in value:
                if isinstance(item, dict) and ('rate_numeric' in item or 'rate_text' in item):
                    rates.append(item)
        elif isinstance(value, dict):
            rates.extend(_find_rates(value, _depth + 1))
        elif isinstance(value, list):
            for item in value:
                if isinstance(item, dict):
                    rates.extend(_find_rates(item, _depth + 1))
    return rates


def _find_dates(data: dict, _depth: int = 0) -> List[str]:
    """Recursively find date strings in extraction output."""
    if _depth > 10:
        return []
    
    dates = []
    date_pattern = re.compile(r'\d{4}-\d{2}-\d{2}|\d{1,2}/\d{1,2}/\d{2,4}')
    
    for key, value in data.items():
        if 'date' in key.lower() and isinstance(value, str):
            if date_pattern.search(value):
                dates.append(value)
        elif isinstance(value, dict):
            dates.extend(_find_dates(value, _depth + 1))
        elif isinstance(value, list):
            for item in value:
                if isinstance(item, dict):
                    dates.extend(_find_dates(item, _depth + 1))
    return dates


def _validate_rate_numeric(value: Any, result: ValidationResult) -> bool:
    """Validate a rate_numeric value is within reasonable bounds."""
    try:
        num = float(value)
    except (TypeError, ValueError):
        result.errors.append(f"rate_numeric not numeric: {value}")
        return False
    
    if num < MIN_RATE_NUMERIC:
        result.errors.append(f"rate_numeric negative: {num}")
        return False
    
    if num > MAX_RATE_NUMERIC:
        result.warnings.append(f"rate_numeric unusually high: {num} (possible 10x error)")
        # Warning only — some implant/transplant rates are legitimately high
    
    return True


def _validate_date(date_str: str) -> bool:
    """Check if a date string is within reasonable range for healthcare contracts."""
    # Try ISO format first
    match = re.match(r'(\d{4})-(\d{2})-(\d{2})', date_str)
    if match:
        try:
            d = date(int(match.group(1)), int(match.group(2)), int(match.group(3)))
            return MIN_DATE <= d <= MAX_DATE
        except ValueError:
            return False
    
    # Try US format M/D/YYYY
    match = re.match(r'(\d{1,2})/(\d{1,2})/(\d{4})', date_str)
    if match:
        try:
            d = date(int(match.group(3)), int(match.group(1)), int(match.group(2)))
            return MIN_DATE <= d <= MAX_DATE
        except ValueError:
            return False
    
    return False
