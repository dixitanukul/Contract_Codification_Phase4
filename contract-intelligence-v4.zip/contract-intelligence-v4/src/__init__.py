"""BSC Provider Contract Intelligence Platform — Core Library.

Pure-function modules extracted from pipeline notebooks for testability.
"""

__version__ = "6.0.0"
