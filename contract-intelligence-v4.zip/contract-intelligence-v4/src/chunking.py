"""Text chunking for large PDF extractions.

Splits documents exceeding LLM context window into overlapping segments.
Handles boundary detection to avoid splitting mid-sentence or mid-table.

Key parameters:
- MAX_CHARS_SINGLE_CALL: 150,000 (triggers chunking)
- CHUNK_SIZE: 80,000 chars per segment
- OVERLAP: 2,000 chars (context continuity)
- Token budget: 200K tokens total, 65K output, ~134K input
- Char-to-token ratio: ~2.9 chars/token
"""

import re
from typing import List, Tuple
from dataclasses import dataclass


# Configuration
MAX_CHARS_SINGLE_CALL = 150_000  # Beyond this, split into chunks
CHUNK_SIZE = 80_000              # Target chars per chunk
OVERLAP = 2_000                  # Overlap between chunks for context
CHAR_TO_TOKEN_RATIO = 2.9        # Empirical from production runs
MAX_INPUT_TOKENS = 134_464       # 200K context - 65.5K output budget


@dataclass
class Chunk:
    """A text chunk with metadata."""
    text: str
    index: int
    total_chunks: int
    start_char: int
    end_char: int
    estimated_tokens: int


def needs_chunking(text: str) -> bool:
    """Determine if text requires chunking based on length."""
    return len(text) > MAX_CHARS_SINGLE_CALL


def estimate_tokens(text: str) -> int:
    """Estimate token count from character length."""
    return int(len(text) / CHAR_TO_TOKEN_RATIO)


def chunk_text(text: str, chunk_size: int = CHUNK_SIZE, overlap: int = OVERLAP) -> List[Chunk]:
    """Split text into overlapping chunks at natural boundaries.
    
    Boundary detection priority:
    1. Section headers (\n\n# or \nSECTION)
    2. Double newlines (paragraph breaks)
    3. Single newlines
    4. Sentence endings (. followed by space/newline)
    5. Hard split at chunk_size (last resort)
    
    Args:
        text: Full document text
        chunk_size: Target size per chunk in characters
        overlap: Characters of overlap between chunks
    
    Returns:
        List of Chunk objects
    """
    if not text:
        return [Chunk(text="", index=0, total_chunks=1, start_char=0, end_char=0, estimated_tokens=0)]
    
    if not needs_chunking(text):
        return [Chunk(
            text=text, index=0, total_chunks=1,
            start_char=0, end_char=len(text),
            estimated_tokens=estimate_tokens(text)
        )]
    
    chunks = []
    pos = 0
    
    while pos < len(text):
        # Determine end position for this chunk
        end = min(pos + chunk_size, len(text))
        
        if end < len(text):
            # Find a natural boundary near the target end
            boundary = _find_boundary(text, pos + chunk_size - 5000, pos + chunk_size + 1000)
            if boundary > pos:
                end = boundary
        
        chunk_text_str = text[pos:end]
        chunks.append(Chunk(
            text=chunk_text_str,
            index=len(chunks),
            total_chunks=0,  # Will be set after loop
            start_char=pos,
            end_char=end,
            estimated_tokens=estimate_tokens(chunk_text_str)
        ))
        
        # Move position forward, accounting for overlap
        pos = end - overlap if end < len(text) else end
    
    # Set total_chunks on all chunks
    for chunk in chunks:
        chunk.total_chunks = len(chunks)
    
    return chunks


def _find_boundary(text: str, search_start: int, search_end: int) -> int:
    """Find the best natural boundary within a search window.
    
    Priority order:
    1. Section header (\n\n followed by uppercase or #)
    2. Double newline (paragraph break)
    3. Single newline
    4. Sentence end (period + space)
    """
    search_start = max(0, search_start)
    search_end = min(len(text), search_end)
    window = text[search_start:search_end]
    
    # Priority 1: Section headers
    headers = list(re.finditer(r'\n\n(?=[A-Z#])', window))
    if headers:
        return search_start + headers[-1].start() + 2  # After the double newline
    
    # Priority 2: Double newlines
    double_nl = window.rfind('\n\n')
    if double_nl > 0:
        return search_start + double_nl + 2
    
    # Priority 3: Single newlines
    single_nl = window.rfind('\n')
    if single_nl > 0:
        return search_start + single_nl + 1
    
    # Priority 4: Sentence endings
    sentence_end = list(re.finditer(r'[.!?]\s', window))
    if sentence_end:
        return search_start + sentence_end[-1].end()
    
    # Fallback: hard split at search_end
    return search_end


def merge_chunk_results(results: List[dict]) -> dict:
    """Merge extraction results from multiple chunks into a single output.
    
    Strategy:
    - Scalar fields: take from first chunk that has them
    - List fields: concatenate and deduplicate by key fields
    - Nested dicts: deep merge
    
    Args:
        results: List of parsed extraction dicts, one per chunk
    
    Returns:
        Merged extraction dict
    """
    if not results:
        return {}
    
    if len(results) == 1:
        return results[0]
    
    merged = {}
    
    for result in results:
        if not isinstance(result, dict):
            continue
        for key, value in result.items():
            if key not in merged:
                merged[key] = value
            elif isinstance(value, list) and isinstance(merged[key], list):
                # Extend lists, attempting dedup
                merged[key] = _merge_lists(merged[key], value)
            elif isinstance(value, dict) and isinstance(merged[key], dict):
                # Deep merge dicts
                merged[key] = _deep_merge(merged[key], value)
            # For scalar conflicts, keep first (earlier chunks have more context)
    
    return merged


def _merge_lists(existing: list, new: list) -> list:
    """Merge two lists, deduplicating based on content similarity."""
    if not new:
        return existing
    if not existing:
        return new
    
    # If items are dicts with identifying fields, deduplicate
    if existing and isinstance(existing[0], dict):
        # Use string representation for dedup (simple but effective)
        existing_strs = {str(sorted(item.items())) if isinstance(item, dict) else str(item) 
                        for item in existing}
        for item in new:
            item_str = str(sorted(item.items())) if isinstance(item, dict) else str(item)
            if item_str not in existing_strs:
                existing.append(item)
                existing_strs.add(item_str)
        return existing
    
    # For simple lists, use set dedup
    return list(dict.fromkeys(existing + new))  # Preserves order


def _deep_merge(base: dict, override: dict) -> dict:
    """Deep merge two dicts. Override wins for scalar conflicts."""
    result = base.copy()
    for key, value in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = _deep_merge(result[key], value)
        elif key in result and isinstance(result[key], list) and isinstance(value, list):
            result[key] = _merge_lists(result[key], value)
        elif key not in result or result[key] is None:
            result[key] = value
    return result
