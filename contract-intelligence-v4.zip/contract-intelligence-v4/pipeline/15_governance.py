# Databricks notebook source
# DBTITLE 1,Governance & Security Engine
# MAGIC %md
# MAGIC # Platform Module 15: Governance & Security Engine
# MAGIC
# MAGIC **Wave 4 — Production-grade access control and auditability**
# MAGIC
# MAGIC Provides LLM audit trail, prompt version control, RBAC policy management, and environment separation for the Provider Contract Intelligence platform.
# MAGIC
# MAGIC **Tables:**
# MAGIC - `tbl_gov_llm_audit` — full audit trail for every LLM extraction call
# MAGIC - `tbl_gov_prompt_registry` — version-controlled prompts with SHA-256 hashes
# MAGIC - `tbl_gov_rbac_policies` — role-based access control definitions
# MAGIC - `tbl_gov_environments` — dev/staging/prod topology and promotion gates
# MAGIC
# MAGIC **Key Principles:**
# MAGIC 1. Every LLM call is traceable: prompt hash + response hash + cost
# MAGIC 2. Prompts are immutable once registered (content-addressable by SHA-256)
# MAGIC 3. Access follows least-privilege: analysts get SELECT on gold, engineers get full dev
# MAGIC 4. Environment promotion requires quality gates (F1, SLOs, golden queries)

# COMMAND ----------

# DBTITLE 1,Configuration
import hashlib
from datetime import datetime
import uuid

SCHEMA = "dev_adb.raw"

# Tables
LLM_AUDIT = f"{SCHEMA}.tbl_gov_llm_audit"
PROMPT_REGISTRY = f"{SCHEMA}.tbl_gov_prompt_registry"
RBAC_POLICIES = f"{SCHEMA}.tbl_gov_rbac_policies"
ENVIRONMENTS = f"{SCHEMA}.tbl_gov_environments"

# Cost model
COST_INPUT_PER_M = 3.00
COST_OUTPUT_PER_M = 15.00

print(f"Governance schema: {SCHEMA}")
print(f"Tables: llm_audit, prompt_registry, rbac_policies, environments")

# COMMAND ----------

# DBTITLE 1,LLM Audit Functions
def log_llm_call(run_id, source_filename, document_type, prompt_name, 
                 input_tokens, output_tokens, latency_seconds,
                 repair_strategy='none', validation_passed=True,
                 chunked=False, chunk_count=None, text_length=None,
                 rates_count=None, sections_count=None):
    """Log a single LLM extraction call to the audit trail.
    
    Call this from extraction notebooks after each successful LLM response.
    """
    audit_id = f"audit_{uuid.uuid4().hex[:12]}"
    cost = (input_tokens * COST_INPUT_PER_M / 1_000_000) + (output_tokens * COST_OUTPUT_PER_M / 1_000_000)
    total_tokens = input_tokens + output_tokens
    
    # Look up prompt hash from registry
    prompt_hash_row = spark.sql(f"""
        SELECT sha256_hash FROM {PROMPT_REGISTRY}
        WHERE prompt_name = '{prompt_name}' AND status = 'ACTIVE'
        LIMIT 1
    """).collect()
    prompt_hash = prompt_hash_row[0].sha256_hash if prompt_hash_row else None
    
    spark.sql(f"""
        INSERT INTO {LLM_AUDIT} VALUES (
            '{audit_id}', '{run_id}', CURRENT_TIMESTAMP(),
            '{source_filename}', '{document_type}', '{prompt_name}', '6.0.0',
            {f"'{prompt_hash}'" if prompt_hash else 'NULL'},
            'databricks-claude-sonnet-4-5', 'databricks-claude-sonnet-4-5',
            {input_tokens}, {output_tokens}, {total_tokens}, {cost:.4f}, {latency_seconds},
            NULL, '{repair_strategy}', {validation_passed}, NULL,
            {chunked}, {f'{chunk_count}' if chunk_count else 'NULL'},
            NULL, {f'{text_length}' if text_length else 'NULL'},
            {f'{sections_count}' if sections_count else 'NULL'},
            {f'{rates_count}' if rates_count else 'NULL'},
            0.0, 65536
        )
    """)
    return audit_id


def audit_summary(run_id=None):
    """Print audit summary for a run (or all runs)."""
    where = f"WHERE run_id = '{run_id}'" if run_id else ""
    stats = spark.sql(f"""
        SELECT COUNT(*) as total_calls,
               SUM(input_tokens) as total_input,
               SUM(output_tokens) as total_output,
               ROUND(SUM(cost_usd), 2) as total_cost,
               ROUND(AVG(latency_seconds), 1) as avg_latency,
               SUM(CASE WHEN validation_passed THEN 1 ELSE 0 END) as passed,
               SUM(CASE WHEN NOT validation_passed THEN 1 ELSE 0 END) as failed,
               SUM(CASE WHEN repair_strategy != 'none' THEN 1 ELSE 0 END) as repaired
        FROM {LLM_AUDIT} {where}
    """).collect()[0]
    
    print(f"\nAUDIT SUMMARY {f'(run: {run_id})' if run_id else '(all runs)'}")
    print(f"  Total calls:    {stats.total_calls}")
    print(f"  Total cost:     ${stats.total_cost}")
    print(f"  Avg latency:    {stats.avg_latency}s")
    print(f"  Passed:         {stats.passed} ({stats.passed*100//max(stats.total_calls,1)}%)")
    print(f"  Repaired:       {stats.repaired}")
    return stats

print("  Functions: log_llm_call(), audit_summary()")
print("  Usage: audit_id = log_llm_call(run_id, filename, doc_type, prompt, in_tok, out_tok, latency)")

# COMMAND ----------

# DBTITLE 1,Prompt Registry Functions
def register_prompt(prompt_name, version, prompt_text, document_type, description, 
                    expected_sections, change_notes='Initial version'):
    """Register a new prompt version. Computes SHA-256 hash for content-addressable lookup."""
    sha = hashlib.sha256(prompt_text.encode('utf-8')).hexdigest()
    prompt_id = f"{prompt_name}_{version.replace('.','')}"
    
    # Deprecate previous active version
    spark.sql(f"""
        UPDATE {PROMPT_REGISTRY}
        SET status = 'DEPRECATED', effective_to = CURRENT_DATE()
        WHERE prompt_name = '{prompt_name}' AND status = 'ACTIVE'
    """)
    
    spark.sql(f"""
        INSERT INTO {PROMPT_REGISTRY} VALUES (
            '{prompt_id}', '{prompt_name}', '{version}', '{sha}',
            '{prompt_text[:4000]}',
            '{document_type}', '{description}', 'V6',
            '{expected_sections}',
            CURRENT_DATE(), NULL, 'ACTIVE',
            'adixit01@blueshieldca.com', CURRENT_TIMESTAMP(),
            '{change_notes}'
        )
    """)
    print(f"  Registered: {prompt_name} v{version} (hash: {sha[:12]}...)")
    return sha


def validate_prompt_hash(prompt_name, prompt_text):
    """Verify prompt text matches registered hash. Returns True if valid."""
    sha = hashlib.sha256(prompt_text.encode('utf-8')).hexdigest()
    registered = spark.sql(f"""
        SELECT sha256_hash FROM {PROMPT_REGISTRY}
        WHERE prompt_name = '{prompt_name}' AND status = 'ACTIVE'
    """).collect()
    
    if not registered:
        print(f"  WARNING: No active registration for {prompt_name}")
        return False
    
    match = registered[0].sha256_hash == sha
    if not match:
        print(f"  REJECT: Prompt hash mismatch for {prompt_name}")
        print(f"    Expected: {registered[0].sha256_hash[:16]}...")
        print(f"    Got:      {sha[:16]}...")
    return match


print("  Functions: register_prompt(), validate_prompt_hash()")
print("  Usage: sha = register_prompt('base_v6', '6.1.0', text, 'base_agreement', desc, sections)")

# COMMAND ----------

# DBTITLE 1,Governance Health Check
def governance_health_check():
    """Run governance health checks and report status."""
    print("GOVERNANCE HEALTH CHECK")
    print("=" * 50)
    
    # 1. Audit trail completeness
    audit_count = spark.sql(f"SELECT COUNT(*) FROM {LLM_AUDIT}").collect()[0][0]
    print(f"  Audit records: {audit_count}")
    
    # 2. Active prompts
    prompts = spark.sql(f"SELECT COUNT(*) FROM {PROMPT_REGISTRY} WHERE status = 'ACTIVE'").collect()[0][0]
    print(f"  Active prompts: {prompts}")
    
    # 3. RBAC policies
    policies = spark.sql(f"SELECT COUNT(*) FROM {RBAC_POLICIES} WHERE status = 'ACTIVE'").collect()[0][0]
    print(f"  Active RBAC policies: {policies}")
    
    # 4. Environment readiness
    envs = spark.sql(f"SELECT env_name, status FROM {ENVIRONMENTS}").collect()
    for e in envs:
        print(f"  Environment {e.env_name}: {e.status}")
    
    # 5. Unaudited extractions (files in tables but not in audit)
    total_extractions = spark.sql("SELECT COUNT(DISTINCT source_filename) FROM dev_adb.raw.tbl_genie_amendment_timeline").collect()[0][0]
    audited = spark.sql(f"SELECT COUNT(DISTINCT source_filename) FROM {LLM_AUDIT}").collect()[0][0]
    gap = total_extractions - audited
    print(f"\n  Extraction audit gap: {gap} files not yet in audit trail")
    print(f"    ({audited}/{total_extractions} audited = {audited*100//total_extractions}%)")
    print(f"    Note: Full audit requires re-running extraction with logging enabled")
    
    # Summary
    issues = []
    if prompts < 4:
        issues.append("Missing prompt registrations")
    if gap > 0:
        issues.append(f"{gap} unaudited extractions")
    
    print(f"\n  Status: {'ALL CLEAR' if not issues else f'{len(issues)} issue(s): ' + ', '.join(issues)}")
    return len(issues)

governance_health_check()

# COMMAND ----------

# DBTITLE 1,Audit Trail Report
# MAGIC %sql
# MAGIC -- Audit trail: cost and token usage by document type
# MAGIC SELECT document_type,
# MAGIC        COUNT(*) as files,
# MAGIC        SUM(input_tokens) as total_input_tokens,
# MAGIC        SUM(output_tokens) as total_output_tokens,
# MAGIC        ROUND(SUM(cost_usd), 2) as total_cost_usd,
# MAGIC        ROUND(AVG(latency_seconds), 1) as avg_latency_s,
# MAGIC        SUM(CASE WHEN repair_strategy != 'none' THEN 1 ELSE 0 END) as repairs,
# MAGIC        SUM(CASE WHEN NOT validation_passed THEN 1 ELSE 0 END) as failures
# MAGIC FROM dev_adb.raw.tbl_gov_llm_audit
# MAGIC GROUP BY document_type
# MAGIC ORDER BY files DESC

# COMMAND ----------

# DBTITLE 1,RBAC Summary
# MAGIC %sql
# MAGIC -- RBAC policy overview
# MAGIC SELECT role_name, role_description, permissions, data_classification, status
# MAGIC FROM dev_adb.raw.tbl_gov_rbac_policies
# MAGIC WHERE status = 'ACTIVE'
# MAGIC ORDER BY 
# MAGIC     CASE data_classification 
# MAGIC         WHEN 'RESTRICTED' THEN 1 
# MAGIC         WHEN 'CONFIDENTIAL' THEN 2 
# MAGIC         WHEN 'INTERNAL' THEN 3 
# MAGIC         ELSE 4 
# MAGIC     END

# COMMAND ----------

# DBTITLE 1,Environment Topology
# MAGIC %sql
# MAGIC -- Environment topology and promotion gates
# MAGIC SELECT env_name, catalog_name, schema_name, status,
# MAGIC        promotion_source, promotion_gate, data_refresh_frequency
# MAGIC FROM dev_adb.raw.tbl_gov_environments
# MAGIC ORDER BY 
# MAGIC     CASE env_name WHEN 'dev' THEN 1 WHEN 'staging' THEN 2 WHEN 'prod' THEN 3 END