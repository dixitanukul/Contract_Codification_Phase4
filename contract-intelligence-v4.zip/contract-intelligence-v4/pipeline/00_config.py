"""
Contract Intelligence Platform — Shared Configuration
======================================================
All platform implementation files import from this module.
Run this first to initialize the session context.
"""

from datetime import datetime
from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()

# ============================================================
# CATALOG & SCHEMA
# ============================================================
CATALOG = "dev_adb"
SCHEMA = "raw"
FQ_PREFIX = f"{CATALOG}.{SCHEMA}"  # "dev_adb.raw"

# ============================================================
# MODEL ENDPOINTS
# ============================================================
EMBEDDING_MODEL = "databricks-gte-large-en"
RERANKER_MODEL = "bge-reranker-v2-m3"
LLM_JUDGE = "databricks-claude-sonnet-4-5"
LLM_EXTRACTION = "databricks-claude-sonnet-4-5"

# ============================================================
# VECTOR SEARCH
# ============================================================
VS_ENDPOINT = "contract_intelligence_vs_endpoint"
VS_INDEX_LEGAL_UNITS = f"{CATALOG}.{SCHEMA}.idx_legal_units_v2"

# ============================================================
# FEATURE FLAGS (toggle as integrations come online)
# ============================================================
CLAIMS_AVAILABLE = False       # Claims feed not yet connected (P0-3: no join path, see claims_linkage_investigation.md)
RERANKER_DEPLOYED = False      # Cross-encoder not yet on Model Serving
FULL_CORPUS_PROCESSED = False  # Only 199/10,372 PDFs processed
V3_AGENT_ENABLED = True        # V3 Universal Agent — set True to route Cell 15 through AgentController

# ============================================================
# TABLE NAMES — State Engine
# ============================================================
TBL_CONTRACT_REGISTRY = f"{FQ_PREFIX}.tbl_v2_contract_registry"
TBL_AMENDMENT_REGISTRY = f"{FQ_PREFIX}.tbl_v2_amendment_registry"
TBL_RATE_FACTS = f"{FQ_PREFIX}.tbl_v2_rate_facts_bitemporal"
TBL_DOCUMENT_LINEAGE = f"{FQ_PREFIX}.tbl_v2_document_lineage"
TBL_STATE_LOG = f"{FQ_PREFIX}.tbl_v2_state_computation_log"

# ============================================================
# TABLE NAMES — Reimbursement Engine
# ============================================================
TBL_RATE_RULES = f"{FQ_PREFIX}.tbl_reimb_rate_rules"
TBL_FORMULA_COMPONENTS = f"{FQ_PREFIX}.tbl_reimb_formula_components"
TBL_STOP_LOSS = f"{FQ_PREFIX}.tbl_reimb_stop_loss"
TBL_CARVE_OUTS = f"{FQ_PREFIX}.tbl_reimb_carve_outs"
TBL_ESCALATORS = f"{FQ_PREFIX}.tbl_reimb_escalators"
TBL_CONDITIONS = f"{FQ_PREFIX}.tbl_reimb_conditions"
TBL_LESSER_OF = f"{FQ_PREFIX}.tbl_reimb_lesser_of"
TBL_TAXONOMY = f"{FQ_PREFIX}.dim_service_line_taxonomy"
TBL_PATTERNS = f"{FQ_PREFIX}.dim_service_line_patterns"

# ============================================================
# TABLE NAMES — Intelligence Engine
# ============================================================
TBL_CLAIMS_FEED = f"{FQ_PREFIX}.tbl_claims_summary_feed"
TBL_UTILIZATION_FEED = f"{FQ_PREFIX}.tbl_utilization_feed"
TBL_BENCHMARK = f"{FQ_PREFIX}.tbl_intel_benchmark_results"
TBL_PROVIDER_SPEND = f"{FQ_PREFIX}.tbl_intel_provider_spend_summary"
TBL_SERVICE_SPEND = f"{FQ_PREFIX}.tbl_intel_service_line_spend"
TBL_SAVINGS = f"{FQ_PREFIX}.tbl_intel_savings_opportunity"
TBL_SCENARIOS = f"{FQ_PREFIX}.tbl_intel_scenario_results"
TBL_LEVERAGE = f"{FQ_PREFIX}.tbl_intel_leverage_scores"
TBL_RENEWAL = f"{FQ_PREFIX}.tbl_intel_renewal_priority"

# ============================================================
# TABLE NAMES — Retrieval Engine
# ============================================================
TBL_LEGAL_UNITS = f"{FQ_PREFIX}.tbl_retrieval_legal_units"
TBL_TELEMETRY = f"{FQ_PREFIX}.tbl_retrieval_telemetry"

# ============================================================
# V1 TABLES (read-only references)
# ============================================================
V1_RATES = f"{FQ_PREFIX}.tbl_contract_rates_all"
V1_PROTECTIONS = f"{FQ_PREFIX}.tbl_contract_financial_protections"
V1_CLAUSES = f"{FQ_PREFIX}.tbl_contract_clauses_all"
V1_PARTIES = f"{FQ_PREFIX}.tbl_contract_parties_all"
V1_TERMS = f"{FQ_PREFIX}.tbl_contract_terms_all"
V1_CAPITATION = f"{FQ_PREFIX}.tbl_serving_capitation_card"
V1_GENIE_RATES = f"{FQ_PREFIX}.tbl_genie_rates_current"
V1_AMENDMENTS = f"{FQ_PREFIX}.tbl_genie_amendment_timeline"
V1_PROVIDERS = f"{FQ_PREFIX}.tbl_genie_provider_profile"
V1_DIM_PROVIDER = f"{FQ_PREFIX}.dim_provider_canonical"

# ============================================================
# PATHS
# ============================================================
BASE_PATH = "/Users/adixit01@blueshieldca.com/Contract_Codification_Pipeline"
PLATFORM_PATH = f"{BASE_PATH}/platform"
SQL_PATH = f"{BASE_PATH}/sql"
EXTRACTION_PATH = f"{BASE_PATH}/extraction"
DOCS_PATH = f"{BASE_PATH}/docs"
DATA_PATH = f"{BASE_PATH}/data"

# ============================================================
# UTILITY FUNCTIONS
# ============================================================

def run_sql(sql_statement: str, description: str = "") -> "DataFrame":
    """Execute a SQL statement with logging."""
    start = datetime.now()
    desc = description or sql_statement[:80]
    print(f"[SQL] {desc}...")
    try:
        result = spark.sql(sql_statement)
        elapsed = (datetime.now() - start).total_seconds()
        print(f"  ✓ Completed in {elapsed:.1f}s")
        return result
    except Exception as e:
        elapsed = (datetime.now() - start).total_seconds()
        print(f"  ✗ FAILED after {elapsed:.1f}s: {e}")
        raise


def table_exists(table_name: str) -> bool:
    """Check if a table exists in the catalog (fully qualified name)."""
    try:
        spark.sql(f"DESCRIBE TABLE {table_name}")
        return True
    except Exception:
        return False


def row_count(table_name: str) -> int:
    """Get row count of a table. Returns -1 if table doesn't exist."""
    if not table_exists(table_name):
        return -1
    return spark.sql(f"SELECT COUNT(*) AS n FROM {table_name}").collect()[0]["n"]


def log_step(step_name: str, status: str, details: str = ""):
    """Log a pipeline step with timestamp."""
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    icon = "✓" if status == "SUCCESS" else "✗" if status == "FAILED" else "○"
    print(f"[{ts}] {icon} {step_name}: {status}")
    if details:
        print(f"    {details}")


def read_sql_file(file_path: str) -> str:
    """Read a SQL file from the workspace filesystem."""
    workspace_path = f"/Workspace{file_path}"
    with open(workspace_path, "r") as f:
        return f.read()


def execute_sql_file(file_path: str, description: str = ""):
    """Read and execute all statements in a SQL file (split on semicolons)."""
    desc = description or file_path.split("/")[-1]
    log_step(f"Executing {desc}", "RUNNING")
    sql_content = read_sql_file(file_path)

    # Split on semicolons, filter empty statements
    statements = [s.strip() for s in sql_content.split(";") if s.strip()]
    success_count = 0
    error_count = 0

    for i, stmt in enumerate(statements, 1):
        # Skip pure comments
        lines = [l for l in stmt.split("\n") if not l.strip().startswith("--")]
        if not "".join(lines).strip():
            continue
        try:
            spark.sql(stmt)
            success_count += 1
        except Exception as e:
            error_count += 1
            print(f"  ✗ Statement {i} failed: {str(e)[:120]}")

    status = "SUCCESS" if error_count == 0 else "PARTIAL"
    log_step(desc, status, f"{success_count} succeeded, {error_count} failed")
    return success_count, error_count



# ============================================================
# TELEMETRY — Structured pipeline observability
# ============================================================
import uuid as _uuid_mod
from datetime import datetime as _dt_cls, timezone as _tz_mod

_RUN_ID = str(_uuid_mod.uuid4())
_TELEMETRY_BUFFER = []
_TELEMETRY_TABLE = f"{CATALOG}.{SCHEMA}.tbl_pipeline_telemetry"


def log_telemetry(step, check, result, filename=None, provider_id=None,
                  severity='INFO', detail=None, metric=None, value=None):
    """Buffer a telemetry event for later flush."""
    _TELEMETRY_BUFFER.append({
        'run_id': _RUN_ID,
        'ts': _dt_cls.now(_tz_mod.utc).strftime('%Y-%m-%d %H:%M:%S'),
        'step': step,
        'check': check,
        'result': result,
        'filename': filename,
        'provider_id': provider_id,
        'severity': severity,
        'detail': json.dumps(detail) if detail else None,
        'metric': metric,
        'value': float(value) if value is not None else None,
    })


def flush_telemetry():
    """Write buffered telemetry to Delta table. Returns count flushed."""
    if not _TELEMETRY_BUFFER:
        return 0
    from pyspark.sql.types import StructType, StructField, StringType, DoubleType, TimestampType
    schema = StructType([
        StructField("run_id", StringType()), StructField("ts", StringType()),
        StructField("step", StringType()), StructField("check_name", StringType()),
        StructField("result", StringType()), StructField("filename", StringType()),
        StructField("provider_id", StringType()), StructField("severity", StringType()),
        StructField("detail", StringType()), StructField("metric", StringType()),
        StructField("value", DoubleType()),
    ])
    from pyspark.sql import functions as _F
    df = spark.createDataFrame(_TELEMETRY_BUFFER, schema=schema)
    df = df.withColumn("ts", _F.to_timestamp("ts"))
    df.write.mode("append").saveAsTable(_TELEMETRY_TABLE)
    n = len(_TELEMETRY_BUFFER)
    _TELEMETRY_BUFFER.clear()
    return n


# ============================================================
# SESSION INITIALIZATION
# ============================================================
print("=" * 60)
print("CONTRACT INTELLIGENCE PLATFORM — Config Loaded")
print(f"  Catalog: {CATALOG}")
print(f"  Schema:  {SCHEMA}")
print(f"  Claims:  {'AVAILABLE' if CLAIMS_AVAILABLE else 'NOT CONNECTED'}\
  V3 Agent: {'ENABLED' if V3_AGENT_ENABLED else 'DISABLED (V2 fallback)'}")
print(f"  Reranker: {'DEPLOYED' if RERANKER_DEPLOYED else 'FALLBACK MODE'}")
print(f"  Corpus:  {'FULL' if FULL_CORPUS_PROCESSED else 'SAMPLE (199 PDFs)'}")
print("=" * 60)
