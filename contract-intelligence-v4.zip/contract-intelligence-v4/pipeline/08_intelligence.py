"""V2 Step 8: Intelligence Pipeline (Trimmed)
=================================================
Computes negotiation intelligence from V2 rate rules + taxonomy:
  1. Benchmark results (percentile rates per service line) — REAL DATA
  2. Renewal priority scoring (contract expiry dates) — REAL DATA

Removed (fabricated, no claims feed):
  - Provider spend summary (used hardcoded volume=50)
  - Savings opportunity (depended on fabricated spend)
  - Leverage scores (hardcoded plan_market_share=0.25)
  - Scenario results (hardcoded volume_per_line=50)

Run AFTER: 03_reimbursement_migration.py
"""

from datetime import datetime
from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()

CATALOG = "dev_adb"
SCHEMA = "raw"
FQ = f"{CATALOG}.{SCHEMA}"


def main():
    print("=" * 60)
    print("V2 INTELLIGENCE PIPELINE (trimmed — real metrics only)")
    print(f"  Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)

    spark.sql(f"USE CATALOG {CATALOG}")
    spark.sql(f"USE SCHEMA {SCHEMA}")

    # ============================================================
    # TABLE 1: tbl_intel_benchmark_results
    # Percentile rates per service line across all providers
    # ============================================================
    print("\n[1] Creating benchmark results...")

    spark.sql(f"""
    CREATE TABLE IF NOT EXISTS {FQ}.tbl_intel_benchmark_results (
        benchmark_id    STRING NOT NULL  COMMENT 'Unique benchmark row ID',
        rate_domain     STRING NOT NULL  COMMENT 'INPATIENT|OUTPATIENT|CAPITATION|PROFESSIONAL',
        service_line    STRING NOT NULL  COMMENT 'Service line (from rate_rules or taxonomy)',
        formula_type    STRING           COMMENT 'Formula type for this benchmark group',
        p10             FLOAT            COMMENT '10th percentile rate',
        p25             FLOAT            COMMENT '25th percentile rate',
        p50_median      FLOAT            COMMENT 'Median rate (50th percentile)',
        p75             FLOAT            COMMENT '75th percentile rate',
        p90             FLOAT            COMMENT '90th percentile rate',
        mean_rate       FLOAT            COMMENT 'Mean rate across providers',
        provider_count  INT              COMMENT 'Number of providers with this service line',
        rate_count      INT              COMMENT 'Total rate entries in this group',
        std_dev         FLOAT            COMMENT 'Standard deviation of rates',
        computed_at     TIMESTAMP        COMMENT 'When this benchmark was computed',
        source          STRING           COMMENT 'estimated|claims_weighted'
    ) USING DELTA
    COMMENT 'Percentile rate benchmarks by service line. Foundation for savings analysis.'
    TBLPROPERTIES ('delta.enableChangeDataFeed'='true','delta.columnMapping.mode'='name')
    """)

    spark.sql(f"""
    INSERT OVERWRITE {FQ}.tbl_intel_benchmark_results
    SELECT
        sha2(concat_ws('|', rate_domain, service_line, formula_type), 256) AS benchmark_id,
        rate_domain,
        service_line,
        formula_type,
        percentile_approx(rate_numeric, 0.10) AS p10,
        percentile_approx(rate_numeric, 0.25) AS p25,
        percentile_approx(rate_numeric, 0.50) AS p50_median,
        percentile_approx(rate_numeric, 0.75) AS p75,
        percentile_approx(rate_numeric, 0.90) AS p90,
        AVG(rate_numeric) AS mean_rate,
        COUNT(DISTINCT provider_id) AS provider_count,
        COUNT(*) AS rate_count,
        STDDEV(rate_numeric) AS std_dev,
        current_timestamp() AS computed_at,
        'estimated' AS source
    FROM {FQ}.tbl_reimb_rate_rules
    WHERE rate_numeric IS NOT NULL AND rate_numeric > 0
    GROUP BY rate_domain, service_line, formula_type
    HAVING COUNT(*) >= 3
    """)

    bench_count = spark.sql(f"SELECT COUNT(*) AS n FROM {FQ}.tbl_intel_benchmark_results").collect()[0]["n"]
    print(f"  ✓ {bench_count} benchmark groups computed")

    # ============================================================
    # TABLE 2: tbl_intel_renewal_priority
    # Contract expiry dates + rate percentile position (real data)
    # ============================================================
    print("\n[2] Creating renewal priority scores...")

    spark.sql(f"""
    CREATE TABLE IF NOT EXISTS {FQ}.tbl_intel_renewal_priority (
        provider_id         STRING NOT NULL  COMMENT 'Provider ID',
        provider_name       STRING NOT NULL  COMMENT 'Provider name',
        contract_id         STRING           COMMENT 'FK to contract registry',
        urgency_score       FLOAT            COMMENT 'Urgency component (0-40)',
        days_to_expiry      INT              COMMENT 'Days until contract expires',
        auto_renewal        BOOLEAN          COMMENT 'Whether contract auto-renews',
        impact_score        FLOAT            COMMENT 'Rate volume component (0-40)',
        estimated_spend     FLOAT            COMMENT 'Placeholder spend column retained for table compatibility',
        savings_opportunity FLOAT            COMMENT 'Placeholder savings column retained for table compatibility',
        risk_score          FLOAT            COMMENT 'Rate position risk component (0-20)',
        pct_above_median    FLOAT            COMMENT 'Percent of rates above median',
        priority_score      FLOAT            COMMENT 'Total priority (0-100)',
        priority_rank       INT              COMMENT 'Rank (1=most urgent)',
        recommended_action  STRING           COMMENT 'ALLOW_AUTO_RENEW|NEGOTIATE|ISSUE_NON_RENEWAL|ESCALATE',
        computed_at         TIMESTAMP        COMMENT 'Computation timestamp'
    ) USING DELTA
    COMMENT 'Contract renewal priority scoring for proactive negotiation planning.'
    TBLPROPERTIES ('delta.enableChangeDataFeed'='true','delta.columnMapping.mode'='name')
    """)

    spark.sql(f"""
    INSERT OVERWRITE {FQ}.tbl_intel_renewal_priority
    WITH provider_rate_stats AS (
        SELECT
            rr.provider_id,
            COUNT(*) AS total_rate_rules,
            AVG(CASE WHEN rr.rate_numeric > b.p50_median THEN 1.0 ELSE 0.0 END) * 100 AS pct_above_median
        FROM {FQ}.tbl_reimb_rate_rules rr
        JOIN {FQ}.tbl_intel_benchmark_results b
            ON rr.rate_domain = b.rate_domain
            AND rr.service_line = b.service_line
            AND rr.formula_type = b.formula_type
        WHERE rr.rate_numeric IS NOT NULL AND rr.rate_numeric > 0
        GROUP BY rr.provider_id
    ),
    amendment_recency AS (
        SELECT contract_id,
            DATEDIFF(current_date(), MAX(effective_date_parsed)) as days_since_last_amendment
        FROM {FQ}.tbl_contract_documents_master
        GROUP BY contract_id
    ),
    base AS (
        SELECT
            c.provider_id,
            c.provider_name,
            c.contract_id,
            DATEDIFF(c.effective_to, current_date()) AS days_to_expiry,
            CASE WHEN c.auto_renewal THEN TRUE ELSE FALSE END AS auto_renewal,
            COALESCE(rs.total_rate_rules, 0) AS total_rate_rules,
            COALESCE(rs.pct_above_median, 50) AS pct_above_median,
            ar.days_since_last_amendment
        FROM {FQ}.tbl_v2_contract_registry c
        LEFT JOIN provider_rate_stats rs ON c.provider_id = rs.provider_id
        LEFT JOIN amendment_recency ar ON c.contract_id = ar.contract_id
        WHERE c.status = 'ACTIVE'
    ),
    scored AS (
        SELECT *,
            -- URGENCY (0-1): Sigmoid decay for known expiry, staleness proxy otherwise
            CASE
                WHEN days_to_expiry IS NOT NULL THEN
                    CAST(1.0 / (1.0 + EXP((days_to_expiry - 180.0) / 60.0)) AS FLOAT)
                WHEN days_since_last_amendment IS NOT NULL THEN
                    CAST(LEAST(1.0, days_since_last_amendment / 1095.0) * 0.6 AS FLOAT)
                ELSE CAST(0.3 AS FLOAT)
            END AS urgency_raw,
            -- IMPACT (0-1): Log-scaled rate count (avoids saturation)
            CAST(LEAST(1.0, LN(1 + total_rate_rules) / LN(1001)) AS FLOAT) AS impact_raw,
            -- RISK (0-1): Full-range pct above median
            CAST(pct_above_median / 100.0 AS FLOAT) AS risk_raw
        FROM base
    )
    SELECT
        provider_id, provider_name, contract_id,
        -- Urgency with auto-renewal dampener (40% reduction)
        CAST(urgency_raw * CASE WHEN auto_renewal THEN 0.6 ELSE 1.0 END AS FLOAT) AS urgency_score,
        days_to_expiry, auto_renewal,
        impact_raw AS impact_score,
        CAST(NULL AS FLOAT) AS estimated_spend,
        CAST(NULL AS FLOAT) AS savings_opportunity,
        risk_raw AS risk_score,
        pct_above_median,
        -- PRIORITY (0-1): Weighted composite (urgency 40%, impact 30%, risk 30%)
        CAST(
            (urgency_raw * CASE WHEN auto_renewal THEN 0.6 ELSE 1.0 END) * 0.40
            + impact_raw * 0.30 + risk_raw * 0.30
        AS FLOAT) AS priority_score,
        CAST(ROW_NUMBER() OVER (ORDER BY
            (urgency_raw * CASE WHEN auto_renewal THEN 0.6 ELSE 1.0 END) * 0.40
            + impact_raw * 0.30 + risk_raw * 0.30
        DESC) AS INT) AS priority_rank,
        CASE
            WHEN (urgency_raw * CASE WHEN auto_renewal THEN 0.6 ELSE 1.0 END) * 0.40 + impact_raw * 0.30 + risk_raw * 0.30 >= 0.7 THEN 'ESCALATE'
            WHEN risk_raw >= 0.8 AND impact_raw >= 0.5 THEN 'ISSUE_NON_RENEWAL'
            WHEN risk_raw >= 0.6 OR ((urgency_raw * CASE WHEN auto_renewal THEN 0.6 ELSE 1.0 END) >= 0.7 AND risk_raw >= 0.4) THEN 'NEGOTIATE'
            WHEN auto_renewal AND urgency_raw < 0.4 THEN 'MONITOR'
            ELSE 'ALLOW_AUTO_RENEW'
        END AS recommended_action,
        current_timestamp() AS computed_at
    FROM scored
    """)

    renewal_count = spark.sql(f"SELECT COUNT(*) AS n FROM {FQ}.tbl_intel_renewal_priority").collect()[0]["n"]
    print(f"  ✓ {renewal_count} renewal priorities scored")

    # ============================================================
    # SUMMARY
    # ============================================================
    print("\n" + "=" * 60)
    print("INTELLIGENCE PIPELINE COMPLETE")
    print("=" * 60)
    tables = [
        "tbl_intel_benchmark_results",
        "tbl_intel_renewal_priority",
    ]
    summary = {}
    for table_name in tables:
        count = spark.sql(f"SELECT COUNT(*) AS n FROM {FQ}.{table_name}").collect()[0]["n"]
        print(f"  {table_name:<40} {count:>6} rows")
        summary[table_name] = count
    print("=" * 60)

    return summary


if __name__ == "__main__":
    main()
