# Databricks notebook source
# DBTITLE 1,Semantic Intelligence Engine
# MAGIC %md
# MAGIC # Platform Module 19: Semantic Intelligence Engine
# MAGIC
# MAGIC **Wave 8 — Move from retrieval to reasoning**
# MAGIC
# MAGIC Enables semantic understanding of contract language: clause classification, supersession tracking, entity resolution, and competitive benchmarking.
# MAGIC
# MAGIC **Components:**
# MAGIC - **8.1 Clause-Type Ontology**: 25 clause types in 10 categories classifying 75K legal units
# MAGIC - **8.2 Amendment Supersession Graph**: 2,380 edges tracking what each amendment supersedes
# MAGIC - **8.3 Provider Entity Resolution (MDM)**: 302 canonical providers, 906 aliases, health system mapping
# MAGIC - **8.4 Rate Benchmarking Intelligence**: 10K+ provider-rate percentile positions
# MAGIC
# MAGIC **Tables:**
# MAGIC | Table | Rows | Purpose |
# MAGIC |-------|------|---------|
# MAGIC | `dim_clause_type_taxonomy` | 25 | Clause type definitions (10 top-level) |
# MAGIC | `tbl_retrieval_legal_units.clause_type` | 75,306 classified | Heuristic + LLM clause classification (100% coverage) |
# MAGIC | `fact_supersession` | 2,380 | Document-to-document supersession edges |
# MAGIC | `dim_provider_master` | 302 | Canonical provider identities |
# MAGIC | `bridge_provider_alias` | 906 | Name variant → canonical mapping |
# MAGIC | `tbl_intel_provider_percentiles` | 10,056 | Per-provider rate competitiveness |

# COMMAND ----------

# DBTITLE 1,Freshness Gate — Semantic Dependencies
from datetime import datetime

MONITORED_TABLES = [
    "tbl_retrieval_legal_units",
    "tbl_intel_benchmark_results",
    "tbl_intel_provider_percentiles",
    "dim_provider_master",
    "bridge_provider_alias",
    "fact_supersession",
]

freshness_df = spark.sql("""
    SELECT table_name, last_altered
    FROM system.information_schema.tables
    WHERE table_catalog = 'dev_adb'
      AND table_schema = 'raw'
      AND table_name IN (
          'tbl_retrieval_legal_units',
          'tbl_intel_benchmark_results',
          'tbl_intel_provider_percentiles',
          'dim_provider_master',
          'bridge_provider_alias',
          'fact_supersession'
      )
    ORDER BY last_altered DESC
""")

freshness_rows = {row["table_name"]: row["last_altered"] for row in freshness_df.collect()}
missing_tables = sorted(set(MONITORED_TABLES) - set(freshness_rows))

display(freshness_df)

if missing_tables:
    raise RuntimeError(
        "Missing required semantic dependency tables: " + ", ".join(missing_tables)
    )

dependency_rules = [
    (
        "tbl_retrieval_legal_units",
        "tbl_intel_benchmark_results",
        "Benchmark aggregates must be recomputed after semantic source updates.",
    ),
    (
        "tbl_retrieval_legal_units",
        "tbl_intel_provider_percentiles",
        "Provider percentile intelligence must be recomputed after semantic source updates.",
    ),
    (
        "tbl_intel_benchmark_results",
        "tbl_intel_provider_percentiles",
        "Provider percentile intelligence must not be older than its benchmark aggregate source.",
    ),
]

violations = []
for upstream, downstream, reason in dependency_rules:
    upstream_ts = freshness_rows[upstream]
    downstream_ts = freshness_rows[downstream]
    if downstream_ts < upstream_ts:
        violations.append(
            {
                "upstream": upstream,
                "upstream_ts": upstream_ts,
                "downstream": downstream,
                "downstream_ts": downstream_ts,
                "reason": reason,
            }
        )

if violations:
    violation_text = "\n".join(
        f"- {item['downstream']} is stale vs {item['upstream']} "
        f"({item['downstream_ts']} < {item['upstream_ts']}) — {item['reason']}"
        for item in violations
    )
    raise RuntimeError(
        "Downstream semantic freshness gate failed.\n"
        + violation_text
        + "\n\nRefresh downstream semantic materializations before rerunning the remaining report cells or publishing dashboard/Genie updates."
    )

print(
    "Freshness gate passed at",
    datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
)
print("Semantic reporting can proceed because downstream semantic tables are fresh.")

# COMMAND ----------

# DBTITLE 1,Clause Type Distribution
# MAGIC %sql
# MAGIC -- Clause classification coverage and distribution
# MAGIC SELECT 
# MAGIC     t.top_level,
# MAGIC     l.clause_type,
# MAGIC     COUNT(*) as unit_count,
# MAGIC     t.legal_significance
# MAGIC FROM dev_adb.raw.tbl_retrieval_legal_units l
# MAGIC JOIN dev_adb.raw.dim_clause_type_taxonomy t 
# MAGIC     ON l.clause_type = t.sub_type
# MAGIC WHERE l.clause_type IS NOT NULL
# MAGIC GROUP BY t.top_level, l.clause_type, t.legal_significance
# MAGIC ORDER BY unit_count DESC

# COMMAND ----------

# DBTITLE 1,Supersession Graph — Amendment Chains
# MAGIC %sql
# MAGIC -- Longest amendment supersession chains
# MAGIC SELECT 
# MAGIC     contract_chain_id,
# MAGIC     COUNT(*) as chain_depth,
# MAGIC     MIN(superseded_effective_date) as chain_start,
# MAGIC     MAX(superseding_effective_date) as chain_end,
# MAGIC     DATEDIFF(MAX(superseding_effective_date), MIN(superseded_effective_date)) as span_days
# MAGIC FROM dev_adb.raw.fact_supersession
# MAGIC WHERE superseded_effective_date IS NOT NULL
# MAGIC GROUP BY contract_chain_id
# MAGIC HAVING COUNT(*) >= 5
# MAGIC ORDER BY chain_depth DESC
# MAGIC LIMIT 20

# COMMAND ----------

# DBTITLE 1,Provider MDM — Health System Summary
# MAGIC %sql
# MAGIC -- Provider MDM health system overview
# MAGIC SELECT 
# MAGIC     COALESCE(health_system, 'Independent') as health_system,
# MAGIC     COUNT(*) as providers,
# MAGIC     SUM(total_contracts) as total_contracts,
# MAGIC     SUM(total_rate_rules) as total_rates,
# MAGIC     ROUND(AVG(total_amendments), 1) as avg_amendments
# MAGIC FROM dev_adb.raw.dim_provider_master
# MAGIC GROUP BY health_system
# MAGIC ORDER BY providers DESC

# COMMAND ----------

# DBTITLE 1,Rate Benchmarking — Expensive Outliers
# MAGIC %sql
# MAGIC -- Providers with the most expensive/outlier rates (highest savings opportunity)
# MAGIC SELECT 
# MAGIC     provider_name,
# MAGIC     rate_domain,
# MAGIC     service_line,
# MAGIC     provider_rate,
# MAGIC     p50_median,
# MAGIC     percentile_rank,
# MAGIC     competitiveness,
# MAGIC     savings_if_p50 as savings_to_median
# MAGIC FROM dev_adb.raw.tbl_intel_provider_percentiles
# MAGIC WHERE competitiveness IN ('EXPENSIVE', 'OUTLIER')
# MAGIC   AND savings_if_p50 > 100
# MAGIC ORDER BY savings_if_p50 DESC
# MAGIC LIMIT 25