# Databricks notebook source
# DBTITLE 1,Retrieval Quality Engine
# MAGIC %md
# MAGIC # Platform Module 18: Retrieval Quality Engine
# MAGIC
# MAGIC **Wave 7 — Make the Genie Space and search actually useful**
# MAGIC
# MAGIC Evaluation framework, temporal filtering, query classification, and reranker management for the retrieval subsystem.
# MAGIC
# MAGIC **Tables:**
# MAGIC - `tbl_eval_retrieval_queries` — 50 annotated queries (target: 200)
# MAGIC - `tbl_eval_retrieval_results` — per-query metric tracking
# MAGIC - `tbl_query_classification` — query type + routing decisions
# MAGIC - `tbl_query_routing_rules` — priority-ordered classification rules
# MAGIC - `tbl_reranker_config` — cross-encoder deployment status
# MAGIC - `tbl_retrieval_config` — engine defaults (temporal filter, max_results)
# MAGIC
# MAGIC **Retrieval SLOs:**
# MAGIC - Recall@5 > 0.85
# MAGIC - MRR > 0.70
# MAGIC - NDCG@10 > 0.75
# MAGIC - P95 latency < 500ms
# MAGIC
# MAGIC **Query Types & Strategies:**
# MAGIC | Type | Strategy | Temporal Filter | Max Results |
# MAGIC |------|----------|----------------|-------------|
# MAGIC | factual_current | vs_temporal | TRUE | 10 |
# MAGIC | historical | vs_full | FALSE | 20 |
# MAGIC | comparative | multi_provider | TRUE | 50 |
# MAGIC | absence | exhaustive_scan | TRUE | 100 |

# COMMAND ----------

# DBTITLE 1,Configuration
import re
from typing import Optional, Tuple

SCHEMA = "dev_adb.raw"

# Tables
RETRIEVAL_QUERIES = f"{SCHEMA}.tbl_eval_retrieval_queries"
RETRIEVAL_RESULTS = f"{SCHEMA}.tbl_eval_retrieval_results"
QUERY_CLASSIFICATION = f"{SCHEMA}.tbl_query_classification"
ROUTING_RULES = f"{SCHEMA}.tbl_query_routing_rules"
RETRIEVAL_CONFIG = f"{SCHEMA}.tbl_retrieval_config"
RERANKER_CONFIG = f"{SCHEMA}.tbl_reranker_config"

# SLO targets
SLO_RECALL_AT_5 = 0.85
SLO_MRR = 0.70
SLO_NDCG_AT_10 = 0.75
SLO_LATENCY_P95_MS = 500

print(f"Retrieval Quality schema: {SCHEMA}")
print(f"SLOs: Recall@5>{SLO_RECALL_AT_5}, MRR>{SLO_MRR}, NDCG@10>{SLO_NDCG_AT_10}, P95<{SLO_LATENCY_P95_MS}ms")

# COMMAND ----------

# DBTITLE 1,Query Classifier
def classify_query(query_text: str) -> Tuple[str, str, bool, int]:
    """Classify a query and determine retrieval strategy.
    
    Evaluates routing rules in priority order; first match wins.
    
    Returns:
        Tuple of (query_type, strategy, temporal_filter, max_results)
    """
    rules = spark.sql(f"""
        SELECT * FROM {ROUTING_RULES}
        ORDER BY priority ASC
    """).collect()
    
    query_lower = query_text.lower()
    
    for rule in rules:
        matched = False
        if rule.condition_type == 'keyword':
            keywords = [k.strip() for k in rule.condition_value.split(',')]
            matched = any(kw in query_lower for kw in keywords)
        elif rule.condition_type == 'pattern':
            matched = bool(re.match(rule.condition_value, query_lower))
        
        if matched:
            return (
                rule.assigned_query_type,
                rule.assigned_strategy,
                rule.temporal_filter,
                rule.max_results
            )
    
    # Fallback
    return ('factual_current', 'vs_temporal', True, 10)


def classify_and_log(query_text: str) -> dict:
    """Classify query and log to classification table."""
    import uuid
    qtype, strategy, temporal, max_results = classify_query(query_text)
    
    # Detect signals
    ql = query_text.lower()
    has_provider = bool(re.search(r'(cedars|providence|sutter|kaiser|stanford|dignity|sharp|ucsf|john muir|adventist|enloe|queen)', ql))
    has_temporal = bool(re.search(r'(history|historical|over time|changed|previous|before|was|were|used to)', ql))
    has_comparison = bool(re.search(r'(compare|versus|vs|difference|higher|lower|ranking|percentile|across)', ql))
    has_negation = bool(re.search(r'(does not|is there no|missing|without|absent|lack|no clause|never)', ql))
    
    cid = f"cls_{uuid.uuid4().hex[:8]}"
    spark.sql(f"""
        INSERT INTO {QUERY_CLASSIFICATION} VALUES (
            '{cid}', '{query_text.replace("'", "''")}', CURRENT_TIMESTAMP(),
            '{qtype}', 0.9,
            '{strategy}', {temporal}, {f"'{has_provider}'" if has_provider else 'NULL'}, 
            {'TRUE' if strategy != 'vs_temporal' else 'FALSE'}, {max_results},
            {has_provider}, {has_temporal}, {has_comparison}, {has_negation},
            NULL, NULL
        )
    """)
    
    return {'query_type': qtype, 'strategy': strategy, 'temporal_filter': temporal, 'max_results': max_results}

# Demo
for q in ["What is the current rate for Cedars-Sinai?", 
          "How have rates changed over time?",
          "Compare stop-loss across providers",
          "Does Providence have a transplant carve-out?"]:
    result = classify_query(q)
    print(f"  {q[:50]:<50} -> {result[0]} ({result[1]})")

# COMMAND ----------

# DBTITLE 1,Retrieval Evaluation Runner
def run_retrieval_evaluation(run_id: str = None, strategy: str = 'vs_temporal'):
    """Run evaluation against all annotated queries.
    
    Note: Full evaluation requires live VS endpoint. This function
    provides the framework; actual retrieval calls are mocked until
    the VS endpoint is connected.
    """
    import uuid
    from datetime import datetime
    
    if not run_id:
        run_id = f"ret_eval_{datetime.now().strftime('%Y%m%d_%H%M')}"
    
    queries = spark.sql(f"SELECT * FROM {RETRIEVAL_QUERIES}").collect()
    print(f"  Running evaluation: {len(queries)} queries, strategy={strategy}")
    print(f"  Run ID: {run_id}")
    
    # TODO: Connect to live VS endpoint for actual retrieval
    # For now, log framework readiness
    print(f"\n  ⚠️  Live evaluation requires VS endpoint connection.")
    print(f"  Framework ready. Connect platform/05_retrieval_engine for live eval.")
    print(f"\n  Expected workflow:")
    print(f"    1. For each query: classify -> retrieve -> measure")
    print(f"    2. Compute Recall@K, MRR, NDCG@10 per query")
    print(f"    3. Aggregate metrics, compare to SLOs")
    print(f"    4. Store results in tbl_eval_retrieval_results")
    
    return run_id

run_retrieval_evaluation()

# COMMAND ----------

# DBTITLE 1,Query Distribution
# MAGIC %sql
# MAGIC -- Retrieval evaluation query distribution
# MAGIC SELECT query_type, difficulty, COUNT(*) as cnt
# MAGIC FROM dev_adb.raw.tbl_eval_retrieval_queries
# MAGIC GROUP BY query_type, difficulty
# MAGIC ORDER BY query_type, 
# MAGIC     CASE difficulty WHEN 'easy' THEN 1 WHEN 'medium' THEN 2 WHEN 'hard' THEN 3 END

# COMMAND ----------

# DBTITLE 1,Retrieval Config & Reranker Status
# MAGIC %sql
# MAGIC -- Current retrieval configuration
# MAGIC SELECT config_key, config_value, description
# MAGIC FROM dev_adb.raw.tbl_retrieval_config
# MAGIC ORDER BY config_key;
# MAGIC
# MAGIC -- Reranker deployment status
# MAGIC SELECT model_name, deployment_status, feature_flag_value as enabled,
# MAGIC        max_candidates, return_top_k, notes
# MAGIC FROM dev_adb.raw.tbl_reranker_config
# MAGIC WHERE effective_to IS NULL