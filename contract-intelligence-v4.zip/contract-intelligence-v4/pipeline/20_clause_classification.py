# Databricks notebook source
# DBTITLE 1,Cell 1: Setup — Imports, Config, Auth
"""Cell 1: Setup — Imports, Config, Auth
LLM-classify 57,678 unclassified legal units using Claude Sonnet 4.5 via REST API.
Estimated cost: ~$50 (short output, ~500 input tokens avg per unit)
"""
import requests
import json
import time
import math
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime

# === CONFIG ===
WORKSPACE_URL = "https://adb-640321604414221.1.azuredatabricks.net"
ENDPOINT = f"{WORKSPACE_URL}/serving-endpoints/databricks-claude-sonnet-4-5/invocations"
TOKEN = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiToken().get()
HEADERS = {"Authorization": f"Bearer {TOKEN}", "Content-Type": "application/json"}

# Processing config
MAX_WORKERS = 5
BATCH_SIZE = 500
MAX_RETRIES = 3
BASE_BACKOFF = 2  # seconds
RATE_LIMIT_SLEEP = 30  # seconds on 429
MAX_OUTPUT_TOKENS = 100
TEMPERATURE = 0.0
HTTP_TIMEOUT = 60  # seconds per request

# Checkpoint table
TMP_TABLE = "dev_adb.raw._tmp_clause_classifications"

print(f"Endpoint: {ENDPOINT}")
print(f"Workers: {MAX_WORKERS}, Batch size: {BATCH_SIZE}")
print(f"Config ready at {datetime.now().isoformat()}")

# COMMAND ----------

# DBTITLE 1,Cell 2: Load Taxonomy & Build Classification Prompt
"""Cell 2: Load taxonomy from dim_clause_type_taxonomy, build classification prompt template."""

# Load all 25 clause types
taxonomy_df = spark.sql("""
    SELECT sub_type as clause_type, top_level as category, description 
    FROM dev_adb.raw.dim_clause_type_taxonomy 
    ORDER BY top_level, sub_type
""").toPandas()

print(f"Loaded {len(taxonomy_df)} clause types across {taxonomy_df['category'].nunique()} categories")
print()

# Build the valid clause types list for the prompt
VALID_TYPES = taxonomy_df['clause_type'].tolist()
TYPE_DESCRIPTIONS = "\n".join(
    f"  - {row['clause_type']}: {row['description']}" 
    for _, row in taxonomy_df.iterrows()
)

# Classification prompt template
CLASSIFICATION_PROMPT = f"""You are a classification system. Your ONLY job is to output a single clause_type label.

Valid clause types:
{TYPE_DESCRIPTIONS}

INSTRUCTIONS:
1. Read the contract text below.
2. Output EXACTLY ONE word from the list above (e.g., reimbursement_methodology) or the word "other" if none fit.
3. Do NOT output any other text, explanation, greeting, or punctuation. Just the label.

Contract text:
{{UNIT_TEXT}}

Output:"""

print(f"Prompt template length: {len(CLASSIFICATION_PROMPT)} chars")
print(f"\nValid types ({len(VALID_TYPES)}): {VALID_TYPES}")

# COMMAND ----------

# DBTITLE 1,Cell 3: Load Unclassified Units
"""Cell 3: Load unclassified units (WHERE clause_type IS NULL), establish baseline."""

# Count current state
stats = spark.sql("""
    SELECT 
        COUNT(*) as total,
        COUNT(CASE WHEN clause_type IS NOT NULL THEN 1 END) as classified,
        COUNT(CASE WHEN clause_type IS NULL THEN 1 END) as unclassified
    FROM dev_adb.raw.tbl_retrieval_legal_units
""").collect()[0]

print(f"Total legal units: {stats.total:,}")
print(f"Already classified: {stats.classified:,} ({stats.classified/stats.total*100:.1f}%)")
print(f"Unclassified: {stats.unclassified:,} ({stats.unclassified/stats.total*100:.1f}%)")

# Load unclassified units into a list of dicts
unclassified_df = spark.sql("""
    SELECT unit_id, unit_text
    FROM dev_adb.raw.tbl_retrieval_legal_units
    WHERE clause_type IS NULL
    ORDER BY unit_id
""").toPandas()

print(f"\nLoaded {len(unclassified_df):,} units to classify")
print(f"Avg text length: {unclassified_df['unit_text'].str.len().mean():.0f} chars")
print(f"Max text length: {unclassified_df['unit_text'].str.len().max():,} chars")

# Create checkpoint table if not exists
spark.sql(f"""
    CREATE TABLE IF NOT EXISTS {TMP_TABLE} (
        unit_id STRING,
        clause_type STRING,
        classified_at TIMESTAMP
    ) USING DELTA
""")

# Check how many already checkpointed (resume support)
already_done = spark.sql(f"SELECT COUNT(*) as cnt FROM {TMP_TABLE}").collect()[0].cnt
if already_done > 0:
    print(f"\n⚡ Resuming: {already_done:,} already checkpointed, {len(unclassified_df) - already_done:,} remaining")
    # Filter out already-done units
    done_ids = set(spark.sql(f"SELECT unit_id FROM {TMP_TABLE}").toPandas()['unit_id'].tolist())
    unclassified_df = unclassified_df[~unclassified_df['unit_id'].isin(done_ids)].reset_index(drop=True)
    print(f"  After filtering: {len(unclassified_df):,} units to process")
else:
    print(f"\nFresh start — no prior checkpoints")

# Estimate cost
avg_input_tokens = unclassified_df['unit_text'].str.len().mean() / 2.9 + 200  # text + prompt overhead
total_input = avg_input_tokens * len(unclassified_df)
total_output = 10 * len(unclassified_df)  # ~10 tokens per response
cost_estimate = (total_input / 1_000_000 * 3) + (total_output / 1_000_000 * 15)
print(f"\nEstimated cost: ${cost_estimate:.2f} ({total_input/1_000_000:.1f}M input + {total_output/1_000_000:.2f}M output tokens)")
print(f"Estimated time: {len(unclassified_df) / MAX_WORKERS / 2:.0f} seconds (~{len(unclassified_df) / MAX_WORKERS / 2 / 60:.0f} minutes)")

# COMMAND ----------

# DBTITLE 1,Cell 4: Define classify_unit() with Retry Logic
"""Cell 4: Define classify_unit() — sends unit_text to Claude, returns clause_type.
Includes retry logic with exponential backoff and rate limit handling.
"""

def classify_unit(unit_id: str, unit_text: str) -> dict:
    """Classify a single legal unit text into a clause type via Claude REST API.
    
    Returns: {"unit_id": str, "clause_type": str, "error": str or None}
    """
    # Truncate very long texts to fit context (keep first 8000 chars — enough for classification)
    text_for_prompt = unit_text[:8000] if len(unit_text) > 8000 else unit_text
    prompt = CLASSIFICATION_PROMPT.replace("{{UNIT_TEXT}}", text_for_prompt)
    
    payload = {
        "messages": [
            {"role": "user", "content": prompt}
        ],
        "max_tokens": MAX_OUTPUT_TOKENS,
        "temperature": TEMPERATURE
    }
    
    for attempt in range(MAX_RETRIES):
        try:
            resp = requests.post(
                ENDPOINT, 
                headers=HEADERS, 
                json=payload, 
                timeout=HTTP_TIMEOUT
            )
            
            if resp.status_code == 429:
                # Rate limited — sleep and retry
                sleep_time = RATE_LIMIT_SLEEP * (attempt + 1)
                time.sleep(sleep_time)
                continue
            
            if resp.status_code == 503:
                # Service temporarily unavailable
                time.sleep(BASE_BACKOFF * (2 ** attempt))
                continue
                
            resp.raise_for_status()
            
            result = resp.json()
            raw_type = result["choices"][0]["message"]["content"].strip().lower()
            
            # Clean the response — remove quotes, periods, extra whitespace
            raw_type = raw_type.strip('"\' .\n')
            
            # Validate against known types
            if raw_type in VALID_TYPES:
                return {"unit_id": unit_id, "clause_type": raw_type, "error": None}
            elif raw_type == "other":
                return {"unit_id": unit_id, "clause_type": "other", "error": None}
            else:
                # Try fuzzy match — check if response contains a valid type
                for vt in VALID_TYPES:
                    if vt in raw_type:
                        return {"unit_id": unit_id, "clause_type": vt, "error": None}
                # Default to other if unrecognized
                return {"unit_id": unit_id, "clause_type": "other", "error": f"unrecognized: {raw_type[:50]}"}
                
        except requests.exceptions.Timeout:
            if attempt < MAX_RETRIES - 1:
                time.sleep(BASE_BACKOFF * (2 ** attempt))
                continue
            return {"unit_id": unit_id, "clause_type": None, "error": "timeout_after_retries"}
            
        except requests.exceptions.RequestException as e:
            if attempt < MAX_RETRIES - 1:
                time.sleep(BASE_BACKOFF * (2 ** attempt))
                continue
            return {"unit_id": unit_id, "clause_type": None, "error": str(e)[:100]}
        
        except (KeyError, IndexError, json.JSONDecodeError) as e:
            return {"unit_id": unit_id, "clause_type": None, "error": f"parse_error: {str(e)[:50]}"}
    
    return {"unit_id": unit_id, "clause_type": None, "error": "max_retries_exhausted"}


# Quick sanity test with one unit
if unclassified_df.empty:
    print("No unclassified legal units remain — skipping sanity test.")
else:
    test_unit = unclassified_df.iloc[0]
    test_result = classify_unit(test_unit['unit_id'], test_unit['unit_text'])
    print(f"Sanity test:")
    print(f"  Unit ID: {test_result['unit_id']}")
    print(f"  Classified as: {test_result['clause_type']}")
    print(f"  Error: {test_result['error']}")
    print(f"  Text preview: {test_unit['unit_text'][:200]}...")

# COMMAND ----------

# DBTITLE 1,Cell 5: Batch Processing Loop with Checkpointing
"""Cell 5: Batch processing loop — ThreadPoolExecutor(max_workers=5).
Processes in batches of 500, checkpoints to Delta after each batch.
Prints progress every 100 units.
"""
from pyspark.sql.types import StructType, StructField, StringType, TimestampType

def process_batch(batch_df, batch_num, total_batches):
    """Process a batch of units with concurrent workers."""
    results = []
    errors = 0
    start_time = time.time()
    
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        futures = {
            executor.submit(classify_unit, row['unit_id'], row['unit_text']): row['unit_id']
            for _, row in batch_df.iterrows()
        }
        
        completed = 0
        for future in as_completed(futures):
            result = future.result()
            results.append(result)
            completed += 1
            
            if result['error']:
                errors += 1
            
            if completed % 100 == 0:
                elapsed = time.time() - start_time
                rate = completed / elapsed if elapsed > 0 else 0
                print(f"  Batch {batch_num}/{total_batches}: {completed}/{len(batch_df)} done "
                      f"({rate:.1f} units/sec, {errors} errors)")
    
    return results


def checkpoint_results(results: list):
    """Write batch results to checkpoint Delta table."""
    now = datetime.now()
    valid_results = [
        (r['unit_id'], r['clause_type'], now) 
        for r in results 
        if r['clause_type'] is not None
    ]
    
    if not valid_results:
        return 0
    
    schema = StructType([
        StructField("unit_id", StringType(), False),
        StructField("clause_type", StringType(), False),
        StructField("classified_at", TimestampType(), False)
    ])
    
    df = spark.createDataFrame(valid_results, schema=schema)
    df.write.format("delta").mode("append").saveAsTable(TMP_TABLE)
    return len(valid_results)


# === MAIN PROCESSING LOOP ===
total_units = len(unclassified_df)
total_batches = math.ceil(total_units / BATCH_SIZE)

print(f"Starting classification: {total_units:,} units in {total_batches} batches")
print(f"Workers: {MAX_WORKERS}, Batch size: {BATCH_SIZE}")
print(f"Start time: {datetime.now().isoformat()}")
print("=" * 60)

global_start = time.time()
total_classified = 0
total_errors = 0

for batch_idx in range(total_batches):
    batch_start = batch_idx * BATCH_SIZE
    batch_end = min(batch_start + BATCH_SIZE, total_units)
    batch_df = unclassified_df.iloc[batch_start:batch_end]
    
    print(f"\nBatch {batch_idx + 1}/{total_batches} ({batch_start:,}-{batch_end:,})")
    
    # Process batch
    results = process_batch(batch_df, batch_idx + 1, total_batches)
    
    # Checkpoint
    saved = checkpoint_results(results)
    batch_errors = sum(1 for r in results if r['error'])
    total_classified += saved
    total_errors += batch_errors
    
    # Progress summary
    elapsed = time.time() - global_start
    overall_rate = total_classified / elapsed if elapsed > 0 else 0
    eta_seconds = (total_units - batch_end) / overall_rate if overall_rate > 0 else 0
    
    print(f"  ✓ Checkpoint: {saved} saved | Errors: {batch_errors} | "
          f"Total: {total_classified:,}/{total_units:,} | "
          f"Rate: {overall_rate:.1f}/sec | ETA: {eta_seconds/60:.0f}min")

# Final summary
total_elapsed = time.time() - global_start
print(f"\n{'=' * 60}")
print(f"CLASSIFICATION COMPLETE")
print(f"  Total classified: {total_classified:,}")
print(f"  Total errors: {total_errors:,}")
print(f"  Elapsed: {total_elapsed/60:.1f} minutes")
print(f"  Rate: {total_classified/total_elapsed:.1f} units/sec")
print(f"  End time: {datetime.now().isoformat()}")

# COMMAND ----------

# DBTITLE 1,Cell 6: Merge Results into tbl_retrieval_legal_units
"""Cell 6: Merge results — UPDATE tbl_retrieval_legal_units SET clause_type from checkpoint table."""

# Count checkpoint results
checkpoint_count = spark.sql(f"SELECT COUNT(*) as cnt FROM {TMP_TABLE}").collect()[0].cnt
print(f"Checkpoint table has {checkpoint_count:,} classified units")

# Merge into main table
print(f"\nMerging into tbl_retrieval_legal_units...")
spark.sql(f"""
    MERGE INTO dev_adb.raw.tbl_retrieval_legal_units target
    USING {TMP_TABLE} source
    ON target.unit_id = source.unit_id
    WHEN MATCHED AND target.clause_type IS NULL THEN
        UPDATE SET target.clause_type = source.clause_type
""")
print("✅ Merge complete")

# Verify new state
post_stats = spark.sql("""
    SELECT 
        COUNT(*) as total,
        COUNT(CASE WHEN clause_type IS NOT NULL THEN 1 END) as classified,
        COUNT(CASE WHEN clause_type IS NULL THEN 1 END) as still_null
    FROM dev_adb.raw.tbl_retrieval_legal_units
""").collect()[0]

print(f"\nPost-merge state:")
print(f"  Total: {post_stats.total:,}")
print(f"  Classified: {post_stats.classified:,} ({post_stats.classified/post_stats.total*100:.1f}%)")
print(f"  Still NULL: {post_stats.still_null:,} ({post_stats.still_null/post_stats.total*100:.1f}%)")
print(f"\n  Coverage improvement: 23.4% → {post_stats.classified/post_stats.total*100:.1f}%")

# COMMAND ----------

# DBTITLE 1,Cell 7: Validation & Quality Metrics Update
"""Cell 7: Validation — distribution by clause_type, update quality metrics, cleanup."""

# Distribution of classifications
print("Clause Type Distribution (after LLM classification):")
print("=" * 60)

dist = spark.sql("""
    SELECT 
        clause_type,
        COUNT(*) as cnt,
        ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER(), 1) as pct
    FROM dev_adb.raw.tbl_retrieval_legal_units
    WHERE clause_type IS NOT NULL
    GROUP BY clause_type
    ORDER BY cnt DESC
""").collect()

print(f"{'Clause Type':<40} {'Count':>8} {'Pct':>6}")
print("-" * 56)
for row in dist:
    print(f"{row.clause_type:<40} {row.cnt:>8,} {row.pct:>5.1f}%")

# Compare heuristic vs LLM classified
print(f"\n\nClassification Source Comparison:")
source_stats = spark.sql(f"""
    SELECT 
        CASE WHEN t.unit_id IS NOT NULL THEN 'llm_classified' ELSE 'heuristic_classified' END as source,
        COUNT(*) as cnt
    FROM dev_adb.raw.tbl_retrieval_legal_units lu
    LEFT JOIN {TMP_TABLE} t ON lu.unit_id = t.unit_id
    WHERE lu.clause_type IS NOT NULL
    GROUP BY 1
""").collect()
for row in source_stats:
    print(f"  {row.source}: {row.cnt:,}")

# Update observability quality metrics
final_coverage = spark.sql("""
    SELECT ROUND(COUNT(CASE WHEN clause_type IS NOT NULL THEN 1 END) * 100.0 / COUNT(*), 1)
    FROM dev_adb.raw.tbl_retrieval_legal_units
""").collect()[0][0]

spark.sql(f"""
    INSERT INTO dev_adb.raw.tbl_obs_quality_metrics VALUES (
        'qm_clause_coverage_' || DATE_FORMAT(CURRENT_TIMESTAMP(), 'yyyyMMdd_HHmmss'),
        CURRENT_TIMESTAMP(),
        'clause_type_coverage_pct',
        {final_coverage},
        'percent',
        'tbl_retrieval_legal_units',
        'clause_type',
        90.0,
        50.0,
        CASE WHEN {final_coverage} >= 90 THEN 'OK' ELSE 'WARNING' END,
        '6.0.0',
        'LLM classification of 57K units via Claude Sonnet 4.5 REST API'
    )
""")
print(f"\n✅ Quality metric recorded: clause_type_coverage = {final_coverage}%")

# Cleanup: drop temp table (optional — keep for audit trail)
# spark.sql(f"DROP TABLE IF EXISTS {TMP_TABLE}")
print(f"\n💡 Checkpoint table {TMP_TABLE} retained for audit trail.")
print(f"   Run 'DROP TABLE {TMP_TABLE}' to clean up when satisfied.")

print(f"\n{'=' * 60}")
print(f"CLAUSE CLASSIFICATION COMPLETE")
print(f"  Coverage: 23.4% → {final_coverage}%")
print(f"  Method: Claude Sonnet 4.5 REST API, 5 workers, batch 500")
print(f"  Taxonomy: 25 types + 'other' fallback")
print(f"{'=' * 60}")