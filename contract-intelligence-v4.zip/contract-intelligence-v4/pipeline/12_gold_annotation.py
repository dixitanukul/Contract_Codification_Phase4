# Databricks notebook source
# DBTITLE 1,Gold Annotation Framework
# Gold Annotation Framework — Wave 1
# BSC Provider Contract Intelligence Platform
#
# Purpose: Infrastructure for human annotation of extraction quality.
# Creates the workflow for reviewers to verify LLM extraction accuracy
# against source PDFs and compute field-level F1 scores.
#
# Tables:
#   - tbl_eval_gold_sample: 200 stratified files for annotation
#   - tbl_eval_gold_annotations: Per-field ground truth judgments
#   - tbl_eval_f1_scores: Computed precision/recall/F1 by scope
#   - vw_annotation_queue: Reviewer work queue
#   - vw_annotation_field_spec: 30 critical fields to verify
#
# Workflow:
#   1. Run "Annotation Queue" section to see what needs review
#   2. Use review_file(sample_id) to see extraction vs source
#   3. Use submit_annotation() to record findings
#   4. Run compute_f1() to update scores after annotations

# COMMAND ----------

# DBTITLE 1,Configuration
# Configuration
SCHEMA = "dev_adb.raw"
PDF_VOLUME = "/Volumes/prod_adb/default/ext-data-volume-stmlz/Health_Plan_Ops_Transformation/Provider_Contracts"
JSON_PATH = "/Workspace/Users/adixit01@blueshieldca.com/Contract_Codification_Pipeline/data/json_extract"

# Field severity weights for weighted F1
SEVERITY_WEIGHTS = {"CRITICAL": 3.0, "MAJOR": 2.0, "MINOR": 1.0, "COSMETIC": 0.5}

# COMMAND ----------

# DBTITLE 1,Annotation Queue
# MAGIC %sql
# MAGIC -- Annotation Queue: Files needing human review
# MAGIC -- Priority order: COMPLEX first, fewest existing annotations first
# MAGIC SELECT 
# MAGIC     sample_id,
# MAGIC     provider_name,
# MAGIC     doc_role,
# MAGIC     complexity_tier,
# MAGIC     existing_annotations,
# MAGIC     human_verified,
# MAGIC     review_status,
# MAGIC     ROUND(review_priority, 2) as priority
# MAGIC FROM dev_adb.raw.vw_annotation_queue
# MAGIC ORDER BY review_priority DESC
# MAGIC LIMIT 20

# COMMAND ----------

# DBTITLE 1,Review File Function
import json, os
from datetime import datetime

def review_file(sample_id: int):
    """Display extraction data for a gold sample file alongside source info.
    
    Shows: extracted rates, dates, terms, clauses — everything the LLM produced.
    Reviewer compares against the original PDF to mark correct/incorrect.
    """
    # Get sample metadata
    sample = spark.sql(f"""
        SELECT * FROM {SCHEMA}.tbl_eval_gold_sample WHERE sample_id = {sample_id}
    """).collect()
    
    if not sample:
        print(f"❌ Sample ID {sample_id} not found")
        return
    
    s = sample[0]
    print(f"{'='*80}")
    print(f"REVIEW FILE: Sample #{s.sample_id}")
    print(f"{'='*80}")
    print(f"  Provider:    {s.provider_name} ({s.provider_id})")
    print(f"  Doc Type:    {s.doc_role}")
    print(f"  Complexity:  {s.complexity_tier}")
    print(f"  File:        {s.source_filename}")
    print(f"  Status:      {s.annotation_status}")
    
    # Show extracted rates
    print(f"\n--- EXTRACTED RATES ---")
    rates = spark.sql(f"""
        SELECT rate_domain, service_line, formula_type, rate_numeric, rate_text, rate_unit
        FROM {SCHEMA}.tbl_reimb_rate_rules
        WHERE source_filename = '{s.source_filename}'
        ORDER BY rate_domain, service_line
    """).toPandas()
    if len(rates) > 0:
        display(rates.head(20))
        if len(rates) > 20:
            print(f"  ... and {len(rates)-20} more rates")
    else:
        print("  (no rates extracted)")
    
    # Show extracted terms
    print(f"\n--- EXTRACTED TERMS ---")
    terms = spark.sql(f"""
        SELECT effective_date, expiration_date, auto_renewal, contract_term_years,
               prior_rates_superseded, rate_count, amendment_order
        FROM {SCHEMA}.tbl_genie_amendment_timeline
        WHERE source_filename = '{s.source_filename}'
    """).toPandas()
    if len(terms) > 0:
        display(terms)
    
    # Show existing annotations for this file
    print(f"\n--- EXISTING ANNOTATIONS ---")
    annotations = spark.sql(f"""
        SELECT field_category, field_name, extracted_value, gold_value, 
               is_correct, error_type, confidence_source
        FROM {SCHEMA}.tbl_eval_gold_annotations
        WHERE sample_id = {sample_id}
        ORDER BY field_category, field_name
    """).toPandas()
    if len(annotations) > 0:
        display(annotations)
    else:
        print("  (no annotations yet)")
    
    # Show PDF path for manual review
    parts = s.source_filename.split('_')
    provider_folder = f"{parts[0]}_{parts[1]}" if len(parts) >= 2 else parts[0]
    print(f"\n--- PDF LOCATION ---")
    print(f"  {PDF_VOLUME}/{provider_folder}/{s.source_filename}")
    
    # Show JSON extraction path
    json_file = s.source_filename.replace('.pdf', '.json')
    print(f"  {JSON_PATH}/{json_file}")
    
    return s.source_filename


# Usage: review_file(1)

# COMMAND ----------

# DBTITLE 1,Submit Annotations
from pyspark.sql.functions import lit, current_timestamp

def submit_annotation(
    sample_id: int,
    field_category: str,
    field_name: str,
    extracted_value: str,
    gold_value: str,
    is_correct: bool,
    error_type: str = None,
    pdf_page: int = None,
    pdf_excerpt: str = None,
    severity: str = "MAJOR",
    annotator: str = "human_reviewer"
):
    """Submit a single field annotation to the gold dataset.
    
    Args:
        sample_id: Which file (from tbl_eval_gold_sample)
        field_category: RATE | CLAUSE | DATE | PARTY | TERM | FINANCIAL | METADATA
        field_name: Specific field (e.g., 'inpatient_per_diem')
        extracted_value: What the LLM extracted
        gold_value: Correct value per human review
        is_correct: True if extraction matches gold
        error_type: HALLUCINATION | OMISSION | WRONG_VALUE | WRONG_SCOPE | TRUNCATION
        pdf_page: Page number where gold value found
        pdf_excerpt: Verbatim text from PDF (<=500 chars)
        severity: CRITICAL | MAJOR | MINOR | COSMETIC
        annotator: Reviewer identifier
    """
    # Get source_filename
    sample = spark.sql(f"""
        SELECT source_filename FROM {SCHEMA}.tbl_eval_gold_sample WHERE sample_id = {sample_id}
    """).collect()
    if not sample:
        print(f"❌ Sample ID {sample_id} not found")
        return
    
    source_filename = sample[0].source_filename
    annotation_id = f"HUMAN_{sample_id}_{field_name}"
    
    spark.sql(f"""
        INSERT INTO {SCHEMA}.tbl_eval_gold_annotations VALUES (
            '{annotation_id}',
            {sample_id},
            '{source_filename}',
            '{field_category}',
            '{field_name}',
            '{extracted_value}',
            '{gold_value}',
            {str(is_correct).lower()},
            {'NULL' if error_type is None else f"'{error_type}'"},
            'HUMAN_VERIFIED',
            {pdf_page if pdf_page else 'NULL'},
            {'NULL' if pdf_excerpt is None else f"'{pdf_excerpt.replace(chr(39), chr(39)+chr(39))}'"},
            '{severity}',
            '{annotator}',
            CURRENT_TIMESTAMP(),
            'v6_production'
        )
    """)
    print(f"✅ Annotation saved: {field_category}/{field_name} = {'CORRECT' if is_correct else error_type}")


def submit_batch_annotations(sample_id: int, annotations: list, annotator: str = "human_reviewer"):
    """Submit multiple annotations for one file.
    
    Args:
        sample_id: File to annotate
        annotations: List of dicts with keys: field_category, field_name, 
                    extracted_value, gold_value, is_correct, error_type, severity
        annotator: Reviewer ID
    """
    for a in annotations:
        submit_annotation(
            sample_id=sample_id,
            annotator=annotator,
            **a
        )
    
    # Update sample status
    spark.sql(f"""
        UPDATE {SCHEMA}.tbl_eval_gold_sample
        SET annotation_status = 'COMPLETE',
            annotator = '{annotator}',
            annotation_date = CURRENT_DATE()
        WHERE sample_id = {sample_id}
    """)
    print(f"\n✅ {len(annotations)} annotations submitted for sample #{sample_id}")

# COMMAND ----------

# DBTITLE 1,Compute F1 Scores
def compute_f1(run_label: str = None):
    """Compute F1 scores across all scopes and save to tbl_eval_f1_scores.
    
    Scopes: OVERALL, BY_CATEGORY, BY_FIELD, BY_DOC_TYPE
    Only uses HUMAN_VERIFIED annotations for the official score.
    """
    if run_label is None:
        run_label = f"f1_{datetime.now().strftime('%Y-%m-%d_%H%M')}"
    
    # Clear previous run with same label
    spark.sql(f"DELETE FROM {SCHEMA}.tbl_eval_f1_scores WHERE run_id = '{run_label}'")
    
    # BY_CATEGORY
    spark.sql(f"""
        INSERT INTO {SCHEMA}.tbl_eval_f1_scores
        SELECT
            '{run_label}' as run_id,
            CURRENT_TIMESTAMP() as run_timestamp,
            'BY_CATEGORY' as scope,
            field_category as scope_value,
            COUNT(*) as total_annotations,
            SUM(CASE WHEN is_correct = TRUE THEN 1 ELSE 0 END) as true_positives,
            SUM(CASE WHEN is_correct = FALSE AND error_type != 'OMISSION' THEN 1 ELSE 0 END) as false_positives,
            SUM(CASE WHEN error_type = 'OMISSION' THEN 1 ELSE 0 END) as false_negatives,
            0 as true_negatives,
            CASE WHEN SUM(CASE WHEN is_correct THEN 1 ELSE 0 END) + SUM(CASE WHEN is_correct = FALSE AND error_type != 'OMISSION' THEN 1 ELSE 0 END) > 0
                THEN CAST(SUM(CASE WHEN is_correct THEN 1 ELSE 0 END) AS FLOAT) / 
                     (SUM(CASE WHEN is_correct THEN 1 ELSE 0 END) + SUM(CASE WHEN is_correct = FALSE AND error_type != 'OMISSION' THEN 1 ELSE 0 END))
                ELSE NULL END as precision_score,
            CASE WHEN SUM(CASE WHEN is_correct THEN 1 ELSE 0 END) + SUM(CASE WHEN error_type = 'OMISSION' THEN 1 ELSE 0 END) > 0
                THEN CAST(SUM(CASE WHEN is_correct THEN 1 ELSE 0 END) AS FLOAT) /
                     (SUM(CASE WHEN is_correct THEN 1 ELSE 0 END) + SUM(CASE WHEN error_type = 'OMISSION' THEN 1 ELSE 0 END))
                ELSE NULL END as recall_score,
            CASE WHEN (2 * SUM(CASE WHEN is_correct THEN 1 ELSE 0 END) + 
                      SUM(CASE WHEN is_correct = FALSE THEN 1 ELSE 0 END)) > 0
                THEN CAST(2 * SUM(CASE WHEN is_correct THEN 1 ELSE 0 END) AS FLOAT) /
                     (2 * SUM(CASE WHEN is_correct THEN 1 ELSE 0 END) + SUM(CASE WHEN is_correct = FALSE THEN 1 ELSE 0 END))
                ELSE NULL END as f1_score,
            CAST(SUM(CASE WHEN is_correct THEN 1 ELSE 0 END) AS FLOAT) / COUNT(*) as accuracy,
            CAST(SUM(CASE WHEN error_type = 'HALLUCINATION' THEN 1 ELSE 0 END) AS FLOAT) / COUNT(*) as error_rate_hallucination,
            CAST(SUM(CASE WHEN error_type = 'OMISSION' THEN 1 ELSE 0 END) AS FLOAT) / COUNT(*) as error_rate_omission,
            'v6_production' as pipeline_version,
            'Human-verified annotations only' as notes
        FROM {SCHEMA}.tbl_eval_gold_annotations
        WHERE is_correct IS NOT NULL
        GROUP BY field_category
    """)
    
    # OVERALL
    spark.sql(f"""
        INSERT INTO {SCHEMA}.tbl_eval_f1_scores
        SELECT
            '{run_label}' as run_id,
            CURRENT_TIMESTAMP() as run_timestamp,
            'OVERALL' as scope,
            'ALL' as scope_value,
            COUNT(*) as total_annotations,
            SUM(CASE WHEN is_correct = TRUE THEN 1 ELSE 0 END) as true_positives,
            SUM(CASE WHEN is_correct = FALSE AND error_type != 'OMISSION' THEN 1 ELSE 0 END) as false_positives,
            SUM(CASE WHEN error_type = 'OMISSION' THEN 1 ELSE 0 END) as false_negatives,
            0 as true_negatives,
            CASE WHEN SUM(CASE WHEN is_correct THEN 1 ELSE 0 END) + SUM(CASE WHEN is_correct = FALSE AND error_type != 'OMISSION' THEN 1 ELSE 0 END) > 0
                THEN CAST(SUM(CASE WHEN is_correct THEN 1 ELSE 0 END) AS FLOAT) / 
                     (SUM(CASE WHEN is_correct THEN 1 ELSE 0 END) + SUM(CASE WHEN is_correct = FALSE AND error_type != 'OMISSION' THEN 1 ELSE 0 END))
                ELSE NULL END as precision_score,
            CASE WHEN SUM(CASE WHEN is_correct THEN 1 ELSE 0 END) + SUM(CASE WHEN error_type = 'OMISSION' THEN 1 ELSE 0 END) > 0
                THEN CAST(SUM(CASE WHEN is_correct THEN 1 ELSE 0 END) AS FLOAT) /
                     (SUM(CASE WHEN is_correct THEN 1 ELSE 0 END) + SUM(CASE WHEN error_type = 'OMISSION' THEN 1 ELSE 0 END))
                ELSE NULL END as recall_score,
            CASE WHEN (2 * SUM(CASE WHEN is_correct THEN 1 ELSE 0 END) + 
                      SUM(CASE WHEN is_correct = FALSE THEN 1 ELSE 0 END)) > 0
                THEN CAST(2 * SUM(CASE WHEN is_correct THEN 1 ELSE 0 END) AS FLOAT) /
                     (2 * SUM(CASE WHEN is_correct THEN 1 ELSE 0 END) + SUM(CASE WHEN is_correct = FALSE THEN 1 ELSE 0 END))
                ELSE NULL END as f1_score,
            CAST(SUM(CASE WHEN is_correct THEN 1 ELSE 0 END) AS FLOAT) / COUNT(*) as accuracy,
            CAST(SUM(CASE WHEN error_type = 'HALLUCINATION' THEN 1 ELSE 0 END) AS FLOAT) / COUNT(*) as error_rate_hallucination,
            CAST(SUM(CASE WHEN error_type = 'OMISSION' THEN 1 ELSE 0 END) AS FLOAT) / COUNT(*) as error_rate_omission,
            'v6_production' as pipeline_version,
            'All verified annotations' as notes
        FROM {SCHEMA}.tbl_eval_gold_annotations
        WHERE is_correct IS NOT NULL
    """)
    
    # Display results
    print(f"\n{'='*60}")
    print(f"F1 SCORES — Run: {run_label}")
    print(f"{'='*60}")
    results = spark.sql(f"""
        SELECT scope_value, total_annotations,
            ROUND(precision_score, 4) as prec,
            ROUND(recall_score, 4) as recall,
            ROUND(f1_score, 4) as f1,
            ROUND(error_rate_hallucination, 4) as halluc_rate,
            ROUND(error_rate_omission, 4) as omission_rate
        FROM {SCHEMA}.tbl_eval_f1_scores
        WHERE run_id = '{run_label}'
        ORDER BY CASE WHEN scope = 'OVERALL' THEN 0 ELSE 1 END, total_annotations DESC
    """).toPandas()
    display(results)
    return run_label

# Usage: compute_f1()

# COMMAND ----------

# DBTITLE 1,Regression Gate
def regression_gate(current_run_id: str, baseline_run_id: str = 'f1_2026-06-05_bootstrap', threshold: float = 0.05):
    """Compare current F1 to baseline. FAIL if any category drops > threshold.
    
    This is the regression gate for extraction pipeline changes.
    Before deploying new prompts or model changes, run this to ensure quality holds.
    
    Args:
        current_run_id: Run ID of the new evaluation
        baseline_run_id: Run ID to compare against
        threshold: Maximum allowed F1 drop (default 5%)
    
    Returns:
        True if gate passes, False if regression detected
    """
    comparison = spark.sql(f"""
        SELECT 
            c.scope_value as category,
            c.f1_score as current_f1,
            b.f1_score as baseline_f1,
            c.f1_score - b.f1_score as f1_delta,
            CASE WHEN c.f1_score < b.f1_score - {threshold} THEN 'FAIL' ELSE 'PASS' END as gate_status
        FROM {SCHEMA}.tbl_eval_f1_scores c
        JOIN {SCHEMA}.tbl_eval_f1_scores b 
            ON c.scope_value = b.scope_value AND c.scope = b.scope
        WHERE c.run_id = '{current_run_id}'
          AND b.run_id = '{baseline_run_id}'
          AND c.scope = 'BY_CATEGORY'
        ORDER BY f1_delta ASC
    """).toPandas()
    
    if len(comparison) == 0:
        print("⚠️  No comparison data found. Check run IDs.")
        return None
    
    failures = comparison[comparison['gate_status'] == 'FAIL']
    
    print(f"\n{'='*60}")
    print(f"REGRESSION GATE: {current_run_id} vs {baseline_run_id}")
    print(f"Threshold: F1 drop > {threshold:.0%} = FAIL")
    print(f"{'='*60}")
    display(comparison)
    
    if len(failures) > 0:
        print(f"\n❌ GATE FAILED: {len(failures)} categories regressed")
        for _, row in failures.iterrows():
            print(f"   {row['category']}: {row['baseline_f1']:.3f} → {row['current_f1']:.3f} ({row['f1_delta']:+.3f})")
        return False
    else:
        print(f"\n✅ GATE PASSED: No regressions detected")
        return True

# Usage: regression_gate('f1_new_run', 'f1_2026-06-05_bootstrap')

# COMMAND ----------

# DBTITLE 1,F1 Score History
# MAGIC %sql
# MAGIC -- Current F1 Scores Summary
# MAGIC SELECT 
# MAGIC     run_id,
# MAGIC     scope,
# MAGIC     scope_value,
# MAGIC     total_annotations,
# MAGIC     ROUND(precision_score, 3) as precision,
# MAGIC     ROUND(recall_score, 3) as recall,
# MAGIC     ROUND(f1_score, 3) as f1,
# MAGIC     ROUND(error_rate_hallucination, 4) as halluc_rate,
# MAGIC     ROUND(error_rate_omission, 4) as omission_rate,
# MAGIC     run_timestamp
# MAGIC FROM dev_adb.raw.tbl_eval_f1_scores
# MAGIC ORDER BY run_timestamp DESC, scope, scope_value