"""
tests/test_extraction_regression.py

W6-4: Extraction regression gate.

Runs the V6 extraction pipeline components against golden baselines
stored in tests/fixtures/extraction_baselines.json. No LLM calls needed.

Gate purpose
------------
When extraction prompts, validation rules, or chunking parameters change,
this suite detects quality regressions BEFORE they reach production:
  - Every baseline must still pass validate_extraction() with no errors
  - rate_numeric population stays above the per-baseline minimum
  - Date validity stays above per-baseline minimum
  - Required sections are found
  - Aggregate success rate across all baselines >= PASS_THRESHOLD (0.90)

Adding new golden snapshots
---------------------------
When a significant contract is added to the corpus, capture a known-good
extraction in extraction_baselines.json and it will be picked up automatically.
"""
from __future__ import annotations

import json
import os
import sys
import pytest

# Allow both direct run and pytest from repo root
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))
from validation import validate_extraction, ValidationResult
from json_repair import clean_json_response, repair_truncated_json, repair_trailing_commas
from chunking import chunk_text, needs_chunking, estimate_tokens


# ============================================================================
# Constants
# ============================================================================

FIXTURES_PATH = os.path.join(os.path.dirname(__file__), 'fixtures', 'extraction_baselines.json')
PASS_THRESHOLD = 0.90       # 90% of baselines must pass for aggregate gate
RATE_NUMERIC_FLOOR = 0.80   # >= 80% of rates must have rate_numeric (where expected)


# ============================================================================
# Fixture loading
# ============================================================================

def _load_baselines() -> list[dict]:
    with open(FIXTURES_PATH) as f:
        data = json.load(f)
    return data["baselines"]


_BASELINES = _load_baselines()


def _get(baseline_id: str) -> dict:
    for b in _BASELINES:
        if b["id"] == baseline_id:
            return b
    raise KeyError(f"Baseline {baseline_id} not found")


# ============================================================================
# Category 1: Fixture integrity (2 tests)
# ============================================================================

class TestFixtureIntegrity:

    def test_baselines_file_loads(self):
        """Fixture file exists and contains expected keys."""
        assert len(_BASELINES) >= 6
        for b in _BASELINES:
            assert "id" in b
            assert "doc_type" in b
            assert "extraction" in b
            assert "expected_metrics" in b

    def test_all_baseline_ids_unique(self):
        ids = [b["id"] for b in _BASELINES]
        assert len(ids) == len(set(ids)), "Duplicate baseline IDs"


# ============================================================================
# Category 2: Per-baseline validation (6 tests — one per baseline)
# ============================================================================

class TestPerBaselineValidation:

    @pytest.mark.parametrize("baseline_id", ["BL01", "BL02", "BL03", "BL04", "BL05", "BL06"])
    def test_baseline_passes_validation(self, baseline_id):
        """Every golden baseline must pass validate_extraction() with no errors."""
        b      = _get(baseline_id)
        result = validate_extraction(b["extraction"], b["doc_type"])
        assert result.errors == [], (
            f"{baseline_id} ({b['doc_type']}) has validation errors: {result.errors}"
        )


# ============================================================================
# Category 3: Rate metric floors (4 tests)
# ============================================================================

class TestRateMetricFloors:

    def test_BL01_rate_numeric_count(self):
        b = _get("BL01")
        result = validate_extraction(b["extraction"], b["doc_type"])
        expected_min = b["expected_metrics"]["rates_with_numeric_min"]
        assert result.rates_with_numeric >= expected_min, (
            f"BL01: rates_with_numeric {result.rates_with_numeric} < {expected_min}"
        )

    def test_BL05_complex_all_rates_numeric(self):
        """Complex capitation contract: all 5 rates must have numeric values."""
        b = _get("BL05")
        result = validate_extraction(b["extraction"], b["doc_type"])
        assert result.rates_with_numeric == 5

    def test_rate_numeric_floor_across_rate_baselines(self):
        """Aggregate rate_numeric coverage >= RATE_NUMERIC_FLOOR for rate-heavy baselines."""
        rate_baselines = [b for b in _BASELINES
                          if b["expected_metrics"]["rates_with_numeric_min"] > 0]
        total_rates   = 0
        total_numeric = 0
        for b in rate_baselines:
            result = validate_extraction(b["extraction"], b["doc_type"])
            total_rates   += result.rates_count
            total_numeric += result.rates_with_numeric
        actual_pct = total_numeric / total_rates if total_rates > 0 else 0.0
        assert actual_pct >= RATE_NUMERIC_FLOOR, (
            f"rate_numeric coverage {actual_pct:.2%} < floor {RATE_NUMERIC_FLOOR:.2%}"
        )

    def test_no_negative_rates_in_any_baseline(self):
        """No baseline should contain negative rate_numeric values."""
        for b in _BASELINES:
            result = validate_extraction(b["extraction"], b["doc_type"])
            neg_errors = [e for e in result.errors if "negative" in e]
            assert not neg_errors, f"{b['id']}: {neg_errors}"


# ============================================================================
# Category 4: Date validity (3 tests)
# ============================================================================

class TestDateValidity:

    @pytest.mark.parametrize("baseline_id", ["BL01", "BL02", "BL03", "BL04", "BL05", "BL06"])
    def test_date_validity_meets_minimum(self, baseline_id):
        b          = _get(baseline_id)
        result     = validate_extraction(b["extraction"], b["doc_type"])
        min_valid  = b["expected_metrics"]["dates_valid_min"]
        assert result.dates_valid >= min_valid, (
            f"{baseline_id}: dates_valid {result.dates_valid} < {min_valid}; "
            f"dates_count={result.dates_count}"
        )

    def test_no_future_dates_past_2035(self):
        """No baseline should have dates beyond the 2035 contract horizon."""
        for b in _BASELINES:
            result = validate_extraction(b["extraction"], b["doc_type"])
            future_warnings = [w for w in result.warnings if "invalid date" in w.lower()]
            assert not future_warnings, f"{b['id']}: future dates found — {future_warnings}"


# ============================================================================
# Category 5: Section coverage (2 tests)
# ============================================================================

class TestSectionCoverage:

    @pytest.mark.parametrize("baseline_id", ["BL01", "BL02", "BL03", "BL04", "BL05", "BL06"])
    def test_section_count_meets_minimum(self, baseline_id):
        b          = _get(baseline_id)
        result     = validate_extraction(b["extraction"], b["doc_type"])
        min_sects  = b["expected_metrics"]["sections_found_min"]
        assert len(result.sections_found) >= min_sects, (
            f"{baseline_id}: sections_found {result.sections_found} < min {min_sects}"
        )


# ============================================================================
# Category 6: JSON repair round-trip (3 tests)
# ============================================================================

class TestJsonRepairRoundTrip:

    def test_baseline_json_survives_clean_and_reload(self):
        """Serialise each baseline extraction to JSON, clean, and reload cleanly."""
        for b in _BASELINES:
            raw  = json.dumps(b["extraction"])
            clean = clean_json_response(raw)
            reloaded = json.loads(clean)
            assert reloaded == b["extraction"], f"{b['id']}: round-trip failed"

    def test_markdown_wrapped_json_cleaned_correctly(self):
        """clean_json_response() strips ```json fences."""
        payload  = _get("BL01")["extraction"]
        wrapped  = "```json\n" + json.dumps(payload) + "\n```"
        cleaned  = clean_json_response(wrapped)
        reloaded = json.loads(cleaned)
        assert reloaded["contract_info"]["provider"] == "Cedars-Sinai Medical Center"

    def test_trailing_comma_repair(self):
        """repair_trailing_commas() fixes JSON that would otherwise fail json.loads()."""
        broken = '{"a": 1, "b": 2, "rates": [1, 2, 3,],}'
        fixed  = repair_trailing_commas(broken)
        obj    = json.loads(fixed)
        assert obj["a"] == 1
        assert obj["rates"] == [1, 2, 3]


# ============================================================================
# Category 7: Regression detection (3 tests)
# ============================================================================

class TestRegressionDetection:

    def test_gate_detects_missing_rate_numeric(self):
        """Removing rate_numeric from all rates should drop rates_with_numeric to 0."""
        import copy
        b           = copy.deepcopy(_get("BL01"))
        for rate in b["extraction"]["reimbursement_rates"]:
            rate.pop("rate_numeric", None)
        result = validate_extraction(b["extraction"], b["doc_type"])
        assert result.rates_with_numeric == 0
        expected_min = b["expected_metrics"]["rates_with_numeric_min"]
        # Gate should now fail the floor test
        assert result.rates_with_numeric < expected_min

    def test_gate_detects_hallucinated_structure(self):
        """Extraction with no expected sections produces validation error."""
        hallucinated = {"random_key": "value", "another": {"nested": True}}
        result = validate_extraction(hallucinated, "base_agreement")
        assert result.valid is False
        assert any("hallucinated" in e.lower() or "no expected" in e.lower()
                   for e in result.errors)

    def test_gate_detects_negative_rate(self):
        """Negative rate_numeric in extraction should trigger validation error."""
        import copy
        b = copy.deepcopy(_get("BL01"))
        b["extraction"]["reimbursement_rates"][0]["rate_numeric"] = -500
        result = validate_extraction(b["extraction"], b["doc_type"])
        assert result.valid is False
        assert any("negative" in e for e in result.errors)


# ============================================================================
# Category 8: Aggregate gate (2 tests)
# ============================================================================

class TestAggregateGate:

    def test_aggregate_pass_rate_meets_threshold(self):
        """
        W6-4 CI gate: >= PASS_THRESHOLD (90%) of all baselines must pass
        validate_extraction() with no errors.
        """
        passed = 0
        failed_ids = []
        for b in _BASELINES:
            result = validate_extraction(b["extraction"], b["doc_type"])
            if not result.errors:
                passed += 1
            else:
                failed_ids.append(b["id"])
        actual = passed / len(_BASELINES)
        assert actual >= PASS_THRESHOLD, (
            f"Aggregate pass rate {actual:.2%} < {PASS_THRESHOLD:.2%}. "
            f"Failed baselines: {failed_ids}"
        )

    def test_all_baselines_currently_pass(self):
        """Every baseline should pass at this commit — 100% is the production bar."""
        for b in _BASELINES:
            result = validate_extraction(b["extraction"], b["doc_type"])
            assert result.errors == [], (
                f"{b['id']} ({b['doc_type']}) has errors: {result.errors}"
            )


# ============================================================================
# Category 9: Chunking integration (2 tests)
# ============================================================================

class TestChunkingIntegration:

    def test_short_contract_does_not_need_chunking(self):
        """A short extraction payload (< 150K chars) should not trigger chunking."""
        short_text = json.dumps(_get("BL01")["extraction"])
        assert not needs_chunking(short_text)

    def test_large_contract_chunks_correctly(self):
        """A 200K-char text should be split into multiple chunks with overlap."""
        large_text = "PROVIDER CONTRACT SECTION.\n\n" + ("A" * 200_000)
        chunks = chunk_text(large_text, chunk_size=80_000, overlap=2_000)
        assert len(chunks) >= 3
        # Verify overlap: end of chunk N overlaps start of chunk N+1
        for i in range(len(chunks) - 1):
            assert chunks[i].end_char >= chunks[i+1].start_char


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
