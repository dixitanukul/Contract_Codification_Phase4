"""Unit tests for src/chunking.py

10+ test cases covering:
- Short text (no chunking)
- Boundary detection at section headers
- Boundary detection at paragraphs
- Overlap correctness
- Token estimation
- Merge strategy for chunk results
- Empty input handling
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

import pytest
from chunking import (
    needs_chunking,
    estimate_tokens,
    chunk_text,
    merge_chunk_results,
    Chunk,
    MAX_CHARS_SINGLE_CALL,
    CHUNK_SIZE,
    OVERLAP,
)


class TestNeedsChunking:
    def test_short_text_no_chunking(self):
        assert needs_chunking("Hello world") is False

    def test_at_threshold_no_chunking(self):
        text = "x" * MAX_CHARS_SINGLE_CALL
        assert needs_chunking(text) is False

    def test_above_threshold_needs_chunking(self):
        text = "x" * (MAX_CHARS_SINGLE_CALL + 1)
        assert needs_chunking(text) is True

    def test_empty_no_chunking(self):
        assert needs_chunking("") is False


class TestEstimateTokens:
    def test_known_ratio(self):
        # 2.9 chars per token
        tokens = estimate_tokens("x" * 2900)
        assert tokens == 1000

    def test_empty(self):
        assert estimate_tokens("") == 0

    def test_single_char(self):
        assert estimate_tokens("x") == 0  # rounds down


class TestChunkText:
    def test_short_text_single_chunk(self):
        chunks = chunk_text("Short text")
        assert len(chunks) == 1
        assert chunks[0].index == 0
        assert chunks[0].total_chunks == 1
        assert chunks[0].text == "Short text"

    def test_empty_text(self):
        chunks = chunk_text("")
        assert len(chunks) == 1
        assert chunks[0].text == ""

    def test_long_text_produces_multiple_chunks(self):
        # Create text that needs chunking (>150K chars)
        text = "A" * 200_000
        chunks = chunk_text(text)
        assert len(chunks) > 1
        assert all(c.total_chunks == len(chunks) for c in chunks)

    def test_chunks_cover_full_text(self):
        text = "Word " * 40_000  # 200K chars
        chunks = chunk_text(text)
        # Reassemble (without overlaps) should cover all content
        total_unique_chars = sum(c.end_char - c.start_char for c in chunks)
        # Due to overlaps, total may exceed text length
        assert total_unique_chars >= len(text)

    def test_chunk_indexes_are_sequential(self):
        text = "x" * 250_000
        chunks = chunk_text(text)
        for i, chunk in enumerate(chunks):
            assert chunk.index == i

    def test_boundary_detection_at_paragraph(self):
        # Build text with clear paragraph boundaries
        paragraph = "This is a paragraph. " * 100  # ~2100 chars
        text = (paragraph + "\n\n") * 80  # ~168K chars with paragraph breaks
        chunks = chunk_text(text, chunk_size=80_000)
        # Chunks should end near paragraph boundaries
        for chunk in chunks[:-1]:  # All but last
            # Check that chunk ends near a double-newline
            tail = chunk.text[-50:]
            # Should end at or near a paragraph boundary
            assert '\n' in tail or len(chunk.text) <= CHUNK_SIZE + 1000

    def test_overlap_exists_between_chunks(self):
        text = "x" * 200_000
        chunks = chunk_text(text, chunk_size=80_000, overlap=2000)
        if len(chunks) > 1:
            # Check overlap: end of chunk[0] should overlap with start of chunk[1]
            end_of_first = chunks[0].text[-2000:]
            start_of_second = chunks[1].text[:2000]
            assert end_of_first == start_of_second

    def test_estimated_tokens_set(self):
        text = "x" * 200_000
        chunks = chunk_text(text)
        for chunk in chunks:
            assert chunk.estimated_tokens > 0
            assert chunk.estimated_tokens == int(len(chunk.text) / 2.9)


class TestMergeChunkResults:
    def test_single_result(self):
        result = merge_chunk_results([{"a": 1, "b": [1, 2]}])
        assert result == {"a": 1, "b": [1, 2]}

    def test_empty_list(self):
        assert merge_chunk_results([]) == {}

    def test_scalar_first_wins(self):
        results = [{"provider": "A"}, {"provider": "B"}]
        merged = merge_chunk_results(results)
        assert merged["provider"] == "A"  # First chunk wins

    def test_lists_concatenated(self):
        results = [
            {"rates": [{"svc": "IP", "rate": 100}]},
            {"rates": [{"svc": "OP", "rate": 200}]}
        ]
        merged = merge_chunk_results(results)
        assert len(merged["rates"]) == 2

    def test_lists_deduplicated(self):
        results = [
            {"rates": [{"svc": "IP", "rate": 100}]},
            {"rates": [{"svc": "IP", "rate": 100}]}  # duplicate
        ]
        merged = merge_chunk_results(results)
        assert len(merged["rates"]) == 1

    def test_nested_dict_merge(self):
        results = [
            {"info": {"name": "Hospital"}},
            {"info": {"id": "123"}}
        ]
        merged = merge_chunk_results(results)
        assert merged["info"]["name"] == "Hospital"
        assert merged["info"]["id"] == "123"

    def test_none_values_filled_from_later_chunks(self):
        results = [
            {"a": None, "b": 1},
            {"a": "found_later", "b": 2}
        ]
        merged = merge_chunk_results(results)
        # First value wins (even if None) unless deep_merge handles it
        # Current impl: first value takes priority
        assert merged["b"] == 1  # First wins for scalars


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
