/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        // BSC brand palette
        'bsc-blue': {
          50: '#eff6ff',
          100: '#dbeafe',
          200: '#bfdbfe',
          500: '#0066cc',
          600: '#0052a3',
          700: '#003d7a',
          900: '#001f3f',
        },
        // Confidence colors
        confidence: {
          high: '#059669',       // emerald-600
          moderate: '#d97706',   // amber-600
          low: '#dc2626',        // red-600
          uncertain: '#6b7280',  // gray-500
        },
        // Evidence states
        evidence: {
          strong: '#059669',
          partial: '#d97706',
          missing: '#dc2626',
        },
        // Health states
        health: {
          ok: '#059669',
          degraded: '#d97706',
          down: '#dc2626',
        },
      },
    },
  },
  plugins: [],
};
