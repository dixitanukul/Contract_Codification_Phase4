import { useEffect, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { ArrowLeft, ExternalLink, FileText, Loader2 } from 'lucide-react';

export default function DocumentViewerV2() {
  const [searchParams] = useSearchParams();
  const doc = searchParams.get('doc') || '';
  const page = Number.parseInt(searchParams.get('page') || '1', 10);
  const snippet = searchParams.get('snippet') || '';
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [providerName, setProviderName] = useState('');
  const [pdfUrl, setPdfUrl] = useState('');

  useEffect(() => {
    if (!doc) {
      setError('No document specified.');
      setLoading(false);
      return;
    }

    setLoading(true);
    setError('');

    // C8: Safety timeout — clears spinner if iframe onLoad never fires
    const loadTimeout = setTimeout(() => setLoading(false), 12_000);

    fetch(`/api/v1/documents/${encodeURIComponent(doc)}/resolve`)
      .then((response) => (response.ok ? response.json() : null))
      .then((data) => {
        if (data?.pdf_url) {
          setPdfUrl(`${data.pdf_url}#page=${page}`);
          setProviderName(data.provider_name || '');
        } else {
          setPdfUrl(`/api/v1/documents/${encodeURIComponent(doc)}/pdf#page=${page}`);
        }
      })
      .catch(() => {
        // C8: Fallback to direct PDF path; clear spinner so user sees the error
        setPdfUrl(`/api/v1/documents/${encodeURIComponent(doc)}/pdf#page=${page}`);
        setLoading(false);
      });

    return () => clearTimeout(loadTimeout);
  }, [doc, page]);

  return (
    <div className="enterprise-panel flex min-h-[calc(100vh-2rem)] flex-col overflow-hidden rounded-[32px]">
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200/80 px-5 py-4 md:px-6">
        <div className="min-w-0">
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.24em] text-bsc-blue-700">
            <FileText size={14} /> Source viewer
          </div>
          <h1 className="mt-2 truncate text-2xl font-semibold text-slate-950">{doc || 'Document viewer'}</h1>
          <div className="mt-1 text-sm text-slate-500">{providerName ? `${providerName} · ` : ''}Page {page}</div>
        </div>
        <div className="flex items-center gap-2">
          <Link to="/" className="inline-flex items-center gap-2 rounded-2xl border border-slate-200 bg-white px-3 py-2 text-sm text-slate-700">
            <ArrowLeft size={16} /> Back
          </Link>
          {pdfUrl ? (
            <a href={pdfUrl} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 rounded-2xl border border-slate-200 bg-white px-3 py-2 text-sm text-slate-700">
              <ExternalLink size={16} /> Open in new tab
            </a>
          ) : null}
        </div>
      </div>

      {snippet ? (
        <div className="border-b border-amber-200 bg-amber-50 px-5 py-3 text-sm text-amber-800 md:px-6">
          <span className="font-semibold">Cited passage:</span> “{snippet}”
        </div>
      ) : null}

      <div className="relative flex-1 bg-slate-100">
        {error ? (
          <div className="flex h-full items-center justify-center px-6 text-center text-sm text-rose-700">{error}</div>
        ) : pdfUrl ? (
          <>
            {loading ? (
              <div className="absolute inset-0 z-10 flex items-center justify-center gap-2 bg-slate-100/90 text-sm text-slate-600">
                <Loader2 size={18} className="animate-spin" /> Loading PDF
              </div>
            ) : null}
            <iframe
              src={pdfUrl}
              title={doc || 'Document'}
              className="h-full w-full border-0"
              onLoad={() => setLoading(false)}
            />
          </>
        ) : (
          <div className="flex h-full items-center justify-center gap-2 text-sm text-slate-500"><Loader2 size={18} className="animate-spin" /> Resolving document</div>
        )}
      </div>
    </div>
  );
}
