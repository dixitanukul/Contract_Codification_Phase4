import { useEffect, useMemo, useState } from 'react';
import { AlertTriangle, CalendarClock, Loader2, ShieldAlert, TrendingUp } from 'lucide-react';
import { Link } from 'react-router-dom';

interface AlertsSummary {
  critical: number;
  high: number;
  medium: number;
  total: number;
}

interface AlertRow {
  alert_id: string;
  provider_name: string;
  deadline_type: string;
  action_required_by: string;
  days_until_due: number;
  alert_priority: string;
  alert_status: string;
  context_text?: string;
  created_at?: string;
}

interface DeadlineRow {
  deadline_id: string;
  provider_name: string;
  deadline_type: string;
  event_date: string;
  action_required_by: string;
  days_until_action: number;
  priority_tier: string;
  notice_days: number;
}

interface RiskScoreRow {
  provider_id: string;
  provider_name: string;
  lob: string;
  payment_type: string;
  risk_score: number;
  risk_tier: string;
  days_to_expiry: number;
  compliance_gap: number;
  clause_gap: number;
  contracted_spend: number;
  scored_at: string;
}

function priorityPill(priority: string) {
  const styles: Record<string, string> = {
    CRITICAL: 'bg-rose-100 text-rose-700',
    HIGH: 'bg-amber-100 text-amber-700',
    MEDIUM: 'bg-sky-100 text-sky-700',
    LOW: 'bg-slate-100 text-slate-600',
  };
  return styles[priority] || 'bg-slate-100 text-slate-600';
}

export default function AlertsPageV2() {
  const [summary, setSummary] = useState<AlertsSummary | null>(null);
  const [alerts, setAlerts] = useState<AlertRow[]>([]);
  const [deadlines, setDeadlines] = useState<DeadlineRow[]>([]);
  const [riskScores, setRiskScores] = useState<RiskScoreRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const load = async (attempt = 0) => {
      let retryScheduled = false;
      if (attempt === 0) setLoading(true);
      try {
        setError('');
        const [summaryRes, alertsRes, deadlinesRes, riskRes] = await Promise.all([
          fetch('/api/v1/alerts/summary'),
          fetch('/api/v1/alerts?priority=CRITICAL&limit=20'),
          fetch('/api/v1/deadlines?days_ahead=90'),
          fetch('/api/v1/risk/scores?limit=15'),
        ]);

        const responses = [summaryRes, alertsRes, deadlinesRes, riskRes];
        const has503 = responses.some((res) => res.status === 503);
        if (has503 && attempt < 6) {
          retryScheduled = true;
          setTimeout(() => { void load(attempt + 1); }, 10_000);
          return;
        }
        responses.forEach((res) => {
          if (!res.ok) throw new Error(`HTTP ${res.status}`);
        });

        const [summaryData, alertsData, deadlinesData, riskData] = await Promise.all([
          summaryRes.json() as Promise<AlertsSummary>,
          alertsRes.json() as Promise<{ alerts: AlertRow[] }>,
          deadlinesRes.json() as Promise<{ deadlines: DeadlineRow[] }>,
          riskRes.json() as Promise<{ scores: RiskScoreRow[] }>,
        ]);

        setSummary(summaryData);
        setAlerts(alertsData.alerts || []);
        setDeadlines(deadlinesData.deadlines || []);
        setRiskScores(riskData.scores || []);
      } catch (err) {
        if (attempt < 6) {
          retryScheduled = true;
          setTimeout(() => { void load(attempt + 1); }, 10_000);
          return;
        }
        setSummary(null);
        setAlerts([]);
        setDeadlines([]);
        setRiskScores([]);
        setError(err instanceof Error ? err.message : 'Failed to load alerts dashboard');
      } finally {
        if (!retryScheduled) setLoading(false);
      }
    };

    void load();
  }, []);

  const topDeadlines = useMemo(() => deadlines.slice(0, 12), [deadlines]);
  const topRiskScores = useMemo(() => riskScores.slice(0, 10), [riskScores]);

  return (
    <div className="space-y-4">
      <section className="enterprise-panel rounded-[32px] p-6">
        <div className="flex flex-wrap items-start justify-between gap-4 border-b border-slate-200/80 pb-5">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.24em] text-bsc-blue-700">
              <ShieldAlert size={14} /> Alerts Dashboard
            </div>
            <h1 className="mt-2 text-3xl font-semibold text-slate-950">Contract risk monitoring</h1>
            <p className="mt-2 max-w-3xl text-sm leading-6 text-slate-600">
              Review critical alerts, upcoming deadlines, and high-risk providers from the production risk endpoints.
            </p>
          </div>
          <button
            type="button"
            onClick={() => window.location.reload()}
            className="rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm font-medium text-slate-700 hover:bg-slate-50"
          >
            Refresh
          </button>
        </div>

        {error ? <div className="mt-5 rounded-2xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700">{error}</div> : null}

        {loading ? (
          <div className="mt-6 flex items-center gap-3 rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-500">
            <span aria-hidden="true"><Loader2 size={16} className="animate-spin" /></span> <span>Loading alerts</span> dashboard
          </div>
        ) : (
          <>
            <div className="mt-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
              <div className="enterprise-card rounded-2xl p-4">
                <div className="text-xs uppercase tracking-wide text-slate-500">Critical alerts</div>
                <div className="mt-2 text-3xl font-semibold text-rose-700">{summary?.critical || 0}</div>
              </div>
              <div className="enterprise-card rounded-2xl p-4">
                <div className="text-xs uppercase tracking-wide text-slate-500">High priority</div>
                <div className="mt-2 text-3xl font-semibold text-amber-700">{summary?.high || 0}</div>
              </div>
              <div className="enterprise-card rounded-2xl p-4">
                <div className="text-xs uppercase tracking-wide text-slate-500">Medium priority</div>
                <div className="mt-2 text-3xl font-semibold text-sky-700">{summary?.medium || 0}</div>
              </div>
              <div className="enterprise-card rounded-2xl p-4">
                <div className="text-xs uppercase tracking-wide text-slate-500">Total open alerts</div>
                <div className="mt-2 text-3xl font-semibold text-slate-950">{summary?.total || 0}</div>
              </div>
            </div>

            <div className="mt-6 grid gap-6 xl:grid-cols-[1.2fr_0.8fr]">
              <section className="rounded-[28px] border border-slate-200 bg-white p-5">
                <div className="flex items-center gap-2 text-sm font-semibold text-slate-900">
                  <AlertTriangle size={16} className="text-rose-600" /> Critical alert queue
                </div>
                <div className="app-scrollbar mt-4 overflow-auto rounded-2xl border border-slate-200">
                  <table className="min-w-full text-sm" aria-label="Critical alert queue">
                    <thead className="bg-slate-50 text-left text-xs uppercase tracking-wide text-slate-500">
                      <tr>
                        <th className="px-4 py-3">Provider</th>
                        <th className="px-4 py-3">Type</th>
                        <th className="px-4 py-3">Due</th>
                        <th className="px-4 py-3">Priority</th>
                      </tr>
                    </thead>
                    <tbody>
                      {alerts.length === 0 ? (
                        <tr><td colSpan={4} className="px-4 py-10 text-center text-sm text-slate-400">No critical alerts returned.</td></tr>
                      ) : alerts.map((alert) => (
                        <tr key={alert.alert_id} className="border-t border-slate-100 align-top">
                          <td className="px-4 py-3">
                            <div className="font-medium text-slate-800">{alert.provider_name}</div>
                            <Link to={`/?provider=${encodeURIComponent(alert.provider_name)}`} className="mt-1 inline-block text-xs text-bsc-blue-600 hover:underline">Ask about provider</Link>
                          </td>
                          <td className="px-4 py-3 text-slate-600">
                            <div>{alert.deadline_type}</div>
                            {alert.context_text ? <div className="mt-1 line-clamp-2 text-xs text-slate-400">{alert.context_text}</div> : null}
                          </td>
                          <td className="px-4 py-3 text-slate-600">
                            <div>{alert.action_required_by || '—'}</div>
                            <div className="mt-1 text-xs text-slate-400">{alert.days_until_due} days</div>
                          </td>
                          <td className="px-4 py-3">
                            <span className={`inline-flex rounded-full px-2.5 py-1 text-[11px] font-semibold ${priorityPill(alert.alert_priority)}`}>{alert.alert_priority}</span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </section>

              <section className="rounded-[28px] border border-slate-200 bg-white p-5">
                <div className="flex items-center gap-2 text-sm font-semibold text-slate-900">
                  <CalendarClock size={16} className="text-amber-600" /> Upcoming deadlines (90 days)
                </div>
                <div className="mt-4 space-y-2">
                  {topDeadlines.length === 0 ? (
                    <div className="rounded-2xl border border-dashed border-slate-200 px-4 py-8 text-center text-sm text-slate-400">No deadlines returned.</div>
                  ) : topDeadlines.map((deadline) => (
                    <div key={deadline.deadline_id} className="rounded-2xl border border-slate-100 bg-slate-50 px-4 py-3">
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <div className="font-medium text-slate-800">{deadline.provider_name}</div>
                          <div className="mt-1 text-xs text-slate-500">{deadline.deadline_type} · {deadline.action_required_by || deadline.event_date || 'Unknown date'}</div>
                        </div>
                        <span className={`inline-flex rounded-full px-2.5 py-1 text-[11px] font-semibold ${priorityPill(deadline.priority_tier)}`}>{deadline.priority_tier}</span>
                      </div>
                      <div className="mt-2 text-xs text-slate-400">{deadline.days_until_action} days until action · {deadline.notice_days} notice days</div>
                    </div>
                  ))}
                </div>
              </section>
            </div>

            <section className="mt-6 rounded-[28px] border border-slate-200 bg-white p-5">
              <div className="flex items-center gap-2 text-sm font-semibold text-slate-900">
                <TrendingUp size={16} className="text-bsc-blue-700" /> Highest risk providers
              </div>
              <div className="app-scrollbar mt-4 overflow-auto rounded-2xl border border-slate-200">
                <table className="min-w-full text-sm">
                  <thead className="bg-slate-50 text-left text-xs uppercase tracking-wide text-slate-500">
                    <tr>
                      <th className="px-4 py-3">Provider</th>
                      <th className="px-4 py-3">Risk score</th>
                      <th className="px-4 py-3">Tier</th>
                      <th className="px-4 py-3">Days to expiry</th>
                      <th className="px-4 py-3">Spend</th>
                    </tr>
                  </thead>
                  <tbody>
                    {topRiskScores.length === 0 ? (
                      <tr><td colSpan={5} className="px-4 py-10 text-center text-sm text-slate-400">No risk scores returned.</td></tr>
                    ) : topRiskScores.map((row) => (
                      <tr key={`${row.provider_id}-${row.provider_name}`} className="border-t border-slate-100">
                        <td className="px-4 py-3 font-medium text-slate-800">{row.provider_name}</td>
                        <td className="px-4 py-3 text-slate-700">{Number(row.risk_score || 0).toFixed(1)}</td>
                        <td className="px-4 py-3"><span className={`inline-flex rounded-full px-2.5 py-1 text-[11px] font-semibold ${priorityPill(row.risk_tier)}`}>{row.risk_tier}</span></td>
                        <td className="px-4 py-3 text-slate-700">{row.days_to_expiry ?? '—'}</td>
                        <td className="px-4 py-3 text-slate-700">${Number(row.contracted_spend || 0).toLocaleString()}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>
          </>
        )}
      </section>
    </div>
  );
}
