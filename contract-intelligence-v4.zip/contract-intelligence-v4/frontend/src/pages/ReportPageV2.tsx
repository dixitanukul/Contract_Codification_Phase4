import { useEffect, useMemo, useState } from 'react';
import { ArrowUpDown, BarChart3, CheckSquare, ChevronLeft, ChevronRight, Download, FileText, Loader2, Play, Square } from 'lucide-react';

interface Concept {
  key: string;
  label?: string;
  display_name?: string;
  description?: string;
}

interface ReportResult {
  provider_name: string;
  classifications: Record<string, string>;
}

interface ReportResponse {
  total_providers: number;
  concept_keys: string[];
  summary: Record<string, Record<string, number>>;
  results: ReportResult[];
}

function StatusPill({ status }: { status: string }) {
  const styles: Record<string, string> = {
    HAS: 'bg-emerald-100 text-emerald-700',
    NO_MENTION: 'bg-slate-100 text-slate-600',
    DENIED: 'bg-rose-100 text-rose-700',
    MIXED: 'bg-amber-100 text-amber-700',
    UNCLASSIFIED: 'bg-slate-100 text-slate-500',
  };
  return <span className={`inline-flex rounded-full px-2.5 py-1 text-[11px] font-semibold ${styles[status] || 'bg-slate-100 text-slate-600'}`}>{status}</span>;
}

export default function ReportPageV2() {
  const [concepts, setConcepts] = useState<Concept[]>([]);
  const [selectedKeys, setSelectedKeys] = useState<Set<string>>(new Set());
  const [providerFilter, setProviderFilter] = useState('');
  const [lobFilter, setLobFilter] = useState('');
  const [activeOnly, setActiveOnly] = useState(true);
  const [loadingConcepts, setLoadingConcepts] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [report, setReport] = useState<ReportResponse | null>(null);
  const [error, setError] = useState('');
  const [sortBy, setSortBy] = useState<string>('provider_name');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('asc');
  const [page, setPage] = useState(0);
  const pageSize = 25;

  // C3: Load concepts with 503 retry (handles cold-start warming-up period)
  useEffect(() => {
    const loadConcepts = (attempt = 0): void => {
      fetch('/api/v1/concepts')
        .then((res) => {
          if (res.status === 503 && attempt < 6) {
            setTimeout(() => loadConcepts(attempt + 1), 10_000);
            return Promise.resolve(null);
          }
          if (!res.ok) throw new Error(`HTTP ${res.status}`);
          return res.json() as Promise<{ concepts: Concept[] }>;
        })
        .then((data) => {
          if (!data) return; // retry scheduled
          const items = data.concepts || [];
          setConcepts(items);
          setSelectedKeys(new Set(items.slice(0, 3).map((item) => item.key)));
          setLoadingConcepts(false);
        })
        .catch(() => {
          if (attempt < 6) {
            setTimeout(() => loadConcepts(attempt + 1), 10_000);
          } else {
            setConcepts([]);
            setLoadingConcepts(false);
          }
        });
    };
    loadConcepts();
  }, []);

  const selectedConcepts = useMemo(() => concepts.filter((concept) => selectedKeys.has(concept.key)), [concepts, selectedKeys]);

  const conceptLabel = (key: string) => concepts.find((concept) => concept.key === key)?.display_name || concepts.find((concept) => concept.key === key)?.label || key;

  const sortedResults = useMemo(() => {
    if (!report) return [];
    const statusOrder: Record<string, number> = {
      HAS: 5,
      MIXED: 4,
      DENIED: 3,
      NO_MENTION: 2,
      UNCLASSIFIED: 1,
    };
    const rows = [...report.results];
    rows.sort((a, b) => {
      const left = sortBy === 'provider_name'
        ? a.provider_name.toLowerCase()
        : statusOrder[a.classifications[sortBy] || 'UNCLASSIFIED'] || 0;
      const right = sortBy === 'provider_name'
        ? b.provider_name.toLowerCase()
        : statusOrder[b.classifications[sortBy] || 'UNCLASSIFIED'] || 0;
      if (left < right) return sortDir === 'asc' ? -1 : 1;
      if (left > right) return sortDir === 'asc' ? 1 : -1;
      return a.provider_name.localeCompare(b.provider_name);
    });
    return rows;
  }, [report, sortBy, sortDir]);

  const totalPages = Math.max(Math.ceil(sortedResults.length / pageSize), 1);
  const pagedResults = useMemo(() => sortedResults.slice(page * pageSize, (page + 1) * pageSize), [sortedResults, page]);

  const toggleSort = (key: string) => {
    setPage(0);
    if (sortBy === key) {
      setSortDir((current) => current === 'asc' ? 'desc' : 'asc');
      return;
    }
    setSortBy(key);
    setSortDir(key === 'provider_name' ? 'asc' : 'desc');
  };

  const exportCsv = () => {
    if (!report) return;
    const escapeCsv = (value: string) => `"${value.replace(/"/g, '""')}"`;
    const headers = ['Provider', ...report.concept_keys.map((key) => conceptLabel(key))];
    const rows = sortedResults.map((row) => [
      row.provider_name,
      ...report.concept_keys.map((key) => row.classifications[key] || 'UNCLASSIFIED'),
    ]);
    const csv = [headers, ...rows].map((row) => row.map((value) => escapeCsv(String(value ?? ''))).join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = `contract_report_${new Date().toISOString().slice(0, 10)}.csv`;
    anchor.click();
    URL.revokeObjectURL(url);
  };

  const toggleConcept = (key: string) => {
    setSelectedKeys((current) => {
      const next = new Set(current);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  };

  const generateReport = async () => {
    if (selectedKeys.size === 0) return;
    setGenerating(true);
    setError('');
    setReport(null);
    try {
      const response = await fetch('/api/v1/report', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          concept_keys: Array.from(selectedKeys),
          provider_filter: providerFilter,
          lob_filter: lobFilter,
          active_only: activeOnly,
        }),
      });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const data = await response.json() as ReportResponse;
      setReport(data);
      setSortBy('provider_name');
      setSortDir('asc');
      setPage(0);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to generate report');
    } finally {
      setGenerating(false);
    }
  };

  return (
    <div className="space-y-4">
      <section className="enterprise-panel rounded-[32px] p-6">
        <div className="flex flex-wrap items-start justify-between gap-4 border-b border-slate-200/80 pb-5">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.24em] text-bsc-blue-700">
              <FileText size={14} /> Reports
            </div>
            <h1 className="mt-2 text-3xl font-semibold text-slate-950">Coverage and compliance reporting</h1>
            <p className="mt-2 max-w-3xl text-sm leading-6 text-slate-600">
              Build a classification matrix across providers and policy concepts without leaving the application. Filters remain aligned to the existing API contract.
            </p>
          </div>
          <div className="enterprise-card rounded-2xl p-4">
            <div className="flex items-center gap-2 text-xs uppercase tracking-wide text-slate-500"><BarChart3 size={13} /> Selected concepts</div>
            <div className="mt-2 text-2xl font-semibold text-slate-950">{selectedKeys.size}</div>
          </div>
        </div>

        <div className="mt-6 grid gap-6 xl:grid-cols-[1.25fr_0.9fr]">
          <div className="space-y-4">
            <div>
              <div className="mb-3 text-sm font-semibold text-slate-800">Choose concepts</div>
              {loadingConcepts ? (
                <div className="flex items-center gap-2 rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-500"><Loader2 size={16} className="animate-spin" /> Loading concepts</div>
              ) : (
                <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
                  {concepts.map((concept) => {
                    const label = concept.display_name || concept.label || concept.key;
                    const selected = selectedKeys.has(concept.key);
                    return (
                      <button key={concept.key} type="button" onClick={() => toggleConcept(concept.key)} className={`rounded-2xl border p-4 text-left transition-all ${selected ? 'border-bsc-blue-200 bg-bsc-blue-50' : 'border-slate-200 bg-white hover:border-slate-300'}`}>
                        <div className="flex items-start gap-3">
                          <div className={`mt-0.5 ${selected ? 'text-bsc-blue-700' : 'text-slate-400'}`}>{selected ? <CheckSquare size={18} /> : <Square size={18} />}</div>
                          <div>
                            <div className="text-sm font-semibold text-slate-900">{label}</div>
                            <div className="mt-1 text-xs leading-5 text-slate-500">{concept.description || 'Use this concept in the generated classification matrix.'}</div>
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          </div>

          <div className="enterprise-card rounded-[28px] p-5">
            <div className="text-sm font-semibold text-slate-900">Report parameters</div>
            <div className="mt-4 space-y-4">
              <label className="block">
                <span className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">Provider filter</span>
                <input value={providerFilter} onChange={(event) => setProviderFilter(event.target.value)} placeholder="e.g. Hoag, Sutter" className="w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm outline-none focus:border-bsc-blue-300" />
              </label>
              <label className="block">
                <span className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">LOB filter</span>
                <input value={lobFilter} onChange={(event) => setLobFilter(event.target.value)} placeholder="e.g. commercial" className="w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm outline-none focus:border-bsc-blue-300" />
              </label>
              <label className="flex items-center gap-3 rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700">
                <input type="checkbox" checked={activeOnly} onChange={(event) => setActiveOnly(event.target.checked)} className="h-4 w-4 rounded border-slate-300 text-bsc-blue-600" />
                Limit to active providers
              </label>
              <button type="button" onClick={generateReport} disabled={generating || selectedKeys.size === 0} className="inline-flex w-full items-center justify-center gap-2 rounded-2xl bg-slate-950 px-4 py-3 text-sm font-medium text-white shadow-lg shadow-slate-200 disabled:cursor-not-allowed disabled:opacity-40">
                {generating ? <Loader2 size={16} className="animate-spin" /> : <Play size={16} />}
                {generating ? 'Generating report' : 'Generate report'}
              </button>
            </div>

            {selectedConcepts.length > 0 ? (
              <div className="mt-5 flex flex-wrap gap-2">
                {selectedConcepts.map((concept) => (
                  <span key={concept.key} className="rounded-full bg-slate-100 px-3 py-1 text-xs font-medium text-slate-700">{concept.display_name || concept.label || concept.key}</span>
                ))}
              </div>
            ) : null}
          </div>
        </div>
      </section>

      {error ? <div className="rounded-2xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700">{error}</div> : null}

      {report ? (
        <section className="enterprise-panel rounded-[32px] p-6">
          <div className="flex flex-wrap items-start justify-between gap-4 border-b border-slate-200/80 pb-5">
            <div>
              <div className="text-xs font-semibold uppercase tracking-[0.24em] text-bsc-blue-700">Generated matrix</div>
              <h2 className="mt-2 text-2xl font-semibold text-slate-950">{report.total_providers} providers evaluated</h2>
              <div className="mt-2 text-xs text-slate-500">Sorted by {sortBy === 'provider_name' ? 'Provider' : conceptLabel(sortBy)} ({sortDir})</div>
            </div>
            <div className="flex flex-col items-stretch gap-3">
              <button
                type="button"
                onClick={exportCsv}
                aria-label="Export results as CSV"
                className="inline-flex items-center justify-center gap-2 rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm font-medium text-slate-700 hover:bg-slate-50"
              >
                <Download size={16} /> Export CSV
              </button>
              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                {report.concept_keys.map((key) => {
                  const counts = report.summary[key] || {};
                  const total = Object.values(counts).reduce((sum, value) => sum + value, 0);
                  const hasCount = counts.HAS || 0;
                  const percentage = total ? Math.round((hasCount / total) * 100) : 0;
                  return (
                    <div key={key} className="enterprise-card rounded-2xl p-4">
                      <div className="text-xs uppercase tracking-wide text-slate-500">{conceptLabel(key)}</div>
                      <div className="mt-2 text-2xl font-semibold text-slate-950">{percentage}%</div>
                      <div className="mt-1 text-xs text-slate-500">{hasCount} of {total} flagged HAS</div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          <div className="app-scrollbar mt-5 overflow-auto rounded-[28px] border border-slate-200 bg-white">
            <table className="min-w-full text-sm">
              <thead className="bg-slate-50 text-left text-xs uppercase tracking-wide text-slate-500">
                <tr>
                  <th className="px-5 py-4">
                    <button type="button" onClick={() => toggleSort('provider_name')} aria-label="Sort by provider name" className="inline-flex items-center gap-1 font-semibold hover:text-slate-700">
                      Provider <ArrowUpDown size={12} />
                    </button>
                  </th>
                  {report.concept_keys.map((key) => (
                    <th key={key} className="px-4 py-4">
                      <button type="button" onClick={() => toggleSort(key)} className="inline-flex items-center gap-1 font-semibold hover:text-slate-700">
                        {conceptLabel(key)} <ArrowUpDown size={12} />
                      </button>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {pagedResults.map((row) => (
                  <tr key={row.provider_name} className="border-t border-slate-100">
                    <td className="px-5 py-4 font-medium text-slate-800">{row.provider_name}</td>
                    {report.concept_keys.map((key) => (
                      <td key={`${row.provider_name}-${key}`} className="px-4 py-4"><StatusPill status={row.classifications[key] || 'UNCLASSIFIED'} /></td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="mt-4 flex flex-wrap items-center justify-between gap-3 text-sm text-slate-500">
            <span>
              Showing {sortedResults.length === 0 ? 0 : page * pageSize + 1}-{Math.min((page + 1) * pageSize, sortedResults.length)} of {sortedResults.length}
            </span>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setPage((current) => Math.max(current - 1, 0))}
                disabled={page === 0}
                className="inline-flex items-center gap-1 rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-medium hover:bg-slate-50 disabled:opacity-40"
              >
                <ChevronLeft size={14} /> Prev
              </button>
              <span className="text-xs text-slate-400">Page {page + 1} of {totalPages}</span>
              <button
                type="button"
                onClick={() => setPage((current) => (current + 1 < totalPages ? current + 1 : current))}
                disabled={page + 1 >= totalPages}
                className="inline-flex items-center gap-1 rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-medium hover:bg-slate-50 disabled:opacity-40"
              >
                Next <ChevronRight size={14} />
              </button>
            </div>
          </div>
        </section>
      ) : null}
    </div>
  );
}
