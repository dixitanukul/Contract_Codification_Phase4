import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  CalendarClock,
  ChevronLeft,
  ChevronRight,
  Clock,
  List,
  Loader2,
  X,
} from 'lucide-react';

interface Deadline {
  deadline_id: string;
  provider_name: string;
  deadline_type: string;
  event_date: string;
  action_required_by: string;
  days_until_action: number;
  priority_tier: string;
  notice_days: number;
}

const PRIORITY_CONFIG: Record<string, { pill: string; dot: string; label: string; order: number }> = {
  CRITICAL: { pill: 'bg-rose-100 text-rose-700 border border-rose-200',   dot: 'bg-rose-500',    label: 'Critical', order: 0 },
  HIGH:     { pill: 'bg-amber-100 text-amber-700 border border-amber-200', dot: 'bg-amber-500',   label: 'High',     order: 1 },
  MEDIUM:   { pill: 'bg-sky-100 text-sky-700 border border-sky-200',       dot: 'bg-sky-500',     label: 'Medium',   order: 2 },
  LOW:      { pill: 'bg-emerald-100 text-emerald-700 border border-emerald-200', dot: 'bg-emerald-500', label: 'Low', order: 3 },
};

const WEEK_DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const MONTH_NAMES = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December',
];

function toDateKey(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function parseKey(key: string): Date {
  const [y, m, d] = key.split('-').map(Number);
  return new Date(y, m - 1, d);
}

export default function DeadlineCalendarV2() {
  const today = useMemo(() => new Date(), []);
  const todayKey = useMemo(() => toDateKey(today), [today]);

  const [currentMonth, setCurrentMonth] = useState(() => new Date(today.getFullYear(), today.getMonth(), 1));
  const [deadlines, setDeadlines] = useState<Deadline[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [selectedDay, setSelectedDay] = useState<string | null>(null);
  const [view, setView] = useState<'calendar' | 'list'>('calendar');
  const detailRef = useRef<HTMLDivElement>(null);

  // Fetch all deadlines for the next 365 days, once
  useEffect(() => {
    const load = async (attempt = 0) => {
      if (attempt === 0) setLoading(true);
      let retry = false;
      try {
        const res = await fetch('/api/v1/deadlines?days_ahead=365');
        if (res.status === 503 && attempt < 6) {
          retry = true;
          setTimeout(() => { void load(attempt + 1); }, 10_000);
          return;
        }
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data = await res.json() as { deadlines: Deadline[] };
        setDeadlines(data.deadlines || []);
      } catch (e) {
        if (attempt < 6) {
          retry = true;
          setTimeout(() => { void load(attempt + 1); }, 10_000);
          return;
        }
        setError(e instanceof Error ? e.message : 'Failed to load deadlines');
      } finally {
        if (!retry) setLoading(false);
      }
    };
    void load();
  }, []);

  // Group deadlines by action_required_by date string
  const byDate = useMemo(() => {
    const map: Record<string, Deadline[]> = {};
    for (const d of deadlines) {
      const key = (d.action_required_by || '').slice(0, 10);
      if (!key) continue;
      if (!map[key]) map[key] = [];
      map[key].push(d);
    }
    // Sort each day's deadlines by priority
    for (const key of Object.keys(map)) {
      map[key].sort((a, b) => (PRIORITY_CONFIG[a.priority_tier]?.order ?? 9) - (PRIORITY_CONFIG[b.priority_tier]?.order ?? 9));
    }
    return map;
  }, [deadlines]);

  // Calendar grid data
  const { gridCells, daysInMonth } = useMemo(() => {
    const year = currentMonth.getFullYear();
    const month = currentMonth.getMonth();
    const firstDow = new Date(year, month, 1).getDay(); // 0=Sun
    const dim = new Date(year, month + 1, 0).getDate();
    const cells: Array<{ dateKey: string; dayNum: number } | null> = [];
    for (let i = 0; i < firstDow; i++) cells.push(null); // leading blanks
    for (let d = 1; d <= dim; d++) {
      const key = `${year}-${String(month + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
      cells.push({ dateKey: key, dayNum: d });
    }
    return { gridCells: cells, daysInMonth: dim };
  }, [currentMonth]);

  // Month summary stats
  const monthStats = useMemo(() => {
    const year = currentMonth.getFullYear();
    const month = currentMonth.getMonth();
    const prefix = `${year}-${String(month + 1).padStart(2, '0')}-`;
    const monthDeadlines = deadlines.filter((d) => (d.action_required_by || '').startsWith(prefix));
    const counts: Record<string, number> = { CRITICAL: 0, HIGH: 0, MEDIUM: 0, LOW: 0 };
    for (const d of monthDeadlines) counts[d.priority_tier] = (counts[d.priority_tier] || 0) + 1;
    return { total: monthDeadlines.length, counts };
  }, [deadlines, currentMonth]);

  // Upcoming list (next 60 days, sorted ascending)
  const upcomingList = useMemo(() => {
    const cutoff = new Date(today);
    cutoff.setDate(cutoff.getDate() + 60);
    return deadlines
      .filter((d) => {
        if (!d.action_required_by) return false;
        const dt = parseKey(d.action_required_by.slice(0, 10));
        return dt >= today && dt <= cutoff;
      })
      .sort((a, b) => a.action_required_by.localeCompare(b.action_required_by))
      .slice(0, 80);
  }, [deadlines, today]);

  const prevMonth = useCallback(() => {
    setCurrentMonth((m) => new Date(m.getFullYear(), m.getMonth() - 1, 1));
    setSelectedDay(null);
  }, []);
  const nextMonth = useCallback(() => {
    setCurrentMonth((m) => new Date(m.getFullYear(), m.getMonth() + 1, 1));
    setSelectedDay(null);
  }, []);

  // Close day panel on Escape
  useEffect(() => {
    const handler = (e: KeyboardEvent) => { if (e.key === 'Escape') setSelectedDay(null); };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, []);

  // Focus first focusable in detail panel when it opens
  useEffect(() => {
    if (selectedDay && detailRef.current) {
      const btn = detailRef.current.querySelector<HTMLElement>('button, a');
      btn?.focus();
    }
  }, [selectedDay]);

  const selectedDeadlines = selectedDay ? (byDate[selectedDay] || []) : [];

  return (
    <div className="flex h-full flex-col gap-4 overflow-hidden">
      {/* ── Header ── */}
      <div className="enterprise-panel shrink-0 rounded-[28px] p-5">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.24em] text-bsc-blue-700">
              <CalendarClock size={14} /> Deadline Calendar
            </div>
            <h1 className="mt-1 text-2xl font-semibold text-slate-950">Contract deadline tracker</h1>
          </div>

          {/* Summary pills */}
          {!loading && (
            <div className="flex flex-wrap items-center gap-2" aria-label="This month deadline summary">
              <span className="text-xs text-slate-500">{MONTH_NAMES[currentMonth.getMonth()]}:</span>
              {(Object.entries(monthStats.counts) as [string, number][]).filter(([, n]) => n > 0).map(([tier, n]) => {
                const cfg = PRIORITY_CONFIG[tier];
                return (
                  <span key={tier} className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-[11px] font-semibold ${cfg.pill}`}>
                    <span className={`h-1.5 w-1.5 rounded-full ${cfg.dot}`} />
                    {n} {cfg.label}
                  </span>
                );
              })}
              {monthStats.total === 0 && <span className="text-xs text-slate-400">No deadlines this month</span>}
            </div>
          )}

          {/* View toggle */}
          <div className="flex rounded-xl border border-slate-200 overflow-hidden" role="group" aria-label="Calendar view">
            <button
              type="button"
              aria-pressed={view === 'calendar'}
              onClick={() => setView('calendar')}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium transition-colors ${view === 'calendar' ? 'bg-bsc-blue-600 text-white' : 'bg-white text-slate-600 hover:bg-slate-50'}`}
            >
              <CalendarClock size={13} /> Month
            </button>
            <button
              type="button"
              aria-pressed={view === 'list'}
              onClick={() => setView('list')}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium transition-colors ${view === 'list' ? 'bg-bsc-blue-600 text-white' : 'bg-white text-slate-600 hover:bg-slate-50'}`}
            >
              <List size={13} /> Upcoming
            </button>
          </div>
        </div>

        {error && (
          <div className="mt-3 rounded-2xl border border-rose-200 bg-rose-50 px-4 py-2 text-sm text-rose-700" role="alert">{error}</div>
        )}
      </div>

      {loading ? (
        <div className="enterprise-panel flex flex-1 items-center justify-center gap-3 rounded-[28px] p-8 text-sm text-slate-500" aria-live="polite" aria-busy="true">
          <Loader2 size={18} className="animate-spin" /> Loading deadlines…
        </div>
      ) : view === 'list' ? (
        /* ── List view ── */
        <div className="enterprise-panel flex-1 overflow-auto rounded-[28px] p-5" aria-label="Upcoming deadlines list">
          <div className="mb-4 text-sm font-semibold text-slate-700">Next 60 days — {upcomingList.length} deadline{upcomingList.length !== 1 ? 's' : ''}</div>
          {upcomingList.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-slate-200 py-12 text-center text-sm text-slate-400">No upcoming deadlines in the next 60 days.</div>
          ) : (
            <div className="space-y-2">
              {upcomingList.map((d) => {
                const cfg = PRIORITY_CONFIG[d.priority_tier] || PRIORITY_CONFIG['LOW'];
                return (
                  <div key={d.deadline_id} className="flex items-start gap-4 rounded-[20px] border border-slate-100 bg-white px-4 py-3">
                    <div className={`mt-1 h-2.5 w-2.5 shrink-0 rounded-full ${cfg.dot}`} aria-label={`Priority: ${cfg.label}`} />
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-start gap-x-3 gap-y-1">
                        <span className="font-medium text-slate-900">{d.provider_name}</span>
                        <span className="text-xs text-slate-400">{d.deadline_type}</span>
                      </div>
                      <div className="mt-1 flex flex-wrap items-center gap-3 text-xs text-slate-500">
                        <span className="flex items-center gap-1"><Clock size={10} /> Action by: {d.action_required_by?.slice(0, 10) || '—'}</span>
                        <span>{d.days_until_action} day{d.days_until_action !== 1 ? 's' : ''} away</span>
                        {d.event_date && <span>Event: {d.event_date?.slice(0, 10)}</span>}
                      </div>
                    </div>
                    <span className={`shrink-0 self-center rounded-full px-2 py-0.5 text-[11px] font-semibold ${cfg.pill}`}>{cfg.label}</span>
                    <Link
                      to={`/?provider=${encodeURIComponent(d.provider_name)}`}
                      className="shrink-0 self-center rounded-lg border border-slate-200 bg-slate-50 px-2 py-1 text-[11px] text-slate-600 hover:bg-bsc-blue-50 hover:text-bsc-blue-700"
                      aria-label={`Ask about ${d.provider_name}`}
                    >
                      Ask AI
                    </Link>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      ) : (
        /* ── Calendar view ── */
        <div className="flex min-h-0 flex-1 gap-4">
          <div className="enterprise-panel flex min-h-0 flex-1 flex-col overflow-hidden rounded-[28px]">
            {/* Month nav */}
            <div className="flex items-center justify-between border-b border-slate-100 px-5 py-3">
              <button
                type="button"
                onClick={prevMonth}
                aria-label="Previous month"
                className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100"
              >
                <ChevronLeft size={16} />
              </button>
              <h2 className="text-base font-semibold text-slate-900">
                {MONTH_NAMES[currentMonth.getMonth()]} {currentMonth.getFullYear()}
              </h2>
              <button
                type="button"
                onClick={nextMonth}
                aria-label="Next month"
                className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100"
              >
                <ChevronRight size={16} />
              </button>
            </div>

            {/* Day-of-week header */}
            <div className="grid grid-cols-7 border-b border-slate-100">
              {WEEK_DAYS.map((d) => (
                <div key={d} className="py-2 text-center text-[11px] font-semibold uppercase tracking-wide text-slate-400">{d}</div>
              ))}
            </div>

            {/* Grid */}
            <div
              className="app-scrollbar flex-1 overflow-auto"
              role="grid"
              aria-label={`Calendar for ${MONTH_NAMES[currentMonth.getMonth()]} ${currentMonth.getFullYear()}`}
            >
              <div className="grid grid-cols-7">
                {gridCells.map((cell, idx) => {
                  if (!cell) {
                    return <div key={`blank-${idx}`} role="gridcell" aria-hidden="true" className="min-h-[90px] border-b border-r border-slate-100 bg-slate-50/40" />;
                  }
                  const { dateKey, dayNum } = cell;
                  const dayDeadlines = byDate[dateKey] || [];
                  const isToday = dateKey === todayKey;
                  const isSelected = dateKey === selectedDay;
                  const shown = dayDeadlines.slice(0, 3);
                  const overflow = dayDeadlines.length - shown.length;
                  return (
                    <div
                      key={dateKey}
                      role="gridcell"
                      aria-label={`${dateKey}${dayDeadlines.length ? `, ${dayDeadlines.length} deadline${dayDeadlines.length > 1 ? 's' : ''}` : ''}`}
                      tabIndex={dayDeadlines.length > 0 ? 0 : -1}
                      onClick={() => dayDeadlines.length > 0 && setSelectedDay(isSelected ? null : dateKey)}
                      onKeyDown={(e) => {
                        if ((e.key === 'Enter' || e.key === ' ') && dayDeadlines.length > 0) {
                          e.preventDefault();
                          setSelectedDay(isSelected ? null : dateKey);
                        }
                      }}
                      className={`min-h-[90px] cursor-default border-b border-r border-slate-100 p-1.5 transition-colors ${
                        dayDeadlines.length > 0 ? 'cursor-pointer hover:bg-bsc-blue-50/30' : ''
                      } ${isSelected ? 'bg-bsc-blue-50' : ''}`}
                    >
                      <div className={`mb-1 flex h-6 w-6 items-center justify-center rounded-full text-xs font-semibold ${
                        isToday ? 'bg-bsc-blue-600 text-white' : 'text-slate-700'
                      }`}>
                        {dayNum}
                      </div>
                      <div className="space-y-0.5">
                        {shown.map((dl) => {
                          const cfg = PRIORITY_CONFIG[dl.priority_tier] || PRIORITY_CONFIG['LOW'];
                          return (
                            <div
                              key={dl.deadline_id}
                              className={`truncate rounded px-1.5 py-0.5 text-[10px] font-medium leading-tight ${cfg.pill}`}
                            >
                              {dl.provider_name}
                            </div>
                          );
                        })}
                        {overflow > 0 && (
                          <div className="px-1 text-[10px] font-medium text-slate-400">+{overflow} more</div>
                        )}
                      </div>
                    </div>
                  );
                })}
                {/* Trailing blanks to complete last row */}
                {Array.from({ length: (7 - ((gridCells.length) % 7)) % 7 }).map((_, i) => (
                  <div key={`trail-${i}`} role="gridcell" aria-hidden="true" className="min-h-[90px] border-b border-r border-slate-100 bg-slate-50/40" />
                ))}
              </div>
            </div>
          </div>

          {/* Day detail panel */}
          {selectedDay && (
            <div
              ref={detailRef}
              role="complementary"
              aria-label={`Deadlines for ${selectedDay}`}
              className="enterprise-panel w-80 shrink-0 overflow-auto rounded-[28px] p-5"
            >
              <div className="mb-4 flex items-start justify-between">
                <div>
                  <div className="text-xs font-semibold uppercase tracking-wide text-slate-400">
                    {parseKey(selectedDay).toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}
                  </div>
                  <div className="mt-0.5 text-base font-semibold text-slate-900">{selectedDeadlines.length} deadline{selectedDeadlines.length !== 1 ? 's' : ''}</div>
                </div>
                <button
                  type="button"
                  onClick={() => setSelectedDay(null)}
                  aria-label="Close day detail"
                  className="flex h-7 w-7 items-center justify-center rounded-full text-slate-400 hover:bg-slate-100"
                >
                  <X size={14} />
                </button>
              </div>
              <div className="space-y-3">
                {selectedDeadlines.map((d) => {
                  const cfg = PRIORITY_CONFIG[d.priority_tier] || PRIORITY_CONFIG['LOW'];
                  return (
                    <div key={d.deadline_id} className="rounded-[18px] border border-slate-100 bg-white p-3">
                      <div className="flex items-start gap-2">
                        <span className={`mt-0.5 inline-flex h-2 w-2 shrink-0 rounded-full ${cfg.dot}`} aria-label={cfg.label} />
                        <div className="min-w-0 flex-1">
                          <div className="truncate text-sm font-semibold text-slate-900">{d.provider_name}</div>
                          <div className="mt-0.5 text-xs text-slate-500">{d.deadline_type}</div>
                          <div className="mt-1.5 flex flex-wrap gap-x-3 gap-y-1 text-[11px] text-slate-400">
                            <span>Action by: {d.action_required_by?.slice(0, 10)}</span>
                            {d.event_date && <span>Event: {d.event_date?.slice(0, 10)}</span>}
                            <span>{d.notice_days}d notice</span>
                          </div>
                        </div>
                        <span className={`shrink-0 rounded-full px-2 py-0.5 text-[10px] font-semibold ${cfg.pill}`}>{cfg.label}</span>
                      </div>
                      <Link
                        to={`/?provider=${encodeURIComponent(d.provider_name)}`}
                        className="mt-2 flex items-center justify-center rounded-xl border border-bsc-blue-200 bg-bsc-blue-50 py-1.5 text-xs font-medium text-bsc-blue-700 hover:bg-bsc-blue-100"
                        aria-label={`Ask AI about ${d.provider_name}`}
                      >
                        Ask AI about this provider
                      </Link>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
