import { useEffect, useMemo, useState } from 'react';
import { CheckCircle2, ClipboardList, Loader2, Search } from 'lucide-react';

interface ComplianceRow {
  regulation: string;
  compliance_status: string;
  provider_count: number;
  pct_of_regulation: number;
}

interface ProviderComplianceRow {
  regulation: string;
  requirement_category: string;
  compliance_status: string;
  risk_level: string;
  evidence_text?: string;
  source_filename?: string;
}

const REGULATION_LABELS: Record<string, string> = {
  KNOX_KEENE: 'Knox-Keene Act',
  CMS_MA: 'CMS Medicare Advantage',
  DMHC_STANDARDS: 'DMHC Standards',
  AB_1455: 'AB 1455',
  SB_137: 'SB 137',
  AB_352: 'AB 352',
  AB_72: 'AB 72',
};

const STATUS_CONFIG: Record<string, { label: string; color: string; bar: string }> = {
  COMPLIANT: { label: 'Compliant', color: 'text-emerald-700 bg-emerald-100', bar: 'bg-emerald-500' },
  PARTIAL: { label: 'Partial', color: 'text-amber-700 bg-amber-100', bar: 'bg-amber-400' },
  UNKNOWN: { label: 'Unknown', color: 'text-slate-600 bg-slate-100', bar: 'bg-slate-300' },
  EXEMPT: { label: 'Exempt', color: 'text-sky-700 bg-sky-100', bar: 'bg-sky-400' },
};

function StatusBadge({ status }: { status: string }) {
  const cfg = STATUS_CONFIG[status] || { label: status, color: 'text-slate-600 bg-slate-100', bar: 'bg-slate-300' };
  return <span className={`inline-flex rounded-full px-2.5 py-0.5 text-[11px] font-semibold ${cfg.color}`}>{cfg.label}</span>;
}

interface RegRow { compliant: number; partial: number; unknown: number; exempt: number; total: number }

export default function CompliancePageV2() {
  const [rows, setRows] = useState<ComplianceRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');
  const [providerRows, setProviderRows] = useState<ProviderComplianceRow[] | null>(null);
  const [providerLoading, setProviderLoading] = useState(false);
  const [providerError, setProviderError] = useState('');
  const [searchedName, setSearchedName] = useState('');

  useEffect(() => {
    const load = async (attempt = 0) => {
      if (attempt === 0) setLoading(true);
      let retryScheduled = false;
      try {
        const res = await fetch('/api/v1/compliance/summary');
        if (res.status === 503 && attempt < 6) {
          retryScheduled = true;
          setTimeout(() => { void load(attempt + 1); }, 10_000);
          return;
        }
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data = await res.json() as { compliance_by_regulation: ComplianceRow[] };
        setRows(data.compliance_by_regulation || []);
      } catch (err) {
        if (attempt < 6) {
          retryScheduled = true;
          setTimeout(() => { void load(attempt + 1); }, 10_000);
          return;
        }
        setError(err instanceof Error ? err.message : 'Failed to load compliance data');
      } finally {
        if (!retryScheduled) setLoading(false);
      }
    };
    void load();
  }, []);

  const byRegulation = useMemo(() => {
    const map: Record<string, RegRow> = {};
    for (const row of rows) {
      if (!map[row.regulation]) map[row.regulation] = { compliant: 0, partial: 0, unknown: 0, exempt: 0, total: 0 };
      const m = map[row.regulation];
      m.total += row.provider_count;
      if (row.compliance_status === 'COMPLIANT') m.compliant += row.provider_count;
      else if (row.compliance_status === 'PARTIAL')  m.partial  += row.provider_count;
      else if (row.compliance_status === 'UNKNOWN')  m.unknown  += row.provider_count;
      else if (row.compliance_status === 'EXEMPT')   m.exempt   += row.provider_count;
    }
    return map;
  }, [rows]);

  const regulations = Object.keys(byRegulation).sort();

  const totalProviders = useMemo(() => {
    const t = Object.values(byRegulation).find(Boolean);
    return t?.total || 0;
  }, [byRegulation]);

  const overallCompliant = useMemo(() => {
    const vals = Object.values(byRegulation);
    if (!vals.length) return 0;
    return Math.round(vals.reduce((s, v) => s + (v.total ? v.compliant / v.total : 0), 0) / vals.length * 100);
  }, [byRegulation]);

  const lookupProvider = async () => {
    const name = search.trim();
    if (!name) return;
    setSearchedName(name);
    setProviderLoading(true);
    setProviderError('');
    setProviderRows(null);
    try {
      const res = await fetch(`/api/v1/compliance/${encodeURIComponent(name)}`);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json() as { compliance_records: ProviderComplianceRow[] };
      setProviderRows(data.compliance_records || []);
    } catch (err) {
      setProviderError(err instanceof Error ? err.message : 'Failed to load provider compliance');
    } finally {
      setProviderLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      <section className="enterprise-panel rounded-[32px] p-6">
        <div className="flex flex-wrap items-start justify-between gap-4 border-b border-slate-200/80 pb-5">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.24em] text-bsc-blue-700">
              <ClipboardList size={14} /> Compliance Matrix
            </div>
            <h1 className="mt-2 text-3xl font-semibold text-slate-950">Regulatory compliance tracking</h1>
            <p className="mt-2 max-w-3xl text-sm leading-6 text-slate-600">
              Compliance status for {totalProviders} providers across {regulations.length} regulations.
              Status reflects contractual language extraction — PARTIAL/UNKNOWN means the requirement was not fully
              confirmed in source documents.
            </p>
          </div>
          <div className="enterprise-card rounded-2xl p-4">
            <div className="text-xs uppercase tracking-wide text-slate-500">Avg compliant rate</div>
            <div className="mt-2 text-3xl font-semibold text-emerald-700">{overallCompliant}%</div>
          </div>
        </div>

        {error ? <div className="mt-5 rounded-2xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700">{error}</div> : null}

        {loading ? (
          <div className="mt-6 flex items-center gap-3 rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-500">
            <Loader2 size={16} className="animate-spin" /> Loading compliance data
          </div>
        ) : (
          <div className="mt-6 space-y-3">
            {regulations.map((reg) => {
              const m = byRegulation[reg];
              const compliantPct = m.total ? Math.round(m.compliant / m.total * 100) : 0;
              const partialPct   = m.total ? Math.round(m.partial  / m.total * 100) : 0;
              const unknownPct   = m.total ? Math.round(m.unknown  / m.total * 100) : 0;
              const exemptPct    = m.total ? Math.round(m.exempt   / m.total * 100) : 0;
              return (
                <div key={reg} className="rounded-[28px] border border-slate-200 bg-white p-5">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div>
                      <div className="font-semibold text-slate-900">{REGULATION_LABELS[reg] || reg}</div>
                      <div className="mt-1 text-xs text-slate-400">{m.total} providers</div>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {[
                        { key: 'COMPLIANT', count: m.compliant, pct: compliantPct },
                        { key: 'PARTIAL',   count: m.partial,   pct: partialPct },
                        { key: 'UNKNOWN',   count: m.unknown,   pct: unknownPct },
                        { key: 'EXEMPT',    count: m.exempt,    pct: exemptPct },
                      ].filter(({ count }) => count > 0).map(({ key, count, pct }) => (
                        <div key={key} className="flex items-center gap-1.5">
                          <StatusBadge status={key} />
                          <span className="text-xs text-slate-500">{count} ({pct}%)</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  {/* Stacked bar */}
                  <div className="mt-4 flex h-2 w-full overflow-hidden rounded-full bg-slate-100">
                    {compliantPct > 0 && <div style={{ width: `${compliantPct}%` }} className="bg-emerald-500" />}
                    {partialPct   > 0 && <div style={{ width: `${partialPct}%`   }} className="bg-amber-400" />}
                    {exemptPct    > 0 && <div style={{ width: `${exemptPct}%`    }} className="bg-sky-400" />}
                    {unknownPct   > 0 && <div style={{ width: `${unknownPct}%`   }} className="bg-slate-300" />}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>

      {/* Provider drill-down */}
      <section className="enterprise-panel rounded-[32px] p-6">
        <div className="mb-5 flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.24em] text-bsc-blue-700">
          <CheckCircle2 size={14} /> Provider drill-down
        </div>
        <div className="flex gap-3">
          <label className="relative flex-1">
            <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter') { void lookupProvider(); } }}
              placeholder="Search provider name (e.g. Hoag, Sutter)…"
              className="w-full rounded-2xl border border-slate-200 bg-white py-3 pl-9 pr-3 text-sm outline-none focus:border-bsc-blue-300"
            />
          </label>
          <button
            type="button"
            onClick={() => { void lookupProvider(); }}
            disabled={!search.trim() || providerLoading}
            className="rounded-2xl bg-slate-950 px-5 py-3 text-sm font-medium text-white disabled:opacity-40 hover:bg-slate-800"
          >
            {providerLoading ? <Loader2 size={15} className="animate-spin" /> : 'Look up'}
          </button>
        </div>

        {providerError ? <div className="mt-4 rounded-2xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700">{providerError}</div> : null}

        {providerRows !== null && (
          providerRows.length === 0 ? (
            <div className="mt-4 rounded-2xl border border-dashed border-slate-200 px-4 py-8 text-center text-sm text-slate-400">
              No compliance records found for "{searchedName}".
            </div>
          ) : (
            <div className="mt-4 space-y-4">
              <div className="text-sm font-semibold text-slate-800">{providerRows.length} records for "{searchedName}"</div>
              <div className="app-scrollbar overflow-auto rounded-[28px] border border-slate-200">
                <table className="min-w-full text-sm">
                  <thead className="bg-slate-50 text-left text-xs uppercase tracking-wide text-slate-500">
                    <tr>
                      <th className="px-4 py-3">Regulation</th>
                      <th className="px-4 py-3">Category</th>
                      <th className="px-4 py-3">Status</th>
                      <th className="px-4 py-3">Risk level</th>
                      <th className="px-4 py-3">Evidence</th>
                    </tr>
                  </thead>
                  <tbody>
                    {providerRows.map((row, i) => (
                      <tr key={`${row.regulation}-${i}`} className="border-t border-slate-100 align-top">
                        <td className="px-4 py-3 font-medium text-slate-800">{REGULATION_LABELS[row.regulation] || row.regulation}</td>
                        <td className="px-4 py-3 text-slate-600">{row.requirement_category}</td>
                        <td className="px-4 py-3"><StatusBadge status={row.compliance_status} /></td>
                        <td className="px-4 py-3">
                          {row.risk_level ? (
                            <span className={`inline-flex rounded-full px-2 py-0.5 text-[11px] font-semibold ${
                              row.risk_level === 'HIGH' ? 'bg-rose-100 text-rose-700' :
                              row.risk_level === 'MEDIUM' ? 'bg-amber-100 text-amber-700' :
                              'bg-slate-100 text-slate-600'
                            }`}>{row.risk_level}</span>
                          ) : <span className="text-slate-400">—</span>}
                        </td>
                        <td className="px-4 py-3 max-w-xs text-xs text-slate-500 line-clamp-2">{row.evidence_text || '—'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )
        )}
      </section>
    </div>
  );
}
