import { useCallback, useRef, useState } from 'react';
import type { Citation, ConfidenceLabel, QueryRequest, StreamEvent } from '../types/api';

export interface StreamingProgress {
  isStreaming: boolean;
  thinking: string;
  answer: string;
  toolSteps: { tool: string; summary: string; step: number }[];
  citations: Citation[];
  confidence: { label: ConfidenceLabel; score: number } | null;
  done: { latency_ms: number; cost_usd: number; tool_calls: number; tool_names: string[]; session_id: string } | null;
  error: string | null;
}

export interface StreamResult {
  answer: string;
  citations: Citation[];
  confidence: { label: ConfidenceLabel; score: number } | null;
  done: { latency_ms: number; cost_usd: number; tool_calls: number; tool_names: string[]; session_id: string } | null;
  error: string | null;
}

const INITIAL_PROGRESS: StreamingProgress = {
  isStreaming: false,
  thinking: '',
  answer: '',
  toolSteps: [],
  citations: [],
  confidence: null,
  done: null,
  error: null,
};

export function useStreamQueryV2() {
  const [progress, setProgress] = useState<StreamingProgress>(INITIAL_PROGRESS);
  const abortRef = useRef<AbortController | null>(null);

  const reset = useCallback(() => {
    setProgress(INITIAL_PROGRESS);
  }, []);

  const abort = useCallback(() => {
    abortRef.current?.abort();
    setProgress((prev) => ({
      ...prev,
      isStreaming: false,
      thinking: prev.thinking || 'Response canceled',
    }));
  }, []);

  const stream = useCallback(async (request: QueryRequest): Promise<StreamResult> => {
    abortRef.current?.abort();
    const controller = new AbortController();
    abortRef.current = controller;

    let answer = '';
    let citations: Citation[] = [];
    let confidence: { label: ConfidenceLabel; score: number } | null = null;
    let done: { latency_ms: number; cost_usd: number; tool_calls: number; tool_names: string[]; session_id: string } | null = null;
    let error: string | null = null;
    const toolNames: string[] = [];

    setProgress({ ...INITIAL_PROGRESS, isStreaming: true });

    try {
      const res = await fetch('/api/v1/query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...request, stream: true }),
        signal: controller.signal,
      });

      if (res.status === 503) {
        // Runtime still starting up — surface a friendly message instead of raw 503
        const body = await res.json().catch(() => ({})) as Record<string, string>;
        const msg = body.detail || 'The assistant is still starting up. Please try again in a moment.';
        throw new Error(msg);
      }
      if (!res.ok) {
        throw new Error(`API returned ${res.status}`);
      }

      const reader = res.body?.getReader();
      if (!reader) {
        throw new Error('Streaming response body unavailable');
      }

      const decoder = new TextDecoder();
      let buffer = '';

      while (true) {
        const { done: streamDone, value } = await reader.read();
        if (streamDone) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';

        for (const line of lines) {
          if (!line.trim()) continue;

          let event: StreamEvent;
          try {
            event = JSON.parse(line) as StreamEvent;
          } catch {
            continue;
          }

          setProgress((prev) => applyEvent(prev, event));

          switch (event.type) {
            case 'answer_chunk':
              answer += event.content;
              break;
            case 'tool_use':
              if (event.tool && !toolNames.includes(event.tool)) toolNames.push(event.tool);
              break;
            case 'citations':
              citations = event.citations;
              break;
            case 'confidence':
              confidence = { label: event.label, score: event.score };
              break;
            case 'done':
              done = {
                latency_ms: event.latency_ms,
                cost_usd: event.cost_usd,
                tool_calls: event.tool_calls,
                tool_names: toolNames,
                session_id: event.session_id || '',
              };
              break;
            case 'error':
              error = event.message;
              break;
          }
        }
      }
    } catch (err) {
      if ((err as Error).name !== 'AbortError') {
        error = err instanceof Error ? err.message : 'Unknown error';
        setProgress((prev) => ({ ...prev, error, isStreaming: false }));
      }
    } finally {
      setProgress((prev) => ({ ...prev, isStreaming: false }));
    }

    return {
      answer,
      citations,
      confidence,
      done,
      error,
    };
  }, []);

  return {
    progress,
    stream,
    abort,
    reset,
  };
}

function applyEvent(state: StreamingProgress, event: StreamEvent): StreamingProgress {
  switch (event.type) {
    case 'thinking':
      return { ...state, thinking: event.content };
    case 'tool_start':
      return {
        ...state,
        toolSteps: [...state.toolSteps, { tool: event.tool, summary: '', step: event.step }],
      };
    case 'tool_result':
      return {
        ...state,
        toolSteps: state.toolSteps.map((step) =>
          step.step === event.step ? { ...step, summary: event.summary } : step,
        ),
      };
    case 'answer_chunk':
      return { ...state, answer: state.answer + event.content };
    case 'citations':
      return { ...state, citations: event.citations };
    case 'confidence':
      return { ...state, confidence: { label: event.label, score: event.score } };
    case 'done':
      return {
        ...state,
        done: {
          latency_ms: event.latency_ms,
          cost_usd: event.cost_usd,
          tool_calls: event.tool_calls,
          tool_names: state.done?.tool_names ?? [],
          session_id: event.session_id || '',
        },
      };
    case 'error':
      return { ...state, error: event.message };
    default:
      return state;
  }
}
