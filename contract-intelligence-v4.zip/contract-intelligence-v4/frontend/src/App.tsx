import { Component, useEffect, useState } from 'react';
import type { ErrorInfo, ReactNode } from 'react';
import { NavLink, Route, Routes } from 'react-router-dom';
import {
  Activity,
  AlertTriangle,
  Building2,
  CalendarClock,
  ClipboardList,
  FileText,
  Loader2,
  Menu,
  MessageSquare,
  ShieldCheck,
  X,
} from 'lucide-react';
import ChatPageV2 from './pages/ChatPageV2';
import ProviderExplorerV2 from './pages/ProviderExplorerV2';
import ReportPageV2 from './pages/ReportPageV2';
import StatusPageV2 from './pages/StatusPageV2';
import DocumentViewerV2 from './pages/DocumentViewerV2';
import AlertsPageV2 from './pages/AlertsPageV2';
import CompliancePageV2 from './pages/CompliancePageV2';
import DeadlineCalendarV2 from './pages/DeadlineCalendarV2';

// ── Error Boundary ───────────────────────────────────────────────────────────
interface ErrorBoundaryState { hasError: boolean; error: Error | null; }

class ErrorBoundary extends Component<{ children: ReactNode }, ErrorBoundaryState> {
  constructor(props: { children: ReactNode }) {
    super(props);
    this.state = { hasError: false, error: null };
  }
  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { hasError: true, error };
  }
  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error('[ErrorBoundary]', error, info.componentStack);
  }
  render() {
    if (this.state.hasError) {
      return (
        <div className="flex h-screen items-center justify-center bg-slate-50 p-8">
          <div className="max-w-md rounded-2xl border border-rose-200 bg-white p-8 text-center shadow-lg">
            <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-rose-100 text-rose-600 text-lg font-bold">!</div>
            <h2 className="mt-4 text-lg font-bold text-slate-900">Something went wrong</h2>
            <p className="mt-2 text-sm text-slate-600">The application encountered an unexpected error.</p>
            <p className="mt-2 rounded-lg bg-slate-100 px-3 py-2 text-xs font-mono text-slate-500 break-all">{this.state.error?.message}</p>
            <button type="button" onClick={() => { this.setState({ hasError: false, error: null }); window.location.href = '/'; }} className="mt-5 rounded-lg bg-bsc-blue-600 px-5 py-2.5 text-sm font-medium text-white hover:bg-bsc-blue-700">Return home</button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

const navItems = [
  { to: '/', icon: MessageSquare, label: 'Workspace' },
  { to: '/providers', icon: Building2, label: 'Providers' },
  { to: '/reports', icon: FileText, label: 'Reports' },
  { to: '/alerts', icon: AlertTriangle, label: 'Alerts' },
  { to: '/compliance', icon: ClipboardList, label: 'Compliance' },
  { to: '/calendar', icon: CalendarClock, label: 'Calendar' },
  { to: '/status', icon: Activity, label: 'Status' },
];

function ShellNav({ onNavigate }: { onNavigate?: () => void }) {
  return (
    <div className="flex h-full flex-col">
      <div className="px-5 py-5">
        <div className="flex items-center gap-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-bsc-blue-600 text-white">
            <ShieldCheck size={18} />
          </div>
          <div>
            <div className="text-sm font-bold text-slate-900">Contract Intel</div>
            <div className="text-[11px] text-slate-400">Enterprise Platform</div>
          </div>
        </div>
      </div>

      <nav className="flex-1 px-3 space-y-1" aria-label="Main navigation">
        {navItems.map(({ to, icon: Icon, label }) => (
          <NavLink
            key={to}
            to={to}
            end={to === '/'}
            onClick={onNavigate}
            aria-label={label}
            className={({ isActive }) =>
              `flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors ${
                isActive
                  ? 'bg-bsc-blue-50 text-bsc-blue-700'
                  : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
              }`
            }
          >
            <Icon size={18} aria-hidden="true" />
            {label}
          </NavLink>
        ))}
      </nav>

      <div className="border-t border-slate-100 px-5 py-4">
        <div className="text-[11px] text-slate-400">v4.0.0 &middot; Blue Shield of California</div>
      </div>
    </div>
  );
}

export default function AppV2() {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <>
      {/* M1: Skip-to-content link for keyboard users */}
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[100] focus:rounded-lg focus:bg-bsc-blue-600 focus:px-4 focus:py-2 focus:text-sm focus:font-medium focus:text-white"
      >
        Skip to main content
      </a>

      <div className="enterprise-shell text-slate-900">
        <div className="flex h-screen overflow-hidden">
          <aside className="enterprise-sidebar hidden w-[220px] shrink-0 xl:block" aria-label="Application sidebar">
            <ShellNav />
          </aside>

          {mobileOpen && (
            <div
              className="enterprise-mobile-overlay fixed inset-0 z-40 xl:hidden"
              role="dialog"
              aria-modal="true"
              aria-label="Navigation menu"
              onClick={() => setMobileOpen(false)}
            >
              <aside className="h-full w-[240px] bg-white shadow-xl" onClick={(e) => e.stopPropagation()}>
                <ShellNav onNavigate={() => setMobileOpen(false)} />
              </aside>
            </div>
          )}

          <div className="flex min-w-0 flex-1 flex-col">
            <header className="sticky top-0 z-30 flex items-center justify-between border-b border-slate-100 bg-white px-4 py-3 xl:hidden">
              <button type="button" onClick={() => setMobileOpen((v) => !v)} className="flex h-9 w-9 items-center justify-center rounded-lg border border-slate-200 text-slate-600" aria-label="Toggle navigation menu" aria-expanded={mobileOpen}>
                {mobileOpen ? <X size={16} aria-hidden="true" /> : <Menu size={16} aria-hidden="true" />}
              </button>
              <div className="text-sm font-semibold text-slate-800">Contract Intelligence</div>
              <div className="w-9" />
            </header>

            <main id="main-content" className="flex-1 overflow-hidden p-3 md:p-4 xl:p-5">
              <ErrorBoundary>
                <Routes>
                  <Route path="/" element={<ChatPageV2 />} />
                  <Route path="/providers" element={<ProviderExplorerV2 />} />
                  <Route path="/reports" element={<ReportPageV2 />} />
                  <Route path="/alerts" element={<AlertsPageV2 />} />
                  <Route path="/compliance" element={<CompliancePageV2 />} />
                  <Route path="/calendar" element={<DeadlineCalendarV2 />} />
                  <Route path="/status" element={<StatusPageV2 />} />
                  <Route path="/viewer" element={<DocumentViewerV2 />} />
                </Routes>
              </ErrorBoundary>
            </main>
          </div>
        </div>
      </div>
    </>
  );
}
