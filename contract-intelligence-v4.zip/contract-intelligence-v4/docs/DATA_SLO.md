# Contract Intelligence V4 — Data SLO Contract

## Effective: 2026-07-12
## Owner: Contract Operations / Data Engineering

---

## 1. Data Freshness SLOs

| Table | Freshness Target | Refresh Cadence | Monitoring |
|-------|-----------------|-----------------|------------|
| tbl_contract_rates_all | <24h from contract amendment | On extraction pipeline run | vw_phase6_table_drift_detection |
| tbl_genie_provider_profile | <24h from rate/clause changes | Triggered by rate/clause updates | vw_phase6_regression_sentinels |
| tbl_contract_documents_master | <1h from PDF ingestion | Event-driven (volume watcher) | fact_file_extraction |
| tbl_vs_unified_ready | <4h from document parsing | Post-extraction pipeline | VS chunk count drift sentinel |
| tbl_contract_clauses | <24h from extraction | Pipeline batch | Clause count sentinel |
| bridge_provider_alias | <1h from orphan detection | Triggered by rate insert | S-3 sentinel |

## 2. Data Quality SLOs

| Metric | Target | Current | Sentinel |
|--------|--------|---------|----------|
| Rate validity (is_valid_rate=true) | >95% | 98.0% | S-1 |
| Domain-aware outliers | 0 | 0 | S-2 |
| Referential integrity (rates→profile) | 100% | 100% | S-3 |
| Referential integrity (clauses→profile) | 100% | 100% | NEW |
| Offset clause integrity (profile HAS = clause HAS) | 100% | 100% | S-6 |
| Provider profile↔service_areas sync | 100% | 100% | S-5 |
| Regression sentinel pass rate | 10/10 | 10/10 | vw_phase6_regression_sentinels |

## 3. Availability SLOs

| Service | Target | Monitoring |
|---------|--------|------------|
| Contract Intelligence App | 99.5% uptime | /health endpoint |
| SQL query tool (Genie) | <5s p95 latency | app_query_telemetry |
| Provider Explorer | <3s p95 latency | app_query_telemetry |

## 4. Incident Response

| Severity | Response Time | Escalation |
|----------|--------------|------------|
| CRITICAL (sentinel FAIL, data corruption) | <1h | Data Engineering + Contract Ops |
| HIGH (>5% quality degradation) | <4h | Data Engineering |
| MEDIUM (cosmetic, non-blocking) | <24h | Next sprint |
| LOW (documentation, minor gaps) | Best effort | Backlog |

## 5. Known Limitations (Accepted Risk)

- 8,297 NULL rate_numeric: formula-based rates (by-design, no SLO breach)
- 444 ACTIVE_NO_EXPIRY documents: evergreen contracts (correct behavior)
- Rate benchmarks: synthetic only until CMS/DHCS integration
- 39 providers missing base contract PDFs: blocked on document procurement

## 6. Review Cadence

This SLO is reviewed monthly by Data Engineering and Contract Operations.
Next review: 2026-08-12.
