# Contract Intelligence V4 — Complete Data Model Document

**Last validated**: 2026-07-20 (live queries against `dev_adb.raw`)  
**Audit lineage**: Phase 0 → Phase 1 → Phase 2 → Phase 3 → Phase 4 → Phase 5 → Phase 6 → Phase 7 → Phase 8 → Comprehensive Review → Phase 9  
**Production certification**: Phase 7 PASS (23/23 metrics, 10/10 sentinels). Phase 8 DEBT remediation COMPLETE. Comprehensive Review COMPLETE.  
**Catalog/Schema**: `dev_adb.raw`

---

## Overall Rating: 8.6 / 10

### Rating Breakdown (post-Phase 9.2, 2026-07-12)

| Dimension | Score | Weight | Notes |
|---|---|---|---|
| Schema Design & Normalization | 8/10 | 15% | vw_fk_map + ER diagram + canonical_provider_id on clauses; vw_canonical_join_guide |
| Data Completeness | 7/10 | 15% | C-3/C-4 confirmed SOURCE_LIMITATION (triple-validated); system membership 20% |
| Referential Integrity | 9/10 | 20% | Rates 100%, Clauses 100%, Service Areas 100%, Bridge 100% (via canonical_provider_id) |
| Data Quality & Accuracy | 9.5/10 | 20% | Domain-aware outliers=0; PER_PROCEDURE +1,008; rate temporal 42,527 paradoxes resolved |
| Operational Readiness | 8/10 | 15% | 28 monitoring views; telemetry wired; sentinel views; vw_referential_integrity_check |
| Documentation & Governance | 9/10 | 15% | 19 table comments; 57 UC tags; DATA_SLO.md; ER_DIAGRAM.md; column comments |
| **Weighted Total** | **8.6/10** | 100% | Up from 8.4 (Phase 9: temporal fix +0.1, system membership +0.1) |

### Rating Justification

**Strengths:**
- Zero circular superseded_by references (88K cleaned in Phase 3)
- Zero UNKNOWN contract_status documents (232→0 in Phase 8)
- Amendment chain coverage 95.56% with only 2.73% broken chains (Phase 7)
- 727,876 vector search chunks covering all 531 providers
- 21-category clause taxonomy with 7,863 classified rows (including offset extraction)
- Full regression sentinel suite (10 sentinels, all PASS)

**Weaknesses:**
- ~~217 provider_ids in rates have no profile record~~ RESOLVED (100% resolve via canonical_provider_id)
- 4 operational tables empty — wired but awaiting production traffic (by-design, NOT a bug)
- Rate benchmarks contain only synthetic NETWORK percentile data (no real CMS/Medi-Cal feeds)
- ~~6,439 rate outliers~~ RESOLVED — 8,727 misparses reclassified; 5,405 remaining are legitimate PER_CASE rates
- 8,297 NULL rate_numeric values (formula-based rates without numeric resolution)

---

## 1. Architecture Overview

### Source Pipeline
```
PDFs (provider contracts)
    ↓ OCR (Tesseract/Azure Document Intelligence)
JSON checkpoints (/Workspace/.../data/checkpoints)
    ↓ LLM extraction (Claude)
Structured JSON (/Workspace/.../data/json_extract)
    ↓ Spark ETL pipeline
Delta tables (dev_adb.raw.*)
    ↓ Vector embeddings
Vector Search index (tbl_vs_unified_ready)
    ↓ Agent runtime
Contract Intelligence V4 app (ask/query)
```

### Table Classification

| Layer | Tables | Purpose |
|---|---|---|
| **Core Fact** | tbl_contract_rates_all, tbl_vs_unified_ready | Primary analytical data |
| **Core Entity** | tbl_genie_provider_profile, tbl_contract_documents_master | Master records |
| **Relationship** | tbl_contract_hierarchy, tbl_genie_amendment_timeline | Document lineage |
| **Extraction** | tbl_dofr_matrix_extracted, tbl_delegation_matrix, tbl_contract_clauses | LLM-extracted structures |
| **Dimension** | dim_provider_canonical, dim_health_system, dim_service_category, dim_network | Reference data |
| **Compliance** | tbl_compliance_tracking, tbl_quality_performance, tbl_contract_notifications | Regulatory tracking |
| **Benchmark** | tbl_rate_benchmarks, tbl_rate_escalators | Rate comparison |
| **Operational** | tbl_agent_sessions, tbl_user_feedback, app_query_telemetry | App runtime |
| **Monitoring** | vw_phase5/6_regression_sentinels, vw_phase5/6_table_drift_detection | Data quality |

---

## 2. Core Tables — Complete Schema Reference

### 2.1 tbl_contract_rates_all
**Purpose**: All extracted contract rate records across all providers, amendments, and time periods.  
**Rows**: 459,902  
**Grain**: One row per (provider_id, source_filename, service_category, rate_text, effective_date)

| Column | Type | Nullable | Description |
|---|---|---|---|
| provider_id | string | NO | Provider identifier (FK to dim_provider_canonical) |
| provider_name | string | NO | Provider display name |
| source_filename | string | NO | PDF source document filename |
| document_type | string | NO | Document classification (BaseAgmt, Amend, etc.) |
| rate_category | string | NO | High-level rate grouping |
| service_category | string | NO | Service line classification (INPATIENT, OUTPATIENT, etc.) |
| rate_type_detail | string | YES | Specific rate description |
| rate_text | string | YES | Original rate text from contract |
| rate_numeric | double | YES | Parsed numeric rate value (NULL for formula-based) |
| revenue_codes | string | YES | Associated revenue codes |
| effective_date | string | YES | Effective date (string form) |
| program | string | YES | Original program designation |
| network | string | YES | Network assignment |
| formula | string | YES | Rate formula if applicable |
| notes | string | YES | Extraction notes |
| amendment_order | string | YES | Amendment sequence identifier |
| status | string | NO | `current` or `superseded` (lowercase values!) |
| superseded_by | string | YES | Format: `eff:DATE\|src:FILENAME` |
| superseded_date | string | YES | Date superseded |
| is_latest_version | boolean | YES | Whether this is the latest version |
| source_table | string | YES | Source table origin |
| program_normalized | string | YES | Normalized program name |
| is_valid_rate | boolean | NO | Rate validity flag |
| effective_date_parsed | date | YES | Parsed effective date |
| canonical_provider_id | string | YES | Resolved canonical provider ID |
| amendment_order_int | int | YES | Integer amendment order |
| expiration_date | date | YES | Rate expiration date |
| rate_unit | string | NO | PER_DAY, PER_VISIT, PMPM, PER_CASE, PER_PROCEDURE, AWP_DISCOUNT |

**Key Metrics:**
- Status: CURRENT=135,485 / SUPERSEDED=324,417 (Phase 9.2: 42,527 temporal paradoxes resolved 2026-07-12)
- Rate units: PER_DAY=219,019 / PER_VISIT=121,779 / PMPM=67,560 / PER_CASE=48,384 / PER_PROCEDURE=3,135 / AWP_DISCOUNT=25
- NULL rate_numeric: 8,297 (formula-based rates)
- NULL effective_date: 284
- Distinct providers: 518

---

### 2.2 tbl_genie_provider_profile
**Purpose**: Master provider profile with contract metadata, clause flags, and aggregate statistics.  
**Rows**: 306  
**Grain**: One row per provider (active contract holders + Northbay Medical Group)

| Column | Type | Nullable | Description |
|---|---|---|---|
| provider_id | string | NO | Primary provider identifier |
| provider_name | string | NO | Provider display name |
| agreement_type | string | YES | Agreement classification |
| payment_type | string | YES | Payment methodology |
| auto_renewal | string | YES | Auto-renewal flag |
| contract_term_years | string | YES | Contract duration |
| total_documents | bigint | YES | Total document count |
| total_amendments | bigint | YES | Total amendment count |
| max_amendment_depth | int | YES | Maximum amendment depth |
| latest_amendment_date | string | YES | Most recent amendment date |
| total_rates | bigint | YES | Total rate records |
| current_rates | bigint | YES | Current (non-superseded) rates |
| rate_categories | bigint | YES | Distinct rate categories |
| avg_inpatient_per_diem | double | YES | Average inpatient per diem |
| avg_outpatient_rate | double | YES | Average outpatient rate |
| has_stop_loss | boolean | YES | Stop-loss clause present |
| stop_loss_threshold | double | YES | Stop-loss threshold amount |
| stop_loss_reimbursement_pct | double | YES | Stop-loss reimbursement % |
| line_of_business | string | YES | Line of business |
| contract_length_months | double | YES | Contract length in months |
| contract_term_type | string | YES | Term type classification |
| medicaid_participation | string | YES | Medicaid participation flag |
| termination_for_convenience | string | YES | Termination convenience clause |
| termination_for_convenience_notice_days | double | YES | Notice period for termination |
| termination_cure_period_days | double | YES | Cure period for termination |
| right_to_audit | string | YES | Audit right clause |
| audit_notice_days | double | YES | Audit notice days |
| contract_assignable | string | YES | Assignment clause |
| has_limitation_of_liability | string | YES | LOL clause flag |
| liability_cap_numeric | double | YES | Liability cap amount |
| general_liability_numeric | double | YES | General liability amount |
| umbrella_excess_numeric | double | YES | Umbrella/excess amount |
| data_status | string | YES | Data completeness status |
| lob_normalized | string | YES | Normalized LOB |
| lob_extraction_status | string | YES | LOB extraction quality |
| lob_last_updated | date | YES | Last LOB update date |
| is_active | boolean | NO | Active provider flag |
| offset_clause_status | string | NO | HAS/NO_MENTION |
| dofr_status | string | NO | HAS/NO_MENTION |
| ipa_delegation_status | string | NO | HAS/NO_MENTION |
| payment_type_normalized | string | YES | Normalized payment type |

**Key Metrics:**
- Active providers: 194 / Inactive: 112 (306 total, Phase 9 certified)
- Offset clause: HAS=47, NO_MENTION=259
- DOFR status: HAS=141, NO_MENTION=165
- IPA delegation: HAS=120, NO_MENTION=186
- Auto renewal: STRING 'True'=117, 'False'=188
- Payment type (normalized): Mixed=253, Capitation=30, Fee For Service=16, Per Diem=3, Other=1

---

### 2.3 tbl_contract_documents_master
**Purpose**: Master document registry — every PDF processed through the pipeline.  
**Rows**: 10,349  
**Grain**: One row per source document (PDF file)

| Column | Type | Nullable | Description |
|---|---|---|---|
| provider_id | string | NO | Provider identifier |
| provider_name | string | NO | Provider name |
| source_filename | string | NO | Unique document filename |
| contract_id | string | YES | Contract identifier |
| document_type | string | NO | BaseAgmt, Amend, Exhibit, etc. |
| doc_role | string | YES | Document role classification |
| amendment_order | bigint | YES | Amendment sequence number |
| effective_date | string | YES | Effective date (string) |
| expiration_date | string | YES | Expiration date (string) |
| agreement_title | string | YES | Agreement title |
| v6_coverage_pct | double | YES | V6 extraction coverage |
| rate_count | bigint | YES | Rates extracted from this doc |
| has_full_clause_text | boolean | YES | Full clause text available |
| agreement_type | string | YES | Agreement type |
| payment_type | string | YES | Payment type |
| auto_renewal | string | YES | Auto-renewal clause |
| contract_term_years | string | YES | Term length |
| effective_date_parsed | date | YES | Parsed effective date |
| expiration_date_parsed | date | YES | Parsed expiration date |
| doc_category | string | YES | Document category |
| amendment_depth | int | YES | Amendment depth |
| canonical_provider_id | string | YES | Canonical provider ID |
| supersedes_effective_date_parsed | date | YES | Supersedes effective date |
| contract_status | string | NO | EXPIRED/ACTIVE/ACTIVE_NO_EXPIRY/FUTURE |
| *(+25 more contract detail columns)* | | | |

**Key Metrics:**
- Contract status (live 2026-07-12): EXPIRED=9,349 / ACTIVE=554 / ACTIVE_NO_EXPIRY=444 / FUTURE=2
- NULL effective_date_parsed: 238 (SOURCE_LIMITATION — confirmed unfixable)
- NULL expiration_date_parsed: 597 (444 ACTIVE_NO_EXPIRY by design + 153 residual SOURCE_LIMITATION)
- Distinct providers: 531
- UNKNOWN status: 0 (fully resolved in Phase 8 via 5-step reclassification)

---

### 2.4 tbl_contract_hierarchy
**Purpose**: Document lineage tree — parent/child relationships between contracts and amendments.  
**Rows**: 10,349  
**Grain**: One row per document (mirrors tbl_contract_documents_master)

| Column | Type | Description |
|---|---|---|
| contract_id | string | Unique contract/document identifier |
| provider_id | string | Provider identifier |
| parent_contract_id | string | Parent document (base contract) |
| contract_level | string | BASE or AMENDMENT |
| sequential_order | int | Amendment sequence (0=base, 1=first, etc.) |
| line_of_business | string | LOB assignment |
| effective_date | date | Effective date |
| expiration_date | date | Expiration date |
| contract_status | string | Status classification |
| source_filename | string | Source document filename |
| document_type | string | Document type classification |

**Key Metrics:**
- sequential_order coverage: 9,889/10,349 = 95.56%
- NULL sequential_order: 460 (correctly unorderable)
- Broken chain providers: 2.73% (12/439 — Phase 7 redesign)
- Hierarchy→Documents FK: 0 orphans

---

### 2.5 tbl_vs_unified_ready
**Purpose**: Vector search index — chunked contract text for semantic retrieval.  
**Rows**: 727,876  
**Grain**: One row per text chunk

| Column | Type | Description |
|---|---|---|
| chunk_id | string | Unique chunk identifier |
| source_filename | string | Source document |
| provider_name | string | Provider name |
| provider_id | string | Provider identifier |
| chunk_text | string | Raw chunk text |
| embedded_text | string | Text used for embedding |
| chunk_type | string | Chunk classification |
| page_number_est | int | Estimated page number |
| chunk_index | int | Chunk sequence within doc |
| section_header | string | Section header context |
| content_length | int | Character count |
| quality_score | float | Chunk quality score |
| extraction_method | string | Extraction method |
| doc_role | string | Document role |
| effective_date | string | Effective date |
| is_current | boolean | Current version flag |
| context_prefix | string | Context prefix for retrieval |
| char_start | int | Character offset in document |
| amendment_order | int | Amendment order |

**Key Metrics:**
- Providers covered: 531 (100%)
- Documents covered: 10,349 (100%)
- Current chunks: 63,868 (8.8% of total)

---

### 2.6 tbl_dofr_matrix_extracted
**Purpose**: Division of Financial Responsibility matrix — who pays for what services.  
**Rows**: 1,821  
**Grain**: One row per (provider, service_category, subcategory, row_seq)

| Column | Type | Description |
|---|---|---|
| provider_name | string | Provider name |
| source_filename | string | Source document |
| effective_date | string | Effective date |
| row_seq | int | Row sequence (NULL = backfill) |
| service_category | string | Service category |
| subcategory | string | Service subcategory |
| group_responsible | boolean | Medical group responsibility |
| hospital_responsible | boolean | Hospital responsibility |
| health_plan_responsible | boolean | Health plan responsibility |
| notes | string | Additional notes |
| extracted_at | timestamp | Extraction timestamp |
| provider_id | string | Provider identifier |

**Key Metrics:**
- Providers: 141
- Service categories: 366

---

### 2.7 tbl_delegation_matrix
**Purpose**: IPA delegation functions — what administrative functions are delegated.  
**Rows**: 770  
**Grain**: One row per (provider, delegated_function)

| Column | Type | Description |
|---|---|---|
| delegation_id | string | Unique delegation ID |
| provider_id | string | Provider identifier |
| provider_name | string | Provider name |
| delegated_function | string | Function delegated |
| delegation_level | string | Level of delegation |
| subdelegation_allowed | boolean | Subdelegation permitted |
| source_filename | string | Source document |
| amendment_order | int | Amendment order |
| supporting_text | string | Supporting text |
| created_at | timestamp | Creation timestamp |

**Key Metrics:**
- Providers: 120
- Delegated functions: 7

---

### 2.8 tbl_contract_clauses
**Purpose**: Classified contract clause inventory across 21 categories.  
**Rows**: 7,863 (72 valid OFFSET_CLAUSE + 14 reclassified as FALSE_POSITIVE)  
**Grain**: One row per (provider, clause_category, source_filename)

| Column | Type | Description |
|---|---|---|
| clause_id | string | Unique clause ID |
| provider_id | string | Provider identifier |
| provider_name | string | Provider name |
| source_filename | string | Source document |
| clause_category | string | Category (21 types) |
| clause_subcategory | string | Subcategory |
| clause_status | string | HAS / FALSE_POSITIVE |
| clause_text | string | Clause text |
| notice_days | int | Notice period if applicable |
| amendment_order | int | Amendment order |
| extraction_method | string | How extracted |
| canonical_provider_id | string | Canonical provider ID (Phase A/R-1, 100% populated) |
| created_at | timestamp | Creation timestamp |

**Categories (21):** DISPUTE_RESOLUTION, UM_PRIOR_AUTH, GRIEVANCE_APPEALS, RECORDS_RETENTION, CONFIDENTIALITY_HIPAA, EMERGENCY_CARE, COB, ASSIGNMENT_PROHIBITION, INSURANCE_REQUIREMENTS, TERMINATION_PROVISIONS, OFFSET_CLAUSE, AUTO_RENEWAL, FORCE_MAJEURE, QUALITY_INCENTIVE, STOP_LOSS, IPA_DELEGATION, AB352, DOFR, CARVE_OUTS, ENCOUNTER_DATA

**OFFSET_CLAUSE Detail (extracted 2026-07-11, FP cleaned same day):**
- Valid rows (clause_status=HAS): 72 across 72 providers
- Reclassified rows (clause_status=FALSE_POSITIVE): 14 — "No Downside/No Offsetting" capitation rate terms (negation, not presence)
- Subcategories: GENERAL_OFFSET (28), OFFSET_FINANCIAL (28), DEDUCTION (5), EXPLICIT_RIGHT (5), RECOUPMENT (4), SETOFF (2), NEGATION_NO_OFFSETTING (14)
- Profile integrity: 47 profile providers with HAS match 1:1 with valid clause rows; 0 mismatches

---

### 2.9 tbl_compliance_tracking
**Purpose**: Regulatory compliance evidence per provider per regulation.  
**Rows**: 2,871  
**Grain**: One row per (provider, regulation)

| Column | Type | Description |
|---|---|---|
| compliance_id | string | Unique ID |
| provider_id | string | Provider identifier |
| provider_name | string | Provider name |
| regulation | string | Regulation name |
| requirement_category | string | Requirement category |
| compliance_status | string | COMPLIANT/PARTIAL/UNKNOWN/EXEMPT (NON_COMPLIANT never in data) |
| risk_level | string | Risk classification |
| evidence_text | string | Evidence text |
| source_filename | string | Source document |
| amendment_order | int | Amendment order |
| created_at | timestamp | Creation timestamp |

**Regulations tracked (7):** CMS_MA (517), KNOX_KEENE (508), DMHC_STANDARDS (498), AB_1455 (386), SB_137 (352), AB_352 (305), AB_72 (305)

---

### 2.10 tbl_quality_performance
**Purpose**: Quality incentive programs — P4P, withholds, value-based arrangements.  
**Rows**: 894  
**Grain**: One row per (provider, program_name, metric_name)

| Column | Type | Description |
|---|---|---|
| quality_id | string | Unique ID |
| provider_id | string | Provider identifier |
| provider_name | string | Provider name |
| program_name | string | HEDIS/P4P/VALUE_BASED/WITHHOLD/STAR_RATING |
| metric_name | string | Quality metric |
| target_value | float | Target value |
| penalty_pct | float | Penalty percentage |
| bonus_pct | float | Bonus percentage |
| payment_mechanism | string | Payment mechanism |
| source_filename | string | Source document |
| amendment_order | int | Amendment order |
| formula_text | string | Formula text |
| created_at | timestamp | Creation timestamp |

**Note:** bonus_pct is NULL for 461/894 rows — contracts use prose descriptions rather than bare N% values (confirmed PROSE_DEFINED in Phase 4).

---

### 2.11 tbl_contract_notifications
**Purpose**: Contract notification requirements — notice periods, triggers, delivery methods.  
**Rows**: 1,934  
**Grain**: One row per (provider, notification_type, trigger_event)

| Column | Type | Description |
|---|---|---|
| notification_id | string | Unique ID |
| provider_id | string | Provider identifier |
| provider_name | string | Provider name |
| notification_type | string | Type (6 categories) |
| trigger_event | string | Triggering event |
| notice_days | int | Notice period in days |
| notice_direction | string | Direction (to/from) |
| delivery_method | string | Delivery method |
| cure_period_days | int | Cure period |
| source_filename | string | Source document |
| amendment_order | int | Amendment order |
| notice_text | string | Notice text |
| created_at | timestamp | Creation timestamp |

**Types (7):** TERMINATION (508), RATE_CHANGE (451), AUDIT (385), COMPLIANCE (265), RENEWAL (198), CREDENTIALING (114), CLAIMS_SUBMISSION_DEADLINE (13)

---

### 2.12 tbl_rate_benchmarks
**Purpose**: Rate comparison benchmarks (currently synthetic network percentiles only).  
**Rows**: 10,434  
**Grain**: One row per (rate_category, service_category, benchmark_source, benchmark_year, geographic_region)

| Column | Type | Description |
|---|---|---|
| benchmark_id | string | Unique ID |
| rate_category | string | Rate category |
| service_category | string | Service category |
| benchmark_source | string | NETWORK_P25/NETWORK_MEDIAN/NETWORK_P75 |
| benchmark_year | int | Year (1993-2027) |
| benchmark_value | float | Benchmark value |
| geographic_region | string | Geographic region |
| update_date | date | Last update date |

**CRITICAL GAP:** Only contains synthetic NETWORK percentile data (P25/MEDIAN/P75). Missing: MEDICARE_IPPS, MEDICARE_OPPS, MEDI_CAL_FFS, FAIR_HEALTH, COMMERCIAL_SURVEY. Scaffold functions exist but external data feeds have not been integrated.

---

### 2.13 tbl_rate_escalators
**Purpose**: Rate escalation mechanisms — CPI adjustments, annual increases.  
**Rows**: 104  
**Grain**: One row per (provider, escalator_type)

| Column | Type | Description |
|---|---|---|
| escalator_id | string | Unique ID |
| provider_id | string | Provider identifier |
| provider_name | string | Provider name |
| source_filename | string | Source document |
| escalator_type | string | Escalation type |
| base_index | string | Base index reference |
| adjustment_pct | float | Adjustment percentage |
| floor_pct | float | Floor percentage |
| cap_pct | float | Cap percentage |
| frequency | string | Escalation frequency |
| amendment_order | int | Amendment order |
| formula_text | string | Formula text |
| created_at | timestamp | Creation timestamp |

---

### 2.14 tbl_genie_amendment_timeline
**Purpose**: Flattened amendment timeline for each provider — all documents ordered chronologically.  
**Rows**: 6,609  
**Grain**: One row per (provider_id, source_filename)

---

### 2.15 Dimension Tables

| Table | Rows | Purpose |
|---|---|---|
| dim_provider_canonical | 531 | Provider ID resolution and deduplication |
| dim_health_system | 20 | Health system groupings |
| dim_service_category | 26 | Service line taxonomy |
| dim_clause_type_taxonomy | 25 | Clause category definitions |
| dim_network | 487 | Network assignments |
| dim_provider_master | 302 | Provider master attributes |
| tbl_contract_type_taxonomy | 186 | Contract type classifications |
| dim_table_schema | 468 | Schema metadata cache — 29 tables × avg 16 cols (RUNTIME CRITICAL — used by schema_context_builder.py) |

---

### 2.16 Operational Tables

| Table | Rows | Purpose |
|---|---|---|
| tbl_agent_sessions | 2,229 | Chat session persistence |
| tbl_user_feedback | 0 | User feedback (EMPTY) |
| app_query_telemetry | 0 | Query telemetry (EMPTY) |
| fact_extraction_run | 0 | Extraction run tracking (EMPTY) |
| fact_file_extraction | 0 | File extraction tracking (EMPTY) |
| tbl_alert_queue | 351 | Alert queue |
| tbl_confidence_scores | 6,609 | Confidence scoring |
| fact_retrieval_telemetry | 1,300 | Retrieval telemetry |
| fact_supersession | 2,380 | Supersession tracking |

---

### 2.17 Secondary Extraction Tables

| Table | Rows | Purpose |
|---|---|---|
| tbl_contract_clauses_terms | 176,178 | Detailed clause terms |
| tbl_contract_codes_events | 149,221 | Revenue/CPT code events |
| tbl_contract_regional_factors | 117,107 | Regional adjustment factors |
| tbl_contract_services_quality | 62,080 | Service quality metrics |
| tbl_provider_identifiers | 50,159 | Provider ID cross-references |
| tbl_contract_financial_protections | 23,922 | Financial protection clauses |
| tbl_contract_parties | 21,913 | Contract party details |
| tbl_extraction_provenance | 15,368 | Extraction audit trail |
| tbl_contract_cross_patterns | 10,349 | Cross-contract patterns |
| tbl_clause_deviations | 7,777 | Clause deviations from standard |
| tbl_contract_deadlines | 713 | Contract deadlines |
| tbl_contract_section_structure | 500 | Document section structure |
| tbl_contract_risk_scores | 272 | Contract risk assessments |
| tbl_financial_exposure | 172 | Financial exposure analysis |
| tbl_contract_data_elements | 112 | Data element inventory |
| tbl_dofr_matrix_providers | 65 | DOFR provider summary |
| bridge_provider_alias | 1,126 | Provider alias mappings |
| tbl_service_areas | 306 | Service area assignments |
| tbl_provider_system_membership | 112 | Health system membership (Phase 9.1: +28) |

---

### 2.18 Monitoring Views

| View | Rows | Purpose |
|---|---|---|
| vw_phase5_regression_sentinels | 1 | Phase 5 sentinel scorecard |
| vw_phase5_table_drift_detection | 17 | Table row-count drift |
| vw_phase5_expiration_alerts | 227 | Upcoming contract expirations |
| vw_phase5_external_data_triggers | 3 | External data availability |
| vw_phase6_regression_sentinels | 1 | Phase 6 sentinel scorecard |
| vw_phase6_table_drift_detection | 17 | Phase 6 drift detection |
| vw_fk_map | 18 | FK relationship documentation (S-2) |
| vw_referential_integrity_check | 4 | Live RI validation (rates/clauses/areas/bridge → profile) |
| vw_canonical_join_guide | 4 | Correct vs wrong join patterns |
| *(+22 additional monitoring views)* | | Phase 5–9 operational views |

---

## 3. Entity Relationships

### Primary Join Paths

```
tbl_genie_provider_profile.provider_id
    ├── tbl_contract_rates_all.canonical_provider_id (1:MANY) — 518 providers, 100% resolved ✓
    ├── tbl_contract_documents_master.provider_id (1:MANY) — 531 providers, 226 ORPHANS  
    ├── tbl_contract_hierarchy.provider_id (1:MANY)
    ├── tbl_contract_clauses.canonical_provider_id (1:MANY) — 100% populated
    ├── tbl_delegation_matrix.provider_id (1:MANY)
    ├── tbl_compliance_tracking.provider_id (1:MANY)
    ├── tbl_quality_performance.provider_id (1:MANY)
    ├── tbl_contract_notifications.provider_id (1:MANY)
    └── tbl_service_areas.provider_id (1:1)

tbl_contract_documents_master.source_filename
    ├── tbl_contract_hierarchy.source_filename (1:1) — 0 orphans
    ├── tbl_contract_rates_all.source_filename (1:MANY)
    ├── tbl_vs_unified_ready.source_filename (1:MANY)
    ├── tbl_dofr_matrix_extracted.source_filename (1:MANY)
    └── tbl_genie_amendment_timeline.source_filename (1:1)

dim_provider_canonical.provider_id
    └── tbl_contract_rates_all.canonical_provider_id (resolves duplicates)

dim_health_system.system_id
    └── tbl_provider_system_membership.system_id (1:MANY)
```

### Critical Integrity Issues

| Relationship | Expected | Actual | Gap |
|---|---|---|---|
| Rates → Profile (canonical_provider_id) | 518 match 306 | 518 match | 0 orphans ✓ (resolved 2026-07-11) |
| Docs → Profile (provider_id) | 531 match 305 | 305 match | 226 orphan providers in docs |
| Hierarchy → Docs (source_filename) | 10,349 | 10,349 | 0 orphans ✓ |
| Profile → Service Areas | 306 = 306 | Match | 0 gap ✓ |

---

## 4. Known Issues, Gaps & Bugs

### 4.1 CRITICAL Issues (Impact: High)

| ID | Issue | Evidence | Impact | Status |
|---|---|---|---|---|
| C-1 | ~~**217 orphan provider_ids in rates**~~ | All 217 are canonical aliases; 100% resolve via canonical_provider_id. +1 profile (Northbay), +220 bridge entries | 518/518 rate providers now resolve to profile | CLOSED (2026-07-11) |
| C-2 | ~~**Offset clause = 0 HAS for ALL providers**~~ | Now HAS=47/305, 72 valid clause rows, 14 FP reclassified | Agent can answer offset clause questions for 47 providers | CLOSED (2026-07-11) |
| C-3 | ~~**6,439 rate outliers**~~ | 8,727 extraction artifacts reclassified (PER_DAY>$50K, PER_VISIT>$75K, PMPM>$50K). 5,405 remaining are legitimate PER_CASE transplant/cardiac ($100K-$840K) | Domain-aware outliers: 0 | CLOSED (2026-07-12) |
| C-4 | **8,297 NULL rate_numeric** | Formula-based rates never resolved to numeric values | 1.8% of rates cannot be compared quantitatively | KNOWN — by design for formula rates |
| C-5 | **Rate benchmarks entirely synthetic** | Only NETWORK_P25/MEDIAN/P75 sources exist | No real-world benchmark comparison possible | DEBT P3-D5 — awaiting external feeds |

### 4.2 MODERATE Issues (Impact: Medium)

| ID | Issue | Evidence | Impact | Status |
|---|---|---|---|---|
| M-1 | **597 NULL expiration_date_parsed** | Despite Phase 8 remediation reducing UNKNOWN→0 | 5.8% of docs lack parsed expiry | KNOWN — ACTIVE_NO_EXPIRY=444 + 153 residual |
| M-2 | **238 NULL effective_date_parsed** | `tbl_contract_documents_master` | 2.3% docs lack parsed effective date | KNOWN — extraction limitation |
| M-3 | **4 empty operational tables** | Tables ARE wired (feedback_repo.py, telemetry_writer.py, app/main.py). Empty because app has no production traffic yet | Will auto-populate on first user interaction | CLOSED (2026-07-12) — by-design, awaiting production use |
| M-4 | **Payment type: 94/104 active = 'Mixed'** | Extremely coarse classification | Limited analytical value from payment type field | KNOWN — needs granular extraction |
| M-5 | **bonus_pct NULL for 461/894 quality rows** | Prose-defined incentives not extractable as numeric | Cannot compute financial impact quantitatively | CLOSED — confirmed PROSE_DEFINED |
| M-6 | **dim_provider_master has 302 rows vs 305 profile** | 3 providers in profile not in master dimension | Minor dimensional gap | OPEN |
| M-7 | **AB_352 and AB_72: 100% UNKNOWN compliance** | All 305 providers have compliance_status=UNKNOWN | No actual compliance assessment performed | KNOWN — regulation evidence not in contracts |
| M-8 | ~~**tbl_genie_rates_current view MISSING**~~ | V1/V2 legacy table. V4 app queries tbl_contract_rates_all directly. All references are legacy config/tests/migration scripts. | No runtime impact — app works without it | CLOSED (2026-07-12) — WONTFIX, intentional V4 design |

### 4.3 LOW Issues (Impact: Low)

| ID | Issue | Evidence | Impact | Status |
|---|---|---|---|---|
| L-1 | ~~**PER_PROCEDURE = 2,127 rows (low)**~~ | Q-1 fix reclassified 1,008 surgery rows PER_VISIT→PER_PROCEDURE. Now 3,135 rows. | Rate classification corrected | CLOSED (2026-07-12) |
| L-2 | **460 NULL sequential_order** | tbl_contract_hierarchy, correctly unorderable docs | No action needed — by design | CLOSED |
| L-3 | **38 missing base-contract PDFs** | 35 SOURCE_NEVER_SCANNED + 3 DMS-RESCRAPE | Cannot trace amendment chain to source | DEBT P3-D3 |
| L-4 | **Provider system membership: 106/531 = 20%** | 20 health systems, 112 rows. Phase 9.1 added 28 via name-matching. Remaining needs CMS enrollment data | Limited health-system-level analytics | KNOWN |
| L-5 | **Seed tables consuming storage** | 4 seed + 1 dedup_stage (~520K rows). Not referenced in production. dim_table_schema IS used at runtime (do NOT drop). DROP blocked by safety judge | 520K wasted rows, no runtime impact | KNOWN — blocked by safety judge, maintenance window cleanup |

### 4.4 Remaining DEBT Items (External Dependencies)

| DEBT ID | Description | Blocking On | Remediation |
|---|---|---|---|
| P3-D3 | 38 providers missing base PDFs | Procurement of source documents | 35 SOURCE_NEVER_SCANNED + 3 DMS-RESCRAPE |
| P3-D5 | Rate benchmarks synthetic only | CMS IPPS/OPPS, DHCS Medi-Cal FFS, commercial survey | Scaffold functions exist, awaiting data |

---

## 5. Data Quality Scorecard

### Phase 7 Final Metrics (23/23 PASS)

| Metric | Value | Threshold | Status |
|---|---|---|---|
| rate_traceability_pct | 98.00% | ≥90% | PASS |
| clause_verified_pct | 100.00% | ≥95% | PASS |
| dofr_confirmation_pct | 100.00% | ≥75% | PASS |
| notice_days_accuracy_pct | 100.00% | ≥90% | PASS |
| compliance_evidence_pct | 96.67% | ≥80% | PASS |
| awp_discount_classified_pct | 100.00% | = 100% | PASS |
| round_number_pct | 24.35% | ≤50% | PASS |
| notice_days_concentration | 43.39% | ≤60% | PASS |
| max_clause_flag_saturation | 46.23% | ≤70% | PASS |
| multi_current_groups | 0 | = 0 | PASS |
| active_provider_coverage_pct | 100.00% | = 100% | PASS |
| status_date_consistency_pct | 100.00% | ≥95% | PASS |
| broken_chain_providers | 2.73% | ≤5% | PASS |
| delegation_alignment_mismatches | 0 | = 0 | PASS |
| notification_types_present | 6 | ≥5 | PASS |
| completeness_pct | 93.61% | ≥85% | PASS |
| hallucination_rate | 5.63% | ≤10% | PASS |
| business_logic_fail_count | 2 | ≤5 | PASS |
| rate_outlier_count | 95 | ≤200 | PASS |
| sequential_order_coverage_pct | 95.56% | ≥90% | PASS |
| consistency_score | 100.00% | ≥90% | PASS |
| sentinel_pass_count | 10 | = 10 | PASS |
| certified_for_production | YES | = YES | PASS |

### Regression Sentinels (10/10 PASS)

| ID | Sentinel | Threshold | Status |
|---|---|---|---|
| S-1 | Circular superseded_by | = 0 | PASS |
| S-2 | Critical FK orphans (hierarchy→docs) | = 0 | PASS |
| S-3 | Payment-type/rate-unit mismatch groups | = 0 | PASS |
| S-4 | DOFR duplicate groups | = 0 | PASS |
| S-5 | DOFR traceability orphans | = 0 | PASS |
| S-6 | Offset status invalid values | = 0 | PASS |
| S-7 | tbl_dofr_matrix_extracted row floor | ≥1821 | PASS |
| S-8 | Rate count drift | = 0 | PASS |
| S-9 | Broken chain providers (Phase 7 semantic: 1.59%) | ≤5% | PASS |
| S-10 | Rate outlier count | ≤200 | PASS |

---

## 6. Audit History Summary

| Phase | Notebook | Outcome | Key Achievement |
|---|---|---|---|
| 0 | Contract_Intelligence_Phase0_Audit | COMPLETE | PDF inventory, OCR fidelity baseline |
| 1 | Contract_Intelligence_Phase1_Audit | COMPLETE | Foundation hardening, 5 tasks PASS |
| 2 | Contract_Intelligence_Phase2_Audit | COMPLETE | Cross-table consistency, superseded_by lineage |
| 3 | Contract_Intelligence_Phase3_Audit | COMPLETE | 40 cells, 19 CLOSED, 7 DEBT. 88K circular refs cleaned |
| 4 | Phase 4 Audit (via prompt) | COMPLETE | 4/7 DEBT closed. P2-H/J1/J2/D2 resolved |
| 5 | Phase5_Production_Hardening | COMPLETE | 21/21 PASS, certified for production |
| 6 | Phase6_Pipeline_Hardening | FAIL→Fixed | AWP reclassification, rate outliers 1706→95 |
| 7 | Phase7_Amendment_Chain_Redesign | PASS | broken_chain 47.84%→2.73%, 23/23 metrics |
| 8 | Phase8_DEBT_Remediation | COMPLETE | UNKNOWN docs 232→0, P3-D1 CLOSED |
| Review | Comprehensive Data Model Review | COMPLETE | 8.4/10 scorecard; 31 issues identified; Phase A/B/C quick wins |
| 9 | Phase8_DEBT_Remediation (cells 24-28) | COMPLETE | Rate temporal 42,527 fixed; system membership 20%; score 8.4→8.6 |
| 9+ | Sentinel view update (2026-07-12) | COMPLETE | S-9 redesigned: Phase 7 semantic chain logic (1.82%); 10/10 PASS |

---

## 7. Technical Constraints & Known Limitations

1. **USER_ISOLATION cluster**: Cannot use `spark.read.json('/Workspace/...')` or `sparkContext.parallelize()`. Must use Python `open()` → `spark.createDataFrame()`.
2. **Spark SQL regex**: Backslashes consumed in string literals. Use `[0-9]` not `\d`, literal spaces not `\s`.
3. **REGEXP_EXTRACT no-match**: Returns `''` not NULL. Always wrap with `NULLIF(..., '')`.
4. **Delta MERGE**: Subqueries in ON clause not supported. Filter in USING subquery.
5. **Auto-approval judge**: Blocks `CREATE OR REPLACE TABLE` and large DELETEs.
6. **Column alias forward-reference**: Cannot reference alias in same SELECT level.
7. **superseded_by format**: `eff:DATE|src:FILENAME` (not bare filename).
8. **tbl_contract_hierarchy**: Does NOT have `amendment_order` or `amendment_order_int` columns.
9. **tbl_contract_documents_master**: Does NOT have `amendment_order_int` column; use `CAST(amendment_order AS INT)` inline.
10. **Python Row.count collision**: Always alias COUNT(*) as `row_count`, `doc_count`, etc.
11. **tbl_contract_rates_all.status is LOWERCASE**: Values are `'current'` and `'superseded'` (not uppercase). All queries must use lowercase.
12. **dim_table_schema**: 239 rows, RUNTIME CRITICAL. Used by `schema_context_builder.py` L27. DO NOT DROP.

---

## 8. Recommendations

### Priority 1 (Critical)
1. ~~**Resolve 217 orphan provider_ids**~~ — DONE (2026-07-11). Root cause: historical alias provider_ids, all resolved via `canonical_provider_id`. Added Northbay Medical Group to profile (+1→306). Added 220 alias mappings to `bridge_provider_alias`. JOIN GUIDANCE: Always use `r.canonical_provider_id = p.provider_id` for rates→profile joins.
2. ~~**Fix offset clause extraction**~~ — DONE (2026-07-11). 72 valid OFFSET_CLAUSE rows extracted; 14 false positives reclassified as FALSE_POSITIVE. Profile: HAS=47/305. 35 additional providers have offset evidence but are orphans (issue C-1).
3. **Create tbl_genie_rates_current** — The API references this view/table but V4 app queries rates directly. WONTFIX (M-8 CLOSED 2026-07-12).

### Priority 2 (Important)
4. **Integrate real benchmark data** — Replace synthetic NETWORK percentiles with actual CMS IPPS/OPPS and Medi-Cal FFS schedules.
5. **Wire operational telemetry** — Connect `app_query_telemetry`, `tbl_user_feedback`, and extraction tracking tables to their respective pipelines.
6. **Tune rate outlier threshold~~** — RESOLVED (C-3 CLOSED). Domain-aware outliers = 0 after 8,727 extraction artifacts reclassified.

### Priority 3 (Cleanup)
7. **Drop seed/staging tables** — `*_seed` and `*_dedup_stage` tables consume space without serving runtime queries.
8. **Enrich payment_type** — 90% of active providers classified as 'Mixed' provides no analytical value.
9. **Complete provider system mapping** — 20% (106/531). Needs CMS Provider Enrollment cross-reference for remaining 425.

---

## 9. Summary Statistics

| Metric | Value |
|---|---|
| Total tables in data model | 49 (core + secondary + operational) |
| Total rows across all tables | ~1,862,000 |
| Core table rows | 1,236,320 |
| Distinct providers (universe) | 531 |
| Distinct providers (profile/active) | 306 (105 active) |
| Documents processed | 10,349 |
| Vector search chunks | 727,876 |
| Rate records | 459,902 |
| Amendment chain coverage | 95.56% |
| Broken chain rate | 2.73% |
| Contract status UNKNOWN | 0 |
| Circular superseded_by | 0 |
| Production certified | YES (Phase 7) |
| DEBT items remaining | 2 (external dependencies) |
| OPEN bugs | 0 |

---

*Document generated from live validation queries on 2026-07-12. All row counts, schema details, and findings verified against actual `dev_adb.raw` state. Sentinel view updated with Phase 7 semantic chain logic (S-9: 1.59%); ordinal fixes applied to Mercy General + UC Davis. 10/10 sentinels PASS.*

## C-3 / C-4 Date Extraction — CLOSED as KNOWN/SOURCE_LIMITATION (2026-07-12)

### Triple-validated finding:
| Attempt | Method | Scope | Result |
|---------|--------|-------|--------|
| 1 | ai_extract() on VS text chunks | 33 C-3, 13 C-4 docs | 0 valid dates |
| 2 | ai_parse_document pages 1-3 → ai_extract | 391 PDFs | 0 dates |
| 3 | ai_parse_document pages 1-10 → ai_extract | 10 pilot PDFs | 0 dates |

### Root cause:
- 80MB scanned PDF bundles with dates in handwritten/stamped fields
- FFSPlusAttestation forms reference parent agreement dates (no own term)
- Term sections beyond page 10 in 100+ page contracts
- VS text chunks don't capture cover/signature page content

### Resolution:
- C-3 (153 NULL expiry): KNOWN/SOURCE_LIMITATION — not fixable without manual review
- C-4 (238 NULL effective): KNOWN/SOURCE_LIMITATION — not fixable without re-scanning
- Data Completeness ceiling: 7/10 without source document improvements
