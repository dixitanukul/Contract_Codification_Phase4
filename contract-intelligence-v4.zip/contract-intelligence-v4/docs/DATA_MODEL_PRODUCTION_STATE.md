# Contract Intelligence V4 — Production Data Model Reference

**Version**: v4 (Post Phase 10B Complete)
**Date**: 2026-07-20
**Catalog / Schema**: `dev_adb.raw`
**Audit coverage**: Phases 0 → 9 complete. Phase 5 certified `certified_for_production: YES` (21/21). Phase 7 re-certified (23/23, 10/10 sentinels). Phase 8 DEBT remediation complete (0 UNKNOWN docs, all sentinels PASS). Phase 9 deep audit: 20 PASS / 7 CONDITIONAL / 2 FAIL → remediated to PRODUCTION-READY. Phase 10B complete (10B-1 through 10B-6 — all 6 tool groups registered, validated, and live in production).
**Scope**: This document lists ONLY the 31 tables that are production-ready — populated with real data, audit-certified, and actively part of the new data model ecosystem. Legacy originals, empty tables, synthetic-only tables, and staging artifacts are explicitly excluded at the bottom.

---

## Quick Summary

| Category | Tables | Total Rows |
|---|---|---|
| Core Fact & Entity | 14 | ~1,232,149 |
| Phase 5–7 Core | 7 | ~77,262 |
| Dimension / Reference | 7 | ~29,807 |
| App Persistence (populated) | 3 | ~3,846 |
| **TOTAL** | **31** (excl. views) | **~1,343,064** |

---

## SECTION 1 — Core Fact & Entity Tables (14)

These are the primary source-of-truth tables the agent reads to answer user questions.

---

### 1.1 `tbl_contract_rates_all`
**Phase introduced**: Original (enriched through Phase 7)
**Rows**: 459,902
**Purpose**: Master reimbursement-rate fact table across all historical document versions. Single most business-critical table — errors here directly corrupt rate answers to users.

**Key columns**:
- `provider_id`, `provider_name`, `source_filename`
- `rate_category`, `service_category`
- `rate_numeric`, `rate_text`, `formula`, `revenue_codes`
- `rate_unit` — valid values: `PER_DAY`, `PER_VISIT`, `PMPM`, `PER_CASE`, `PER_PROCEDURE`, `AWP_DISCOUNT`, `UNCLASSIFIED`
- `effective_date_parsed`, `expiration_date`
- `status` — lowercase `current` / `superseded`
- `superseded_by` — format: `eff:DATE|src:FILENAME`
- `amendment_order_int`, `canonical_provider_id`
- `is_valid_rate`

**Audit state (Phase 7/8 certified)**:
- 88,596 duplicate rows removed (Phase 2)
- 4 OCR artifact rates > $1M deleted
- 8 current PMPM > $5,000 nulled
- 5,405 Stanford/Packard inpatient case rates reclassified `PER_DAY → PER_CASE` (Phase 5)
- 25 AWP discount rows reclassified to `AWP_DISCOUNT` (Phase 6)
- 42,527 temporal paradoxes resolved (Phase 9.2, 2026-07-12)
- **Post P2-J1 re-label (2026-07-20)**: status=`current` = **171,763** / status=`superseded` = **288,139** (stale split 135,485/324,417 is superseded)
- 121,403 honest NULL `superseded_by` rows (terminal versions — expected)
- `revenue_codes` blank on ~146,307 rows by design (not all contracts use UB-04 codes)

**Plausibility bounds** (Phase 6 final):
- PER_DAY: $0.10 – $500,000
- PER_VISIT: $0 – $100,000
- PMPM: $0.01 – $25,000
- PER_CASE: $0.50 – $1,000,000
- PER_PROCEDURE: $0.01 – $50,000

---

### 1.2 `tbl_contract_documents_master`
**Phase introduced**: Original (enriched Phase 1–8)
**Rows**: 10,349
**Purpose**: Master document inventory and contract metadata — one row per source PDF/version.

**Key columns**:
- `provider_id`, `provider_name`, `source_filename`, `contract_id`
- `document_type` — camelCase: `BaseAgmtRenew`, `FirstAmend`, `SecondAmend`, etc.
- `doc_role`, `doc_category`
- `amendment_order`, `amendment_depth`
- `effective_date_parsed`, `expiration_date_parsed`
- `contract_status` — `ACTIVE` / `EXPIRED` / `ACTIVE_NO_EXPIRY` / `FUTURE` / `UNKNOWN`
- `agreement_title`, `agreement_type`, `payment_type`, `line_of_business`
- `delegated_activities`

**Note**: No `amendment_order_int` column — use `CAST(amendment_order AS INT)` inline.

**Audit state (Phase 8 certified)**:
- `contract_status` distribution: EXPIRED 9,349 / ACTIVE 554 / ACTIVE_NO_EXPIRY 444 / FUTURE 2 / UNKNOWN 0
- UNKNOWN reduced from 232 → 0 via Phase 8 multi-strategy remediation
- 1,756 status corrections applied (Phase 2)
- Valid base document variants: `BaseAgmt`, `BaseAgmtNew`, `BaseAgmtRenew`
- ~26% NULL `expiration_date_parsed` (DEBT P3-D1 — requires OCR/LLM pipeline rerun for 38 docs)

---

### 1.3 `tbl_contract_hierarchy`
**Phase introduced**: Phase 3
**Rows**: 10,349
**Purpose**: Full document chain structure — amendment ordering and sequential position per provider.

**Key columns** (live schema — `dev_adb.raw.tbl_contract_hierarchy`):
- `contract_id` — STRING, surrogate PK. NOT `hierarchy_id` — that column does not exist.
- `provider_id` — STRING, FK to `dim_provider_canonical`
- `source_filename` — STRING, FK to `tbl_contract_documents_master`
- `document_type` — STRING, matches `tbl_contract_documents_master`
- `sequential_order` — INT, amendment chain position (Phase 7 redesign; NULL = unorderable doc types)
- `parent_contract_id` — STRING, FK to parent document in chain (NULL for base docs). NOT `parent_filename`.
- `contract_level` — STRING, chain depth level
- `line_of_business` — STRING, LOB from contract
- `contract_status` — STRING, ACTIVE / EXPIRED / ACTIVE_NO_EXPIRY / UNKNOWN / FUTURE
- `effective_date` — DATE. NOT `effective_date_parsed`.
- `expiration_date` — DATE. NOT `expiration_date_parsed`.

**CRITICAL**: Columns `amendment_order`, `parent_filename`, `doc_role`, `provider_name`, `hierarchy_id`, `effective_date_parsed`, `expiration_date_parsed` do NOT exist in this table (confirmed by live query 2026-07-13 and 2026-07-20). Any SQL referencing them will fail with UNRESOLVED_COLUMN. Use `sequential_order` for chain position; `parent_contract_id` for the parent FK.

**Audit state (Phase 7 certified)**:
- 550 Phase 6 `_vN`-derived values reverted (Phase 6 used document revision suffix, not amendment order)
- 91 rows assigned correct ordinals via 23-pattern validated amendment-order parser
- Coverage: 95.56% non-null `sequential_order` (459 correctly NULL = unorderable types: AmendLRA, SettlementAgmt, bare Amend)
- `broken_chain_providers` = 2.73% (Phase 7 redesign — semantic conflicts only, not corpus gaps)
- Row count parity with `tbl_contract_documents_master`: both 10,349

---

### 1.4 `tbl_vs_unified_ready`
**Phase introduced**: Original (enriched Phase 1–2)
**Rows**: 727,875
**Purpose**: Vector-search corpus — chunked OCR text for all documents. Powers all natural-language retrieval and clause verification.

**Key columns**:
- `provider_id`, `source_filename`, `chunk_text`
- `section_header`, `chunk_index`, `page_number_est`
- `amendment_order`
- `is_current` — TRUE only for latest amendment's chunks per provider
- `embedding` (vector)

**Audit state (Phase 2 certified)**:
- 384,814 stale `is_current` flags corrected via MERGE (Phase 2)
- 109 rows with NULL `amendment_order` (known, specific doc types)
- Hallucination rate: 2.87% (Phase 5 final measurement)

---

### 1.5 `tbl_dofr_matrix_extracted`
**Phase introduced**: Original (enriched Phase 2–3)
**Rows**: 1,821
**Purpose**: Structured delegation-of-financial-responsibility rows — responsible party per service category.

**Key columns**:
- `provider_id`, `provider_name`, `source_filename`, `effective_date`
- `row_seq` — dedup ordering proxy (use `WHERE row_seq IS NOT NULL` for sentinel checks)
- `service_category`, `subcategory`
- `group_responsible`, `hospital_responsible`, `health_plan_responsible`

**Note**: No `confidence_score` column. No `dofr_category` column — uses `service_category` + `subcategory`. Only 60 of 1,821 rows have `is_current=TRUE` — always query the full table, do not filter on `is_current`.

**Audit state**:
- 365 duplicate PK groups removed (Phase 2)
- 127 backfill rows inserted for 5 providers (Phase 2)
- 658 BH/Pharmacy/Emergency/Radiology/Lab category rows inserted (Phase 3 B-6 backfill)
- 0 HAS-profile/no-matrix conflicts

---

### 1.6 `tbl_delegation_matrix`
**Phase introduced**: Phase 3
**Rows**: 770
**Purpose**: IPA delegation scope — which administrative/clinical functions each IPA-delegated provider has delegated.

**Key columns**:
- `delegation_id` (STRING — PK), `provider_id`, `provider_name`, `source_filename`
- `delegated_function` — values: `claims_processing`, `credentialing`, `utilization_management`, `quality`, `prior_authorization`, `appeals`, `member_services`
- `delegation_level` — STRING (full / partial / administrative)
- `subdelegation_allowed` — BOOLEAN
- `supporting_text` — contract excerpt supporting this delegation entry
- `amendment_order` (INT), `is_current` (BOOLEAN — TRUE for active-amendment rows)

**CRITICAL**: `delegation_scope` and `effective_date` do NOT exist in this table — do not use them in queries.

**Audit state**:
- 866 stale rows removed (Phase 2 — orphaned after F1-IPA flag rebuild)
- 37 backfill rows inserted for 9 IPA providers
- **120 IPA providers** (confirmed live 2026-07-20; Phase 8 false-positive correction from 256), average **6.4 functions** per provider
- 0 single-function providers (all have 5–7 functions)

---

### 1.7 `tbl_contract_clauses`
**Phase introduced**: Phase 2/4
**Rows**: 7,863
**Purpose**: 21-category structured clause extraction — one row per clause instance per document.

**Key columns**:
- `clause_id` (STRING — PK), `provider_id`, `provider_name`, `source_filename`
- `clause_category` — 21 categories (OFFSET_CLAUSE, TERMINATION_PROVISIONS, AUTO_RENEWAL, DISPUTE_RESOLUTION, UM_PRIOR_AUTH, GRIEVANCE_APPEALS, RECORDS_RETENTION, CONFIDENTIALITY_HIPAA, EMERGENCY_CARE, COB, ASSIGNMENT_PROHIBITION, INSURANCE_REQUIREMENTS, QUALITY_REPORTING, AUDIT_RIGHTS, LANGUAGE_ACCESS, INDEMNIFICATION_LIABILITY, CONTINUITY_OF_CARE, CLAIM_SUBMISSION, CREDENTIALING_REQUIREMENTS, TELEHEALTH, NETWORK_ADEQUACY)
- `clause_status` — `HAS` (7,849 rows) / `FALSE_POSITIVE` (14 rows). **ABSENT does NOT exist in live data — never use it in WHERE clauses.**
- `clause_text` — full extracted clause text
- `is_current` (BOOLEAN — TRUE for current-amendment clauses; 670 current rows)
- `amendment_order` (INT), `extraction_method` (STRING)

**Audit state (Phase 8 certified)**:
- 300 distinct providers covered (7,863 rows / 21 categories)
- 0 null `provider_id`, 0 null `source_filename`, 0 blank `clause_category`
- Offset false-positive saturation corrected (97.1% → ~46% post Phase 3 hardening)
- Verified against `tbl_vs_unified_ready` chunks: hallucination rate within 2.87% tolerance

---

### 1.8 `tbl_genie_amendment_timeline`
**Phase introduced**: Original
**Rows**: 6,609
**Purpose**: Document-level amendment history for timeline and change-tracking questions.

**Key columns**:
- `provider_id`, `provider_name`, `source_filename`
- `document_type`, `doc_category`
- `amendment_order`, `amendment_depth`
- `effective_date_parsed`, `expiration_date_parsed`
- `rate_count`, `summary_of_changes`

**Note**: 3,739-row gap vs `tbl_contract_documents_master` (10,348) — exhibits and cover memos excluded by design.

---

### 1.9 `tbl_genie_provider_profile`
**Phase introduced**: Original (enriched through Phase 8)
**Rows**: 306
**Purpose**: One-row provider summary — primary entry point for provider-level queries.

**Key columns**:
- `provider_id`, `provider_name`
- `payment_type`, `payment_type_normalized` — `payment_type_normalized` breakdown: Mixed=253, Capitation=30, Fee For Service=16, Per Diem=3, Other=1 (3 NULL)
- `total_documents`, `total_amendments`, `max_amendment_depth`
- `total_rates`, `current_rates` (drift = 0 post Phase 9 MERGE)
- `lob_normalized`, `lob_extraction_status`
- `is_active` — BOOLEAN (194 true, 112 false)
- `offset_clause_status` — `HAS` / `NO_MENTION` (no `offset_language` column)
- `dofr_status` — `HAS` / `NO_MENTION`
- `ipa_delegation_status` — `HAS` / `NO_MENTION`

**Note**: Uses `program_normalized`, NOT `lob_normalized`, on some query paths. `auto_renewal` stored as STRING `'True'`/`'False'`.

**Audit state (Phase 9 certified)**:
- DOFR false-positive saturation corrected (was 97–99% HAS → now 141 HAS / 165 NO_MENTION)
- IPA false-positive corrected (was overfiring on capitation language → now 120 HAS / 186 NO_MENTION)
- `is_active` refreshed Phase 9: 89 providers corrected (was 105/201, now 194/112 from live doc statuses)
- `current_rates` refreshed Phase 9: 211 providers corrected (drift 0 post MERGE)
- `total_documents`, `total_amendments`, `max_amendment_depth` refreshed Phase 9: 301 providers corrected
- `offset_clause_status`: 47 HAS / 259 NO_MENTION

---

### 1.10 `tbl_compliance_tracking`
**Phase introduced**: Phase 4
**Rows**: 2,871
**Purpose**: Regulatory compliance status per provider × regulation.

**Key columns**:
- `compliance_id` (STRING), `provider_id`, `provider_name`
- `regulation` — KNOX_KEENE (508), CMS_MA (517), DMHC_STANDARDS (498), AB_1455 (386), SB_137 (352), AB_352 (305), AB_72 (305). **HIPAA, STATE_LICENSING, AB_1107 do NOT exist.**
- `compliance_status` — COMPLIANT (663) / PARTIAL (1,231) / UNKNOWN (974) / EXEMPT (3). **NON_COMPLIANT does NOT exist in live data.**
- `evidence_text`, `source_filename`, `amendment_order` (INT), `created_at`

---

### 1.11 `tbl_quality_performance`
**Phase introduced**: Phase 4
**Rows**: 894
**Purpose**: Quality and performance program tracking per provider.

**Key columns**:
- `quality_id` (STRING), `provider_id`, `provider_name`
- `program_name` — HEDIS (470), WITHHOLD (173), VALUE_BASED (164), P4P (71), STAR_RATING (16). Use `program_name` not `program_type`.
- `bonus_pct`, `penalty_pct` — NULL for prose-defined contracts (confirmed Phase 4 B-7 PROSE_DEFINED)
- `metric_name`, `target_value` (FLOAT), `payment_mechanism`, `formula_text`
- `source_filename`, `amendment_order` (INT), `created_at`

**CRITICAL**: `target_metric`, `measurement_period`, `effective_date` do NOT exist in this table.

---

### 1.12 `tbl_contract_notifications`
**Phase introduced**: Phase 4
**Rows**: 1,934
**Purpose**: Notice, renewal, and termination deadline tracking — 7 notification types per provider.

**Key columns**:
- `notification_id` (STRING), `provider_id`, `provider_name`, `source_filename`
- `notification_type` — TERMINATION (508) / RATE_CHANGE (451) / AUDIT (385) / COMPLIANCE (265) / RENEWAL (198) / CREDENTIALING (114) / CLAIMS_SUBMISSION_DEADLINE (13). **TERMINATION_FOR_CONVENIENCE, CONTRACT_RENEWAL, MATERIAL_CHANGE do NOT exist.**
- `notice_days` — integer day count (NULL on ~277 rows — genuine non-numeric or extraction miss)
- `trigger_event`, `effective_date`

**Note**: `notice_days` regex requires Java regex in Spark SQL — use `(\\d+)` in f-strings to produce `(\d+)` in SQL.

**Audit state**: 13 AB1455 TERMINATION misclassifications corrected to CLAIMS_SUBMISSION_DEADLINE (Phase 0 F2).

---

### 1.13 `tbl_rate_escalators`
**Phase introduced**: Phase 3
**Rows**: 104
**Purpose**: Rate escalation terms — annual increase clauses per provider.

**Key columns**:
- `escalator_id` (STRING), `provider_id`, `provider_name`, `source_filename`
- `escalator_type` — **CUSTOM (59 rows) / FIXED_PCT (27 rows) / CPI (18 rows)**. Three types, not two. `FIXED_PCT` is a real value — not a typo. (Confirmed live 2026-07-20.)
- `base_index` — CPI-U / CPI-W / Medicare IPPS / etc.
- `adjustment_pct` (FLOAT — annual percentage increase)
- `floor_pct` (FLOAT — minimum annual increase), `cap_pct` (FLOAT — maximum; NULL if uncapped)
- `frequency` — ANNUAL (28) / OTHER (76)
- `formula_text` — verbatim escalation language (up to 2,000 chars)
- `amendment_order` (INT), `created_at`

**CRITICAL**: `escalator_pct` and `effective_date` do NOT exist in this table — use `adjustment_pct` and `created_at`.

---

### 1.14 `tbl_service_areas`
**Phase introduced**: Phase 3
**Rows**: 306
**Purpose**: Geographic service area coverage per provider.

**Key columns**:
- `service_area_id` (= provider_id), `provider_id`, `provider_name`
- `region` — Northern CA / Bay Area / Central Valley / Southern CA / Inland Empire / Central Coast / Statewide (186 providers) / Unknown. Use `region`, NOT `service_area_name`.
- `county` (STRING — NULL for most Statewide providers)
- `assignment_method` — NAME_KEYWORD / HEALTH_SYSTEM / PROVIDER_TYPE / DEFAULT
- `created_at`

**CRITICAL**: `coverage_type` and `counties` do NOT exist — use `region` and `county` (singular STRING, not ARRAY).

---

## SECTION 2 — Phase 5–7 Core Tables (7)

---

### 2.1 `tbl_provider_identifiers`
**Phase introduced**: Phase 5
**Rows**: 50,159
**Purpose**: NPI/TIN/claims/PIMS identifier registry — expanded claims-level coverage across source systems. NOT a small static dimension (expanded in Phase 1 revalidation from expected ~595 to 50,159).

**Key columns**:
- `provider_id`, `identifier_type` — NPI / TIN / PIMS / CLAIMS
- `identifier_value` (NPI = 10 digits, TIN = 9 digits)
- `end_date` (DATE — NULL means currently active), `source`, `effective_date`

**Note**: A provider may have multiple NPIs from different sources — prefer `source='FACETS_NAME'` or `'JSON_EXTRACT'`. Filter `WHERE identifier_type = 'NPI' AND end_date IS NULL` for active NPIs. **`id_type` and `id_value` do NOT exist — use `identifier_type` and `identifier_value`.**

---

### 2.2 `tbl_financial_exposure`
**Phase introduced**: Phase 5
**Rows**: 172
**Purpose**: Contracted spend estimates and variance tracking per provider.

**Key columns**:
- `provider_id`, `period_start`, `period_end`, `line_of_business`
- `assigned_members`, `inpatient_admits`, `outpatient_visits`
- `contracted_spend` (DECIMAL) — range $1M–$282M
- `actual_spend` (DECIMAL), `variance_pct` (FLOAT)
- `source` — ESTIMATE / CLAIMS only. **BUDGET does NOT exist in live data.**
- `estimate_confidence` — PROXY_PMPM_x12 / PROXY_AVG_RATE / UNKNOWN

**Note**: No `provider_name` column — JOIN to `tbl_genie_provider_profile` ON `provider_id` to get provider name.

---

### 2.3 `tbl_extraction_provenance`
**Phase introduced**: Phase 5
**Rows**: 15,368
**Purpose**: Full audit trail for every extracted field — method, confidence, source document.

**Key columns**:
- `extraction_id`, `target_table`, `target_record_id`, `target_column`
- `provider_id` (STRING — available for direct joins)
- `extracted_value`, `confidence_score` (FLOAT — NULL for DOFR rows)
- `extraction_method` — **PATTERN_MATCH only** (LLM_V6 / REGEX / MANUAL / RULE_BASED do NOT exist in live data)
- `model_version`, `source_page_numbers`
- `human_verified` (BOOLEAN — **ALL false**, no manual review done), `human_corrected_value`

Coverage by target_table: clauses(7,777), notifications(1,934), compliance(1,897), delegation(1,599), dofr(1,163), quality(894), escalators(104).

---

### 2.4 `tbl_contract_risk_scores`
**Phase introduced**: Phase 6
**Rows**: 272
**Purpose**: Composite risk score per active provider — drives alert generation.

**Key columns**:
- `provider_id`, `provider_name`, `lob`, `payment_type`
- `risk_score` — range 18–48 (composite score)
- `risk_tier` — LOW (239) / MEDIUM (26) / MONITOR (7)
- `expiration_risk`, `days_to_expiry`, `compliance_gap`, `total_regs`, `gap_regs`
- `clause_gap`, `total_clauses`, `absent_clauses`
- `amendment_velocity`, `amendment_count`, `fin_risk`, `contracted_spend`
- `scored_at`

**Audit state**: 272 rows — one per scored provider (generated before Phase 9 is_active correction; includes 78 now-inactive providers). Risk score correlates with `offset_clause_status`, `dofr_status` flag states.

---

### 2.5 `tbl_clause_deviations`
**Phase introduced**: Phase 6
**Rows**: 7,777
**Purpose**: Clause deviation layer — baseline vs actual for each extracted clause.

**Key columns**:
- `deviation_id`, `provider_id`, `provider_name`
- `clause_category` — 21 categories (same as tbl_contract_clauses)
- `clause_status` — provider's actual status (HAS / ABSENT / MODIFIED)
- `network_baseline` — network norm (HAS / ABSENT / MODIFIED)
- `network_has_pct`, `network_absent_pct` (DOUBLE) — % of network with/without this clause
- `deviation_type` — CONFORMANT / DEVIATION
- `severity` — NONE / LOW / MEDIUM / HIGH
- `analyzed_at`

**CRITICAL**: No `baseline_text` or `actual_text` columns. This is a STATUS COMPARISON table, not a text-diff table.

---

### 2.6 `tbl_contract_deadlines`
**Phase introduced**: Phase 6
**Rows**: 713
**Purpose**: Unified deadline calendar — all actionable contract dates in one place.

**Key columns**:
- `deadline_id` (STRING — **NOT unique**: 414 distinct values / 713 rows — use DISTINCT when JOINing), `provider_id`, `provider_name`
- `deadline_type` — CONTRACT_EXPIRY (494) / TERMINATION (149) / RENEWAL (70)
- `contract_status` — **ACTIVE (711) / FUTURE (2) only** — EXPIRED, ACTIVE_NO_EXPIRY, UNKNOWN are not present in this table
- `event_date`, `action_required_by` (DATE)
- `days_until_action` (INT — negative = overdue). **Use `days_until_action`, NOT `days_until_deadline`.**
- `priority_tier` — CRITICAL (127) / HIGH (122) / MEDIUM (89) / LOW (273) / EXPIRED (102)
- `notice_days`, `source_filename`, `created_at`

**CRITICAL**: No `source_notification_id` FK. Link to notifications via `provider_id` only.
FK from `tbl_alert_queue.source_deadline_id` → `deadline_id` (alerts generated from deadlines).

---

### 2.7 `tbl_alert_queue`
**Phase introduced**: Phase 7
**Rows**: 351 (229 CRITICAL)
**Purpose**: Operational alert queue — active contract events requiring attention.

**Key columns**:
- `alert_id`, `provider_id`, `provider_name`
- `deadline_type`, `action_required_by`, `days_until_due`
- `alert_priority` — CRITICAL (229) / HIGH (34) / MEDIUM (88) — NO LOW tier
- `alert_status` — NEW (all 351 currently)
- `context_text`, `source_deadline_id`, `created_at`

**Audit state**: Freshness check — `created_at` must be within 7 days for alerts to be operationally valid.

---

## SECTION 3 — Dimension / Reference Tables (7)

---

### 3.1 `dim_provider_canonical`
**Phase introduced**: Original
**Rows**: 531 (304 primary canonical providers)
**Purpose**: Canonical provider identity layer — the JOIN key for all `provider_id` relationships across the model.

**Key columns**:
- `provider_id` (primary key across all tables)
- `canonical_name`, `primary_provider_id`
- `is_primary_id` — TRUE = representative ID per facility
- `is_primary` — TRUE = canonical/primary provider_id entry
- `doc_count`, `total_rate_count`, `ids_in_facility`
- `all_names_used` (array), `resolution_version`

---

### 3.2 `dim_health_system`
**Phase introduced**: Phase 1
**Rows**: 20
**Purpose**: Health system dimension — groups providers into systems (Kaiser, Dignity, Sutter, etc.).

**Key columns**:
- `system_id` (join key — NOT `health_system_id`)
- `system_name`, `system_type` — NON_PROFIT / FOR_PROFIT / ACADEMIC / GOVERNMENT / INDEPENDENT
- `facility_count` (INT), `name_patterns` (STRING — pipe-delimited ILIKE patterns)

---

### 3.3 `tbl_provider_system_membership`
**Phase introduced**: Phase 1
**Rows**: 112 (106 providers, 19 systems — all OWNED)
**Purpose**: Provider ↔ health system assignment bridge. ~35% of 304 canonical providers mapped.

**Key columns**:
- `provider_id`, `system_id`
- `membership_type` (STRING — all OWNED in live data)
- `match_pattern`, `effective_date` (DATE — NULL = unknown), `source` — PATTERN_MATCH / MANUAL / CLAIMS

**Note**: 63% of providers are NOT in any system — always use LEFT JOIN.

---

### 3.4 `dim_table_schema`
**Phase introduced**: Original (as `tbl_genie_schema_catalog`)
**Rows**: 468 (31 tables × avg 16 columns)
**Purpose**: Column-level schema registry — RUNTIME CRITICAL. Powers schema-aware SQL generation in the agent. Do NOT drop or truncate.

**Key columns**:
- `table_name`, `full_table_name`, `column_name`, `data_type`
- `comment`, `is_filterable`, `is_joinable`
- `sample_values`, `updated_at`

**Note**: Referenced by `schema_context_builder.py`. Rebuilt in Phase 9 remediation to cover all 31 production tables (was 9). Must be refreshed after any major schema change.

---

### 3.5 `tbl_repricing_scenarios`
**Phase introduced**: Phase 6
**Rows**: 7,600
**Purpose**: Repricing simulation outputs — what-if rate scenarios for negotiation support.

**Key columns**:
- `scenario_id`, `provider_id`, `provider_name`
- `rate_category`, `scenario_label` — SCENARIO_MINUS_5PCT / SCENARIO_PLUS_3PCT / SCENARIO_PLUS_5PCT / SCENARIO_PLUS_10PCT
- `avg_rate` (current avg), `simulated_rate` (what-if), `rate_delta`, `rate_delta_pct`
- `rate_row_count` — how many rate rows affected
- `estimated_annual_impact` (DOUBLE) — use `ABS(estimated_annual_impact)` for sorting by magnitude
- `simulated_at`

---

### 3.6 `tbl_reimb_stop_loss`
**Phase introduced**: Original (re-activated — present in SQL whitelist and settings.py)
**Rows**: 3,847
**Purpose**: Stop-loss provisions — dollar threshold above which the health plan bears residual cost.

**Key columns**:
- `stop_loss_id` (STRING — unique PK), `provider_id`, `source_filename`
- `stop_loss_type` — CASE_RATE (3,477 rows) / PER_DIEM (370 rows). **AGGREGATE and CORRIDOR do NOT exist in live data.**
- `attachment_level` (FLOAT — dollar threshold; 248 rows NULL; column-masked for non-owner SPs)
- `attachment_unit` — TOTAL_CHARGES / TOTAL_DAYS / TOTAL_COST
- `reimburse_formula_type` — FIXED_PER_DIEM / PERCENTAGE / CHARGES_LESS_THRESHOLD
- `reimburse_rate` (FLOAT — 2,893 rows NULL; masked), `reimburse_percentage` (FLOAT — masked)
- `aggregate_cap` (FLOAT — mostly NULL; masked), `effective_date` (DATE)

**CRITICAL**: No `provider_name` column — JOIN to `tbl_genie_provider_profile` ON `provider_id` to filter by name. Forbidden column aliases: `stop_loss_threshold` (→ use `attachment_level`), `calculation_method` (→ use `reimburse_formula_type`).

---

### 3.7 `tbl_reimb_carve_outs`
**Phase introduced**: Original (re-activated — present in SQL whitelist and settings.py)
**Rows**: 17,229
**Purpose**: Carve-out provisions — items billed separately from the base rate (implants, drugs, devices, supplies, procedures).

**Key columns**:
- `provider_id`, `source_filename`, `effective_date`
- `carve_out_type` — IMPLANT (10,181) / SUPPLY (3,658) / DRUG (1,713) / PROCEDURE (958) / DEVICE (719)
- `description`, `threshold_amount`, `threshold_type` — PER_ITEM / PER_CASE / PER_DAY
- `reimburse_formula_type` — COST_PLUS / PERCENTAGE / FIXED / INVOICE
- `reimburse_percentage`, `reimburse_of` — INVOICE_COST / AWP / WAC / CHARGES
- `relationship` — ADDITIONAL_TO / INSTEAD_OF / ABOVE_THRESHOLD
- `revenue_codes`, `procedure_codes`, `ndc_codes`

**CRITICAL**: No `provider_name` column — JOIN to `tbl_genie_provider_profile` ON `provider_id` to filter by name.

---

## SECTION 4 — App Persistence Tables (populated) (3)

These are written by the application at runtime. Listed here because they have real traffic data.

---

### 4.1 `tbl_agent_sessions`
**Rows**: 2,229
**Purpose**: Runtime session history — every query turn auto-saved via `_persist_turn()`.

**Key columns**: `session_id`, `user_id`, `query`, `response`, `created_at`, `turn_count`

---

### 4.2 `fact_retrieval_telemetry`
**Rows**: 1,300
**Purpose**: Vector search retrieval telemetry — chunk scores, latency, source docs per query.

**Key columns**: `session_id`, `query`, `retrieved_chunks`, `scores`, `latency_ms`, `created_at`

---

### 4.3 `fact_supersession`
**Rows**: 2,380
**Purpose**: Tracks rate supersession events — when a rate row transitions from CURRENT to SUPERSEDED.

**Key columns**: `supersession_id`, `superseding_filename`, `superseded_filename`, `provider_id`, `contract_chain_id`, `superseding_effective_date`, `superseded_effective_date`, `rate_domain`, `old_rate_numeric`, `new_rate_numeric`, `rate_change_pct`, `confidence`, `created_at`

**CRITICAL**: `provider_id` is **ALL NULL** in this table. To filter by provider, JOIN via filename: `JOIN tbl_contract_documents_master d ON fact_supersession.superseding_filename = d.source_filename WHERE d.provider_id = :provider_id`.

---

## SECTION 5 — Key Relationships

```
dim_provider_canonical.provider_id
  ← tbl_genie_provider_profile.provider_id          (306 rows)
  ← tbl_contract_rates_all.provider_id              (459,902 rows)
  ← tbl_contract_documents_master.provider_id       (10,349 rows)
  ← tbl_contract_hierarchy.provider_id              (10,349 rows)
  ← tbl_vs_unified_ready.provider_id                (727,875 rows)
  ← tbl_dofr_matrix_extracted.provider_id           (1,821 rows)
  ← tbl_delegation_matrix.provider_id               (770 rows)
  ← tbl_contract_clauses.provider_id                (7,863 rows)
  ← tbl_genie_amendment_timeline.provider_id        (6,609 rows)
  ← tbl_compliance_tracking.provider_id             (2,871 rows)
  ← tbl_quality_performance.provider_id             (894 rows)
  ← tbl_contract_notifications.provider_id          (1,934 rows)
  ← tbl_rate_escalators.provider_id                 (104 rows)
  ← tbl_service_areas.provider_id                   (306 rows)
  ← tbl_provider_identifiers.provider_id            (50,159 rows)
  ← tbl_financial_exposure.provider_id              (172 rows)
  ← tbl_contract_risk_scores.provider_id            (272 rows)
  ← tbl_clause_deviations.provider_id               (7,777 rows)
  ← tbl_contract_deadlines.provider_id              (713 rows)
  ← tbl_alert_queue.provider_id                     (351 rows)
  ← tbl_provider_system_membership.provider_id      (112 rows)
  ← tbl_reimb_stop_loss.provider_id                 (3,847 rows)
  ← tbl_reimb_carve_outs.provider_id                (17,229 rows)

dim_health_system.system_id
  ← tbl_provider_system_membership.system_id

tbl_contract_documents_master.source_filename
  ← tbl_contract_rates_all.source_filename
  ← tbl_vs_unified_ready.source_filename
  ← tbl_contract_clauses.source_filename
  ← tbl_genie_amendment_timeline.source_filename
  ← tbl_extraction_provenance.source_filename
  ← tbl_contract_hierarchy.source_filename
  ← fact_supersession.superseding_filename  (provider_id is NULL — must join via filename)

tbl_contract_deadlines.deadline_id
  ← tbl_alert_queue.source_deadline_id

tbl_contract_risk_scores.provider_id
  ← tbl_alert_queue.provider_id  (high-risk providers drive CRITICAL alerts)
```

---

## SECTION 6 — Critical FK Non-Zero Orphans (by design)

These FK relationships have known non-zero orphan counts that are **intentional** (rates/docs for providers in upstream source but absent from 304-provider canonical set):

| Relationship | Orphan Count | Classification |
|---|---|---|
| `tbl_contract_rates_all.provider_id` → `tbl_genie_provider_profile` | 128,963 | RETAINED — universe analysis |
| `tbl_contract_documents_master.provider_id` → `tbl_genie_provider_profile` | 3,086 | RETAINED |
| `tbl_contract_hierarchy.provider_id` → `tbl_genie_provider_profile` | 3,086 | RETAINED |
| `tbl_contract_clauses.provider_id` → `tbl_genie_provider_profile` | 3,038 | RETAINED |
| `tbl_contract_notifications.provider_id` → `tbl_genie_provider_profile` | 764 | RETAINED |
| `tbl_quality_performance.provider_id` → `tbl_genie_provider_profile` | 353 | RETAINED |

All **critical FKs** (hierarchy→docs, dofr→profile, delegation→profile) = **0 orphans**.

---

## SECTION 7 — Monitoring Views (not tables)

Deployed in `dev_adb.raw` as part of production hardening:

| View | Phase | Purpose |
|---|---|---|
| `vw_phase5_regression_sentinels` | 5 | 8 core DQ sentinels (live re-runnable) |
| `vw_phase5_table_drift_detection` | 5 | Row-count drift across 17 core tables |
| `vw_phase5_expiration_alerts` | 5 | Contracts expiring in 30/60/90-day windows |
| `vw_phase5_external_data_triggers` | 5 | External data freshness monitoring |
| `vw_phase6_regression_sentinels` | 6 | S-1 through S-10 extended sentinels |
| `vw_phase6_table_drift_detection` | 6 | Extended drift detection |
| `vw_fk_map` | 7+ | Foreign key map |
| `vw_referential_integrity_check` | 7+ | Live RI check |
| `vw_canonical_join_guide` | 7+ | Join path guide for agent SQL generation |

---

## SECTION 8 — Excluded Tables and Reasons

| Table | Reason |
|---|---|
| `tbl_rate_benchmarks` | 10,434 rows but SYNTHETIC only — no real CMS/Medi-Cal data (DEBT P3-D5). Present in SQL whitelist and queryable, but results are synthetic. Constraint 13 note: whitelist uses `benchmark_type` but audited schema uses `benchmark_source` — naming inconsistency pending resolution. |
| `tbl_vs_name_mapping` | Legacy helper — superseded by `dim_provider_canonical` |
| `tbl_genie_contract_meta` | Legacy original — superseded by `tbl_contract_documents_master` |
| `tbl_genie_contract_clauses_raw` | Legacy original — superseded by `tbl_contract_clauses` |
| `tbl_genie_rates_current` | WONTFIX — V4 intentional design decision, not in production |
| `tbl_user_feedback` | 0 rows — wired but no production traffic yet |
| `app_query_telemetry` | 0 rows — wired but no production traffic yet |
| `tbl_query_cache` | 0 rows — not yet wired |
| `fact_extraction_run` | 0 rows — awaiting pipeline traffic |
| `fact_file_extraction` | 0 rows — awaiting pipeline traffic |
| `tbl_json_staging` | Staging artifact (10,350 rows) — intermediary per-document JSON store, not a business table |
| `tbl_contract_rates_all_dedup_stage` | Temp dedup artifact — retained for reference only |
| `tbl_negotiation_workbench` | 272 rows — secondary layer dependent on risk scores; not yet production-integrated |

---

## SECTION 9 — Technical Constraints Reference

Carry-forward constraints that apply to ALL query and write operations against these tables:

1. **USER_ISOLATION cluster**: `spark.read.json('/Workspace/...')` fails — use Python `open()` + `spark.createDataFrame(list_of_dicts)`
2. **No sparkContext**: `sparkContext.parallelize()` blocked — use `spark.createDataFrame()` from Python lists/dicts
3. **Spark SQL regex backslash eating**: NEVER use `\d`, `\s`, `\b` in SQL string literals — use `[0-9]`, literal spaces, `[a-zA-Z]`
4. **REGEXP_EXTRACT no-match**: returns `''` — always wrap with `NULLIF(..., '')` before casting
5. **Python Row.count collision**: `COUNT(*) AS count` clashes with `.count` — always alias as `row_count`, `doc_count`, etc.
6. **Broad overwrites blocked**: use staging table → `createOrReplaceTempView` → `DELETE WHERE EXISTS` → `INSERT WHERE NOT EXISTS`
7. **Delta MERGE ON restriction**: no subqueries in `ON` clause — push all logic into `USING` subquery with `DISTINCT`
8. **`tbl_contract_documents_master`**: no `amendment_order_int` column — use `CAST(amendment_order AS INT)` inline
9. **`tbl_contract_hierarchy`**: Does NOT have `amendment_order` — confirmed by live query 2026-07-13 (amendment_order_present=False; sequential_order_present=True). Use `sequential_order` (INT) for chain position. PK is `contract_id` (NOT `hierarchy_id`). Parent doc FK is `parent_contract_id` (NOT `parent_filename`). Columns `provider_name`, `doc_role`, `effective_date_parsed`, `expiration_date_parsed` also do not exist.
10. **`_vN` suffix semantics**: means document REVISION version, not amendment chain position (Phase 7 finding)
11. **`superseded_by` format**: `eff:DATE|src:FILENAME` — not a bare filename
12. **DOFR sentinel key**: `(provider_id, service_category, subcategory, row_seq)` with `WHERE row_seq IS NOT NULL`
13. **`tbl_rate_benchmarks` schema**: whitelist uses `benchmark_type`; audited column name is `benchmark_source`. Use `benchmark_source` in non-LLM SQL. `benchmark_year` (not `data_year`), `geographic_region` (not `region`).
14. **`tbl_service_areas`**: use `region` column (not `service_area_name`); `county` is a single STRING (not an array)
15. **`tbl_quality_performance`**: use `program_name` column (not `program_type`)
16. **`tbl_genie_provider_profile`**: `offset_clause_status` only (no `offset_language` column); `is_active` is BOOLEAN; `auto_renewal` is STRING `'True'`/`'False'`
17. **`status` values in `tbl_contract_rates_all`**: lowercase `'current'` / `'superseded'`
18. **Valid base document variants**: `BaseAgmt`, `BaseAgmtNew`, `BaseAgmtRenew`
19. **`fact_supersession` circular check**: use `LIKE CONCAT('%src:', source_filename, '%')`; `provider_id` is ALL NULL — join via filename
20. **`rate_unit` taxonomy** (Phase 6 final): `PER_DAY`, `PER_VISIT`, `PMPM`, `PER_CASE`, `PER_PROCEDURE`, `AWP_DISCOUNT`, `UNCLASSIFIED` — `PERCENT_OF_CHARGES`, `FLAT`, `CASE_RATE` do NOT exist
21. **`tbl_provider_identifiers` duplicate whitelist entry**: table appears twice in `CONTRACT_TABLES_FOR_SQL`; Python dict uses last entry which has `id_type`/`id_value` — but verified schema uses `identifier_type`/`identifier_value`. Always use `identifier_type` and `identifier_value` in SQL.
22. **`tbl_rate_escalators` duplicate whitelist entry**: winning (last) entry uses `adjustment_pct` (not `escalator_pct`), `floor_pct`, `formula_text`, `escalator_type` = CUSTOM(59)|FIXED_PCT(27)|CPI(18) — 3 types, not 2. `FIXED_PCT` is a real value, not a typo. No `effective_date` column.
23. **`tbl_service_areas` duplicate whitelist entry**: winning entry uses `county` (STRING), `service_area_id`, `assignment_method`. No `county_list` array, no `service_area_note`.

---

## SECTION 10 — Open DEBT Items (require external inputs — not resolvable by SQL)

| ID | Description | Quantity | Blocker |
|---|---|---|---|
| P3-D1 | Null expiration dates | ~38 docs (35 SOURCE_NEVER_SCANNED + 3 DMS-RESCRAPE) | OCR/LLM pipeline rerun with date-focused prompting |
| P3-D3 | Missing base contract PDFs | 38 providers | Procurement of missing source PDFs |
| P3-D5 | External benchmark data in `tbl_rate_benchmarks` | 0 real rows (10,434 synthetic only) | CMS IPPS/OPPS fee schedules, DHCS Medi-Cal FFS, commercial survey data |

---

*Document generated 2026-07-13 — last updated 2026-07-20. Reflects Phase 0–10B complete audit state.*
