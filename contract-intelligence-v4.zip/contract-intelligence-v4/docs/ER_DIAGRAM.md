# Contract Intelligence V4 — Entity-Relationship Diagram

**Version**: v4 (Post Phase 10B Complete)
**Date**: 2026-07-20
**Catalog / Schema**: `dev_adb.raw`
**Production tables**: 31 (excl. views)

> All 31 production tables join to `dim_provider_canonical.provider_id` as the canonical identity key. The Mermaid diagram shows cross-group and non-`provider_id` FKs for readability. See DATA_MODEL_PRODUCTION_STATE.md §5 for the full FK inventory.

## Core Relationships (Mermaid syntax)

```mermaid
erDiagram
    dim_provider_canonical ||--o{ tbl_genie_provider_profile : "provider_id"
    dim_provider_canonical ||--o{ tbl_contract_rates_all : "canonical_provider_id"

    dim_health_system ||--o{ tbl_provider_system_membership : "system_id"

    tbl_genie_provider_profile ||--o{ tbl_contract_rates_all : "canonical_provider_id"
    tbl_genie_provider_profile ||--o{ tbl_contract_clauses : "provider_id"
    tbl_genie_provider_profile ||--|| tbl_service_areas : "provider_id"
    tbl_genie_provider_profile ||--o{ tbl_dofr_matrix_extracted : "provider_id"
    tbl_genie_provider_profile ||--o{ tbl_delegation_matrix : "provider_id"
    tbl_genie_provider_profile ||--o{ tbl_rate_escalators : "provider_id"
    tbl_genie_provider_profile ||--o{ tbl_provider_system_membership : "provider_id"
    tbl_genie_provider_profile ||--o{ tbl_financial_exposure : "provider_id"
    tbl_genie_provider_profile ||--o{ tbl_repricing_scenarios : "provider_id"
    tbl_genie_provider_profile ||--o{ tbl_reimb_stop_loss : "provider_id"
    tbl_genie_provider_profile ||--o{ tbl_reimb_carve_outs : "provider_id"
    tbl_genie_provider_profile ||--o{ tbl_contract_risk_scores : "provider_id"
    tbl_genie_provider_profile ||--o{ tbl_contract_deadlines : "provider_id"
    tbl_genie_provider_profile ||--o{ tbl_alert_queue : "provider_id"

    tbl_contract_documents_master ||--o{ tbl_vs_unified_ready : "source_filename"
    tbl_contract_documents_master ||--o{ tbl_contract_hierarchy : "source_filename"
    tbl_contract_documents_master ||--o{ tbl_contract_rates_all : "source_filename"
    tbl_contract_documents_master ||--o{ tbl_contract_clauses : "source_filename"
    tbl_contract_documents_master ||--o{ tbl_genie_amendment_timeline : "source_filename"
    tbl_contract_documents_master ||--o{ tbl_extraction_provenance : "source_filename"
    tbl_contract_documents_master ||--o{ fact_supersession : "superseding_filename"

    tbl_contract_deadlines ||--o{ tbl_alert_queue : "deadline_id"
```

## Join Guide

| From | To | Join Column | Resolution |
|------|-----|-------------|------------|
| `tbl_contract_rates_all` | `tbl_genie_provider_profile` | `canonical_provider_id` = `provider_id` | **100%** |
| `tbl_contract_rates_all` | `dim_provider_canonical` | `provider_id` = `provider_id` | **~72%** — 216 orphan providers / 128,963 rows (ISSUE_10 confirmed) |
| `tbl_contract_clauses` | `tbl_genie_provider_profile` | `provider_id` = `provider_id` | **~61%** — 3,038 orphan rows (§6); 300 distinct providers |
| `tbl_service_areas` | `tbl_genie_provider_profile` | `provider_id` = `provider_id` | **100%** (1:1, 306 rows each) |
| `tbl_provider_system_membership` | `dim_health_system` | `system_id` = `system_id` | **100%** |
| `tbl_vs_unified_ready` | `tbl_contract_documents_master` | `source_filename` = `source_filename` | **100%** (filter `is_current=TRUE`) |
| `tbl_contract_hierarchy` | `tbl_contract_documents_master` | `source_filename` = `source_filename` | **100%** (0 orphans — §6) |
| `tbl_extraction_provenance` | `tbl_contract_documents_master` | `source_filename` = `source_filename` | **100%** |
| `tbl_extraction_provenance` | `tbl_genie_provider_profile` | `provider_id` = `provider_id` | **100%** — 0 nulls, 1,395 distinct (added Phase 10B-6) |
| `fact_supersession` | `tbl_contract_documents_master` | `superseding_filename` = `source_filename` | **100%** via filename; **CRITICAL: `provider_id` ALL NULL** on all 2,380 rows — never join on `provider_id` |
| `tbl_alert_queue` | `tbl_contract_deadlines` | `source_deadline_id` = `deadline_id` | **100%** (0 orphans — B9 confirmed) |

## CRITICAL: Never Use Direct provider_id for Rates

```sql
-- CORRECT (100% resolution):
SELECT * FROM tbl_contract_rates_all r
JOIN tbl_genie_provider_profile p ON r.canonical_provider_id = p.provider_id

-- WRONG (~72% resolution — 128,963 orphan rows / 216 orphan providers):
SELECT * FROM tbl_contract_rates_all r
JOIN tbl_genie_provider_profile p ON r.provider_id = p.provider_id
```

## Table Layers

```
┌──────────────────────────────────────────────────────────────────────┐
│  DIMENSION LAYER (reference)                                          │
│  dim_provider_canonical (531) │ dim_health_system (20)               │
│  dim_table_schema (468 entries — 31 tables × avg 16 cols)            │
└──────────────────────────────────────────────────────────────────────┘
          │                          │
┌─────────┴──────────────────────────┴─────────────────────────────────┐
│  RESOLUTION LAYER                                                      │
│  tbl_provider_system_membership (112)                                  │
└──────────────────────────────────────────────────────────────────────┘
          │
┌─────────┴────────────────────────────────────────────────────────────┐
│  PROFILE LAYER (central entity)                                        │
│  tbl_genie_provider_profile (306) │ tbl_service_areas (306)           │
└──────────────────────────────────────────────────────────────────────┘
          │
┌─────────┴────────────────────────────────────────────────────────────┐
│  FACT LAYER (31 production tables total)                               │
│                                                                        │
│  [Group 1 — Financial & Rates]                                         │
│  tbl_contract_rates_all (459,902)                                      │
│  tbl_reimb_carve_outs (17,229)                                         │
│  tbl_reimb_stop_loss (3,847)                                           │
│  tbl_repricing_scenarios (7,600)                                       │
│  fact_supersession (2,380) ← provider_id ALL NULL (join via filename) │
│  tbl_financial_exposure (172)                                          │
│  tbl_rate_escalators (104)                                             │
│                                                                        │
│  [Group 2 — Documents & Structure]                                     │
│  tbl_vs_unified_ready (727,876)                                        │
│  tbl_contract_documents_master (10,349)                                │
│  tbl_contract_hierarchy (10,349)                                       │
│  tbl_genie_amendment_timeline (6,609)                                  │
│                                                                        │
│  [Group 3 — Clause Intelligence]                                       │
│  tbl_contract_clauses (7,863)                                          │
│  tbl_clause_deviations (7,777)                                         │
│                                                                        │
│  [Group 4 — Provider Identity]                                         │
│  tbl_provider_identifiers (50,159)                                     │
│                                                                        │
│  [Group 5 — Risk, Alerts & Deadlines]                                  │
│  tbl_contract_risk_scores (272)                                        │
│  tbl_contract_deadlines (713)                                          │
│  tbl_alert_queue (351)                                                 │
│                                                                        │
│  [Group 6 — Compliance & Quality]                                      │
│  tbl_compliance_tracking (2,871)                                       │
│  tbl_quality_performance (894)                                         │
│  tbl_contract_notifications (1,934)                                    │
│                                                                        │
│  [Group 7 — Delegation & Responsibility]                               │
│  tbl_dofr_matrix_extracted (1,821)                                     │
│  tbl_delegation_matrix (770)                                           │
│                                                                        │
│  [Group 8 — Audit & Provenance]                                        │
│  tbl_extraction_provenance (15,368)                                    │
│                                                                        │
│  [Group 9 — System & Infrastructure — see Dimensions + App layers]    │
│  dim_provider_canonical │ dim_health_system │ dim_table_schema         │
│  tbl_agent_sessions │ fact_retrieval_telemetry                         │
└──────────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────────┐
│  APP PERSISTENCE LAYER (active runtime traffic)                        │
│  tbl_agent_sessions (2,229) │ fact_retrieval_telemetry (1,300)        │
│  ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─    │
│  WIRED / 0 rows (awaiting production traffic):                         │
│  tbl_user_feedback │ app_query_telemetry │                            │
│  fact_extraction_run │ fact_file_extraction                            │
└──────────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────────┐
│  EXCLUDED / SYNTHETIC-ONLY (not counted in 31-table schema)           │
│  tbl_rate_benchmarks (10,434 rows — ALL SYNTHETIC, DEBT P3-D5:        │
│    pending real CMS IPPS/OPPS + DHCS Medi-Cal FFS data)               │
└──────────────────────────────────────────────────────────────────────┘
```
