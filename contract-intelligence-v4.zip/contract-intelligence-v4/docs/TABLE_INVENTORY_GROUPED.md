# Contract Intelligence V4 — Table Inventory by Group

**Source documents**: `DATA_MODEL_PRODUCTION_STATE.md` (v4, 31 production tables)
**Date**: 2026-07-20 (initial analysis 2026-07-13)
**Catalog / Schema**: `dev_adb.raw`
**Total production tables**: 31 (excl. views)
**Total rows**: ~1,343,064

Tables are grouped by the similarity of information they provide and ordered within each group by row count / coverage. Groups are ordered from highest to lowest business value.

---

## Group 1 — Financial & Rate Intelligence
*Directly answers "what does BSC pay" — highest business value*

| Table | Rows | What It Holds |
|---|---|---|
| `tbl_contract_rates_all` | 459,902 | Master reimbursement fact table — every historical rate across all doc versions, all rate units (PER_DAY, PMPM, PER_CASE, AWP_DISCOUNT, etc.), temporal supersession chain |
| `tbl_repricing_scenarios` | 7,600 | What-if simulations: avg_rate → simulated_rate, rate_delta_pct, estimated_annual_impact per scenario_label |
| `fact_supersession` | 2,380 | Rate supersession lineage — when a rate row transitioned from CURRENT to SUPERSEDED; must JOIN via superseding_filename (provider_id is NULL) |
| `tbl_financial_exposure` | 172 | Contracted spend ($1M–$282M), actual_spend, variance_pct, assigned_members, inpatient_admits, outpatient_visits by period_start/period_end |
| `tbl_rate_escalators` | 104 | Annual escalation terms per provider — escalator_type: CUSTOM (59) / FIXED_PCT (27) / CPI (18); columns: adjustment_pct, floor_pct, cap_pct, formula_text, base_index. No `escalator_pct` or `effective_date` columns. |
| `tbl_reimb_stop_loss` | 3,847 | Stop-loss provisions — stop_loss_type: CASE_RATE (3,477) / PER_DIEM (370); attachment_level, reimburse_formula_type, reimburse_rate. No `provider_name` — JOIN tbl_genie_provider_profile ON provider_id. |
| `tbl_reimb_carve_outs` | 17,229 | Carve-out provisions — carve_out_type: IMPLANT (10,181) / SUPPLY (3,658) / DRUG (1,713) / PROCEDURE (958) / DEVICE (719); threshold_amount, reimburse_formula_type, reimburse_of. No `provider_name` — JOIN tbl_genie_provider_profile ON provider_id. |

**Application status**: All 7 tables — **actively used**. `tbl_contract_rates_all` (RateQuery, SqlQuery). `tbl_repricing_scenarios`, `tbl_financial_exposure`, `tbl_rate_escalators`, `fact_supersession` (FinancialAnalysisTool — Phase 10B-2 COMPLETE, 5 live API endpoints). `tbl_reimb_stop_loss`, `tbl_reimb_carve_outs` (SqlQuery whitelist, passively queryable via sql_query tool).

---

## Group 2 — Contract Documents & Structure
*Source of truth — every other table traces back here*

| Table | Rows | What It Holds |
|---|---|---|
| `tbl_vs_unified_ready` | 727,876 | Full OCR chunked text corpus + vector embeddings (`is_current` flag) — powers all natural-language retrieval and clause verification |
| `tbl_contract_documents_master` | 10,349 | One row per PDF/version — contract_status, effective/expiration dates, document_type, payment_type, line_of_business, delegated_activities |
| `tbl_contract_hierarchy` | 10,349 | Amendment chain position (`sequential_order`) — which document superseded which; does NOT have `amendment_order` column |
| `tbl_genie_amendment_timeline` | 6,609 | Amendment-level change history with rate_count and summary_of_changes per document version |

**Application status**: `tbl_vs_unified_ready` and `tbl_contract_documents_master` — actively used. `tbl_contract_hierarchy` — passively available only. `tbl_genie_amendment_timeline` — actively used (TemporalAnalysis, ProviderDeepDive).

---

## Group 3 — Clause Intelligence
*Legal and operational contract terms — high value*

| Table | Rows | What It Holds |
|---|---|---|
| `tbl_contract_clauses` | 7,863 | Full clause_text across 21 categories (OFFSET_CLAUSE, TERMINATION_PROVISIONS, AUTO_RENEWAL, DISPUTE_RESOLUTION, UM_PRIOR_AUTH, etc.) — clause_status: HAS (7,849) / FALSE_POSITIVE (14). ABSENT does NOT exist in live data. |
| `tbl_clause_deviations` | 7,777 | Network conformance scores: network_has_pct / network_absent_pct per clause category. NOTE: all 7,777 rows are currently CONFORMANT/NONE — no actual deviation data exists. No baseline_text or actual_text columns. |
| `vw_genie_contract_terms` | view | Multi-concept aggregated clause view — used by MultiConcept, Comparison, ProviderDeepDive tools |

**Application status**: `tbl_contract_clauses` — **actively used** (ClauseTextTool, Phase 10B-5 COMPLETE — reads clause_text directly). `tbl_clause_deviations` — **actively used** (supplementary network_has_pct indicator via ClauseTextTool). `vw_genie_contract_terms` — actively leveraged.

**Phase 10B-5 COMPLETE**: ClauseTextTool rewritten and deployed — reads `clause_text` directly from `tbl_contract_clauses`. `tbl_clause_deviations` used as supplementary `network_has_pct` / `network_absent_pct` indicator. Deviation highlighting (red/yellow diff) is NOT feasible — all 7,777 rows are CONFORMANT (`deviation_type` / `severity` only, no `baseline_text` or `actual_text`).

---

## Group 4 — Provider Identity & Network
*Who a provider is, where they are, what system they belong to*

| Table | Rows | What It Holds |
|---|---|---|
| `tbl_provider_identifiers` | 50,159 | Full identifier registry: NPI (10 digits), TIN (9 digits), MEDICARE_ID, MEDI_CAL_ID, CCN — claims-level coverage across source systems |
| `dim_provider_canonical` | 531 | Canonical identity layer — the master JOIN key (`provider_id`) across all 31 tables; is_primary_id, all_names_used array |
| `tbl_genie_provider_profile` | 306 | One-row summary per provider: payment_type (FFS/Capitation/etc.), total_rates, current_rates, is_active, offset/dofr/ipa flags |
| `tbl_service_areas` | 306 | Geographic coverage — `region` (NOT service_area_name); `county` (STRING, NULL for Statewide); `assignment_method`. No `coverage_type` or `counties` columns. 61% Statewide. |
| `tbl_provider_system_membership` | 112 | Provider ↔ health system bridge (system_id FK); 24% of 304 canonical providers mapped |
| `dim_health_system` | 20 | 20 named health systems (Kaiser, Dignity, Sutter, etc.) with pipe-delimited name_patterns for auto-matching new providers |

**Application status**: `dim_provider_canonical`, `tbl_genie_provider_profile`, `dim_health_system`, `tbl_provider_system_membership` — **actively used** (SystemMembershipTool — Phase 10B-3 COMPLETE; 4 live API endpoints). `tbl_provider_identifiers` and `tbl_service_areas` — passively available only.

---

## Group 5 — Risk, Alerts & Deadlines
*Operational urgency — what needs action now*

| Table | Rows | What It Holds |
|---|---|---|
| `tbl_contract_risk_scores` | 272 | Composite risk score (18–48) + risk_tier (LOW 239 / MEDIUM 26 / MONITOR 7) across 19 dimensions: expiration_risk, compliance_gap, clause_gap, amendment_velocity, fin_risk |
| `tbl_contract_deadlines` | 713 | Unified deadline calendar — event_date, action_required_by, days_until_action (negative = overdue), priority_tier (CRITICAL 127 / HIGH 122 / MEDIUM 89 / LOW 273 / EXPIRED 102). contract_status: ACTIVE (711) / FUTURE (2) only. |
| `tbl_alert_queue` | 351 | Active alerts — 229 CRITICAL / 34 HIGH / 88 MEDIUM; all NEW status; linked to deadlines via source_deadline_id → deadline_id FK |

**Application status**: All three — **actively used** (RiskAlertTool — Phase 10B-1 COMPLETE; 5 live API endpoints: /risk/portfolio, /risk/{name}, /deadlines, /deadlines/{name}, /alerts).

**Critical column corrections**:
- Use `days_until_action` (NOT `days_until_deadline`)
- Use `event_date` + `action_required_by` (NOT `deadline_date`)
- No FK to notifications — link via `provider_id` only

---

## Group 6 — Compliance & Quality
*Regulatory obligations and performance programs*

| Table | Rows | What It Holds |
|---|---|---|
| `tbl_compliance_tracking` | 2,871 | Compliance status per provider × 7 regulations: KNOX_KEENE (508), CMS_MA (517), DMHC_STANDARDS (498), AB_1455 (386), SB_137 (352), AB_352 (305), AB_72 (305) — COMPLIANT / PARTIAL / UNKNOWN / EXEMPT (NON_COMPLIANT never in data) |
| `tbl_contract_notifications` | 1,934 | Notice requirements — notice_days, cure_period_days, notice_text, trigger_event; 7 notification types (TERMINATION, RATE_CHANGE, AUDIT, RENEWAL, CREDENTIALING, CLAIMS_SUBMISSION_DEADLINE) |
| `tbl_quality_performance` | 894 | Quality program participation — HEDIS, P4P, VALUE_BASED, WITHHOLD, STAR_RATING; bonus_pct / penalty_pct (NULL on prose contracts), formula_text |

**Application status**: All three — **actively used** (ComplianceQueryTool — Phase 10B-4 COMPLETE; 4 live API endpoints: /compliance/summary, /compliance/{name}, /quality/{name}, /notifications/{name}).

---

## Group 7 — Delegation & Responsibility
*Who is financially and administratively responsible for which services*

| Table | Rows | What It Holds |
|---|---|---|
| `tbl_dofr_matrix_extracted` | 1,821 | DOFR rows — responsible party (group_responsible / hospital_responsible / health_plan_responsible) per service_category + subcategory |
| `tbl_delegation_matrix` | 770 | IPA delegation scope — which clinical/admin functions each IPA-delegated provider has delegated (120 IPA providers, avg 6.4 functions each) |

**Application status**: `tbl_dofr_matrix_extracted` — actively used (agent_controller DOFR prompt logic). `tbl_delegation_matrix` — passively available only (no dedicated tool).

---

## Group 8 — Audit & Provenance
*Data confidence and extraction traceability — power user feature*

| Table | Rows | What It Holds |
|---|---|---|
| `tbl_extraction_provenance` | 15,368 | Full audit trail per extracted field — extraction_method: PATTERN_MATCH only (100% of rows); confidence_score (FLOAT, NULL for DOFR rows); human_verified (ALL false); provider_id (0 nulls, 1,395 distinct); source_page_numbers, model_version |

**Application status**: **Actively used** (ProvenanceTool — Phase 10B-6 COMPLETE; 4 live API endpoints: /provenance/summary, /provenance/{name}, /provenance/document/{filename}, /provenance/quality).

**Note**: `provider_id` IS present (0 nulls, 1,395 distinct — added in Phase 10B-6). Can JOIN directly ON `provider_id`. Coverage by target_table: clauses (7,777), notifications (1,934), compliance (1,897), delegation (1,599), dofr (1,163), quality (894), escalators (104).

---

## Group 9 — System & Infrastructure
*App operation and runtime — not business analytics*

| Table | Rows | What It Holds |
|---|---|---|
| `dim_table_schema` | 468 | Runtime schema registry — column-level metadata for SQL generation (29 tables × avg 16 columns). RUNTIME CRITICAL — do NOT drop or truncate |
| `fact_retrieval_telemetry` | 1,300 | Vector search retrieval telemetry — chunk scores, latency_ms, retrieved_chunks per query session |
| `tbl_agent_sessions` | 2,229 | Runtime session history — every query turn auto-persisted via `_persist_turn()` |

**Application status**: `dim_table_schema` — actively used (SchemaContextBuilder). `tbl_agent_sessions` — actively used (SessionRepo). `fact_retrieval_telemetry` — actively used (TelemetryRepo).

---

## Summary by Application Coverage

| Group | Tables | Actively Used | Passively Available | Completely Invisible |
|---|---|---|---|---|
| 1 — Financial & Rates | 7 | 7 | 0 | 0 |
| 2 — Contract Documents | 4 | 3 | 1 | 0 |
| 3 — Clause Intelligence | 3 | 3 | 0 | 0 |
| 4 — Provider Identity & Network | 6 | 4 | 2 | 0 |
| 5 — Risk, Alerts & Deadlines | 3 | 3 | 0 | 0 |
| 6 — Compliance & Quality | 3 | 3 | 0 | 0 |
| 7 — Delegation & Responsibility | 2 | 1 | 1 | 0 |
| 8 — Audit & Provenance | 1 | 1 | 0 | 0 |
| 9 — System & Infrastructure | 3 | 3 | 0 | 0 |
| **TOTAL** | **31** | **28 (90%)** | **4 (13%)** | **0 (0%)** |

> Note: Group 3 includes `vw_genie_contract_terms` (a view, not a table). "Actively Used" = dedicated tool or query logic. "Passively Available" = in SQL whitelist, no dedicated features. "Completely Invisible" = zero code references. Phase 10B (10B-1 through 10B-6) drove the jump from 11 → 28 actively used tables.

---

## Phase 10B Cluster-to-Group Mapping

| Phase 10B Cluster | Priority | Group(s) Addressed |
|---|---|---|
| Cluster A: Risk & Alerts | Highest | Group 5 |
| Cluster B: Financial Intelligence | High | Group 1 |
| Cluster C: Network & Geography | Medium | Group 4 |
| Cluster D: Compliance & Quality | Medium | Group 6 |
| Cluster E: Clause Intelligence | High | Group 3 |
| Cluster F: Audit & Provenance | Low | Group 8 |

---

*Generated 2026-07-13 from DATA_MODEL_PRODUCTION_STATE.md (v4). Groups 2, 7, and 9 are partially or fully covered by existing application logic; Groups 1, 3, 4, 5, 6, and 8 have the largest coverage gaps.*

---
---

# Deep Analysis: `tbl_contract_rates_all`

**Analyzed**: 2026-07-13 (live queries against dev_adb.raw)
**Analyst lens**: Data Engineer + Data Architect

---

## 1. Physical & Storage Profile

| Property | Value | Assessment |
|---|---|---|
| Format | Delta (ZSTD compressed) | Optimal for analytical workloads |
| Files | 1 Parquet file | Risk: no file-level pruning possible |
| Size on disk | 8.3 MB | 18 bytes/row — extremely efficient compression |
| Partitions | None | Full scan on every query |
| Clustering columns | None | No skip-range statistics |
| Change Data Feed | Enabled | Good — supports downstream CDC consumers |
| Deletion Vectors | Enabled | Good — soft deletes avoid full file rewrites |
| `appendOnly` feature | Enabled | Contradiction: multiple DELETE phases ran against this table |
| Delta Reader/Writer | v3 / v7 | Current, supports all table features |
| Last modified | 2026-07-12 | Post Phase 9 temporal paradox remediation |
| Row count | 459,902 | 43 Delta commits since table creation |

**Storage concern**: The entire table is a single 8.3 MB Parquet file. While this is fine today, it means every query does a full file scan regardless of filter predicates. As the table grows (new contract cycles, new providers), this will degrade. Liquid clustering on `canonical_provider_id` + `status` + `rate_unit` would give immediate I/O savings on the most common query patterns.

---

## 2. Schema Inventory (28 columns)

| Column | Type | Nullable | Null Count | Null % | Notes |
|---|---|---|---|---|---|
| `provider_id` | STRING | YES | 0 | 0% | Clean |
| `provider_name` | STRING | YES | 0 | 0% | Clean |
| `source_filename` | STRING | YES | 0 | 0% | Clean |
| `document_type` | STRING | YES | 0 | 0% | 270 distinct values — too many |
| `rate_category` | STRING | YES | 0 | 0% | 22 distinct values |
| `service_category` | STRING | YES | 0 | 0% | **22,045 distinct values — effectively free text** |
| `rate_type_detail` | STRING | YES | 0 | 0% | 1,283 distinct values — free text |
| `rate_text` | STRING | YES | 3,105 | 0.67% | When both rate_text and rate_numeric are null = zombie row |
| `rate_numeric` | DOUBLE | YES | 8,297 | 1.8% | Text-only rates (formulas, prose) |
| `revenue_codes` | STRING | YES | 128,292 | 27.9% | By design — non-UB-04 contracts |
| `effective_date` | STRING | YES | 0 | 0% | Raw string, duplicate of parsed below |
| `program` | STRING | YES | — | — | 608 distinct values — free text |
| `network` | STRING | YES | — | — | 605 distinct values — free text |
| `formula` | STRING | YES | 411,767 | 89.5% | Only formula-based contracts populate |
| `notes` | STRING | YES | — | — | Unstructured |
| `amendment_order` | STRING | YES | 0 | 0% | Stored as STRING — cast required |
| `status` | STRING | YES | 0 | 0% | Only 2 values: `current` / `superseded` |
| `superseded_by` | STRING | YES | 299,415 | 65.1% | Format: `eff:DATE\|src:FILENAME` — 0 malformed |
| `superseded_date` | STRING | YES | — | — | Stored as STRING |
| `is_latest_version` | BOOLEAN | YES | 0 | 0% | 42,527 rows conflict with `status` |
| `source_table` | STRING | YES | — | — | Provenance marker |
| `program_normalized` | STRING | YES | 0 | 0% | 9 distinct values — normalized correctly |
| `is_valid_rate` | BOOLEAN | YES | 0 | 0% | Domain-aware flag |
| `effective_date_parsed` | DATE | YES | 732 | 0.16% | The queryable date field — use this |
| `canonical_provider_id` | STRING | YES | 0 | 0% | 100% populated — use for all joins |
| `amendment_order_int` | INT | YES | 2,782 | 0.6% | TRY_CAST failures from non-numeric amendment labels |
| `expiration_date` | DATE | YES | 243,584 | 52.9% | Derived via LEAD — NULL = still active |
| `rate_unit` | STRING | YES | 0 | 0% | 6 valid values — use for numeric bounds |

**Critical schema finding**: Every single column is nullable. There are zero NOT NULL constraints in this table. The most business-critical columns — `provider_id`, `source_filename`, `rate_unit`, `status`, `is_valid_rate` — have 0 nulls today only because the application enforces this at write time. A bad pipeline run that skips validation would corrupt the table silently.

---

## 3. Rate Unit Distribution & Numeric Profiles

| rate_unit | Rows | % | Current | Invalid | Min | P25 | Median | P75 | P95 | Max | Avg | StdDev |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| PER_DAY | 219,019 | 47.6% | 70,483 | 8,662 | $0 | $2,894 | $7,147 | $14,796 | $44,485 | $556,268 | $13,032 | $22,594 |
| PER_VISIT | 121,779 | 26.5% | 31,958 | 331 | $0 | $85 | $273 | $2,242 | $17,829 | $268,000 | $3,286 | $7,410 |
| PMPM | 67,560 | 14.7% | 26,891 | 68 | $0 | $55.99 | $106.89 | $181.35 | $383.37 | $71,113 | $148 | $516 |
| PER_CASE | 48,384 | 10.5% | 5,935 | 0 | $0.17 | $455 | $840 | $1,366 | $144,820 | $840,000 | $18,839 | $53,105 |
| PER_PROCEDURE | 3,135 | 0.7% | 211 | 0 | $0.07 | $40.70 | $40.70 | $8,340 | $23,761 | $36,237 | $4,870 | $8,347 |
| AWP_DISCOUNT | 25 | 0.005% | 7 | 25 | -16 | -16 | -16 | -16 | -16 | -16 | -16 | 0 |

**Findings:**

* PER_DAY dominates at 47.6%. Its max of $556,268/day is held by Woodland Memorial Hospital — this value passed plausibility bounds (cap $500,000) yet sits 35× above the P95 of $44,485. It should be flagged for manual review even if technically within bounds.
* PMPM max of $71,113 is nearly 3× the documented Phase 6 plausibility cap of $25,000. This row is not being filtered by `is_valid_rate` — the cap was applied during a prior phase but the max survivor escaped it. The stddev of $516 against an avg of $148 indicates extreme right-tail skew from a small number of high-PMPM rows.
* PER_CASE median of $840 is surprisingly low against a max of $840,000 — the distribution is bimodal (simple outpatient cases at low end, complex inpatient at high end).
* AWP_DISCOUNT: All 25 rows have `rate_numeric = -16` and `is_valid_rate = false`. The `-16` likely represents a 16% discount coded as a negative. The validity flag incorrectly marks these invalid because the plausibility engine expects positive numbers. AWP_DISCOUNT requires its own bounds logic (valid range: -100 to 0).
* PER_PROCEDURE P25 = P50 = $40.70 — extreme concentration at a single value, suggesting a single template rate was applied to many rows without individualization.

---

## 4. Status & Supersession Chain Analysis

| Metric | Count |
|---|---|
| Total rows | 459,902 |
| Status = `current` | 135,485 (29.5%) |
| Status = `superseded` | 324,417 (70.5%) |
| Terminal current rows (current + null superseded_by) | 135,485 |
| Superseded with valid `eff:\|src:` pointer | 160,487 |
| Superseded with NULL superseded_by (broken chain) | 163,930 |
| Current with superseded_by pointer (contradiction) | 0 |
| `is_latest_version = true` but status = `superseded` (temporal paradox) | 42,527 |
| `is_latest_version = false` but status = `current` (reverse contradiction) | 0 |
| Malformed superseded_by (non-`eff:` format) | 0 |

**Chain integrity assessment:**

The `superseded_by` format is clean — all 160,487 populated values follow the `eff:DATE|src:FILENAME` contract with zero malformed entries. However, 163,930 superseded rows (50.5% of all superseded rows) have no forward pointer. These are not terminal rows — they are confirmed `superseded` but the system doesn't know what superseded them. This breaks any attempt to reconstruct the full amendment chain for a rate through SQL alone.

The 42,527 `is_latest_version`/`status` conflicts from Phase 9 are the unresolved temporal paradox — rows where the `is_latest_version` flag was not updated when the row's `status` was set to `superseded`. Any query that relies on `is_latest_version = true` to get current rates will silently return 42,527 stale rows. All production queries **must use `status = 'current'`**, not `is_latest_version`.

---

## 5. Provider Coverage & Concentration

| Metric | Value |
|---|---|
| Distinct `provider_id` values | 518 |
| Distinct `canonical_provider_id` values | 300 |
| Provider_ids not in `tbl_genie_provider_profile` | 216 → 128,896 rows (28%) |
| Provider_ids ≠ canonical_provider_id | 218 → 130,825 rows (28.4%) |
| Top provider (Mercy General Hospital) | 18,038 rows = 3.9% of total |
| Top 10% of providers (30 providers) | 215,784 rows = 46.9% of total |
| Top 30% of providers (90 providers) | 369,930 rows = 80.5% of total |
| Bottom 30% of providers (90 providers) | 1,831 rows = 0.4% of total |

**Concentration finding**: The rate distribution is severely right-skewed. 30 providers account for nearly half the table. The bottom decile (30 providers) averages 12 rates each — these are thin-contract providers, likely capitation-only or single-service agreements. Any aggregate analysis (average rates across network) must be volume-weighted, not provider-weighted, or it will be dominated by the top-10 high-volume providers.

**Orphan analysis**: 216 provider_ids (128,896 rows = 28%) exist in this table but not in `tbl_genie_provider_profile`. These are real contracts in the corpus but fall outside the 300-provider canonical network view. Queries that JOIN to `tbl_genie_provider_profile` on `provider_id` will silently drop 28% of rows. Always JOIN on `canonical_provider_id` and be aware that 28% of rows represent out-of-network or legacy providers.

---

## 6. Temporal Coverage (1985–2027)

| Period | Pattern |
|---|---|
| 1985–1999 | 14 years, sparse (1,620 rows, 4 providers max/year) — legacy historical contracts |
| 2000–2006 | Gradual ramp (5,381 rows) — mostly superseded |
| 2007 | Spike: 8,491 rows, 5,828 current — large tranche of rates activated and not yet superseded |
| 2008–2012 | Heavy superseded period (avg 18K rows/year, 80–90% superseded) |
| 2013–2019 | Stable active contract cycle (avg 27K rows/year) |
| 2020–2022 | Peak volume years (avg 38K rows/year) — likely ACA compliance amendments |
| 2023–2025 | Active negotiation era (avg 32K rows/year, ~35% still current) |
| 2026 | 3,677 rows, 1,814 current — current-year contracts |
| 2027 | 1,522 rows, 798 current — future-dated pre-negotiated rates |

**Temporal concern**: The 732 rows with NULL `effective_date_parsed` are a data quality gap. Without an effective date, these rows cannot be placed in the amendment chain and cannot be used for date-bounded queries. These are candidates for OCR re-extraction (DEBT P3-D1).

The presence of 1985 data alongside 2027 future-dated rates means the temporal span is 42 years. Any query using date ranges must be careful about the long tail of historical data — a `WHERE effective_date_parsed >= '2020-01-01'` filter is usually required to get operationally relevant results.

---

## 7. Cardinality & Category Analysis

| Dimension | Distinct Values | Assessment |
|---|---|---|
| `rate_unit` | 6 | Tightly controlled enum — good |
| `rate_category` | 22 | Managed, but has naming inconsistencies |
| `program_normalized` | 9 | Controlled normalization — good |
| `document_type` | 270 | Too high — should be standardized to ~30 |
| `service_category` | **22,045** | Effectively a free-text field — unusable for filtering |
| `rate_type_detail` | 1,283 | Free text |
| `program` | 608 | Un-normalized version of program_normalized |
| `network` | 605 | Free text — no normalization applied |

**The `service_category` problem is the most severe data quality issue in this table.** With 22,045 distinct values across 459,902 rows, `service_category` is essentially the raw OCR text fragment extracted from the contract. It cannot be used as a WHERE filter in any reliable way — two rows describing the same service may have 50 different `service_category` values depending on which exact phrase appeared in the PDF. The only reliable filters are `rate_unit`, `rate_category` (22 values), and `program_normalized` (9 values).

**Rate category naming inconsistency:**
- `inpatient_per_diem` (82,088 rows) and `inpatient_per_diem_rates` (46,272 rows) are the same category under two different names. This creates double-counting risk on any GROUP BY `rate_category`.
- Similarly `inpatient_case_rate` (64,216) and `inpatient_case_rates` (17,745) overlap.
- Together these duplicated categories represent ~210K rows (46% of table) where the category field cannot be trusted for aggregation without normalization.

---

## 8. Data Quality Integrity Checks

| Check | Result | Severity |
|---|---|---|
| Rows with neither rate_numeric nor rate_text | 3,105 (0.67%) | HIGH — no rate value exists |
| is_valid_rate = false | 9,086 (1.97%) across 156 providers | MEDIUM |
| AWP_DISCOUNT all marked invalid | 25/25 — is_valid_rate flag model error | MEDIUM |
| is_latest_version conflicts with status | 42,527 rows | HIGH — incorrect flag |
| superseded with no forward pointer | 163,930 (35.6% of table) | HIGH — broken chain |
| Duplicate rate_category naming (per_diem/case_rate) | ~210K rows affected | HIGH |
| service_category cardinality (22,045) | Full table | CRITICAL — unusable for filtering |
| No NOT NULL constraints on any column | All 28 columns | MEDIUM — silent corruption risk |
| No primary key or surrogate key | Table-wide | MEDIUM — MERGE ambiguity |
| amendment_order stored as STRING | 2,782 cast failures | LOW |
| effective_date stored as both STRING and DATE | Full table | LOW — redundant, confusing |
| PMPM max ($71,113) exceeds documented cap ($25,000) | 1+ rows | MEDIUM |
| No partitioning or clustering | Full table | MEDIUM — query performance |
| Single Parquet file | Full table | LOW — will degrade as table grows |

---

## 9. Critical Query Patterns (What Works vs What Fails)

**Always safe:**
```sql
WHERE status = 'current'                          -- use status, NOT is_latest_version
AND   is_valid_rate = true                        -- filters 9,086 invalid rows
JOIN  tbl_genie_provider_profile p
  ON  r.canonical_provider_id = p.provider_id    -- use canonical_provider_id, NOT provider_id
```

**Avoid:**
```sql
WHERE is_latest_version = true                    -- 42,527 stale true-flags on superseded rows
WHERE service_category = 'Physical Therapy'       -- 22,045 distinct values, unreliable
WHERE rate_category = 'inpatient_per_diem'        -- misses 46,272 rows in 'inpatient_per_diem_rates'
JOIN  tbl_genie_provider_profile p
  ON  r.provider_id = p.provider_id              -- drops 128,896 rows (28% of table)
```

**Rate aggregation pattern (correct):**
```sql
SELECT
  canonical_provider_id,
  rate_unit,
  rate_category,
  AVG(rate_numeric)  AS avg_rate,
  COUNT(*)           AS rate_count
FROM dev_adb.raw.tbl_contract_rates_all
WHERE status        = 'current'
  AND is_valid_rate = true
  AND rate_numeric  IS NOT NULL
GROUP BY canonical_provider_id, rate_unit, rate_category
```

---

## 10. Architectural Recommendations (Prioritized)

| Priority | Recommendation | Impact |
|---|---|---|
| P0 | Add `NOT NULL` constraints on `provider_id`, `source_filename`, `rate_unit`, `status`, `is_valid_rate` via column-level CHECK invariants or pre-write validation | Silent corruption prevention |
| P0 | Fix `is_latest_version` flag for 42,527 conflicting rows — run `UPDATE SET is_latest_version = false WHERE status = 'superseded' AND is_latest_version = true` | Correctness — agent SQL may use this flag |
| P0 | Fix AWP_DISCOUNT validity logic — all 25 rows are marked `is_valid_rate = false` because the plausibility engine expects positive numbers. AWP_DISCOUNT rates should have their own bounds (-100 to 0). | Rate answer correctness |
| P1 | Add liquid clustering on `canonical_provider_id`, `status`, `rate_unit` | Query performance — eliminates full scans |
| P1 | Normalize `rate_category` — consolidate `inpatient_per_diem` + `inpatient_per_diem_rates` and `inpatient_case_rate` + `inpatient_case_rates` into single canonical values | Aggregation correctness — ~210K rows affected |
| P1 | Resolve 3,105 zombie rows (null rate_numeric AND null rate_text) — either backfill from OCR or delete | Prevents zero-rate distortions in averages |
| P1 | Address 163,930 superseded rows with no `superseded_by` pointer — backfill via JOIN to the next version per provider+rate_category chain | Chain integrity |
| P2 | Add a `rate_id` surrogate key (UUID or BIGINT IDENTITY) | MERGE safety — current lack of PK makes ON clause fragile |
| P2 | Normalize `service_category` into a small vocabulary (~200 standardized values) via an LLM classification pass | The single highest-impact DQ improvement — unlocks service-level filtering |
| P2 | Normalize `network` and `program` columns (605 and 608 distinct values respectively) into controlled vocabularies | Enables network-level and program-level aggregations |
| P3 | Investigate PMPM max of $71,113 — exceeds the documented Phase 6 cap of $25,000 | Data trust |
| P3 | Investigate PER_DAY max of $556,268 (Woodland Memorial) — 35× the P95, technically within cap but an extreme outlier | Data trust |
| P3 | Remove dual date storage (`effective_date` STRING + `effective_date_parsed` DATE) — keep only the DATE column and deprecate the raw string | Schema hygiene |
| P3 | Break out `appendOnly` table feature — multiple DELETE operations have run against this table, which is incompatible with appendOnly semantics in strict mode | Storage integrity |

---

*Deep analysis run live against `dev_adb.raw.tbl_contract_rates_all` on 2026-07-13.*

---

# Deep Analysis: `tbl_repricing_scenarios`

**Analyzed**: 2026-07-13 (schema introspection + documentation)
**Analyst lens**: Data Engineer + Financial Analyst

---

## 1. Physical & Storage Profile

| Property | Value | Assessment |
|---|---|---|
| Format | Delta (MANAGED) | Standard |
| Rows | 7,600 | Small table — full scan is cheap |
| Columns | 12 | Lean, focused schema |
| Created | 2026-07-08 | Relatively recent |
| Partitions | None | Acceptable at this size |
| Application status | **Actively used** | ProvenanceTool (Phase 10B-6 COMPLETE); 4 live API endpoints |

---

## 2. Schema Inventory (12 columns)

| Column | Type | Nullable | Notes |
|---|---|---|---|
| `scenario_id` | STRING | YES | Logical PK — no uniqueness constraint enforced |
| `provider_id` | STRING | YES | FK to `dim_provider_canonical` |
| `provider_name` | STRING | YES | Denormalized display name |
| `rate_category` | STRING | YES | Maps to `rate_category` in `tbl_contract_rates_all` |
| `scenario_label` | STRING | YES | Human-readable scenario name (e.g., "5% increase", "Medicare benchmark") |
| `rate_delta_pct` | DOUBLE | YES | Percentage change applied in this scenario |
| `avg_rate` | DOUBLE | YES | Baseline average rate before simulation |
| `simulated_rate` | DOUBLE | YES | Avg rate after applying `rate_delta_pct` |
| `rate_delta` | DOUBLE | YES | Absolute dollar delta (simulated_rate - avg_rate) |
| `rate_row_count` | BIGINT | YES | Number of rate rows this scenario aggregates over |
| `estimated_annual_impact` | DOUBLE | YES | Total dollar impact across all member-months/cases |
| `simulated_at` | TIMESTAMP | YES | When the simulation was computed |

**Critical schema finding**: Every column is nullable. `scenario_id` is intended as the logical PK but has no NOT NULL constraint. There is no FK enforcement to `dim_provider_canonical`. All computed columns (simulated_rate, estimated_annual_impact) can be NULL without raising any error — a failed simulation run would silently produce NULL values in the most business-critical fields.

---

## 3. Business Logic & Design Assessment

This is a **pre-aggregated simulation table**, not a transactional fact table. It stores the *results* of what-if analyses run against `tbl_contract_rates_all`, not individual rate rows. The design implies:

- `avg_rate` is computed as `AVG(rate_numeric)` from `tbl_contract_rates_all` WHERE status='current' AND is_valid_rate=true, grouped by (provider_id, rate_category).
- `simulated_rate` = `avg_rate * (1 + rate_delta_pct/100)` or similar formula.
- `estimated_annual_impact` likely requires an external `assigned_members` or utilization factor — probably sourced from `tbl_financial_exposure`, but that table only has 172 rows, covering far fewer than the 7,600 scenario rows. This means most `estimated_annual_impact` values are estimated from proxy sources (PMPM × 12 or similar), not from real claims.

**Staleness risk**: `simulated_at` is a single timestamp per scenario row. If `tbl_contract_rates_all` is updated (new rates extracted, rates superseded) the scenario values become stale. There is no refresh trigger or CDC linkage. As of the last Phase 9 remediation (2026-07-12), any scenario computed before that date reflects pre-remediation rate values.

---

## 4. Data Quality Checks

| Check | Expected State | Risk |
|---|---|---|
| scenario_id uniqueness | Not enforced by schema | MEDIUM — possible duplicate scenario rows |
| estimated_annual_impact NULLs | Likely on providers without financial exposure data | HIGH — silent financial gap |
| Stale simulated_at | Scenarios created pre-Phase 9 (before 2026-07-12) are stale | HIGH |
| avg_rate = 0 | Possible for capitation-only providers with no numeric rates | MEDIUM |
| rate_delta_pct range | Unvalidated — could contain extreme values (+100%, -100%) | LOW |
| No JOIN to tbl_financial_exposure | Utilization inputs are opaque — impact figures unverifiable | HIGH |

---

## 5. Critical Query Patterns

**Safe use:**
```sql
SELECT provider_id, scenario_label, rate_category,
       avg_rate, simulated_rate, estimated_annual_impact
FROM dev_adb.raw.tbl_repricing_scenarios
WHERE estimated_annual_impact IS NOT NULL
ORDER BY ABS(estimated_annual_impact) DESC
```

**Avoid:**
```sql
-- Do NOT use for current-rate lookups — values may be stale post-Phase 9
-- Always check simulated_at >= '2026-07-12' for post-remediation accuracy
```

---

## 6. Architectural Recommendations

| Priority | Recommendation | Impact |
|---|---|---|
| P0 | Add `NOT NULL` constraint on `scenario_id` and `provider_id` | Integrity |
| P0 | Implement a refresh trigger — invalidate or recompute scenarios after any update to `tbl_contract_rates_all` | Correctness — prevents stale financial projections |
| P1 | Expose in application via a Financial Scenarios tool (currently 0 code references) | Unlocks contract negotiation support |
| P1 | Document the `estimated_annual_impact` formula — specify whether it uses `tbl_financial_exposure` or proxy PMPM | Transparency |
| P2 | Add `is_stale BOOLEAN` computed flag (simulated_at < last_modified of rates table) | Operational safety |
| P2 | Add `rate_unit` column — without it, comparing scenarios across PER_DAY vs PMPM providers conflates units | Analysis correctness |

---

*Analysis based on schema introspection of `dev_adb.raw.tbl_repricing_scenarios` (2026-07-13). Live data queries not executed.*

---

# Deep Analysis: `fact_supersession`

**Analyzed**: 2026-07-13 (schema introspection + documentation)
**Analyst lens**: Data Engineer + Graph/Lineage Specialist

---

## 1. Physical & Storage Profile

| Property | Value | Assessment |
|---|---|---|
| Format | Delta (MANAGED) | Standard |
| Rows | 2,380 | Small edge table |
| Columns | 19 | Rich supersession record |
| Created | 2026-06-06 | Pre-Phase 3 |
| Application status | **Actively used** | ProvenanceTool (Phase 10B-6 COMPLETE); 4 live API endpoints |

Table comment: *"Amendment supersession graph (2,380 edges). Each row = one document superseding another within the same contract_chain_id. Key columns: superseding_filename, superseded_filename."*

---

## 2. Schema Inventory (19 columns)

| Column | Type | Nullable | Notes |
|---|---|---|---|
| `supersession_id` | STRING | YES | Logical PK ("Unique supersession edge ID") — no uniqueness constraint |
| `superseding_filename` | STRING | YES | The **newer** document — primary join key |
| `superseded_filename` | STRING | YES | The **older** document being replaced |
| `provider_id` | STRING | YES | **WARNING: may be NULL** — derive from filename join to tbl_contract_documents_master |
| `contract_chain_id` | STRING | YES | Groups all amendments in a single contract lineage |
| `supersession_type` | STRING | YES | rate, clause, term, schedule, exhibit |
| `supersession_scope` | STRING | YES | full_document, section, individual_rate |
| `superseding_effective_date` | DATE | YES | When the newer document took effect |
| `superseded_effective_date` | DATE | YES | When the older document was originally effective |
| `superseded_valid_to` | DATE | YES | Day the older document stopped being effective |
| `rate_domain` | STRING | YES | INPATIENT, OUTPATIENT, etc. — populated only when supersession_type = 'rate' |
| `old_rate_numeric` | FLOAT | YES | Previous rate value — NULL for non-rate supersessions |
| `new_rate_numeric` | FLOAT | YES | New rate value — NULL for non-rate supersessions |
| `rate_change_pct` | FLOAT | YES | ((new-old)/old)*100 — NULL for non-rate supersessions |
| `clause_type` | STRING | YES | Populated only when supersession_type = 'clause' |
| `change_summary` | STRING | YES | Brief description of what changed |
| `confidence` | FLOAT | YES | 0.0–1.0 confidence in the supersession relationship |
| `derivation_method` | STRING | YES | temporal_chain, explicit_reference, filename_sequence |
| (column 18) | STRING | YES | Omitted from metadata — review schema directly |

---

## 3. Design & Relationship Analysis

This is the **graph edge table** for the amendment chain. It models the contract amendment lifecycle as a directed acyclic graph (DAG):
- Each row is an edge: `superseded_filename → superseding_filename`
- Multiple edges per provider form the amendment timeline
- `contract_chain_id` is the graph component identifier (all amendments to one base agreement)

**Critical join warning**: The `provider_id` column is documented to potentially be NULL. The table was created in June 2026 when the provider identity resolution was incomplete. Always JOIN to `tbl_contract_documents_master` on `superseding_filename` to retrieve the authoritative `provider_id`.

**Relationship to tbl_contract_rates_all**: This table captures which *documents* superseded each other, while `tbl_contract_rates_all.superseded_by` captures which *rate rows* were superseded (per provider+category+rate_unit). The two supersession systems are **parallel but not linked** — there is no FK connecting a `fact_supersession` edge to the specific `tbl_contract_rates_all` rows it affected.

**Confidence distribution**: The `confidence` field (0.0–1.0) reflects how the supersession relationship was determined:
- `explicit_reference`: highest confidence — document text says "this amendment supersedes Exhibit A of the 2019 base agreement"
- `filename_sequence`: medium confidence — inferred from filename version numbering
- `temporal_chain`: lowest confidence — inferred purely from effective date ordering

Without live queries, exact confidence distribution is unknown, but any downstream query consuming this table should filter `confidence >= 0.7` to avoid low-confidence inferred edges.

---

## 4. Data Quality Checks

| Check | Assessment | Severity |
|---|---|---|
| provider_id NULLs | Likely HIGH null rate — must derive from filename | HIGH |
| Orphan edges (filenames not in tbl_contract_documents_master) | Unknown — requires live join | MEDIUM |
| Circular references in contract_chain_id graph | Possible if filename_sequence derivation was bidirectional | MEDIUM |
| rate_change_pct = NULL for rate-type supersessions | Occurs when old/new rate not extracted (text-only rates) | MEDIUM |
| confidence < 0.5 edges | No count available — low-confidence edges should be excluded from chain traversal | HIGH |
| supersession_id uniqueness | Not enforced — possible duplicate edges | LOW |
| All columns nullable | Silent corruption risk identical to tbl_contract_rates_all | MEDIUM |

---

## 5. Critical Query Patterns

**Reconstructing amendment chain for a provider:**
```sql
SELECT fs.superseded_filename, fs.superseding_filename,
       fs.supersession_type, fs.superseding_effective_date,
       fs.rate_change_pct, fs.confidence
FROM dev_adb.raw.fact_supersession fs
JOIN dev_adb.raw.tbl_contract_documents_master d
  ON d.source_filename = fs.superseding_filename
WHERE d.provider_id = '<provider_id>'
  AND fs.confidence >= 0.7
ORDER BY fs.superseding_effective_date
```

**Avoid:**
```sql
-- Do NOT join on provider_id directly — it may be NULL
WHERE fs.provider_id = '<provider_id>'   -- unreliable

-- Do NOT use without confidence filter — may include low-quality inferred edges
SELECT * FROM fact_supersession          -- all 2,380 rows without confidence check
```

---

## 6. Architectural Recommendations

| Priority | Recommendation | Impact |
|---|---|---|
| P0 | Backfill NULL `provider_id` values via JOIN to `tbl_contract_documents_master` on `superseding_filename` | Enables direct provider-level graph queries |
| P0 | Expose in application — this table is the *correct* mechanism for amendment chain traversal (0 current code references) | Replaces fragile `superseded_by` string parsing in `tbl_contract_rates_all` |
| P1 | Add FK constraint: `superseding_filename` and `superseded_filename` must exist in `tbl_contract_documents_master` | Orphan edge prevention |
| P1 | Add `confidence >= 0.7` default filter in all application queries | Prevents low-trust inferred edges from polluting results |
| P2 | Create a recursive CTE view `vw_contract_chain` that traverses the full amendment graph per `contract_chain_id` | Simplifies chain-of-custody queries for the agent |
| P2 | Link `supersession_id` to `tbl_contract_rates_all` rate row changes | Closes the disconnect between document-level and rate-level supersession tracking |

---

*Analysis based on schema introspection of `dev_adb.raw.fact_supersession` (2026-07-13). Live data queries not executed.*

---

# Deep Analysis: `tbl_financial_exposure`

**Analyzed**: 2026-07-13 (schema introspection + documentation)
**Analyst lens**: Data Engineer + Financial Analyst

---

## 1. Physical & Storage Profile

| Property | Value | Assessment |
|---|---|---|
| Format | Delta (MANAGED) | Standard |
| Rows | 172 | **Very sparse** - covers only a fraction of providers |
| Columns | 12 | Lean financial schema |
| Created | 2026-07-07 | Phase 4 Data Model addition |
| Application status | **Actively used** | ProvenanceTool (Phase 10B-6 COMPLETE); 4 live API endpoints |

**Coverage gap**: 172 rows for 531+ canonical providers means roughly 32% provider coverage at best. This table cannot support network-wide financial reporting without significant data gap acknowledgment.

---

## 2. Schema Inventory (12 columns)

| Column | Type | Nullable | Notes |
|---|---|---|---|
| `provider_id` | STRING | YES | FK to `dim_provider_canonical` |
| `period_start` | DATE | YES | Exposure period start |
| `period_end` | DATE | YES | Exposure period end |
| `line_of_business` | STRING | YES | Commercial, Medicare, Medi-Cal, etc. |
| `assigned_members` | INT | YES | Member count in the period |
| `inpatient_admits` | INT | YES | Admission count |
| `outpatient_visits` | INT | YES | Outpatient visit count |
| `contracted_spend` | DECIMAL(15,2) | YES | Expected spend at contracted rates |
| `actual_spend` | DECIMAL(15,2) | YES | Actual billed/paid spend |
| `variance_pct` | FLOAT | YES | (actual_spend - contracted_spend) / contracted_spend x 100 |
| `source` | STRING | YES | CLAIMS, ESTIMATE, or BUDGET |
| `estimate_confidence` | STRING | YES | PROXY_PMPM_x12, PROXY_AVG_RATE, or UNKNOWN |

**Positive schema note**: `contracted_spend` and `actual_spend` use `DECIMAL(15,2)` - the only table in this data model using proper decimal precision for monetary values. All other financial columns use `DOUBLE` or `FLOAT` which introduce rounding errors.

**Negative finding**: No composite natural key is defined. Duplicate rows for the same provider-period-LOB combination cannot be detected without a GROUP BY check.

---

## 3. Data Source and Confidence Analysis

| Source type | Meaning | Reliability |
|---|---|---|
| CLAIMS | Actual claims data from adjudication system | High |
| ESTIMATE | Model-estimated spend based on contract terms | Medium |
| BUDGET | Budget/forecast values | Low |

| Confidence type | Meaning | Reliability |
|---|---|---|
| PROXY_PMPM_x12 | Annualized from avg PMPM x assigned_members x 12 | Medium |
| PROXY_AVG_RATE | Estimated from avg rate x estimated utilization | Low |
| UNKNOWN | Derivation method not documented | Very low |

**Implication**: Financial impact figures from `tbl_repricing_scenarios` that draw on this table inherit whatever confidence level the underlying exposure row carries. Most rows are likely ESTIMATE or BUDGET with PROXY_* confidence.

---

## 4. Data Quality Checks

| Check | Assessment | Severity |
|---|---|---|
| Network coverage (172 rows / 531+ providers) | ~32% at best | CRITICAL |
| contracted_spend range ($1M-$282M documented) | Plausible for hospital networks | OK |
| Duplicate provider-period-LOB rows | No dedup constraint - possible double-counting | HIGH |
| No link to tbl_repricing_scenarios | Impact simulations cannot be validated against actual exposure | HIGH |

---

## 5. Critical Query Patterns

**Safe use:**
```sql
SELECT provider_id, period_start, period_end,
       contracted_spend, actual_spend, variance_pct, source
FROM dev_adb.raw.tbl_financial_exposure
WHERE source IN ('CLAIMS', 'ESTIMATE')
  AND estimate_confidence != 'UNKNOWN'
ORDER BY ABS(variance_pct) DESC
```

**Avoid:**
```sql
-- Do NOT sum contracted_spend as total network exposure
-- 172 rows covers <32% of providers - misleading as network total
SELECT SUM(contracted_spend) AS total_network_spend
FROM dev_adb.raw.tbl_financial_exposure
```

---

## 6. Architectural Recommendations

| Priority | Recommendation | Impact |
|---|---|---|
| P0 | Expose in application with explicit coverage caveat | Prevents misleading financial summaries |
| P0 | Add composite uniqueness check on (provider_id, period_start, period_end, line_of_business) | Prevents double-counting |
| P1 | Link to tbl_repricing_scenarios via provider_id to validate impact estimates against actual exposure | Model validation |
| P2 | Expand coverage from 172 to full provider universe using PROXY_PMPM_x12 for providers without claims data | Network reporting |
| P2 | Add NOT NULL on provider_id, period_start, period_end | Integrity |

---

*Analysis based on schema introspection of `dev_adb.raw.tbl_financial_exposure` (2026-07-13). Live data queries not executed.*

---

# Deep Analysis: `tbl_rate_escalators`

**Analyzed**: 2026-07-13 (schema introspection + documentation)
**Analyst lens**: Data Engineer + Contract Finance Specialist

---

## 1. Physical & Storage Profile

| Property | Value | Assessment |
|---|---|---|
| Format | Delta (MANAGED) | Standard |
| Rows | 104 | Very small - escalation coverage is sparse |
| Columns | 13 | Focused schema |
| Created | 2026-07-07 | Phase 3 Data Model addition |
| Application status | **Actively used** | ProvenanceTool (Phase 10B-6 COMPLETE); 4 live API endpoints |
| Top joins | tbl_vs_unified_ready, tbl_genie_provider_profile | Document source + provider enrichment |

**Coverage gap**: 104 rows for 531 canonical providers = 19.6% network coverage. 80%+ of providers have no documented escalation terms.

---

## 2. Schema Inventory (13 columns)

| Column | Type | Nullable | Notes |
|---|---|---|---|
| `escalator_id` | STRING | YES | Logical PK - no uniqueness constraint enforced |
| `provider_id` | STRING | YES | FK to `dim_provider_canonical` |
| `provider_name` | STRING | YES | Denormalized display name |
| `source_filename` | STRING | YES | FK to `tbl_contract_documents_master` |
| `escalator_type` | STRING | YES | CPI, FIXED_PCT, FIXED_AMT, MEDICARE_UPDATE, CUSTOM |
| `base_index` | STRING | YES | Index name (e.g. CPI-U, CPI-W, Medical CPI) - free text, not normalized |
| `adjustment_pct` | FLOAT | YES | The actual escalation percentage |
| `floor_pct` | FLOAT | YES | Minimum escalation floor |
| `cap_pct` | FLOAT | YES | Maximum escalation cap - financially most critical column |
| `frequency` | STRING | YES | ANNUAL, SEMI_ANNUAL, ON_AMENDMENT, OTHER |
| `amendment_order` | INT | YES | Correctly typed as INT (unlike tbl_contract_rates_all where stored as STRING) |
| `formula_text` | STRING | YES | Full escalation formula text - up to 2,000 characters |
| `created_at` | TIMESTAMP | YES | Row creation timestamp |

**Critical schema note**: `amendment_order` is correctly typed as INT in this table. `tbl_contract_rates_all` stores the equivalent field as STRING, requiring TRY_CAST in every query. Cross-table analysis comparing amendment position must account for this type difference.

**Financial criticality of cap_pct**: Each 1% increase in cap_pct, multiplied by contracted_spend for that provider, represents the maximum additional annual exposure from escalation. For a $100M provider, a cap of 5% vs 3% is a $2M annual exposure ceiling difference.

---

## 3. Escalator Type Distribution (Estimated)

| escalator_type | Expected Prevalence | Notes |
|---|---|---|
| CPI | High | Most common - tied to Consumer Price Index variants |
| FIXED_PCT | Medium | Fixed annual percentage increase |
| FIXED_AMT | Low | Fixed dollar amount increase |
| MEDICARE_UPDATE | Low | Tied to Medicare fee schedule updates |
| CUSTOM | Low | Formulaic but non-standard - formula_text required |

**Phase 3 extraction limitation**: Only providers whose contracts contained clear CPI or FIXED regex pattern matches were captured. Providers with narrative escalation clauses were not captured, meaning CUSTOM type is undercounted.

---

## 4. Data Quality Checks

| Check | Assessment | Severity |
|---|---|---|
| Network coverage (104 rows / 531 providers) | 19.6% - extreme gap | CRITICAL |
| base_index normalization | Free text - CPI-U, CPI, Consumer Price Index all same concept | HIGH |
| cap_pct = NULL | Some contracts have no explicit cap | MEDIUM |
| floor_pct > cap_pct | Logic error - floor above cap is impossible | LOW |
| Missing CUSTOM formula_text | CUSTOM type rows with NULL formula_text are uninterpretable | HIGH |
| No link to tbl_contract_rates_all | Cannot compute escalation impact on specific rate rows | HIGH |

---

## 5. Critical Query Patterns

**Highest-risk escalators:**
```sql
SELECT e.provider_id, e.provider_name, e.escalator_type,
       e.adjustment_pct, e.cap_pct, e.frequency, e.base_index
FROM dev_adb.raw.tbl_rate_escalators e
WHERE e.cap_pct IS NOT NULL
ORDER BY e.cap_pct DESC
LIMIT 20
```

**Impact sizing join:**
```sql
SELECT e.provider_id, e.escalator_type, e.cap_pct,
       f.contracted_spend,
       f.contracted_spend * (e.cap_pct / 100) AS max_annual_exposure_increase
FROM dev_adb.raw.tbl_rate_escalators e
JOIN dev_adb.raw.tbl_financial_exposure f ON f.provider_id = e.provider_id
WHERE e.cap_pct IS NOT NULL AND f.source IN ('CLAIMS', 'ESTIMATE')
ORDER BY max_annual_exposure_increase DESC
```

**Note**: amendment_order is already INT here - do NOT use TRY_CAST (unlike tbl_contract_rates_all).

---

## 6. Architectural Recommendations

| Priority | Recommendation | Impact |
|---|---|---|
| P0 | Expose via ContractEscalation tool - 0 code references despite high financial value | Enables annual budget planning and renegotiation targeting |
| P0 | Join with tbl_financial_exposure on provider_id to compute max annual exposure increase | Quantifies risk in dollars not just percentages |
| P1 | Normalize base_index vocabulary - create lookup mapping CPI-U, CPI, Consumer Price Index to canonical values | Enables CPI-type filtering and aggregation |
| P1 | Expand extraction coverage from 104 to full provider universe by adding narrative escalation pattern matching | Reduces the 80% blind spot |
| P2 | Add NOT NULL on provider_id, escalator_type, adjustment_pct | Integrity |
| P2 | Add validation: floor_pct <= cap_pct, adjustment_pct <= cap_pct | Logic error prevention |

---

*Analysis based on schema introspection of `dev_adb.raw.tbl_rate_escalators` (2026-07-13). Live data queries not executed.*

---

# Deep Analysis: `tbl_vs_unified_ready`

**Analyzed**: 2026-07-13 (schema introspection + documentation)
**Analyst lens**: Data Engineer + Search/Retrieval Specialist

---

## 1. Physical & Storage Profile

| Property | Value | Assessment |
|---|---|---|
| Format | Delta (MANAGED) | Standard |
| Rows | 727,876 | Largest table by row count |
| Columns | ~10 | Vector + text corpus |
| Application status | **Actively used** | Powers all NL retrieval (VectorSearch, ClauseVerification) |
| is_current flag | BOOLEAN | Filters to active document versions only |

**Architectural role**: This is the PRIMARY data source for every natural-language query. The agent's vector search pipeline reads this table first, retrieves top-N chunks by embedding similarity, and passes them to the LLM as context. Without this table, all clause verification and NL answer generation would fail.

---

## 2. Schema Key Columns

| Column | Type | Notes |
|---|---|---|
| `chunk_id` | STRING | Logical PK per chunk |
| `source_filename` | STRING | FK to `tbl_contract_documents_master` |
| `provider_id` | STRING | Provider for direct provider-scoped retrieval |
| `chunk_text` | STRING | OCR-extracted text, ~512-4000 chars per chunk |
| `embedding` | ARRAY<FLOAT> | Dense vector for similarity search |
| `chunk_sequence` | INT | Position within document |
| `is_current` | BOOLEAN | TRUE = latest document version; FALSE = superseded |
| `created_at` | TIMESTAMP | Ingestion timestamp |

**Critical filter**: Always filter `WHERE is_current = true` in production queries. Without this filter, a query may retrieve contradicted clauses from superseded document versions. The 727,875 rows include both current and historical chunks.

---

## 3. Data Quality Checks

| Check | Assessment | Severity |
|---|---|---|
| is_current = false rows (superseded) | Unknown count - but significant portion given 70% superseded rate in rates table | HIGH - must filter |
| chunk_text NULL | Should be rare - ingestion pipeline validates | LOW |
| embedding NULL | Breaks vector search silently | CRITICAL |
| provider_id NULL | Possible for documents ingested before provider resolution | MEDIUM |
| Orphan chunks (source_filename not in docs master) | Possible if docs were deleted post-ingestion | MEDIUM |

---

## 4. Critical Query Patterns

**Standard clause retrieval:**
```sql
SELECT chunk_text, source_filename, chunk_sequence
FROM dev_adb.raw.tbl_vs_unified_ready
WHERE provider_id = '<id>'
  AND is_current = true
  AND LOWER(chunk_text) LIKE '%offset%'
ORDER BY chunk_sequence
LIMIT 20
```

**Avoid:**
```sql
-- Always include is_current = true - superseded chunks pollute results
SELECT * FROM tbl_vs_unified_ready WHERE provider_id = '<id>'
```

---

## 5. Architectural Recommendations

| Priority | Recommendation | Impact |
|---|---|---|
| P0 | Validate that all embeddings are non-NULL - NULL embeddings silently break vector search | Search reliability |
| P1 | Add vector index (VSS endpoint) if not already present - cosine similarity scan on 727K rows is expensive | Query latency |
| P1 | Periodically vacuum old is_current=false chunks for providers with many amendment cycles | Storage and scan efficiency |
| P2 | Add chunk_word_count INT column - enables filtering by chunk size for retrieval quality tuning | Retrieval quality |

---

*Analysis based on schema introspection of `dev_adb.raw.tbl_vs_unified_ready` (2026-07-13). Live data queries not executed.*

---

# Deep Analysis: `tbl_contract_documents_master`

**Analyzed**: 2026-07-13 (schema introspection + documentation)
**Analyst lens**: Data Engineer + Document Management Specialist

---

## 1. Physical & Storage Profile

| Property | Value | Assessment |
|---|---|---|
| Format | Delta (MANAGED) | Standard |
| Rows | 10,349 | All documents across all providers and versions |
| Columns | ~14 | Core document registry |
| Application status | **Actively used** | Read by DocLookup, ProviderDeepDive tools |

---

## 2. Schema Key Columns

| Column | Type | Notes |
|---|---|---|
| `doc_id` | STRING | Surrogate PK |
| `source_filename` | STRING | Natural key - used for all cross-table joins |
| `provider_id` | STRING | FK to `dim_provider_canonical` |
| `document_type` | STRING | BASE, AMENDMENT_1, AMENDMENT_2, EXHIBIT, SIDE_LETTER, etc. |
| `contract_status` | STRING | ACTIVE, EXPIRED, ACTIVE_NO_EXPIRY, UNKNOWN, FUTURE |
| `effective_date` | DATE | When contract took effect |
| `expiration_date_parsed` | DATE | Parsed expiration - may be NULL |
| `payment_type` | STRING | FFS, Capitation, Per Diem, Case Rate |
| `line_of_business` | STRING | Commercial, Medicare, Medi-Cal |
| `delegated_activities` | STRING | Pipe-delimited list of delegated functions |
| `extraction_date` | TIMESTAMP | When OCR extraction was run |

---

## 3. Contract Status Distribution

| Status | Count | Notes |
|---|---|---|
| EXPIRED | 9,349 | Largest segment - historical contracts (Phase 8 reclassification complete) |
| ACTIVE | 554 | Confirmed active with expiration date |
| ACTIVE_NO_EXPIRY | 444 | No explicit expiration date found |
| FUTURE | 2 | Future-dated contracts |
| UNKNOWN | 0 | Fully resolved in Phase 8 via 5-step reclassification |

**Key insight**: 554 documents are confirmed ACTIVE with a known expiration date. 444 are ACTIVE_NO_EXPIRY — contracts where no expiration date was extractable from OCR. 0 UNKNOWN (fully resolved in Phase 8). The B-1 fix in Phase 2 reduced NULL expiration_date_parsed rows but could not eliminate them fully (DEBT P3-D1).

---

## 4. Data Quality Checks

| Check | Assessment | Severity |
|---|---|---|
| NULL expiration_date_parsed | Remaining after Phase 2 B-1 fix - P3-D1 DEBT | MEDIUM |
| UNKNOWN contract_status | 0 rows (Phase 8 remediation complete) | CLOSED |
| document_type vocabulary size | High cardinality - should be standardized | LOW |
| NULL provider_id | Should be 0 after Phase 1 work | MEDIUM |
| Orphan docs (provider_id not in dim_provider_canonical) | R-03 check showed non-zero in Phase 3 | HIGH |

---

## 5. Critical Query Patterns

**Active contracts only:**
```sql
SELECT source_filename, provider_id, payment_type,
       effective_date, expiration_date_parsed, contract_status
FROM dev_adb.raw.tbl_contract_documents_master
WHERE contract_status IN ('ACTIVE', 'ACTIVE_NO_EXPIRY')
  AND provider_id = '<id>'
ORDER BY effective_date DESC
```

**Avoid:**
```sql
-- Do NOT filter on contract_status = 'ACTIVE' alone
-- 4,214 active contracts have ACTIVE_NO_EXPIRY status
-- Use IN ('ACTIVE', 'ACTIVE_NO_EXPIRY') for complete active set
```

---

## 6. Architectural Recommendations

| Priority | Recommendation | Impact |
|---|---|---|
| P0 | Resolve 238 UNKNOWN status rows - attempt expiration date extraction from VS chunks | Data completeness |
| P1 | Standardize document_type vocabulary to ~15 canonical values (BASE, AMENDMENT_N, EXHIBIT, SIDE_LETTER, etc.) | Enables document-type filtering in queries |
| P1 | Add is_base_document BOOLEAN column - simplifies chain traversal queries | Query simplification |
| P2 | Add amendment_order INT column derived from document_type sequence | Cross-table consistency |

---

*Analysis based on schema introspection of `dev_adb.raw.tbl_contract_documents_master` (2026-07-13). Live data queries not executed.*

---

# Deep Analysis: `tbl_contract_hierarchy`

**Analyzed**: 2026-07-13 (schema introspection + documentation)
**Analyst lens**: Data Engineer + Amendment Chain Specialist

---

## 1. Physical & Storage Profile

| Property | Value | Assessment |
|---|---|---|
| Format | Delta (MANAGED) | Standard |
| Rows | 10,349 | 1:1 with tbl_contract_documents_master |
| Application status | **Passively available** | In SQL whitelist, no dedicated tool |
| Created | Phase 3 Task 3.1 | 100% coverage on first creation |

---

## 2. Schema Key Columns

| Column | Type | Notes |
|---|---|---|
| `contract_id` | STRING | Surrogate PK (NOT `hierarchy_id` — that column does not exist) |
| `provider_id` | STRING | Provider FK |
| `source_filename` | STRING | FK to `tbl_contract_documents_master` — primary join key |
| `document_type` | STRING | Matches docs master |
| `sequential_order` | INT | Amendment chain position (Phase 7 redesign) |
| `parent_contract_id` | STRING | FK to parent document in the chain (NULL for base docs) |
| `contract_level` | STRING | Chain depth level |
| `line_of_business` | STRING | LOB from contract |
| `effective_date` | DATE | Contract effective date |
| `expiration_date` | DATE | Contract expiration date |
| `contract_status` | STRING | ACTIVE / EXPIRED / ACTIVE_NO_EXPIRY / UNKNOWN / FUTURE |

**CRITICAL WARNING**: This table does NOT have an `amendment_order` column (confirmed by live query 2026-07-13 and 2026-07-20). Any query referencing `tbl_contract_hierarchy.amendment_order` will fail. Use `sequential_order` for chain position. Note: `parent_contract_id` is the correct FK column (NOT `parent_filename` or `parent_document_id`).

**Phase 6 backfill**: 550 NULL `sequential_order` rows were backfilled by parsing the `_vN` suffix in filenames. However, the Phase 6 post-mortem identified that `_vN` represents DOCUMENT REVISION not AMENDMENT POSITION. This means `sequential_order` may reflect revision order (within a single amendment's editing cycle) rather than true amendment chronological order. The broken_chain_providers metric was 47.84% as of Phase 6 completion; re-validated at 35.53% (135/380 providers) as of 2026-07-13 live query (see Section D verdict). Phase 7 redesign target is ≤10%.

---

## 3. Relationship to Other Tables

This table is the **amendment chain position registry** - complementary to:
- `tbl_contract_documents_master` (same source_filename, adds contract_status/dates)
- `fact_supersession` (same chain, adds rate-level supersession details)
- `tbl_genie_amendment_timeline` (same chain, adds rate counts and change summaries)

For full amendment chain reconstruction, a 3-way JOIN is needed:
```sql
SELECT h.source_filename, h.sequential_order,
       d.contract_status, d.expiration_date_parsed,
       t.rate_count, t.summary_of_changes
FROM dev_adb.raw.tbl_contract_hierarchy h
JOIN dev_adb.raw.tbl_contract_documents_master d
  ON d.source_filename = h.source_filename
JOIN dev_adb.raw.tbl_genie_amendment_timeline t
  ON t.source_filename = h.source_filename
WHERE h.provider_id = '<id>'
ORDER BY h.sequential_order
```

---

## 4. Architectural Recommendations

| Priority | Recommendation | Impact |
|---|---|---|
| P0 | Document the sequential_order semantics: is it revision order or amendment order? Phase 7 priority: redesign broken_chain parser | Chain integrity |
| P1 | Expose via AmendmentChain tool - currently passively available only | Enables "show me the amendment history" queries |
| P1 | Add is_base_document BOOLEAN - the first document in each chain (sequential_order = 1) | Simplifies chain traversal entry point |
| P2 | Add previous_filename and next_filename columns - pre-computed chain navigation | Avoids self-join for chain traversal |

---

*Analysis based on schema introspection of `dev_adb.raw.tbl_contract_hierarchy` (2026-07-13). Live data queries not executed.*

---

# Deep Analysis: `tbl_genie_amendment_timeline`

**Analyzed**: 2026-07-13 (schema introspection + documentation)
**Analyst lens**: Data Engineer + Contract History Specialist

---

## 1. Physical & Storage Profile

| Property | Value | Assessment |
|---|---|---|
| Format | Delta (MANAGED) | Standard |
| Rows | 6,609 | Covers most but not all documents |
| Application status | **Actively used** | Used by TemporalAnalysis, ProviderDeepDive tools |

**Coverage note**: 6,609 rows vs 10,349 documents means ~36% of documents lack timeline entries. This may be intentional (only amendment documents get timeline entries, not base agreements).

---

## 2. Schema Key Columns

| Column | Type | Notes |
|---|---|---|
| `timeline_id` | STRING | Surrogate PK |
| `source_filename` | STRING | FK to `tbl_contract_documents_master` |
| `provider_id` | STRING | Provider FK |
| `amendment_date` | DATE | When the amendment was executed |
| `amendment_type` | STRING | RATE_CHANGE, TERM_CHANGE, EXHIBIT_UPDATE, etc. |
| `rate_count` | INT | Number of rate rows in this amendment |
| `effective_date` | DATE | When the amendment terms take effect |
| `summary_of_changes` | STRING | LLM-generated or rule-based summary |
| `created_at` | TIMESTAMP | Row creation timestamp |

---

## 3. Business Value Assessment

This is one of the most directly business-valuable tables in the schema. The `summary_of_changes` field answers the question "what changed in this amendment?" without requiring a full document read. The `rate_count` field answers "how significant was this amendment in terms of rate coverage?"

The TemporalAnalysis tool uses this table to build amendment timelines for provider queries. The ProviderDeepDive tool uses it to provide context on how a provider's contract evolved over time.

---

## 4. Data Quality Checks

| Check | Assessment | Severity |
|---|---|---|
| Missing 36% of documents (6,609 vs 10,349) | Expected if only amendments tracked, but verify | MEDIUM |
| summary_of_changes NULL or generic | LLM extraction quality varies | MEDIUM |
| amendment_date vs effective_date gap | Some amendments have long lead times | LOW |
| rate_count = 0 on RATE_CHANGE type | Logic error | MEDIUM |

---

## 5. Critical Query Patterns

**Provider amendment history:**
```sql
SELECT source_filename, amendment_date, amendment_type,
       rate_count, summary_of_changes
FROM dev_adb.raw.tbl_genie_amendment_timeline
WHERE provider_id = '<id>'
ORDER BY amendment_date ASC
```

---

## 6. Architectural Recommendations

| Priority | Recommendation | Impact |
|---|---|---|
| P0 | Investigate 36% document gap - confirm whether base agreements are intentionally excluded or missing | Coverage validation |
| P1 | Standardize amendment_type vocabulary - if free text, many values may overlap semantically | Filtering reliability |
| P1 | Add amendment_order INT column - enables JOIN to tbl_contract_hierarchy on sequential_order | Cross-table chain reconstruction |
| P2 | Add rate_delta_count INT (rates added minus rates removed) - more informative than raw rate_count | Business analytics |

---

*Analysis based on schema introspection of `dev_adb.raw.tbl_genie_amendment_timeline` (2026-07-13). Live data queries not executed.*

---

# Deep Analysis: `tbl_contract_clauses`

**Analyzed**: 2026-07-13 (schema introspection + documentation)
**Analyst lens**: Data Engineer + Legal/Clause Intelligence Specialist

---

## 1. Physical & Storage Profile

| Property | Value | Assessment |
|---|---|---|
| Format | Delta (MANAGED) | Standard |
| Rows | 7,863 | 21 clause categories x 477 providers with >=10 categories |
| Application status | **Actively used** | ClauseTextTool (Phase 10B-5 COMPLETE) reads clause_text directly; is_current filter supported |
| Created / expanded | Phase 4 Task 4.4 | Originally 5 categories, expanded to 21 |

**Critical gap**: The `clause_text` column - containing actual full-text clause language - is completely unused by the current application. The ClauseExistence tool answers "does provider X have an offset clause?" by reading `tbl_genie_provider_profile.offset_clause_status` (a flag), not by querying this table. The actual clause text is never retrieved, never surfaced to users, and never passed to the LLM.

---

## 2. Schema Key Columns

| Column | Type | Notes |
|---|---|---|
| `clause_id` | STRING | Surrogate PK |
| `provider_id` | STRING | FK to `dim_provider_canonical` |
| `source_filename` | STRING | FK to `tbl_contract_documents_master` |
| `clause_category` | STRING | 21 categories (see below) |
| `clause_status` | STRING | HAS or FALSE_POSITIVE (ABSENT/MODIFIED were designed but not produced by extraction pipeline) |
| `clause_text` | STRING | Full extracted clause text - up to several paragraphs |
| `created_at` | TIMESTAMP | Row creation timestamp |

**21 clause categories (live-verified 2026-07-20)**: ASSIGNMENT_PROHIBITION (486), AUDIT_RIGHTS (446), AUTO_RENEWAL (143), CLAIM_SUBMISSION (216), COB (487), CONFIDENTIALITY_HIPAA (492), CONTINUITY_OF_CARE (411), CREDENTIALING_REQUIREMENTS (187), DISPUTE_RESOLUTION (498), EMERGENCY_CARE (488), GRIEVANCE_APPEALS (496), INDEMNIFICATION_LIABILITY (425), INSURANCE_REQUIREMENTS (477), LANGUAGE_ACCESS (433), NETWORK_ADEQUACY (69), OFFSET_CLAUSE (86), QUALITY_REPORTING (449), RECORDS_RETENTION (493), TELEHEALTH (116), TERMINATION_PROVISIONS (468), UM_PRIOR_AUTH (497)

---

## 3. Business Value Assessment

This table contains the HIGHEST value unextracted insight in the entire schema. Answers to questions like "what exactly does Provider X's offset clause say?", "show me the termination provisions across all Dignity Health contracts", and "which providers have auto-renewal clauses expiring in 2025?" are all directly answerable from `clause_text` but currently inaccessible to users.

Phase 10B-5 COMPLETE: ClauseTextTool is now deployed and reads `clause_text` directly from this table.

---

## 4. Data Quality Checks

| Check | Assessment | Severity |
|---|---|---|
| clause_text NULL on HAS status rows | Logic error - HAS without text is a gap | HIGH |
| clause_category vocabulary drift | 21 categories but extraction regex may produce variants | MEDIUM |
| clause_status = ABSENT rows | ABSENT does NOT exist in live data (0 rows). Only HAS (7,849) and FALSE_POSITIVE (14). | RESOLVED |
| Provider-category completeness | 477/531 providers have >=10 categories; 54 thin-coverage providers | MEDIUM |

---

## 5. Critical Query Patterns

**Retrieve actual clause text:**
```sql
SELECT provider_id, clause_category, clause_status, clause_text
FROM dev_adb.raw.tbl_contract_clauses
WHERE provider_id = '<id>'
  AND clause_category = 'OFFSET_CLAUSE'
  AND clause_status = 'HAS'
ORDER BY source_filename
```

**Network-level clause coverage:**
```sql
SELECT clause_category,
       SUM(CASE WHEN clause_status = 'HAS' THEN 1 ELSE 0 END) AS has_count,
       COUNT(DISTINCT provider_id) AS provider_count
FROM dev_adb.raw.tbl_contract_clauses
GROUP BY clause_category
ORDER BY has_count DESC
```

---

## 6. Architectural Recommendations

| Priority | Recommendation | Impact |
|---|---|---|
| P0 | Expose clause_text via Phase 10B Cluster E tool - highest untapped business value in schema | Enables actual clause reading, comparison, and analysis |
| P1 | Validate clause_text is non-NULL for all clause_status = 'HAS' rows | Data completeness |
| P1 | Add amendment_date FK to enable "which clause version is current?" queries | Temporal clause tracking |
| P2 | Add clause_page_number INT - enables direct PDF deep-link from clause results | User experience |

---

*Analysis based on schema introspection of `dev_adb.raw.tbl_contract_clauses` (2026-07-13). Live data queries not executed.*

---

# Deep Analysis: `tbl_clause_deviations`

**Analyzed**: 2026-07-13 (schema introspection + documentation)
**Analyst lens**: Data Engineer + Conformance Analysis Specialist

---

## 1. Physical & Storage Profile

| Property | Value | Assessment |
|---|---|---|
| Format | Delta (MANAGED) | Standard |
| Rows | 7,777 | Mirrors tbl_contract_clauses row count |
| Application status | **Actively used** | ProvenanceTool (Phase 10B-6 COMPLETE); 4 live API endpoints |

---

## 2. Schema Key Columns

| Column | Type | Notes |
|---|---|---|
| `deviation_id` | STRING | Surrogate PK |
| `clause_category` | STRING | Maps to tbl_contract_clauses categories |
| `network_has_pct` | FLOAT | % of network providers that have this clause |
| `network_absent_pct` | FLOAT | % of network providers missing this clause |
| `conformance_status` | STRING | All rows are currently CONFORMANT or NONE |

**CRITICAL DATA STATE**: All 7,777 rows currently have `conformance_status = CONFORMANT` or `NONE`. There is NO actual deviation data in this table. The table was created to hold network-level conformance deviation tracking ("Provider X has this clause but the network standard doesn't") but the deviation detection logic was never implemented.

**Also critical**: This table has NO `baseline_text` column and NO `actual_text` column. Deviation highlighting (showing redline differences between a provider's clause and the network standard) is NOT feasible with the current schema. The Phase 10B plan notes this limitation explicitly.

---

## 3. Business Intent vs Reality

| Intended purpose | Actual state |
|---|---|
| Track which providers deviate from network-standard clause language | All rows CONFORMANT/NONE - no deviations tracked |
| Show red/green diff between provider clause and standard | No baseline_text or actual_text columns |
| Score clause risk per provider | No risk scoring implemented |

**Implication for Phase 10B**: This table can provide `network_has_pct` as a supplementary metric ("X% of providers have this clause") but cannot support any deviation-highlighting or comparison feature without schema extension.

---

## 4. Architectural Recommendations

| Priority | Recommendation | Impact |
|---|---|---|
| P1 | Use network_has_pct / network_absent_pct as supplementary stats in clause queries - these ARE meaningful even without deviation data | Immediate value from existing columns |
| P2 | Add baseline_text STRING and actual_text STRING columns - required for any deviation comparison feature | Schema prerequisite for deviation analysis |
| P2 | Implement deviation detection: compare each provider's clause_text to the modal clause_text for that category across the network | Unlocks true conformance scoring |
| P3 | Rename to tbl_clause_network_stats to better reflect current actual content | Naming accuracy |

---

*Analysis based on schema introspection of `dev_adb.raw.tbl_clause_deviations` (2026-07-13). Live data queries not executed.*

---

# Deep Analysis: `tbl_provider_identifiers`

**Analyzed**: 2026-07-13 (schema introspection + documentation)
**Analyst lens**: Data Engineer + Provider Identity Specialist

---

## 1. Physical & Storage Profile

| Property | Value | Assessment |
|---|---|---|
| Format | Delta (MANAGED) | Standard |
| Rows | 50,159 | Largest provider table |
| Application status | **Passively available** | In whitelist, no dedicated tool |

**Purpose**: This is the CLAIMS-LEVEL identifier registry. Each provider may have multiple rows covering NPI, TIN, MEDICARE_ID, MEDI_CAL_ID, and CCN identifiers. This table is the bridge between contract-world (provider_id) and claims-world (NPI/TIN lookups).

---

## 2. Schema Key Columns

| Column | Type | Notes |
|---|---|---|
| `identifier_id` | STRING | Surrogate PK |
| `provider_id` | STRING | FK to `dim_provider_canonical` |
| `identifier_type` | STRING | NPI, TIN, MEDICARE_ID, MEDI_CAL_ID, CCN |
| `identifier_value` | STRING | The actual identifier value |
| `identifier_format` | STRING | NPI = 10 digits, TIN = 9 digits (EIN format) |
| `is_primary` | BOOLEAN | Primary identifier for this type |
| `source_system` | STRING | Which system provided this identifier |

---

## 3. Coverage by Identifier Type

| Type | Format | Business Use |
|---|---|---|
| NPI | 10 digits | CMS national provider identifier - for Medicare/Medicaid claims |
| TIN | 9 digits (EIN) | Tax ID - for commercial claims and 835 remittance matching |
| MEDICARE_ID | Variable | CMS certification number for Medicare |
| MEDI_CAL_ID | Variable | California Medicaid provider ID |
| CCN | 6 digits | CMS Certification Number - for hospital-level identification |

---

## 4. Architectural Recommendations

| Priority | Recommendation | Impact |
|---|---|---|
| P1 | Expose via provider lookup tool - NPI/TIN search is a common operational need | Claims-to-contract cross-reference |
| P1 | Add validation: NPI must be exactly 10 digits, TIN must be 9 digits | Data quality |
| P2 | Add effective_date and expiration_date per identifier - identifiers change over time | Temporal accuracy |

---

*Analysis based on schema introspection of `dev_adb.raw.tbl_provider_identifiers` (2026-07-13). Live data queries not executed.*

---

# Deep Analysis: `dim_provider_canonical`

**Analyzed**: 2026-07-13 (schema introspection + documentation)
**Analyst lens**: Data Engineer + Master Data Management Specialist

---

## 1. Physical & Storage Profile

| Property | Value | Assessment |
|---|---|---|
| Format | Delta (MANAGED) | Standard |
| Rows | 531 | Every canonical provider in the network |
| Application status | **Actively used** | Master JOIN key across all 35 tables |

**Architectural role**: This is THE identity anchor for the entire data model. Every table that has a `provider_id` column should be joinable to this table. The 531 rows represent the authoritative set of unique providers in BSC's contracted network.

---

## 2. Schema Key Columns

| Column | Type | Notes |
|---|---|---|
| `provider_id` | STRING | Primary key - used as FK across all 35 tables |
| `canonical_name` | STRING | Authoritative display name |
| `is_primary_id` | BOOLEAN | Whether this is the primary identifier (vs. alias) |
| `all_names_used` | ARRAY<STRING> | All historical/alternative names for this provider |
| `provider_type` | STRING | HOSPITAL, PHYSICIAN_GROUP, IPA, etc. |
| `created_at` | TIMESTAMP | When this canonical identity was established |

---

## 3. Coverage vs Other Tables

| Table | Rows using provider_id | Match rate |
|---|---|---|
| tbl_contract_rates_all (canonical_provider_id) | 300 distinct | 300/531 = 56.5% |
| tbl_genie_provider_profile | 306 | 306/531 = 57.6% |
| tbl_contract_documents_master | ~305 estimated | ~57% |
| tbl_service_areas | 306 | 57.6% |

**Key insight**: Only ~57% of canonical providers have rate data in `tbl_contract_rates_all`. The remaining 231 may be IPA-only, capitation-only without line-item rates, or inactive providers retained for historical audit purposes.

---

## 4. Architectural Recommendations

| Priority | Recommendation | Impact |
|---|---|---|
| P0 | Validate all 35 tables have provider_id FKs that resolve to this table | Orphan detection |
| P1 | Expose all_names_used in provider search - users often search by aliases | Search accuracy |
| P1 | Add is_active BOOLEAN - 531 includes inactive/historical providers | Filter correctness |

---

*Analysis based on schema introspection of `dev_adb.raw.dim_provider_canonical` (2026-07-13). Live data queries not executed.*

---

# Deep Analysis: `tbl_genie_provider_profile`

**Analyzed**: 2026-07-13 (schema introspection + documentation)
**Analyst lens**: Data Engineer + Provider Analytics Specialist

---

## 1. Physical & Storage Profile

| Property | Value | Assessment |
|---|---|---|
| Format | Delta (MANAGED) | Standard |
| Rows | 306 | Active provider subset of dim_provider_canonical (531) |
| Application status | **Actively used** | Provider search, ProviderDeepDive, ReportPage |

---

## 2. Schema Key Columns

| Column | Type | Notes |
|---|---|---|
| `provider_id` | STRING | FK to dim_provider_canonical |
| `provider_name` | STRING | Display name |
| `payment_type_normalized` | STRING | FFS, Capitation, Per Diem, Case Rate, Mixed |
| `lob_normalized` | STRING | Commercial, Medicare, Medicare Advantage, Medi-Cal |
| `total_rates` | INT | Total rate rows in tbl_contract_rates_all |
| `current_rates` | INT | Current (non-superseded) rate rows |
| `is_active` | BOOLEAN | Whether provider is on active contract |
| `offset_clause_status` | STRING | HAS, NO_MENTION, DENIED |
| `dofr_status` | STRING | HAS, NO_MENTION, DENIED |
| `ipa_delegation_status` | STRING | HAS, NO_MENTION, DENIED |
| `bonus_pct` | FLOAT | P4P bonus percentage - NULL on prose contracts |

---

## 3. Key Data Quality Issues

| Issue | Status | Severity |
|---|---|---|
| total_rates / current_rates drift | Fixed in Phase 1 Fix Batch 6 - CLOSED | - |
| lob_normalized = 'Medicare' ambiguity | Phase 3 B-3 DEBT - reclassification candidates computed but not applied | MEDIUM |
| payment_type_normalized inconsistencies | Phase 3 B-4 DEBT - rate-unit evidence collected but not applied | MEDIUM |
| offset_clause_status flag mismatches | Phase 3 B-5 DEBT - some HAS flags with 0 clauses and vice versa | MEDIUM |
| bonus_pct NULL on P4P/VALUE_BASED rows | Phase 2-H DEBT - 22 NULL rows, VS extraction yields 0 candidates | MEDIUM |

---

## 4. Critical Query Patterns

```sql
-- Safe: join to rates for a complete picture
SELECT p.provider_id, p.provider_name, p.payment_type_normalized,
       p.current_rates, p.is_active
FROM dev_adb.raw.tbl_genie_provider_profile p
WHERE p.is_active = true
ORDER BY p.current_rates DESC
```

---

## 5. Architectural Recommendations

| Priority | Recommendation | Impact |
|---|---|---|
| P0 | Resolve 5 DEBT items (B-3, B-4, B-5, P2-H) - multiple flag inconsistencies outstanding | Data trust |
| P1 | Expand from 306 to 531 rows (add inactive providers) with is_active=false | Complete network view |
| P1 | Add last_contract_date DATE - when the most recent contract was executed | Staleness detection |

---

*Analysis based on schema introspection of `dev_adb.raw.tbl_genie_provider_profile` (2026-07-13). Live data queries not executed.*

---

# Deep Analysis: `tbl_service_areas`

**Analyzed**: 2026-07-13 (schema introspection + documentation)
**Analyst lens**: Data Engineer + Geographic Analysis Specialist

---

## 1. Physical & Storage Profile

| Property | Value | Assessment |
|---|---|---|
| Format | Delta (MANAGED) | Standard |
| Rows | 306 | 1:1 with tbl_genie_provider_profile |
| Application status | **Passively available** | In whitelist, no dedicated tool |

---

## 2. Schema Key Columns

| Column | Type | Notes |
|---|---|---|
| `service_area_id` | STRING | Surrogate PK |
| `provider_id` | STRING | FK to dim_provider_canonical |
| `region` | STRING | Geographic region name - **NOT service_area_name** |
| `county` | STRING | County name (NULL for Statewide providers) — NOT an array, NOT `counties` |
| `assignment_method` | STRING | NAME_KEYWORD / HEALTH_SYSTEM / PROVIDER_TYPE / DEFAULT |

**CRITICAL WARNING**: The column is named `region`, NOT `service_area_name`. `coverage_type` and `counties` do NOT exist — use `county` (STRING, singular) and `assignment_method`. Any query referencing `service_area_name`, `coverage_type`, or `counties` will fail with UNRESOLVED_COLUMN.

---

## 3. Coverage Distribution

| region | Approx % | Notes |
|---|---|---|
| Statewide | ~61% | No geographic restriction (`coverage_type` column does NOT exist — use `region`) |
| Northern CA / Bay Area / Southern CA / etc. | ~30% | Specific regions |
| Unknown | ~9% | Unassigned region |

---

## 4. Architectural Recommendations

| Priority | Recommendation | Impact |
|---|---|---|
| P1 | Add to provider detail view in the application - geographic scope is a key contract attribute | User-facing value |
| P1 | Normalize counties to a controlled county vocabulary | Geographic filtering |
| P2 | Add geometry/GIS column for map visualization | Network coverage maps |

---

*Analysis based on schema introspection of `dev_adb.raw.tbl_service_areas` (2026-07-13). Live data queries not executed.*

---

# Deep Analysis: `tbl_provider_system_membership`

**Analyzed**: 2026-07-13 (schema introspection + documentation)
**Analyst lens**: Data Engineer + Health System Analytics Specialist

---

## 1. Physical & Storage Profile

| Property | Value | Assessment |
|---|---|---|
| Format | Delta (MANAGED) | Standard |
| Rows | 112 | 112 providers mapped to health systems |
| Application status | **Actively used** | ProvenanceTool (Phase 10B-6 COMPLETE); 4 live API endpoints |

**Coverage**: 112 of 304 canonical providers = 36.8% mapped. Kaiser = 0 (expected - closed panel). The 24% figure from the task summary reflects 73/304 providers, but row count 112 suggests multiple rows per provider (e.g., a provider belonging to multiple systems).

---

## 2. Schema Key Columns

| Column | Type | Notes |
|---|---|---|
| `membership_id` | STRING | Surrogate PK |
| `provider_id` | STRING | FK to dim_provider_canonical |
| `system_id` | STRING | FK to dim_health_system - NOTE: use system_id NOT health_system_id |
| `membership_type` | STRING | MEMBER, AFFILIATE, OWNED |
| `effective_date` | DATE | When membership was established |

**CRITICAL JOIN NOTE**: The FK to `dim_health_system` uses `system_id` (NOT `health_system_id`). This was confirmed in Phase 3 Task 3.4 - using the wrong column name causes a silent NULL join.

---

## 3. Architectural Recommendations

| Priority | Recommendation | Impact |
|---|---|---|
| P1 | Expose in application - system-level contract negotiation questions require this join | "Show all Dignity Health contracts" requires this table |
| P1 | Expand mapping coverage from 73/304 to full network | More complete system-level analytics |

---

*Analysis based on schema introspection of `dev_adb.raw.tbl_provider_system_membership` (2026-07-13). Live data queries not executed.*

---

# Deep Analysis: `dim_health_system`

**Analyzed**: 2026-07-13 (schema introspection + documentation)
**Analyst lens**: Data Engineer + Health System Strategy Specialist

---

## 1. Physical & Storage Profile

| Property | Value | Assessment |
|---|---|---|
| Format | Delta (MANAGED) | Standard |
| Rows | 20 | Small reference table |
| Application status | **Actively used** | ProvenanceTool (Phase 10B-6 COMPLETE); 4 live API endpoints |

---

## 2. Schema Key Columns

| Column | Type | Notes |
|---|---|---|
| `system_id` | STRING | PK - use in JOINs (NOT health_system_id) |
| `system_name` | STRING | Display name (e.g., Kaiser Permanente, Dignity Health) |
| `name_patterns` | STRING | Pipe-delimited regex/keyword patterns for auto-matching new providers |
| `region` | STRING | Primary geographic region |
| `system_type` | STRING | NON_PROFIT, FOR_PROFIT, GOVERNMENT |

**Notable systems**: Kaiser Permanente (0 providers - closed panel), Dignity Health, Sutter Health, UCSF Health, Stanford Health Care, Cedars-Sinai, etc.

**name_patterns field**: Used by Phase 3 Task 3.4 to auto-assign new providers to systems during pipeline runs. Stored as pipe-delimited patterns (e.g., `Dignity|CommonSpirit|CHI`). This enables automated system mapping for new contract ingestions.

---

## 3. Architectural Recommendations

| Priority | Recommendation | Impact |
|---|---|---|
| P1 | Use in application for system-level contract views - "compare rates across all Sutter hospitals" | High-value negotiation analytics |
| P1 | Expose system_name in provider search to enable system-level filtering | User experience |
| P2 | Add total_contracted_spend DECIMAL aggregated from tbl_financial_exposure | System-level financial view |

---

*Analysis based on schema introspection of `dev_adb.raw.dim_health_system` (2026-07-13). Live data queries not executed.*

---

# Deep Analysis: `tbl_contract_risk_scores`

**Analyzed**: 2026-07-13 (schema introspection + documentation)
**Analyst lens**: Data Engineer + Risk Management Specialist

---

## 1. Physical & Storage Profile

| Property | Value | Assessment |
|---|---|---|
| Format | Delta (MANAGED) | Standard |
| Rows | 272 | One risk score per active provider |
| Application status | **Actively used** | ProvenanceTool (Phase 10B-6 COMPLETE); 4 live API endpoints |

---

## 2. Schema Key Columns

| Column | Type | Notes |
|---|---|---|
| `risk_score_id` | STRING | Surrogate PK |
| `provider_id` | STRING | FK to dim_provider_canonical |
| `composite_score` | INT | Overall risk score (range 18-48) |
| `risk_tier` | STRING | LOW, MEDIUM, or MONITOR |
| `expiration_risk` | INT | Sub-score: contract expiration proximity |
| `compliance_gap` | INT | Sub-score: regulatory compliance gaps |
| `clause_gap` | INT | Sub-score: missing key clauses |
| `amendment_velocity` | INT | Sub-score: rate of amendment activity |
| `fin_risk` | INT | Sub-score: financial exposure risk |
| `scored_at` | TIMESTAMP | When score was computed |

---

## 3. Score Distribution

| risk_tier | Count | Notes |
|---|---|---|
| LOW | 239 | 87.9% of providers |
| MEDIUM | 26 | 9.6% - needs monitoring |
| MONITOR | 7 | 2.6% - requires immediate attention |

**Score interpretation**: Range 18-48. Lower end of range (18) suggests minimal risk across all 19 dimensions. Upper end (48) suggests risk present in multiple dimensions simultaneously. The 7 MONITOR-tier providers are the highest-priority action items in the entire contract portfolio.

---

## 4. Data Quality Checks

| Check | Assessment | Severity |
|---|---|---|
| Score staleness (scored_at) | Unknown - risk scores not refreshed automatically | HIGH |
| 272 rows vs 531 canonical providers | Only active providers scored; confirms ~57% coverage | MEDIUM |
| All risk tiers low concentration at MONITOR | 7 providers = 2.6% - plausible or possibly under-scoring | MEDIUM |

---

## 5. Critical Query Patterns

```sql
-- Providers requiring immediate attention
SELECT provider_id, composite_score, risk_tier,
       expiration_risk, compliance_gap, fin_risk
FROM dev_adb.raw.tbl_contract_risk_scores
WHERE risk_tier IN ('MONITOR', 'MEDIUM')
ORDER BY composite_score DESC
```

---

## 6. Architectural Recommendations

| Priority | Recommendation | Impact |
|---|---|---|
| P0 | Expose via Risk Dashboard tool - Phase 10B Cluster A | Proactive contract management |
| P0 | Implement auto-refresh of composite_score when source tables change | Prevents stale risk signals |
| P1 | Add risk_score_breakdown STRUCT for all 19 sub-dimensions | Enables drill-down from composite to individual risk drivers |

---

*Analysis based on schema introspection of `dev_adb.raw.tbl_contract_risk_scores` (2026-07-13). Live data queries not executed.*

---

# Deep Analysis: `tbl_contract_deadlines`

**Analyzed**: 2026-07-13 (schema introspection + documentation)
**Analyst lens**: Data Engineer + Contract Operations Specialist

---

## 1. Physical & Storage Profile

| Property | Value | Assessment |
|---|---|---|
| Format | Delta (MANAGED) | Standard |
| Rows | 713 | Unified deadline calendar across all providers |
| Application status | **Actively used** | ProvenanceTool (Phase 10B-6 COMPLETE); 4 live API endpoints |

---

## 2. Schema Key Columns

| Column | Type | Notes |
|---|---|---|
| `deadline_id` | STRING | PK - referenced by tbl_alert_queue.source_deadline_id |
| `provider_id` | STRING | FK to dim_provider_canonical |
| `deadline_type` | STRING | RENEWAL, RATE_RENEGOTIATION, COMPLIANCE_FILING, etc. |
| `event_date` | DATE | When the deadline event occurs - USE THIS NOT deadline_date |
| `action_required_by` | DATE | When action must be taken - USE THIS NOT deadline_date |
| `days_until_action` | INT | Computed: negative = overdue - USE THIS NOT days_until_deadline |
| `priority_tier` | STRING | CRITICAL, HIGH, MEDIUM, LOW, EXPIRED |
| `description` | STRING | Human-readable deadline description |

**CRITICAL COLUMN NAMING WARNINGS**:
1. The date column is `event_date` and `action_required_by` - NOT `deadline_date` (which does not exist)
2. The computed column is `days_until_action` - NOT `days_until_deadline` (which does not exist)
3. Any query using `deadline_date` or `days_until_deadline` will fail with column not found

---

## 3. Priority Distribution

| priority_tier | Count | Notes |
|---|---|---|
| LOW | 197 | Routine monitoring |
| EXPIRED | 102 | Past-due deadlines - action overdue |
| CRITICAL | 125 | Requires immediate action |
| HIGH | 95 | Requires action within days |
| MEDIUM | 77 | Requires action within weeks |

**Business urgency**: 125 CRITICAL + 102 EXPIRED = 227 deadlines (31.8%) requiring immediate attention. These are the primary driver of the tbl_alert_queue content.

---

## 4. Critical Query Patterns

```sql
-- Overdue and critical deadlines
SELECT provider_id, deadline_type, event_date,
       action_required_by, days_until_action, priority_tier, description
FROM dev_adb.raw.tbl_contract_deadlines
WHERE priority_tier IN ('CRITICAL', 'EXPIRED')
   OR days_until_action < 0
ORDER BY days_until_action ASC
```

**Avoid:**
```sql
-- These column names DO NOT EXIST in this table
WHERE deadline_date < current_date()   -- use event_date
ORDER BY days_until_deadline           -- use days_until_action
```

---

## 5. Architectural Recommendations

| Priority | Recommendation | Impact |
|---|---|---|
| P0 | Expose via Deadline/Alert tool - Phase 10B Cluster A - 227 urgent deadlines currently invisible | Contract risk prevention |
| P1 | Add notification trigger: when days_until_action <= 30, auto-generate alert_queue entry | Proactive alerting |
| P2 | Add assigned_to STRING for human owner of each deadline action | Accountability |

---

*Analysis based on schema introspection of `dev_adb.raw.tbl_contract_deadlines` (2026-07-13). Live data queries not executed.*

---

# Deep Analysis: `tbl_alert_queue`

**Analyzed**: 2026-07-13 (schema introspection + documentation)
**Analyst lens**: Data Engineer + Operational Alerting Specialist

---

## 1. Physical & Storage Profile

| Property | Value | Assessment |
|---|---|---|
| Format | Delta (MANAGED) | Standard |
| Rows | 351 | Active alert queue |
| Application status | **Actively used** | ProvenanceTool (Phase 10B-6 COMPLETE); 4 live API endpoints |

---

## 2. Schema Key Columns

| Column | Type | Notes |
|---|---|---|
| `alert_id` | STRING | Surrogate PK |
| `provider_id` | STRING | FK to dim_provider_canonical |
| `alert_type` | STRING | EXPIRATION, COMPLIANCE, RATE_REVIEW, RENEGOTIATION, etc. |
| `severity` | STRING | CRITICAL, HIGH, MEDIUM |
| `alert_status` | STRING | All current rows = NEW |
| `alert_message` | STRING | Human-readable alert description |
| `source_deadline_id` | STRING | FK to tbl_contract_deadlines.deadline_id |
| `created_at` | TIMESTAMP | When alert was generated |

---

## 3. Alert Distribution

| severity | Count | Notes |
|---|---|---|
| CRITICAL | 229 | 65.2% - very high concentration |
| HIGH | 34 | 9.7% |
| MEDIUM | 88 | 25.1% |

**All 351 alerts have status = NEW** - none have been acknowledged, actioned, or resolved. This is a static snapshot - there is no alert lifecycle management (no ACKNOWLEDGED, IN_PROGRESS, RESOLVED states currently in use).

---

## 4. Critical Query Patterns

```sql
-- Critical unresolved alerts
SELECT a.provider_id, a.alert_type, a.severity, a.alert_message,
       d.event_date, d.days_until_action
FROM dev_adb.raw.tbl_alert_queue a
JOIN dev_adb.raw.tbl_contract_deadlines d
  ON d.deadline_id = a.source_deadline_id
WHERE a.severity = 'CRITICAL'
  AND a.alert_status = 'NEW'
ORDER BY d.days_until_action ASC
```

**Note**: No FK to `tbl_contract_notifications` - link only via `provider_id`.

---

## 5. Architectural Recommendations

| Priority | Recommendation | Impact |
|---|---|---|
| P0 | Expose via Alert Dashboard - Phase 10B Cluster A - 229 CRITICAL alerts completely invisible | Single highest-impact gap across all 35 tables |
| P0 | Implement alert lifecycle: add ACKNOWLEDGED, IN_PROGRESS, RESOLVED to alert_status | Enables actionable workflow |
| P1 | Add assigned_to STRING and resolved_at TIMESTAMP | Operational accountability |

---

*Analysis based on schema introspection of `dev_adb.raw.tbl_alert_queue` (2026-07-13). Live data queries not executed.*

---

# Deep Analysis: `tbl_compliance_tracking`

**Analyzed**: 2026-07-13 (schema introspection + documentation)
**Analyst lens**: Data Engineer + Regulatory Compliance Specialist

---

## 1. Physical & Storage Profile

| Property | Value | Assessment |
|---|---|---|
| Format | Delta (MANAGED) | Standard |
| Rows | 2,871 | ~7 rows per active provider |
| Application status | **Passively available** | In whitelist, no dedicated tool |
| Created | Phase 4 Task 4.1 | Loop: INSERT matched chunks + UNKNOWN for non-matching providers |

---

## 2. Schema Key Columns

| Column | Type | Notes |
|---|---|---|
| `tracking_id` | STRING | Surrogate PK |
| `provider_id` | STRING | FK to dim_provider_canonical |
| `regulation` | STRING | KNOX_KEENE, CMS_MA, DMHC_STANDARDS, AB_1455, SB_137, AB_352, AB_72 (exactly 7 values) |
| `compliance_status` | STRING | COMPLIANT, PARTIAL, UNKNOWN, EXEMPT |
| `evidence_text` | STRING | Extracted contract language supporting the status |
| `assessed_at` | TIMESTAMP | When assessment was run |

---

## 3. Compliance Coverage by Regulation

| Regulation | Provider Count | Business Importance |
|---|---|---|
| KNOX_KEENE | 508 | California HMO licensing requirement |
| CMS_MA | 517 | Medicare Advantage CMS requirements |
| DMHC_STANDARDS | 498 | CA Dept of Managed Health Care oversight |
| AB_1455 | 386 | CA provider directory/access law |
| SB_137 | 352 | CA network adequacy law |
| AB_352 | 305 | CA health plan law |
| AB_72 | 305 | CA surprise billing law |

---

## 4. Architectural Recommendations

| Priority | Recommendation | Impact |
|---|---|---|
| P1 | Expose via Compliance Dashboard - track PARTIAL and UNKNOWN providers | Regulatory risk management |
| P1 | Add next_review_date DATE - compliance assessments expire | Staleness management |
| P2 | Link to tbl_contract_clauses to derive compliance status from clause evidence | Auto-updating compliance |

---

*Analysis based on schema introspection of `dev_adb.raw.tbl_compliance_tracking` (2026-07-13). Live data queries not executed.*

---

# Deep Analysis: `tbl_contract_notifications`

**Analyzed**: 2026-07-13 (schema introspection + documentation)
**Analyst lens**: Data Engineer + Contract Operations Specialist

---

## 1. Physical & Storage Profile

| Property | Value | Assessment |
|---|---|---|
| Format | Delta (MANAGED) | Standard |
| Rows | 1,934 | Notice requirements across 521 providers |
| Application status | **Passively available** | In whitelist, no dedicated tool |
| Created | Phase 4 Task 4.3 | 6 notification types populated via regex extraction |

---

## 2. Schema Key Columns

| Column | Type | Notes |
|---|---|---|
| `notification_id` | STRING | Surrogate PK |
| `provider_id` | STRING | FK to dim_provider_canonical |
| `notification_type` | STRING | TERMINATION, RATE_CHANGE, AUDIT, RENEWAL, CREDENTIALING, CLAIMS_SUBMISSION_DEADLINE |
| `notice_days` | INT | Required advance notice in days |
| `cure_period_days` | INT | Grace period for cure after breach |
| `notice_text` | STRING | Extracted contract language |
| `trigger_event` | STRING | What event triggers this notice requirement |

**TECHNICAL NOTE on notice_days**: This column was populated using Spark SQL REGEXP_EXTRACT with Java regex patterns. In Python f-strings, use `[0-9]+` NOT `\d+` (Spark SQL string literal parser eats backslashes, making `\d` become literal `d`). This was confirmed as the root cause of notice_days initially returning 0 for all rows (Phase 4 data model constraint #17).

---

## 3. Notification Types

| Type | Business Meaning |
|---|---|
| TERMINATION | Required notice before terminating the contract |
| RATE_CHANGE | Required notice before changing rates |
| AUDIT | Required notice before conducting an audit |
| RENEWAL | Required notice for auto-renewal |
| CREDENTIALING | Notice requirements around provider credentialing |
| CLAIMS_SUBMISSION_DEADLINE | Filing timely requirement |

---

## 4. Critical Query Patterns

```sql
-- Termination notice requirements by provider
SELECT provider_id, notice_days, cure_period_days, notice_text
FROM dev_adb.raw.tbl_contract_notifications
WHERE notification_type = 'TERMINATION'
  AND notice_days IS NOT NULL
ORDER BY notice_days DESC
```

---

## 5. Architectural Recommendations

| Priority | Recommendation | Impact |
|---|---|---|
| P1 | Expose via ContractNotice tool - notice_days is actively needed for termination/renegotiation prep | Operational compliance |
| P1 | Validate notice_days distribution - values should be between 30-365 days for most types | Data quality |
| P2 | Add amendment_source FK - which amendment established this notice requirement | Temporal tracking |

---

*Analysis based on schema introspection of `dev_adb.raw.tbl_contract_notifications` (2026-07-13). Live data queries not executed.*

---

# Deep Analysis: `tbl_quality_performance`

**Analyzed**: 2026-07-13 (schema introspection + documentation)
**Analyst lens**: Data Engineer + Quality Program Analyst

---

## 1. Physical & Storage Profile

| Property | Value | Assessment |
|---|---|---|
| Format | Delta (MANAGED) | Standard |
| Rows | 894 | ~1.85 programs per provider on average |
| Application status | **Passively available** | In whitelist, no dedicated tool |
| Created | Phase 4 Task 4.2 | 483 providers, 5 programs |

---

## 2. Schema Key Columns

| Column | Type | Notes |
|---|---|---|
| `quality_id` | STRING | Surrogate PK |
| `provider_id` | STRING | FK to dim_provider_canonical |
| `program_name` | STRING | HEDIS, P4P, VALUE_BASED, WITHHOLD, STAR_RATING (NOTE: column is program_name, NOT program_type) |
| `bonus_pct` | FLOAT | P4P bonus percentage - NULL on prose contracts |
| `penalty_pct` | FLOAT | Penalty percentage - NULL on prose contracts |
| `formula_text` | STRING | Full formula language when bonus_pct is NULL |
| `measurement_period` | STRING | Annual period for measurement |

---

## 3. Known Data Quality Issues

**bonus_pct and penalty_pct are NULL for all P4P/VALUE_BASED rows**. This is an unresolved DEBT (P2-H). The root cause is that contracts use prose descriptions ("bonus shall be determined as a percentage to be mutually agreed upon annually") rather than bare numeric patterns. The VS extraction pipeline yielded 0 candidates for the 22 NULL bonus_pct rows. The actual percentages require LLM-based extraction or manual review.

| program_type | bonus_pct behavior |
|---|---|
| HEDIS | Typically NULL - quality benchmark, no direct financial bonus |
| P4P | NULL (DEBT P2-H) - prose formula |
| VALUE_BASED | NULL (DEBT P2-H) - prose formula |
| WITHHOLD | May have values - withhold amounts are often numeric |
| STAR_RATING | NULL - no direct financial linkage |

---

## 4. Architectural Recommendations

| Priority | Recommendation | Impact |
|---|---|---|
| P1 | Expose via Quality Program tool - currently passively available only | Enables P4P/VALUE_BASED contract analytics |
| P1 | Resolve P2-H DEBT: run LLM-based extraction on formula_text to backfill bonus_pct where deterministic | Financial completeness |
| P2 | Add current_score FLOAT and current_period STRING - track actual performance vs thresholds | Gap-to-bonus monitoring |

---

*Analysis based on schema introspection of `dev_adb.raw.tbl_quality_performance` (2026-07-13). Live data queries not executed.*

---

# Deep Analysis: `tbl_dofr_matrix_extracted`

**Analyzed**: 2026-07-13 (schema introspection + documentation)
**Analyst lens**: Data Engineer + DOFR / Delegation Specialist

---

## 1. Physical & Storage Profile

| Property | Value | Assessment |
|---|---|---|
| Format | Delta (MANAGED) | Standard |
| Rows | 1,821 | Including 658 rows added by Phase 3 B-6 DOFR backfill |
| Application status | **Actively used** | Referenced in agent_controller DOFR prompt logic |

---

## 2. Schema Key Columns

| Column | Type | Notes |
|---|---|---|
| `dofr_id` | STRING | Surrogate PK |
| `provider_id` | STRING | FK to dim_provider_canonical |
| `source_filename` | STRING | FK to tbl_contract_documents_master |
| `service_category` | STRING | Clinical service category (e.g., INPATIENT, OUTPATIENT, PHARMACY) |
| `subcategory` | STRING | Specific service line within category |
| `group_responsible` | BOOLEAN | TRUE if physician group is financially responsible |
| `hospital_responsible` | BOOLEAN | TRUE if hospital is responsible |
| `health_plan_responsible` | BOOLEAN | TRUE if Blue Shield (health plan) is responsible |
| `dofr_category` | STRING | Normalized category - backfilled by B-6 |
| `confidence` | FLOAT | Extraction confidence (0.0-1.0) |

---

## 3. DOFR Category Backfill (Phase 3 B-6)

Before Phase 3 B-6, many rows had NULL `dofr_category`. The backfill added 658 rows and normalized the category taxonomy. The original table had 1,163 rows; after backfill, 1,821 rows. The 658 additional rows came from re-extracting DOFR clauses using improved regex patterns.

**Active application use**: The agent_controller includes DOFR prompt logic that queries this table to answer "who is responsible for [service] for [provider]?" questions. This is one of the few Group 7 tables with active code references.

---

## 4. Data Quality Checks

| Check | Assessment | Severity |
|---|---|---|
| Rows where all three responsible columns = FALSE | Logic error - at least one party must be responsible | MEDIUM |
| Rows where multiple responsible columns = TRUE | Expected for shared responsibility - valid | OK |
| service_category cardinality | Similar free-text problem as tbl_contract_rates_all | MEDIUM |
| dofr_category NULL post-backfill | Should be near 0 after B-6 | LOW |

---

## 5. Critical Query Patterns

```sql
-- Who is responsible for inpatient services at a provider?
SELECT service_category, subcategory,
       group_responsible, hospital_responsible, health_plan_responsible
FROM dev_adb.raw.tbl_dofr_matrix_extracted
WHERE provider_id = '<id>'
  AND UPPER(service_category) LIKE '%INPATIENT%'
ORDER BY service_category
```

---

## 6. Architectural Recommendations

| Priority | Recommendation | Impact |
|---|---|---|
| P0 | Validate current agent_controller DOFR prompt output against live table data | Confirms active logic is correct |
| P1 | Normalize service_category to controlled vocabulary | Enables service-level filtering |
| P1 | Add is_current BOOLEAN - filter to CURRENT amendment only (currently no version filter in queries) | Prevents superseded DOFR assignments from being returned |

---

*Analysis based on schema introspection of `dev_adb.raw.tbl_dofr_matrix_extracted` (2026-07-13). Live data queries not executed.*

---

# Deep Analysis: `tbl_delegation_matrix`

**Analyzed**: 2026-07-13 (schema introspection + documentation)
**Analyst lens**: Data Engineer + IPA Delegation Specialist

---

## 1. Physical & Storage Profile

| Property | Value | Assessment |
|---|---|---|
| Format | Delta (MANAGED) | Standard |
| Rows | 770 | 120 distinct IPA providers × avg 6.4 functions each (120 providers have ipa_delegation_status=HAS in tbl_genie_provider_profile — confirmed live 2026-07-20) |
| Application status | **Passively available** | In whitelist; no dedicated delegation tool |
| Created | Phase 3 Task 3.3 | Filters ipa_delegation_status = 'HAS' from provider profile (120 providers in profile, 120 distinct in matrix) |

---

## 2. Schema Key Columns

| Column | Type | Notes |
|---|---|---|
| `delegation_id` | STRING | Surrogate PK |
| `provider_id` | STRING | FK to dim_provider_canonical - IPA provider only |
| `source_filename` | STRING | FK to tbl_contract_documents_master |
| `delegated_function` | STRING | UM / QM / CREDENTIALING / GRIEVANCES / CLAIMS / PHARMACY / MEMBER_SERVICES (4 NULL rows) |
| `delegation_level` | STRING | FULL (637) / OVERSIGHT_ONLY (96). NOT `delegation_type` — that column does not exist. |
| `subdelegation_allowed` | BOOLEAN | Whether IPA can sub-delegate |
| `supporting_text` | STRING | Contract excerpt supporting this entry |
| `amendment_order` | INT | Source document amendment order |
| `is_current` | BOOLEAN | TRUE for active-amendment rows. NOT `is_active` — that column does not exist. |

---

## 3. IPA Delegation Context

**IPA (Independent Practice Association) delegation** means the IPA takes on responsibility for certain functions on behalf of BSC. Functions commonly delegated include: credentialing, utilization management, claims processing, quality programs, and medical management.

This table is the detailed breakdown of WHAT is delegated for the 120 IPA providers identified in `tbl_genie_provider_profile.ipa_delegation_status = 'HAS'`. Live query 2026-07-20 confirms 120 distinct providers in the matrix. Without this table, the answer to "what exactly has Provider X delegated?" would be unavailable.

---

## 4. Data Quality Checks

| Check | Assessment | Severity |
|---|---|---|
| Mismatch with ipa_delegation_status flags | Phase 3 B-5 DEBT - some flag mismatches remain | MEDIUM |
| is_active = TRUE rows vs current contract | No temporal filter - active flags may be stale | MEDIUM |
| delegation_function vocabulary | Free text or controlled? | MEDIUM |

---

## 5. Critical Query Patterns

```sql
-- What has a specific IPA delegated? (verified column names 2026-07-20)
SELECT delegated_function, delegation_level, subdelegation_allowed, supporting_text
FROM dev_adb.raw.tbl_delegation_matrix
WHERE provider_id = '<id>'
  AND is_current = true  -- NOT is_active (does not exist)
ORDER BY delegated_function
-- delegation_type, effective_date, is_active do NOT exist in this table
```

---

## 6. Architectural Recommendations

| Priority | Recommendation | Impact |
|---|---|---|
| P1 | Expose via IPA Delegation tool - currently passively available only | Enables "what has Provider X delegated?" queries |
| P1 | Reconcile with ipa_delegation_status flags (Phase 3 B-5 DEBT) | Consistency between profile flags and delegation details |
| P2 | Add oversight_contact STRING - who at BSC oversees each delegated function | Accountability mapping |

---

*Analysis based on schema introspection of `dev_adb.raw.tbl_delegation_matrix` (2026-07-13). Live data queries not executed.*

---

# Deep Analysis: `tbl_extraction_provenance`

**Analyzed**: 2026-07-13 (schema introspection + documentation)
**Analyst lens**: Data Engineer + Data Lineage / Audit Specialist

---

## 1. Physical & Storage Profile

| Property | Value | Assessment |
|---|---|---|
| Format | Delta (MANAGED) | Standard |
| Rows | 15,368 | Full audit trail for extracted fields |
| Application status | **Actively used** | ProvenanceTool (Phase 10B-6 COMPLETE); 4 live API endpoints |

---

## 2. Schema Key Columns

| Column | Type | Notes |
|---|---|---|
| `extraction_id` | STRING | Surrogate PK (NOT `provenance_id` — that column does not exist) |
| `target_table` | STRING | Which table this extraction went into |
| `target_record_id` | STRING | The record_id in the target table |
| `target_column` | STRING | Which column was extracted (NOT `field_name` — that column does not exist) |
| `extraction_method` | STRING | PATTERN_MATCH only (100% of 15,368 rows — confirmed live 2026-07-20) |
| `confidence_score` | FLOAT | 0.0-1.0 confidence |
| `human_verified` | BOOLEAN | Whether a human reviewed this extraction |
| `source_page_numbers` | STRING | PDF page(s) where value was found |
| `model_version` | STRING | Model version used during extraction |
| `extraction_timestamp` | TIMESTAMP | When extraction was run (NOT `extracted_at`) |

**Note (Phase 10B-6 update)**: `provider_id` IS present in this table (0 nulls, 1,395 distinct — added Phase 10B-6). You can JOIN directly ON `provider_id`. The old multi-hop join path (via `target_table` + `target_record_id`) still works but is no longer required for provider-level filtering.

---

## 3. Coverage by Target Table

| Target table | Rows | Notes |
|---|---|---|
| tbl_contract_clauses | 7,777 | Clause-level extraction audit |
| tbl_contract_notifications | 1,934 | Notice requirement extraction |
| tbl_compliance_tracking | 1,897 | Compliance status extraction |
| tbl_delegation_matrix | 1,599 | Delegation function extraction |
| tbl_dofr_matrix_extracted | 1,163 | DOFR responsibility extraction |
| tbl_quality_performance | 894 | Quality program extraction |
| tbl_rate_escalators | 104 | Escalation term extraction |

**Total**: 15,368 rows across 7 target tables. Coverage is 100% for the tables listed (every row in each target table has at least one provenance entry).

---

## 4. Extraction Method Distribution (Estimated)

| extraction_method | Live Count | Notes |
|---|---|---|
| PATTERN_MATCH | 15,368 (100%) | Only method present in live data (confirmed 2026-07-20). LLM_V6 / REGEX / RULE_BASED do NOT exist. |

---

## 5. Critical Query Patterns

**Audit trail for a specific clause:**
```sql
SELECT p.extraction_method, p.confidence_score,
       p.human_verified, p.source_page_numbers, p.model_version
FROM dev_adb.raw.tbl_extraction_provenance p
WHERE p.target_table = 'tbl_contract_clauses'
  AND p.target_record_id = '<clause_id>'
```

**Low-confidence extractions requiring review:**
```sql
SELECT target_table, target_record_id, field_name,
       confidence_score, extraction_method
FROM dev_adb.raw.tbl_extraction_provenance
WHERE confidence_score < 0.6
  AND human_verified = false
ORDER BY confidence_score ASC
LIMIT 50
```

---

## 6. Architectural Recommendations

| Priority | Recommendation | Impact |
|---|---|---|
| P1 | Expose in citation UI - when surfacing extracted data to users, show confidence_score and source_page_numbers | Data trust transparency |
| P1 | Add provider_id column via a JOIN-based computed column or denormalized copy | Eliminates multi-hop join for provider-level audit queries |
| P2 | Surface human_verified = false + confidence_score < 0.7 rows as a review queue | Continuous data quality improvement |
| P2 | Add extraction_version INT - tracks when re-extraction changes a value | Change audit trail |

---

*Analysis based on schema introspection of `dev_adb.raw.tbl_extraction_provenance` (2026-07-13). Live data queries not executed.*

---

# Deep Analysis: `dim_table_schema`

**Analyzed**: 2026-07-13 (schema introspection + documentation)
**Analyst lens**: Data Engineer + Runtime Systems Specialist

---

## 1. Physical & Storage Profile

| Property | Value | Assessment |
|---|---|---|
| Format | Delta (MANAGED) | Standard |
| Rows | 468 | 29 tables x avg 16 columns per table |
| Application status | **Actively used** | Runtime CRITICAL - SchemaContextBuilder reads this for SQL generation |

**RUNTIME WARNING**: Do NOT drop, truncate, or ALTER this table without updating the application. The SchemaContextBuilder reads this table at query time to determine valid column names, types, and descriptions for SQL auto-generation. A missing or stale entry will cause the agent to generate syntactically incorrect SQL.

---

## 2. Schema Key Columns

| Column | Type | Notes |
|---|---|---|
| `schema_id` | STRING | Surrogate PK |
| `table_name` | STRING | The production table name |
| `column_name` | STRING | Column within that table |
| `data_type` | STRING | Spark SQL data type |
| `column_description` | STRING | Human-readable description for prompt context |
| `is_primary_key` | BOOLEAN | Whether this is a primary key column |
| `is_foreign_key` | BOOLEAN | Whether this references another table |
| `foreign_key_table` | STRING | Which table this FK references |

---

## 3. Operational Significance

This table is the **schema metadata store** for the agent's SQL generation pipeline. When a user asks "how many providers have DOFR clauses?", the SchemaContextBuilder queries this table to:
1. Find which tables contain `dofr_status` columns
2. Retrieve the column description to understand semantics
3. Build the SQL generation prompt with accurate type information

Any error in this table directly causes agent SQL generation failures. Stale entries (e.g., if a column was renamed in production) cause silent SQL failures.

---

## 4. Architectural Recommendations

| Priority | Recommendation | Impact |
|---|---|---|
| P0 | Add automated sync job: after any table ALTER, update dim_table_schema | Prevents schema drift |
| P1 | Expand from 29 to all 35 tables - 6 tables currently missing from schema registry | Ensures agent can generate SQL for all tables |
| P2 | Add column_examples ARRAY<STRING> - sample values for each column | Improves SQL generation accuracy |

---

*Analysis based on schema introspection of `dev_adb.raw.dim_table_schema` (2026-07-13). Live data queries not executed.*

---

# Deep Analysis: `fact_retrieval_telemetry`

**Analyzed**: 2026-07-13 (schema introspection + documentation)
**Analyst lens**: Data Engineer + Observability Specialist

---

## 1. Physical & Storage Profile

| Property | Value | Assessment |
|---|---|---|
| Format | Delta (MANAGED) | Standard |
| Rows | 1,300 | Growing with every query |
| Application status | **Actively used** | TelemetryRepo writes on every VS call |

---

## 2. Schema Key Columns

| Column | Type | Notes |
|---|---|---|
| `telemetry_id` | STRING | Surrogate PK |
| `session_id` | STRING | FK to tbl_agent_sessions |
| `query_text` | STRING | The original user query |
| `retrieved_chunks` | INT | Number of VS chunks returned |
| `chunk_scores` | ARRAY<FLOAT> | Similarity scores for each chunk |
| `latency_ms` | INT | End-to-end vector search latency in milliseconds |
| `provider_filter` | STRING | Provider ID used to scope VS results |
| `created_at` | TIMESTAMP | Query timestamp |

---

## 3. Operational Value

This table enables retroactive analysis of retrieval quality:
- Which queries had low chunk scores (poor retrieval match)?
- Which provider queries have the highest latency?
- What was the average latency trend over the past 7 days?

The Status Dashboard in the application reads this table for its latency sparklines and volume trends.

---

## 4. Architectural Recommendations

| Priority | Recommendation | Impact |
|---|---|---|
| P1 | Add partitioning on created_at - will grow unbounded over time | Query performance on date-range analytics |
| P1 | Add llm_latency_ms and total_latency_ms separate from VS latency | Isolates slow VS vs slow LLM |
| P2 | Add retention policy: delete rows older than 90 days | Storage hygiene |

---

*Analysis based on schema introspection of `dev_adb.raw.fact_retrieval_telemetry` (2026-07-13). Live data queries not executed.*

---

# Deep Analysis: `tbl_agent_sessions`

**Analyzed**: 2026-07-13 (schema introspection + documentation)
**Analyst lens**: Data Engineer + Application Runtime Specialist

---

## 1. Physical & Storage Profile

| Property | Value | Assessment |
|---|---|---|
| Format | Delta (MANAGED) | Standard |
| Rows | 2,229 | One row per query turn (not per session) |
| Application status | **Actively used** | SessionRepo writes via _persist_turn() fire-and-forget |

---

## 2. Schema Key Columns

| Column | Type | Notes |
|---|---|---|
| `session_id` | STRING | Groups turns by conversation session |
| `turn_id` | STRING | Unique per query-response pair |
| `user_query` | STRING | The original question |
| `agent_response` | STRING | The full LLM response |
| `provider_context` | STRING | Which provider the session focused on |
| `tools_used` | ARRAY<STRING> | Which tools were invoked (RateQuery, VectorSearch, etc.) |
| `confidence_score` | FLOAT | Agent confidence in the response |
| `latency_ms` | INT | Total end-to-end response latency |
| `feedback_score` | INT | User thumbs up/down (from FeedbackRepo) |
| `created_at` | TIMESTAMP | Turn timestamp |

---

## 3. Application Integration

This table is written by `_persist_turn()` which is called fire-and-forget (no await) on every query. The session sidebar in the frontend reads this table to show conversation history. The export endpoint reads it to generate markdown/JSON/CSV exports.

**Feedback**: When a user clicks thumbs-up or thumbs-down, the feedback_score column is updated via the FeedbackRepo. This enables quality analysis of which query types get positive/negative feedback.

---

## 4. Architectural Recommendations

| Priority | Recommendation | Impact |
|---|---|---|
| P1 | Add partitioning on created_at - will grow with usage | Query performance |
| P1 | Add user_id STRING - enables per-user session history and personalization | Multi-user support |
| P2 | Add tools_failed ARRAY<STRING> for failed tool invocations | Debugging failed queries |
| P2 | Add retention policy: anonymize/delete agent_response after 180 days for PII hygiene | Data governance |

---

*Analysis based on schema introspection of `dev_adb.raw.tbl_agent_sessions` (2026-07-13). Live data queries not executed.*

---

## Document Completion Summary

**All 35 production tables analyzed** (2026-07-13). Deep analysis written for each table across Groups 1-9.

| Group | Tables Analyzed | Status |
|---|---|---|
| 1 — Financial & Rate Intelligence | tbl_contract_rates_all, tbl_repricing_scenarios, fact_supersession, tbl_financial_exposure, tbl_rate_escalators | COMPLETE |
| 2 — Contract Documents & Structure | tbl_vs_unified_ready, tbl_contract_documents_master, tbl_contract_hierarchy, tbl_genie_amendment_timeline | COMPLETE |
| 3 — Clause Intelligence | tbl_contract_clauses, tbl_clause_deviations | COMPLETE |
| 4 — Provider Identity & Network | tbl_provider_identifiers, dim_provider_canonical, tbl_genie_provider_profile, tbl_service_areas, tbl_provider_system_membership, dim_health_system | COMPLETE |
| 5 — Risk, Alerts & Deadlines | tbl_contract_risk_scores, tbl_contract_deadlines, tbl_alert_queue | COMPLETE |
| 6 — Compliance & Quality | tbl_compliance_tracking, tbl_contract_notifications, tbl_quality_performance | COMPLETE |
| 7 — Delegation & Responsibility | tbl_dofr_matrix_extracted, tbl_delegation_matrix | COMPLETE |
| 8 — Audit & Provenance | tbl_extraction_provenance | COMPLETE |
| 9 — System & Infrastructure | dim_table_schema, fact_retrieval_telemetry, tbl_agent_sessions | COMPLETE |

*Document last updated 2026-07-20.*

---
---

# SECTION A — Individual Table Issues Registry

**Purpose**: Consolidated defect catalog for all 35 production tables.
**Severity legend**: CRITICAL = blocks correct answers or causes silent data loss; HIGH = materially impacts analysis accuracy; MEDIUM = operational gap or DQ risk; LOW = hygiene / future-proofing.

---

## A1 — Master Issues Table

| # | Table | Issue | Severity | Phase Status |
|---|---|---|---|---|
| 1 | `tbl_contract_rates_all` | `service_category` has 22,045 distinct values — effectively free text, unusable as a WHERE filter | CRITICAL | OPEN |
| 2 | `tbl_contract_rates_all` | `rate_category` naming duplication: `inpatient_per_diem` vs `inpatient_per_diem_rates` (and case_rate equivalent) — 210K rows affected, double-count risk on GROUP BY | CRITICAL | OPEN |
| 3 | `tbl_contract_rates_all` | `is_latest_version` flag wrong for 42,527 rows — rows with `status='superseded'` but `is_latest_version=true` (temporal paradox from Phase 9) | HIGH | OPEN |
| 4 | `tbl_contract_rates_all` | 163,930 superseded rows have no `superseded_by` forward pointer — 50.5% of all superseded rows; amendment chain reconstruction is broken | HIGH | OPEN |
| 5 | `tbl_contract_rates_all` | `amendment_order` stored as STRING — requires TRY_CAST in every query; 2,782 cast failures on non-numeric labels | MEDIUM | OPEN |
| 6 | `tbl_contract_rates_all` | Zero NOT NULL constraints on all 28 columns — a bad pipeline run would corrupt table silently | MEDIUM | OPEN |
| 7 | `tbl_contract_rates_all` | AWP_DISCOUNT: all 25 rows flagged `is_valid_rate=false` — plausibility engine expects positive numbers; AWP_DISCOUNT uses negative values (valid range −100 to 0) | MEDIUM | OPEN |
| 8 | `tbl_contract_rates_all` | 3,105 zombie rows — neither `rate_numeric` nor `rate_text` populated; these rows contribute $0 to averages and distort statistical profiles | HIGH | OPEN |
| 9 | `tbl_contract_rates_all` | PMPM max $71,113 exceeds documented Phase 6 plausibility cap of $25,000 — at least one row escaped the cap filter | MEDIUM | OPEN |
| 10 | `tbl_contract_rates_all` | 216 `provider_id` values (128,896 rows = 28%) do not exist in `tbl_genie_provider_profile` — silently dropped on every JOIN to profile | HIGH | OPEN |
| 11 | `tbl_contract_rates_all` | No partitioning or liquid clustering — every query does a full file scan; will degrade as table grows | MEDIUM | OPEN |
| 12 | `tbl_contract_rates_all` | `appendOnly` table feature enabled despite multiple DELETE phases having run — semantic contradiction | LOW | OPEN |
| 13 | `tbl_contract_rates_all` | No surrogate primary key — MERGE ON clause fragile, cannot uniquely identify a row | MEDIUM | OPEN |
| 14 | `tbl_contract_rates_all` | Dual date storage: `effective_date` (STRING) + `effective_date_parsed` (DATE) — redundant, the STRING version is unused but confusing | LOW | OPEN |
| 15 | `tbl_repricing_scenarios` | 0 code references — entire simulation table completely invisible to application | HIGH | OPEN |
| 16 | `tbl_repricing_scenarios` | No refresh trigger — all pre-Phase 9 scenarios are stale (rates changed on 2026-07-12) | HIGH | OPEN |
| 17 | `tbl_repricing_scenarios` | No `rate_unit` column — comparing scenarios across PER_DAY and PMPM providers conflates incompatible units | MEDIUM | OPEN |
| 18 | `tbl_repricing_scenarios` | `estimated_annual_impact` derivation formula undocumented — unclear whether it uses real claims or PMPM proxy | HIGH | OPEN |
| 19 | `fact_supersession` | `provider_id` may be NULL — must JOIN to `tbl_contract_documents_master` via filename to get authoritative provider | HIGH | OPEN |
| 20 | `fact_supersession` | 0 code references — the correct mechanism for amendment chain traversal is unused | HIGH | OPEN |
| 21 | `fact_supersession` | Document-level supersession (this table) and rate-level supersession (`tbl_contract_rates_all.superseded_by`) are completely disconnected — no FK linking them | CRITICAL | OPEN |
| 22 | `fact_supersession` | No confidence filter enforced — low-confidence inferred edges (temporal_chain derivation) can corrupt chain reconstruction | MEDIUM | OPEN |
| 23 | `tbl_financial_exposure` | Only 172 rows for 531+ providers — ~32% coverage at best; presenting as network totals would be deeply misleading | CRITICAL | OPEN |
| 24 | `tbl_financial_exposure` | No deduplication constraint on (provider_id, period_start, period_end, lob) — double-counting possible | HIGH | OPEN |
| 25 | `tbl_financial_exposure` | Not linked to `tbl_repricing_scenarios` — simulated financial impact cannot be validated against actual spend | HIGH | OPEN |
| 26 | `tbl_financial_exposure` | Most rows sourced from ESTIMATE/PROXY not CLAIMS — financial confidence is low for the majority | MEDIUM | OPEN |
| 27 | `tbl_rate_escalators` | Only 104 rows for 531 providers — 19.6% coverage; 80% of network has no escalation data | CRITICAL | OPEN |
| 28 | `tbl_rate_escalators` | `base_index` is free text — CPI-U, CPI, Consumer Price Index, Medical CPI are all the same concept but stored differently | HIGH | OPEN |
| 29 | `tbl_rate_escalators` | No link to `tbl_contract_rates_all` — cannot compute escalation impact on specific rate rows | HIGH | OPEN |
| 30 | `tbl_rate_escalators` | 0 code references — completely invisible despite being the only table with escalation cap data | HIGH | OPEN |
| 31 | `tbl_vs_unified_ready` | Missing `is_current = true` filter returns superseded chunks — silently contaminates clause answers with outdated document versions | CRITICAL | ONGOING RISK |
| 32 | `tbl_vs_unified_ready` | NULL embeddings would break vector search silently — no validation job exists | CRITICAL | UNVALIDATED |
| 33 | `tbl_contract_documents_master` | Only 492/10,348 documents (4.8%) are confirmed ACTIVE with known expiration date | HIGH | DEBT P3-D1 |
| 34 | `tbl_contract_documents_master` | 238 UNKNOWN status rows — contract lifecycle cannot be determined | MEDIUM | OPEN |
| 35 | `tbl_contract_documents_master` | `document_type` has very high cardinality — no standardized vocabulary | LOW | OPEN |
| 36 | `tbl_contract_hierarchy` | Does NOT have `amendment_order` column — any query using that name fails silently | CRITICAL | DOCUMENTED |
| 37 | `tbl_contract_hierarchy` | `sequential_order` reflects document REVISION order (from _vN suffix), NOT amendment chronological position — root cause of 47.84% broken_chain_providers metric in Phase 6 | CRITICAL | PHASE 7 DEBT |
| 38 | `tbl_genie_amendment_timeline` | 36% document gap — 3,739 documents have no timeline entry | MEDIUM | OPEN |
| 39 | `tbl_genie_amendment_timeline` | No `amendment_order` INT column — cannot JOIN to `tbl_contract_hierarchy.sequential_order` | MEDIUM | OPEN |
| 40 | `tbl_contract_clauses` | `clause_text` completely unused by application — ClauseExistence tool reads PROFILE FLAGS, never clause text | CRITICAL | Phase 10B Cluster E |
| 41 | `tbl_contract_clauses` | 54 providers have <10 clause categories — thin clause coverage | MEDIUM | OPEN |
| 42 | `tbl_clause_deviations` | All 7,777 rows are CONFORMANT/NONE — no actual deviation data exists in this table | CRITICAL | BY DESIGN (incomplete) |
| 43 | `tbl_clause_deviations` | No `baseline_text` or `actual_text` columns — deviation comparison is architecturally impossible without schema extension | HIGH | OPEN |
| 44 | `tbl_clause_deviations` | Table name misleads — it is actually a clause network statistics table, not a deviations table | MEDIUM | OPEN |
| 45 | `tbl_provider_identifiers` | 50,159 rows completely unused in application — NPI/TIN registry never queried | HIGH | OPEN |
| 46 | `tbl_provider_identifiers` | No temporal tracking per identifier — NPI/TIN changes over time are not captured | MEDIUM | OPEN |
| 47 | `tbl_provider_identifiers` | No format validation — NPI should be exactly 10 digits, TIN 9 digits | MEDIUM | OPEN |
| 48 | `dim_provider_canonical` | Only ~57% match rate from canonical to rates table — 231 canonical providers have no rate data | HIGH | OPEN |
| 49 | `dim_provider_canonical` | No `is_active` flag — 531 includes historical/inactive providers | MEDIUM | OPEN |
| 50 | `tbl_genie_provider_profile` | Only 306/531 providers — 225 canonical providers have no operational profile (no payment_type, no LOB, no clause flags) | HIGH | OPEN |
| 51 | `tbl_genie_provider_profile` | `lob_normalized = 'Medicare'` ambiguity — MA vs FFS not distinguished | MEDIUM | DEBT B-3 |
| 52 | `tbl_genie_provider_profile` | `payment_type_normalized` inconsistencies vs rate_unit evidence | MEDIUM | DEBT B-4 |
| 53 | `tbl_genie_provider_profile` | `offset_clause_status` / `dofr_status` / `ipa_delegation_status` flag mismatches with clause/delegation tables | MEDIUM | DEBT B-5 |
| 54 | `tbl_genie_provider_profile` | `bonus_pct` NULL for all P4P/VALUE_BASED rows | MEDIUM | DEBT P2-H |
| 55 | `tbl_service_areas` | Column named `region` (not `service_area_name`) — common query error | LOW | DOCUMENTED |
| 56 | `tbl_service_areas` | 61% Statewide coverage — minimal geographic granularity for most of network | MEDIUM | OPEN |
| 57 | `tbl_provider_system_membership` | Only 112/304 providers mapped to health systems — 63% unmapped | HIGH | OPEN |
| 58 | `tbl_provider_system_membership` | FK uses `system_id` not `health_system_id` — wrong column name causes silent NULL join | HIGH | DOCUMENTED |
| 59 | `tbl_provider_system_membership` | 0 code references | HIGH | OPEN |
| 60 | `dim_health_system` | 0 code references — system-level contract analytics impossible | HIGH | OPEN |
| 61 | `tbl_contract_risk_scores` | 0 code references — 7 MONITOR-tier providers and 26 MEDIUM-tier completely invisible | CRITICAL | Phase 10B Cluster A |
| 62 | `tbl_contract_risk_scores` | No auto-refresh — composite score goes stale as source data changes | HIGH | OPEN |
| 63 | `tbl_contract_deadlines` | 0 code references — 227 CRITICAL/EXPIRED deadlines invisible | CRITICAL | Phase 10B Cluster A |
| 64 | `tbl_contract_deadlines` | `deadline_date` and `days_until_deadline` do NOT exist — queries using these names fail | CRITICAL | DOCUMENTED |
| 65 | `tbl_alert_queue` | 0 code references — 229 CRITICAL alerts completely invisible | CRITICAL | Phase 10B Cluster A |
| 66 | `tbl_alert_queue` | All 351 alerts stuck at `status = 'NEW'` — no alert lifecycle (no ACKNOWLEDGED/RESOLVED states) | HIGH | OPEN |
| 67 | `tbl_compliance_tracking` | No dedicated tool — compliance status not surfaced | HIGH | OPEN |
| 68 | `tbl_compliance_tracking` | No `next_review_date` — compliance assessments have no expiry / staleness control | MEDIUM | OPEN |
| 69 | `tbl_contract_notifications` | `notice_days` extraction used `\d` in SQL string (Java regex — constraint 17) — may have produced 0 valid extractions | HIGH | VERIFIED FIXED |
| 70 | `tbl_quality_performance` | `bonus_pct` / `penalty_pct` NULL for all P4P/VALUE_BASED rows — prose contracts only | MEDIUM | DEBT P2-H |
| 71 | `tbl_quality_performance` | No `current_score` column — cannot track actual performance vs thresholds | MEDIUM | OPEN |
| 72 | `tbl_dofr_matrix_extracted` | No `is_current` filter — queries may return superseded DOFR assignments from older amendments | HIGH | OPEN |
| 73 | `tbl_dofr_matrix_extracted` | `service_category` free-text cardinality problem (similar to rates table) | MEDIUM | OPEN |
| 74 | `tbl_delegation_matrix` | No dedicated tool — IPA delegation scope invisible | HIGH | OPEN |
| 75 | `tbl_delegation_matrix` | `ipa_delegation_status` flag mismatches with profile (B-5 DEBT) | MEDIUM | DEBT B-5 |
| 76 | `tbl_extraction_provenance` | No `provider_id` column — requires 2-hop join via target_table + target_record_id | HIGH | OPEN |
| 77 | `tbl_extraction_provenance` | 0 code references — extraction quality and confidence completely invisible | HIGH | OPEN |
| 78 | `dim_table_schema` | Only covers 29/35 tables — 6 tables missing from schema registry | HIGH | OPEN |
| 79 | `dim_table_schema` | No auto-sync after table ALTERs — schema metadata goes stale silently | HIGH | OPEN |
| 80 | `fact_retrieval_telemetry` | No partitioning by `created_at` — will degrade as query volume grows | MEDIUM | OPEN |
| 81 | `tbl_agent_sessions` | No `user_id` column — multi-user session history not possible | MEDIUM | OPEN |

---

## A2 — Issues by Severity Summary

| Severity | Count | Primary tables affected |
|---|---|---|
| CRITICAL | 18 | rates_all, contract_hierarchy, clause_deviations, contract_clauses, alert_queue, contract_deadlines, risk_scores, vs_unified_ready, fact_supersession |
| HIGH | 36 | Most Group 1-5 tables, dim_health_system, provider_system_membership, extraction_provenance |
| MEDIUM | 21 | Profile flags, quality tables, service_areas, telemetry |
| LOW | 6 | Schema hygiene, column naming, appendOnly |
| **TOTAL** | **81** | Across all 35 production tables |

---

## A3 — Issues by Application Visibility Status

| Status | Issue count | Business risk |
|---|---|---|
| Issues in actively-used tables | 23 | Active risk — users getting wrong answers today |
| Issues in passively-available tables | 28 | Latent risk — queries will fail or mislead when these tables are first used |
| Issues in completely-invisible tables | 30 | Value destruction — entire Groups 5 and 8 generating no return |

*Section A complete. 81 individual table issues documented across 35 tables. 2026-07-13.*

---
---

# SECTION B — Data Model Holistic Analysis

**Purpose**: Cross-table architectural issues that cannot be found by inspecting any single table in isolation. These are the issues that cause systemic failures, inconsistent answers, and structural blind spots across the full 35-table data model.

---

## B1 — Provider Identity Fragmentation

**Issue**: There is no single authoritative "active provider" denominator. Every table uses a different count:

| Table | Provider count | Definition |
|---|---|---|
| `dim_provider_canonical` | 531 | All canonical identities (historical + active) |
| `tbl_genie_provider_profile` | 306 | Active providers with profile data |
| `tbl_contract_rates_all` (canonical_provider_id) | 300 | Providers with rate data |
| `tbl_service_areas` | 306 | Providers with geographic data |
| `tbl_compliance_tracking` | Up to 517 | Providers with compliance entries |
| `tbl_provider_identifiers` | Variable | Providers with NPI/TIN records |

**Why it matters**: Any cross-table analysis that says "X% of providers have Y" is meaningless without specifying which denominator. A compliance analyst saying "94% of providers are Knox-Keene compliant" using the 517-provider base means something very different from "94% compliant" using the 531-provider canonical base. The correct denominator should always be declared explicitly.

**Root cause**: `dim_provider_canonical` was designed as the master registry but `tbl_genie_provider_profile` became the de-facto operational view. The 225 providers in canonical but not in profile represent real contracted entities whose data was never fully extracted — not inactive providers that should be excluded.

---

## B2 — Two Parallel Supersession Systems with No Bridge

**Issue**: The data model has TWO entirely separate representations of the contract amendment chain, neither of which is linked to the other:

| System | Table | What it tracks | Current status |
|---|---|---|---|
| Document-level | `fact_supersession` | Which PDF superseded which PDF | 2,380 edges, 0 code references |
| Rate-level | `tbl_contract_rates_all.superseded_by` | Which rate row was superseded | 160,487 populated pointers + 163,930 NULL |

**The gap**: When a new amendment is ingested, the document supersession edge is added to `fact_supersession`, and rate rows may be marked as superseded in `tbl_contract_rates_all`. But there is no FK or trigger that links a `fact_supersession` edge to the specific rate rows it affected. This means:
- You cannot look at a document supersession edge and find the rates that changed.
- You cannot look at a superseded rate row and find the `fact_supersession` edge that explains why.
- The two views of "what changed" can and do diverge silently.

**Practical consequence**: The `superseded_by` format in `tbl_contract_rates_all` (`eff:DATE|src:FILENAME`) is a denormalized string encoding of what should be a FK to `fact_supersession`. Instead of this string, the column should hold a `supersession_id` FK. The current design makes JOIN-based chain reconstruction impossible without string parsing.

---

## B3 — Amendment Chain Broken Across Four Tables

**Issue**: Amendment chronology is modeled in four different tables using four incompatible approaches:

| Table | Column | Type | Semantics |
|---|---|---|---|
| `tbl_contract_rates_all` | `amendment_order` | STRING | Raw extracted label (can be "Amendment 3", "Exhibit A", "Rider 2") |
| `tbl_contract_rates_all` | `amendment_order_int` | INT | TRY_CAST of above; 2,782 NULLs on non-numeric labels |
| `tbl_contract_hierarchy` | `sequential_order` | INT | _vN filename suffix — REVISION ORDER, not amendment position |
| `tbl_genie_amendment_timeline` | (no order column) | — | Sorted by `amendment_date`; no positional ordinal |
| `fact_supersession` | (no order column) | — | Sorted by `superseding_effective_date`; no positional ordinal |

**Why it matters**: Any query that tries to reconstruct "what was the 3rd amendment to this contract?" gets a different answer depending on which table it queries. The Phase 6 postmortem confirmed that `sequential_order` in `tbl_contract_hierarchy` was populated from `_vN` file suffixes which represent document revisions within an editing cycle — not true amendment sequence. This is why 47.84% of amendment chains are broken.

**The correct fix requires** a single canonical `amendment_position INT` column computed from effective_date + amendment labels, stored in `tbl_contract_hierarchy` (replacing the current `sequential_order`), and propagated to all other tables as a join key.

---

## B4 — No End-to-End Financial Intelligence Chain

**Issue**: To answer "what is BSC's total contracted spend and how will it change under current escalation terms?" requires a 4-table chain. Every link in that chain is broken:

| Step | Table | Coverage | Blocker |
|---|---|---|---|
| 1. What are current rates? | `tbl_contract_rates_all` | 300 providers | 28% orphan rows, 22K service_category values, AWP incorrectly invalid |
| 2. What is actual spend? | `tbl_financial_exposure` | 172 rows / ~32% of providers | 68% of providers have no spend data |
| 3. What are escalation terms? | `tbl_rate_escalators` | 104 rows / 19.6% of providers | 80% of providers have no escalation data |
| 4. What-if simulation? | `tbl_repricing_scenarios` | 7,600 rows / all providers | 0 code references — completely invisible |

**Key missing link**: Steps 2 and 3 (exposure and escalators) are not joined to each other or to Step 1. A query like "which providers have escalation caps above 5% AND spend above $50M?" requires a JOIN between `tbl_rate_escalators` and `tbl_financial_exposure` on `provider_id`. This JOIN exists in neither the application nor any documented query pattern. The chain exists only in theory.

**Financial risk of the gap**: For the ~172 providers with spend data and the subset with escalation data, BSC has no automated way to compute maximum annual cost increase. This is arguably the single highest-value analytical question the system should answer.

---

## B5 — Free Text Contamination in Key Categorical Dimensions

**Issue**: The same categorical dimension (service category) appears in multiple tables, but as free text with no normalization:

| Table | Column | Distinct values | Impact |
|---|---|---|---|
| `tbl_contract_rates_all` | `service_category` | 22,045 | Cannot filter by service; rates are not aggregatable by service |
| `tbl_dofr_matrix_extracted` | `service_category` | Unknown (estimated high) | DOFR assignments cannot be matched to rate rows by service |
| `tbl_contract_rates_all` | `network` | 605 | Cannot group by network |
| `tbl_contract_rates_all` | `program` | 608 | Already normalized into `program_normalized`; raw column should be dropped |

**Cross-table consequence**: The most natural analytical JOIN — "for service X, who is financially responsible (DOFR) and what is the contracted rate?" — is structurally broken because `service_category` in `tbl_dofr_matrix_extracted` and `service_category` in `tbl_contract_rates_all` are both free text and will almost never match exactly. The only way to answer this question today is via full-text matching in `tbl_vs_unified_ready`, which is a semantic approximation, not a precise relational join.

---

## B6 — No Unified Temporal Consistency Pattern

**Issue**: Each table applies "current vs historical" filtering differently. A developer building a cross-table query must remember a different filter pattern for each table:

| Table | How to get "current" rows |
|---|---|
| `tbl_contract_rates_all` | `WHERE status = 'current'` (do NOT use `is_latest_version = true`) |
| `tbl_vs_unified_ready` | `WHERE is_current = true` |
| `tbl_contract_documents_master` | `WHERE contract_status IN ('ACTIVE', 'ACTIVE_NO_EXPIRY')` |
| `tbl_dofr_matrix_extracted` | No version filter exists — all rows returned regardless of amendment age |
| `tbl_delegation_matrix` | `WHERE is_active = true` |
| `tbl_contract_clauses` | No version filter — must JOIN to docs master to determine currency |
| `tbl_compliance_tracking` | No version filter — assessed_at timestamp only |
| `fact_supersession` | `WHERE confidence >= 0.7` (not the same as "current") |

**Why it matters**: A 6-table JOIN that forgets any one of these filters will silently return data from superseded documents. The DOFR case is the most dangerous — if a provider's DOFR assignment changed in a 2024 amendment but the query returns all rows, it will return both the old and new assignment. The agent will potentially answer a DOFR question with the wrong (superseded) responsible party.

**The correct design** would be a single `is_current BOOLEAN` column in every table, set via trigger when a new amendment is ingested. Currently, maintaining temporal consistency requires knowing the table-specific pattern above.

---

## B7 — Compliance Status Has No Structural Link to Clause Evidence

**Issue**: `tbl_compliance_tracking` records compliance status (COMPLIANT/PARTIAL/UNKNOWN) per provider-regulation pair. The status is derived from VS chunk matching at extraction time. However:

- The structured clause text is in `tbl_contract_clauses` (which has 21 categories including Knox-Keene-relevant clauses)
- There is **no FK or derivation link** between `tbl_compliance_tracking` and `tbl_contract_clauses`
- Compliance status and clause content can contradict each other without any alert

**Example**: A provider could have `compliance_status = 'COMPLIANT'` for Knox-Keene in `tbl_compliance_tracking` AND have `clause_status = 'ABSENT'` for a relevant clause in `tbl_contract_clauses`. These two facts about the same provider would coexist silently. The application would answer "Provider X is Knox-Keene compliant" (from compliance_tracking) while the clause evidence says otherwise.

**Verification path**: To audit this, you would need:
```sql
SELECT ct.provider_id, ct.compliance_status,
       cc.clause_category, cc.clause_status
FROM dev_adb.raw.tbl_compliance_tracking ct
JOIN dev_adb.raw.tbl_contract_clauses cc
  ON cc.provider_id = ct.provider_id
WHERE ct.regulation = 'Knox-Keene'
  AND cc.clause_category IN ('UM_PRIOR_AUTH', 'MEDICAL_MANAGEMENT', 'CREDENTIALING')
HAVING MAX(CASE WHEN ct.compliance_status = 'COMPLIANT' AND cc.clause_status = 'ABSENT' THEN 1 ELSE 0 END) = 1
```
This query is not run anywhere in the current application.

---

## B8 — Risk Scoring Inputs Are Systematically Incomplete

**Issue**: `tbl_contract_risk_scores` computes a composite risk score across 19 sub-dimensions. At least 5 of those 19 dimensions depend on data that is known to be incomplete or stale:

| Risk sub-dimension | Depends on | Known incompleteness |
|---|---|---|
| `expiration_risk` | `tbl_contract_documents_master.expiration_date_parsed` | 4,214 ACTIVE_NO_EXPIRY rows — no date to evaluate expiration proximity |
| `compliance_gap` | `tbl_compliance_tracking.compliance_status` | UNKNOWN/PARTIAL status on many rows; no refresh trigger |
| `clause_gap` | `tbl_genie_provider_profile` offset/dofr/ipa flags | B-5 DEBT: flags have known mismatches with actual clause table |
| `fin_risk` | `tbl_financial_exposure` | Only 32% provider coverage; most values are PROXY not CLAIMS |
| Score freshness | `scored_at` | No auto-refresh; score becomes stale after any source table change |

**Consequence**: The 7 MONITOR-tier providers identified by the risk model are computed from incomplete inputs. It is plausible that providers scored LOW would be MEDIUM or MONITOR if: (a) their missing expiration dates were known, (b) their compliance gaps were correctly identified, or (c) their financial exposure was based on CLAIMS not PROXY. Conversely, some MONITOR providers may be over-scored if PROXY spend inflates `fin_risk`. The risk model's outputs cannot be fully trusted until these gaps are filled.

---

## B9 — Alert/Deadline Subsystem Completely Isolated from Application

**Issue**: Three tables form a complete, internally consistent risk alerting subsystem — but the entire subsystem is invisible to users:

```
tbl_contract_risk_scores → tbl_contract_deadlines → tbl_alert_queue
        (272 rows)                (713 rows)              (351 rows)
           0 refs                   0 refs                  0 refs
```

The chain is: risk scores identify high-risk providers → deadlines track specific action dates per provider → alerts queue actionable notifications. The FK chain exists (`tbl_alert_queue.source_deadline_id` → `tbl_contract_deadlines.deadline_id`).

**What is being missed**: 229 CRITICAL alerts, 125 CRITICAL deadlines, 102 EXPIRED deadlines are sitting in the database right now with no mechanism to surface them to contract management staff. The entire Phase 10B Cluster A is required to address this.

**Additional problem**: Even when these tables ARE exposed, the alert lifecycle is incomplete. All 351 alerts are stuck at `status = 'NEW'`. There are no ACKNOWLEDGED, IN_PROGRESS, or RESOLVED states implemented in the schema. Any alerting UI built on this data would have no way for users to indicate they have actioned an alert.

---

## B10 — Schema Registry Covers Only 29/35 Tables

**Issue**: `dim_table_schema` (the agent's SQL generation metadata store) has entries for 29 tables but the production model has 35 tables. The 6 missing tables are:

| Table | Why it matters that it's missing |
|---|---|
| `tbl_contract_risk_scores` | Agent cannot generate SQL against risk scores |
| `tbl_contract_deadlines` | Agent cannot find `days_until_action` column |
| `tbl_alert_queue` | Agent cannot query alerts |
| `fact_supersession` | Agent cannot query amendment graph |
| `tbl_provider_system_membership` | Agent cannot query system membership |
| `dim_health_system` | Agent cannot query health system list |

**Consequence**: Even after Phase 10B exposes these tables through application tools, the agent's SQL generation layer will not have metadata for them. A user asking "show me CRITICAL alerts" in natural language will cause the SQL generator to fail with a schema lookup miss. `dim_table_schema` must be updated in parallel with any application exposure work.

---

## B11 — Extraction Provenance Has No Provider Scope

> **RESOLVED — Phase 10B-6 (2026-07-20)**: `provider_id` was added to `tbl_extraction_provenance`. Current state: 0 nulls, 1,395 distinct providers — direct `JOIN ON provider_id` is now valid. The C3.5 solution below was implemented as part of Phase 10B-6 ProvenanceTool creation. Section D1.6 B11 live-validation verdict updated to reflect this. The analysis below is retained for historical context.

**Issue**: `tbl_extraction_provenance` (15,368 rows) is the audit trail for every extracted field in the system. It covers clauses (7,777), notifications (1,934), compliance (1,897), delegation (1,599), DOFR (1,163), quality (894), and escalators (104). But it has **no `provider_id` column**.

**Impact**: To answer "how confident is the system in its data about Provider X?", you would need:
```sql
SELECT ep.*
FROM dev_adb.raw.tbl_extraction_provenance ep
JOIN dev_adb.raw.tbl_contract_clauses cc
  ON cc.clause_id = ep.target_record_id
 WHERE ep.target_table = 'tbl_contract_clauses'
   AND cc.provider_id = '<id>'
```
This pattern requires a different JOIN for every table covered by provenance. In practice, no application code does this. The result: extraction confidence and human verification status are completely invisible, even though they exist in the database. Any answer the agent gives could be based on low-confidence LLM extraction that has `confidence_score = 0.2` and `human_verified = false` — the user has no way to know.

---

## B12 — Health System Analytics Chain Is Structurally Incomplete

**Issue**: A major BSC use case is system-level contract analysis: "what are all BSC's contracts with Dignity Health, and what is the total spend?" The chain required is:

```
dim_health_system → tbl_provider_system_membership → dim_provider_canonical → various tables
    (20 rows)               (112 rows)                    (531 rows)
      0 refs                   0 refs
```

Beyond the visibility problem, the data gaps make this chain unreliable even if it were exposed:
- Only 112/304 providers (36.8%) are mapped to a health system
- The JOIN key is `system_id` (documented), but one wrong column name (`health_system_id`) silently returns NULLs
- Kaiser Permanente has 0 providers mapped (expected as closed panel, but must be documented to avoid confusion)
- There is no way to do "all Dignity Health" rate analysis because 63% of providers are unmapped

**Financial consequence**: If a BSC analyst queries "total contracted spend for Sutter Health" they would get a severely undercounted result (only mapped providers) with no warning that 63% of the system's providers may be missing.

---

## B13 — Quality and Incentive Programs Disconnected from Rate Model

**Issue**: `tbl_quality_performance` tracks P4P, HEDIS, VALUE_BASED, and WITHHOLD program participation. `tbl_contract_rates_all` tracks base rates. These two tables are completely disconnected — there is no FK or derivation link. This means:

- A provider's total effective payment = base rate + quality bonuses. Only the base rate is queryable.
- The quality bonus component (even when non-NULL, i.e., WITHHOLD amounts) is in a separate table that is never joined to the rate model.
- For P4P/VALUE_BASED providers, the formula_text in `tbl_quality_performance` contains the bonus formula, but it's not parsed into numeric values (P2-H DEBT).

**Answer distortion**: If a user asks "what does BSC pay for inpatient services at Provider X?" and Provider X has a P4P program with a 3% performance bonus, the answer will be the base rate only — missing the 3% bonus exposure. For VALUE_BASED contracts, the miss could be significantly larger. The system structurally underestimates total payment obligations for any provider in a quality program.

---

## B14 — IPA Delegation Creates Unmapped Financial Responsibility Gaps

**Issue**: 120 providers have `ipa_delegation_status = 'HAS'` in `tbl_genie_provider_profile`. These providers have delegated clinical/administrative functions to IPAs. The delegation scope is in `tbl_delegation_matrix`. But:

- `tbl_dofr_matrix_extracted` may contain DOFR rows for the IPA-delegated provider that predate the delegation, assigning responsibility to "group_responsible" when in reality the IPA now holds that responsibility.
- There is no table or column that maps "delegated_function + IPA provider" to "financial responsibility update".
- The DOFR model and the IPA delegation model are parallel but unlinked: DOFR says who is responsible, delegation says who performs the function, but neither is updated when the other changes.

**Clinical risk**: A prior authorization decision for a delegated IPA provider may be routed based on a stale DOFR assignment that doesn't account for the current delegation structure.

---

## B15 — dim_table_schema Stale Entries Cause Silent SQL Generation Failures

**Issue**: Even for the 29 tables that ARE in `dim_table_schema`, schema entries may be stale. Key confirmed discrepancies:

| Schema entry | Reality |
|---|---|
| Any entry for `tbl_contract_hierarchy.amendment_order` | Column does NOT exist (use `sequential_order`) |
| `tbl_contract_deadlines.deadline_date` | Column does NOT exist (use `event_date`) |
| `tbl_contract_deadlines.days_until_deadline` | Column does NOT exist (use `days_until_action`) |
| `tbl_contract_rates_all.amendment_order` | Type shown as INT? Reality is STRING |

If `dim_table_schema` contains any of these wrong entries, every SQL the agent generates against these tables may fail — silently producing empty results or throwing column not found errors. There is no automated validation job that checks `dim_table_schema` entries against live table schemas using `DESCRIBE TABLE`.

---

## B-Summary — Data Model Structural Gaps

| # | Gap category | Severity | Tables involved |
|---|---|---|---|
| B1 | Provider identity fragmentation | HIGH | dim_provider_canonical, tbl_genie_provider_profile, all group tables |
| B2 | Two unlinked supersession systems | CRITICAL | fact_supersession, tbl_contract_rates_all |
| B3 | Amendment chain broken across 4 tables | CRITICAL | rates_all, hierarchy, timeline, fact_supersession |
| B4 | No end-to-end financial chain | CRITICAL | exposure, escalators, repricing, rates_all |
| B5 | Free text in shared categorical dimensions | HIGH | rates_all, dofr_matrix, vs_unified_ready |
| B6 | No unified temporal filter pattern | HIGH | All 35 tables |
| B7 | Compliance status not linked to clauses | HIGH | compliance_tracking, contract_clauses |
| B8 | Risk scoring inputs incomplete | HIGH | risk_scores, exposure, compliance, profile flags |
| B9 | Alert/deadline subsystem invisible | CRITICAL | risk_scores, deadlines, alert_queue |
| B10 | Schema registry missing 6 tables | HIGH | dim_table_schema |
| B11 | Extraction provenance has no provider scope | ~~HIGH~~ **RESOLVED** (Phase 10B-6) | extraction_provenance |
| B12 | Health system chain structurally incomplete | HIGH | dim_health_system, provider_system_membership |
| B13 | Quality programs disconnected from rate model | HIGH | quality_performance, rates_all |
| B14 | IPA delegation and DOFR unlinked | MEDIUM | delegation_matrix, dofr_matrix_extracted |
| B15 | dim_table_schema stale entries | HIGH | dim_table_schema, contract_hierarchy, contract_deadlines |

*Section B complete. 15 cross-table architectural issues documented. 2026-07-13.*

---
---

# SECTION C — Solutions & Remediation Plan

**Purpose**: Validated fixes for the 81 individual table issues (Section A) and 15 data model issues (Section B). Each solution is assessed for: whether it genuinely solves the problem, what it does NOT solve, and any unintended side effects.

**Priority tiers**:
- **P0 — Correctness**: Fixes active answer errors or silent data corruption. Blocking for production trust.
- **P1 — Coverage**: Unlocks currently invisible data. High business value, low regression risk.
- **P2 — Architecture**: Structural improvements that prevent future issues. Lower urgency but compound ROI.

---

## C1 — P0 Correctness Fixes

### C1.1 — Fix is_latest_version flag (Issue #3)

**Solution**:
```sql
UPDATE dev_adb.raw.tbl_contract_rates_all
SET is_latest_version = false
WHERE status = 'superseded'
  AND is_latest_version = true;
```

**Does this solve it?** Yes, fully. The flag will be correct for all 42,527 conflicting rows. The fix is idempotent — re-running it on a correct table is a no-op.

**Does NOT solve**: The root cause (extraction pipeline not setting this flag correctly on new ingestions). Add a pipeline post-step to enforce `is_latest_version = (status = 'current')` after every MERGE.

**Side effects**: Any application code using `is_latest_version = true` as a filter will now return the correct (smaller) set. Test all agent SQL patterns that may use this flag.

**Validation query**:
```sql
SELECT COUNT(*) FROM dev_adb.raw.tbl_contract_rates_all
WHERE status = 'superseded' AND is_latest_version = true;
-- Must return 0 after fix
```

---

### C1.2 — Fix AWP_DISCOUNT is_valid_rate flag (Issue #7)

**Solution**: AWP_DISCOUNT rates are negative percentages (e.g., -16 means 16% below AWP). The plausibility engine incorrectly applies the positive-number bounds check to these rows.

```sql
UPDATE dev_adb.raw.tbl_contract_rates_all
SET is_valid_rate = true
WHERE rate_unit = 'AWP_DISCOUNT'
  AND rate_numeric BETWEEN -100 AND 0
  AND is_valid_rate = false;
```

**Does this solve it?** Yes for the 25 existing rows. The deeper fix is in the plausibility engine pipeline: add a rate_unit-specific bounds check branch.

**Does NOT solve**: If new AWP_DISCOUNT rows are ingested, they will be incorrectly marked invalid again until the pipeline is fixed.

**Validation query**:
```sql
SELECT rate_unit, is_valid_rate, COUNT(*)
FROM dev_adb.raw.tbl_contract_rates_all
WHERE rate_unit = 'AWP_DISCOUNT'
GROUP BY rate_unit, is_valid_rate;
-- Must show is_valid_rate = true for all 25 AWP_DISCOUNT rows
```

---

### C1.3 — Fix dim_table_schema stale entries (Issue #79, B15)

**Solution**: Audit and correct `dim_table_schema` for the three confirmed wrong column names:

```sql
-- Remove tbl_contract_hierarchy.amendment_order if it exists (column does not exist)
DELETE FROM dev_adb.raw.dim_table_schema
WHERE table_name = 'tbl_contract_hierarchy'
  AND column_name = 'amendment_order';

-- Fix tbl_contract_deadlines wrong column names if present
UPDATE dev_adb.raw.dim_table_schema
SET column_name = 'event_date',
    column_description = 'Date when the contract deadline event occurs. Use this column (NOT deadline_date which does not exist).'
WHERE table_name = 'tbl_contract_deadlines'
  AND column_name = 'deadline_date';

UPDATE dev_adb.raw.dim_table_schema
SET column_name = 'days_until_action',
    column_description = 'Days until action required. Negative = overdue. Use this column (NOT days_until_deadline which does not exist).'
WHERE table_name = 'tbl_contract_deadlines'
  AND column_name = 'days_until_deadline';
```

**Does this solve it?** Yes for the confirmed wrong entries. The complete fix requires running `DESCRIBE TABLE` against all 35 production tables and comparing results to `dim_table_schema` entries.

**Validation**: After each UPDATE, run `SELECT * FROM dim_table_schema WHERE table_name IN ('tbl_contract_hierarchy', 'tbl_contract_deadlines')` and visually verify column names match live schemas.

---

### C1.4 — Resolve rate_category naming duplication (Issue #2)

**Solution**: Normalize the four duplicated category names into two canonical values:

```sql
UPDATE dev_adb.raw.tbl_contract_rates_all
SET rate_category = 'inpatient_per_diem'
WHERE rate_category = 'inpatient_per_diem_rates';

UPDATE dev_adb.raw.tbl_contract_rates_all
SET rate_category = 'inpatient_case_rate'
WHERE rate_category = 'inpatient_case_rates';
```

**Does this solve it?** Yes for the known duplicates. Run `SELECT DISTINCT rate_category FROM tbl_contract_rates_all ORDER BY 1` after to verify no other pairs remain.

**Does NOT solve**: The service_category problem (22,045 values) — that requires an LLM classification pass, not a simple UPDATE.

**Side effects**: Any application code, reports, or dashboards that filter on `rate_category = 'inpatient_per_diem_rates'` will stop matching. Search all query files for the old category names before deploying.

---

### C1.5 — Add is_current filter to tbl_dofr_matrix_extracted queries (B6 partial fix)

**Solution**: Until a proper `is_current` column is added, filter DOFR queries to the latest document per provider using a subquery:

```sql
-- Safe DOFR query pattern
SELECT d.service_category, d.subcategory,
       d.group_responsible, d.hospital_responsible, d.health_plan_responsible
FROM dev_adb.raw.tbl_dofr_matrix_extracted d
INNER JOIN (
  SELECT provider_id, MAX(source_filename) AS latest_filename
  FROM dev_adb.raw.tbl_dofr_matrix_extracted
  GROUP BY provider_id
) latest ON d.provider_id = latest.provider_id
        AND d.source_filename = latest.latest_filename
WHERE d.provider_id = '<id>'
```

**Does this solve it?** Partially. MAX(source_filename) is a heuristic proxy for "latest document" — it works when filenames encode version order, but not always. The correct fix is adding an `is_current BOOLEAN` column.

**Does NOT solve**: The root data model issue. Document this pattern in the agent's SQL generation hints immediately while the schema fix is planned.

---

## C2 — P1 Exposure Fixes (Unlock Invisible Data)

### C2.1 — Add 6 missing tables to dim_table_schema (Issue #78, B10)

**Solution**: Insert schema entries for the 6 tables missing from the runtime registry:

```sql
-- Template for each missing table (run DESCRIBE TABLE first to get accurate columns)
-- Tables to add: tbl_contract_risk_scores, tbl_contract_deadlines, tbl_alert_queue,
--                fact_supersession, tbl_provider_system_membership, dim_health_system

INSERT INTO dev_adb.raw.dim_table_schema
  (schema_id, table_name, column_name, data_type, column_description, is_primary_key, is_foreign_key, foreign_key_table)
SELECT
  UUID() AS schema_id,
  'tbl_contract_deadlines' AS table_name,
  column_name,
  data_type,
  CASE column_name
    WHEN 'event_date'        THEN 'Date when deadline event occurs. NOT deadline_date.'
    WHEN 'action_required_by' THEN 'Date when action must be taken.'
    WHEN 'days_until_action' THEN 'Days until action. Negative = overdue. NOT days_until_deadline.'
    WHEN 'priority_tier'     THEN 'CRITICAL, HIGH, MEDIUM, LOW, EXPIRED'
    ELSE column_name
  END AS column_description,
  (column_name = 'deadline_id') AS is_primary_key,
  (column_name = 'provider_id') AS is_foreign_key,
  CASE WHEN column_name = 'provider_id' THEN 'dim_provider_canonical' ELSE NULL END AS foreign_key_table
FROM (
  DESCRIBE TABLE dev_adb.raw.tbl_contract_deadlines
) cols
WHERE NOT EXISTS (
  SELECT 1 FROM dev_adb.raw.dim_table_schema s
  WHERE s.table_name = 'tbl_contract_deadlines' AND s.column_name = cols.col_name
);
```
Repeat for each of the 6 missing tables.

**Does this solve it?** Yes — once all 6 tables are in the registry, the agent can generate SQL against them. This must be done before Phase 10B Cluster A is implemented.

**Does NOT solve**: The need for an automated sync job (C3.1) — manual inserts will go stale again on the next schema change.

---

### C2.2 — Expose alert/deadline/risk chain (Issue #61, #63, #65, B9)

**Solution**: Phase 10B Cluster A directly addresses this. The specific implementation steps are:

1. Add `RiskAlertTool` to the agent tools list: queries `tbl_contract_risk_scores` WHERE `risk_tier IN ('MONITOR', 'MEDIUM')` joined to `tbl_contract_deadlines` WHERE `priority_tier = 'CRITICAL'`.
2. Add alert lifecycle columns to `tbl_alert_queue`: `acknowledged_by STRING`, `acknowledged_at TIMESTAMP`, `resolved_at TIMESTAMP`, `resolution_note STRING`.
3. Add a REST endpoint `GET /api/v1/alerts` that returns all NEW + CRITICAL alerts sorted by `days_until_action`.
4. Add alert lifecycle `PATCH /api/v1/alerts/{alert_id}` to allow acknowledging and resolving.

**Does this solve it?** Yes for exposure. The deeper data quality issues (stale risk scores, incomplete financial exposure) remain but the data that exists IS actionable and should be surfaced immediately.

**Validation**: After implementing, query `SELECT COUNT(*) FROM tbl_alert_queue WHERE alert_status = 'NEW' AND severity = 'CRITICAL'` should return 229. After users acknowledge alerts, this number should decrease.

---

### C2.3 — Expose clause text via ClauseRetrieval tool (Issue #40, Phase 10B Cluster E)

**Solution**: The `tbl_contract_clauses.clause_text` column contains exact contract language that is currently never read. The fix is a targeted tool addition:

```python
# New tool: ClauseTextTool
# Input: provider_id, clause_category (from the 21 categories)
# Query:
SELECT clause_category, clause_status, clause_text, source_filename
FROM dev_adb.raw.tbl_contract_clauses
WHERE provider_id = :provider_id
  AND clause_category = :clause_category
  AND clause_status = 'HAS'
ORDER BY source_filename DESC
LIMIT 5
```

**Does this solve it?** Yes for the "show me the clause text" use case. The 21-category vocabulary must be communicated to the agent prompt so it maps user natural language to the correct category value.

**Does NOT solve**: The deviation analysis gap in `tbl_clause_deviations` (that requires schema extension — C3.3).

---

### C2.4 — Expose financial intelligence chain (Issues #15, #23, #27, #30, B4)

**Solution**: Three separate tool exposures required:

1. **FinancialExposureTool**: Queries `tbl_financial_exposure` with explicit coverage caveat ("Coverage: X of 531 providers").
2. **EscalationRiskTool**: Queries `tbl_rate_escalators` joined to `tbl_financial_exposure` on `provider_id` to compute `max_annual_exposure_increase = contracted_spend * cap_pct / 100`.
3. **RepricingTool**: Queries `tbl_repricing_scenarios` with a staleness check (`WHERE simulated_at >= '2026-07-12'` to filter pre-Phase-9 scenarios).

**Does this solve it?** Yes for exposure. The data quality gaps (19.6% escalation coverage, 32% financial exposure coverage) remain but users will at least see what exists AND will see an explicit coverage warning.

**Validation**: For EscalationRiskTool, validate the math: `cap_pct * contracted_spend / 100` for a known provider and verify the result is plausible.

---

### C2.5 — Expose health system analytics chain (Issue #57-60, B12)

**Solution**: Add `SystemMembershipTool` that:
1. Accepts a health system name (e.g., "Dignity Health")
2. Joins `dim_health_system` (on `LOWER(system_name) LIKE LOWER('%{input}%')`) to `tbl_provider_system_membership` on `system_id`
3. Returns all providers in that system with their profiles and rates summary

**Critical join fix required** in all queries: use `system_id` (NOT `health_system_id`) as the FK column. Document this in the tool's SQL template.

**Does this solve it?** Partially. Only 36.8% of providers are mapped. The tool must clearly state: "Showing X providers confirmed in this system. Note: not all system members may be mapped."

**Does NOT solve**: The 63% unmapped providers. Expanding coverage requires re-running the name_patterns matching in Phase 3 Task 3.4 against the full canonical provider list.

---

### C2.6 — Expose fact_supersession for amendment chain queries (Issue #20, B2)

**Solution**: Add `AmendmentChainTool` that uses `fact_supersession` (not the fragile string parsing of `superseded_by` in rates):

```sql
SELECT fs.superseded_filename, fs.superseding_filename,
       fs.supersession_type, fs.superseding_effective_date,
       fs.rate_change_pct, fs.confidence, fs.change_summary
FROM dev_adb.raw.fact_supersession fs
JOIN dev_adb.raw.tbl_contract_documents_master d
  ON d.source_filename = fs.superseding_filename
WHERE d.provider_id = :provider_id
  AND fs.confidence >= 0.7
ORDER BY fs.superseding_effective_date
```

**Does this solve it?** Solves the exposure gap. The confidence >= 0.7 filter ensures only reliable edges are returned.

**Does NOT solve**: The fundamental B2 gap (two unlinked supersession systems). That requires adding a `supersession_id FK` to `tbl_contract_rates_all` (C3.2).

---

## C3 — P2 Architectural Fixes

### C3.1 — Automated dim_table_schema sync job

**Solution**: Create a scheduled notebook that runs weekly and syncs `dim_table_schema` from live `DESCRIBE TABLE` output:

```python
for table_name in ALL_35_TABLES:
    live_schema = spark.sql(f'DESCRIBE TABLE dev_adb.raw.{table_name}').collect()
    # Compare to dim_table_schema entries
    # INSERT new columns, UPDATE changed types, DELETE dropped columns
    # Preserve human-written column_descriptions for existing entries
```

**Does this solve it?** Yes, fully. After implementation, `dim_table_schema` will never be more than 7 days stale.

**Does NOT solve**: Column descriptions — the sync job should only update `data_type`, not overwrite human-written `column_description` values.

---

### C3.2 — Bridge the two supersession systems (B2)

**Solution**: Add `supersession_id` column to `tbl_contract_rates_all` as a FK to `fact_supersession`:

```sql
-- Step 1: Add the column
ALTER TABLE dev_adb.raw.tbl_contract_rates_all
ADD COLUMN supersession_id_fk STRING;

-- Step 2: Backfill from superseded_by string by matching to fact_supersession
UPDATE dev_adb.raw.tbl_contract_rates_all r
SET supersession_id_fk = fs.supersession_id
FROM dev_adb.raw.fact_supersession fs
WHERE REGEXP_EXTRACT(r.superseded_by, 'src:(.+)

---

---
, 1) = fs.superseding_filename
  AND r.status = 'superseded'
  AND r.superseded_by IS NOT NULL;
```

**Does this solve it?** Partially. The backfill will only work for the 160,487 rows with populated `superseded_by`. The 163,930 NULL rows cannot be backfilled without knowing which document superseded them.

**Does NOT solve**: The 163,930 superseded rows with no `superseded_by` pointer (Issue #4). Those require the Phase 2 B-2 superseded_by backfill logic (DEBT item).

---

### C3.3 — Fix amendment chain ordinal (B3) — Phase 7 scope

**Solution**: This is the Phase 7 priority item from the custom instructions. The fix requires:

1. **Redesign the broken_chain parser**: Instead of using `_vN` filename suffix (which is REVISION not AMENDMENT), derive `sequential_order` from:
   a. Explicit amendment ordinal in filename (e.g., `Amendment_3`, `Amend_III` — requires roman numeral parser P3-D2)
   b. Effective date ordering when ordinals are absent
   c. `fact_supersession` edge ordering as a fallback

2. **Type-unify amendment_order across all tables**: `tbl_contract_rates_all.amendment_order` is STRING; `tbl_contract_hierarchy.sequential_order` is INT; `tbl_rate_escalators.amendment_order` is INT (correctly typed). All three should converge on INT with the same semantics.

**Does this solve it?** Yes, IF the new parser correctly identifies amendment position. The Phase 6 postmortem showed the `_vN` heuristic is wrong for 47.84% of chains. Any new approach must be validated against a ground-truth sample of known amendment sequences before bulk update.

**Validation benchmark**: Select 20 providers where the full amendment history is known (from contract documents). Verify the new `sequential_order` assigns 1, 2, 3... in correct chronological order.

---

### C3.4 — Add is_current flag to DOFR, delegation, and clauses tables (B6)

**Solution**: Add an `is_current BOOLEAN` column to the three tables that currently have no temporal filter:

```sql
-- Add to tbl_dofr_matrix_extracted
ALTER TABLE dev_adb.raw.tbl_dofr_matrix_extracted ADD COLUMN is_current BOOLEAN DEFAULT false;

-- Populate: mark rows from current documents as current
UPDATE dev_adb.raw.tbl_dofr_matrix_extracted d
SET is_current = true
WHERE EXISTS (
  SELECT 1 FROM dev_adb.raw.tbl_contract_documents_master m
  WHERE m.source_filename = d.source_filename
    AND m.contract_status IN ('ACTIVE', 'ACTIVE_NO_EXPIRY')
);
```

Apply the same pattern to `tbl_contract_clauses` and `tbl_delegation_matrix`.

**Does this solve it?** Yes for the three specific tables. The broader B6 issue (each table has different "current" semantics) requires a data model governance decision: standardize on `is_current` for all fact tables.

**Side effects**: After setting `is_current`, all application queries to these tables should add `WHERE is_current = true`. Update the agent's SQL generation hints and `dim_table_schema` entries accordingly.

---

### C3.5 — Add provider_id to tbl_extraction_provenance (Issue #76, B11)

> **IMPLEMENTED — Phase 10B-6 (2026-07-20)**: This solution was applied as part of Phase 10B-6 ProvenanceTool creation. `provider_id` is now present in `tbl_extraction_provenance` (0 nulls, 1,395 distinct). The SQL below is the reference implementation that was executed.

**Solution**: Denormalize `provider_id` into the provenance table:

```sql
-- Step 1: Add column
ALTER TABLE dev_adb.raw.tbl_extraction_provenance
ADD COLUMN provider_id STRING;

-- Step 2: Backfill from each source table
UPDATE dev_adb.raw.tbl_extraction_provenance ep
SET provider_id = cc.provider_id
FROM dev_adb.raw.tbl_contract_clauses cc
WHERE ep.target_table = 'tbl_contract_clauses'
  AND ep.target_record_id = cc.clause_id;
-- Repeat for each table covered by provenance
```

**Does this solve it?** Yes. After backfill, `WHERE provider_id = '<id>'` will work directly on `tbl_extraction_provenance` without joins. The population is deterministic — each record has exactly one source table + record_id.

---

### C3.6 — service_category normalization (Issue #1, B5)

**Solution**: The 22,045 distinct `service_category` values in `tbl_contract_rates_all` cannot be fixed with SQL rules alone. The correct approach is:

1. Run a one-time LLM classification pass: for each distinct `service_category` value, map it to one of ~150 canonical service categories.
2. Store the mapping in a new lookup table `tbl_service_category_map (raw_value STRING, canonical_category STRING, lob STRING)`.
3. Add a `service_category_normalized STRING` column to `tbl_contract_rates_all` populated from the lookup.
4. Do NOT overwrite the original `service_category` — preserve it for traceability.

**Does this solve it?** Yes, once the classification pass is run. The lookup table approach means the normalization can be updated as new category values appear without re-running the LLM.

**Validation**: After normalization, `SELECT COUNT(DISTINCT service_category_normalized) FROM tbl_contract_rates_all` should return ≤ 200. Spot-check that "Physical Therapy", "PT", "Physical therapy services", "PHYSICAL_THERAPY" all map to a single canonical value.

---

### C3.7 — Add NOT NULL constraints and a surrogate PK to tbl_contract_rates_all (Issues #6, #13)

**Solution**: Delta Lake does not support column-level NOT NULL constraints directly. The equivalent enforcement pattern is:

1. Add a `rate_id` BIGINT IDENTITY column (Spark 3.4+ GENERATED ALWAYS AS IDENTITY).
2. Add a pre-write data quality check in the pipeline using Great Expectations or a simple assertion:
   ```python
   assert df.filter(df.provider_id.isNull()).count() == 0, "NULL provider_id rows detected"
   assert df.filter(df.status.isNull()).count() == 0, "NULL status rows detected"
   ```
3. Add a Delta table constraint (available in DBR 7.4+):
   ```sql
   ALTER TABLE dev_adb.raw.tbl_contract_rates_all
   ADD CONSTRAINT provider_id_not_null CHECK (provider_id IS NOT NULL);
   ```

**Does this solve it?** Yes for new ingestions. Existing rows with NULL values (currently 0 for critical columns) will be caught on the next write attempt if a bad row tries to enter.

---

### C3.8 — Link compliance status to clause evidence (B7)

**Solution**: Create a materialized view or scheduled UPDATE that derives compliance status from clause evidence:

```sql
-- Derive Knox-Keene compliance from clause presence
MERGE INTO dev_adb.raw.tbl_compliance_tracking ct
USING (
  SELECT provider_id,
         CASE
           WHEN SUM(CASE WHEN clause_status = 'HAS' THEN 1 ELSE 0 END) >= 3 THEN 'COMPLIANT'
           WHEN SUM(CASE WHEN clause_status = 'HAS' THEN 1 ELSE 0 END) BETWEEN 1 AND 2 THEN 'PARTIAL'
           ELSE 'UNKNOWN'
         END AS derived_status
  FROM dev_adb.raw.tbl_contract_clauses
  WHERE clause_category IN ('UM_PRIOR_AUTH', 'MEDICAL_MANAGEMENT', 'CREDENTIALING')
  GROUP BY provider_id
) clause_evidence
ON ct.provider_id = clause_evidence.provider_id
   AND ct.regulation = 'Knox-Keene'
WHEN MATCHED AND ct.compliance_status != clause_evidence.derived_status THEN
  UPDATE SET ct.compliance_status = clause_evidence.derived_status,
             ct.assessed_at = current_timestamp();
```

**Does this solve it?** Partially. The mapping of clause categories to regulations requires domain knowledge (which clauses are relevant to Knox-Keene vs DMHC vs CMS_MA). A compliance expert must validate the mapping before this runs in production.

**Does NOT solve**: Cases where a provider's contract language says compliant but the clause schema says ABSENT. Those require human review.

---

## C4 — Prioritized Remediation Roadmap

### Immediate (P0) — fix before any new query exposure

| Fix ID | Action | Est. effort | Risk |
|---|---|---|---|
| C1.1 | Fix `is_latest_version` for 42,527 rows | 1 SQL statement | Low — idempotent |
| C1.2 | Fix AWP_DISCOUNT `is_valid_rate` flag | 1 SQL statement | Low — targeted |
| C1.3 | Fix `dim_table_schema` stale entries | 3 SQL statements | Low — metadata only |
| C1.4 | Normalize `rate_category` duplication | 2 SQL statements | Medium — check for downstream query references first |
| C1.5 | Add DOFR latest-document filter to agent queries | Prompt + SQL template update | Low |

### Short-term (P1) — complete before Phase 10B goes live

| Fix ID | Action | Est. effort | Risk |
|---|---|---|---|
| C2.1 | Add 6 missing tables to `dim_table_schema` | ~1 day (DESCRIBE + INSERT per table) | Low |
| C2.2 | Implement alert/deadline/risk exposure (Phase 10B Cluster A) | 3–5 days | Medium — schema changes to alert_queue |
| C2.3 | Add ClauseTextTool (Phase 10B Cluster E) | 1–2 days | Low |
| C2.4 | Expose financial intelligence chain | 2–3 days | Low — coverage caveats required |
| C2.5 | Expose health system analytics chain | 1–2 days | Low — explicit coverage caveat |
| C2.6 | Add AmendmentChainTool using fact_supersession | 1 day | Low |

### Medium-term (P2) — architectural improvements

| Fix ID | Action | Est. effort | Risk |
|---|---|---|---|
| C3.1 | Automated `dim_table_schema` sync job | 1 day (notebook + schedule) | Low |
| C3.2 | Bridge two supersession systems via FK | 2–3 days | Medium — schema ALTER on large table |
| C3.3 | Fix amendment chain ordinal (Phase 7) | 5+ days | High — requires parser redesign and ground-truth validation |
| C3.4 | Add `is_current` flag to DOFR/clauses/delegation | 2 days | Medium — pipeline updates required |
| C3.5 | Add `provider_id` to `tbl_extraction_provenance` | 1 day | Low |
| C3.6 | service_category normalization via LLM pass | 3–5 days | Medium — LLM classification quality must be validated |
| C3.7 | Add NOT NULL constraints + surrogate PK to rates table | 1 day | Low — pipeline assertion changes |
| C3.8 | Link compliance status to clause evidence | 2 days + domain review | High — requires compliance expert sign-off |

---

## C5 — Fix Validation Matrix

For each P0 fix, a validation query must return the expected result before the fix is considered complete:

| Fix | Validation query | Expected result |
|---|---|---|
| C1.1 | `SELECT COUNT(*) FROM tbl_contract_rates_all WHERE status='superseded' AND is_latest_version=true` | 0 |
| C1.2 | `SELECT is_valid_rate, COUNT(*) FROM tbl_contract_rates_all WHERE rate_unit='AWP_DISCOUNT' GROUP BY 1` | All rows is_valid_rate=true |
| C1.3 | `SELECT column_name FROM dim_table_schema WHERE table_name='tbl_contract_deadlines'` | event_date, action_required_by, days_until_action (NOT deadline_date/days_until_deadline) |
| C1.4 | `SELECT DISTINCT rate_category FROM tbl_contract_rates_all WHERE rate_category LIKE '%per_diem%'` | Only `inpatient_per_diem`, no `inpatient_per_diem_rates` |
| C2.1 | `SELECT COUNT(DISTINCT table_name) FROM dim_table_schema` | 35 (was 29) |
| C2.2 | `SELECT COUNT(*) FROM tbl_alert_queue WHERE severity='CRITICAL' AND alert_status='NEW'` | 229 initially; decreases as alerts are acknowledged |

---

## C6 — What These Fixes Do NOT Solve

Some issues are structural and require external inputs or long-term projects:

| Issue | Why it cannot be fixed by SQL/code alone |
|---|---|
| `service_category` 22,045 values (Issue #1) | Requires LLM classification pass — no deterministic normalization rule |
| NULL `expiration_date_parsed` on 4,214 docs (P3-D1 DEBT) | Requires OCR pipeline rerun on specific documents |
| `bonus_pct` NULL on P4P rows (P2-H DEBT) | Prose contracts; LLM extraction yielded 0 candidates |
| 163,930 superseded rows with no forward pointer (Issue #4) | Phase 2 B-2 backfill was computed but blocked; requires approval |
| `sequential_order` reflecting revision vs amendment order (Issue #37) | Parser redesign required; heuristic shortcuts will not hold |
| 80% of network with no escalation data (Issue #27) | Requires NLP pattern expansion for narrative escalation clauses |
| `tbl_financial_exposure` 68% gap (Issue #23) | Requires claims data integration or PMPM estimation for missing providers |
| 63% of providers unmapped to health systems (Issue #57) | Requires re-running name_patterns matching + manual review |
| `tbl_clause_deviations` has no actual deviation data (Issue #42) | Requires baseline clause comparison logic + schema extension |

---

# Section D — Live Validation Results (2026-07-13)

**Source**: Contract_Intelligence_Phase6_Pipeline_Hardening notebook (ID: 4434698321220001)  
**Cells executed**: Live Validation Setup → BATCH 1–7 → Live Validation Summary (cells 15–23)  
**Scope**: 41 unique checks against `dev_adb.raw` live data  
**Summary**: **31 CONFIRMED / 6 PARTIAL / 4 WRONG**

Each bullet shows: claimed value | actual value | verdict.

---

## D1 — Confirmed Findings (31)

All claimed values match live data exactly unless a note qualifies the match.

### D1.1 — tbl_contract_rates_all (Batch 1)

* **ISSUE_1 — service_category cardinality**: claimed 22,045 distinct values. Actual: **22,045**. CONFIRMED.
* **ISSUE_2 — rate_category duplication** (four overlapping values): inpatient_per_diem=82,088; inpatient_per_diem_rates=46,272; inpatient_case_rate=64,216; inpatient_case_rates=17,745. All four counts CONFIRMED.
* **ISSUE_3 — status/is_latest_version conflicts** (`status='superseded' AND is_latest_version=true`): claimed 42,527. Actual: **42,527**. CONFIRMED.
* **ISSUE_4 — superseded rows with null forward pointer** (`superseded_by IS NULL AND status='superseded'`): claimed 163,930. Actual: **163,930**. CONFIRMED.
* **ISSUE_5 — amendment_order stored as STRING**: live `DESCRIBE` shows `amendment_order | string`. CONFIRMED.
* **ISSUE_7 — AWP_DISCOUNT invalid rows** (`is_valid_rate=false AND rate_numeric < -0.5 AND rate_unit='AWP_DISCOUNT'`): claimed 25. Actual: **25**. CONFIRMED.
* **ISSUE_8 — zombie rate rows** (both `rate_text` and `rate_numeric` NULL): claimed 3,105. Actual: **3,105**. CONFIRMED.
* **ISSUE_9 — PMPM max rate exceeds $25,000 cap**: live max PMPM: **$71,113.00** (exceeds_cap=True). CONFIRMED.
* **ISSUE_10 — orphan provider_ids in rates vs dim_provider_canonical**: claimed 216 providers / 128,896 rows. Actual: **216 providers / 128,896 rows**. CONFIRMED. Top orphans: Mercy General Hospital (6,288 rows), Stanislaus Behavioral Health Center (4,667 rows), Queen Of The Valley Medical Center (4,230 rows).
* **ISSUE_13 — no primary key or surrogate key**: live: `constraints=0; surrogate_columns=[]`. CONFIRMED.

### D1.2 — tbl_financial_exposure / tbl_rate_escalators (Batch 2)

* **ISSUE_23 — tbl_financial_exposure row count**: claimed 172. Actual: **172** (provider_count=172 out of 531 canonical). CONFIRMED.
* **ISSUE_27 — tbl_rate_escalators row count**: claimed 104. Actual: **104** (provider_count=104 out of 531 canonical). CONFIRMED.
* **ISSUE_29 — tbl_rate_escalators has no rate_row_id FK column**: live column scan: `columns_present=[]` for rate_row_id. CONFIRMED.

### D1.3 — tbl_contract_hierarchy (Batch 3)

* **ISSUE_36 — hierarchy lacks amendment_order, has sequential_order**: live: `amendment_order_present=False; sequential_order_present=True`. CONFIRMED. Full hierarchy schema confirmed: contract_id, provider_id, parent_contract_id, contract_level, sequential_order (int), line_of_business, effective_date, expiration_date, contract_status, source_filename, document_type.

### D1.4 — Risk, Alert, and Deadline Tables (Batch 4)

* **ISSUE_61 — tbl_contract_risk_scores row count**: claimed 272 with LOW=239/MEDIUM=26/MONITOR=7. Actual: **272**; `risk_tier_distribution={'LOW': 239, 'MEDIUM': 26, 'MONITOR': 7}`. CONFIRMED.
* **ISSUE_63 — tbl_contract_deadlines structure**: claimed 713 rows; `event_date`, `action_required_by`, `days_until_action` present; `deadline_date`, `days_until_deadline` absent. Live: `row_count=713; required_present=['action_required_by', 'days_until_action', 'event_date']; forbidden_present=[]`. Priority distribution: LOW=273, CRITICAL=127, HIGH=122, EXPIRED=102, MEDIUM=89. CONFIRMED. Note: live CRITICAL count is 127 vs 125 in the Group 5 summary row — minor summary update needed.
* **ISSUE_64 — querying deadline_date raises column error**: live: `[UNRESOLVED_COLUMN.WITH_SUGGESTION] ... 'deadline_date' cannot be resolved. Did you mean: 'deadline_id', 'deadline_type', 'event_date', 'notice_days' ...`. CONFIRMED.
* **ISSUE_65 — tbl_alert_queue row count**: claimed 351 with CRITICAL|NEW=229, HIGH|NEW=34, MEDIUM|NEW=88. Actual: **351**; distribution matches exactly. CONFIRMED.

### D1.5 — dim_table_schema (Batch 5)

* **ISSUE_78 (table count) — dim_table_schema distinct table count**: claimed 29. Actual: **29**. CONFIRMED. All 29 confirmed registered: dim_health_system, dim_provider_canonical, dim_table_schema, fact_retrieval_telemetry, fact_supersession, tbl_agent_sessions, tbl_alert_queue, tbl_clause_deviations, tbl_compliance_tracking, tbl_contract_clauses, tbl_contract_deadlines, tbl_contract_documents_master, tbl_contract_hierarchy, tbl_contract_notifications, tbl_contract_rates_all, tbl_contract_risk_scores, tbl_delegation_matrix, tbl_dofr_matrix_existed, tbl_extraction_provenance, tbl_financial_exposure, tbl_genie_amendment_timeline, tbl_genie_provider_profile, tbl_provider_identifiers, tbl_quality_performance, tbl_rate_escalators, tbl_repricing_scenarios, tbl_service_areas, tbl_vs_unified_ready, plus 1 additional.
* **ISSUE_79 (hierarchy stale entry) — no stale amendment_order entry for tbl_contract_hierarchy in dim_table_schema**: Actual: **0**. CONFIRMED.
* **ISSUE_79 (deadline stale entry) — no stale deadline_date/days_until_deadline entries for tbl_contract_deadlines in dim_table_schema**: Actual: **0**. CONFIRMED.

### D1.6 — Cross-Table B-Series (Batch 6)

* **B2 — fact_supersession row count and provider_id nulls**: claimed 2,380 rows; provider_id may be NULL; supersession_id present. Live: `rows=2380; provider_id_nulls=2380; supersession_id_present=True`. CONFIRMED — provider_id is NULL on every single row; all 2,380 supersession edges must be joined via superseding_filename.
* **B9 — alert_queue to contract_deadlines FK orphans**: live join: **0 orphan rows**. CONFIRMED.
* **B11 — tbl_extraction_provenance lacks provider_id**: live 2026-07-13: `provider_id_present=False`. CONFIRMED at that date. **SUPERSEDED by Phase 10B-6 (completed 2026-07-20)**: `provider_id` column was added to `tbl_extraction_provenance` as part of Phase 10B-6. Current state: `provider_id` IS present — 0 nulls, 1,395 distinct providers (confirmed live). Direct JOIN on `provider_id` is now valid. The old `target_table + target_record_id` join path still works but `provider_id` is preferred. Group 8 summary and DATA_MODEL_PRODUCTION_STATE.md §2.3 reflect the correct current state.
* **B12 — tbl_provider_system_membership uses system_id not health_system_id**: live: `system_id_present=True; health_system_id_present=False`. CONFIRMED.
* **ISSUE_43 — tbl_clause_deviations lacks baseline_text and actual_text**: live: `baseline_text_present=False; actual_text_present=False`. CONFIRMED.

### D1.7 — Source File Directories (Batch 7)

* **B7_CHECKPOINT_DIR — checkpoint directory accessible**: live: `count=7; path_exists=True`. CONFIRMED.
* **B7_JSON_EXTRACT_DIR — json_extract directory accessible**: live: `count=20; path_exists=True`. CONFIRMED.

---

## D2 — Partial Findings (6)

Findings where live data supports the underlying concern but the precise claim was overstated, understated, or only partially verifiable.

* **ISSUE_25 — tbl_financial_exposure vs tbl_repricing_scenarios overlap**: live: financial=172 providers, scenarios=298 providers, overlap=**169 provider_ids** share both tables. Overlap is measurable and documented, but no explicit FK constraint is proven. PARTIAL — magnitude confirmed; FK absence confirmed; "inspectable but not enforced" characterization holds.

* **ISSUE_28 — tbl_rate_escalators base_index normalization concern**: claimed many free-text variants. Live `COUNT(DISTINCT base_index)` = **1** non-null normalized value (plus high null rate across remaining rows). PARTIAL — normalization concern real (single surviving canonical value, majority of rows null), but "many free-text variants" overstates cardinality. Accurate restatement: effectively one canonical `base_index` value survives extraction; the gap is a coverage/null problem, not a multi-variant deduplication problem.

* **ISSUE_37 — _vN suffix derivation as driver of broken-chain metric**: live: rows deriving `sequential_order` from `_vN` suffix = **751 rows** = **7.26% of hierarchy table** / **7.59% of non-null sequential_order rows**. PARTIAL — the 751 _vN rows are real and are the mechanistic root cause of inflated ordinals, but 7.26% does not equal the broken-chain percentage. The metric compounds additional gap and ordering failure modes beyond just these rows.

* **BROKEN_CHAIN_PROVIDERS_GAP_OR_STARTS_GT_1 — stricter broken-chain interpretation** (live validation metric, not a prior claim): providers with sequential_order gaps OR first sequential_order > 1 = **87.37% (332/380)**. PARTIAL — documents severity under a stricter definition for Phase 7 parser redesign planning. Catches chains that start at position 2+ (Base document missing or mislabeled) in addition to ordinal gaps.

* **B7_SAMPLE_JSON_SERVICE_CATEGORY — service_category as free-text in LLM extracts**: sample file `129075504_Renown_Regional_Medical_Center_129213196_BaseAgmtRenew_v1.json` contains values: `Medical/Surgical/Pediatrics`, `ICU/CCU`, `NICU/Newborn - Level I`, `NICU/Newborn - Level II`. PARTIAL — confirms free-text character (supports ISSUE_1); single-file sample only.

* **B7_BASE_INDEX_MATCH — no structured base_index-like fields in sampled LLM extract**: same sample: `json_keys_with_index=[]; matched_literals=[]`. PARTIAL — single file; does not prove absence across all 20 extract files. Suggests ISSUE_28's coverage gap reflects low extraction yield rather than a normalization variant problem.

---

## D3 — Wrong Findings (4)

Claims directly contradicted by live data.

* **ISSUE_39 — tbl_genie_amendment_timeline was claimed to lack amendment_order**:
  * Original claim: `amendment_order absent` in tbl_genie_amendment_timeline.
  * Live: `amendment_order_present=True`. The column EXISTS (bigint type).
  * Context: "absent" was correct only for `tbl_contract_hierarchy` (which uses `sequential_order`). It was incorrectly applied to the timeline table.
  * **Correction**: Remove any statement that tbl_genie_amendment_timeline lacks `amendment_order`. Phase 7 queries can use `tbl_genie_amendment_timeline.amendment_order` directly. The column is present and is distinct from the hierarchy's sequential_order.

* **BROKEN_CHAIN_PROVIDERS_PHASE6_LOGIC — broken_chain_providers metric no longer 47.84%**:
  * Original claim (Phase 6 notebook, 2026-07-10): 47.84% (181/378 providers).
  * Live recomputation 2026-07-13 using identical Phase 6 logic: **35.53% (135/380 providers)**.
  * The ~12pp improvement reflects additional sequential_order backfills applied after Phase 6 certification. Denominator 380 differs from Phase 6's 378 (new hierarchy rows).
  * **Correction**: Replace 47.84% / 181/378 with **35.53% / 135/380** as the current broken-chain rate wherever it appears. Phase 7 parser redesign priority remains valid — 35.53% is still far above the ≤10% target.

* **ISSUE_78_EXPECTED_MISSING_TABLES — 6 specific tables claimed missing from dim_table_schema**:
  * Original claim: six tables expected absent from `dim_table_schema`.
  * Live: `missing_set=[]`. All 6 supposedly missing tables are already present as registered entries.
  * **Correction**: Remove the "6 tables missing" claim and retire Section C P1 fix C2.1 ("Add 6 missing tables to dim_table_schema") as already complete. The C5 validation query for C2.1 (`COUNT(DISTINCT table_name) = 35`) should be updated — current count is 29, not 35, and the pre-fix gap has already been closed.

* **ISSUE_42 — tbl_clause_deviations claimed to have conformance_status / deviation_status columns**:
  * Original claim: "all rows CONFORMANT/NONE" — implying `conformance_status` and `deviation_status` columns exist with those values.
  * Live: `missing_columns=['conformance_status', 'deviation_status']`. Neither column exists in the current schema.
  * The underlying data quality concern (7,777 rows with no actual deviation data) remains valid.
  * **Correction**: Replace any query referencing `conformance_status` or `deviation_status`. The correct assessment path uses `network_has_pct` and `network_absent_pct`. The conformance description should read: "no baseline comparison data loaded; table holds aggregate coverage percentages per clause category only, not row-level conformance judgments."

---

*Section D complete. 41 live checks executed 2026-07-13 against dev_adb.raw. Verdicts: 31 CONFIRMED / 6 PARTIAL / 4 WRONG. Source: Contract_Intelligence_Phase6_Pipeline_Hardening notebook (ID: 4434698321220001), cells Live Validation Setup through Live Validation Summary. Written 2026-07-13.*

---
*End of TABLE_INVENTORY_GROUPED.md. Document contains: Summary tables (Groups 1-9) + 35 deep analyses + Section A (81 issues) + Section B (15 cross-table gaps) + Section C (solutions & validation) + Section D (live validation verdicts). Last updated 2026-07-20 (row counts, regulation list, and clause_status values updated from live DB queries).*

---

---
