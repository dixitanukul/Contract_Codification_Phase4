"""platform — V4 Contract Intelligence package.

This package shadows stdlib `platform`. To avoid breaking libraries that call
platform.python_implementation(), platform.system(), etc., we locate the real
stdlib platform.py and re-export all its public symbols.
"""
import importlib.util
import os
import sys

# ---------------------------------------------------------------------------
# Stdlib platform re-export
# ---------------------------------------------------------------------------
_this_dir = os.path.dirname(os.path.abspath(__file__))
_project_root = os.path.dirname(_this_dir)

_stdlib_path = None
for _p in sys.path:
    if not _p or os.path.abspath(_p) in (os.path.abspath(_project_root), _this_dir):
        continue
    _candidate = os.path.join(_p, 'platform.py')
    if os.path.isfile(_candidate):
        _stdlib_path = _candidate
        break

if _stdlib_path is None:
    # Fallback: sysconfig stdlib directory
    try:
        import sysconfig as _sc
        _stdlib_path = os.path.join(_sc.get_paths()['stdlib'], 'platform.py')
    except Exception:
        pass

if _stdlib_path and os.path.isfile(_stdlib_path):
    _spec = importlib.util.spec_from_file_location('_stdlib_platform', _stdlib_path)
    _mod = importlib.util.module_from_spec(_spec)
    _spec.loader.exec_module(_mod)
    # Re-export every public attribute from stdlib platform
    for _name in dir(_mod):
        if not _name.startswith('_'):
            globals()[_name] = getattr(_mod, _name)
    del _mod, _spec
else:
    import warnings
    warnings.warn(
        "platform/__init__.py: could not locate stdlib platform.py; "
        "libraries calling platform.python_implementation() may fail.",
        RuntimeWarning,
        stacklevel=2,
    )


# ---------------------------------------------------------------------------
# V3 → V4 backward-compatibility alias  (PEP 451 compliant — Python 3.4+)
# ---------------------------------------------------------------------------
# The codebase was migrated from platform.v3 to platform.v4. External callers
# (e.g. notebook cells, conftest.py, older scripts) that still import from
# platform.v3.xxx will be redirected to platform.v4.xxx transparently.
import importlib
import importlib.abc
import importlib.machinery
import types


class _V3Finder(importlib.abc.MetaPathFinder, importlib.abc.Loader):
    """Redirect any `platform.v3.*` import to `platform.v4.*`.

    Uses the PEP 451 find_spec()/exec_module() API (Python 3.4+).
    The deprecated find_module()/load_module() API was removed in Python 3.12.
    """

    _PREFIX = "platform.v3"

    # ── MetaPathFinder ────────────────────────────────────────────────────────

    def find_spec(
        self,
        fullname: str,
        path,
        target=None,
    ):
        if fullname == self._PREFIX or fullname.startswith(self._PREFIX + "."):
            # Return a ModuleSpec that names this object as both finder and loader.
            spec = importlib.machinery.ModuleSpec(
                name=fullname,
                loader=self,
                is_package=True,
            )
            return spec
        return None

    # ── Loader ────────────────────────────────────────────────────────────────

    def create_module(self, spec):
        """Return None to use default module creation semantics."""
        return None

    def exec_module(self, module):
        """
        Populate the module by aliasing it to the corresponding platform.v4 module.
        Stores the alias in sys.modules so subsequent imports are instant.
        """
        fullname = module.__name__
        target = fullname.replace("platform.v3", "platform.v4", 1)
        real_mod = importlib.import_module(target)
        # Copy all public attributes from the real V4 module
        for attr in dir(real_mod):
            setattr(module, attr, getattr(real_mod, attr))
        # Register the alias so `platform.v3.xxx is platform.v4.xxx` holds
        sys.modules[fullname] = real_mod


# Install the finder only once
if not any(isinstance(f, _V3Finder) for f in sys.meta_path):
    sys.meta_path.append(_V3Finder())
