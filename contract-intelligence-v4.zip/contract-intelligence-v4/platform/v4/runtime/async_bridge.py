"""
platform/v4/runtime/async_bridge.py

Async bridge for wrapping synchronous V4 runtime calls in FastAPI async contexts.

Step 3.1.3 — isolates blocking I/O (DatabricksLLMClient, SQL warehouse calls,
VectorSearch REST) from the FastAPI event loop via asyncio.to_thread.

Usage
-----
    from platform.v4.runtime.async_bridge import run_sync

    # In a FastAPI endpoint:
    response = await run_sync(runtime.ask, question, provider_name, session_id)

    # Or with keyword args:
    response = await run_sync(
        runtime.ask,
        question=req.question,
        provider_name=req.provider_name or None,
        session_id=req.session_id or None,
    )
"""
from __future__ import annotations

import asyncio
from typing import Any, Callable, TypeVar

T = TypeVar("T")


async def run_sync(fn: Callable[..., T], *args: Any, **kwargs: Any) -> T:
    """
    Execute a synchronous callable in a thread-pool without blocking the event loop.

    Apply to any I/O-blocking call on a FastAPI async path:
      - ``runtime.ask(...)``           — wraps LLM + SQL warehouse + VS REST
      - ``DatabricksLLMClient.chat()`` — synchronous ``requests`` call
      - SQL warehouse statement execution

    Parameters
    ----------
    fn       : Synchronous callable to execute in a worker thread.
    *args    : Positional arguments forwarded to *fn*.
    **kwargs : Keyword arguments forwarded to *fn*.

    Returns
    -------
    T
        Whatever *fn* returns.

    Raises
    ------
    Propagates any exception raised by *fn* back to the caller.
    """
    return await asyncio.to_thread(fn, *args, **kwargs)
