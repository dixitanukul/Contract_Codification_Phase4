"""platform/v4/runtime — Notebook / API / Genie / Serving entrypoints."""
from .notebook_entry import NotebookRuntime, init_runtime, get_runtime

__all__ = ["NotebookRuntime", "init_runtime", "get_runtime"]
