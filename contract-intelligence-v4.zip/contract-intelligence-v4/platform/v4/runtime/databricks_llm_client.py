"""
platform/v4/runtime/databricks_llm_client.py

Thin wrapper around the Databricks Model Serving REST API that implements
the LLM client interface expected by AgentController:

    client.chat(model, system, user, max_tokens) -> str
    client.chat_multi(model, messages, max_tokens) -> str  (BUG-012)

Usage
-----
    from platform.v4.runtime.databricks_llm_client import DatabricksLLMClient

    # Preferred: factory from WorkspaceConfig (no notebook globals needed)
    client = DatabricksLLMClient.from_spark(spark)

    # Or explicitly:
    client = DatabricksLLMClient(
        workspace_url="adb-xxx.azuredatabricks.net",
        model="databricks-claude-sonnet-4-5",
        api_token="dapi...",
    )
    text = client.chat(
        model="databricks-claude-sonnet-4-5",
        system="You are ...",
        user="What is ...",
        max_tokens=4096,
    )

    # Multi-turn (BUG-012):
    text = client.chat_multi(
        model="databricks-claude-sonnet-4-5",
        messages=[
            {"role": "system", "content": "You are ..."},
            {"role": "user", "content": "First question"},
            {"role": "assistant", "content": "First answer"},
            {"role": "user", "content": "Follow-up question"},
        ],
        max_tokens=4096,
    )
"""
from __future__ import annotations

import json
import logging
import random
import threading
import time
from typing import Any, Callable, Optional

import requests

logger = logging.getLogger(__name__)

_DEFAULT_TIMEOUT_S = 240  # raised from 120: FieldExtractionTool needs >120s for large-context extraction (V2-H01 timeout fix)


class DatabricksLLMClient:
    """
    REST client for Databricks Model Serving endpoints.

    Implements the interface required by AgentController._call_reasoning_llm:
        chat(model, system, user, max_tokens) -> str
        chat_multi(model, messages, max_tokens) -> str  (BUG-012)
    """

    # ------------------------------------------------------------------
    # Class-level global concurrency limiter (shared across ALL instances)
    # ------------------------------------------------------------------
    # Caps the total number of simultaneous in-flight LLM HTTP calls to
    # _MAX_CONCURRENT_CALLS regardless of how many callers exist (agent
    # reasoning, clause classifier batches, synthesis, revalidation, etc.).
    #
    # Without this, tools like ClauseClassifier fire 14 parallel threads
    # simultaneously → all hit 429 together → all retry at the same backoff
    # interval → thundering herd that never resolves ("endless retrying").
    #
    # With the semaphore, excess callers block here and are served
    # sequentially once a slot opens — no more thundering herd.
    _MAX_CONCURRENT_CALLS: int = 4
    _GLOBAL_SEMAPHORE: threading.Semaphore = threading.Semaphore(_MAX_CONCURRENT_CALLS)

    def __init__(
        self,
        workspace_url: str,
        model: str,
        api_token: str = "",
        timeout_s: int = _DEFAULT_TIMEOUT_S,
        *,
        _auth_fn: Optional[Callable[[], dict]] = None,
    ) -> None:
        """
        Parameters
        ----------
        workspace_url : Base URL, e.g. "adb-640321604414221.1.azuredatabricks.net"
                        (with or without https://).
        model         : Serving endpoint name, e.g. "databricks-claude-sonnet-4-5".
        api_token     : Databricks PAT or notebook auth token (ignored if _auth_fn set).
        timeout_s     : Per-request HTTP timeout in seconds.
        _auth_fn      : Callable returning auth headers dict. When set, fresh headers are
                        fetched per-request (supports OAuth token rotation in Apps).
        """
        base = workspace_url.rstrip("/")
        if not base.startswith("http"):
            base = f"https://{base}"
        self._endpoint = f"{base}/serving-endpoints/{model}/invocations"
        self._auth_fn = _auth_fn
        self._static_headers: Optional[dict] = None
        if not _auth_fn:
            self._static_headers = {
                "Authorization": f"Bearer {api_token}",
                "Content-Type": "application/json",
            }
        self._timeout = timeout_s
        self._model = model

    @property
    def _headers(self) -> dict:
        """Auth headers — refreshed per-call when using SDK OAuth."""
        if self._static_headers:
            return self._static_headers
        auth = self._auth_fn()
        return {**auth, "Content-Type": "application/json"}

    # ------------------------------------------------------------------
    # Private: HTTP POST with 429 retry / exponential backoff
    # ------------------------------------------------------------------

    def _post_with_retry(
        self,
        payload: dict,
        max_retries: int = 4,
        base_delay_s: float = 2.0,
        context: str = "chat",
    ) -> dict:
        """
        POST *payload* to the serving endpoint and return the parsed JSON body.

        Retry policy
        ------------
        - 429 Too Many Requests: honour ``Retry-After`` header if present;
          otherwise use exponential back-off with ±25 % jitter:
          attempt 1 → ~2 s, 2 → ~4 s, 3 → ~8 s, 4 → ~16 s  (up to ~30 s cap).
        - 503 Service Unavailable: same back-off (transient overload).
        - Other 4xx / 5xx: raise immediately (retrying won't help).
        - Network timeout / connection error: retry up to *max_retries* with
          back-off, then raise.

        Parameters
        ----------
        payload      : JSON-serialisable request body.
        max_retries  : Maximum number of retry attempts after first failure.
        base_delay_s : Base wait time for exponential back-off (seconds).
        context      : Label used in log/error messages (e.g. 'chat', 'chat_multi').
        """
        for attempt in range(max_retries + 1):  # attempt 0 = first try
            # ── Acquire global concurrency slot ──────────────────────────────────
            # Blocks when _MAX_CONCURRENT_CALLS are already in-flight.
            # Slot is released BEFORE sleeping so other waiters can proceed
            # during the back-off period — prevents thundering herd.
            DatabricksLLMClient._GLOBAL_SEMAPHORE.acquire()
            try:
                resp = requests.post(
                    self._endpoint,
                    headers=self._headers,
                    json=payload,
                    timeout=self._timeout,
                )
            except requests.exceptions.RequestException as exc:
                DatabricksLLMClient._GLOBAL_SEMAPHORE.release()  # free slot before sleep
                if attempt < max_retries:
                    wait = min(base_delay_s * (2 ** attempt) * (0.75 + 0.5 * random.random()), 30.0)
                    logger.warning(
                        "DatabricksLLMClient[%s]: network error (attempt %d/%d): %s — retrying in %.1fs",
                        context, attempt + 1, max_retries + 1, exc, wait,
                    )
                    time.sleep(wait)
                    continue
                raise RuntimeError(
                    f"DatabricksLLMClient[{context}]: request failed after "
                    f"{max_retries + 1} attempts [{exc.__class__.__name__}]: {exc}"
                ) from exc
            else:
                # Response received — free slot immediately so other callers
                # can proceed (we're done with the network layer for now).
                DatabricksLLMClient._GLOBAL_SEMAPHORE.release()

            # ── 429 / 503: back off and retry ───────────────────────────────────
            if resp.status_code in (429, 503) and attempt < max_retries:
                retry_after = resp.headers.get("Retry-After", "")
                try:
                    wait = float(retry_after)
                except (TypeError, ValueError):
                    wait = min(base_delay_s * (2 ** attempt) * (0.75 + 0.5 * random.random()), 30.0)
                logger.warning(
                    "DatabricksLLMClient[%s]: HTTP %d (attempt %d/%d) — retrying in %.1fs",
                    context, resp.status_code, attempt + 1, max_retries + 1, wait,
                )
                time.sleep(wait)
                continue

            # ── All other HTTP errors — fail immediately (no retry) ─────────────
            try:
                resp.raise_for_status()
            except requests.exceptions.HTTPError as exc:
                raise RuntimeError(
                    f"DatabricksLLMClient[{context}]: HTTP {resp.status_code}: {exc}"
                ) from exc

            # ── Success ─────────────────────────────────────────────────────────
            return resp.json()

        # Exhausted all retries
        raise RuntimeError(
            f"DatabricksLLMClient[{context}]: rate-limited after {max_retries + 1} attempts"
        )

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    def chat(
        self,
        model: str,
        system: str,
        user: str,
        max_tokens: int,
        temperature: float = 0.0,
    ) -> str:
        """
        Send a two-message conversation (system + user) and return the
        raw assistant reply text.

        Raises
        ------
        RuntimeError  : if the API call fails after retries.
        """
        payload = {
            "messages": [
                {"role": "system", "content": system},
                {"role": "user",   "content": user},
            ],
            "max_tokens": max_tokens,
            "temperature": temperature,
        }

        data = self._post_with_retry(payload, context="chat")

        # Standard OpenAI-compatible response format used by Databricks endpoints
        try:
            return data["choices"][0]["message"]["content"]
        except (KeyError, IndexError, TypeError) as exc:
            logger.error("Unexpected response shape: %s", json.dumps(data)[:400])
            raise RuntimeError(
                f"DatabricksLLMClient: could not extract content from response: {exc}"
            ) from exc

    def chat_multi(
        self,
        model: str,
        messages: list[dict],
        max_tokens: int,
        temperature: float = 0.0,
    ) -> str:
        """
        BUG-012: Send a multi-turn conversation and return the assistant reply.

        Accepts a pre-built message list (system + user/assistant alternation)
        for multi-turn context. Use build_conversation_context() from
        context_manager to normalize raw messages before passing here.

        Parameters
        ----------
        model       : Serving endpoint name (used for routing; endpoint fixed at init).
        messages    : List of message dicts with 'role' and 'content' keys.
                      Must follow OpenAI chat format: system first (optional),
                      then alternating user/assistant, ending with user.
        max_tokens  : Maximum tokens in the response.
        temperature : Sampling temperature (default 0.0 for deterministic).

        Raises
        ------
        RuntimeError  : if the API call fails.
        ValueError    : if messages list is empty or malformed.
        """
        if not messages:
            raise ValueError("chat_multi: messages list cannot be empty")

        # Validate last message is from user (LLM expects to respond to user)
        if messages[-1].get("role") != "user":
            raise ValueError(
                "chat_multi: last message must have role='user' "
                f"(got '{messages[-1].get('role')}')"
            )

        payload = {
            "messages": messages,
            "max_tokens": max_tokens,
            "temperature": temperature,
        }

        data = self._post_with_retry(payload, context="chat_multi")

        try:
            return data["choices"][0]["message"]["content"]
        except (KeyError, IndexError, TypeError) as exc:
            logger.error("Unexpected response shape: %s", json.dumps(data)[:400])
            raise RuntimeError(
                f"DatabricksLLMClient.chat_multi: could not extract content: {exc}"
            ) from exc

    # ------------------------------------------------------------------
    # Factory methods (P1-LLM-1)
    # ------------------------------------------------------------------

    @classmethod
    def from_config(cls, config: "WorkspaceConfig", timeout_s: int = _DEFAULT_TIMEOUT_S) -> "DatabricksLLMClient":
        """
        Create client from a WorkspaceConfig instance (no notebook globals needed).

        Usage:
            from platform.v4.config.workspace_config import WorkspaceConfig
            config = WorkspaceConfig.from_spark(spark)
            client = DatabricksLLMClient.from_config(config)
        """
        return cls(
            workspace_url=config.workspace_url,
            model=config.llm_model,
            api_token=config.api_token,
            timeout_s=timeout_s,
        )

    @classmethod
    def from_spark(cls, spark, model: Optional[str] = None, timeout_s: int = _DEFAULT_TIMEOUT_S) -> "DatabricksLLMClient":
        """
        Create client directly from a Spark session (resolves auth automatically).

        Usage:
            client = DatabricksLLMClient.from_spark(spark)
        """
        from ..config.workspace_config import WorkspaceConfig
        config = WorkspaceConfig.from_spark(spark, llm_model=model)
        return cls.from_config(config, timeout_s=timeout_s)

    @classmethod
    def from_sdk(
        cls,
        model: Optional[str] = None,
        timeout_s: int = _DEFAULT_TIMEOUT_S,
    ) -> "DatabricksLLMClient":
        """
        Create client using the Databricks SDK's native auth (OAuth-compatible).

        Works in Databricks Apps where DATABRICKS_TOKEN is not set.
        Auth headers are fetched fresh per-request so OAuth token rotation
        is handled automatically for long-lived app processes.

        Usage:
            client = DatabricksLLMClient.from_sdk()
        """
        from databricks.sdk import WorkspaceClient
        from ..config.settings import LLM_REASONING

        w = WorkspaceClient()
        workspace_url = w.config.host or ""
        if not workspace_url:
            raise RuntimeError("DatabricksLLMClient.from_sdk: SDK could not resolve host.")

        resolved_model = model or LLM_REASONING
        auth_fn = w.config.authenticate

        logger.info(
            "DatabricksLLMClient initialized via SDK (host=%s, model=%s)",
            workspace_url[:40], resolved_model,
        )
        return cls(
            workspace_url=workspace_url,
            model=resolved_model,
            timeout_s=timeout_s,
            _auth_fn=auth_fn,
        )

    def __repr__(self) -> str:
        auth_mode = "sdk" if self._auth_fn else "static"
        return f"DatabricksLLMClient(model={self._model!r}, auth={auth_mode})"
