"""
W9-26/34: NotebookStreamHandler — real-time progress display in Databricks notebooks.

Implements StreamCallback to show live agent progress using IPython display.
When V3 is enabled, users see tool calls, partial results, and reasoning
as they happen — no waiting for the full answer.

Usage in notebook_entry.py:
    from platform.v4.runtime.notebook_stream_handler import NotebookStreamHandler

    handler = NotebookStreamHandler()
    response = controller.run(request, stream_callback=handler)
    # Progress updates displayed automatically during execution
"""
from __future__ import annotations

import time
from typing import Any

from platform.v4.contracts.streaming_types import (
    StreamEvent, StreamMessage, StreamCallback,
)


class NotebookStreamHandler:
    """
    StreamCallback implementation for Databricks notebook display.

    Shows a live-updating progress panel using displayHTML / IPython display.
    Falls back gracefully to print() if IPython is not available.
    """

    def __init__(self, verbose: bool = False, max_display_events: int = 10):
        """
        Parameters
        ----------
        verbose : If True, show all events including THINKING details.
                  If False (default), show only user-facing events.
        max_display_events : Max number of events to show in the display panel.
        """
        self._verbose = verbose
        self._max_events = max_display_events
        self._events: list[StreamMessage] = []
        self._display_handle = None
        self._use_ipython = self._check_ipython()

    def on_event(self, message: StreamMessage) -> None:
        """Called by AgentController._emit() for each streaming event."""
        self._events.append(message)

        # Skip verbose events in non-verbose mode
        if not self._verbose and message.event == StreamEvent.THINKING:
            return

        # Update display
        self._update_display(message)

    def _update_display(self, latest: StreamMessage) -> None:
        """Render the current state to the notebook output."""
        if self._use_ipython:
            self._render_ipython(latest)
        else:
            self._render_print(latest)

    def _render_print(self, latest: StreamMessage) -> None:
        """Fallback: simple print output."""
        text = latest.to_display_text()
        if text:
            print(text)

    def _render_ipython(self, latest: StreamMessage) -> None:
        """Render using IPython display with HTML formatting."""
        try:
            from IPython.display import display, HTML, clear_output

            # Build HTML panel
            html = self._build_html_panel()

            if self._display_handle is None:
                self._display_handle = display(HTML(html), display_id=True)
            else:
                self._display_handle.update(HTML(html))

        except Exception:
            # Fallback to print
            self._render_print(latest)

    def _build_html_panel(self) -> str:
        """Build an HTML panel showing recent events."""
        # Get last N events for display
        visible_events = self._events[-self._max_events:]

        rows = []
        for msg in visible_events:
            icon = self._event_icon(msg.event)
            text = self._event_text(msg)
            color = self._event_color(msg.event)
            elapsed = f"{msg.elapsed_s:.1f}s" if msg.elapsed_s > 0 else ""

            rows.append(
                f'<div style="padding:2px 0;color:{color};font-family:monospace;font-size:13px;">'
                f'{icon} {text}'
                f'<span style="float:right;color:#888;font-size:11px;">{elapsed}</span>'
                f'</div>'
            )

        # Progress bar
        progress = self._events[-1].progress_pct if self._events else 0
        progress_bar = (
            f'<div style="background:#e0e0e0;border-radius:4px;height:6px;margin:8px 0;">'
            f'<div style="background:#4CAF50;height:6px;border-radius:4px;'
            f'width:{int(progress*100)}%;transition:width 0.3s;"></div></div>'
        )

        # Final answer (if available)
        final_section = ""
        final_events = [e for e in self._events if e.event == StreamEvent.FINAL_ANSWER]
        if final_events:
            answer = final_events[-1].partial_answer[:500]
            final_section = (
                f'<div style="margin-top:8px;padding:8px;background:#f0f7ff;'
                f'border-left:3px solid #2196F3;font-size:13px;">'
                f'{answer}</div>'
            )

        html = (
            f'<div style="border:1px solid #ddd;border-radius:6px;padding:12px;'
            f'margin:4px 0;max-width:700px;">'
            f'<div style="font-weight:bold;margin-bottom:6px;font-size:14px;">'
            f'Contract Intelligence V3 Agent</div>'
            f'{progress_bar}'
            f'{"".join(rows)}'
            f'{final_section}'
            f'</div>'
        )
        return html

    @staticmethod
    def _event_icon(event: StreamEvent) -> str:
        icons = {
            StreamEvent.STARTED: "&#x1F504;",       # 🔄
            StreamEvent.THINKING: "&#x1F4AD;",      # 💭
            StreamEvent.TOOL_START: "&#x1F527;",    # 🔧
            StreamEvent.TOOL_RESULT: "&#x2705;",    # ✅
            StreamEvent.SYNTHESIZING: "&#x1F4DD;",  # 📝
            StreamEvent.FINAL_ANSWER: "&#x2728;",   # ✨
            StreamEvent.ERROR: "&#x26A0;",          # ⚠️
            StreamEvent.DECOMPOSING: "&#x1F500;",   # 🔀
            StreamEvent.SUB_QUESTION_START: "&#x1F4CB;",  # 📋
            StreamEvent.SUB_QUESTION_RESULT: "&#x2714;",  # ✔
            StreamEvent.ABORTED: "&#x1F6AB;",       # 🚫
        }
        return icons.get(event, "&#x25CF;")

    @staticmethod
    def _event_text(msg: StreamMessage) -> str:
        if msg.event == StreamEvent.STARTED:
            return "Processing your question..."
        elif msg.event == StreamEvent.THINKING:
            thought = msg.data.get("thought", "")[:80]
            return f"Reasoning: {thought}..." if thought else "Thinking..."
        elif msg.event == StreamEvent.TOOL_START:
            return f"Calling <b>{msg.tool_name}</b>..."
        elif msg.event == StreamEvent.TOOL_RESULT:
            preview = msg.partial_answer[:120]
            return f"<b>{msg.tool_name}</b>: {preview}"
        elif msg.event == StreamEvent.SYNTHESIZING:
            return "Assembling final answer..."
        elif msg.event == StreamEvent.FINAL_ANSWER:
            return "Answer ready"
        elif msg.event == StreamEvent.ERROR:
            return f"Error: {msg.data.get('message', 'Unknown')[:100]}"
        elif msg.event == StreamEvent.DECOMPOSING:
            n = msg.data.get("sub_question_count", 0)
            return f"Complex question \u2192 splitting into {n} parts..."
        elif msg.event == StreamEvent.SUB_QUESTION_START:
            q = msg.data.get("question", "")[:80]
            return f"Sub-question: {q}"
        elif msg.event == StreamEvent.SUB_QUESTION_RESULT:
            return f"Sub-question {msg.step_number} answered"
        elif msg.event == StreamEvent.ABORTED:
            return f"Aborted: {msg.data.get('reason', '')[:100]}"
        return f"[{msg.event.value}]"

    @staticmethod
    def _event_color(event: StreamEvent) -> str:
        colors = {
            StreamEvent.STARTED: "#666",
            StreamEvent.THINKING: "#888",
            StreamEvent.TOOL_START: "#1976D2",
            StreamEvent.TOOL_RESULT: "#388E3C",
            StreamEvent.SYNTHESIZING: "#F57C00",
            StreamEvent.FINAL_ANSWER: "#1B5E20",
            StreamEvent.ERROR: "#D32F2F",
            StreamEvent.DECOMPOSING: "#7B1FA2",
            StreamEvent.SUB_QUESTION_START: "#5D4037",
            StreamEvent.SUB_QUESTION_RESULT: "#388E3C",
            StreamEvent.ABORTED: "#D32F2F",
        }
        return colors.get(event, "#333")

    @staticmethod
    def _check_ipython() -> bool:
        try:
            from IPython import get_ipython
            return get_ipython() is not None
        except (ImportError, AttributeError):
            return False

    @property
    def events(self) -> list[StreamMessage]:
        return list(self._events)

    @property
    def event_count(self) -> int:
        return len(self._events)
