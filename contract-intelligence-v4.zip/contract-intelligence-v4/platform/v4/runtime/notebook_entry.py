"""
platform/v4/runtime/notebook_entry.py

V4 notebook runtime entry point.

Responsibilities
----------------
1. Initialise all V4 components (adapters, tools, controller) with
   live Spark session and V2 dispatch function.
2. Expose a simple `ask(question)` interface for notebook cells.
3. Expose `get_runtime()` for the compat adapter.
4. Keep all notebook-specific wiring isolated here; core V4 modules
   must remain runtime-agnostic.

Usage (from a V4 test or runtime notebook)
------------------------------------------
    from platform.v4.runtime.notebook_entry import NotebookRuntime, init_runtime_standalone

    # Initialise once per notebook session
    runtime = init_runtime_standalone(spark=spark)

    # Ask a question
    response = runtime.ask("What is the capitation rate for Cedars-Sinai?")
    print(response.answer)
    print(f"Cost: ${response.total_cost:.3f}")
"""
from __future__ import annotations

import logging
import time
from typing import Any, Callable, Optional

from ..adapters.citation_adapter import CitationAdapter
from ..adapters.legacy_branch_adapter import LegacyBranchAdapter
from ..adapters.provider_adapter import ProviderAdapter
from ..adapters.retrieval_adapter import RetrievalAdapter
from ..config.settings import Settings
from ..contracts.agent_types import AgentRequest, AgentResponse
from ..core.agent_controller import AgentController
from ..core.context_manager import ContextManager
from ..core.cost_controller import CostController
from ..core.current_effective_filter import CurrentEffectiveFilter
from ..core.provenance import ProvenanceResolver
from ..core.response_assembler import ResponseAssembler
from ..data.schema_context_builder import SchemaContextBuilder
from ..tools.registry import ToolRegistry

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Module-level singleton (one per notebook session)
# ---------------------------------------------------------------------------

_RUNTIME: Optional["NotebookRuntime"] = None


def get_runtime() -> Optional["NotebookRuntime"]:
    """Return the initialised runtime singleton, or None if not yet initialised."""
    return _RUNTIME


def init_runtime_standalone(spark: Any, settings: Optional[Settings] = None) -> "NotebookRuntime":
    """
    P1-INIT-1: Self-contained V4 runtime initialization.

    Requires ONLY a Spark session. All services are created internally:
      - WorkspaceConfig (auth from Spark context)
      - DatabricksLLMClient (from config)
      - VectorSearchService (SDK wrapper)
      - ProviderService (canonical resolution)
      - TelemetryRepo, ProvenanceResolver, CurrentEffectiveFilter

    NO V2 cell globals needed (no dispatch_fn, no _workspace_url, no _api_token).

    Usage:
        from platform.v4.runtime.notebook_entry import init_runtime_standalone
        runtime = init_runtime_standalone(spark=spark)
        response = runtime.ask("Which providers have an offset clause?")
    """
    from ..config.workspace_config import WorkspaceConfig
    from ..services.provider_service import ProviderService
    from ..services.vector_search_service import VectorSearchService
    from .databricks_llm_client import DatabricksLLMClient
    from ..data.telemetry_repo import TelemetryRepo

    _settings = settings or Settings()

    # 1. Resolve workspace config (auth)
    config = WorkspaceConfig.from_spark(spark)

    # 2. Create LLM client
    llm_client = DatabricksLLMClient.from_config(config)

    # 3. Create vector search service
    vs_service = VectorSearchService(
        endpoint=config.vs_endpoint,
        index_fulltext=config.vs_index_fulltext,
        index_legal=config.vs_index_legal,
    )

    # 4. P3-RET-4: Build native RetrievalService (replaces _live_retrieve_fn closure)
    from ..core.current_effective_filter import CurrentEffectiveFilter as _CEF
    from ..services.retrieval_service import build_retrieval_service as _build_rs
    _current_filter   = _CEF(spark=spark)
    retrieval_service = _build_rs(
        spark=spark,
        vs_service=vs_service,
        current_filter=_current_filter,
    )

    # 5. Telemetry
    telemetry_repo = TelemetryRepo(spark=spark)

    # 6. Provenance
    provenance = ProvenanceResolver(spark=spark)

    # 7. Build ProviderService (used by P4B deep-dive + temporal tools)
    provider_service = ProviderService(spark=spark)

    # 8. Initialize via the standard path (ensures all wiring is consistent)
    return init_runtime(
        spark=spark,
        dispatch_fn=None,             # No V2 dependency
        retrieve_fn=None,             # P3: native RetrievalService used instead
        llm_client=llm_client,
        settings=_settings,
        telemetry_repo=telemetry_repo,
        provenance_resolver=provenance,
        retrieval_service=retrieval_service,  # P3-RET-4
        provider_service=provider_service,    # P4B
    )


def init_runtime_api(settings: Optional[Settings] = None) -> "NotebookRuntime":
    """
    Step 3.1 — FastAPI / Databricks Apps runtime initialization.

    No notebook Spark session required. Authenticates from environment variables
    (DATABRICKS_HOST + DATABRICKS_TOKEN) and obtains a SQL warehouse Spark
    session via Databricks Connect for SQL-dependent services.

    LLM and VectorSearch services are initialized via REST — no Spark needed
    for those paths.

    Usage (from app/main.py lifespan):
        from platform.v4.runtime.notebook_entry import init_runtime_api
        app.state.runtime = init_runtime_api()
    """
    from ..config.workspace_config import WorkspaceConfig
    from ..services.vector_search_service import VectorSearchService
    from .databricks_llm_client import DatabricksLLMClient

    _settings = settings or Settings()

    # 1. Auth from environment — no Spark needed
    config = WorkspaceConfig.from_env()
    logger.info("init_runtime_api: workspace config resolved from env.")

    # 2. LLM client — pure REST, no Spark
    llm_client = DatabricksLLMClient.from_config(config)

    # 3. VS service — pure REST, no Spark
    vs_service = VectorSearchService(
        endpoint=config.vs_endpoint,
        index_fulltext=config.vs_index_fulltext,
        index_legal=config.vs_index_legal,
    )

    # 4. SQL session via Databricks Connect (required by SQL-dependent services).
    #    In Databricks Apps, DATABRICKS_HOST + DATABRICKS_TOKEN are injected by
    #    the runtime, so DatabricksSession.builder.getOrCreate() resolves cleanly.
    try:
        from databricks.connect import DatabricksSession
        spark = DatabricksSession.builder.getOrCreate()
        logger.info("init_runtime_api: Databricks Connect session established.")
    except Exception as exc:
        raise RuntimeError(
            f"init_runtime_api: Databricks Connect required but unavailable: {exc}. "
            "Ensure databricks-connect is installed and DATABRICKS_HOST / "
            "DATABRICKS_TOKEN environment variables are set."
        ) from exc

    # 5. SQL-dependent services (spark is now guaranteed)
    from ..core.current_effective_filter import CurrentEffectiveFilter
    from ..services.retrieval_service import build_retrieval_service
    from ..data.telemetry_repo import TelemetryRepo
    from ..core.provenance import ProvenanceResolver
    from ..services.provider_service import ProviderService

    current_filter    = CurrentEffectiveFilter(spark=spark)
    retrieval_service = build_retrieval_service(
        spark=spark,
        vs_service=vs_service,
        current_filter=current_filter,
    )
    telemetry_repo   = TelemetryRepo(spark=spark)
    provenance       = ProvenanceResolver(spark=spark)
    provider_service = ProviderService(spark=spark)

    logger.info("init_runtime_api: all services initialized — calling init_runtime.")
    return init_runtime(
        spark=spark,
        dispatch_fn=None,
        retrieve_fn=None,
        llm_client=llm_client,
        settings=_settings,
        telemetry_repo=telemetry_repo,
        provenance_resolver=provenance,
        retrieval_service=retrieval_service,
        provider_service=provider_service,
    )


def init_runtime(
    spark:           Any,
    dispatch_fn:     Optional[Callable]  = None,
    retrieve_fn:     Optional[Callable]  = None,
    retrieve_legal:  Optional[Callable]  = None,
    verify_fn:       Optional[Callable]  = None,
    llm_client:      Optional[Any]       = None,
    settings:        Optional[Settings]  = None,
    preload_providers: bool              = True,
    genie_client:      Optional[Any]      = None,   # W9-36
    telemetry_repo:    Optional[Any]      = None,   # W3-WIRE
    provenance_resolver: Optional[Any]    = None,   # W9-17
    retrieval_service:   Optional[Any]    = None,   # P3-RET-4
    provider_service:    Optional[Any]    = None,   # P4B
) -> "NotebookRuntime":
    """
    Initialise the V4 runtime and store as the module singleton.

    Parameters
    ----------
    spark            : Active Spark session (spark from notebook context).
    dispatch_fn      : [DEPRECATED — P4D-DISP-1] V2 dispatch() function from Cell 4.
                       Accepted for backward compatibility; no longer used by the
                       tool registry. Pass None (or omit) for all new call-sites.
    retrieve_fn      : Legacy retrieve() function from 05_retrieval_engine.py.
    retrieve_legal   : Legacy retrieve_legal() function (optional).
    verify_fn        : Legacy verify() function from 07_citation_verification.py.
    llm_client       : LLM client with .chat(model, system, user, max_tokens)->str.
    settings         : Settings instance (defaults to Settings()).
    preload_providers: If True, load all canonical providers into cache at startup.
    telemetry_repo   : TelemetryRepo instance for retrieval event logging.
    """
    global _RUNTIME

    _RUNTIME = NotebookRuntime(
        spark=spark,
        dispatch_fn=dispatch_fn,
        retrieve_fn=retrieve_fn,
        retrieve_legal=retrieve_legal,
        verify_fn=verify_fn,
        llm_client=llm_client,
        settings=settings or Settings(),
        preload_providers=preload_providers,
        genie_client=genie_client,
        telemetry_repo=telemetry_repo,
        provenance_resolver=provenance_resolver or ProvenanceResolver(spark=spark),  # W9-17
        retrieval_service=retrieval_service,  # P3-RET-4
        provider_service=provider_service,    # P4B
    )
    return _RUNTIME


# ---------------------------------------------------------------------------
# NotebookRuntime
# ---------------------------------------------------------------------------

class NotebookRuntime:
    """
    Wires all V4 components together for notebook use.

    Do not construct this directly; use init_runtime().
    """

    def __init__(
        self,
        spark:             Any,
        dispatch_fn:       Optional[Callable],
        retrieve_fn:       Optional[Callable],
        retrieve_legal:    Optional[Callable],
        verify_fn:         Optional[Callable],
        llm_client:        Optional[Any],
        settings:          Settings,
        preload_providers: bool,
        genie_client:      Optional[Any] = None,   # W9-36
        telemetry_repo:    Optional[Any] = None,   # W3-WIRE
        provenance_resolver: Optional[Any] = None,  # W9-17
        retrieval_service:   Optional[Any] = None,  # P3-RET-4
        provider_service:    Optional[Any] = None,  # P4B
    ) -> None:
        self._settings          = settings
        self._spark             = spark
        self._llm_client        = llm_client         # P4B
        self._provider_service  = provider_service   # P4B

        # P5: Native question router (standalone — no V2 dependencies)
        from ..core.question_router import QuestionRouter
        self._router = (
            QuestionRouter(provider_service=provider_service, llm_client=llm_client)
            if provider_service is not None
            else None
        )
        self._genie_client      = genie_client       # W9-36
        self._provenance        = provenance_resolver   # W9-17

        # W7-2 + V4: CurrentEffectiveFilter — created BEFORE assembler so it
        # can be shared with both RetrievalAdapter and ResponseAssembler
        self._current_filter = CurrentEffectiveFilter(spark=spark)

        # V4: Wire current_effective_filter into ResponseAssembler for
        # inactive provider note surfacing
        self._assembler = ResponseAssembler(
            provenance_resolver=provenance_resolver,
            current_effective_filter=self._current_filter,
        )

        # --- Build adapters ---
        self.branch_adapter    = LegacyBranchAdapter(dispatch_fn=dispatch_fn)
        self.retrieval_adapter = RetrievalAdapter(
            retrieve_fn=retrieve_fn,
            retrieve_legal_fn=retrieve_legal,
            telemetry_repo=telemetry_repo,              # W3-WIRE
            current_effective_filter=self._current_filter,  # W7-2 (legacy path only)
            retrieval_service=retrieval_service,        # P3-RET-4 (native path)
        )
        self.citation_adapter  = CitationAdapter(verify_fn=verify_fn)
        self.provider_adapter  = ProviderAdapter(spark=spark)

        # --- Build core components ---
        self.context_manager = ContextManager(spark=spark)
        self.cost_controller = CostController(
            budget_usd=settings.AGENT_DEFAULT_BUDGET_USD,
        )

        # --- Build tool registry ---
        self.registry = self._build_registry()

        # --- Build agent controller ---
        self.controller = AgentController(
            registry=self.registry,
            context_manager=self.context_manager,
            cost_controller=self.cost_controller,
            assembler=self._assembler,
            llm_client=llm_client,
            settings=settings,
            router=self._router,  # P5: wire native QuestionRouter for direct dispatch
        )
        # NEW-BUG-1 FIX: inject spark session so _inject_profile_facts and profile fallback
        # can query tbl_genie_provider_profile directly.
        self.controller._spark = self._spark

        # --- Startup tasks ---
        if preload_providers:
            n = self.provider_adapter.preload_cache()
            self.context_manager.set_provider_cache(
                self.provider_adapter._cache  # share the same dict
            )

        self._init_time = time.time()

        # W9-22: SessionRepo for multi-turn conversation history.
        # Created here so callers don't need to change their call-sites.
        self._session_repo: Optional[Any] = None
        if getattr(self._settings, 'V4_MULTI_TURN_ENABLED', False):
            try:
                from ..data.session_repo import SessionRepo as _SessionRepo
                self._session_repo = _SessionRepo(spark=spark)
                logger.info("SessionRepo wired for multi-turn (W9-22).")
            except Exception as _exc:
                logger.warning("SessionRepo init failed — multi-turn disabled: %s", _exc)

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    def ask(
        self,
        question:      str,
        provider_name: Optional[str] = None,
        session_id:    Optional[str] = None,
    ) -> AgentResponse:
        """
        Ask the V4 agent a question and return the full AgentResponse.

        Parameters
        ----------
        question      : Natural language question.
        provider_name : Optional provider name hint for context resolution.
        session_id    : Optional session ID for multi-turn tracking.

        BUG-3+4+5 fix: When session_id is provided and V4_MULTI_TURN_ENABLED,
        loads prior conversation turns from Delta via SessionRepo, then uses
        context_manager.resume_session() to rebuild conversation history so
        the agent has full multi-turn context for coreference resolution.
        """
        request = AgentRequest(
            question=question,
            session_id=session_id or "",
            provider_hint=provider_name,
        )
        if provider_name:
            request.context = self.context_manager.resolve(provider_name)

        # BUG-3+4+5: Load conversation history for multi-turn context
        resumed_context = None
        if session_id and self._session_repo and getattr(self._settings, 'V4_MULTI_TURN_ENABLED', False):
            try:
                rows = self._session_repo.load_session(session_id)
                if rows:
                    resumed_context = self.context_manager.resume_session(
                        session_id=session_id,
                        new_question=question,
                        rows=rows,
                    )
            except Exception as _exc:
                import logging
                logging.getLogger(__name__).warning(
                    "Multi-turn history load failed for session %s: %s", session_id, _exc
                )

        return self.controller.run(request, context=resumed_context)

    def stream_ask(
        self,
        question:      str,
        provider_name: Optional[str] = None,
        session_id:    Optional[str] = None,
    ) -> "Iterator[dict]":
        """
        Streaming version of ask() — yields SSE-compatible event dicts.

        Step 3.3: runs the full V4 agent synchronously, then streams the
        collected result as a sequence of typed events.  This gives the
        FastAPI layer a structured SSE stream without requiring token-level
        LLM streaming (Phase 4 upgrade path).

        Event sequence
        --------------
        {"type": "thinking",     "content": str}                    # emitted first
        {"type": "tool_start",   "tool": str, "step": int}          # one per step
        {"type": "tool_result",  "tool": str, "summary": str, "step": int}
        {"type": "answer_chunk", "content": str}                    # ~200 chars each
        {"type": "citations",    "citations": list[dict]}           # if any
        {"type": "confidence",   "label": str, "score": float}
        {"type": "done",         "latency_ms": int, "cost_usd": float,
                                 "tool_calls": int, "session_id": str}
        {"type": "error",        "message": str}                    # on failure
        """
        from typing import Iterator  # local import avoids circular at module level
        import time as _t

        yield {"type": "thinking", "content": "Analyzing your question..."}

        t0 = _t.time()
        try:
            response = self.ask(
                question=question,
                provider_name=provider_name,
                session_id=session_id,
            )
        except Exception as exc:
            yield {"type": "error", "message": str(exc)[:500]}
            return

        elapsed = _t.time() - t0

        # Tool step events
        for i, step in enumerate(response.steps or []):
            tool_name = (
                getattr(step, "tool_name", None)
                or getattr(step, "tool", None)
                or "unknown"
            )
            summary = (
                getattr(step, "summary", None)
                or getattr(step, "result", "")
                or ""
            )
            yield {"type": "tool_start",  "tool": str(tool_name), "step": i + 1}
            yield {"type": "tool_result", "tool": str(tool_name),
                   "summary": str(summary)[:400], "step": i + 1}

        # Answer in ~200-char chunks
        answer = response.answer or ""
        chunk_size = 200
        if not answer:
            yield {"type": "answer_chunk", "content": ""}
        else:
            for start in range(0, len(answer), chunk_size):
                yield {"type": "answer_chunk",
                       "content": answer[start : start + chunk_size]}

        # Citations
        if response.citations:
            yield {"type": "citations", "citations": response.citations}

        # Confidence
        _CONF_MAP = {"HIGH": 0.90, "MODERATE": 0.65, "LOW": 0.35, "UNCERTAIN": 0.15}
        conf_raw   = str(response.confidence or "").upper().split(".")[-1]
        conf_score = _CONF_MAP.get(conf_raw, 0.5)
        yield {"type": "confidence", "label": conf_raw, "score": conf_score}

        # Terminal done event
        # BUG-6 fix: include resolved_entities_json so _stream_generator
        # can persist multi-turn context even in the streaming path.
        _re_json = (response.metadata or {}).get('resolved_entities_json')
        yield {
            "type":       "done",
            "latency_ms": int(elapsed * 1000),
            "cost_usd":   round(float(response.total_cost or 0.0), 4),
            "tool_calls": len(response.tool_calls or []),
            "session_id": response.session_id or "",
            "resolved_entities_json": _re_json,
        }

    def ask_display(self, question: str, **kwargs: Any) -> None:
        """
        Ask a question and print a formatted markdown answer.
        Convenience wrapper for notebook display.
        """
        response = self.ask(question, **kwargs)
        print(ResponseAssembler.format_for_display(response))

    def status(self) -> dict:
        """Return a status dict showing which components are ready."""
        return {
            "branch_adapter_ready":    self.branch_adapter.is_ready,
            "retrieval_adapter_ready": self.retrieval_adapter.is_ready,
            "citation_adapter_ready":  self.citation_adapter.is_ready,
            "provider_adapter_ready":  self.provider_adapter.is_ready,
            "provider_cache_size":     len(self.provider_adapter._cache),
            "tools_registered":        self.registry.list_tools(),
            "feature_flags":           self._settings.get_all_flags(),
            "uptime_s":                round(time.time() - self._init_time, 1),
        }

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _build_registry(self) -> ToolRegistry:
        """
        Register all V4 tools and adapter-backed tools in the registry.
        Tool implementations are wired with live adapter references.
        """
        from ..tools.calculate import CalculateTool
        from ..tools.chart_generate import ChartGenerateTool
        from ..tools.citation_verify import CitationVerifyTool
        from ..tools.document_fetch import DocumentFetchTool
        from ..tools.draft_text import DraftTextTool
        from ..tools.export_data import ExportDataTool
        from ..tools.passage_search import PassageSearchTool
        from ..tools.provider_lookup import ProviderLookupTool
        from ..tools.sql_query import SqlQueryTool
        from ..tools.summarize import SummarizeTool

        registry = ToolRegistry(settings=self._settings)

        # W9-14: inject SchemaContextBuilder for dim_table_schema-backed SQL context
        _schema_builder = SchemaContextBuilder(spark=self._spark)
        registry.register(SqlQueryTool(
            spark=self._spark,
            settings=self._settings,
            schema_context_builder=_schema_builder,
            llm_client=self._llm_client,   # W-AMEND-08: LLM needed for SQL generation
        ))
        registry.register(CalculateTool())
        registry.register(ProviderLookupTool(adapter=self.provider_adapter))
        registry.register(PassageSearchTool(adapter=self.retrieval_adapter, current_filter=self._current_filter))
        from ..services.verification.citation_verifier import CitationVerifier as _CitationVerifier
        _native_verifier = _CitationVerifier()  # native path (P3-VER-1)
        registry.register(CitationVerifyTool(adapter=self.citation_adapter, verifier=_native_verifier))
        registry.register(DocumentFetchTool(spark=self._spark, settings=self._settings))
        registry.register(SummarizeTool(settings=self._settings))
        registry.register(DraftTextTool(settings=self._settings))
        registry.register(ChartGenerateTool())
        registry.register(ExportDataTool(spark=self._spark))

        # W9-36: Genie Space tool (off by default; GENIE_ENABLED flag gates it)
        from ..tools.genie_query import GenieQueryTool
        registry.register(GenieQueryTool(
            genie_client=self._genie_client,
            space_id=self._settings.GENIE_SPACE_ID,
            settings=self._settings,
        ))

        # P4B: Provider Deep Dive + Temporal Analysis (native V4 tools)
        from ..tools.provider_deep_dive import ProviderDeepDiveTool
        from ..tools.temporal_analysis import TemporalAnalysisTool

        # Lazy-build ProviderService if not injected at init time
        _ps = self._provider_service
        if _ps is None:
            from ..services.provider_service import ProviderService
            _ps = ProviderService(spark=self._spark)
            self._provider_service = _ps

        _retrieval_svc = getattr(self.retrieval_adapter, "_retrieval_service", None)

        registry.register(ProviderDeepDiveTool(
            spark=self._spark,
            provider_service=_ps,
            retrieval_service=_retrieval_svc,
            llm_client=self._llm_client,
        ))
        registry.register(TemporalAnalysisTool(
            spark=self._spark,
            provider_service=_ps,
            llm_client=self._llm_client,
        ))

        # P4A: Rate Query + Field Extraction (native V4 tools)
        from ..tools.rate_query import RateQueryTool
        from ..tools.field_extraction import FieldExtractionTool

        registry.register(RateQueryTool(
            spark=self._spark,
            provider_service=_ps,
            llm_client=self._llm_client,
        ))
        registry.register(FieldExtractionTool(
            spark=self._spark,
            provider_service=_ps,
            retrieval_service=_retrieval_svc,
            llm_client=self._llm_client,
        ))

        # P4C: Clause Existence (native V4 tool)
        from ..tools.clause_existence_tool import ClauseExistenceTool

        registry.register(ClauseExistenceTool(
            spark=self._spark,
            provider_service=_ps,
            retrieval_service=_retrieval_svc,
            llm_client=self._llm_client,
        ))

        # P4E/P4F/P4C-COMP: Explanation, Multi-Concept, Comparison
        from ..tools.explanation import ExplanationTool
        from ..tools.multi_concept import MultiConceptTool
        from ..tools.comparison import ComparisonTool

        registry.register(ExplanationTool(
            spark=self._spark,
            provider_service=_ps,
            retrieval_service=_retrieval_svc,
            llm_client=self._llm_client,
        ))
        registry.register(MultiConceptTool(
            spark=self._spark,
            provider_service=_ps,
            llm_client=self._llm_client,
        ))
        registry.register(ComparisonTool(
            spark=self._spark,
            provider_service=_ps,
            retrieval_service=_retrieval_svc,
            llm_client=self._llm_client,
        ))

        # P4D-DISP-1: Legacy branch tool registration REMOVED.
        # All V2 branches are now covered by native V4 tools registered above
        # (ClauseExistenceTool, RateQueryTool, FieldExtractionTool,
        #  ProviderDeepDiveTool, TemporalAnalysisTool, ExplanationTool,
        #  MultiConceptTool, ComparisonTool).
        # AgentController routes exclusively to native tools.
        # LegacyBranchAdapter is retained for backward-compat call-sites
        # (e.g. Cell 23 V2 regression mode) but is no longer injected into
        # the tool registry.

        # Phase 10B-1: Risk & Alerts
        from ..tools.risk_alert import RiskAlertTool
        registry.register(RiskAlertTool(spark=self._spark))

        # Phase 10B-2: Financial Intelligence
        from ..tools.financial_analysis import FinancialAnalysisTool
        registry.register(FinancialAnalysisTool(spark=self._spark))

        # Phase 10B-3: Network & Geography
        from ..tools.system_membership import SystemMembershipTool
        registry.register(SystemMembershipTool(spark=self._spark))

        # Phase 10B-4: Compliance & Quality
        from ..tools.compliance_query import ComplianceQueryTool
        registry.register(ComplianceQueryTool(spark=self._spark))

        # Phase 10B-5: Clause Intelligence
        from ..tools.clause_text import ClauseTextTool
        registry.register(ClauseTextTool(spark=self._spark))
        # Phase 10B-6: Provenance & Audit
        from ..tools.provenance import ProvenanceTool
        registry.register(ProvenanceTool(spark=self._spark))

        return registry
