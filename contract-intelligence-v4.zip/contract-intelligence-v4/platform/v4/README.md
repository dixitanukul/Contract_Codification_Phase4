# platform/v4 — Contract Intelligence Backend

This package is the core backend for **Contract Intelligence Platform V4**.

It was copied from `Contract_Codification_Pipeline/platform/v3/` on 2026-06-16 and is being
evolved into the V4 production backend. See the root `DEVELOPMENT_PLAN.md` for the full
roadmap.

---

## Package Structure

| Package | Purpose | V4 Status |
|---|---|---|
| `adapters/` | Compatibility shims from V2→V3 pipeline. Wrap older data shapes. | Carry forward as-is |
| `api/` | FastAPI route definitions | Phase 3 — expand with all endpoints |
| `config/` | Settings, table whitelist, taxonomies, tool policies | Update table names for V4 schema |
| `contracts/` | Typed dataclasses for agent, citation, context, report, streaming | Carry forward; add V4 types |
| `core/` | Agent controller, context manager, hallucination guard, provenance | Phase 1 target — fix confidence + grounding |
| `data/` | Repos: feedback, query cache, session, telemetry | Carry forward; wire telemetry in Phase 3 |
| `evaluation/` | Golden query runner, regression gate, metrics, scorers | Phase 1 — expand golden set to 100 queries |
| `presentation/` | Excel/HTML report rendering, report validator | Phase 4 — fix HAS/MIXED/DENIED |
| `runtime/` | Entry points: API, notebook, serving, genie | Phase 3 — `api_entry.py` is the new primary |
| `services/` | Retrieval, vector search, SQL helpers, PII guardrail | Phase 2/7 — add PII middleware |
| `serving/` | MLflow model serving wrapper | Phase 5+ |
| `sql/` | DDL and views | Phase 0 — update for V4 table fixes |
| `tests/` | 1,070 unit + integration tests | Inherited from V3; grow with each phase |
| `tools/` | 13 ReAct agent tools | Phase 2 — add rate sub-table tools |

---

## Import Paths — IMPORTANT

The files in this package still contain internal imports referencing `platform.v3.*`.
These are correct for now (V3 code was copied verbatim). They will be migrated to
`platform.v4.*` in **Phase 3, Step 3.1**.

Until then, run tests from the `contract-intelligence-v4/` root so both `platform.v3`
(via `Contract_Codification_Pipeline/`) and `platform.v4` resolve correctly:

```bash
# From contract-intelligence-v4/
PYTHONPATH=/Workspace/Users/adixit01@blueshieldca.com:. \
  python -B -m pytest platform/v4/tests/ -m "not live" -p no:cacheprovider -q
```

---

## Test Baseline (inherited from V3)

| Suite | Count | Status |
|---|---|---|
| Unit tests | 1,070 | Passing (Phase 6 gate COMPLETE, 2026-06-14) |
| Live integration | 19 | Passing (require VS + SQL warehouse) |
| Regression gate | 30/30 | PASS (run ID: v3_phase6_regression_1781499693) |

Run unit tests (no live compute needed):
```bash
python -B -m pytest platform/v4/tests/ -m "not live" -p no:cacheprovider -q
```

---

## Key Files to Start With

| Task | File |
|---|---|
| Ask a question end-to-end | `runtime/notebook_entry.py` → `init_runtime()` |
| Add a new tool | `tools/base.py` → subclass `BaseTool`, register in `tools/registry.py` |
| Run evaluation | `evaluation/golden_query_runner.py` → `GoldenQueryRunner` |
| Change retrieval behaviour | `services/retrieval_service.py` |
| Fix confidence scores | `core/agent_controller.py` + `evaluation/scorers.py` |
| Update table names | `config/settings.py` + `sql/01_v3_tables.sql` |

---

## V4 Additions vs V3 (added during V4 development — NOT in original copy)

Track V4-specific changes here as they are made:

| Date | Change | File | Phase |
|---|---|---|---|
| 2026-06-16 | Initial V4 copy from platform/v3 | entire package | Setup |
| 2026-06-17 | Step 1.8 golden gate PASS 100/100 via `init_runtime_standalone` | `Contract_Intelligence_V4` notebook | Step 1.8 |
| 2026-06-17 | FET-SQL-1: `page_number` → `page_number_est AS page_number` | `tools/field_extraction.py`, `tools/temporal_analysis.py` | Step 1.8 bug fix |
| 2026-06-17 | RQT-SQL-1: `ORDER BY provider_name` → `provider_id` on stop-loss | `tools/rate_query.py` | Step 1.8 bug fix |
| 2026-06-17 | platform namespace bootstrap: `platform/__init__.py` + `platform.v3.__path__` V4-first setup | `platform/__init__.py`, `Contract_Intelligence_V4` Cell 3 | Step 1.8 infra |
| TBD | Import path migration v3→v4 | all `*.py` files | Phase 3 Step 3.1 |
| TBD | PII redaction middleware | `services/verification/` | Phase 7 Step 7.1 |
| TBD | Real-time SSE streaming | `runtime/api_entry.py` | Phase 3 Step 3.5 |
