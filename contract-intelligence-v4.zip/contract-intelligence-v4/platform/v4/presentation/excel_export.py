"""platform/v4/presentation/excel_export.py

P5-RPT-3: Excel export service for V3 typed report objects.

Produces multi-sheet .xlsx files from typed report dataclasses. Replaces
V2 Cell 16's xlsxwriter logic with a standalone service that operates
on structured data rather than notebook globals.

Usage
-----
    from platform.v4.presentation.excel_export import ExcelExportService
    from platform.v4.contracts.report_types import ClauseReport

    service = ExcelExportService()
    path = service.export(report, output_dir="/path/to/reports", question="...")
"""
from __future__ import annotations

import math
import os
import re
import glob
from datetime import datetime
from typing import Any

import xlsxwriter

from platform.v4.contracts.report_types import (
    AnyReport, ClauseReport, StructuredExtractionReport, ProviderReport,
    RateReport, TemporalReport, ComparisonReport, ExplanationReport,
    MultiConceptReport, ProviderStatus, ClassifiedPassage, ProviderFindingSummary,
    ProviderEnrichment, ConfidenceScore, DocumentMetadata, ExtractedValue,
    FieldDefinition, TaxonomyEntry, ExecutionPlan, ReportConfig,
    ROUTE_TO_REPORT_TYPE,
)


# ============================================================
# MODULE HELPERS
# ============================================================


def _truncate(text: Any, max_chars: int = 200) -> str:
    """Truncate text with ellipsis."""
    text = str(text or "")
    return text[:max_chars].rstrip() + "…" if len(text) > max_chars else text


def _split_paragraphs(text: str) -> list[str]:
    """Split narrative text into paragraphs on double-newlines."""
    if not text:
        return []
    return [p.strip() for p in text.split("\n\n") if p.strip()]


# ============================================================
# WORKBOOK CONTEXT (format holder)
# ============================================================


class _WorkbookContext:
    """Holds a Workbook reference and shared format objects."""

    def __init__(self, wb: xlsxwriter.Workbook, question: str = ""):
        self.wb = wb
        self.question = question
        self._init_formats()

    def _init_formats(self) -> None:
        wb = self.wb
        self.fmt_title = wb.add_format({"bold": True, "font_size": 16, "font_color": "#1B3A5C"})
        self.fmt_subtitle = wb.add_format({"font_size": 11, "font_color": "#555555", "text_wrap": True})
        self.fmt_header = wb.add_format({
            "bold": True, "font_size": 11, "font_color": "white",
            "bg_color": "#1B3A5C", "border": 1, "text_wrap": True, "valign": "vcenter"
        })
        self.fmt_row_even = wb.add_format({
            "bg_color": "#F7F9FB", "text_wrap": True, "valign": "top",
            "border_color": "#E0E0E0", "bottom": 1, "font_size": 10
        })
        self.fmt_row_odd = wb.add_format({
            "text_wrap": True, "valign": "top",
            "border_color": "#E0E0E0", "bottom": 1, "font_size": 10
        })
        self.fmt_bold = wb.add_format({"bold": True, "font_size": 12, "font_color": "#1B3A5C"})
        self.fmt_section = wb.add_format({"bold": True, "font_size": 12, "font_color": "#1B3A5C", "bottom": 2})
        self.fmt_narrative = wb.add_format({"text_wrap": True, "valign": "top", "font_size": 11, "font_color": "#333333"})

    def add_sheet(self, name: str) -> Any:
        """Add a new worksheet, truncating name to 31 chars (Excel limit)."""
        return self.wb.add_worksheet(name[:31])

    def write_title(self, ws: Any, title: str, subtitle: str, last_col: int = 5) -> int:
        """Write title + subtitle + timestamp. Returns next writable row."""
        ws.merge_range(0, 0, 0, last_col, title, self.fmt_title)
        ws.set_row(0, 22)
        ws.merge_range(1, 0, 1, last_col, subtitle, self.fmt_subtitle)
        ws.set_row(1, 18)
        ts = f"Generated: {datetime.now().strftime('%B %d, %Y at %I:%M %p')}"
        if self.question:
            ts += f' | Question: "{self.question[:80]}"'
        ws.merge_range(2, 0, 2, last_col, ts, self.fmt_subtitle)
        ws.set_row(2, 28)
        return 4

    def write_table(self, ws: Any, start_row: int, headers: list, data_rows: list, freeze: bool = True) -> int:
        """Write formatted table. Returns next row after table."""
        for col, h in enumerate(headers):
            ws.write(start_row, col, h, self.fmt_header)
        if freeze:
            ws.freeze_panes(start_row + 1, 0)
        ws.set_row(start_row, 24)
        row = start_row + 1
        for i, data_row in enumerate(data_rows):
            fmt = self.fmt_row_even if i % 2 == 0 else self.fmt_row_odd
            for col, val in enumerate(data_row):
                if isinstance(val, float) and (math.isnan(val) or math.isinf(val)):
                    val = "—"
                ws.write(row, col, val, fmt)
            row += 1
        if data_rows:
            ws.autofilter(start_row, 0, row - 1, len(headers) - 1)
        return row

    def auto_widths(self, ws: Any, headers: list, data_rows: list, max_width: int = 70) -> None:
        """Set column widths based on content sampling."""
        for col_idx, header in enumerate(headers):
            col_max = max(10, len(str(header)) + 2)
            for row in data_rows[:50]:
                if col_idx < len(row):
                    col_max = max(col_max, min(len(str(row[col_idx] or "")), max_width))
            ws.set_column(col_idx, col_idx, min(col_max + 2, max_width))


# ============================================================
# EXCEL EXPORT SERVICE
# ============================================================


class ExcelExportService:
    """Generates formatted multi-sheet Excel reports from typed report objects.

    Thread-safe: each export() call creates its own Workbook instance.
    No mutable state between calls.
    """

    ROUTE_LABELS = {
        "clause_existence": "Clause_Analysis",
        "single_provider": "Provider_Deep_Dive",
        "comparison": "Provider_Comparison",
        "rate_query": "Rate_Analysis",
        "explanation": "Explanation",
        "multi_concept": "Multi_Concept",
        "temporal": "Temporal_Analysis",
        "structured_extraction": "Structured_Extraction",
    }

    def export(
        self,
        report: AnyReport,
        output_dir: str,
        question: str = "",
        route: str = "",
        concept_label: str = "",
    ) -> str:
        """Export a typed report to .xlsx.

        Args:
            report: Any typed report dataclass.
            output_dir: Directory for the output file.
            question: Original user question (for metadata).
            route: Route name (auto-detected from report type if empty).
            concept_label: Short label for filename (e.g. 'Offset_Clause').

        Returns:
            Full path to the generated .xlsx file.
        """
        os.makedirs(output_dir, exist_ok=True)

        # Auto-detect route from report type
        if not route:
            for r, cls in ROUTE_TO_REPORT_TYPE.items():
                if isinstance(report, cls):
                    route = r
                    break

        # Build filename
        route_label = self.ROUTE_LABELS.get(route, "Analysis")
        file_label = concept_label or route_label
        base_filename = f"{route_label}_{file_label}_Report"

        # Auto-version: find existing files, bump version
        existing = glob.glob(f"{output_dir}/{base_filename}*.xlsx")
        if not existing:
            filename = f"{base_filename}.xlsx"
        else:
            max_ver = 1
            for f in existing:
                ver_match = re.search(r"_v(\d+)\.xlsx$", f)
                if ver_match:
                    max_ver = max(max_ver, int(ver_match.group(1)))
            filename = f"{base_filename}_v{max_ver + 1}.xlsx"

        output_path = f"{output_dir}/{filename}"

        # Create workbook and export
        wb = xlsxwriter.Workbook(output_path)
        ctx = _WorkbookContext(wb, question)

        try:
            if isinstance(report, ClauseReport):
                self._export_clause(report, ctx)
            elif isinstance(report, StructuredExtractionReport):
                self._export_structured_extraction(report, ctx)
            elif isinstance(report, ProviderReport):
                self._export_provider(report, ctx)
            elif isinstance(report, RateReport):
                self._export_rate(report, ctx)
            elif isinstance(report, TemporalReport):
                self._export_temporal(report, ctx)
            elif isinstance(report, ComparisonReport):
                self._export_comparison(report, ctx)
            elif isinstance(report, ExplanationReport):
                self._export_explanation(report, ctx)
            elif isinstance(report, MultiConceptReport):
                self._export_multi_concept(report, ctx)
            else:
                raise ValueError(f"Unknown report type: {type(report).__name__}")
        finally:
            wb.close()

        return output_path

    # ==================================================================
    # CLAUSE EXISTENCE (8 sheets)
    # ==================================================================

    def _export_clause(self, report: ClauseReport, ctx: _WorkbookContext) -> None:
        """Export ClauseReport to 8-sheet Excel."""
        concept = report.target_concept
        total = report.total_universe or (
            len(report.provider_findings) + len(report.no_mention_providers)
        )

        # Sheet 1: Executive Summary
        ws1 = ctx.add_sheet("1. Executive Summary")
        row = ctx.write_title(ws1, f"{concept.upper()} ANALYSIS REPORT",
            f"Methodology: Hybrid Retrieval + LLM Classification ({report.llm_model}) | {total} providers")

        ws1.write(row, 0, "HEADLINE RESULTS", ctx.fmt_section)
        row += 1
        headers = ["Classification", "Providers", "% of Total", "Interpretation"]
        has_n = report.has_count
        denied_n = report.denied_count
        mixed_n = report.mixed_count
        nm_n = report.no_mention_count
        data_rows = [
            ("Has provision", has_n, f"{has_n/max(1,total)*100:.1f}%",
             f"At least one document grants {concept} rights"),
            ("No mention", nm_n, f"{nm_n/max(1,total)*100:.1f}%",
             f"Zero keyword hits across all documents"),
            ("Explicitly denied", denied_n, f"{denied_n/max(1,total)*100:.1f}%",
             f"Contract explicitly prohibits {concept}"),
            ("Mixed (grant + deny)", mixed_n, f"{mixed_n/max(1,total)*100:.1f}%",
             f"Different docs grant and restrict"),
            ("TOTAL UNIVERSE", total, "100%", "All providers with extracted PDF documents"),
        ]
        row = ctx.write_table(ws1, row, headers, data_rows, freeze=False)
        row += 2

        # Category distribution
        ws1.write(row, 0, "CATEGORY DISTRIBUTION", ctx.fmt_section)
        row += 1
        dist = report.category_distribution
        cat_rows = [(report.code_to_label(cat), count)
                    for cat, count in sorted(dist.items(), key=lambda x: x[1], reverse=True)]
        row = ctx.write_table(ws1, row, ["Category", "Documents Found"], cat_rows, freeze=False)
        row += 2

        # Execution plan
        if report.execution_plan:
            ws1.write(row, 0, "EXECUTION PLAN", ctx.fmt_section)
            row += 1
            plan = report.execution_plan
            for label, val in [
                ("Core Keywords", ", ".join(plan.core_keywords)),
                ("Extended Keywords", ", ".join(plan.extended_keywords)),
                ("Strategy", plan.precision_strategy.title()),
            ]:
                ws1.write(row, 0, label, ctx.fmt_bold)
                ws1.write(row, 1, val, ctx.fmt_subtitle)
                row += 1
        ctx.auto_widths(ws1, ["Classification", "Providers", "% of Total", "Interpretation"],
                       data_rows, max_width=74)

        # Sheet 2: All Providers Master
        ws2 = ctx.add_sheet("2. All Providers - Master")
        row2 = ctx.write_title(ws2, f"ALL PROVIDERS — {concept.upper()} STATUS",
            f"Complete list of all {total} providers with classification")

        headers2 = ["#", "Provider Name", "Provider ID", "Status", "Documents Found",
                    "Categories Found", "Effective Date", "Term End Date",
                    "Provider Network Status", "Auto-Renewal",
                    "Line of Business", "LOB Method",
                    "Contract Has Supersession", "Confidence Score",
                    "Confidence Label", "Confidence Reasoning", "Latest Doc Review"]

        master_rows = []
        sorted_findings = sorted(
            report.provider_findings.items(),
            key=lambda x: (-x[1].doc_count, x[0])
        )
        for prov, finding in sorted_findings:
            enr = report.provider_enrichment.get(prov, ProviderEnrichment())
            cats = ", ".join(report.code_to_label(c) for c in sorted(finding.categories.keys()))
            conf = report.confidence_scores.get(prov)
            master_rows.append((
                len(master_rows) + 1, prov, enr.provider_id,
                finding.status.display_label, finding.doc_count, cats,
                enr.effective_date, enr.expiration_date,
                enr.contract_status, enr.auto_renewal,
                enr.lob, enr.lob_method,
                enr.has_supersession,
                conf.score_pct if conf else "",
                conf.label.value if conf else "",
                conf.reasoning if conf else "",
                enr.latest_doc_review,
            ))
        # NO_MENTION providers
        for prov in sorted(report.no_mention_providers):
            enr = report.provider_enrichment.get(prov, ProviderEnrichment())
            conf = report.confidence_scores.get(prov)
            master_rows.append((
                len(master_rows) + 1, prov, enr.provider_id,
                "No Mention", 0, "",
                enr.effective_date, enr.expiration_date,
                enr.contract_status, enr.auto_renewal,
                enr.lob, enr.lob_method,
                "N/A",
                conf.score_pct if conf else "",
                conf.label.value if conf else "",
                conf.reasoning if conf else "",
                "N/A (No Findings)",
            ))
        row2 = ctx.write_table(ws2, row2, headers2, master_rows)
        ctx.auto_widths(ws2, headers2, master_rows)

        # Sheet 3: No Mention / Denied
        ws3 = ctx.add_sheet("3. Not Found")
        row3 = ctx.write_title(ws3, f"PROVIDERS WITHOUT {concept.upper()}",
            f"{nm_n + denied_n} providers with no mention or explicit denial")

        ws3.write(row3, 0, f"A. NO MENTION ({nm_n} providers)", ctx.fmt_section)
        row3 += 1
        nm_rows = [(i, p, f"No {concept} language found")
                   for i, p in enumerate(sorted(report.no_mention_providers), 1)]
        row3 = ctx.write_table(ws3, row3, ["#", "Provider Name", "Finding"], nm_rows, freeze=False)
        row3 += 2

        denied = report.get_denied_providers()
        ws3.write(row3, 0, f"B. EXPLICITLY DENIED ({len(denied)} providers)", ctx.fmt_section)
        row3 += 1
        denied_rows = [(i, p, "Provision explicitly denied")
                       for i, (p, _) in enumerate(sorted(denied.items()), 1)]
        row3 = ctx.write_table(ws3, row3, ["#", "Provider Name", "Finding"], denied_rows, freeze=False)

        # Sheet 4: Detailed Findings
        ws4 = ctx.add_sheet("4. Detailed Findings")
        row4 = ctx.write_title(ws4, f"DETAILED {concept.upper()} FINDINGS",
            f"Every confirmed provision with document, category, and LLM reasoning")

        headers4 = ["#", "Provider Name", "Document", "Page",
                    "Category", "LLM Reasoning", "Key Phrase"]
        detail_rows = []
        relevant = sorted(report.relevant_passages, key=lambda p: p.provider)
        for i, p in enumerate(relevant, 1):
            detail_rows.append((
                i, p.provider, p.filename,
                p.page or "",
                report.code_to_label(p.category),
                _truncate(p.reasoning, 150),
                _truncate(p.key_phrase or p.text[:100], 220),
            ))
        row4 = ctx.write_table(ws4, row4, headers4, detail_rows)
        ctx.auto_widths(ws4, headers4, detail_rows)

        # Sheet 5: Mixed Providers
        ws5 = ctx.add_sheet("5. Mixed - Grant and Deny")
        mixed = report.get_mixed_providers()
        row5 = ctx.write_title(ws5, "PROVIDERS WITH BOTH GRANTS AND RESTRICTIONS",
            f"{len(mixed)} providers have conflicting provisions")

        denial_codes = {t.code for t in report.taxonomy if t.is_denial}
        headers5 = ["#", "Provider Name", "Document", "Classification", "Category"]
        mixed_rows = []
        mixed_passages = [p for p in report.classified_passages
                         if p.provider in mixed and p.is_relevant]
        for i, p in enumerate(sorted(mixed_passages, key=lambda x: x.provider), 1):
            classification = "DENY" if p.category in denial_codes else "GRANT"
            mixed_rows.append((i, p.provider, p.filename, classification,
                              report.code_to_label(p.category)))
        row5 = ctx.write_table(ws5, row5, headers5, mixed_rows)
        ctx.auto_widths(ws5, headers5, mixed_rows)

        # Sheet 6: Methodology
        ws6 = ctx.add_sheet("6. Methodology")
        row6 = ctx.write_title(ws6, "TECHNICAL PROCESS & METHODOLOGY",
            "How the answer was generated and validated")

        plan = report.execution_plan or ExecutionPlan()
        steps = [
            ("Data Source", "tbl_vs_unified_ready"),
            ("Target Concept", f'"{concept}"'),
            ("Execution Plan", f"Core: {plan.core_keywords} | Extended: {plan.extended_keywords}"),
            ("Dynamic Taxonomy", f"{len(report.taxonomy)} sub-categories"),
            ("Hybrid Retrieval", "Vector Search semantic + SQL keyword scan"),
            ("LLM Classification", f"{report.llm_model}"),
            ("Provider Rollup", f"HAS:{has_n} / DENIED:{denied_n} / MIXED:{mixed_n} / NO_MENTION:{nm_n}"),
        ]
        for step, desc in steps:
            ws6.write(row6, 0, step, ctx.fmt_bold)
            ws6.write(row6, 1, desc, ctx.fmt_row_odd)
            row6 += 1
        row6 += 1
        ws6.write(row6, 0, "VALIDATION STATISTICS", ctx.fmt_section)
        row6 += 1
        val_stats = [
            ("Total Passages Classified", str(len(report.classified_passages))),
            ("Relevant Classifications", str(len(report.relevant_passages))),
            ("Unique Providers Found", str(len(report.provider_findings))),
            ("Coverage Rate", f"{len(report.provider_findings)/max(1,total)*100:.1f}% of universe"),
            ("Category Count", str(len(report.taxonomy))),
        ]
        for label, val in val_stats:
            ws6.write(row6, 0, label, ctx.fmt_bold)
            ws6.write(row6, 1, val, ctx.fmt_row_odd)
            row6 += 1
        ws6.set_column(0, 0, 32)
        ws6.set_column(1, 1, 95)

        # Sheet 7: Provider-Category Matrix
        ws7 = ctx.add_sheet("7. Provider-Category Matrix")
        all_categories = sorted(set(p.category for p in report.relevant_passages))
        row7 = ctx.write_title(ws7, "PROVIDER × CATEGORY MATRIX",
            "Document counts per provider per category")

        headers7 = ["#", "Provider Name"] + [report.code_to_label(c) for c in all_categories] + ["TOTAL"]
        matrix_counts: dict[str, dict[str, int]] = {}
        for p in report.relevant_passages:
            if p.provider not in matrix_counts:
                matrix_counts[p.provider] = {}
            matrix_counts[p.provider][p.category] = matrix_counts[p.provider].get(p.category, 0) + 1

        matrix_rows = []
        for i, (prov, cats) in enumerate(
            sorted(matrix_counts.items(), key=lambda x: -sum(x[1].values())), 1
        ):
            row_data = [i, prov] + [cats.get(c, "") for c in all_categories] + [sum(cats.values())]
            matrix_rows.append(tuple(row_data))
        row7 = ctx.write_table(ws7, row7, headers7, matrix_rows)

        # Sheet 8: Offset Dates (optional, only for offset/extraction reports)
        if report.offset_extraction is not None:
            ws8 = ctx.add_sheet("8. Offset Dates")
            ext = report.offset_extraction
            row8 = ctx.write_title(ws8, "OFFSET DATES — EXTRACTED VALUES",
                f"{ext.extracted_count} providers with values | {ext.no_data_count} no data found")
            headers8 = ["#", "Provider Name", "Field", "Value", "Confidence",
                       "Evidence (Quote)", "Source Document"]
            offset_rows = []
            for i, (prov, val) in enumerate(sorted(ext.provider_values.items()), 1):
                offset_rows.append((
                    i, prov,
                    ext.field_definition.field_name.replace("_", " ").title(),
                    val.display_value or val.raw_value,
                    val.confidence.value.upper(),
                    _truncate(val.evidence, 180),
                    str(val.source_file)[-60:],
                ))
            row8 = ctx.write_table(ws8, row8, headers8, offset_rows)
            ctx.auto_widths(ws8, headers8, offset_rows)

    # ==================================================================
    # STRUCTURED EXTRACTION (5 sheets)
    # ==================================================================

    def _export_structured_extraction(self, report: StructuredExtractionReport, ctx: _WorkbookContext) -> None:
        """Export StructuredExtractionReport to 5-sheet Excel."""
        fd = report.field_definition
        field_name = fd.field_name

        # Sheet 1: Executive Summary
        ws1 = ctx.add_sheet("1. Executive Summary")
        row = ctx.write_title(ws1, f"STRUCTURED EXTRACTION: {field_name.replace('_', ' ').upper()}",
            f"{fd.description} | {report.total_universe} providers analyzed")

        ws1.write(row, 0, "FIELD DEFINITION", ctx.fmt_section)
        row += 1
        for label, val in [
            ("Field Name", field_name.replace("_", " ").title()),
            ("Value Type", fd.value_type.value.title()),
            ("Unit", fd.unit or "N/A"),
            ("Description", fd.description),
            ("Keywords", ", ".join(fd.keywords[:8])),
        ]:
            ws1.write(row, 0, label, ctx.fmt_bold)
            ws1.write(row, 1, str(val), ctx.fmt_row_odd)
            row += 1
        row += 1

        ws1.write(row, 0, "EXTRACTION RESULTS", ctx.fmt_section)
        row += 1
        total = report.total_universe or (report.extracted_count + report.no_data_count)
        headers = ["Metric", "Count", "% of Universe", "Interpretation"]
        data_rows = [
            ("Value Extracted", report.extracted_count,
             f"{report.extracted_count/max(1,total)*100:.1f}%", "Successfully extracted value"),
            ("  High Confidence", report.high_confidence_count,
             f"{report.high_confidence_count/max(1,total)*100:.1f}%", "Value clearly stated"),
            ("  Medium Confidence", report.medium_confidence_count,
             f"{report.medium_confidence_count/max(1,total)*100:.1f}%", "May need verification"),
            ("  Low Confidence", report.low_confidence_count,
             f"{report.low_confidence_count/max(1,total)*100:.1f}%", "Value inferred"),
            ("No Data", report.no_data_count,
             f"{report.no_data_count/max(1,total)*100:.1f}%", "No relevant passage found"),
            ("TOTAL UNIVERSE", total, "100%", "Providers with confirmed base agreement"),
        ]
        row = ctx.write_table(ws1, row, headers, data_rows, freeze=False)
        ctx.auto_widths(ws1, headers, data_rows, max_width=65)

        # Sheet 2: Extracted Values
        ws2 = ctx.add_sheet("2. Extracted Values")
        row2 = ctx.write_title(ws2, f"EXTRACTED VALUES: {field_name.replace('_', ' ').upper()}",
            f"{report.extracted_count} providers with values")

        headers2 = ["#", "Provider Name", "Extracted Value", "Display Value",
                   "Confidence", "Evidence (Quote)", "Source Document", "Page"]
        conf_order = {"high": 0, "medium": 1, "low": 2}
        sorted_pv = sorted(report.provider_values.items(),
                          key=lambda x: (conf_order.get(x[1].confidence.value, 3), x[0]))
        value_rows = []
        for i, (prov, data) in enumerate(sorted_pv, 1):
            value_rows.append((
                i, prov,
                str(data.raw_value)[:100],
                str(data.display_value)[:60],
                data.confidence.value.upper(),
                _truncate(data.evidence, 200),
                str(data.source_file)[-60:],
                data.page,
            ))
        row2 = ctx.write_table(ws2, row2, headers2, value_rows)
        ctx.auto_widths(ws2, headers2, value_rows)

        # Sheet 3: No Data Providers
        ws3 = ctx.add_sheet("3. No Data Providers")
        row3 = ctx.write_title(ws3, f"PROVIDERS WITH NO DATA: {field_name.replace('_', ' ').upper()}",
            f"{report.no_data_count} providers")
        headers3 = ["#", "Provider Name", "Possible Reason"]
        nd_rows = [(i, p, "No matching passage in retrieval")
                   for i, p in enumerate(sorted(report.no_data_providers), 1)]
        row3 = ctx.write_table(ws3, row3, headers3, nd_rows)

        # Sheet 4: Value Distribution
        ws4 = ctx.add_sheet("4. Value Distribution")
        row4 = ctx.write_title(ws4, f"VALUE DISTRIBUTION: {field_name.replace('_', ' ').upper()}",
            f"Statistical summary (type: {fd.value_type.value})")
        nums = report.numeric_values()
        if nums:
            import statistics
            ws4.write(row4, 0, "DESCRIPTIVE STATISTICS", ctx.fmt_section)
            row4 += 1
            unit_label = f" {fd.unit}" if fd.unit else ""
            stats_data = [
                ("Count", str(len(nums)), ""),
                ("Minimum", f"{min(nums):.1f}{unit_label}", ""),
                ("Median", f"{statistics.median(nums):.1f}{unit_label}", ""),
                ("Maximum", f"{max(nums):.1f}{unit_label}", ""),
                ("Mean", f"{statistics.mean(nums):.2f}{unit_label}", ""),
            ]
            if len(nums) >= 3:
                stats_data.append(("Std Deviation", f"{statistics.stdev(nums):.2f}{unit_label}", ""))
            row4 = ctx.write_table(ws4, row4, ["Statistic", "Value", "Notes"], stats_data, freeze=False)
        else:
            ws4.write(row4, 0, "No numeric values available for distribution.", ctx.fmt_subtitle)

        # Sheet 5: Methodology
        ws5 = ctx.add_sheet("5. Methodology")
        row5 = ctx.write_title(ws5, "TECHNICAL METHODOLOGY",
            "How values were extracted, normalized, and rolled up")
        steps = [
            ("1. Field Resolution", f"Matched to field '{field_name}' (type: {fd.value_type.value})"),
            ("2. Provider Universe", f"{report.total_universe} providers"),
            ("3. Hybrid Retrieval", f"Vector Search + SQL keyword scan. Candidates: {report.retrieval_count:,}"),
            ("4. LLM Extraction", f"{report.llm_model} extracts values from passages"),
            ("5. Provider Rollup", f"{report.extracted_count} extracted, {report.no_data_count} no data"),
        ]
        for step, desc in steps:
            ws5.write(row5, 0, step, ctx.fmt_bold)
            ws5.write(row5, 1, desc, ctx.fmt_narrative)
            row5 += 1
        ws5.set_column(0, 0, 28)
        ws5.set_column(1, 1, 100)

    # ==================================================================
    # PROVIDER REPORT (4 sheets)
    # ==================================================================

    def _export_provider(self, report: ProviderReport, ctx: _WorkbookContext) -> None:
        """Export ProviderReport to 4-sheet Excel."""
        prov = report.provider_name

        # Sheet 1: Provider Summary
        ws1 = ctx.add_sheet("1. Provider Summary")
        row = ctx.write_title(ws1, f"PROVIDER DEEP DIVE: {prov.upper()}", "Comprehensive contract intelligence")
        prof = report.profile
        ws1.write(row, 0, "PROVIDER PROFILE", ctx.fmt_section)
        row += 1
        for label, val in [
            ("Agreement Type", prof.agreement_type or "N/A"),
            ("Total Rates", str(prof.total_rates)),
            ("Total Amendments", str(prof.total_amendments)),
            ("Avg Inpatient Per Diem", f"${int(prof.avg_inpatient_per_diem):,}" if prof.avg_inpatient_per_diem else "N/A"),
            ("Latest Amendment Date", prof.latest_amendment_date or "N/A"),
        ]:
            ws1.write(row, 0, label, ctx.fmt_bold)
            ws1.write(row, 1, str(val), ctx.fmt_row_odd)
            row += 1
        ws1.set_column(0, 0, 30)
        ws1.set_column(1, 1, 50)

        # Sheet 2: Rate Schedule
        ws2 = ctx.add_sheet("2. Rate Schedule")
        row2 = ctx.write_title(ws2, f"RATE SCHEDULE: {prov}", f"{len(report.rates)} rate entries")
        if report.rates:
            headers_r = ["Rate Category", "Service Category", "Rate Text", "Rate Numeric", "Formula", "Program"]
            rate_rows = [(r.rate_category, r.service_category, r.rate_text,
                         r.rate_numeric or "", r.formula, r.program_normalized)
                        for r in report.rates]
            row2 = ctx.write_table(ws2, row2, headers_r, rate_rows)
            ctx.auto_widths(ws2, headers_r, rate_rows)
        else:
            ws2.write(row2, 0, "No rate data found.", ctx.fmt_subtitle)

        # Sheet 3: Contract Terms
        ws3 = ctx.add_sheet("3. Contract Terms")
        row3 = ctx.write_title(ws3, f"KEY CONTRACT TERMS: {prov}", f"{len(report.terms)} terms")
        if report.terms:
            headers_t = ["Topic", "Title", "Content", "Source"]
            term_rows = [(t.topic, t.title, _truncate(t.content_text, 300), t.source_filename)
                        for t in report.terms]
            row3 = ctx.write_table(ws3, row3, headers_t, term_rows)
            ctx.auto_widths(ws3, headers_t, term_rows)
        else:
            ws3.write(row3, 0, "No contract terms found.", ctx.fmt_subtitle)

        # Sheet 4: Amendments
        ws4 = ctx.add_sheet("4. Amendments")
        row4 = ctx.write_title(ws4, f"AMENDMENT TIMELINE: {prov}", f"{len(report.amendments)} amendments")
        if report.amendments:
            headers_a = ["Order", "Document Type", "Summary of Changes", "Source"]
            amend_rows = [(a.amendment_order, a.document_type,
                          _truncate(a.summary_of_changes, 250), a.source_filename)
                         for a in report.amendments]
            row4 = ctx.write_table(ws4, row4, headers_a, amend_rows)
            ctx.auto_widths(ws4, headers_a, amend_rows)
        else:
            ws4.write(row4, 0, "No amendment data found.", ctx.fmt_subtitle)

    # ==================================================================
    # RATE REPORT (2 sheets)
    # ==================================================================

    def _export_rate(self, report: RateReport, ctx: _WorkbookContext) -> None:
        """Export RateReport to 2-sheet Excel."""
        ws1 = ctx.add_sheet("1. Rate Data")
        row = ctx.write_title(ws1, f"RATE ANALYSIS: {report.query_type.upper().replace('_', ' ')}",
            f"Query type: {report.query_type}")
        if report.rows:
            headers = [c.replace("_", " ").title() for c in report.columns]
            data_rows = [tuple(_truncate(str(r.get(c, "")), 100) for c in report.columns) for r in report.rows]
            row = ctx.write_table(ws1, row, headers, data_rows)
            ctx.auto_widths(ws1, headers, data_rows)
        else:
            ws1.write(row, 0, "No rate data returned.", ctx.fmt_subtitle)

        # Sheet 2: Summary Stats (if numeric data)
        numeric_cols = report.numeric_columns()
        if numeric_cols and report.rows:
            ws2 = ctx.add_sheet("2. Summary Statistics")
            row2 = ctx.write_title(ws2, "SUMMARY STATISTICS", f"{report.row_count} rows analyzed")
            import statistics
            stats_rows = []
            for col in numeric_cols:
                vals = [r[col] for r in report.rows if isinstance(r.get(col), (int, float))]
                if vals:
                    stats_rows.append((col.replace("_", " ").title(),
                        f"{statistics.mean(vals):.2f}", f"{statistics.median(vals):.2f}",
                        f"{min(vals):.2f}", f"{max(vals):.2f}"))
            row2 = ctx.write_table(ws2, row2, ["Column", "Mean", "Median", "Min", "Max"], stats_rows)

    # ==================================================================
    # TEMPORAL REPORT (3 sheets)
    # ==================================================================

    def _export_temporal(self, report: TemporalReport, ctx: _WorkbookContext) -> None:
        """Export TemporalReport to 3-sheet Excel."""
        ws1 = ctx.add_sheet("1. Temporal Summary")
        row = ctx.write_title(ws1, f"TEMPORAL ANALYSIS: {report.provider_filter or 'All Providers'}",
            f"{report.amendment_count} amendments analyzed")
        if report.llm_summary:
            ws1.write(row, 0, "AI CHANGE SUMMARY", ctx.fmt_section)
            row += 1
            for para in _split_paragraphs(report.llm_summary):
                ws1.write(row, 0, para, ctx.fmt_narrative)
                row += 1
        ws1.set_column(0, 0, 120)

        # Sheet 2: Amendment Timeline
        ws2 = ctx.add_sheet("2. Amendment Timeline")
        row2 = ctx.write_title(ws2, "AMENDMENT TIMELINE",
            f"{report.amendment_count} amendments for {report.provider_filter or 'All'}")
        if report.amendments:
            headers_a = ["Provider", "Order", "Document Type", "Summary", "Source"]
            amend_rows = [(a.provider_name, a.amendment_order, a.document_type,
                          _truncate(a.summary_of_changes, 250), a.source_filename)
                         for a in report.amendments]
            row2 = ctx.write_table(ws2, row2, headers_a, amend_rows)
            ctx.auto_widths(ws2, headers_a, amend_rows)
        else:
            ws2.write(row2, 0, "No amendment data found.", ctx.fmt_subtitle)

        # Sheet 3: Concept Evolution
        ws3 = ctx.add_sheet("3. Concept Evolution")
        row3 = ctx.write_title(ws3, "CONCEPT EVOLUTION ACROSS VERSIONS",
            f"{len(report.concept_evolution)} version entries")
        if report.concept_evolution:
            headers_ce = ["Version", "Document", "Passages Found", "Sample Language"]
            evo_rows = [(f"v{e.get('version', '?')}", str(e.get('filename', ''))[-50:],
                        e.get("passage_count", 0), _truncate(e.get("sample_text", ""), 200))
                       for e in report.concept_evolution]
            row3 = ctx.write_table(ws3, row3, headers_ce, evo_rows)
            ctx.auto_widths(ws3, headers_ce, evo_rows)
        else:
            ws3.write(row3, 0, "No concept evolution data.", ctx.fmt_subtitle)

    # ==================================================================
    # COMPARISON REPORT (2 sheets)
    # ==================================================================

    def _export_comparison(self, report: ComparisonReport, ctx: _WorkbookContext) -> None:
        """Export ComparisonReport to 2-sheet Excel."""
        ws1 = ctx.add_sheet("1. Comparison Summary")
        providers_str = " vs ".join(report.providers)
        row = ctx.write_title(ws1, f"PROVIDER COMPARISON: {providers_str}",
            f"Focus: {report.target_concept}")
        if report.llm_summary:
            ws1.write(row, 0, "AI COMPARATIVE ANALYSIS", ctx.fmt_section)
            row += 1
            for para in _split_paragraphs(report.llm_summary):
                ws1.write(row, 0, para, ctx.fmt_narrative)
                ws1.set_row(row, 60)
                row += 1
        ws1.set_column(0, 0, 120)

        # Sheet 2: Side-by-side detail
        if report.comparison_data:
            ws2 = ctx.add_sheet("2. Side-by-Side")
            row2 = ctx.write_title(ws2, "SIDE-BY-SIDE COMPARISON", "")
            if report.comparison_data:
                # comparison_data is dict[provider, dict[metric, value]]
                metric_keys = sorted({k for d in report.comparison_data.values() for k in d})
                cols = ["Provider"] + metric_keys
                headers = [c.replace("_", " ").title() for c in cols]
                data_rows = [
                    tuple([prov] + [_truncate(str(data.get(m, "")), 150) for m in metric_keys])
                    for prov, data in report.comparison_data.items()
                ]
                row2 = ctx.write_table(ws2, row2, headers, data_rows)
                ctx.auto_widths(ws2, headers, data_rows)

    # ==================================================================
    # EXPLANATION REPORT (2 sheets)
    # ==================================================================

    def _export_explanation(self, report: ExplanationReport, ctx: _WorkbookContext) -> None:
        """Export ExplanationReport to 2-sheet Excel."""
        ws1 = ctx.add_sheet("1. Explanation")
        row = ctx.write_title(ws1, f"EXPLANATION: {report.target_concept.upper()}",
            f"Based on {report.citation_count} source passages")
        ws1.write(row, 0, "AI-GENERATED NARRATIVE", ctx.fmt_section)
        row += 1
        for para in _split_paragraphs(report.narrative or "No narrative generated."):
            ws1.write(row, 0, para, ctx.fmt_narrative)
            ws1.set_row(row, max(20, min(len(para) // 3, 200)))
            row += 1
        ws1.set_column(0, 0, 120)

        # Sheet 2: Citations
        ws2 = ctx.add_sheet("2. Source Citations")
        row2 = ctx.write_title(ws2, "SOURCE CITATIONS", f"{report.citation_count} passages")
        if report.evidence_passages:
            headers_e = ["#", "Provider", "Source Document", "Origin", "Excerpt"]
            cite_rows = [(i, p.get("provider", "Unknown"), str(p.get("source", ""))[-50:],
                         p.get("origin", ""), _truncate(p.get("text", ""), 250))
                        for i, p in enumerate(report.evidence_passages[:50], 1)]
            row2 = ctx.write_table(ws2, row2, headers_e, cite_rows)
            ctx.auto_widths(ws2, headers_e, cite_rows)

    # ==================================================================
    # MULTI-CONCEPT REPORT (3 sheets)
    # ==================================================================

    def _export_multi_concept(self, report: MultiConceptReport, ctx: _WorkbookContext) -> None:
        """Export MultiConceptReport to 3-sheet Excel."""
        ws1 = ctx.add_sheet("1. Set Summary")
        row = ctx.write_title(ws1, f"MULTI-CONCEPT ANALYSIS: {report.operator}",
            f"Concepts: {', '.join(report.concepts)}")
        ws1.write(row, 0, "CONCEPT COVERAGE", ctx.fmt_section)
        row += 1
        cov_rows = [(c, cnt, f"{cnt/max(1,report.total_universe)*100:.1f}%")
                    for c, cnt in report.concept_results.items()]
        row = ctx.write_table(ws1, row, ["Concept", "Providers With", "% of Universe"], cov_rows, freeze=False)
        row += 2
        ws1.write(row, 0, f"Operator: {report.operator}", ctx.fmt_bold)
        row += 1
        ws1.write(row, 0, f"Result: {report.match_count} providers match", ctx.fmt_bold)

        # Sheet 2: Matching Providers
        ws2 = ctx.add_sheet("2. Matching Providers")
        row2 = ctx.write_title(ws2, f"PROVIDERS MATCHING: {report.operator}",
            f"{report.match_count} providers")
        prov_rows = [(i, p) for i, p in enumerate(sorted(report.result_set), 1)]
        row2 = ctx.write_table(ws2, row2, ["#", "Provider Name"], prov_rows)

        # Sheet 3: Per-Concept Detail
        ws3 = ctx.add_sheet("3. Per-Concept Detail")
        row3 = ctx.write_title(ws3, "PER-CONCEPT PROVIDER LISTS", "")
        for concept, prov_count in report.concept_results.items():
            ws3.write(row3, 0, concept, ctx.fmt_section)
            ws3.write(row3, 1, f"{prov_count} providers", ctx.fmt_row_odd)
            row3 += 1
        row3 += 1

