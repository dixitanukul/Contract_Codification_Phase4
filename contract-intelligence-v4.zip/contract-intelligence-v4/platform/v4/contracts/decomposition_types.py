"""Type definitions for question decomposition.

No Spark or Databricks SDK dependencies — importable anywhere.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class ComplexityLevel(str, Enum):
    """How complex a question is — determines decomposition strategy."""
    SIMPLE = "SIMPLE"           # Single concept, single provider — direct ReAct
    MODERATE = "MODERATE"       # 2-3 sub-questions, mostly independent
    COMPLEX = "COMPLEX"         # 4+ sub-questions, dependency chain


class SubQuestionType(str, Enum):
    """Classification of what each sub-question requires."""
    RETRIEVAL = "RETRIEVAL"         # Passage search / document fetch
    SQL_QUERY = "SQL_QUERY"         # Analytical SQL query
    CALCULATION = "CALCULATION"     # Arithmetic on retrieved values
    COMPARISON = "COMPARISON"       # Compare two or more results
    LOOKUP = "LOOKUP"               # Provider / entity resolution
    SYNTHESIS = "SYNTHESIS"         # Merge sub-results into final answer


@dataclass
class SubQuestion:
    """A single decomposed sub-question with dependency metadata."""
    id: int
    question: str
    sub_type: SubQuestionType
    depends_on: list[int] = field(default_factory=list)
    suggested_tools: list[str] = field(default_factory=list)
    provider_hint: str | None = None
    # Filled after execution
    result: Any = None
    completed: bool = False

    @property
    def is_ready(self) -> bool:
        """True if all dependencies are satisfied (for scheduling)."""
        return not self.depends_on or all(
            dep_id in _COMPLETED_SET for dep_id in self.depends_on
        )


# Module-level set used by SubQuestion.is_ready — caller must populate
_COMPLETED_SET: set[int] = set()


@dataclass
class DecompositionPlan:
    """
    Result of decomposing a complex question.

    Contains:
      - is_simple: True if no decomposition needed (direct ReAct)
      - sub_questions: ordered list of sub-tasks
      - execution_groups: list of parallel groups (each group is a list of IDs
        that can execute simultaneously)
      - synthesis_prompt: how to merge sub-results into final answer
    """
    is_simple: bool
    complexity: ComplexityLevel = ComplexityLevel.SIMPLE
    original_question: str = ""
    sub_questions: list[SubQuestion] = field(default_factory=list)
    execution_groups: list[list[int]] = field(default_factory=list)
    synthesis_prompt: str = ""
    reasoning: str = ""  # Why this decomposition was chosen

    @property
    def total_sub_questions(self) -> int:
        return len(self.sub_questions)

    @property
    def max_parallelism(self) -> int:
        """Largest parallel group size."""
        if not self.execution_groups:
            return 0
        return max(len(g) for g in self.execution_groups)

    def get_group(self, group_idx: int) -> list[SubQuestion]:
        """Return SubQuestion objects for a given execution group."""
        if group_idx >= len(self.execution_groups):
            return []
        ids = self.execution_groups[group_idx]
        id_to_sq = {sq.id: sq for sq in self.sub_questions}
        return [id_to_sq[i] for i in ids if i in id_to_sq]

    def to_log_dict(self) -> dict:
        return {
            "is_simple": self.is_simple,
            "complexity": self.complexity.value,
            "sub_questions": self.total_sub_questions,
            "execution_groups": len(self.execution_groups),
            "max_parallelism": self.max_parallelism,
            "reasoning": self.reasoning[:200],
        }
