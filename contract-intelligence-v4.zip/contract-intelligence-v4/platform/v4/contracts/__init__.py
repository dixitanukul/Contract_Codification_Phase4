"""platform/v4/contracts — Canonical dataclasses and interfaces."""
from .tool_types import ToolResult, Confidence, ToolStatus
from .agent_types import AgentRequest, AgentResponse, AgentStep, StepAction
from .citation_types import Citation, VerificationResult, VerificationStatus
from .context_types import ResolvedEntity, WorkingData, SessionContext
from .report_types import (
    ProviderStatus, Polarity, ConfidenceLabel, ExtractionConfidence, ValueType,
    TaxonomyEntry, ExecutionPlan, ClassifiedPassage, ProviderFindingSummary,
    ConfidenceScore, DocumentMetadata, ProviderEnrichment, ExtractedValue,
    FieldDefinition, ProviderProfile, RateEntry, ContractTerm, AmendmentEntry,
    ClauseReport, StructuredExtractionReport, ProviderReport, RateReport,
    TemporalReport, ComparisonReport, ExplanationReport, MultiConceptReport,
    ReportConfig, AnyReport, ROUTE_TO_REPORT_TYPE,
)

__all__ = [
    "ToolResult", "Confidence", "ToolStatus",
    "AgentRequest", "AgentResponse", "AgentStep", "StepAction",
    "Citation", "VerificationResult", "VerificationStatus",
    "ResolvedEntity", "WorkingData", "SessionContext",
    # Report types (P5-RPT-1)
    "ProviderStatus", "Polarity", "ConfidenceLabel", "ExtractionConfidence", "ValueType",
    "TaxonomyEntry", "ExecutionPlan", "ClassifiedPassage", "ProviderFindingSummary",
    "ConfidenceScore", "DocumentMetadata", "ProviderEnrichment", "ExtractedValue",
    "FieldDefinition", "ProviderProfile", "RateEntry", "ContractTerm", "AmendmentEntry",
    "ClauseReport", "StructuredExtractionReport", "ProviderReport", "RateReport",
    "TemporalReport", "ComparisonReport", "ExplanationReport", "MultiConceptReport",
    "ReportConfig", "AnyReport", "ROUTE_TO_REPORT_TYPE",
]
