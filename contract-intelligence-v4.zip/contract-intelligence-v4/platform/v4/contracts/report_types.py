"""platform/v4/contracts/report_types.py

P5-RPT-1: Typed dataclasses for all report output shapes.

These types capture what V2 currently returns as HTML strings and
untyped dicts. V3 tools emit these typed objects, which the
presentation layer (excel_export, html_renderer, report_validator)
consumes.

Zero external dependencies — importable without Spark, Delta, or
Databricks SDK.

Report types:
  - ClauseReport           — 8-sheet clause existence analysis
  - StructuredExtractionReport — 5-sheet field extraction
  - ProviderReport         — 4-sheet single provider deep dive
  - RateReport             — 2-3 sheet rate/data queries
  - TemporalReport         — 3-sheet amendment/temporal analysis
  - ComparisonReport       — 3-sheet provider comparison
  - ExplanationReport      — 2-sheet narrative synthesis
  - MultiConceptReport     — 3-sheet multi-concept intersection
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


# ============================================================
# ENUMS
# ============================================================


class ProviderStatus(str, Enum):
    """Provider-level classification result for clause existence."""
    HAS_GRANT = "HAS_GRANT"          # At least one passage grants the clause
    HAS_DENIED = "HAS_DENIED"        # Provision explicitly restricted
    MIXED = "MIXED"                  # Both grant and restrict passages found
    NO_MENTION = "NO_MENTION"        # Zero keyword hits across all documents

    @property
    def display_label(self) -> str:
        return self.value.replace("_", " ").title()

    @property
    def has_findings(self) -> bool:
        return self in (ProviderStatus.HAS_GRANT, ProviderStatus.HAS_DENIED, ProviderStatus.MIXED)


class Polarity(str, Enum):
    """Taxonomy code polarity."""
    GRANT = "GRANT"
    RESTRICT = "RESTRICT"
    ABSENT = "ABSENT"


class ConfidenceLabel(str, Enum):
    """Provider-level confidence tier labels."""
    HIGH = "HIGH"
    MODERATE = "MODERATE"
    LOW = "LOW (Review Required)"


class ExtractionConfidence(str, Enum):
    """Field extraction per-value confidence."""
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


class ValueType(str, Enum):
    """Structured extraction value types."""
    NUMERIC = "numeric"
    DURATION = "duration"
    CURRENCY = "currency"
    DATE = "date"
    TEXT = "text"
    BOOLEAN = "boolean"


# ============================================================
# COMMON SUB-TYPES
# ============================================================


@dataclass(frozen=True)
class TaxonomyEntry:
    """A single code in the dynamic taxonomy for a concept."""
    code: str
    label: str
    description: str = ""
    polarity: Polarity = Polarity.GRANT
    is_denial: bool = False

    @property
    def is_absence_code(self) -> bool:
        return self.polarity == Polarity.ABSENT


@dataclass(frozen=True)
class ExecutionPlan:
    """Keyword plan produced by the LLM for retrieval."""
    core_keywords: list[str] = field(default_factory=list)
    extended_keywords: list[str] = field(default_factory=list)
    precision_strategy: str = "balanced"


@dataclass
class ClassifiedPassage:
    """A single passage classified by the LLM.

    Corresponds to one row in Cell 16 'Detailed Findings' sheet.
    """
    provider: str
    filename: str
    category: str                     # Taxonomy code (e.g. 'OVERPAYMENT_OFFSET')
    is_denial: bool = False
    text: str = ""                    # Full passage text
    reasoning: str = ""               # LLM classification reasoning
    key_phrase: str = ""              # Most relevant phrase extracted
    page: int | None = None           # PDF page number
    keywords: list[str] = field(default_factory=list)

    @property
    def is_relevant(self) -> bool:
        return self.category not in ("NOT_RELEVANT", "UNKNOWN", "")


@dataclass
class ProviderFindingSummary:
    """Rolled-up clause status for one provider.

    Corresponds to one row in Cell 16 'All Providers Master' sheet.
    """
    provider_name: str
    status: ProviderStatus
    documents_found: set[str] = field(default_factory=set)
    categories: dict[str, int] = field(default_factory=dict)  # code -> count
    findings: list[ClassifiedPassage] = field(default_factory=list)

    @property
    def doc_count(self) -> int:
        return len(self.documents_found)


@dataclass
class ConfidenceScore:
    """Provider-level confidence assessment."""
    score: float                      # 0.0 - 1.0
    label: ConfidenceLabel = ConfidenceLabel.MODERATE
    reasoning: str = ""
    doc_count: int = 0
    tier: str = ""                    # Extraction confidence tier (FULL/HIGH/MEDIUM/LOW)

    @property
    def score_pct(self) -> str:
        return f"{self.score:.0%}"


@dataclass
class DocumentMetadata:
    """Per-document metadata from tbl_contract_documents_master."""
    source_filename: str
    provider_name: str = ""
    effective_date: str = ""
    expiration_date: str = ""
    doc_role: str = ""                # Normalized: base_agreement, amendment, etc.
    contract_status: str = ""         # ACTIVE, EXPIRED, Not in Registry
    prior_rates_superseded: str = ""
    supersedes_effective_date: str = ""
    prior_agreement_reference: str = ""
    supersedes_flag: str = ""         # Yes, Yes (Prior Ref), No
    contract_id: str = ""
    version: int = 0
    is_latest_version: bool = False


@dataclass
class ProviderEnrichment:
    """Enrichment metadata attached to each provider in the master sheet."""
    provider_id: str = ""
    effective_date: str = ""
    expiration_date: str = ""
    contract_status: str = ""
    auto_renewal: str = ""
    lob: str = ""                     # Line of Business (comma-separated programs)
    lob_method: str = ""              # Detection method: rate data, title, none
    has_supersession: str = ""        # Yes, Yes (Prior Ref), No, N/A
    confidence: ConfidenceScore | None = None
    latest_doc_review: str = ""       # OK, Needs Review, N/A


@dataclass
class ExtractedValue:
    """A single extracted field value for one provider."""
    provider_name: str
    raw_value: str = ""
    display_value: str = ""
    normalized_value: float | str | None = None
    confidence: ExtractionConfidence = ExtractionConfidence.LOW
    evidence: str = ""
    source_file: str = ""
    page: str | int = ""


@dataclass
class FieldDefinition:
    """Definition of an extraction target field."""
    field_name: str
    value_type: ValueType = ValueType.TEXT
    unit: str = ""
    description: str = ""
    keywords: list[str] = field(default_factory=list)


# ============================================================
# REPORT TYPES
# ============================================================


@dataclass
class ClauseReport:
    """Complete result set for a clause existence analysis.

    Captures the full 8-sheet output from V2 Cell 16's
    _export_clause_existence(). This is the primary report type
    for questions like 'Which providers have offset clauses?'

    Sheets:
      1. Executive Summary (headline counts, category distribution)
      2. All Providers Master (every provider with full enrichment)
      3. No Mention / Denied
      4. Detailed Findings (passage-level)
      5. Mixed Providers (grant + deny)
      6. Methodology
      7. Provider-Category Matrix
      8. Offset Dates (optional, offset reports only)
    """
    # --- Core results ---
    target_concept: str
    provider_findings: dict[str, ProviderFindingSummary] = field(default_factory=dict)
    no_mention_providers: set[str] = field(default_factory=set)
    classified_passages: list[ClassifiedPassage] = field(default_factory=list)
    taxonomy: list[TaxonomyEntry] = field(default_factory=list)
    execution_plan: ExecutionPlan | None = None

    # --- Enrichment (populated by report_enrichment service) ---
    provider_enrichment: dict[str, ProviderEnrichment] = field(default_factory=dict)
    document_metadata: dict[str, DocumentMetadata] = field(default_factory=dict)
    confidence_scores: dict[str, ConfidenceScore] = field(default_factory=dict)

    # --- Metadata ---
    total_universe: int = 0
    question: str = ""
    llm_model: str = ""
    elapsed_s: float = 0.0
    cost_estimate: float = 0.0

    # --- Optional offset extraction (Sheet 8) ---
    offset_extraction: StructuredExtractionReport | None = None

    # ── Computed properties ──────────────────────────────────────

    @property
    def has_count(self) -> int:
        return sum(1 for f in self.provider_findings.values()
                   if f.status in (ProviderStatus.HAS_GRANT, ProviderStatus.HAS_DENIED))

    @property
    def denied_count(self) -> int:
        return sum(1 for f in self.provider_findings.values()
                   if f.status == ProviderStatus.HAS_DENIED)

    @property
    def mixed_count(self) -> int:
        return sum(1 for f in self.provider_findings.values()
                   if f.status == ProviderStatus.MIXED)

    @property
    def no_mention_count(self) -> int:
        return len(self.no_mention_providers)

    @property
    def relevant_passages(self) -> list[ClassifiedPassage]:
        return [p for p in self.classified_passages if p.is_relevant]

    @property
    def category_distribution(self) -> dict[str, int]:
        """Category code -> count of relevant passages."""
        dist: dict[str, int] = {}
        for p in self.relevant_passages:
            dist[p.category] = dist.get(p.category, 0) + 1
        return dist

    def code_to_label(self, code: str) -> str:
        """Look up human-readable label for a taxonomy code."""
        for t in self.taxonomy:
            if t.code == code:
                return t.label
        return code

    def get_mixed_providers(self) -> dict[str, ProviderFindingSummary]:
        return {k: v for k, v in self.provider_findings.items()
                if v.status == ProviderStatus.MIXED}

    def get_denied_providers(self) -> dict[str, ProviderFindingSummary]:
        return {k: v for k, v in self.provider_findings.items()
                if v.status == ProviderStatus.HAS_DENIED}


@dataclass
class StructuredExtractionReport:
    """Result set for Branch H structured field extraction.

    Captures the full 5-sheet output for questions like
    'What is the offset start date for each provider?'

    Sheets:
      1. Executive Summary
      2. Extracted Values
      3. No Data Providers
      4. Value Distribution
      5. Methodology
    """
    field_definition: FieldDefinition
    provider_values: dict[str, ExtractedValue] = field(default_factory=dict)
    no_data_providers: list[str] = field(default_factory=list)
    all_extractions: list[dict] = field(default_factory=list)  # Raw LLM outputs

    # --- Metadata ---
    total_universe: int = 0
    question: str = ""
    llm_model: str = ""
    elapsed_s: float = 0.0
    retrieval_count: int = 0

    # ── Computed properties ──────────────────────────────────────

    @property
    def extracted_count(self) -> int:
        return len(self.provider_values)

    @property
    def no_data_count(self) -> int:
        return len(self.no_data_providers)

    @property
    def high_confidence_count(self) -> int:
        return sum(1 for v in self.provider_values.values()
                   if v.confidence == ExtractionConfidence.HIGH)

    @property
    def medium_confidence_count(self) -> int:
        return sum(1 for v in self.provider_values.values()
                   if v.confidence == ExtractionConfidence.MEDIUM)

    @property
    def low_confidence_count(self) -> int:
        return sum(1 for v in self.provider_values.values()
                   if v.confidence == ExtractionConfidence.LOW)

    def numeric_values(self) -> list[float]:
        """Extract numeric normalized_value entries for distribution stats."""
        return [
            v.normalized_value for v in self.provider_values.values()
            if isinstance(v.normalized_value, (int, float)) and v.normalized_value > 0
        ]


@dataclass
class ProviderProfile:
    """Summary profile for a single provider."""
    provider_name: str
    agreement_type: str = ""
    total_rates: int = 0
    total_amendments: int = 0
    avg_inpatient_per_diem: float | None = None
    latest_amendment_date: str = ""


@dataclass
class RateEntry:
    """A single rate schedule entry."""
    rate_category: str = ""
    service_category: str = ""
    rate_text: str = ""
    rate_numeric: float | None = None
    formula: str = ""
    program_normalized: str = ""


@dataclass
class ContractTerm:
    """A key contract term extracted from a document."""
    topic: str = ""
    title: str = ""
    content_text: str = ""
    source_filename: str = ""


@dataclass
class AmendmentEntry:
    """A single amendment in the timeline."""
    amendment_order: int = 0
    document_type: str = ""
    summary_of_changes: str = ""
    source_filename: str = ""
    provider_name: str = ""


@dataclass
class ProviderReport:
    """Result set for single provider deep dive (Branch B).

    Captures the full 4-sheet output for questions like
    'Show me Sutter Health's contract details.'

    Sheets:
      1. Provider Summary
      2. Rate Schedule
      3. Contract Terms
      4. Amendments
    """
    profile: ProviderProfile
    rates: list[RateEntry] = field(default_factory=list)
    terms: list[ContractTerm] = field(default_factory=list)
    amendments: list[AmendmentEntry] = field(default_factory=list)

    # --- Metadata ---
    question: str = ""
    elapsed_s: float = 0.0

    @property
    def provider_name(self) -> str:
        return self.profile.provider_name


@dataclass
class RateReport:
    """Result set for rate/data queries (Branch D).

    Captures the 2-3 sheet output for questions like
    'What are the average per diem rates?'

    Sheets:
      1. Rate Data (main result table)
      2. Summary Statistics
    """
    query_type: str                   # rates, benchmark, aggregation, capitation, stop_loss
    columns: list[str] = field(default_factory=list)
    rows: list[dict[str, Any]] = field(default_factory=list)

    # --- Metadata ---
    question: str = ""
    elapsed_s: float = 0.0

    @property
    def row_count(self) -> int:
        return len(self.rows)

    @property
    def is_empty(self) -> bool:
        return len(self.rows) == 0

    def numeric_columns(self) -> list[str]:
        """Identify columns that contain numeric data."""
        if not self.rows:
            return []
        numeric: list[str] = []
        for col in self.columns:
            sample = [r.get(col) for r in self.rows[:20] if r.get(col) is not None]
            if sample and all(isinstance(v, (int, float)) for v in sample):
                numeric.append(col)
        return numeric


@dataclass
class TemporalReport:
    """Result set for temporal/amendment analysis (Branch G).

    Captures the 3-sheet output for questions like
    'How has Sutter Health's contract changed over time?'

    Sheets:
      1. Temporal Summary (LLM analysis)
      2. Amendment Timeline
      3. Concept Evolution
    """
    provider_filter: str
    amendments: list[AmendmentEntry] = field(default_factory=list)
    concept_evolution: list[dict[str, Any]] = field(default_factory=list)
    llm_summary: str = ""

    # --- Registry data (for enrichment) ---
    registry_data: list[dict[str, Any]] = field(default_factory=list)

    # --- Metadata ---
    question: str = ""
    elapsed_s: float = 0.0

    @property
    def amendment_count(self) -> int:
        return len(self.amendments)

    @property
    def has_evolution(self) -> bool:
        return len(self.concept_evolution) > 0


@dataclass
class ComparisonReport:
    """Result set for provider comparison (Branch C).

    Captures the 3-sheet output for questions like
    'Compare Sutter Health vs Kaiser rates.'

    Sheets:
      1. Comparison Summary (profiles + LLM analysis)
      2. Rate Comparison
      3. [Optional] Detailed side-by-side
    """
    providers: list[str]
    comparison_data: dict[str, dict[str, Any]] = field(default_factory=dict)
    llm_summary: str = ""
    target_concept: str = ""

    # --- Metadata ---
    question: str = ""
    elapsed_s: float = 0.0


@dataclass
class ExplanationReport:
    """Result set for explanation/narrative synthesis (Branch E).

    Captures the 2-sheet output for questions like
    'Explain how offset clauses work across providers.'

    Sheets:
      1. Explanation (narrative)
      2. Source Citations
    """
    narrative: str
    evidence_passages: list[dict[str, Any]] = field(default_factory=list)
    target_concept: str = ""
    provider_filter: str | None = None

    # --- Metadata ---
    question: str = ""
    elapsed_s: float = 0.0

    @property
    def citation_count(self) -> int:
        return len(self.evidence_passages)


@dataclass
class MultiConceptReport:
    """Result set for multi-concept intersection (Branch F).

    Captures the 3-sheet output for questions like
    'Which providers have BOTH offset AND DOFR clauses?'

    Sheets:
      1. Set Summary
      2. Matching Providers
      3. Concept Matrix
    """
    operator: str                     # INTERSECTION, UNION, DIFFERENCE
    concepts: list[str] = field(default_factory=list)
    result_set: list[str] = field(default_factory=list)  # Matching provider names
    concept_results: dict[str, int] = field(default_factory=dict)  # concept -> provider count

    # --- Metadata ---
    total_universe: int = 0
    question: str = ""
    elapsed_s: float = 0.0

    @property
    def match_count(self) -> int:
        return len(self.result_set)

    @property
    def match_rate(self) -> float:
        if self.total_universe == 0:
            return 0.0
        return self.match_count / self.total_universe


# ============================================================
# REPORT CONFIG (typed equivalent of V2 REPORT_CONFIG dict)
# ============================================================


@dataclass
class ReportConfig:
    """Typed configuration for report generation.

    Replaces V2's REPORT_CONFIG dict with validated, typed fields.
    """
    # LOB filtering
    lob_filter_mode: str = "all"            # all | medi_cal_and_promise | medi_cal_only | promise_only
    lob_detection_layers: str = "title_and_body"  # title_only | title_and_body

    # Supersession definition
    supersedes_definition: str = "full_or_rates"  # rates_only | full_or_rates | any_reference

    # Confidence scoring
    confidence_weights: dict[str, float] = field(default_factory=lambda: {
        "doc_count": 0.50,
        "extraction_tier": 0.30,
        "has_latest_doc": 0.20,
    })
    doc_count_scale: int = 3
    confidence_threshold_high: float = 0.75
    confidence_threshold_moderate: float = 0.40

    # LLM cost controls
    max_passages_per_provider: int = 20
    max_classify_tokens: int = 1500
    classify_batch_size: int = 15
    min_denials_for_revalidation: int = 5

    def confidence_label(self, score: float) -> ConfidenceLabel:
        """Map a raw confidence score to its label."""
        if score >= self.confidence_threshold_high:
            return ConfidenceLabel.HIGH
        if score >= self.confidence_threshold_moderate:
            return ConfidenceLabel.MODERATE
        return ConfidenceLabel.LOW


# ============================================================
# UNION TYPE & FACTORY
# ============================================================

# Type alias for any report
AnyReport = (
    ClauseReport
    | StructuredExtractionReport
    | ProviderReport
    | RateReport
    | TemporalReport
    | ComparisonReport
    | ExplanationReport
    | MultiConceptReport
)

# Route -> report type mapping
ROUTE_TO_REPORT_TYPE: dict[str, type] = {
    "clause_existence": ClauseReport,
    "structured_extraction": StructuredExtractionReport,
    "single_provider": ProviderReport,
    "rate_query": RateReport,
    "temporal": TemporalReport,
    "comparison": ComparisonReport,
    "explanation": ExplanationReport,
    "multi_concept": MultiConceptReport,
}
