"""
Per-tool budget and execution policies.

AgentController / ToolRegistry use these to decide whether to invoke a tool
before a single token of LLM reasoning is spent on it.
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ToolPolicy:
    """
    Immutable policy record for one tool.

    requires_flag: if set, the named feature flag must be True in the
                   session's feature_flags dict before the tool is called.
    max_calls_per_session: enforced by ToolRegistry to prevent run-away loops.
    """
    name: str
    max_cost_usd: float         # Estimated maximum cost per single call
    timeout_s: int              # Hard timeout; ToolRegistry should enforce
    requires_flag: str | None = None
    max_calls_per_session: int = 100
    enabled: bool = True


# ── Policy table ──────────────────────────────────────────────────────────────
# Keys must match tool.name values in tools/*.py exactly.

TOOL_POLICIES: dict[str, ToolPolicy] = {
    # ── Native V3 tools ──────────────────────────────────────────────────────
    "sql_query": ToolPolicy(
        "sql_query", max_cost_usd=0.05, timeout_s=60,
        requires_flag="V4_SQL_TOOL_ENABLED",
    ),
    "calculate": ToolPolicy(
        "calculate", max_cost_usd=0.001, timeout_s=30,
    ),
    "provider_lookup": ToolPolicy(
        "provider_lookup", max_cost_usd=0.005, timeout_s=15,
    ),
    "document_fetch": ToolPolicy(
        "document_fetch", max_cost_usd=0.05, timeout_s=60,
        requires_flag="V4_DOCUMENT_FETCH_ENABLED",
    ),
    "summarize": ToolPolicy(
        "summarize", max_cost_usd=0.30, timeout_s=90,
        requires_flag="V4_GENERATIVE_ENABLED", max_calls_per_session=5,
    ),
    "draft_text": ToolPolicy(
        "draft_text", max_cost_usd=0.20, timeout_s=60,
        requires_flag="V4_GENERATIVE_ENABLED", max_calls_per_session=3,
    ),
    "chart_generate": ToolPolicy(
        "chart_generate", max_cost_usd=0.002, timeout_s=30,
        max_calls_per_session=5,
    ),
    "export_data": ToolPolicy(
        "export_data", max_cost_usd=0.002, timeout_s=60,
        max_calls_per_session=3,
    ),

    # ── Adapter-backed tools ──────────────────────────────────────────────────
    "passage_search": ToolPolicy(
        "passage_search", max_cost_usd=0.05, timeout_s=30,
    ),
    "citation_verify": ToolPolicy(
        "citation_verify", max_cost_usd=0.05, timeout_s=30,
        requires_flag="V4_TRUST_LAYER_ENABLED",
    ),

    # ── Legacy branch adapter tools ───────────────────────────────────────────
    "clause_existence": ToolPolicy(
        "clause_existence", max_cost_usd=6.00, timeout_s=600,
        max_calls_per_session=2,
    ),
    "single_provider": ToolPolicy(
        "single_provider", max_cost_usd=0.50, timeout_s=30,
    ),
    "provider_deep_dive": ToolPolicy(
        "provider_deep_dive", max_cost_usd=0.30, timeout_s=60,
        max_calls_per_session=5,
    ),
    "comparison": ToolPolicy(
        "comparison", max_cost_usd=0.50, timeout_s=60,
        max_calls_per_session=3,
    ),
    "rate_query": ToolPolicy(
        "rate_query", max_cost_usd=0.10, timeout_s=15,
    ),
    "explanation": ToolPolicy(
        "explanation", max_cost_usd=0.30, timeout_s=45,
    ),
    "multi_concept": ToolPolicy(
        "multi_concept", max_cost_usd=12.00, timeout_s=1200,
        max_calls_per_session=1,
    ),
    "temporal": ToolPolicy(
        "temporal", max_cost_usd=0.30, timeout_s=30,
    ),
    "field_extraction": ToolPolicy(
        "field_extraction", max_cost_usd=1.00, timeout_s=120,
        max_calls_per_session=3,
    ),
    # -- W9-36: Genie Space tool ------------------------------------------
    "genie_query": ToolPolicy(
        "genie_query", max_cost_usd=0.02, timeout_s=180,
        requires_flag="GENIE_ENABLED",
        max_calls_per_session=10,
    ),
}

_DEFAULT_POLICY = ToolPolicy("unknown", max_cost_usd=1.0, timeout_s=60)


def get_policy(tool_name: str) -> ToolPolicy:
    """Return the policy for tool_name, falling back to a safe default."""
    return TOOL_POLICIES.get(tool_name, _DEFAULT_POLICY)
