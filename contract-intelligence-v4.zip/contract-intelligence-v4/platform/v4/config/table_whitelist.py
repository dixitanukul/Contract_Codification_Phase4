"""
SQL-generation whitelist for V3/V4.

Only tables in CONTRACT_TABLES_FOR_SQL may be exposed to LLM SQL generation.
This is the security boundary for the sql_query tool.

NEVER add tbl_bis_*, cmc_*, tbl_ec_*, tbl_eval_gold_*, or
tbl_vs_unified_ready (use VS SDK, not SQL) to this list.
"""
from __future__ import annotations

CATALOG = "dev_adb"
SCHEMA  = "raw"


def _fq(name: str) -> str:
    return f"{CATALOG}.{SCHEMA}.{name}"


# ── Approved tables + their natural-language descriptions ─────────────────────
# The sql_query tool injects these descriptions into the LLM context so it can
# write correct JOIN and WHERE conditions without seeing raw column names first.
CONTRACT_TABLES_FOR_SQL: dict[str, str] = {
    "tbl_genie_amendment_timeline": (
        "Full document chain per facility — 6,609 rows, 302 distinct providers. "
        "One row per PDF document in a provider's contract chain. "
        "CRITICAL — ACTUAL column names (wrong names cause UNRESOLVED_COLUMN errors): "
        "provider_id, provider_name, source_filename, "
        "doc_category (STRING — 'amendment' 2871 rows, 'base_agreement' 2288, "
        "'cover_memo' 1220, 'other' 151, 'settlement' 75, 'lra_aco' 4; "
        "NOTE: no 'amendment_type' column — use doc_category instead), "
        "amendment_order (BIGINT — 0=base agreement, 1=first amendment, etc.), "
        "amendment_depth (INT — same as amendment_order), "
        "effective_date_parsed (DATE — parsed effective date; 200 NULLs for undated docs; "
        "NOTE: no 'amendment_date' column — use effective_date_parsed instead), "
        "expiration_date_parsed (DATE — NULL if auto-renewal or not stated), "
        "effective_date (STRING — raw string from contract), "
        "sections_modified_count (STRING), exhibits_replaced_count (STRING), "
        "exhibits_added_count (STRING), prior_rates_superseded (STRING), "
        "summary_of_changes (STRING — LLM-generated), rate_count (BIGINT), "
        "agreement_type, payment_type, auto_renewal, contract_term_years, "
        "v6_coverage_pct (DOUBLE), has_full_clause_text (BOOLEAN). "
        "For temporal queries: ORDER BY effective_date_parsed ASC. "
        "To count amendment docs per provider: WHERE doc_category = 'amendment' GROUP BY provider_name. "
        "For date range filters: WHERE effective_date_parsed BETWEEN date1 AND date2."
    ),
    "tbl_genie_provider_profile": (
        "Provider master profile — 306 rows (1 row per provider_id, 306 unique). "
        "All columns fully populated after data quality validation (99.6% health). "
        "IDENTITY: provider_id, provider_name. "
        "LOB (two columns): "
        "line_of_business (STRING — raw extracted value, 76 distinct values like "
        "'Commercial and Medicare Advantage', 'HMO, EPO, PPO, Medicare Advantage', etc.), "
        "lob_normalized (STRING — standardized into 8 categories: "
        "'Commercial' (102), 'Commercial + Medicare Advantage' (92), "
        "'Commercial + Medicare Advantage + Medi-Cal' (48), 'Commercial + Medicare' (25), "
        "'Medi-Cal' (16), 'Medicare' (11), 'Medicare Advantage' (7), 'Medi-Cal + Medicare' (3); "
        "1 NULL — add IS NOT NULL for strict LOB analyses. "
        "PREFER lob_normalized for LOB filtering and GROUP BY). "
        "lob_extraction_status (STRING — 'SOURCE' or 'INFERRED_FROM_PAYMENT_TYPE'). "
        "CONTRACT TERMS: agreement_type, payment_type (2 NULL — irreducible), "
        "auto_renewal (STRING — compare with string literal 'True' or 'False', NEVER boolean TRUE/FALSE; example: WHERE auto_renewal = 'True'; 'True'=117 / 'False'=188, 0 NULL), "
        "contract_term_years (STRING, 7 NULL — values like '5', '4', '3', 'Evergreen'). "
        "DATES: latest_amendment_date (STRING ISO date, 1 NULL). "
        "COUNTS: total_documents, total_amendments, max_amendment_depth, "
        "total_rates, current_rates. "
        "STATUS & CLASSIFICATION: "
        "is_active (BOOLEAN — TRUE if provider has BOTH current rates AND a non-expired document; "
        "194 active / 112 inactive; CAUTION: some providers are is_active=FALSE but still have "
        "current_rates > 0 because their document expired — do NOT use is_active=TRUE as a "
        "proxy for 'has rates'; use it only when the user asks about active/in-network status), "
        "data_status (STRING — NULL=most complete, 'INCOMPLETE_NO_RATES'=32, 'CAPITATION_NO_FEE_SCHEDULE'=1), "
        "offset_clause_status (STRING — 'HAS'=47 or 'NO_MENTION'=259, never NULL; "
        "IMPORTANT: most providers do NOT have offset clause — only 15% have HAS), "
        "dofr_status (STRING — 'HAS'=141 or 'NO_MENTION'=165, never NULL), "
        "ipa_delegation_status (STRING — 'HAS'=120 or 'NO_MENTION'=186, never NULL). "
        "FINANCIALS: avg_inpatient_per_diem, avg_outpatient_rate, "
        "rate_categories (comma-separated list), has_stop_loss, "
        "stop_loss_threshold, stop_loss_reimbursement_pct. "
        "TERMINATION: termination_for_convenience, "
        "termination_for_convenience_notice_days, termination_cure_period_days. "
        "OTHER: right_to_audit, has_limitation_of_liability, contract_assignable, "
        "audit_notice_days, general_liability_numeric, liability_cap_numeric, "
        "umbrella_excess_numeric, medicaid_participation, contract_length_months, "
        "contract_term_type. "
        "IMPORTANT USAGE RULES: "
        "(1) For clause existence questions (offset/DOFR/IPA), query this table directly using "
        "offset_clause_status/dofr_status/ipa_delegation_status — do NOT run expensive corpus search. "
        "(2) For 'which providers are active and have X?' use: "
        "WHERE is_active = TRUE AND offset_clause_status = 'HAS'. "
        "(3) For LOB filtering, use lob_normalized (8 categories) not line_of_business (76 values). "
        "(4) For 'how many commercial providers?' use: lob_normalized LIKE '%Commercial%'. "
        "(5) For 'how many Medi-Cal providers?' use: lob_normalized LIKE '%Medi-Cal%'. "
        "(6) Prefer this table over passage retrieval for structured/factual contract metadata."
    ),
    "tbl_contract_rates_all": (
        "All rate versions (current + superseded) — 459,902 rows, 518 distinct providers. "
        "Key columns: provider_id, provider_name, canonical_provider_id, source_filename, "
        "rate_category (e.g. 'inpatient_case_rate', 'inpatient_per_diem', "
        "'outpatient_other_outpatient_rates'), "
        "service_category (e.g. 'Coronary Surgery', 'MS-DRG Case Rate - Commercial'), "
        "rate_type_detail, rate_text, rate_numeric (DOUBLE — NULL for non-numeric rates), "
        "effective_date, status ('current'=135,485 or 'superseded'=324,417), "
        "superseded_date, "
        "superseded_by (COMPOSITE KEY — stores 'eff:YYYY-MM-DD|src:<source_filename>'; "
        "to join to tbl_contract_documents_master use "
        "REGEXP_EXTRACT(superseded_by,'src:(.+)',1) = source_filename; "
        "direct equality join always returns 0 rows), "
        "amendment_order (INTEGER 0-22, 100% populated — 0=base agreement, N=Nth amendment), "
        "document_type, program_normalized, formula, revenue_codes, notes. "
        "JOIN to tbl_contract_documents_master ON source_filename for document metadata. "
        "Use WHERE status = 'current' for current rates only. "
        "For point-in-time queries: effective_date <= target_date AND "
        "(superseded_date > target_date OR superseded_date IS NULL) AND status IN ('current','superseded'). "
        "For rate version history: GROUP BY service_category, ORDER BY amendment_order."
    ),
    "dim_provider_canonical": (
        "Provider ID mapping table — 531 rows with unique provider_id (1:1 mapping). "
        "Key columns: provider_id, canonical_name, all_names_used (ARRAY), is_primary_id, "
        "primary_provider_id, doc_count, total_rate_count, latest_effective_date."
    ),
    "tbl_provider_identifiers": (
        "Provider NPI and TIN identifiers — 50,159 rows. "
        "Key columns: provider_id (STRING — FK to tbl_genie_provider_profile.provider_id), "
        "identifier_type (STRING — 'NPI' for 10-digit National Provider Identifier, "
        "'TIN' for 9-digit Tax Identification Number / EIN), "
        "identifier_value (STRING — the actual NPI or TIN number), "
        "effective_date (DATE — when identifier became active), "
        "end_date (DATE — NULL means currently active), "
        "source (STRING — 'FACETS_NAME', 'JSON_EXTRACT', 'TIN_BRIDGE_FACETS', 'PIMS_EXACT_NAME', etc.). "
        "USAGE: To find a provider's NPI, JOIN with tbl_genie_provider_profile on provider_id, "
        "filter WHERE identifier_type = 'NPI' AND end_date IS NULL. "
        "A provider may have multiple NPIs from different sources — prefer source='FACETS_NAME' or 'JSON_EXTRACT'. "
        "For TIN lookup: identifier_type = 'TIN'. "
        "EXAMPLE: SELECT p.provider_name, i.identifier_type, i.identifier_value, i.source "
        "FROM dev_adb.raw.tbl_provider_identifiers i "
        "JOIN dev_adb.raw.tbl_genie_provider_profile p ON CAST(i.provider_id AS STRING) = CAST(p.provider_id AS STRING) "
        "WHERE LOWER(p.provider_name) LIKE '%sharp%' AND i.identifier_type = 'NPI' AND i.end_date IS NULL "
        "ORDER BY i.source LIMIT 5."
    ),
    "tbl_contract_documents_master": (
        "Document master — parsed metadata + amendment roles. 10,348 rows. "
        "Key columns: source_filename (primary key), provider_id, provider_name, "
        "contract_id, doc_role (string values: 'amendment' 5425 rows, "
        "'base_agreement' 3270 rows, 'cover_memo' 1338 rows, 'settlement' 89 rows, "
        "'addendum' 15 rows, 'other' 193 rows), "
        "amendment_order (integer 0-22, 0=base agreement), "
        "effective_date_parsed, expiration_date (STRING — may contain non-ISO values; "
        "use TRY_CAST(expiration_date AS DATE) for filtering), "
        "document_type, doc_category, amendment_depth, agreement_type, payment_type. "
        "Use WHERE doc_role = 'amendment' to count amendment documents. "
        "For expiring contracts: WHERE TRY_CAST(expiration_date AS DATE) BETWEEN start AND end."
    ),
    "tbl_reimb_stop_loss": (
        "Stop loss provisions — 3,847 rows across 389 distinct providers. "
        "CRITICAL — ACTUAL column names (wrong names cause UNRESOLVED_COLUMN errors): "
        "provider_id (STRING — no provider_name column in this table), "
        "stop_loss_id (STRING — unique PK), rule_id (STRING — FK to rate rules), "
        "stop_loss_type (STRING — ONLY 2 live values: 'CASE_RATE' 3477 rows, 'PER_DIEM' 370 rows; "
        "column comment lists AGGREGATE/CORRIDOR but zero rows exist for those values), "
        "attachment_level (FLOAT — dollar threshold where stop-loss activates; 248 rows NULL; "
        "NOTE: this column has a column mask — may return NULL for non-owner service principals), "
        "attachment_unit (STRING — 'TOTAL_CHARGES' | 'TOTAL_DAYS' | 'TOTAL_COST'), "
        "reimburse_formula_type (STRING — 'FIXED_PER_DIEM' | 'PERCENTAGE' | 'CHARGES_LESS_THRESHOLD'), "
        "reimburse_rate (FLOAT — per-diem or fixed amount above threshold; 2,893 rows NULL; column masked), "
        "reimburse_percentage (FLOAT — pct reimbursed above threshold e.g. 80.0; 900 rows NULL; column masked), "
        "aggregate_cap (FLOAT — annual aggregate cap; mostly NULL; column masked), "
        "corridor_amount (FLOAT — corridor gap; mostly NULL; column masked), "
        "applies_to_services (STRING — service lines covered, comma-separated), "
        "source_filename (STRING), effective_date (DATE). "
        "FORBIDDEN column names — do NOT use these (they do not exist in this table): "
        "stop_loss_threshold, calculation_method, rate_category, service_category, rate_numeric, provider_name. "
        "Always use attachment_level instead of stop_loss_threshold. "
        "Always use reimburse_formula_type instead of calculation_method. "
        "PROVIDER FILTER — this table has NO provider_name column. "
        "To filter by provider, JOIN to tbl_genie_provider_profile: "
        "SELECT s.attachment_level, s.stop_loss_type, s.attachment_unit, "
        "s.reimburse_formula_type, s.reimburse_rate, s.reimburse_percentage, p.provider_name "
        "FROM dev_adb.raw.tbl_reimb_stop_loss s "
        "INNER JOIN dev_adb.raw.tbl_genie_provider_profile p ON s.provider_id = p.provider_id "
        "WHERE LOWER(p.provider_name) LIKE '%cedars%' "
        "(replace 'cedars' with the target provider slug). "
        "NEVER write WHERE provider_name = ... directly on this table — it will always error."
    ),
    "tbl_reimb_carve_outs": (
        "Carve-out provisions — 17,229 rows. Items billed separately from the base rate "
        "(implants, drugs, devices, supplies, procedures). "
        "Key columns: provider_id, carve_out_type (IMPLANT | DRUG | DEVICE | PROCEDURE | SUPPLY), "
        "description, threshold_amount, threshold_type (PER_ITEM | PER_CASE | PER_DAY), "
        "reimburse_formula_type (COST_PLUS | PERCENTAGE | FIXED | INVOICE), "
        "reimburse_percentage, reimburse_of (INVOICE_COST | AWP | WAC | CHARGES), "
        "relationship (ADDITIONAL_TO | INSTEAD_OF | ABOVE_THRESHOLD), "
        "revenue_codes, procedure_codes, ndc_codes, effective_date, source_filename. "
        "FORBIDDEN column: provider_name — does not exist in this table. "
        "PROVIDER FILTER — JOIN to tbl_genie_provider_profile: "
        "SELECT c.carve_out_type, c.description, c.threshold_amount, c.reimburse_formula_type, "
        "c.reimburse_percentage, c.reimburse_of, p.provider_name "
        "FROM dev_adb.raw.tbl_reimb_carve_outs c "
        "INNER JOIN dev_adb.raw.tbl_genie_provider_profile p ON c.provider_id = p.provider_id "
        "WHERE LOWER(p.provider_name) LIKE '%sharp%' "
        "AND c.carve_out_type = 'IMPLANT' "
        "(replace 'sharp' and carve_out_type filter as needed). "
        "NEVER write WHERE provider_name = ... directly on this table — it will always error."
    ),
    "tbl_dofr_matrix_extracted": (
        "1,821 rows. Clean structured DOFR (Division of Financial Responsibility) matrix — "
        "extracted via ai_parse_document from original contract PDFs. "
        "Each row = one service line from a provider's DOFR exhibit. "
        "Key columns: provider_id, provider_name, service_category (e.g. PREVENTIVE SERVICES, "
        "HEALTH CARE PROFESSIONAL (OUTPATIENT), FACILITY SERVICES INPATIENT/OUTPATIENT, "
        "VISION CARE, HOME HEALTH CARE, REHAB THERAPY, OTHER SERVICES, AMBULANCE, "
        "BEHAVIORAL HEALTH, PHARMACY, EMERGENCY, RADIOLOGY, LAB SERVICES), "
        "subcategory (specific service line), group_responsible (BOOLEAN), "
        "hospital_responsible (BOOLEAN), health_plan_responsible (BOOLEAN), "
        "notes (STRING), effective_date, source_filename, extracted_at. "
        "IMPORTANT: Use is_current = TRUE for temporal filtering — this is the ONLY correct approach. "
        "NEVER add INNER JOIN to tbl_contract_documents_master (contradicts agent Rule 16a). "
        "The is_current column correctly identifies active-amendment rows. Use: "
        "SELECT service_category, subcategory, group_responsible, "
        "hospital_responsible, health_plan_responsible, notes "
        "FROM dev_adb.raw.tbl_dofr_matrix_extracted "
        "WHERE LOWER(provider_name) LIKE '%<provider>%' "
        "AND is_current = TRUE "
        "AND (group_responsible = true OR hospital_responsible = true OR health_plan_responsible = true) "
        "ORDER BY service_category, subcategory."
    ),
    "tbl_vs_unified_ready": (
        "Contract text passage index — 727,875 chunk rows (all providers). "
        "USE ONLY as fallback when passage_search returns 0 results for a named provider. "
        "Key columns: chunk_id, provider_name (EXACT case as in dim_provider_canonical), "
        "chunk_text (full passage text, 500-2000 chars), embedded_text, "
        "section_header, page_number, doc_role ('base_agreement' | 'amendment'), "
        "chunk_type (STRING — 9 values: 'PASSAGE' 670728, 'SECTION' 17413, 'DEFINITION' 12012, "
        "'RATE_TABLE' 11486, 'PARTY' 6536, 'CLAUSE' 4329, 'CONDITION' 3346, "
        "'AMENDMENT_DELTA' 1886, 'MEDICAL_CODE' 139), "
        "effective_date (ISO or month-name), "
        "is_current (BOOLEAN — TRUE for current-effective version). "
        "Fallback SQL pattern: "
        "SELECT chunk_text, effective_date, section_header FROM dev_adb.raw.tbl_vs_unified_ready "
        "WHERE LOWER(provider_name) LIKE '%<provider>%' AND is_current = TRUE "
        "AND (LOWER(chunk_text) LIKE '%division of financial%' OR LOWER(chunk_text) LIKE '%dofr%' "
        "OR LOWER(chunk_text) LIKE '%financial responsibility%') "
        "ORDER BY effective_date DESC LIMIT 10."
    ),
    "tbl_delegation_matrix": (
        "IPA delegation functions — 770 rows, 119 distinct providers (NOT 256), avg 6.5 delegated functions per provider. "
        "Each row = one delegated function for one IPA provider. "
        "ACTUAL columns (use only these — do NOT invent columns): "
        "delegation_id (STRING — PK), provider_id (STRING), provider_name (STRING), "
        "delegated_function (STRING — values include 'claims_processing', 'credentialing', "
        "'utilization_management', 'quality', 'prior_authorization', 'appeals', 'member_services'), "
        "delegation_level (STRING — extent of delegation: full, partial, administrative), "
        "subdelegation_allowed (BOOLEAN — whether IPA can sub-delegate), "
        "supporting_text (STRING — contract excerpt supporting this delegation entry), "
        "source_filename (STRING), amendment_order (INT), "
        "created_at (TIMESTAMP), is_current (BOOLEAN — TRUE for active-amendment rows). "
        "FORBIDDEN columns that do NOT exist: delegation_scope, contractual_authority, "
        "oversight_requirements, reporting_requirements, effective_date, extraction_source, confidence_score. "
        "For current rows only: WHERE is_current = TRUE. "
        "JOIN to tbl_genie_provider_profile ON provider_id WHERE ipa_delegation_status = 'HAS'. "
        "Use: SELECT delegated_function, COUNT(DISTINCT provider_id) AS provider_count "
        "FROM dev_adb.raw.tbl_delegation_matrix WHERE is_current = TRUE "
        "GROUP BY delegated_function ORDER BY provider_count DESC."
    ),
    # ── Phase 3 additions ──────────────────────────────────────────────────────
    "tbl_contract_clauses": (
        "Contract clause extractions — 7,863 rows, 300 providers, 21 clause categories. "
        "Each row = one extracted clause from a provider's contract document. "
        "Key columns: clause_id (STRING — PK), provider_id (STRING), provider_name (STRING), "
        "source_filename (STRING), "
        "clause_category (STRING — 21 values: OFFSET_CLAUSE, TERMINATION_PROVISIONS, "
        "AUTO_RENEWAL, DISPUTE_RESOLUTION, UM_PRIOR_AUTH, GRIEVANCE_APPEALS, "
        "RECORDS_RETENTION, CONFIDENTIALITY_HIPAA, EMERGENCY_CARE, COB, "
        "ASSIGNMENT_PROHIBITION, INSURANCE_REQUIREMENTS, QUALITY_REPORTING, AUDIT_RIGHTS, "
        "LANGUAGE_ACCESS, INDEMNIFICATION_LIABILITY, CONTINUITY_OF_CARE, CLAIM_SUBMISSION, "
        "CREDENTIALING_REQUIREMENTS, TELEHEALTH, NETWORK_ADEQUACY), "
        "clause_status (STRING — 'HAS' 7849 rows | 'FALSE_POSITIVE' 14 rows; "
        "IMPORTANT: ABSENT does NOT exist in live data — never use it in WHERE clauses), "
        "is_current (BOOLEAN — TRUE for current-amendment clauses only; 670 current rows), "
        "clause_text (STRING — full extracted clause text, can be long), "
        "amendment_order (INT), extraction_method (STRING). "
        "For current clause text: WHERE LOWER(provider_name) LIKE '%<provider>%' "
        "AND clause_status = 'HAS' AND is_current = true ORDER BY clause_category. "
        "For clause coverage: SELECT clause_category, COUNT(DISTINCT provider_id) AS provider_count "
        "FROM dev_adb.raw.tbl_contract_clauses WHERE clause_status = 'HAS' GROUP BY clause_category. "
        "IMPORTANT: This table is the authoritative source for clause text. "
        "For flag existence, prefer tbl_genie_provider_profile.offset_clause_status / dofr_status."
    ),
    "tbl_compliance_tracking": (
        "Provider regulatory compliance status — 2,871 rows, 7 regulations × ~410 providers. "
        "Each row = one regulation evaluated for one provider. "
        "Key columns: compliance_id (STRING), provider_id (STRING), provider_name (STRING), "
        "regulation (STRING — 7 values: 'KNOX_KEENE' 508 rows, 'DMHC_STANDARDS' 498 rows, "
        "'CMS_MA' 517 rows, 'AB_1455' 386 rows, 'SB_137' 352 rows, 'AB_352' 305 rows, 'AB_72' 305 rows; "
        "IMPORTANT: HIPAA, STATE_LICENSING, AB_1107 do NOT exist in this table), "
        "compliance_status (STRING — 'COMPLIANT' 663 | 'PARTIAL' 1231 | 'UNKNOWN' 974 | 'EXEMPT' 3; "
        "IMPORTANT: NON_COMPLIANT does NOT exist in the data — never use it in WHERE clauses), "
        "evidence_text (STRING — text excerpt supporting the determination), "
        "source_filename (STRING), amendment_order (INT), created_at (TIMESTAMP). "
        "For compliance gap analysis: WHERE compliance_status IN ('PARTIAL', 'UNKNOWN'). "
        "For Knox-Keene coverage: WHERE regulation = 'KNOX_KEENE'. "
        "To find providers with compliance gaps: GROUP BY provider_name HAVING COUNT(CASE WHEN compliance_status IN ('PARTIAL','UNKNOWN') THEN 1 END) > 0."
    ),
    "tbl_quality_performance": (
        "Quality program incentive terms by provider — 894 rows, 291 providers, 5 programs. "
        "Each row = one quality program enrollment for one provider. "
        "Key columns: quality_id (STRING — '<provider_id>_<program>'), "
        "provider_id (STRING), provider_name (STRING), "
        "program_name (STRING — 'HEDIS' 470 rows, 'WITHHOLD' 173 rows, "
        "'VALUE_BASED' 164 rows, 'P4P' 71 rows, 'STAR_RATING' 16 rows), "
        "bonus_pct (FLOAT — percentage bonus for meeting targets; many NULL — "
        "contracts describe incentives in prose, not bare N% values), "
        "penalty_pct (FLOAT — withhold or penalty percentage; many NULL), "
        "metric_name (STRING — the quality metric name from the contract), "
        "target_value (FLOAT — numeric target threshold if specified), "
        "payment_mechanism (STRING — how the incentive is paid), "
        "formula_text (STRING — prose description of the incentive formula), "
        "source_filename (STRING), amendment_order (INT), created_at (TIMESTAMP). "
        "FORBIDDEN columns that do NOT exist: target_metric, measurement_period, effective_date. "
        "For incentive analysis: WHERE program_name IN ('P4P','VALUE_BASED') AND bonus_pct IS NOT NULL. "
        "For withhold tracking: WHERE program_name = 'WITHHOLD'. "
        "CAUTION: bonus_pct NULL does not mean no bonus — many contracts use prose descriptions."
    ),
    "tbl_contract_notifications": (
        "Contract notification and notice period terms — 1,934 rows, 521 providers, 7 types. "
        "Each row = one notification-type requirement for one provider. "
        "Key columns: notification_id (STRING), provider_id (STRING), provider_name (STRING), "
        "notification_type (STRING — 7 values: 'TERMINATION' 508 rows, 'RATE_CHANGE' 451 rows, "
        "'AUDIT' 385 rows, 'COMPLIANCE' 265 rows, 'RENEWAL' 198 rows, "
        "'CREDENTIALING' 114 rows, 'CLAIMS_SUBMISSION_DEADLINE' 13 rows; "
        "IMPORTANT: TERMINATION_FOR_CONVENIENCE, TERMINATION_FOR_CAUSE, CONTRACT_RENEWAL, "
        "MATERIAL_CHANGE, DISPUTE_RESOLUTION do NOT exist — never use them in WHERE clauses), "
        "notice_days (INTEGER — required advance notice in days; many NULL if prose-only), "
        "trigger_event (STRING — what event triggers this notice requirement), "
        "source_filename (STRING), effective_date (DATE). "
        "For termination notice period: WHERE notification_type = 'TERMINATION' AND notice_days IS NOT NULL. "
        "For providers requiring > 90 days: WHERE notice_days > 90. "
        "For renewal notices: WHERE notification_type = 'RENEWAL'."
    ),
    "tbl_contract_hierarchy": (
        "Full contract document hierarchy — 10,348 rows, 531 providers. "
        "One row per PDF in a provider's full contract chain across all amendment generations. "
        "Key columns: hierarchy_id (STRING), provider_id (STRING), provider_name (STRING), "
        "source_filename (STRING), document_type (STRING — encodes BaseAgmt/BaseAgmtNew/"
        "BaseAgmtRenew/FirstAmend/SecondAmend/etc.), "
        "amendment_order (INTEGER — 0=base agreement, N=Nth amendment; "
        "multiple rows at order=0 are expected for multi-generation base renewals), "
        "parent_filename (STRING — the document this amends or replaces; NULL for base docs), "
        "effective_date_parsed (DATE), expiration_date_parsed (DATE), "
        "contract_status (STRING — 'ACTIVE' | 'EXPIRED' | 'ACTIVE_NO_EXPIRY' | 'UNKNOWN' | 'FUTURE'), "
        "doc_role (STRING — 'base_agreement' | 'amendment' | 'cover_memo' | 'settlement'), "
        "lob (STRING — line of business), payment_type (STRING). "
        "For amendment chain: WHERE provider_id = '<id>' ORDER BY amendment_order ASC, effective_date_parsed ASC. "
        "NOTE: multiple base documents per provider is by design (contract generation renewals)."
    ),
    "tbl_service_areas": (
        "Provider service area geography — 305 rows (one per profiled provider). "
        "Key columns: provider_id (STRING), provider_name (STRING), "
        "region (STRING — geographic classification e.g. 'Northern California', "
        "'Southern California', 'Central Valley', 'Bay Area', 'Statewide'), "
        "county_list (ARRAY<STRING> — counties served; may be empty for statewide), "
        "service_area_note (STRING — text description from contract), "
        "source_filename (STRING). "
        "For geographic analysis: WHERE region = 'Southern California'. "
        "For county-level: WHERE ARRAY_CONTAINS(county_list, 'Los Angeles'). "
        "Default region is 'Statewide' for most providers."
    ),
    "tbl_rate_benchmarks": (
        "External rate benchmark reference — 10,434 rows. "
        "Used for comparing contracted rates against Medicare, Medi-Cal, and commercial averages. "
        "Key columns: benchmark_id (STRING), service_category (STRING), "
        "benchmark_type (STRING — 'MEDICARE_FFS' | 'MEDI_CAL' | 'COMMERCIAL_AVERAGE'), "
        "benchmark_rate (DOUBLE — the reference rate value), "
        "rate_unit (STRING — PER_CASE | PER_DAY | PER_VISIT | PMPM), "
        "effective_year (INTEGER), geographic_region (STRING), "
        "source_name (STRING — the reference data source). "
        "For rate adequacy analysis: JOIN to tbl_contract_rates_all ON service_category "
        "and compare rate_numeric vs benchmark_rate. "
        "Filter benchmark_type to match the provider's LOB."
    ),
    "tbl_rate_escalators": (
        "Contract rate escalation provisions — covers 104 providers. "
        "Each row = one escalation provision per provider contract. "
        "Key columns: escalator_id (STRING), provider_id (STRING), provider_name (STRING), "
        "escalator_type (STRING — 'CPI' | 'FIXED_PCT' | 'MARKET_RATE' | 'OTHER'), "
        "escalation_pct (DOUBLE — annual percentage increase), "
        "escalation_cap_pct (DOUBLE — maximum allowed escalation per period; NULL if uncapped), "
        "trigger_condition (STRING — condition activating the escalation), "
        "effective_date (DATE), source_filename (STRING). "
        "For CPI-tied escalations: WHERE escalator_type = 'CPI'. "
        "For average escalation rate: SELECT escalator_type, AVG(escalation_pct) "
        "FROM dev_adb.raw.tbl_rate_escalators GROUP BY escalator_type."
    ),
    "tbl_provider_identifiers": (
        "Provider external identifier mapping — 50,159 rows, multiple IDs per provider. "
        "Each row = one identifier for one provider. "
        "Key columns: identifier_id (STRING), provider_id (STRING), provider_name (STRING), "
        "id_type (STRING — 'NPI' | 'TIN' | 'MEDICARE_ID' | 'MEDICAID_ID' | 'STATE_LICENSE'), "
        "id_value (STRING — the identifier value), "
        "effective_date (DATE), source_filename (STRING). "
        "For NPI lookup: WHERE id_type = 'NPI' AND provider_id = '<id>'. "
        "For TIN lookup: WHERE id_type = 'TIN'. "
        "Multiple rows per provider are expected (one per id_type)."
    ),
    # ── Phase 10B-1: Risk & Alerts ──────────────────────────────────────────────
    "tbl_contract_risk_scores": (
        "Composite risk score per provider — 272 rows (one per scored provider). "
        "risk_tier: LOW (239 providers) | MEDIUM (26) | MONITOR (7 — highest risk). "
        "risk_score range 18–48 (higher = more risk). "
        "Component scores: expiration_risk (INT), compliance_gap (INT), clause_gap (INT), "
        "amendment_velocity (INT), fin_risk (INT). "
        "Key columns: provider_id (FK to dim_provider_canonical), provider_name, lob, "
        "payment_type, risk_score (INT 18–48), risk_tier (LOW|MEDIUM|MONITOR), "
        "days_to_expiry (INT — negative = already expired), "
        "compliance_gap (INT — number of compliance gaps), "
        "clause_gap (INT — number of missing standard clauses), "
        "contracted_spend (DOUBLE — annual contracted spend), scored_at (TIMESTAMP). "
        "For risk portfolio overview: GROUP BY risk_tier. "
        "For high-risk providers: WHERE risk_tier IN ('MEDIUM','MONITOR') ORDER BY risk_score DESC. "
        "For expiring providers: WHERE days_to_expiry BETWEEN 0 AND 90 ORDER BY days_to_expiry ASC."
    ),
    "tbl_alert_queue": (
        "Operational alert queue — 351 active alerts (229 CRITICAL, 34 HIGH, 88 MEDIUM). "
        "Generated from contract deadlines. All current alerts have alert_status = 'NEW'. "
        "Key columns: alert_id (STRING UUID PK), provider_id, provider_name, "
        "deadline_type (STRING — EXPIRY | TERMINATION_NOTICE | RATE_CHANGE | etc.), "
        "action_required_by (DATE — date by which action must be taken), "
        "days_until_due (INT — negative = already overdue), "
        "alert_priority (STRING — CRITICAL | HIGH | MEDIUM; NO LOW tier), "
        "alert_status (STRING — NEW | ACKNOWLEDGED | RESOLVED; currently all NEW), "
        "context_text (STRING — human-readable alert description), "
        "source_deadline_id (STRING FK to tbl_contract_deadlines.deadline_id), "
        "created_at (TIMESTAMP). "
        "For critical alerts: WHERE alert_status = 'NEW' AND alert_priority = 'CRITICAL' ORDER BY days_until_due ASC. "
        "For overdue alerts: WHERE days_until_due < 0 ORDER BY days_until_due ASC. "
        "CAUTION: Use alert_priority (NOT 'severity'). NO LOW priority tier exists."
    ),
    "tbl_contract_deadlines": (
        "Unified deadline calendar — 713 contract deadlines across 177 distinct providers. "
        "deadline_type: CONTRACT_EXPIRY (494 rows) | TERMINATION (149) | RENEWAL (70). "
        "priority_tier: CRITICAL (127) | HIGH (122) | MEDIUM (89) | LOW (273) | EXPIRED (102). "
        "Key columns: deadline_id (STRING — NOT unique: 414 distinct / 713 rows), "
        "provider_id, provider_name, deadline_type, "
        "contract_status (STRING — ACTIVE (711) | FUTURE (2)), "
        "event_date (DATE — the deadline date), "
        "action_required_by (DATE — when action must be taken), "
        "days_until_action (INT — negative = overdue; NOT days_until_deadline), "
        "priority_tier (STRING), notice_days (INT), source_filename (STRING), created_at (TIMESTAMP). "
        "For upcoming deadlines: WHERE days_until_action BETWEEN 0 AND 90 AND priority_tier != 'EXPIRED'. "
        "For critical deadlines: WHERE priority_tier = 'CRITICAL' ORDER BY days_until_action ASC. "
        "CAUTION: deadline_id is NOT unique — use DISTINCT when JOINing to tbl_alert_queue. "
        "Use days_until_action (NOT days_until_deadline)."
    ),
    # Phase 10B-2: Financial Intelligence
    "tbl_financial_exposure": (
        "Contracted spend and utilization by provider and period (172 rows). "
        "Columns: provider_id, period_start (DATE), period_end (DATE), line_of_business, "
        "assigned_members (INT), inpatient_admits (INT), outpatient_visits (INT), "
        "contracted_spend (DECIMAL — range $1M–$282M), actual_spend (DECIMAL), "
        "variance_pct (FLOAT — negative = under-spend), "
        "source (STRING — ESTIMATE | CLAIMS; NO 'BUDGET' value), "
        "estimate_confidence (STRING — PROXY_PMPM_x12 | PROXY_AVG_RATE | UNKNOWN). "
        "Covers 172 providers only. Order by contracted_spend DESC for top spenders."
    ),
    "tbl_repricing_scenarios": (
        "Pre-computed what-if rate scenarios (7,600 rows). "
        "Columns: scenario_id, provider_id, provider_name, rate_category, "
        "scenario_label (STRING — SCENARIO_MINUS_5PCT | SCENARIO_PLUS_3PCT | SCENARIO_PLUS_5PCT | SCENARIO_PLUS_10PCT), "
        "rate_delta_pct (DOUBLE), avg_rate (DOUBLE), simulated_rate (DOUBLE), "
        "rate_delta (DOUBLE), rate_row_count (LONG), "
        "estimated_annual_impact (DOUBLE — total dollar impact; use ABS() for sorting), "
        "simulated_at (TIMESTAMP). "
        "Use LOWER(provider_name) LIKE LOWER('%name%') for provider matching. "
        "Sort by ABS(estimated_annual_impact) DESC for highest-impact scenarios."
    ),
    "fact_supersession": (
        "Rate supersession lineage tracking (2,380 rows). "
        "Columns: supersession_id, superseding_filename, superseded_filename, "
        "provider_id (STRING — ALL NULL; must JOIN via filename), contract_chain_id, "
        "supersession_type (ALL 'full_document'), supersession_scope (ALL 'full_document'), "
        "superseding_effective_date (DATE), superseded_effective_date (DATE), superseded_valid_to (DATE), "
        "rate_domain (STRING — INPATIENT | OUTPATIENT | etc.), "
        "old_rate_numeric (FLOAT), new_rate_numeric (FLOAT), rate_change_pct (FLOAT), "
        "clause_type, change_summary, confidence (FLOAT 0-1), "
        "derivation_method (ALL 'temporal_chain'), created_at. "
        "CRITICAL: provider_id is ALL NULL. Must JOIN via filename: "
        "JOIN tbl_contract_documents_master d ON fact_supersession.superseding_filename = d.source_filename "
        "WHERE d.provider_id = :provider_id"
    ),
    "tbl_rate_escalators": (
        "Contract rate escalation terms (104 rows). "
        "Columns: escalator_id, provider_id, provider_name, source_filename, "
        "escalator_type (STRING — CPI (38 rows) | CUSTOM (66 rows)), "
        "base_index (STRING — CPI-U | CPI-W | Medicare IPPS | etc.), "
        "adjustment_pct (FLOAT), floor_pct (FLOAT — minimum annual increase), "
        "cap_pct (FLOAT — maximum annual increase), "
        "frequency (STRING — ANNUAL (28) | OTHER (76)), amendment_order (INT), "
        "formula_text (STRING — verbatim escalation language up to 2000 chars), created_at. "
        "Use LOWER(provider_name) LIKE LOWER('%name%') for matching. "
        "formula_text contains the actual contract language for the escalation clause."
    ),
    # Phase 10B-3: Network & Geography
    "dim_health_system": (
        "Health system master — 20 rows. "
        "Columns: system_id (STRING — e.g. SYS001; FK for JOINs — NOT health_system_id), "
        "system_name (STRING), "
        "system_type (STRING — NON_PROFIT | FOR_PROFIT | ACADEMIC | GOVERNMENT | INDEPENDENT), "
        "facility_count (INT — approximate CA facility count), "
        "name_patterns (STRING — pipe-delimited ILIKE patterns for name matching). "
        "Always use system_id for JOINs — never health_system_id. "
        "JOIN tbl_provider_system_membership ON dim_health_system.system_id = tbl_provider_system_membership.system_id."
    ),
    "tbl_provider_system_membership": (
        "Provider-to-health-system membership — 112 rows, 106 providers, 19 systems. "
        "Columns: provider_id (STRING — FK to dim_provider_canonical), "
        "system_id (STRING — FK to dim_health_system), "
        "membership_type (STRING — all OWNED in live data), "
        "match_pattern (STRING), effective_date (DATE — NULL = unknown), "
        "source (STRING — PATTERN_MATCH | MANUAL | CLAIMS). "
        "IMPORTANT: 63% of providers are NOT in any system — use LEFT JOIN. "
        "JOIN dim_provider_canonical ON provider_id for provider names."
    ),
    "tbl_service_areas": (
        "Provider geographic service areas — 306 rows, 1 per provider. "
        "Columns: service_area_id (= provider_id), provider_id (STRING), provider_name (STRING), "
        "region (STRING — Northern CA | Bay Area | Central Valley | Southern CA | "
        "Inland Empire | Central Coast | Statewide (186 providers) | Unknown), "
        "county (STRING — NULL for most Statewide providers), "
        "assignment_method (STRING — NAME_KEYWORD | HEALTH_SYSTEM | PROVIDER_TYPE | DEFAULT), "
        "created_at (TIMESTAMP). "
        "Use GROUP BY region for geographic distribution."
    ),
    "tbl_clause_deviations": (
        "Network deviation analysis — 7,777 rows, 519 providers, 21 clause categories. "
        "Columns: deviation_id, provider_id, provider_name, clause_category, "
        "clause_status (HAS | ABSENT | MODIFIED), "
        "network_baseline (STRING — most common status in network), "
        "network_has_pct (DOUBLE — % of network providers with HAS; 100.0 = universal), "
        "network_absent_pct (DOUBLE), "
        "deviation_type (STRING — CONFORMANT | DEVIATION), "
        "severity (STRING — NONE | LOW | MEDIUM | HIGH), analyzed_at (TIMESTAMP). "
        "CONFORMANT = matches network norm. DEVIATION = outlier vs network. "
        "Use for network benchmarking and clause deviation analysis."
    ),
    # ── Phase 10B-6: Provenance & Audit ──────────────────────────────────────
    "tbl_extraction_provenance": (
        "Extraction provenance audit trail — 15,368 rows, 1,395 providers. "
        "Columns: extraction_id, target_table, target_record_id, target_column, "
        "extracted_value, confidence_score (NULL for DOFR rows), extraction_method "
        "(only PATTERN_MATCH), model_version, source_page_numbers, human_verified "
        "(ALL false — no manual review done), human_corrected_value, provider_id. "
        "target_table values: tbl_contract_clauses | tbl_contract_notifications | "
        "tbl_compliance_tracking | tbl_delegation_matrix | tbl_dofr_matrix_extracted | "
        "tbl_quality_performance | tbl_rate_escalators. "
        "JOIN tbl_genie_provider_profile ON provider_id to get provider_name. "
        "Use for: where did this data come from, how was it extracted, "
        "how reliable are the extractions, extraction audit trail."
    ),
}

# Fully-qualified names for fast set membership test
CONTRACT_TABLES_FQ: set[str] = {_fq(t) for t in CONTRACT_TABLES_FOR_SQL}

# ── Explicitly blocked prefixes and tables ────────────────────────────────────
BLOCKED_PREFIXES: tuple[str, ...] = (
    "tbl_bis_",    # Claims data — not exposed until Phase 5 governance complete
    "cmc_",        # External CMC tables
    "tbl_ec_",     # External eligibility tables
    "tbl_eval_gold_",  # Gold annotation tables
)

BLOCKED_EXACT: frozenset[str] = frozenset({
    "tbl_retrieval_legal_units",        # dropped — retained as safety block
    "fact_retrieval_telemetry",         # Internal telemetry
    "tbl_agent_sessions",               # Session state — internal
    "tbl_query_cache",                  # Cache — internal
    "tbl_user_feedback",                # Feedback — internal
    "tbl_pipeline_telemetry",           # Pipeline audit — internal
    "dim_table_schema",                 # LLM schema context — internal metadata
})


def is_allowed(table_name: str) -> bool:
    """
    Return True if this table may be exposed to LLM SQL generation.

    Accepts both short names ("tbl_genie_provider_profile") and
    fully-qualified names ("dev_adb.raw.tbl_genie_provider_profile").
    """
    short = table_name.split(".")[-1].strip("`").lower()
    if short in BLOCKED_EXACT:
        return False
    if any(short.startswith(p) for p in BLOCKED_PREFIXES):
        return False
    return short in CONTRACT_TABLES_FOR_SQL


def get_schema_context(tables: list[str] | None = None) -> str:
    """
    Return a natural-language schema description for the given tables
    (or all approved tables if None). Used to build LLM SQL prompts.
    """
    target = tables if tables else list(CONTRACT_TABLES_FOR_SQL.keys())
    lines = ["Available tables for SQL generation:\n"]
    for t in target:
        if t in CONTRACT_TABLES_FOR_SQL:
            lines.append(f"  {_fq(t)}\n    {CONTRACT_TABLES_FOR_SQL[t]}\n")
    return "\n".join(lines)
