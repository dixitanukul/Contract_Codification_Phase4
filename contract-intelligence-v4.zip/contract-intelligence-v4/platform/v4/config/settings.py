"""
V4 runtime settings.

All V4-specific configuration lives here.
To override for testing, import and monkey-patch before calling code under test.
"""
import os

# ── Catalog / Schema — env-driven for dev/staging/prod routing (Step 3.9) ──────────────────────────────────────────────────────────
CATALOG = os.environ.get("APP_CATALOG", "dev_adb")
SCHEMA  = os.environ.get("APP_SCHEMA",  "raw")

# ── LLM Models ────────────────────────────────────────────────────────────────
# LLM endpoint names — read from env vars injected by app.yaml resource bindings.
# Fallback to hardcoded defaults so notebook/test usage still works without env.
LLM_REASONING    = os.environ.get("LLM_ENDPOINT",      "databricks-claude-sonnet-4-6")   # Agent reasoning, SQL gen, synthesis
LLM_FAST         = os.environ.get("LLM_FAST_ENDPOINT", "databricks-claude-haiku-4-5")    # Citation verify, coreference, entity extraction

# ── Vector Search ─────────────────────────────────────────────────────────────
VS_ENDPOINT      = os.environ.get("VS_ENDPOINT_NAME", "contract_intelligence_vs_endpoint")
VS_INDEX_UNIFIED = f"{CATALOG}.{SCHEMA}.idx_unified_v4"  # Step 0.3: single unified index (727K chunks)
# Legacy aliases (both point to unified index now — old indexes deleted in Step 0.2)
VS_INDEX_LEGAL   = VS_INDEX_UNIFIED
VS_INDEX_FULLTEXT = VS_INDEX_UNIFIED

# ── Legacy capability tables (read-only from V3) ──────────────────────────────
TBL_VS_UNIFIED_READY           = f"{CATALOG}.{SCHEMA}.tbl_vs_unified_ready"
TBL_CONTRACT_RATES_ALL         = f"{CATALOG}.{SCHEMA}.tbl_contract_rates_all"
TBL_GENIE_AMENDMENT_TIMELINE   = f"{CATALOG}.{SCHEMA}.tbl_genie_amendment_timeline"
TBL_GENIE_PROVIDER_PROFILE     = f"{CATALOG}.{SCHEMA}.tbl_genie_provider_profile"
TBL_DIM_PROVIDER_CANONICAL     = f"{CATALOG}.{SCHEMA}.dim_provider_canonical"
# Active: used by rate_query.py benchmark mode
TBL_CONTRACT_DOCUMENTS_MASTER  = f"{CATALOG}.{SCHEMA}.tbl_contract_documents_master"
TBL_REIMB_STOP_LOSS            = f"{CATALOG}.{SCHEMA}.tbl_reimb_stop_loss"
TBL_REIMB_CARVE_OUTS           = f"{CATALOG}.{SCHEMA}.tbl_reimb_carve_outs"  # Step 2.6: carve-out provisions

# ── V3-owned persistence tables ───────────────────────────────────────────────
TBL_AGENT_SESSIONS    = f"{CATALOG}.{SCHEMA}.tbl_agent_sessions"
TBL_QUERY_CACHE       = f"{CATALOG}.{SCHEMA}.tbl_query_cache"
TBL_USER_FEEDBACK     = f"{CATALOG}.{SCHEMA}.tbl_user_feedback"
TBL_DIM_TABLE_SCHEMA  = f"{CATALOG}.{SCHEMA}.dim_table_schema"

# ── API telemetry (Step 3.7)
TBL_APP_QUERY_TELEMETRY = f"{CATALOG}.{SCHEMA}.app_query_telemetry"

# ── Legacy telemetry tables (V3 populates via adapters) ───────────────────────
TBL_FACT_RETRIEVAL_TELEMETRY = f"{CATALOG}.{SCHEMA}.fact_retrieval_telemetry"

# ── Phase 10B-1: Risk & Alerts ────────────────────────────────────────────────
TBL_CONTRACT_RISK_SCORES = f"{CATALOG}.{SCHEMA}.tbl_contract_risk_scores"
TBL_ALERT_QUEUE          = f"{CATALOG}.{SCHEMA}.tbl_alert_queue"
TBL_CONTRACT_DEADLINES   = f"{CATALOG}.{SCHEMA}.tbl_contract_deadlines"

# ── Phase 10B-2: Financial Intelligence ────────────────────────────────
TBL_FINANCIAL_EXPOSURE  = f"{CATALOG}.{SCHEMA}.tbl_financial_exposure"
TBL_REPRICING_SCENARIOS = f"{CATALOG}.{SCHEMA}.tbl_repricing_scenarios"
TBL_FACT_SUPERSESSION   = f"{CATALOG}.{SCHEMA}.fact_supersession"
TBL_RATE_ESCALATORS     = f"{CATALOG}.{SCHEMA}.tbl_rate_escalators"

# ── Phase 10B-3: Network & Geography ─────────────────────────────────────────
TBL_DIM_HEALTH_SYSTEM          = f"{CATALOG}.{SCHEMA}.dim_health_system"
TBL_PROVIDER_SYSTEM_MEMBERSHIP = f"{CATALOG}.{SCHEMA}.tbl_provider_system_membership"
TBL_SERVICE_AREAS              = f"{CATALOG}.{SCHEMA}.tbl_service_areas"

# ── Phase 10B-4: Compliance & Quality ────────────────────────────────────────
TBL_COMPLIANCE_TRACKING   = f"{CATALOG}.{SCHEMA}.tbl_compliance_tracking"
TBL_QUALITY_PERFORMANCE   = f"{CATALOG}.{SCHEMA}.tbl_quality_performance"
TBL_CONTRACT_NOTIFICATIONS= f"{CATALOG}.{SCHEMA}.tbl_contract_notifications"

# ── Phase 10B-5: Clause Intelligence ─────────────────────────────────────────
TBL_CONTRACT_CLAUSES    = f"{CATALOG}.{SCHEMA}.tbl_contract_clauses"
TBL_CLAUSE_DEVIATIONS   = f"{CATALOG}.{SCHEMA}.tbl_clause_deviations"

# ── Phase 10B-6: Provenance & Audit ─────────────────────────────────────────
TBL_EXTRACTION_PROVENANCE = f"{CATALOG}.{SCHEMA}.tbl_extraction_provenance"

# ── Agent limits ──────────────────────────────────────────────────────────────
AGENT_MAX_STEPS          = 10
AGENT_DEFAULT_BUDGET_USD = 15.0   # Was 5.0 — must cover clause_existence ($6) + multi_concept ($12)
AGENT_STEP_TIMEOUT_S     = 120
AGENT_TOTAL_TIMEOUT_S    = 600   # NO-TIMEOUT-OUR-SIDE: raised from 90s — let queries run
AGENT_REASONING_MAX_TOKENS = 6000

# ── Tool limits ───────────────────────────────────────────────────────────────
SQL_MAX_ROWS             = 1000
SQL_QUERY_TIMEOUT_S      = 300  # NO-TIMEOUT-OUR-SIDE: raised from 60s
SQL_MAX_TOKENS           = 800    # LLM token budget for NL→SQL generation
PASSAGE_SEARCH_TOP_K     = 20
CALCULATE_MAX_SERIES_LEN = 50_000
DOCUMENT_FETCH_MAX_PAGES = 50
EXPORT_MAX_ROWS          = 10_000
PROVIDER_LOOKUP_MAX_IDS  = 50

# ── Cost estimates (USD per call) ─────────────────────────────────────────────
COST_SQL_QUERY         = 0.001
COST_PASSAGE_SEARCH    = 0.010
COST_CALCULATE         = 0.0001
COST_DOCUMENT_FETCH    = 0.005
COST_PROVIDER_LOOKUP   = 0.0005
COST_CITATION_VERIFY   = 0.020
COST_SUMMARIZE         = 0.150
COST_DRAFT_TEXT        = 0.100
COST_CHART_GENERATE    = 0.002
COST_EXPORT_DATA       = 0.002
COST_REASONING_STEP    = 0.005   # Per LLM reasoning call in the ReAct loop
COST_LEGACY_BRANCH_A   = 5.50   # Branch A (clause_existence) is expensive
COST_LEGACY_BRANCH_FAST = 0.20  # Branches B-H (single-provider class, fast)

# ── Feature flags ─────────────────────────────────────────────────────────────
# All False by default — enable progressively as each phase is validated.
V4_AGENT_ENABLED          = True
V4_SQL_TOOL_ENABLED       = True
V4_DOCUMENT_FETCH_ENABLED = True   # Enabled: DocumentFetchTool queries tbl_vs_unified_ready (fully implemented)
V4_MULTI_TURN_ENABLED     = True
V4_GENERATIVE_ENABLED     = True
V4_TRUST_LAYER_ENABLED    = True
V4_QUERY_CACHE_ENABLED    = True
GENIE_ENABLED             = True    # W9-36: Genie Space integration (Phase 5) — ENABLED per fix plan P4
GENIE_SPACE_ID            = "01f14d360bd51f8d801452065b2df600"
GENIE_QUERY_TIMEOUT_S     = 120

def get_all_flags() -> dict:
    """Return all V3 feature flags as a dict (for injecting into AgentRequest)."""
    return {
        "V4_AGENT_ENABLED":          V4_AGENT_ENABLED,
        "V4_SQL_TOOL_ENABLED":       V4_SQL_TOOL_ENABLED,
        "V4_DOCUMENT_FETCH_ENABLED": V4_DOCUMENT_FETCH_ENABLED,
        "V4_MULTI_TURN_ENABLED":     V4_MULTI_TURN_ENABLED,
        "V4_GENERATIVE_ENABLED":     V4_GENERATIVE_ENABLED,
        "V4_TRUST_LAYER_ENABLED":    V4_TRUST_LAYER_ENABLED,
        "V4_QUERY_CACHE_ENABLED":    V4_QUERY_CACHE_ENABLED,
        "GENIE_ENABLED":             GENIE_ENABLED,
    }


# ── Settings class ─────────────────────────────────────────────────────────────
# Instantiable wrapper around the module-level constants above.
# Allows per-instance override in tests: s = Settings(); s.AGENT_MAX_STEPS = 2

class Settings:
    """
    Instantiable V4 runtime configuration object.

    All attributes default to the module-level constants in this file.
    Override individual values after instantiation for testing:

        s = Settings()
        s.AGENT_MAX_STEPS = 2   # limit steps in unit tests

    Usage:
        from platform.v4.config.settings import Settings
        settings = Settings()
        print(settings.LLM_REASONING)
    """

    # Catalog / Schema — re-read from env at instantiation (Step 3.9)
    CATALOG = os.environ.get("APP_CATALOG", "dev_adb")
    SCHEMA  = os.environ.get("APP_SCHEMA",  "raw")
    TBL_APP_QUERY_TELEMETRY = f"{os.environ.get('APP_CATALOG','dev_adb')}.{os.environ.get('APP_SCHEMA','raw')}.app_query_telemetry"

    # LLM Models
    LLM_REASONING             = LLM_REASONING
    LLM_FAST                  = LLM_FAST
    LLM_MODEL                 = LLM_REASONING   # alias used by SqlQueryTool

    # Vector Search
    VS_ENDPOINT               = VS_ENDPOINT
    VS_INDEX_LEGAL            = VS_INDEX_LEGAL
    VS_INDEX_FULLTEXT         = VS_INDEX_FULLTEXT

    # Legacy tables (read-only)
    TBL_CONTRACT_RATES_ALL         = TBL_CONTRACT_RATES_ALL
    TBL_GENIE_AMENDMENT_TIMELINE   = TBL_GENIE_AMENDMENT_TIMELINE
    TBL_GENIE_PROVIDER_PROFILE     = TBL_GENIE_PROVIDER_PROFILE
    TBL_DIM_PROVIDER_CANONICAL     = TBL_DIM_PROVIDER_CANONICAL
    TBL_CONTRACT_DOCUMENTS_MASTER  = TBL_CONTRACT_DOCUMENTS_MASTER
    TBL_REIMB_STOP_LOSS            = TBL_REIMB_STOP_LOSS
    TBL_REIMB_CARVE_OUTS           = TBL_REIMB_CARVE_OUTS  # Step 2.6: carve-out provisions

    # V3-owned persistence tables
    TBL_AGENT_SESSIONS    = TBL_AGENT_SESSIONS
    TBL_QUERY_CACHE       = TBL_QUERY_CACHE
    TBL_USER_FEEDBACK     = TBL_USER_FEEDBACK
    TBL_DIM_TABLE_SCHEMA  = TBL_DIM_TABLE_SCHEMA

    # Legacy telemetry
    TBL_FACT_RETRIEVAL_TELEMETRY = TBL_FACT_RETRIEVAL_TELEMETRY

    # Agent limits
    AGENT_MAX_STEPS            = AGENT_MAX_STEPS
    AGENT_DEFAULT_BUDGET_USD   = AGENT_DEFAULT_BUDGET_USD
    AGENT_STEP_TIMEOUT_S       = AGENT_STEP_TIMEOUT_S
    AGENT_REASONING_MAX_TOKENS = AGENT_REASONING_MAX_TOKENS

    # Tool limits
    SQL_MAX_ROWS              = SQL_MAX_ROWS
    SQL_QUERY_TIMEOUT_S       = SQL_QUERY_TIMEOUT_S
    SQL_MAX_TOKENS            = SQL_MAX_TOKENS
    PASSAGE_SEARCH_TOP_K      = PASSAGE_SEARCH_TOP_K
    CALCULATE_MAX_SERIES_LEN  = CALCULATE_MAX_SERIES_LEN
    DOCUMENT_FETCH_MAX_PAGES  = DOCUMENT_FETCH_MAX_PAGES
    EXPORT_MAX_ROWS           = EXPORT_MAX_ROWS
    PROVIDER_LOOKUP_MAX_IDS   = PROVIDER_LOOKUP_MAX_IDS

    # Cost estimates
    COST_SQL_QUERY         = COST_SQL_QUERY
    COST_PASSAGE_SEARCH    = COST_PASSAGE_SEARCH
    COST_CALCULATE         = COST_CALCULATE
    COST_DOCUMENT_FETCH    = COST_DOCUMENT_FETCH
    COST_PROVIDER_LOOKUP   = COST_PROVIDER_LOOKUP
    COST_CITATION_VERIFY   = COST_CITATION_VERIFY
    COST_SUMMARIZE         = COST_SUMMARIZE
    COST_DRAFT_TEXT        = COST_DRAFT_TEXT
    COST_CHART_GENERATE    = COST_CHART_GENERATE
    COST_EXPORT_DATA       = COST_EXPORT_DATA
    COST_REASONING_STEP    = COST_REASONING_STEP
    COST_LEGACY_BRANCH_A   = COST_LEGACY_BRANCH_A
    COST_LEGACY_BRANCH_FAST = COST_LEGACY_BRANCH_FAST

    # Feature flags
    V4_AGENT_ENABLED          = V4_AGENT_ENABLED
    V4_SQL_TOOL_ENABLED       = V4_SQL_TOOL_ENABLED
    V4_DOCUMENT_FETCH_ENABLED = V4_DOCUMENT_FETCH_ENABLED
    V4_MULTI_TURN_ENABLED     = V4_MULTI_TURN_ENABLED
    V4_GENERATIVE_ENABLED     = V4_GENERATIVE_ENABLED
    V4_TRUST_LAYER_ENABLED    = V4_TRUST_LAYER_ENABLED
    V4_QUERY_CACHE_ENABLED    = V4_QUERY_CACHE_ENABLED
    GENIE_ENABLED             = GENIE_ENABLED
    GENIE_SPACE_ID            = GENIE_SPACE_ID
    GENIE_QUERY_TIMEOUT_S     = GENIE_QUERY_TIMEOUT_S

    def get_all_flags(self) -> dict:
        """Return all V3 feature flags as a dict."""
        return {
            "V4_AGENT_ENABLED":          self.V4_AGENT_ENABLED,
            "V4_SQL_TOOL_ENABLED":       self.V4_SQL_TOOL_ENABLED,
            "V4_DOCUMENT_FETCH_ENABLED": self.V4_DOCUMENT_FETCH_ENABLED,
            "V4_MULTI_TURN_ENABLED":     self.V4_MULTI_TURN_ENABLED,
            "V4_GENERATIVE_ENABLED":     self.V4_GENERATIVE_ENABLED,
            "V4_TRUST_LAYER_ENABLED":    self.V4_TRUST_LAYER_ENABLED,
            "V4_QUERY_CACHE_ENABLED":    self.V4_QUERY_CACHE_ENABLED,
            "GENIE_ENABLED":             self.GENIE_ENABLED,
        }
