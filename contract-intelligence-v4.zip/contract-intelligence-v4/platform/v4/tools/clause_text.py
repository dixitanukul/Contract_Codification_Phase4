"""ClauseTextTool: Retrieves verbatim clause text and network deviation analysis."""
from __future__ import annotations
from typing import Any
from platform.v4.contracts.tool_types import ToolResult, Confidence, ToolStatus
from platform.v4.tools.base import BaseTool


class ClauseTextTool(BaseTool):
    name = "clause_text"
    description = (
        "Retrieve verbatim clause text, summarise all clauses for a provider, compare clauses "
        "across the network, or check how a provider deviates from network norms. "
        "Use for clause-text retrieval; use clause_existence for HAS/NO_MENTION checks. "
        "clause_status values: HAS | FALSE_POSITIVE (ABSENT does not exist in live data). "
        "is_current=true returns only the current-amendment clause (670 rows). "
        "query_type: clause_text | category_summary | clause_compare | network_norms"
    )

    def __init__(self, spark):
        self.spark = spark
        self.tbl     = "dev_adb.raw.tbl_contract_clauses"
        self.tbl_dev = "dev_adb.raw.tbl_clause_deviations"

    # 21 valid categories (for input normalisation)
    _VALID_CATEGORIES = frozenset({
        "DISPUTE_RESOLUTION", "UM_PRIOR_AUTH", "GRIEVANCE_APPEALS", "RECORDS_RETENTION",
        "CONFIDENTIALITY_HIPAA", "EMERGENCY_CARE", "COB", "ASSIGNMENT_PROHIBITION",
        "INSURANCE_REQUIREMENTS", "TERMINATION_PROVISIONS", "QUALITY_REPORTING",
        "AUDIT_RIGHTS", "LANGUAGE_ACCESS", "INDEMNIFICATION_LIABILITY",
        "CONTINUITY_OF_CARE", "CLAIM_SUBMISSION", "CREDENTIALING_REQUIREMENTS",
        "AUTO_RENEWAL", "TELEHEALTH", "OFFSET_CLAUSE", "NETWORK_ADEQUACY",
    })

    def _run(self, **kwargs: Any) -> ToolResult:
        query_type = kwargs.get("query_type", "clause_text")
        # Accept both 'provider' and 'provider_name' (agent dispatch uses provider_name)
        provider   = kwargs.get("provider", "") or kwargs.get("provider_name", "")
        # FIX-4L: Accept a 'providers' list for multi-provider clause_compare queries
        providers_list = kwargs.get("providers") if isinstance(kwargs.get("providers"), list) else []
        if not provider and providers_list:
            provider = providers_list[0]
        category   = kwargs.get("category", "").upper().replace(" ", "_")
        current_only = kwargs.get("current_only", False)

        current_filter = "AND is_current = true" if current_only else ""

        if query_type == "clause_text":
            # Verbatim text for one provider + category.
            # FIX-4H/4J: Return ALL amendments (current + historical) ordered by
            # is_current DESC, amendment_order DESC so current rows appear first.
            # This ensures providers whose current row has boilerplate/address text
            # (CHW DISPUTE_RESOLUTION, Stanford TERMINATION_PROVISIONS) still surface
            # the historical amendment containing the actual clause language.
            cat_filter = f"AND clause_category = '{category}'" if category else ""
            sql = f"""
                SELECT provider_name, clause_category, clause_subcategory,
                       clause_status,
                       LEFT(clause_text, 800) AS clause_text,
                       is_current, amendment_order,
                       source_filename, extraction_method
                FROM {self.tbl}
                WHERE LOWER(provider_name) LIKE LOWER('%{provider}%')
                  AND clause_status = 'HAS'
                  {cat_filter}
                ORDER BY is_current DESC, amendment_order DESC, clause_category
                LIMIT 8
            """
            caveat = (
                "Returns verbatim extracted text (current + historical amendments). "
                "Rows marked is_current=False are from superseded amendments. "
                "For HAS/NO_MENTION status only use clause_existence route instead."
            )

        elif query_type == "category_summary":
            # All 21 categories with status for a provider
            sql = f"""
                SELECT clause_category,
                       COUNT(*) AS total_rows,
                       SUM(CASE WHEN clause_status = 'HAS' THEN 1 ELSE 0 END) AS has_count,
                       SUM(CASE WHEN is_current THEN 1 ELSE 0 END) AS current_count,
                       MAX(amendment_order) AS latest_amendment
                FROM {self.tbl}
                WHERE LOWER(provider_name) LIKE LOWER('%{provider}%')
                GROUP BY clause_category
                ORDER BY clause_category
            """
            caveat = "Shows all clause categories for provider. has_count > 0 means clause was found."

        elif query_type == "clause_compare":
            # Compare a specific clause category across providers.
            # FIX-4L: Support multi-provider comparison via providers_list.
            if providers_list and len(providers_list) >= 2:
                # Build OR LIKE for each provider (use first token for broader match)
                _or_parts = [
                    f"LOWER(provider_name) LIKE LOWER('%{p.split()[0].lower()}%')"
                    for p in providers_list[:4]
                ]
                prov_filter = f"AND ({' OR '.join(_or_parts)})"
            elif provider:
                prov_filter = f"AND LOWER(provider_name) LIKE LOWER('%{provider}%')"
            else:
                prov_filter = ""
            cat_filter  = f"AND clause_category = '{category}'" if category else ""
            sql = f"""
                SELECT provider_name, clause_category, clause_status,
                       LEFT(clause_text, 800) AS clause_text_preview,
                       REGEXP_EXTRACT(clause_text, '(?si)[(]([0-9]+)[)].{0,5}day', 1) AS days_notice_paren,
                       REGEXP_EXTRACT(clause_text, '(?i)one hundred .{0,30}[(]([0-9]+)[)]', 1) AS days_notice_words,
                       REGEXP_EXTRACT(clause_text, '([0-9]+)-day', 1)           AS days_notice_hyphen,
                       is_current,
                       amendment_order
                FROM {self.tbl}
                WHERE clause_status = 'HAS'
                  {cat_filter}
                  {current_filter}
                  {prov_filter}
                ORDER BY provider_name, is_current DESC, amendment_order DESC
                LIMIT 20
            """
            caveat = f"Comparing clause text for {'matched providers' if provider else 'all providers'} (current + historical). days_notice_paren/hyphen extract notice periods from full text. Preview truncated to 400 chars."

        elif query_type == "network_norms":
            # How provider deviates from network baseline
            prov_filter = f"WHERE LOWER(provider_name) LIKE LOWER('%{provider}%')" if provider else ""
            cat_filter  = f"AND clause_category = '{category}'" if category else ""
            sql = f"""
                SELECT provider_name, clause_category, clause_status,
                       network_baseline, network_has_pct, network_absent_pct,
                       deviation_type, severity
                FROM {self.tbl_dev}
                {prov_filter}
                {'AND' if prov_filter else 'WHERE'} {cat_filter[4:] if cat_filter else '1=1'}
                ORDER BY severity DESC, clause_category
            """
            # Fix: build WHERE correctly
            if provider and category:
                sql = f"""
                    SELECT provider_name, clause_category, clause_status,
                           network_baseline, network_has_pct, network_absent_pct,
                           deviation_type, severity
                    FROM {self.tbl_dev}
                    WHERE LOWER(provider_name) LIKE LOWER('%{provider}%')
                      AND clause_category = '{category}'
                    ORDER BY severity DESC, clause_category
                """
            elif provider:
                sql = f"""
                    SELECT provider_name, clause_category, clause_status,
                           network_baseline, network_has_pct, network_absent_pct,
                           deviation_type, severity
                    FROM {self.tbl_dev}
                    WHERE LOWER(provider_name) LIKE LOWER('%{provider}%')
                    ORDER BY severity DESC, clause_category
                """
            elif category:
                sql = f"""
                    SELECT provider_name, clause_category, clause_status,
                           network_baseline, network_has_pct, network_absent_pct,
                           deviation_type, severity
                    FROM {self.tbl_dev}
                    WHERE clause_category = '{category}'
                    ORDER BY severity DESC, provider_name
                    LIMIT 30
                """
            else:
                sql = f"""
                    SELECT clause_category, deviation_type, severity,
                           ROUND(AVG(network_has_pct), 1) AS avg_network_has_pct,
                           COUNT(*) AS provider_count
                    FROM {self.tbl_dev}
                    GROUP BY clause_category, deviation_type, severity
                    ORDER BY clause_category, severity DESC
                """
            caveat = "deviation_type: CONFORMANT | DEVIATION. severity: NONE | LOW | MEDIUM | HIGH."

        else:
            return ToolResult(
                success=False, data=None,
                summary=f"Unknown query_type: {query_type}. Valid: clause_text | category_summary | clause_compare | network_norms",
                confidence=Confidence.LOW, status=ToolStatus.ERROR,
            )

        df   = self.spark.sql(sql)
        rows = [r.asDict() for r in df.collect()]


        # FIX-4H/4J: Add a note when all returned rows are from superseded amendments.
        # (The query now always returns all amendments so an explicit retry is no longer
        # needed, but we keep the note for transparency.)
        _superseded_note = ""
        if rows and query_type == 'clause_text':
            _any_current = any(r.get('is_current', False) for r in rows)
            _any_historical = any(not r.get('is_current', True) for r in rows)
            if not _any_current and _any_historical:
                _superseded_note = (
                    " (all rows are historical amendments — is_current=FALSE for all"
                    " rows of this provider; use these as the best available contract"
                    " version and present the content to the user)"
                )
            elif _any_historical:
                _superseded_note = " (mix of current and historical amendment rows)"

        # Coerce floats
        for r in rows:
            for k in ("network_has_pct", "network_absent_pct"):
                if r.get(k) is not None:
                    try:
                        r[k] = float(r[k])
                    except (TypeError, ValueError):
                        pass

        # clause_compare: synthesise a per-provider comparison narrative with extracted notice
        # periods. Returns dict-typed data (not a row list) so agent_controller uses the
        # summary string as the final answer rather than _format_rows_as_markdown — which was
        # hiding notice-period details behind OCR header noise in the first 300 chars.
        # This is the same pattern used by temporal_analysis._run_coverage_analysis().
        if query_type == 'clause_compare' and rows:
            import re as _re_cc
            _prov_info: dict = {}
            for _r in rows:
                _pn = str(_r.get('provider_name', '') or '')
                if _pn and _pn not in _prov_info:
                    _ct = str(_r.get('clause_text_preview', '') or '')
                    # SQL REGEXP_EXTRACT searched the full column with two patterns.
                    _days = (
                        str(_r.get('days_notice_paren', '') or '').strip()
                        or str(_r.get('days_notice_words', '') or '').strip()
                        or str(_r.get('days_notice_hyphen', '') or '').strip()
                    )
                    if not _days:
                        # Python fallback: search the 400-char preview.
                        _mc = _re_cc.search(r'\(([0-9]+)\)\s*[Dd]ay', _ct)
                        if not _mc:
                            _mc = _re_cc.search(r'([0-9]+)[- ]day', _ct, _re_cc.IGNORECASE)
                        if not _mc:
                            _mc = _re_cc.search(
                                r'([0-9]+)\s+days?\s+prior', _ct, _re_cc.IGNORECASE
                            )
                        _days = _mc.group(1) if _mc else ''
                    _prov_info[_pn] = {
                        'days': _days,
                        'amendment': _r.get('amendment_order', ''),
                        'is_current': bool(_r.get('is_current', False)),
                    }

            _all_hist = bool(_prov_info) and all(
                not v['is_current'] for v in _prov_info.values()
            )
            _hist_note = (
                '\n*(Note: all rows are from historical amendments — '
                'is_current=FALSE for every returned row. '
                'No current-amendment version exists for this clause category; '
                'the data below is the best available contract information.)*'
            ) if _all_hist else ''

            _cat_label = (
                (rows[0].get('clause_category') or category or 'Clause')
                .replace('_', ' ').title()
            )
            _narr_lines = [
                f'**{_cat_label} — Side-by-Side Comparison '
                f'({len(_prov_info)} providers, {len(rows)} clause rows)**{_hist_note}',
                '',
            ]
            for _pn, _info in _prov_info.items():
                _line = f'* **{_pn}**'
                if _info['days']:
                    _line += f': **{_info["days"]}-day prior written notice** requirement'
                else:
                    _line += ': notice period not directly extractable from available text'
                if _info['amendment'] is not None and _info['amendment'] != '':
                    _line += f' (Amendment #{_info["amendment"]})​'
                _narr_lines.append(_line)

            _narrative = '\n'.join(_narr_lines)
            return ToolResult(
                success=True,
                data={
                    'narrative': _narrative,
                    'provider_summary': {p: v['days'] for p, v in _prov_info.items()},
                    'category': category,
                    'all_historical': _all_hist,
                    'row_count': len(rows),
                },
                summary=_narrative,
                confidence=Confidence.HIGH,
                status=ToolStatus.SUCCESS,
            )

        summary = f"[clause_text:{query_type}] {len(rows)} results{_superseded_note}"
        if caveat:
            summary += f" | {caveat}"
        return ToolResult(
            success=True, data=rows, summary=summary,
            confidence=Confidence.HIGH, status=ToolStatus.SUCCESS,
        )
