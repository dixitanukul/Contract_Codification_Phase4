"""
platform/v4/tools/provider_lookup.py

Provider canonical resolution tool for the V3 agent.

This tool is the agent's single interface for resolving free-text
provider names to their canonical identity.  It delegates to the
ProviderAdapter which owns the SQL and caching logic.

Typical usage in the ReAct loop
--------------------------------
The Planner always schedules provider_lookup first whenever a provider
name is present in the request context.  The resolved CanonicalProvider
is stored in the session context and used by subsequent tools.
"""
from __future__ import annotations

from typing import Any, Optional

from ..adapters.provider_adapter import ProviderAdapter
from ..contracts.tool_types import Confidence, ToolResult
from ..tools.base import BaseTool


class ProviderLookupTool(BaseTool):
    """
    Resolve a free-text provider name to its canonical identity.

    Parameters
    ----------
    adapter : ProviderAdapter
        Injected from the notebook entry point.
    """

    def __init__(self, adapter: Optional[ProviderAdapter] = None) -> None:
        self._adapter = adapter or ProviderAdapter()

    def set_adapter(self, adapter: ProviderAdapter) -> None:
        self._adapter = adapter

    @property
    def name(self) -> str:
        return "provider_lookup"

    def _run(
        self,
        provider_name: str = "",
        fuzzy:         bool = True,
        **kwargs:      Any,
    ) -> ToolResult:
        """
        Parameters
        ----------
        provider_name : Free-text provider name to resolve.
        fuzzy         : If True, fall back to LIKE SQL when exact match fails.
        """
        if not provider_name or not provider_name.strip():
            return ToolResult(
                success=False,
                data=None,
                summary="provider_name is required",
                confidence=Confidence.LOW,
                error_message="Empty provider_name",
            )

        result = self._adapter.resolve(provider_name)

        if not result.success:
            # Try listing similar providers to help disambiguation
            list_result = self._adapter.list_providers(limit=10)
            suggestions = []
            if list_result.success and list_result.data:
                q_words = set(provider_name.lower().split())
                for row in list_result.data:
                    name = row.get("canonical_name", "")
                    if any(w in name.lower() for w in q_words if len(w) > 3):
                        suggestions.append(name)

            return ToolResult(
                success=False,
                data=None,
                summary=(
                    f"Provider '{provider_name}' not found. "
                    + (f"Similar: {', '.join(suggestions[:3])}" if suggestions else "")
                ),
                confidence=Confidence.LOW,
                error_message=result.error_message,
                metadata={"suggestions": suggestions[:5]},
            )

        # W9-29: Confidence based on resolution quality
        if result.success and result.data:
            method = getattr(result.data, "resolution_method", "") if hasattr(result.data, "resolution_method") else ""
            if method == "exact":
                result.confidence = Confidence.HIGH
            elif method in ("alias", "fuzzy"):
                result.confidence = Confidence.MODERATE
            else:
                result.confidence = Confidence.HIGH  # default for successful lookups
        return result

    def get_profile(self, provider_name: str) -> ToolResult:
        """Convenience: resolve provider then fetch full profile."""
        resolve_result = self._run(provider_name=provider_name)
        if not resolve_result.success:
            return resolve_result
        cp = resolve_result.data
        return self._adapter.get_profile(cp.canonical_name)
