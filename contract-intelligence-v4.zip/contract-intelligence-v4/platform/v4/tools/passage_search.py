"""
platform/v4/tools/passage_search.py

Contract passage search tool — wraps the RetrievalAdapter for agent use.

This tool is the agent's primary interface for contract language retrieval.
It calls 4-channel hybrid retrieval (BM25 + semantic + legal + metadata)
via the injected RetrievalAdapter and returns ranked, normalised passages.

Step 1.1 (2026-06-18): Confidence scoring replaced with multi-factor formula
using actual cosine similarity scores + recency from CurrentEffectiveFilter.
"""
from __future__ import annotations

from typing import Any, Optional

from ..adapters.retrieval_adapter import RetrievalAdapter, RetrievedPassage
from ..contracts.tool_types import Confidence, ToolResult
from ..core.current_effective_filter import CurrentEffectiveFilter
from ..tools.base import BaseTool

# Step 1.1: Calibrated threshold for doc_score computation.
# Empirically derived from idx_unified_v4 (GTE-1024d): scores cluster in [0.62, 0.80].
# 0.65 = p50-p75 cutoff; never zeros out for clause queries while still
# discriminating between strong and weak evidence.
_SCORE_THRESHOLD = 0.65


def compute_confidence(
    passages: list,
    current_filter: Optional[CurrentEffectiveFilter] = None,
) -> tuple[float, str]:
    """
    Multi-factor confidence score for passage retrieval results.

    Step 1.1 formula (replaces hardcoded 0.20 * 0.5 and count-based enum):
      confidence = 0.50 * doc_score + 0.30 * passage_score + 0.20 * recency_score

    Parameters
    ----------
    passages : list[RetrievedPassage]
        Retrieved passages with .score (cosine similarity) and .metadata.
    current_filter : CurrentEffectiveFilter, optional
        For recency check. If None, recency_score defaults to 0.5 (unknown).

    Returns
    -------
    tuple[float, str]
        (numeric_confidence, confidence_label)
    """
    if not passages:
        return 0.0, Confidence.LOW

    # Factor 1: doc_score — ratio of high-quality passages (score > threshold)
    scores = [getattr(p, "score", 0.0) for p in passages]
    doc_score = len([s for s in scores if s > _SCORE_THRESHOLD]) / max(len(scores), 1)

    # Factor 2: passage_score — peak semantic relevance
    passage_score = max(scores) if scores else 0.0

    # Factor 3: recency_score — are top passages from current-effective docs?
    if current_filter is not None:
        top_passages = passages[:3]
        latest_doc_flag = any(
            current_filter.is_current(
                getattr(p, "metadata", {}).get("source_filename", "")
                if hasattr(p, "metadata") and isinstance(p.metadata, dict)
                else ""
            )
            for p in top_passages
        )
        recency_score = 1.0 if latest_doc_flag else 0.3
    else:
        recency_score = 0.5  # Unknown — neutral midpoint

    # Composite score
    confidence = 0.50 * doc_score + 0.30 * passage_score + 0.20 * recency_score
    confidence = round(min(1.0, confidence), 3)

    # Map to label
    if confidence >= 0.70:
        label = Confidence.HIGH
    elif confidence >= 0.40:
        label = Confidence.MODERATE
    else:
        label = Confidence.LOW

    return confidence, label


class PassageSearchTool(BaseTool):
    """
    Hybrid contract passage retrieval.

    Parameters
    ----------
    adapter : RetrievalAdapter
        Injected from the notebook entry point.
    current_filter : CurrentEffectiveFilter, optional
        For recency-aware confidence scoring. Injected from notebook entry point.
    """

    def __init__(
        self,
        adapter: Optional[RetrievalAdapter] = None,
        current_filter: Optional[CurrentEffectiveFilter] = None,
    ) -> None:
        self._adapter = adapter or RetrievalAdapter()
        self._current_filter = current_filter

    def set_adapter(self, adapter: RetrievalAdapter) -> None:
        self._adapter = adapter

    def set_current_filter(self, current_filter: CurrentEffectiveFilter) -> None:
        """Late-bind current effective filter (useful in notebook cells)."""
        self._current_filter = current_filter

    @property
    def name(self) -> str:
        return "passage_search"

    def _run(
        self,
        query:         str = "",
        top_k:         int = 10,
        provider:      Optional[str] = None,
        clause_type:   Optional[str] = None,
        use_legal_index: bool = False,
        current_only:  bool = True,
        **kwargs:      Any,
    ) -> ToolResult:
        """
        Parameters
        ----------
        query        : Natural language search query.
        top_k        : Number of passages to retrieve.
        provider     : Optional provider name filter.
        clause_type  : Optional clause type filter (e.g. 'offset', 'dofr').
        use_legal_index: If True, query the legal-unit index instead of fulltext.
        current_only : If True (default), only return passages from current-effective
                       documents. Set False for temporal/amendment history queries.
        """
        if not query or not query.strip():
            return ToolResult(
                success=False,
                data=[],
                summary="query is required for passage_search",
                confidence=Confidence.LOW,
                error_message="Empty query",
            )

        if use_legal_index:
            result = self._adapter.retrieve_legal(query=query, top_k=top_k, **kwargs)
        else:
            result = self._adapter.retrieve(
                query=query,
                top_k=top_k,
                provider=provider,
                clause_type=clause_type,
                current_only=current_only,
                **kwargs,
            )

        # Step 1.1: Multi-factor confidence scoring based on actual passage scores
        if result.success and isinstance(result.data, list):
            numeric_confidence, confidence_label = compute_confidence(
                result.data, self._current_filter
            )
            result.confidence = confidence_label
            # Store numeric score in metadata for downstream use
            if result.metadata is None:
                result.metadata = {}
            result.metadata["confidence_numeric"] = numeric_confidence

        return result
