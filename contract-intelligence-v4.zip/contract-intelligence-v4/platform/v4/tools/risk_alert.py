"""RiskAlertTool: Exposes tbl_contract_risk_scores, tbl_alert_queue, tbl_contract_deadlines."""
from __future__ import annotations
from typing import Any
from platform.v4.contracts.tool_types import ToolResult, Confidence, ToolStatus
from platform.v4.tools.base import BaseTool


class RiskAlertTool(BaseTool):
    name = "risk_alert"
    description = (
        "Query contract risk scores, active alerts, and upcoming deadlines. "
        "Use for risk assessment, alert triage, and deadline tracking. "
        "query_type: risk_summary | risk_detail | alerts | deadlines | provider_risk"
    )

    def __init__(self, spark):
        self.spark = spark
        self.catalog = "dev_adb"
        self.schema = "raw"

    def _run(self, **kwargs: Any) -> ToolResult:
        question = (kwargs.get("question", "") or "").lower()
        query_type = kwargs.get("query_type", "") or ""
        provider = kwargs.get("provider", "") or kwargs.get("provider_name", "")
        priority = kwargs.get("priority", None)
        risk_tier_filter = kwargs.get("risk_tier", None)
        days_ahead = int(kwargs.get("days_ahead", 90))

        # Self-route: infer query_type from question when not explicitly provided.
        # This prevents the default 'alerts' from firing on risk-score questions.
        if not query_type or query_type == "alerts":
            if any(w in question for w in (
                "risk distribution", "risk breakdown", "risk across",
                "risk by tier", "risk summary", "risk tiers",
                "distribution across",
            )):
                query_type = "risk_summary"
            elif any(w in question for w in (
                "monitor tier", "monitor risk", "monitor-tier",
                "in the monitor", "providers in monitor",
            )):
                query_type = "risk_tier_list"
                risk_tier_filter = risk_tier_filter or "MONITOR"
            elif any(w in question for w in (
                "high tier", "high risk tier", "in the high tier",
            )):
                query_type = "risk_tier_list"
                risk_tier_filter = risk_tier_filter or "HIGH"
            elif any(w in question for w in (
                "risk score", "risk tier for", "risk level for",
                "risk assessment for", "risk profile",
            )):
                query_type = "provider_risk" if provider else "risk_summary"
            elif any(w in question for w in (
                "critical alert", "active alert", "alert queue",
                "active right now", "current alert",
            )):
                query_type = "alerts"
                if not priority and "critical" in question:
                    priority = "CRITICAL"
            else:
                query_type = "alerts"

        tbl_risk = f"{self.catalog}.{self.schema}.tbl_contract_risk_scores"
        tbl_alerts = f"{self.catalog}.{self.schema}.tbl_alert_queue"
        tbl_deadlines = f"{self.catalog}.{self.schema}.tbl_contract_deadlines"
        _alert_count_sql: str | None = None  # set in 'alerts' branch for total-count disclosure

        if query_type == "risk_summary":
            sql = f"""
                SELECT risk_tier, COUNT(*) as provider_count,
                       ROUND(AVG(risk_score), 1) as avg_score,
                       ROUND(SUM(contracted_spend), 0) as total_spend
                FROM {tbl_risk}
                GROUP BY risk_tier ORDER BY avg_score DESC
            """
        elif query_type == "risk_detail":
            sql = f"""
                SELECT * FROM {tbl_risk}
                WHERE LOWER(provider_name) LIKE LOWER('%{provider}%')
            """
        elif query_type == "risk_tier_list":
            tier_clause = f"AND UPPER(risk_tier) = UPPER('{risk_tier_filter}')" if risk_tier_filter else ""
            sql = f"""
                SELECT provider_name, risk_tier, risk_score,
                       days_to_expiry, compliance_gap, contracted_spend
                FROM {tbl_risk}
                WHERE 1=1 {tier_clause}
                ORDER BY risk_score DESC
            """
        elif query_type == "alerts":
            priority_filter = f"AND alert_priority = '{priority}'" if priority else ""
            provider_filter = f"AND LOWER(provider_name) LIKE LOWER('%{provider}%')" if provider else ""
            # 8-C-COUNT-FIX: count ALL records matching priority/provider (no date filter)
            # so the total matches the known fact (229 total CRITICAL) even though
            # the displayed rows are filtered to active/future-due ones.
            _alert_count_sql = f"""
                SELECT COUNT(*) AS total
                FROM {tbl_alerts}
                WHERE {priority_filter.lstrip('AND').strip() or '1=1'}
                  {('AND ' + provider_filter.lstrip('AND').strip()) if provider_filter.strip() else ''}
            """
            sql = f"""
                SELECT alert_id, provider_name, deadline_type, action_required_by,
                       DATEDIFF(action_required_by, CURRENT_DATE()) AS days_until_due,
                       alert_priority, context_text
                FROM {tbl_alerts}
                WHERE alert_status = 'NEW'
                  AND action_required_by >= CURRENT_DATE()
                  {priority_filter}
                  {provider_filter}
                ORDER BY action_required_by ASC
                LIMIT 25
            """
        elif query_type == "deadlines":
            provider_filter_dl = f"AND LOWER(provider_name) LIKE LOWER('%{provider}%')" if provider else ""
            sql = f"""
                SELECT DISTINCT deadline_id, provider_name, deadline_type, event_date,
                       action_required_by,
                       DATEDIFF(action_required_by, CURRENT_DATE()) AS days_until_action,
                       priority_tier, notice_days
                FROM {tbl_deadlines}
                WHERE action_required_by >= CURRENT_DATE()
                  AND DATEDIFF(action_required_by, CURRENT_DATE()) <= {days_ahead}
                  AND priority_tier != 'EXPIRED'
                  {{provider_filter_dl}}
                ORDER BY action_required_by ASC
                LIMIT 50
            """
            sql = sql.format(provider_filter_dl=provider_filter_dl)
        elif query_type == "provider_risk":
            sql = f"""
                SELECT r.provider_name, r.risk_tier, r.risk_score,
                       r.days_to_expiry, r.compliance_gap, r.contracted_spend,
                       COUNT(DISTINCT a.alert_id) as active_alerts,
                       MIN(d.days_until_action) as nearest_deadline
                FROM {tbl_risk} r
                LEFT JOIN {tbl_alerts} a ON r.provider_id = a.provider_id AND a.alert_status = 'NEW'
                LEFT JOIN {tbl_deadlines} d ON r.provider_id = d.provider_id AND d.priority_tier != 'EXPIRED'
                WHERE LOWER(r.provider_name) LIKE LOWER('%{provider}%')
                GROUP BY r.provider_name, r.risk_tier, r.risk_score,
                         r.days_to_expiry, r.compliance_gap, r.contracted_spend
            """
        else:
            return ToolResult(success=False, data=None, summary=f"Unknown query_type: {query_type}",
                             confidence=Confidence.LOW, status=ToolStatus.ERROR)

        df = self.spark.sql(sql)
        rows = [row.asDict() for row in df.collect()]
        # For paginated alert queries, include total count so the LLM can report
        # the full scope (e.g. '25 of 229 CRITICAL alerts shown').
        _summary_extra = ""
        if query_type == "alerts" and _alert_count_sql is not None:
            try:
                _total = self.spark.sql(_alert_count_sql).collect()[0]['total']
                if _total > len(rows):
                    _ptype = f" {priority}" if priority else ""
                    _summary_extra = f" (showing {len(rows)} of {_total} total{_ptype} alerts)"
            except Exception:
                pass
        return ToolResult(
            success=True, data=rows,
            summary=f"[risk_alert:{query_type}] {len(rows)} results{_summary_extra}",
            confidence=Confidence.HIGH, status=ToolStatus.SUCCESS,
        )
