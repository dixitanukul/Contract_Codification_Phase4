"""
platform/v4/tools/clause_existence/classifier.py

P4C-CE-4: Batch LLM classification + polarity-aware provider rollup.

ClauseClassifier:
  classify_all()    -- parallel ThreadPoolExecutor, batch_size=15, max_workers=2 (was 14; reduced to prevent 429 thundering herd)
  classify_batch()  -- single batch LLM call with retry logic
  provider_rollup() -- polarity-aware HAS/DENIED/MIXED/NO_MENTION per provider
  verify_key_phrases() / verify_numbers() -- citation grounding checks

Migrated from V2 Cell 5 _classify_batch(), Cell 6 _classify_all_passages(),
_provider_rollup(), _verify_key_phrases(), _verify_numbers().
"""
from __future__ import annotations

import json
import logging
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Dict, List, Optional, Set, Tuple

from platform.v4.services.concepts import category_polarity_map
from platform.v4.config.settings import LLM_REASONING

logger = logging.getLogger(__name__)

# Hard-coded FP guard phrases (third-party lien = hospital hold-harmless, not plan offset)
_LIEN_PHRASES = ("third party lien", "third-party lien", "third party liens")


class ClauseClassifier:
    """
    Classify candidate passages and roll them up to provider-level verdicts.

    Constructor
    -----------
    llm_client    : DatabricksLLMClient (required for classify_all/classify_batch)
    batch_size    : passages per LLM call (default 15)
    max_workers   : parallel LLM calls (default 14)
    max_tokens    : per classify_batch call (default 1500)
    """

    def __init__(
        self,
        llm_client: Any,
        batch_size: int = 15,
        max_workers: int = 2,   # Reduced from 14: more threads just cause 429 thundering herd.
        max_tokens: int = 1500, # Global semaphore in DatabricksLLMClient caps concurrency at 4;
    ) -> None:                  # 2 workers here keeps classifier from saturating that budget.
        self._llm = llm_client
        self._batch_size = batch_size
        self._max_workers = max_workers
        self._max_tokens = max_tokens

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def classify_all(
        self,
        candidates: List[Dict],
        understanding: Dict,
        taxonomy: List[Dict],
    ) -> List[Dict]:
        """
        Classify ALL candidates via parallel LLM calls.

        Uses ThreadPoolExecutor with max_workers concurrent batches.
        Returns flat list of classified passage dicts (one dict per passage).
        """
        if not candidates:
            return []

        target = understanding.get("target_concept", "the provision")
        taxonomy_codes = [cat["code"] for cat in taxonomy]
        plan = understanding.get("_plan", {})
        disambiguation_rules = plan.get("disambiguation_rules") if plan else None

        batches = [
            candidates[i:i + self._batch_size]
            for i in range(0, len(candidates), self._batch_size)
        ]
        classified: List[Dict] = []
        completed = 0
        total_batches = len(batches)

        with ThreadPoolExecutor(max_workers=self._max_workers) as executor:
            futures = {
                executor.submit(
                    self.classify_batch,
                    batch, target, taxonomy_codes, disambiguation_rules
                ): i
                for i, batch in enumerate(batches)
            }
            for future in as_completed(futures):
                try:
                    classified.extend(future.result())
                except Exception:
                    pass
                completed += 1
                if completed % 20 == 0 or completed == total_batches:
                    logger.info(
                        "classify_all: %d/%d batches done (%d passages)",
                        completed, total_batches, len(classified)
                    )

        return classified

    def classify_batch(
        self,
        batch: List[Dict],
        target: str,
        taxonomy_codes: List[str],
        disambiguation_rules: Optional[List[str]] = None,
    ) -> List[Dict]:
        """
        Classify a single batch of passages via LLM.

        Hard-coded FP guard: third-party lien passages classified as
        NO_OFFSET_RIGHTS / CONDITIONAL_OFFSET_RESTRICTION are forced to
        NOT_RELEVANT (hospital hold-harmless for member injury funds, not
        a restriction on the plan's offset rights).

        Retries once at temperature=0 on JSON parse failure.
        Returns list of classified dicts (category, reasoning, key_phrase added).
        """
        batch_text = ""
        for j, c in enumerate(batch):
            batch_text += (
                f"\n---PASSAGE {j+1} (Provider: {c['provider']}, "
                f"File: {c['filename']})---\n{c['text'][:600]}\n"
            )

        disam_section = (
            "\nDISAMBIGUATION:\n" + "\n".join(f"- {r}" for r in disambiguation_rules)
            if disambiguation_rules else ""
        )
        codes_str = ", ".join(taxonomy_codes)
        prompt = (
            f'Classify each passage regarding "{target}" in provider contracts.'
            f"{disam_section}\n\n"
            f"Categories: [{codes_str}, NOT_RELEVANT]\n\n"
            "For EACH passage return: category, reasoning (1 sentence), "
            "key_phrase (exact quote, max 100 chars).\n"
            "NOT_RELEVANT when the passage does not address the concept.\n"
            "Return ONLY a JSON array: "
            '[{"passage_num":1,"category":"...","reasoning":"...","key_phrase":"..."}]'
            f"\n\nPassages:{batch_text}"
        )

        results = self._run_classify_llm(prompt, batch, taxonomy_codes)

        # Hard-coded FP guard: third-party lien clauses
        for cls in results:
            if cls.get("category") in ("NO_OFFSET_RIGHTS", "CONDITIONAL_OFFSET_RESTRICTION"):
                kp_lower = (cls.get("key_phrase") or "").lower()
                rsn_lower = (cls.get("reasoning") or "").lower()
                if any(p in kp_lower or p in rsn_lower for p in _LIEN_PHRASES):
                    cls["category"] = "NOT_RELEVANT"
                    cls["reasoning"] = (
                        "[Hard override: third-party lien = hospital hold-harmless "
                        "for member injury funds, not plan offset restriction]"
                    )

        return results

    def provider_rollup(
        self,
        classified: List[Dict],
        taxonomy: List[Dict],
        all_providers: List[str],
        target_concept: str,
    ) -> Tuple[Dict, List[str]]:
        """
        Polarity-aware rollup: HAS / DENIED / MIXED / NO_MENTION per provider.

        Polarity semantics:
          GRANT    -> positive_count (counts toward HAS)
          RESTRICT -> denial_count  (creates DENIED / MIXED)
          ABSENT   -> absent_count  (NEUTRAL — NEVER creates MIXED)

        Rollup:
          positive > 0 AND denial > 0  -> MIXED
          positive > 0                 -> HAS_<CONCEPT>
          denial > 0 (no positive)     -> <CONCEPT>_DENIED
          only ABSENT / none           -> NO_MENTION
        """
        pol = category_polarity_map(taxonomy)
        provider_data: Dict[str, Any] = {}

        for c in classified:
            if c.get("category") == "NOT_RELEVANT":
                continue
            prov = c["provider"]
            if prov not in provider_data:
                provider_data[prov] = {
                    "positive_cats": set(), "denial_cats": set(), "absent_cats": set(),
                    "positive_count": 0, "denial_count": 0, "absent_count": 0,
                    "docs": set(), "findings": [], "categories": {},
                }
            cat = c["category"]
            pd_ = provider_data[prov]
            pd_["findings"].append(c)
            pd_["docs"].add(c["filename"])
            pd_["categories"][cat] = pd_["categories"].get(cat, 0) + 1
            polarity = pol.get(cat, "GRANT")
            if polarity == "RESTRICT":
                pd_["denial_cats"].add(cat)
                pd_["denial_count"] += 1
            elif polarity == "ABSENT":
                pd_["absent_cats"].add(cat)
                pd_["absent_count"] += 1
            else:
                pd_["positive_cats"].add(cat)
                pd_["positive_count"] += 1

        concept_label = (
            target_concept.upper().replace(" ", "_").replace("-", "_")
        )
        absent_only: List[str] = []
        # Two thresholds calibrated against V2 offset v8 baseline (HAS=304, MIXED=3,
        # DENIED=4, NO_MENTION=15). V3 retrieval is broader, so extra passages can
        # introduce minor opposing evidence for otherwise-clear providers.
        #
        # MIXED_DENIAL_RATIO_THRESHOLD = 0.30:
        #   Require denial evidence >= 30% of total before classifying MIXED.
        #   At 0.20 (prior value), providers with 1-2 incidental RESTRICT passages out
        #   of 8-10 GRANT passages were false-positively MIXED.
        #
        # STRONGLY_DENIED_THRESHOLD = 0.65:
        #   When denial evidence dominates (>= 65% of total), override MIXED -> DENIED.
        #   Handles providers where V3 retrieval finds 1-2 incidental GRANT passages for
        #   what is fundamentally a denial-only provider (V2 DENIED=4 category).
        MIXED_DENIAL_RATIO_THRESHOLD = 0.30
        STRONGLY_DENIED_THRESHOLD    = 0.65

        for prov, data in provider_data.items():
            data["doc_count"] = len(data.get("docs", set()))
            if data["positive_count"] > 0 and data["denial_count"] > 0:
                total = data["positive_count"] + data["denial_count"]
                denial_ratio = data["denial_count"] / total
                if denial_ratio >= STRONGLY_DENIED_THRESHOLD:
                    # Denial evidence dominates: treat as DENIED despite minor GRANT noise
                    data["status"] = f"{concept_label}_DENIED"
                elif denial_ratio >= MIXED_DENIAL_RATIO_THRESHOLD:
                    data["status"] = "MIXED"
                else:
                    # Minor restriction — classify as HAS (offset exists with minor caveats)
                    data["status"] = f"HAS_{concept_label}"
            elif data["positive_count"] > 0:
                data["status"] = f"HAS_{concept_label}"
            elif data["denial_count"] > 0:
                data["status"] = f"{concept_label}_DENIED"
            else:
                # Only ABSENT findings -> neutral -> NO_MENTION
                absent_only.append(prov)

        for prov in absent_only:
            del provider_data[prov]

        no_mention = sorted(set(all_providers) - set(provider_data.keys()))
        return provider_data, no_mention

    def verify_key_phrases(self, classified: List[Dict]) -> List[Dict]:
        """Six-check key phrase grounding verification."""
        for c in classified:
            kp = c.get("key_phrase", "")
            text = c.get("text", "")
            if not kp or not text:
                c["kp_verified"] = None
                continue
            kp_clean = kp.lower().strip().strip("\"'")
            tl = text.lower()
            checks = [
                kp_clean in tl,
                kp_clean[:80] in tl,
                all(w in tl for w in kp_clean.split()[:5]),
                any(kp_clean[i:i+30] in tl for i in range(0, min(len(kp_clean), 60), 15)),
                len(set(kp_clean.split()) & set(tl.split())) / max(1, len(kp_clean.split())) > 0.5,
                len(kp_clean) < 20,
            ]
            c["kp_verified"] = any(checks)
        return classified

    def verify_numbers(self, classified: List[Dict]) -> List[Dict]:
        """Detect hallucinated numbers not present in source text."""
        trivial = {"0","1","2","3","4","5","6","7","8","9","10","100"}
        for c in classified:
            reasoning = c.get("reasoning", "")
            kp = c.get("key_phrase", "")
            text = c.get("text", "")
            llm_nums = set(re.findall(r"\b\d+(?:\.\d+)?\b", reasoning + " " + kp))
            src_nums = set(re.findall(r"\b\d+(?:\.\d+)?\b", text))
            hallucinated = llm_nums - src_nums - trivial
            c["num_verified"] = not hallucinated
            c["hallucinated_numbers"] = list(hallucinated)
        return classified

    # ------------------------------------------------------------------
    # Internal: LLM call with retry
    # ------------------------------------------------------------------

    def _run_classify_llm(
        self,
        prompt: str,
        batch: List[Dict],
        taxonomy_codes: List[str],
    ) -> List[Dict]:
        """Run LLM classification with one retry on JSON parse failure."""
        default_cat = taxonomy_codes[0] if taxonomy_codes else "CONFIRMED_PRESENT"

        def _parse_and_apply(raw: str) -> Optional[List[Dict]]:
            raw = raw.strip()
            if raw.startswith("```"):
                raw = raw.split("\n", 1)[-1].rsplit("```", 1)[0]
            if not raw.endswith("]"):
                last = raw.rfind("}")
                if last > 0:
                    raw = raw[:last+1] + "]"
            items = json.loads(raw)
            results = []
            classified_idxs: Set[int] = set()
            for cls in items:
                idx = cls.get("passage_num", 1) - 1
                if 0 <= idx < len(batch):
                    classified_idxs.add(idx)
                    c = batch[idx].copy()
                    cat = cls.get("category", "NOT_RELEVANT")
                    c["category"] = cat if (cat in taxonomy_codes or cat == "NOT_RELEVANT") else "NOT_RELEVANT"
                    c["reasoning"] = cls.get("reasoning", "")
                    c["key_phrase"] = cls.get("key_phrase", "")
                    results.append(c)
            # Fill missed passages
            for i, c in enumerate(batch):
                if i not in classified_idxs:
                    cp = c.copy()
                    cp["category"] = default_cat
                    cp["reasoning"] = "Keyword match (LLM dropped)"
                    cp["key_phrase"] = ""
                    results.append(cp)
            return results

        try:
            raw = self._ask_llm(prompt)
            return _parse_and_apply(raw)
        except Exception as exc:
            logger.warning("Classification batch failed (%d passages): %s -- retrying", len(batch), exc)

        # Retry at temperature=0
        try:
            raw = self._ask_llm(prompt, temperature=0.0)
            return _parse_and_apply(raw)
        except Exception as exc2:
            logger.error("Retry also failed: %s -- keyword fallback", exc2)
            return [
                {**c, "category": default_cat, "reasoning": "Keyword match (parse failed)", "key_phrase": c.get("text", "")[:100]}
                for c in batch
            ]

    def _ask_llm(self, prompt: str, temperature: float = 0.1) -> str:
        if not self._llm:
            raise RuntimeError("No LLM client configured")
        return self._llm.chat(
            model=LLM_REASONING,
            system="You are a healthcare contract clause classifier. Return only valid JSON.",
            user=prompt,
            max_tokens=self._max_tokens,
            temperature=temperature,
        )
