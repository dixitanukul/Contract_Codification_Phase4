"""
platform/v4/tools/clause_existence/taxonomy_builder.py

P4C-CE-2: Taxonomy resolution for clause existence analysis.

Known concepts (KNOWN_TAXONOMIES): return cached taxonomy + pre-built plan.
Novel concepts: LLM generates taxonomy + execution plan in parallel.

Migrated from V2 Cell 5 _generate_taxonomy() / _create_execution_plan().
"""
from __future__ import annotations

import json
import logging
from concurrent.futures import ThreadPoolExecutor
from typing import Any, Dict, List, Optional, Tuple

from platform.v4.services.concepts import KNOWN_TAXONOMIES, KNOWN_RECALL_SIGNALS, assign_polarity
from platform.v4.config.settings import LLM_REASONING

logger = logging.getLogger(__name__)

Taxonomy = List[Dict[str, Any]]
Plan = Dict[str, Any]


class TaxonomyBuilder:
    """
    Resolve taxonomy and execution plan for a target clause concept.

    Usage:
        builder = TaxonomyBuilder(llm_client=llm)
        taxonomy, plan = builder.resolve("offset clause", ["offset", "recoup"])

    Plan dict keys: core_keywords, extended_keywords, extended_strong,
    extended_weak, excluded_keywords, disambiguation_rules, expected_prevalence,
    precision_strategy, bypass_frequency_gate, known_concept_key.
    """

    def __init__(self, llm_client: Optional[Any] = None) -> None:
        self._llm = llm_client

    def resolve(
        self,
        target_concept: str,
        search_keywords: List[str],
    ) -> Tuple[Taxonomy, Plan]:
        """
        Resolve taxonomy + execution plan for a concept.

        Returns (taxonomy_list, plan_dict). For known concepts, LLM calls are
        skipped and bypass_frequency_gate=True. For novel concepts, LLM is
        called in parallel for taxonomy + execution plan.
        """
        target_lower = target_concept.lower().strip()
        known_key = next(
            (k for k in KNOWN_TAXONOMIES if k in target_lower or target_lower in k),
            None,
        )

        if known_key:
            taxonomy = KNOWN_TAXONOMIES[known_key]
            # P4C-CE-3 FIX: for known concepts, use KNOWN_RECALL_SIGNALS as the
            # keyword corpus rather than the caller-supplied search_keywords,
            # which is empty when routing=None (standalone / direct tool call).
            recall = KNOWN_RECALL_SIGNALS.get(known_key, {})
            _core_kws = recall.get("first_pass", []) or search_keywords[:4]
            _strong_kws = recall.get("strong", []) or search_keywords[4:]
            plan: Plan = {
                "core_keywords": _core_kws,
                "extended_keywords": _strong_kws,
                "extended_strong": _strong_kws,
                "extended_weak": [],
                "excluded_keywords": [],
                "disambiguation_rules": [],
                "expected_prevalence": "high",
                "precision_strategy": "balanced",
                "bypass_frequency_gate": True,
                "known_concept_key": known_key,
            }
            logger.debug(
                "Known concept %r: cached taxonomy (%d cats), core_kws=%d, strong_kws=%d",
                known_key, len(taxonomy), len(_core_kws), len(_strong_kws),
            )
            return taxonomy, plan

        # Novel concept: generate via LLM (parallel)
        if self._llm:
            with ThreadPoolExecutor(max_workers=2) as pool:
                tax_fut = pool.submit(self._generate_taxonomy_llm, target_concept)
                plan_fut = pool.submit(self._create_execution_plan_llm, target_concept, search_keywords)
                taxonomy = tax_fut.result()
                plan_dict = plan_fut.result()
        else:
            taxonomy = self._binary_fallback(target_concept)
            plan_dict = {}

        plan = {
            "core_keywords": plan_dict.get("core_keywords", search_keywords[:4]),
            "extended_keywords": plan_dict.get("extended_keywords", search_keywords[4:]),
            "extended_strong": plan_dict.get("extended_keywords", search_keywords[4:]),
            "extended_weak": [],
            "excluded_keywords": plan_dict.get("excluded_keywords", []),
            "disambiguation_rules": plan_dict.get("disambiguation_rules", []),
            "expected_prevalence": plan_dict.get("expected_prevalence", "medium"),
            "precision_strategy": plan_dict.get("precision_strategy", "balanced"),
            "bypass_frequency_gate": False,
            "known_concept_key": None,
        }
        return taxonomy, plan

    # ------------------------------------------------------------------
    # LLM helpers
    # ------------------------------------------------------------------

    def _generate_taxonomy_llm(self, target_concept: str) -> Taxonomy:
        """LLM-generated taxonomy for a novel concept."""
        prompt = (
            f'Generate a classification taxonomy for "{target_concept}" in '
            "healthcare provider contracts. "
            "Return ONLY valid JSON with 5-7 positive categories + 1 denial category. "
            'Format: {"categories": [{"code": "CODE", "label": "Label", '
            '"description": "When to assign", "is_denial": false}, ...]}'
        )
        try:
            result = self._ask_llm(prompt, max_tokens=800)
            result = result.strip()
            if result.startswith("```"):
                result = result.split("\n", 1)[-1].rsplit("```", 1)[0]
            cats: Taxonomy = json.loads(result).get("categories", [])
            for entry in cats:
                entry["polarity"] = assign_polarity(entry)
                entry["is_denial"] = entry["polarity"] == "RESTRICT"
            return cats if cats else self._binary_fallback(target_concept)
        except Exception as exc:
            logger.warning("Taxonomy LLM failed: %s", exc)
            return self._binary_fallback(target_concept)

    def _create_execution_plan_llm(
        self, target_concept: str, keywords: List[str]
    ) -> Dict[str, Any]:
        """LLM keyword triage: core / extended / excluded + disambiguation."""
        prompt = (
            "You are a healthcare contract search strategist. "
            f'I need to search contract text chunks for "{target_concept}". '
            f"Candidate keywords: {json.dumps(keywords)}. "
            "Classify each keyword: "
            f"CORE=directly refers to {target_concept}; "
            "EXTENDED=related but ambiguous; EXCLUDE=too broad (>80% false positives). "
            "Return ONLY valid JSON: "
            '{"core_keywords":["kw1"],"extended_keywords":["kw2"],'
            '"excluded_keywords":[{"keyword":"...","reason":"..."}],'
            '"disambiguation_rules":["IS ...","IS NOT ..."],'
            '"expected_prevalence":"high|medium|low","precision_strategy":"strict|balanced|broad"}'
        )
        try:
            result = self._ask_llm(prompt, max_tokens=800)
            result = result.strip()
            if result.startswith("```"):
                result = result.split("\n", 1)[-1].rsplit("```", 1)[0]
            plan_dict = json.loads(result)
            for key in ("core_keywords", "extended_keywords", "excluded_keywords", "disambiguation_rules"):
                if key not in plan_dict:
                    plan_dict[key] = []
            plan_dict.setdefault("expected_prevalence", "medium")
            plan_dict.setdefault("precision_strategy", "balanced")
            return plan_dict
        except Exception as exc:
            logger.warning("Execution plan LLM failed: %s", exc)
            return {
                "core_keywords": keywords[:4],
                "extended_keywords": keywords[4:],
                "excluded_keywords": [],
                "disambiguation_rules": [],
                "expected_prevalence": "medium",
                "precision_strategy": "balanced",
            }

    def _binary_fallback(self, target_concept: str) -> Taxonomy:
        """Minimal 2-category fallback when LLM is unavailable."""
        return [
            {
                "code": "CONFIRMED_PRESENT", "label": "Present",
                "description": f"{target_concept} is clearly present",
                "is_denial": False, "polarity": "GRANT",
            },
            {
                "code": "EXPLICITLY_DENIED", "label": "Denied",
                "description": f"{target_concept} is explicitly denied",
                "is_denial": True, "polarity": "RESTRICT",
            },
        ]

    def _ask_llm(self, prompt: str, max_tokens: int = 800) -> str:
        if not self._llm:
            return ""
        try:
            return self._llm.chat(
                model=LLM_REASONING,
                system="You are a healthcare contract classification expert.",
                user=prompt,
                max_tokens=max_tokens,
                temperature=0.1,
            )
        except Exception as exc:
            logger.warning("LLM call failed: %s", exc)
            return ""
