"""
platform/v4/tools/export_data.py

Data export tool — converts query results to CSV, JSON, or Delta table.

Used when the user asks to "save", "export", or "download" data.
Requires Spark for Delta table writes; CSV/JSON exports work from
in-memory data only.
"""
from __future__ import annotations

import io
import json
import time
from typing import Any, Optional

from ..contracts.tool_types import Confidence, ToolResult
from ..tools.base import BaseTool

CATALOG = "dev_adb"
SCHEMA  = "raw"


class ExportDataTool(BaseTool):
    """
    Export structured data to CSV string, JSON string, or Delta table.

    Parameters
    ----------
    spark : Active Spark session (required for Delta export only).
    """

    def __init__(self, spark: Optional[Any] = None) -> None:
        self._spark = spark

    def set_spark(self, spark: Any) -> None:
        self._spark = spark

    @property
    def name(self) -> str:
        return "export_data"

    def _run(
        self,
        rows:        Optional[list[dict]] = None,
        format:      str                  = "csv",
        table_name:  Optional[str]        = None,
        label:       str                  = "export",
        **kwargs:    Any,
    ) -> ToolResult:
        """
        Parameters
        ----------
        rows       : Data rows to export.
        format     : One of: csv | json | delta
        table_name : Required for delta format (table name only, no catalog/schema).
        label      : Display label used in the summary.
        """
        if not rows:
            return ToolResult(
                success=False,
                data=None,
                summary="No data to export",
                confidence=Confidence.LOW,
                error_message="rows is empty",
            )

        fmt = format.lower()

        if fmt == "csv":
            return self._to_csv(rows, label)
        elif fmt == "json":
            return self._to_json(rows, label)
        elif fmt == "delta":
            return self._to_delta(rows, table_name, label)
        else:
            return ToolResult(
                success=False,
                data=None,
                summary=f"Unknown export format: {format}",
                confidence=Confidence.LOW,
                error_message="Valid formats: csv, json, delta",
            )

    # ------------------------------------------------------------------
    # Format implementations
    # ------------------------------------------------------------------

    @staticmethod
    def _to_csv(rows: list[dict], label: str) -> ToolResult:
        if not rows:
            return ToolResult(success=False, data=None, summary="No rows", confidence=Confidence.LOW)
        buf = io.StringIO()
        cols = list(rows[0].keys())
        buf.write(",".join(f'"{c}"' for c in cols) + "\n")
        for r in rows:
            buf.write(",".join(f'"{r.get(c, "")}"' for c in cols) + "\n")
        csv_str = buf.getvalue()
        return ToolResult(
            success=True,
            data=csv_str,
            summary=f"Exported {len(rows)} rows as CSV ({label})",
            confidence=Confidence.HIGH,
            metadata={"format": "csv", "rows": len(rows), "columns": cols},
        )

    @staticmethod
    def _to_json(rows: list[dict], label: str) -> ToolResult:
        try:
            json_str = json.dumps(rows, indent=2, default=str)
        except Exception as exc:  # noqa: BLE001
            return ToolResult(
                success=False,
                data=None,
                summary=f"JSON serialisation error: {exc}",
                confidence=Confidence.LOW,
                error_message=str(exc),
            )
        return ToolResult(
            success=True,
            data=json_str,
            summary=f"Exported {len(rows)} rows as JSON ({label})",
            confidence=Confidence.HIGH,
            metadata={"format": "json", "rows": len(rows)},
        )

    def _to_delta(
        self,
        rows:       list[dict],
        table_name: Optional[str],
        label:      str,
    ) -> ToolResult:
        if self._spark is None:
            return ToolResult(
                success=False,
                data=None,
                summary="[STUB] Spark not injected — delta export unavailable",
                confidence=Confidence.GENERATED,
                error_message="ExportDataTool.spark is None",
            )
        if not table_name:
            return ToolResult(
                success=False,
                data=None,
                summary="table_name required for delta export",
                confidence=Confidence.LOW,
                error_message="table_name is None",
            )
        t0 = time.time()
        full_name = f"{CATALOG}.{SCHEMA}.{table_name}"
        try:
            df = self._spark.createDataFrame(rows)
            df.write.format("delta").mode("overwrite").saveAsTable(full_name)
            return ToolResult(
                success=True,
                data={"table": full_name, "rows": len(rows)},
                summary=f"Exported {len(rows)} rows to Delta table {full_name}",
                confidence=Confidence.HIGH,
                execution_time_s=time.time() - t0,
                metadata={"format": "delta", "table": full_name},
            )
        except Exception as exc:  # noqa: BLE001
            return ToolResult(
                success=False,
                data=None,
                summary=f"Delta export error: {exc}",
                confidence=Confidence.LOW,
                execution_time_s=time.time() - t0,
                error_message=str(exc),
            )
