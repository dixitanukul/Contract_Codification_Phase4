"""FinancialAnalysisTool: contracted spend, repricing scenarios, rate supersession, escalators."""
from __future__ import annotations
from typing import Any
from platform.v4.contracts.tool_types import ToolResult, Confidence, ToolStatus
from platform.v4.tools.base import BaseTool


class FinancialAnalysisTool(BaseTool):
    name = "financial_analysis"
    description = (
        "Access contracted financial data: spend exposure by provider, "
        "repricing what-if scenarios, rate supersession lineage, and escalation terms. "
        "query_type options: exposure_summary, exposure_by_lob, provider_exposure, "
        "repricing_scenarios, supersession_history, escalators."
    )

    def __init__(self, spark: Any = None, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self._spark = spark

    # ------------------------------------------------------------------
    # BaseTool._run implementation
    # ------------------------------------------------------------------

    def _run(
        self,
        query_type: str = "exposure_summary",
        provider: str = "",
        provider_id: str = "",
        scenario_label: str = "",
        limit: int = 50,
        **kwargs: Any,
    ) -> ToolResult:
        """
        Parameters
        ----------
        query_type        : One of exposure_summary | exposure_by_lob | provider_exposure |
                            repricing_scenarios | supersession_history | escalators
        provider          : Provider name (partial LIKE match against provider_name)
        provider_id       : Provider ID (exact match when set)
        scenario_label    : Filter repricing by label (e.g. SCENARIO_MINUS_5PCT)
        limit             : Max rows to return
        """
        if self._spark is None:
            return ToolResult(
                success=False,
                data=[],
                summary="[STUB] Spark not injected — financial_analysis unavailable",
                confidence=Confidence.GENERATED,
                error_message="FinancialAnalysisTool.spark is None",
            )

        import time
        t0 = time.time()
        try:
            rows, summary = self._dispatch(query_type, provider, provider_id, scenario_label, limit)
            return ToolResult(
                success=True,
                data=rows,
                summary=f"[financial_analysis:{query_type}] {summary}",
                confidence=Confidence.HIGH if rows else Confidence.LOW,
                execution_time_s=time.time() - t0,
                metadata={"query_type": query_type, "row_count": len(rows)},
            )
        except Exception as exc:  # noqa: BLE001
            return ToolResult(
                success=False,
                data=[],
                summary=f"financial_analysis error: {exc}",
                confidence=Confidence.LOW,
                execution_time_s=time.time() - t0,
                error_message=str(exc),
            )

    # ------------------------------------------------------------------
    # Private query dispatch
    # ------------------------------------------------------------------

    def _dispatch(
        self,
        query_type: str,
        provider: str,
        provider_id: str,
        scenario_label: str,
        limit: int,
    ):
        from platform.v4.config.settings import (
            TBL_FINANCIAL_EXPOSURE, TBL_GENIE_PROVIDER_PROFILE,
            TBL_REPRICING_SCENARIOS,
            TBL_FACT_SUPERSESSION, TBL_RATE_ESCALATORS,
            TBL_CONTRACT_DOCUMENTS_MASTER,
        )
        lim = min(limit, 200)

        if query_type == "exposure_summary":
            # JOIN provider profile to surface provider names alongside IDs
            sql = f"""
                SELECT pp.provider_name, fe.provider_id, fe.line_of_business,
                       CAST(fe.contracted_spend AS DOUBLE) AS contracted_spend,
                       CAST(fe.actual_spend AS DOUBLE) AS actual_spend,
                       fe.variance_pct,
                       fe.assigned_members, fe.estimate_confidence
                FROM {TBL_FINANCIAL_EXPOSURE} fe
                LEFT JOIN {TBL_GENIE_PROVIDER_PROFILE} pp ON fe.provider_id = pp.provider_id
                ORDER BY contracted_spend DESC NULLS LAST
                LIMIT {lim}
            """
            rows = [r.asDict() for r in self._spark.sql(sql).collect()]
            total = sum(float(r.get("contracted_spend") or 0) for r in rows)
            return rows, f"{len(rows)} providers, ${total/1e6:.1f}M total contracted spend"

        elif query_type == "exposure_by_lob":
            # Aggregate contracted and actual spend by line of business
            prov_safe = provider.replace("'", "''")
            pid_safe  = provider_id.replace("'", "''")
            if pid_safe:
                provider_filter = f"WHERE fe.provider_id = '{pid_safe}'"
            elif prov_safe:
                provider_filter = (
                    f"JOIN {TBL_GENIE_PROVIDER_PROFILE} pp2 ON fe.provider_id = pp2.provider_id "
                    f"WHERE LOWER(pp2.provider_name) LIKE LOWER('%{prov_safe}%')"
                )
            else:
                provider_filter = ""
            sql = f"""
                SELECT
                    COALESCE(fe.line_of_business, 'Unknown') AS line_of_business,
                    COUNT(DISTINCT fe.provider_id) AS provider_count,
                    ROUND(COALESCE(SUM(CAST(fe.contracted_spend AS DOUBLE)), 0) / 1e6, 2)
                        AS contracted_spend_millions,
                    ROUND(COALESCE(SUM(CAST(fe.actual_spend AS DOUBLE)), 0) / 1e6, 2)
                        AS actual_spend_millions,
                    ROUND(AVG(fe.variance_pct), 1) AS avg_variance_pct
                FROM {TBL_FINANCIAL_EXPOSURE} fe
                {provider_filter}
                GROUP BY fe.line_of_business
                ORDER BY contracted_spend_millions DESC NULLS LAST
                LIMIT {lim}
            """
            rows = [r.asDict() for r in self._spark.sql(sql).collect()]
            import math
            total = sum(
                float(r.get("contracted_spend_millions") or 0)
                for r in rows
                if not math.isnan(float(r.get("contracted_spend_millions") or 0))
            )
            return rows, f"{len(rows)} lines of business, ${total:.1f}M total contracted spend"

        elif query_type == "provider_exposure":
            # FIX: tbl_financial_exposure.provider_id is a numeric string FK —
            # must JOIN tbl_genie_provider_profile to filter by provider name.
            prov_safe = provider.replace("'", "''")
            pid_safe  = provider_id.replace("'", "''")
            if pid_safe:
                join_clause = ""
                join_where  = f"fe.provider_id = '{pid_safe}'"
            elif prov_safe:
                join_clause = f"JOIN {TBL_GENIE_PROVIDER_PROFILE} pp ON fe.provider_id = pp.provider_id"
                join_where  = f"LOWER(pp.provider_name) LIKE LOWER('%{prov_safe}%')"
            else:
                join_clause = f"LEFT JOIN {TBL_GENIE_PROVIDER_PROFILE} pp ON fe.provider_id = pp.provider_id"
                join_where  = "1=1"
            sql = f"""
                SELECT
                    COALESCE(pp.provider_name, fe.provider_id) AS provider_name,
                    fe.line_of_business,
                    CAST(fe.contracted_spend AS DOUBLE) AS contracted_spend,
                    CAST(fe.actual_spend AS DOUBLE)     AS actual_spend,
                    fe.variance_pct, fe.assigned_members,
                    fe.inpatient_admits, fe.outpatient_visits,
                    fe.estimate_confidence,
                    CAST(fe.period_start AS STRING) AS period_start,
                    CAST(fe.period_end   AS STRING) AS period_end
                FROM {TBL_FINANCIAL_EXPOSURE} fe
                {join_clause}
                WHERE {join_where}
                ORDER BY contracted_spend DESC NULLS LAST
                LIMIT {lim}
            """
            rows = [r.asDict() for r in self._spark.sql(sql).collect()]
            return rows, f"{len(rows)} exposure records"

        elif query_type == "repricing_scenarios":
            prov_safe  = provider.replace("'", "''")
            label_safe = scenario_label.replace("'", "''")
            where_parts = []
            if prov_safe:
                where_parts.append(f"LOWER(provider_name) LIKE LOWER('%{prov_safe}%')")
            if label_safe:
                where_parts.append(f"scenario_label = '{label_safe}'")
            where = "WHERE " + " AND ".join(where_parts) if where_parts else ""
            sql = f"""
                SELECT provider_name, scenario_label, rate_category,
                       avg_rate, simulated_rate, rate_delta, rate_delta_pct,
                       estimated_annual_impact, rate_row_count, simulated_at
                FROM {TBL_REPRICING_SCENARIOS}
                {where}
                ORDER BY ABS(estimated_annual_impact) DESC NULLS LAST
                LIMIT {lim}
            """
            rows = [r.asDict() for r in self._spark.sql(sql).collect()]
            for r in rows:
                r["simulated_at"] = str(r.get("simulated_at") or "")
            total_impact = sum(float(r.get("estimated_annual_impact") or 0) for r in rows)
            return rows, f"{len(rows)} scenarios, net impact ${total_impact/1e6:.2f}M"

        elif query_type == "supersession_history":
            # provider_id is ALL NULL — must join via filename
            prov_safe = provider.replace("'", "''")
            pid_safe  = provider_id.replace("'", "''")
            if pid_safe:
                join_where = f"d.provider_id = '{pid_safe}'"
            elif prov_safe:
                join_where = f"LOWER(d.provider_name) LIKE LOWER('%{prov_safe}%')"
            else:
                join_where = "1=1"
            sql = f"""
                SELECT DISTINCT
                       fs.superseding_filename, fs.superseded_filename,
                       fs.old_rate_numeric, fs.new_rate_numeric, fs.rate_change_pct,
                       fs.superseding_effective_date, fs.rate_domain,
                       fs.change_summary, fs.confidence
                FROM {TBL_FACT_SUPERSESSION} fs
                JOIN {TBL_CONTRACT_DOCUMENTS_MASTER} d
                  ON fs.superseding_filename = d.source_filename
                WHERE {join_where}
                ORDER BY fs.superseding_effective_date DESC NULLS LAST
                LIMIT {lim}
            """
            rows = [r.asDict() for r in self._spark.sql(sql).collect()]
            for r in rows:
                r["superseding_effective_date"] = str(r.get("superseding_effective_date") or "")
            return rows, f"{len(rows)} supersession events"

        elif query_type == "escalators":
            prov_safe = provider.replace("'", "''")
            where_prov = f"AND LOWER(provider_name) LIKE LOWER('%{prov_safe}%')" if prov_safe else ""

            # --- Tier 1: network-wide summary stats (all rows) ---
            stats_sql = f"""
                SELECT
                    COUNT(*)                                                        AS total_records,
                    COUNT(DISTINCT provider_name)                                   AS total_providers,
                    SUM(CASE WHEN escalator_type = 'FIXED_PCT' THEN 1 ELSE 0 END) AS fixed_pct_count,
                    SUM(CASE WHEN escalator_type = 'CPI'        THEN 1 ELSE 0 END) AS cpi_count,
                    SUM(CASE WHEN escalator_type = 'CUSTOM'     THEN 1 ELSE 0 END) AS custom_count,
                    SUM(CASE WHEN adjustment_pct IS NOT NULL      THEN 1 ELSE 0 END) AS with_rate_pct,
                    ROUND(AVG(adjustment_pct), 2)                                   AS avg_adj_pct,
                    MIN(adjustment_pct)                                             AS min_adj_pct,
                    MAX(adjustment_pct)                                             AS max_adj_pct
                FROM {TBL_RATE_ESCALATORS}
                WHERE 1=1 {where_prov}
            """
            _stats_rows = self._spark.sql(stats_sql).collect()
            stats = _stats_rows[0].asDict() if _stats_rows else {}
            # replace float NaN with None
            for _k, _v in list(stats.items()):
                if isinstance(_v, float) and _v != _v:
                    stats[_k] = None

            # --- Tier 2: detail rows — all escalator types ---
            # Provider-specific queries: no quality filter — even NOISE rows confirm escalator
            #   existence (e.g. Stanford CPI is NOISE/CONTRACT_BOILERPLATE but IS a real clause).
            # Network-wide queries: HIGH/MEDIUM only to suppress noise rows.
            _qual_clause = (
                ""
                if prov_safe
                else "extraction_quality IN ('HIGH', 'MEDIUM') AND"
            )
            detail_sql = f"""
                SELECT provider_name, escalator_type, base_index,
                       ROUND(adjustment_pct, 2) AS adjustment_pct,
                       frequency, content_class, data_notes
                FROM {TBL_RATE_ESCALATORS}
                WHERE {_qual_clause} 1=1
                  {where_prov}
                ORDER BY
                    CASE WHEN adjustment_pct IS NOT NULL THEN 0 ELSE 1 END,
                    adjustment_pct DESC,
                    escalator_type,
                    provider_name
                LIMIT {min(lim, 35)}
            """
            rows = [r.asDict() for r in self._spark.sql(detail_sql).collect()]
            for r in rows:
                for _k, _v in list(r.items()):
                    if isinstance(_v, float) and _v != _v:
                        r[_k] = None

            # --- Build rich summary string for LLM context ---
            _fixed  = int(stats.get("fixed_pct_count") or 0)
            _cpi    = int(stats.get("cpi_count")        or 0)
            _custom = int(stats.get("custom_count")      or 0)
            _total  = int(stats.get("total_records")     or 0)
            _wpct   = int(stats.get("with_rate_pct")     or 0)
            _avg    = stats.get("avg_adj_pct")
            _mn     = stats.get("min_adj_pct")
            _mx     = stats.get("max_adj_pct")
            _pct_range = (
                f" (range {_mn:.1f}%\u2013{_mx:.1f}%, avg {_avg:.1f}%)"
                if _avg is not None else ""
            )
            summary_msg = (
                f"{_total} escalation records across {stats.get('total_providers', 0)} providers. "
                f"Types: FIXED_PCT={_fixed}, CPI={_cpi}, CUSTOM={_custom}. "
                f"{_wpct} providers have extracted rate percentages{_pct_range}. "
                f"Note: floor_pct and cap_pct are not yet extracted from source contracts. "
                f"Showing {len(rows)} records (all escalator types{('' if prov_safe else ', HIGH/MEDIUM quality')})."
            )
            return rows, summary_msg

        else:
            raise ValueError(f"Unknown query_type: {query_type!r}")
