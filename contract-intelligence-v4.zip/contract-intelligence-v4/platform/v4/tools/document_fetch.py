"""
platform/v4/tools/document_fetch.py

Retrieves full document pages or sections from tbl_vs_unified_ready.

The fulltext table has 1,361,179 rows and includes a page_number column,
making page-level document fetch efficient via SQL.

This tool is used when the agent needs to read specific pages or sections
of a contract (e.g. after passage_search identifies relevant pages).
"""
from __future__ import annotations

import time
from typing import Any, Optional

from ..config.settings import Settings
from ..contracts.tool_types import Confidence, ToolResult
from ..tools.base import BaseTool

CATALOG = "dev_adb"
SCHEMA  = "raw"
TABLE   = f"{CATALOG}.{SCHEMA}.tbl_vs_unified_ready"


class DocumentFetchTool(BaseTool):
    """
    Fetch document pages/sections from the fulltext corpus.

    Parameters
    ----------
    spark    : Active Spark session.
    settings : Settings instance.
    """

    def __init__(
        self,
        spark:    Optional[Any]      = None,
        settings: Optional[Settings] = None,
    ) -> None:
        self._spark    = spark
        self._settings = settings or Settings()

    @property
    def name(self) -> str:
        return "document_fetch"

    def set_spark(self, spark: Any) -> None:
        self._spark = spark

    def _run(
        self,
        doc_id:        Optional[str] = None,
        provider_name: Optional[str] = None,
        page_number:   Optional[int] = None,
        page_range:    Optional[tuple] = None,   # (start_page, end_page)
        clause_type:   Optional[str] = None,
        limit:         int = 20,
        **kwargs:      Any,
    ) -> ToolResult:
        """
        Parameters
        ----------
        doc_id        : Specific document ID to fetch from.
        provider_name : Filter by provider name.
        page_number   : Specific page to fetch.
        page_range    : (start, end) page range (inclusive).
        clause_type   : Filter by clause type / section label.
        limit         : Max rows to return.
        """
        if self._spark is None:
            return ToolResult(
                success=False,
                data=[],
                summary="[STUB] Spark not injected — document_fetch unavailable",
                confidence=Confidence.GENERATED,
                error_message="DocumentFetchTool.spark is None",
            )

        if not doc_id and not provider_name:
            return ToolResult(
                success=False,
                data=[],
                summary="Either doc_id or provider_name must be provided",
                confidence=Confidence.LOW,
                error_message="doc_id and provider_name are both None",
            )

        t0         = time.time()
        conditions = self._build_conditions(doc_id, provider_name, page_number, page_range, clause_type)
        # W9-18 → Step 0.3: Aligned with tbl_vs_unified_ready (V4 unified corpus).
        # Key columns: chunk_id, source_filename, provider_name, chunk_text,
        #              page_number_est, chunk_index, content_length, is_current,
        #              doc_role, effective_date, section_header, quality_score
        sql        = f"""
            SELECT chunk_id AS doc_id, provider_name,
                   page_number_est AS page_number,
                   NULL AS clause_type,
                   chunk_text AS text, effective_date,
                   is_current AS is_current_effective,
                   NULL AS contract_id, NULL AS amendment_id,
                   source_filename
            FROM {TABLE}
            WHERE {conditions}
            ORDER BY page_number_est, chunk_index
            LIMIT {limit}
        """

        try:
            df   = self._spark.sql(sql)
            rows = [r.asDict() for r in df.collect()]
        except Exception as exc:  # noqa: BLE001
            return ToolResult(
                success=False,
                data=[],
                summary=f"Document fetch error: {exc}",
                confidence=Confidence.LOW,
                execution_time_s=time.time() - t0,
                error_message=str(exc),
            )

        citations = [
            {
                "doc_id":        r.get("doc_id", ""),
                "provider_name": r.get("provider_name", ""),
                "page_number":   r.get("page_number"),
                "section":       r.get("clause_type"),
            }
            for r in rows
        ]

        return ToolResult(
            success=True,
            data=rows,
            summary=f"Fetched {len(rows)} page(s)" + (f" from doc {doc_id}" if doc_id else ""),
            citations=citations,
            confidence=Confidence.HIGH if rows else Confidence.LOW,
            execution_time_s=time.time() - t0,
            metadata={"sql": sql, "row_count": len(rows)},
        )

    @staticmethod
    def _build_conditions(
        doc_id:        Optional[str],
        provider_name: Optional[str],
        page_number:   Optional[int],
        page_range:    Optional[tuple],
        clause_type:   Optional[str],
    ) -> str:
        parts: list[str] = []
        if doc_id:
            esc = str(doc_id).replace("'", "''")
            # doc_id maps to source_filename (string) or chunk_id (bigint)
            if esc.isdigit():
                parts.append(f"chunk_id = {esc}")
            else:
                parts.append(f"source_filename = '{esc}'")
        if provider_name:
            esc = provider_name.replace("'", "''")
            parts.append(f"LOWER(provider_name) = LOWER('{esc}')")
        if page_number is not None:
            parts.append(f"page_number_est = {int(page_number)}")
        elif page_range:
            start, end = page_range
            parts.append(f"page_number_est BETWEEN {int(start)} AND {int(end)}")
        if clause_type:
            # clause_type not in source table; search in chunk_text instead
            esc = clause_type.replace("'", "''")
            parts.append(f"LOWER(chunk_text) LIKE LOWER('%{esc}%')")
        return " AND ".join(parts) if parts else "1=1"
