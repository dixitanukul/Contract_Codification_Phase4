"""
Phase 10B-6: Provenance & Audit Tool
Query types:
  extraction_summary   — fleet-wide view: tables, methods, confidence bands, verification rate
  provider_provenance  — all extraction records for a specific provider (JOIN dim_provider_canonical)
  document_lineage     — supersession chain for a provider or filename (from fact_supersession)
  extraction_quality   — per-table confidence stats; useful for "how reliable is the X data?" questions

Key table facts (DO NOT CHANGE without re-validating):
  tbl_extraction_provenance:
    - 15,368 rows; provider_id is a numeric string (joins tbl_genie_provider_profile.provider_id)
    - extraction_method: only PATTERN_MATCH
    - human_verified: ALL false (no manual review done yet)
    - confidence_score: NULL for DOFR entries; ~0.694 avg where populated
    - target_tables: tbl_contract_clauses|tbl_contract_notifications|tbl_compliance_tracking|
                     tbl_delegation_matrix|tbl_dofr_matrix_extracted|tbl_quality_performance|
                     tbl_rate_escalators
    - model_version: DOFR_EXTRACTOR_V1 (for DOFR rows)
  fact_supersession:
    - 2,380 rows; supersession_type = full_document only
    - rate_change_pct, rate_domain, clause_type ALL NULL
    - derivation_method = temporal_chain only; confidence = 0.85
    - provider_id IS populated (numeric string); JOIN tbl_genie_provider_profile on provider_id
    - superseding_filename / superseded_filename are full PDF filenames
"""
from __future__ import annotations
from platform.v4.tools.base import BaseTool, ToolResult


class ProvenanceTool(BaseTool):
    name = "provenance"
    # Hardcode table names (same pattern as ClauseTextTool, ComplianceQueryTool)
    _TBL_PROVENANCE   = "dev_adb.raw.tbl_extraction_provenance"
    _TBL_SUPERSESSION = "dev_adb.raw.fact_supersession"
    _TBL_PROVIDER     = "dev_adb.raw.tbl_genie_provider_profile"

    def __init__(self, spark):
        self.spark = spark

    description = (
        "Answer provenance, audit, and extraction lineage questions. "
        "Handles: where did this data come from, how was it extracted, how reliable are the extractions, "
        "document supersession history, contract replacement chains, extraction audit trail, "
        "and verification status of extracted values."
    )

    def _run(self, **kwargs) -> ToolResult:
        query_type: str = kwargs.get("query_type", "extraction_summary")
        provider: str = kwargs.get("provider", "") or kwargs.get("provider_name", "")
        target_table: str = kwargs.get("target_table", "")
        filename: str = kwargs.get("filename", "")
        limit: int = int(kwargs.get("limit", 50))

        # If provider is specified, prefer provider-specific queries
        if provider and query_type == "extraction_summary":
            query_type = "provider_provenance"

        try:
            if query_type == "extraction_summary":
                return self._extraction_summary()
            elif query_type == "provider_provenance":
                return self._provider_provenance(provider, target_table, limit)
            elif query_type == "document_lineage":
                return self._document_lineage(provider, filename, limit)
            elif query_type == "extraction_quality":
                return self._extraction_quality(target_table)
            else:
                return ToolResult(
                    success=False,
                    data=[],
                    summary=f"Unknown query_type '{query_type}'. "
                            "Use: extraction_summary | provider_provenance | document_lineage | extraction_quality",
                )
        except Exception as exc:
            return ToolResult(success=False, data=[], summary=f"ProvenanceTool error: {exc}")

    # ── Query implementations ──────────────────────────────────────────────

    def _extraction_summary(self) -> ToolResult:
        """Fleet-wide extraction overview."""
        df = self.spark.sql(f"""
            SELECT
                target_table,
                COUNT(*)                                                    AS extraction_count,
                COUNT(DISTINCT provider_id)                                 AS provider_count,
                extraction_method,
                ROUND(AVG(confidence_score), 3)                             AS avg_confidence,
                SUM(CASE WHEN confidence_score IS NULL     THEN 1 ELSE 0 END) AS null_confidence,
                SUM(CASE WHEN confidence_score >= 0.9      THEN 1 ELSE 0 END) AS high_conf,
                SUM(CASE WHEN confidence_score >= 0.7
                          AND confidence_score < 0.9       THEN 1 ELSE 0 END) AS medium_conf,
                SUM(CASE WHEN confidence_score < 0.7
                          AND confidence_score IS NOT NULL  THEN 1 ELSE 0 END) AS low_conf,
                SUM(CASE WHEN human_verified THEN 1 ELSE 0 END)             AS human_verified_count
            FROM {self._TBL_PROVENANCE}
            GROUP BY target_table, extraction_method
            ORDER BY extraction_count DESC
        """)
        rows = [r.asDict() for r in df.collect()]
        total = sum(r["extraction_count"] for r in rows)
        return ToolResult(
            success=True,
            data=rows,
            summary=(
                f"Extraction summary across {len(rows)} table/method combinations. "
                f"Total extractions: {total:,}. "
                f"All extractions use PATTERN_MATCH. "
                f"Human verification rate: 0% (no records manually reviewed)."
            ),
        )

    def _provider_provenance(
        self, provider: str, target_table: str, limit: int
    ) -> ToolResult:
        """All extraction records for a provider, optionally filtered by table."""
        if not provider:
            return ToolResult(
                success=False,
                data=[],
                summary="provider parameter is required for provider_provenance.",
            )
        table_filter = (
            f"AND ep.target_table = '{target_table}'" if target_table else ""
        )

        def _query_prov(match_expr: str) -> list:
            df = self.spark.sql(f"""
                SELECT
                    p.provider_name,
                    ep.target_table,
                    ep.target_column,
                    ep.extracted_value,
                    ep.confidence_score,
                    ep.extraction_method,
                    ep.model_version,
                    ep.source_page_numbers,
                    ep.human_verified,
                    ep.human_corrected_value,
                    ep.extraction_timestamp
                FROM {self._TBL_PROVENANCE} ep
                JOIN {self._TBL_PROVIDER} p
                    ON p.provider_id = ep.provider_id
                WHERE {match_expr}
                {table_filter}
                ORDER BY ep.target_table, ep.target_column, ep.extraction_timestamp DESC
                LIMIT {limit}
            """)
            return [r.asDict() for r in df.collect()]

        # Try exact substring match first
        prov_esc = provider.replace("'", "\'")
        rows = _query_prov(f"LOWER(p.provider_name) LIKE LOWER('%{prov_esc}%')")

        # Fallback: use first significant word (e.g. 'Sharp' from 'Sharp HealthCare')
        if not rows:
            first_token = provider.strip().split()[0] if provider.strip() else ''
            if len(first_token) >= 4:
                tok_esc = first_token.replace("'", "\'")
                rows = _query_prov(f"LOWER(p.provider_name) LIKE LOWER('%{tok_esc}%')")

        if not rows:
            return ToolResult(
                success=True,
                data=[],
                summary=f"No extraction provenance found for provider matching '{provider}'.",
            )
        provider_name = rows[0]["provider_name"]
        tables_seen = list({r["target_table"] for r in rows})
        verified = sum(1 for r in rows if r.get("human_verified"))
        return ToolResult(
            success=True,
            data=rows,
            summary=(
                f"Found {len(rows)} extraction records for {provider_name} "
                f"across {len(tables_seen)} table(s): {', '.join(tables_seen)}. "
                f"Human-verified: {verified}/{len(rows)} (note: 0% verification is normal — "
                f"all extractions are PATTERN_MATCH; no manual review has been performed)."
            ),
        )

    def _document_lineage(
        self, provider: str, filename: str, limit: int
    ) -> ToolResult:
        """Supersession chain — ordered sequence of documents that replace each other."""
        if not provider and not filename:
            return ToolResult(
                success=False,
                data=[],
                summary="Provide either provider or filename for document_lineage.",
            )

        if filename:
            filename_esc = filename.replace("'", "\'")
            filter_clause = (
                f"WHERE fs.superseding_filename LIKE '%{filename_esc}%' "
                f"   OR fs.superseded_filename  LIKE '%{filename_esc}%'"
            )
        else:
            # Try exact substring match; fall back to first significant token
            provider_esc = provider.replace("'", "\'")
            first_token = provider.strip().split()[0] if provider.strip() else ''
            token_esc = first_token.replace("'", "\'") if len(first_token) >= 4 else provider_esc
            filter_clause = (
                f"JOIN {self._TBL_PROVIDER} p "
                f"  ON p.provider_id = fs.provider_id "
                f"WHERE (LOWER(p.provider_name) LIKE LOWER('%{provider_esc}%') "
                f"    OR LOWER(p.provider_name) LIKE LOWER('%{token_esc}%'))"
            )

        df = self.spark.sql(f"""
            SELECT
                fs.supersession_id,
                {"p.provider_name," if not filename else "fs.provider_id AS provider_id,"}
                fs.contract_chain_id,
                fs.supersession_type,
                fs.supersession_scope,
                fs.superseding_filename,
                fs.superseded_filename,
                fs.superseding_effective_date,
                fs.superseded_effective_date,
                fs.superseded_valid_to,
                fs.derivation_method,
                fs.confidence,
                fs.change_summary
            FROM {self._TBL_SUPERSESSION} fs
            {filter_clause}
            ORDER BY fs.superseding_effective_date DESC
            LIMIT {limit}
        """)
        rows = [r.asDict() for r in df.collect()]
        if not rows:
            return ToolResult(
                success=True,
                data=[],
                summary=f"No supersession records found for {'provider ' + provider if provider else 'filename ' + filename}.",
            )
        chains = len({r["contract_chain_id"] for r in rows})
        date_range = (
            f"{min(str(r['superseded_effective_date']) for r in rows)} "
            f"→ {max(str(r['superseding_effective_date']) for r in rows)}"
        )
        return ToolResult(
            success=True,
            data=rows,
            summary=(
                f"Found {len(rows)} supersession records across {chains} contract chain(s). "
                f"Date range: {date_range}. "
                f"All derivations are temporal_chain (date-sequence inference). "
                f"Note: rate_change_pct and clause_type are NULL for all records (full_document supersessions only)."
            ),
        )

    def _extraction_quality(self, target_table: str) -> ToolResult:
        """Per-table (or overall) confidence and quality stats."""
        table_filter = (
            f"WHERE target_table = '{target_table.replace(chr(39), chr(92) + chr(39))}'"
            if target_table
            else ""
        )
        df = self.spark.sql(f"""
            SELECT
                target_table,
                target_column,
                COUNT(*)                                                     AS row_count,
                ROUND(AVG(confidence_score), 3)                              AS avg_confidence,
                ROUND(MIN(confidence_score), 3)                              AS min_confidence,
                ROUND(MAX(confidence_score), 3)                              AS max_confidence,
                SUM(CASE WHEN confidence_score IS NULL     THEN 1 ELSE 0 END) AS null_conf_count,
                SUM(CASE WHEN human_verified               THEN 1 ELSE 0 END) AS verified_count,
                SUM(CASE WHEN human_corrected_value IS NOT NULL THEN 1 ELSE 0 END) AS corrected_count
            FROM {self._TBL_PROVENANCE}
            {table_filter}
            GROUP BY target_table, target_column
            ORDER BY target_table, row_count DESC
        """)
        rows = [r.asDict() for r in df.collect()]
        if not rows:
            return ToolResult(
                success=True,
                data=[],
                summary=f"No extraction records found{' for table ' + target_table if target_table else ''}.",
            )
        total = sum(r["row_count"] for r in rows)
        null_total = sum(r["null_conf_count"] for r in rows)
        return ToolResult(
            success=True,
            data=rows,
            summary=(
                f"Extraction quality across {len(rows)} table/column combinations "
                f"({total:,} total records). "
                f"Confidence NULL: {null_total:,} rows ({null_total*100//total if total else 0}%) — "
                f"these are DOFR extractions which don't emit a confidence score. "
                f"Human verification: 0 records verified (no manual review completed)."
            ),
        )
