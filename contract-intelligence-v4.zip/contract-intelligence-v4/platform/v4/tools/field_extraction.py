"""
platform/v4/tools/field_extraction.py

P4A-RATE-2: Native structured field extraction tool.

Replaces V2 Branch H (branch_structured_extraction). Extracts specific
contract values (days, amounts, dates, text, boolean) per provider using
version-aware retrieval + LLM field extraction.

Supports 28+ registered field types from the requirements matrix.

Dependencies (all V3-owned):
    - RetrievalService (passage retrieval)
    - ProviderService (canonical resolution)
    - DatabricksLLMClient (field extraction)
    - FIELD_REGISTRY (field definitions)

Usage
-----
    from platform.v4.tools.field_extraction import FieldExtractionTool

    tool = FieldExtractionTool(
        spark=spark, provider_service=svc,
        retrieval_service=ret, llm_client=client
    )
    result = tool(
        question="What is Kaiser's termination notice period?",
        provider_name="Kaiser",
        field_name="termination for convenience notice",
    )
"""
from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from ..contracts.tool_types import Confidence, ToolResult, ToolStatus
from ..services.provider_service import ProviderService
from ..config.settings import (
    CATALOG,
    SCHEMA,
    LLM_REASONING,
    LLM_FAST,
    TBL_VS_UNIFIED_READY,
)
from ..services.sql_helpers import build_provider_id_filter, qualified_table
from ..config.settings import TBL_CONTRACT_DOCUMENTS_MASTER, TBL_CONTRACT_RATES_ALL
from ..tools.base import BaseTool

logger = logging.getLogger(__name__)


# -- Structured metadata columns (direct SQL lookup, no LLM needed) ----------
# Maps field_name → (table_setting, column_name, aggregation_method)
# These fields exist as columns in metadata tables and can be queried directly.
_STRUCTURED_FIELD_COLUMNS: Dict[str, Tuple[str, str, str]] = {
    "payment_type": (
        "TBL_CONTRACT_DOCUMENTS_MASTER", "payment_type", "mode"
    ),
    "contract_term_years": (
        "TBL_CONTRACT_DOCUMENTS_MASTER", "contract_term_years", "latest"
    ),
    "auto_renewal": (
        "TBL_CONTRACT_DOCUMENTS_MASTER", "auto_renewal", "mode"
    ),
    "line_of_business": (
        "TBL_CONTRACT_RATES_ALL", "program_normalized", "mode"
    ),
}


# -- Field Registry -----------------------------------------------------------
# From V2 Cell 7 requirements matrix. Defines all extractable contract fields.

@dataclass
class FieldDefinition:
    """Definition of an extractable contract field."""
    name: str
    value_type: str  # numeric, duration, currency, date, text, boolean
    unit: Optional[str]  # days, years, months, USD, count, None
    keywords: List[str]
    description: str


FIELD_REGISTRY: Dict[str, FieldDefinition] = {}

_RAW_FIELDS = {
    "termination for convenience notice": {
        "value_type": "duration", "unit": "days",
        "keywords": ["termination", "convenience", "notice", "prior written notice",
                     "days notice", "calendar days", "without cause"],
        "description": "Number of days notice required for termination without cause",
    },
    "termination for cause notice": {
        "value_type": "duration", "unit": "days",
        "keywords": ["termination", "cause", "notice", "cure period", "breach"],
        "description": "Number of days notice required for termination with cause",
    },
    "confidentiality period": {
        "value_type": "duration", "unit": "years",
        "keywords": ["confidentiality", "confidential", "survive", "survival",
                     "post-termination", "years after"],
        "description": "Duration confidentiality obligations survive after termination",
    },
    "audit notice": {
        "value_type": "duration", "unit": "days",
        "keywords": ["audit", "notice", "advance notice", "prior notice",
                     "business days", "written notice"],
        "description": "Number of days advance notice required before conducting an audit",
    },
    "audit retention period": {
        "value_type": "duration", "unit": "years",
        "keywords": ["audit", "retention", "records", "maintain", "years", "period"],
        "description": "How long records must be retained for audit purposes",
    },
    "termination cure period": {
        "value_type": "duration", "unit": "days",
        "keywords": ["cure", "cure period", "remedy", "correct", "days to cure"],
        "description": "Number of days allowed to cure a breach before termination",
    },
    "limitation of liability amount": {
        "value_type": "currency", "unit": "USD",
        "keywords": ["limitation of liability", "liability", "aggregate",
                     "shall not exceed", "maximum", "cap"],
        "description": "Maximum dollar amount of liability",
    },
    "insurance required": {
        "value_type": "currency", "unit": "USD",
        "keywords": ["insurance", "coverage", "minimum", "per occurrence",
                     "aggregate", "professional liability", "malpractice"],
        "description": "Minimum insurance coverage amounts required",
    },
    "effective date": {
        "value_type": "date", "unit": None,
        "keywords": ["effective date", "effective", "commence", "beginning"],
        "description": "Contract effective/start date",
    },
    "expiration date": {
        "value_type": "date", "unit": None,
        "keywords": ["expiration", "expire", "termination date", "end date", "term ends"],
        "description": "Contract expiration/end date",
    },
    "contract length": {
        "value_type": "duration", "unit": "months",
        "keywords": ["initial term", "term of", "contract term", "period of",
                     "years", "months"],
        "description": "Duration of the contract term",
    },
    "extension renewal length": {
        "value_type": "duration", "unit": "months",
        "keywords": ["renewal", "extension", "auto-renew", "successive",
                     "additional term", "extended"],
        "description": "Duration of each renewal/extension period",
    },
    "number of extensions renewals": {
        "value_type": "numeric", "unit": "count",
        "keywords": ["renewal", "extensions", "successive", "number of",
                     "times", "unlimited"],
        "description": "Maximum number of renewal periods allowed",
    },
    "penalty for early termination": {
        "value_type": "text", "unit": None,
        "keywords": ["early termination", "penalty", "liquidated damages",
                     "termination fee"],
        "description": "Financial penalty for terminating before term ends",
    },
    "dispute resolution": {
        "value_type": "text", "unit": None,
        "keywords": ["dispute", "arbitration", "mediation", "resolution",
                     "governing law"],
        "description": "Mechanism for resolving contract disputes",
    },
    "assignment clause": {
        "value_type": "text", "unit": None,
        "keywords": ["assignment", "assign", "transfer", "consent", "without consent"],
        "description": "Conditions under which contract can be assigned to another party",
    },
    "change of control": {
        "value_type": "text", "unit": None,
        "keywords": ["change of control", "merger", "acquisition", "ownership",
                     "controlling interest"],
        "description": "What happens on change of ownership/control",
    },
    "force majeure": {
        "value_type": "text", "unit": None,
        "keywords": ["force majeure", "act of god", "pandemic", "unforeseeable",
                     "beyond control"],
        "description": "Force majeure / excusable delay provisions",
    },
    "indemnification": {
        "value_type": "text", "unit": None,
        "keywords": ["indemnif", "hold harmless", "defend", "indemnity"],
        "description": "Indemnification obligations and scope",
    },
    "right to audit": {
        "value_type": "text", "unit": None,
        "keywords": ["right to audit", "audit rights", "inspect", "examination",
                     "review records"],
        "description": "Plan's right to audit provider records",
    },
    "recoupment rights": {
        "value_type": "text", "unit": None,
        "keywords": ["recoup", "recoupment", "recovery", "overpayment",
                     "claw back", "offset"],
        "description": "Plan's right to recoup overpayments",
    },
    "delegation of financial responsibility": {
        "value_type": "text", "unit": None,
        "keywords": ["delegation", "DOFR", "delegated", "financial responsibility",
                     "capitation", "risk", "full risk", "shared risk"],
        "description": "Whether provider has delegated financial responsibility (DOFR)",
    },
    "drg methodology": {
        "value_type": "text", "unit": None,
        "keywords": ["DRG", "diagnosis related group", "MS-DRG", "APR-DRG",
                     "grouper", "case rate", "CMS"],
        "description": "Which DRG grouper/methodology is used for inpatient reimbursement",
    },
    "offset clause amount": {
        "value_type": "text", "unit": None,
        "keywords": ["offset", "withhold", "deduction", "recoup", "net against",
                     "reduce payment", "offset amount"],
        "description": "Offset clause mechanics and limitations",
    },
    "ab 352 compliance": {
        "value_type": "boolean", "unit": None,
        "keywords": ["AB 352", "AB352", "timely payment", "prompt payment",
                     "45 days", "clean claim", "interest penalty"],
        "description": "Whether contract references AB 352 (CA timely payment law)",
    },
    "encounter data requirements": {
        "value_type": "text", "unit": None,
        "keywords": ["encounter", "encounter data", "reconciliation", "submission",
                     "HEDIS", "encounter reporting"],
        "description": "Requirements for encounter data submission and reporting",
    },
    "offset_start_date": {
        "value_type": "date", "unit": None,
        "keywords": ["offset effective date", "recoupment commences",
                     "right of offset begins", "offset rights effective"],
        "description": "Date when offset/recoupment rights first become effective",
    },
    "offset_end_date": {
        "value_type": "date", "unit": None,
        "keywords": ["offset expires", "recoupment period ends", "offset ceases",
                     "offset termination date"],
        "description": "Date when offset/recoupment rights expire",
    },
    "payment_type": {
        "value_type": "text", "unit": None,
        "keywords": ["payment methodology", "reimbursement type", "payment structure",
                     "fee for service", "capitation", "per diem", "case rate",
                     "DRG", "percent of charges"],
        "description": "What is the primary payment methodology (FFS, capitation, case rate, per diem, etc.)",
    },
    "stop_loss_threshold": {
        "value_type": "currency", "unit": "USD",
        "keywords": ["stop loss", "stop-loss", "attachment point", "stop loss level",
                     "outlier threshold", "stop-loss attachment", "catastrophic"],
        "description": "What is the stop-loss attachment threshold amount",
    },
    "contract_term_years": {
        "value_type": "duration", "unit": "years",
        "keywords": ["contract term", "agreement term", "term of agreement",
                     "initial term", "term of this agreement", "term years"],
        "description": "What is the contract term in years",
    },
    "auto_renewal": {
        "value_type": "boolean", "unit": None,
        "keywords": ["auto-renewal", "automatic renewal", "evergreen",
                     "automatically renew", "successive periods", "unless terminated"],
        "description": "Does this contract have auto-renewal/evergreen provisions",
    },
    "line_of_business": {
        "value_type": "text", "unit": None,
        "keywords": ["line of business", "LOB", "product line", "commercial",
                     "medi-cal", "medicare", "HMO", "PPO", "EPO"],
        "description": "What line(s) of business are covered by this contract",
    },
}

# Build registry
for name, spec in _RAW_FIELDS.items():
    FIELD_REGISTRY[name] = FieldDefinition(
        name=name,
        value_type=spec["value_type"],
        unit=spec.get("unit"),
        keywords=spec["keywords"],
        description=spec["description"],
    )


def find_matching_field(question: str) -> Optional[FieldDefinition]:
    """Find the best matching field definition for a natural language question."""
    q_lower = question.lower()
    # Direct name match first
    for name, defn in FIELD_REGISTRY.items():
        if name in q_lower:
            return defn
    # Keyword match (score by overlap)
    best_score = 0
    best_field = None
    for name, defn in FIELD_REGISTRY.items():
        score = sum(1 for kw in defn.keywords if kw.lower() in q_lower)
        if score > best_score:
            best_score = score
            best_field = defn
    return best_field if best_score >= 2 else None


# -- Extraction result --------------------------------------------------------

@dataclass
class ExtractionResult:
    """Result of extracting a field value from contract text."""
    field_name: str
    value: Any  # The extracted value (number, string, date, bool, None)
    raw_text: str  # The source passage text
    confidence: str  # HIGH, MODERATE, LOW
    source_filename: Optional[str] = None
    page_number: Optional[int] = None
    notes: str = ""


# -- Tool implementation ------------------------------------------------------

class FieldExtractionTool(BaseTool):
    """
    Native structured field extraction tool (replaces V2 Branch H).

    Extracts specific contract values per provider by:
    1. Resolving provider to canonical IDs
    2. Retrieving top-K passages filtered by field keywords
    3. Preferring latest document version (version-aware ranking)
    4. Using LLM to extract the specific value from retrieved passages

    Parameters
    ----------
    spark : SparkSession
    provider_service : ProviderService
    retrieval_service : optional retrieval service
    llm_client : DatabricksLLMClient for extraction
    """

    name = "field_extraction"
    description = (
        "Extract specific contract field values (notice periods, amounts, dates, "
        "terms) from contract text for a given provider. Supports 28+ registered "
        "field types including termination notice, insurance requirements, renewal "
        "terms, and financial thresholds."
    )
    is_adapter_backed = False

    def __init__(
        self,
        spark: Any,
        provider_service: ProviderService,
        retrieval_service: Any = None,
        llm_client: Any = None,
    ) -> None:
        self._spark = spark
        self._provider_service = provider_service
        self._retrieval_service = retrieval_service
        self._llm_client = llm_client

    # -- Public interface -----------------------------------------------------

    def validate_inputs(self, **kwargs: Any) -> list[str]:
        errors = self._require(kwargs, "question")
        return errors

    def _run(
        self,
        question: str = "",
        provider_name: Optional[str] = None,
        field_name: Optional[str] = None,
        top_k: int = 7,
        **kwargs: Any,
    ) -> ToolResult:
        """
        Extract a structured field value from contract text.

        Parameters
        ----------
        question      : Natural language extraction question.
        provider_name : Provider to extract for (required for meaningful results).
        field_name    : Explicit field name from FIELD_REGISTRY (auto-detected if omitted).
        top_k         : Number of passages to retrieve per provider.
        """
        # Step 1: Identify the field to extract
        field_def = self._resolve_field(question, field_name)
        if field_def is None:
            # DOFR SERVICE-CATEGORY FALLBACK:
            # "Who handles pharmacy?" / "Who handles behavioral health?" don't map to a
            # contract field but ARE asking about DOFR service-category responsibility.
            # When a service-category keyword + who-handles pattern is detected, return
            # the network-wide DOFR distribution instead of the unrecognized-field error.
            _FE_SVC_MAP = {
                'behavioral health': 'BEHAVIORAL HEALTH',
                'behavioral': 'BEHAVIORAL HEALTH',
                'pharmacy': 'PHARMACY',
                'emergency': 'EMERGENCY',
                'radiology': 'RADIOLOGY',
                'lab services': 'LAB SERVICES',
                'lab': 'LAB SERVICES',
                'general': 'GENERAL',
            }
            _fe_dofr_cat = None
            for _fe_kw, _fe_cat in _FE_SVC_MAP.items():
                if re.search(rf'\b{re.escape(_fe_kw)}\b', question, re.I):
                    _fe_dofr_cat = _fe_cat
                    break
            if (_fe_dofr_cat and self._spark is not None
                    and re.search(
                        r'\b(who\s+handles?|who\s+is\s+responsible|responsible\s+for|who\s+covers?)\b',
                        question, re.I,
                    )):
                try:
                    _fe_agg_sql = (
                        f"SELECT "
                        f"ROUND(100.0*SUM(CASE WHEN group_responsible THEN 1 ELSE 0 END)/COUNT(*),1) AS group_pct, "
                        f"ROUND(100.0*SUM(CASE WHEN hospital_responsible THEN 1 ELSE 0 END)/COUNT(*),1) AS hospital_pct, "
                        f"ROUND(100.0*SUM(CASE WHEN health_plan_responsible THEN 1 ELSE 0 END)/COUNT(*),1) AS hp_pct, "
                        f"COUNT(DISTINCT provider_name) AS provider_count "
                        f"FROM dev_adb.raw.tbl_dofr_matrix_extracted "
                        f"WHERE service_category = '{_fe_dofr_cat}'"
                    )
                    _fe_agg = [r.asDict() for r in self._spark.sql(_fe_agg_sql).collect()]
                    if _fe_agg and _fe_agg[0].get('provider_count', 0):
                        _fe_a = _fe_agg[0]
                        _fe_rows_sql = (
                            f"SELECT DISTINCT provider_name, group_responsible, "
                            f"hospital_responsible, health_plan_responsible "
                            f"FROM dev_adb.raw.tbl_dofr_matrix_extracted "
                            f"WHERE service_category = '{_fe_dofr_cat}' "
                            f"ORDER BY provider_name LIMIT 10"
                        )
                        _fe_rows = [r.asDict() for r in self._spark.sql(_fe_rows_sql).collect()]
                        # Prepend aggregate-stats row (same pattern as sql_query.py payer fallback)
                        # so the agent reads exact percentages from data row 0 and does NOT
                        # recompute from sample rows or use the 141 total-DOFR denominator.
                        _fe_agg_display_row = {
                            "provider_name": (
                                f"=== NETWORK TOTAL ({_fe_a.get('provider_count',0)}"
                                f" contracted providers) ==="
                            ),
                            "group_responsible": f"GROUP={_fe_a.get('group_pct',0)}%",
                            "hospital_responsible": f"HOSPITAL={_fe_a.get('hospital_pct',0)}%",
                            "health_plan_responsible": f"HEALTH_PLAN={_fe_a.get('hp_pct',0)}%",
                        }
                        _fe_data_with_agg = [_fe_agg_display_row] + _fe_rows
                        return ToolResult(
                            success=True,
                            data=_fe_data_with_agg,
                            summary=(
                                f"{_fe_dofr_cat} DOFR network-wide — "
                                f"{_fe_a.get('provider_count',0)} contracted providers: "
                                f"Hospital {_fe_a.get('hospital_pct',0)}%, "
                                f"Group {_fe_a.get('group_pct',0)}%, "
                                f"Health Plan {_fe_a.get('hp_pct',0)}%. "
                                f"(Provider not in BSC contracted network — payer context.) "
                                f"Row 0 = NETWORK TOTAL with exact percentages. "
                                f"Rows 1+ = sample contracted provider assignments."
                            ),
                            confidence=Confidence.HIGH,
                            metadata={"category": _fe_dofr_cat, "dofr_svc_fallback": True,
                                      "hospital_pct": float(_fe_a.get('hospital_pct', 0)),
                                      "group_pct": float(_fe_a.get('group_pct', 0))},
                        )
                except Exception:
                    pass  # DOFR network fallback failed — fall through to unrecognized-field
            return ToolResult(
                success=True,
                data={"query_type": "field_extraction", "field_name": None,
                      "message": "Could not identify a registered field to extract."},
                summary="Could not identify a registered field. Available fields: "
                        + ", ".join(sorted(FIELD_REGISTRY.keys())[:10]) + "...",
                confidence=Confidence.LOW,
                status=ToolStatus.EMPTY,
            )

        # Step 2: Resolve provider
        providers, provider_ids = self._resolve_provider(question, provider_name)

        # Step 2.5: Try structured metadata shortcut (fast, no LLM, avoids hallucination)
        structured_result = self._try_structured_lookup(field_def, providers, provider_ids)
        if structured_result is not None:
            return structured_result

        # Step 3: Retrieve relevant passages (fallback when no structured column exists)
        passages = self._retrieve_passages(field_def, providers, provider_ids, top_k)

        if not passages:
            target = providers[0] if providers else "any provider"
            return ToolResult.empty(
                f"No relevant passages found for '{field_def.name}' ({target})."
            )

        # Step 4: Extract value using LLM
        extraction = self._extract_value(field_def, passages, providers)

        return ToolResult(
            success=True,
            data={
                "query_type": "field_extraction",
                "field_name": field_def.name,
                "value_type": field_def.value_type,
                "unit": field_def.unit,
                "provider": providers[0] if providers else None,
                "extraction": {
                    "value": extraction.value,
                    "raw_text": extraction.raw_text[:500],
                    "confidence": extraction.confidence,
                    "source_filename": extraction.source_filename,
                    "notes": extraction.notes,
                },
                "passages_retrieved": len(passages),
            },
            summary=(
                f"{field_def.name} for {providers[0] if providers else 'unknown'}: "
                f"{extraction.value}"
                + (f" {field_def.unit}" if field_def.unit and extraction.value else "")
            ),
            confidence=Confidence.HIGH if extraction.confidence == "HIGH" else Confidence.MODERATE,
            status=ToolStatus.SUCCESS,
            citations=[{
                "source_filename": extraction.source_filename,
                "text": extraction.raw_text[:200],
            }] if extraction.source_filename else [],
        )

    # -- Field resolution -----------------------------------------------------

    def _resolve_field(
        self, question: str, explicit_name: Optional[str]
    ) -> Optional[FieldDefinition]:
        """Resolve to a field definition."""
        if explicit_name and explicit_name in FIELD_REGISTRY:
            return FIELD_REGISTRY[explicit_name]
        return find_matching_field(question)

    # -- Provider resolution --------------------------------------------------

    def _resolve_provider(
        self, question: str, explicit_name: Optional[str]
    ) -> Tuple[List[str], List[str]]:
        """Resolve provider to canonical names and IDs."""
        name = explicit_name or self._extract_provider_from_question(question)
        if not name:
            return ([], [])
        resolved_names, method, provider_ids = self._provider_service.resolve(name)
        return (resolved_names, provider_ids)

    # -- Structured metadata shortcut -----------------------------------------

    def _try_structured_lookup(
        self,
        field_def: FieldDefinition,
        providers: List[str],
        provider_ids: List[str],
    ) -> Optional[ToolResult]:
        """Try to resolve field from structured metadata columns (no LLM needed).

        Returns a ToolResult if the field has a direct column and data is found,
        or None if the field requires passage-based extraction.
        """
        field_config = _STRUCTURED_FIELD_COLUMNS.get(field_def.name)
        if not field_config:
            return None
        if not provider_ids:
            return None

        table_key, column_name, agg_method = field_config
        # Resolve table name
        if table_key == "TBL_CONTRACT_DOCUMENTS_MASTER":
            table = qualified_table(TBL_CONTRACT_DOCUMENTS_MASTER)
        elif table_key == "TBL_CONTRACT_RATES_ALL":
            table = qualified_table(TBL_CONTRACT_RATES_ALL)
        else:
            return None

        prov_filter = build_provider_id_filter(provider_ids)
        try:
            if agg_method == "mode":
                # Get most common non-null value
                pdf = self._spark.sql(f"""
                    SELECT {column_name}, COUNT(*) AS cnt
                    FROM {table}
                    WHERE {prov_filter}
                      AND {column_name} IS NOT NULL
                      AND TRIM({column_name}) != ''
                    GROUP BY {column_name}
                    ORDER BY cnt DESC
                    LIMIT 5
                """).toPandas()
            elif agg_method == "latest":
                # Get value from latest document
                pdf = self._spark.sql(f"""
                    SELECT {column_name}, effective_date_parsed, source_filename
                    FROM {table}
                    WHERE {prov_filter}
                      AND {column_name} IS NOT NULL
                      AND TRIM(CAST({column_name} AS STRING)) != ''
                    ORDER BY effective_date_parsed DESC
                    LIMIT 5
                """).toPandas()
            else:
                return None

            if pdf.empty:
                return None  # Fall back to passage extraction

            # Extract the best value
            if agg_method == "mode":
                value = str(pdf.iloc[0][column_name])
                confidence = "HIGH" if pdf.iloc[0]["cnt"] >= 3 else "MODERATE"
                all_values = pdf[column_name].tolist()[:3]
                notes = f"From structured metadata ({pdf.iloc[0]['cnt']} occurrences)"
                if len(all_values) > 1:
                    notes += f". All values: {all_values}"
            else:  # latest
                value = str(pdf.iloc[0][column_name])
                confidence = "HIGH"
                notes = f"From structured metadata (latest document)"

            provider_display = providers[0] if providers else "provider"

            return ToolResult(
                success=True,
                data={
                    "query_type": "field_extraction",
                    "field_name": field_def.name,
                    "value_type": field_def.value_type,
                    "unit": field_def.unit,
                    "provider": provider_display,
                    "extraction": {
                        "value": value,
                        "confidence": confidence,
                        "source": "structured_metadata",
                        "notes": notes,
                    },
                    "method": "structured_lookup",
                },
                summary=(
                    f"{field_def.name} for {provider_display}: {value}"
                    + (f" {field_def.unit}" if field_def.unit and value else "")
                ),
                confidence=Confidence.HIGH if confidence == "HIGH" else Confidence.MODERATE,
                status=ToolStatus.SUCCESS,
                citations=[],
            )
        except Exception as exc:
            logger.debug("Structured lookup failed for %s: %s", field_def.name, exc)
            return None  # Fall back to passage extraction

    def _extract_provider_from_question(self, question: str) -> Optional[str]:
        """Extract provider from question using canonical names."""
        q_lower = question.lower()
        all_names = sorted(self._provider_service.all_names(), key=len, reverse=True)
        for name in all_names:
            if name.lower() in q_lower:
                return name
        return None

    # -- Passage retrieval ----------------------------------------------------

    def _retrieve_passages(
        self,
        field_def: FieldDefinition,
        providers: List[str],
        provider_ids: List[str],
        top_k: int,
    ) -> List[Dict[str, Any]]:
        """Retrieve relevant passages using keyword-based SQL retrieval.

        Uses version-aware ranking: latest document version preferred.
        """
        # Build keyword filter from field definition
        keyword_conditions = " OR ".join(
            f"LOWER(chunk_text) LIKE '%{kw.lower().replace(chr(39), chr(39)+chr(39))}%'"
            for kw in field_def.keywords[:5]  # Top 5 keywords
        )

        # Provider filter — tbl_vs_unified_ready uses provider_name (not provider_id)
        # Always filter by canonical name; provider_ids are for other tables (rates, etc.)
        provider_filter = ""
        if providers:
            safe_name = providers[0].replace("'", "''").lower()
            provider_filter = f"AND LOWER(provider_name) LIKE '%{safe_name}%'"
        # provider_ids intentionally NOT used here: fulltext table has no provider_id column

        # Version-aware query: prefer higher version numbers (_v2 > _v1)
        sql = f"""
            SELECT chunk_id, chunk_text, source_filename, provider_name,
                   page_number_est AS page_number,
                   CASE
                       WHEN source_filename RLIKE '_v[0-9]+\\.pdf$'
                       THEN CAST(REGEXP_EXTRACT(source_filename, '_v([0-9]+)\\.pdf$', 1) AS INT)
                       ELSE 1
                   END AS doc_version
            FROM {TBL_VS_UNIFIED_READY}
            WHERE ({keyword_conditions})
              {provider_filter}
            ORDER BY doc_version DESC, chunk_id
            LIMIT {top_k}
        """

        try:
            df = self._spark.sql(sql).toPandas()
            return df.to_dict(orient="records")
        except Exception as e:
            logger.warning(f"FieldExtraction retrieval failed: {e}")
            return []

    # -- LLM extraction -------------------------------------------------------

    def _extract_value(
        self,
        field_def: FieldDefinition,
        passages: List[Dict[str, Any]],
        providers: List[str],
    ) -> ExtractionResult:
        """Use LLM to extract the field value from retrieved passages."""
        if not self._llm_client:
            # Fallback: regex-based extraction for numeric/duration fields
            return self._extract_regex_fallback(field_def, passages)

        # Build context from passages
        context_parts = []
        for i, p in enumerate(passages[:5], 1):
            text = p.get("chunk_text", "")[:800]
            src = p.get("source_filename", "unknown")
            context_parts.append(f"[Passage {i} | {src}]\n{text}")
        context = "\n\n".join(context_parts)

        provider_label = providers[0] if providers else "the provider"

        # Type-specific extraction prompt
        type_instruction = {
            "duration": f"Return ONLY the numeric value (in {field_def.unit}). "
                       f"If the text says '90 days', return '90'. If unclear, return 'null'.",
            "currency": "Return ONLY the dollar amount as a number (no $ sign). "
                       "E.g., if '$1,000,000', return '1000000'. If unclear, return 'null'.",
            "date": "Return ONLY the date in YYYY-MM-DD format. If unclear, return 'null'.",
            "numeric": "Return ONLY the numeric value. If unclear, return 'null'.",
            "boolean": "Return ONLY 'true' or 'false'. If unclear, return 'null'.",
            "text": "Return a concise summary of the provision (1-2 sentences max). "
                   "If not found, return 'null'.",
        }.get(field_def.value_type, "Return the extracted value or 'null' if not found.")

        prompt = (
            f"Extract the following contract field for {provider_label}:\n\n"
            f"Field: {field_def.name}\n"
            f"Description: {field_def.description}\n"
            f"Expected type: {field_def.value_type}"
            + (f" ({field_def.unit})" if field_def.unit else "")
            + f"\n\nInstruction: {type_instruction}\n\n"
            f"Contract passages:\n{context}\n\n"
            f"Extracted value:"
        )

        try:
            response = self._llm_client.chat(
                model=LLM_FAST,
                system="You extract specific field values from healthcare contract text. "
                       "Be precise. Return only the value requested, nothing else.",
                user=prompt,
                max_tokens=200,
            )
            value = self._parse_extraction(response.strip(), field_def.value_type)
            best_passage = passages[0] if passages else {}
            return ExtractionResult(
                field_name=field_def.name,
                value=value,
                raw_text=best_passage.get("chunk_text", "")[:500],
                confidence="HIGH" if value is not None else "LOW",
                source_filename=best_passage.get("source_filename"),
                page_number=best_passage.get("page_number"),
            )
        except Exception as e:
            logger.warning(f"LLM extraction failed: {e}")
            return self._extract_regex_fallback(field_def, passages)

    def _parse_extraction(self, raw: str, value_type: str) -> Any:
        """Parse LLM response into typed value."""
        cleaned = raw.strip().strip("'\"\'").strip()
        if cleaned.lower() in ("null", "none", "n/a", "not found", ""):
            return None

        if value_type == "duration" or value_type == "numeric":
            # Extract first number
            match = re.search(r"[\d,]+\.?\d*", cleaned)
            if match:
                return float(match.group().replace(",", ""))
            return cleaned

        if value_type == "currency":
            match = re.search(r"[\d,]+\.?\d*", cleaned.replace("$", ""))
            if match:
                return float(match.group().replace(",", ""))
            return cleaned

        if value_type == "boolean":
            if cleaned.lower() in ("true", "yes", "1"):
                return True
            if cleaned.lower() in ("false", "no", "0"):
                return False
            return None

        if value_type == "date":
            # Accept ISO dates
            match = re.search(r"\d{4}-\d{2}-\d{2}", cleaned)
            if match:
                return match.group()
            return cleaned

        return cleaned  # text type

    def _extract_regex_fallback(
        self, field_def: FieldDefinition, passages: List[Dict[str, Any]]
    ) -> ExtractionResult:
        """Regex-based extraction when LLM is unavailable."""
        combined_text = " ".join(p.get("chunk_text", "") for p in passages[:3])
        value = None

        if field_def.value_type in ("duration", "numeric"):
            # Look for "X days/years/months" patterns near keywords
            for kw in field_def.keywords[:3]:
                pattern = rf"{re.escape(kw)}[^.]*?(\d+)\s*(?:{field_def.unit or 'days|years|months'})"
                match = re.search(pattern, combined_text, re.IGNORECASE)
                if match:
                    value = float(match.group(1))
                    break
            if value is None:
                # Broader: any number near a keyword
                for kw in field_def.keywords[:3]:
                    if kw.lower() in combined_text.lower():
                        numbers = re.findall(r"\b(\d+)\b", combined_text)
                        if numbers:
                            value = float(numbers[0])
                            break

        best_passage = passages[0] if passages else {}
        return ExtractionResult(
            field_name=field_def.name,
            value=value,
            raw_text=best_passage.get("chunk_text", "")[:500],
            confidence="MODERATE" if value is not None else "LOW",
            source_filename=best_passage.get("source_filename"),
            page_number=best_passage.get("page_number"),
            notes="regex fallback (no LLM)" if value else "no value extracted",
        )
