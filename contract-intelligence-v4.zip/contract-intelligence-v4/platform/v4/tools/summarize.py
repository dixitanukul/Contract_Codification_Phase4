"""
platform/v4/tools/summarize.py

LLM-based summarisation of retrieved contract passages.

Called by the agent after passage_search (and optionally citation_verify)
to synthesise a natural-language answer grounded in retrieved text.
All generated text is tagged Confidence.GENERATED per the V3 confidence
policy — the agent must attach source citations alongside it.
"""
from __future__ import annotations

import time
from typing import Any, Optional

from ..adapters.retrieval_adapter import RetrievedPassage
from ..config.settings import Settings
from ..contracts.tool_types import Confidence, ToolResult
from ..tools.base import BaseTool

_SYSTEM_PROMPT = """\
You are a contract analysis assistant for Blue Shield of California.
Summarise the following contract passages to answer the question.

Rules:
1. Only state what is directly supported by the provided passages.
2. Quote specific clause language where it matters.
3. Note any conflicting or superseded provisions.
4. If the passages are insufficient to answer the question, say so clearly.
5. Do NOT fabricate rates, dates, or legal terms not present in the passages.
6. Label your answer VERIFIED if grounded in passage text, or INFERRED if
   you had to draw a logical conclusion.
"""

_USER_TEMPLATE = """\
Question: {question}

Contract passages:
{passages_text}

Summary:
"""


def _format_passages(passages: list) -> str:
    """Format a list of RetrievedPassage objects or dicts for the LLM prompt."""
    lines: list[str] = []
    for i, p in enumerate(passages[:15], 1):   # cap at 15 to stay within token budget
        if isinstance(p, dict):
            provider = p.get("provider_name", "Unknown")
            page     = p.get("page_number", "")
            text     = p.get("text", "")
        elif hasattr(p, "provider_name"):
            provider = p.provider_name
            page     = p.page_number or ""
            text     = p.text
        else:
            text = str(p)
            provider = ""
            page     = ""

        header = f"[{i}] {provider}"
        if page:
            header += f" p.{page}"
        lines.append(header)
        lines.append(text[:800])
        lines.append("")
    return "\n".join(lines)


class SummarizeTool(BaseTool):
    """
    Synthesise a natural-language answer from retrieved passages.

    Parameters
    ----------
    llm_client : LLM client with .chat(model, system, user, max_tokens)->str.
    settings   : Settings instance.
    """

    def __init__(
        self,
        llm_client: Optional[Any]      = None,
        settings:   Optional[Settings] = None,
    ) -> None:
        self._llm      = llm_client
        self._settings = settings or Settings()

    def set_llm(self, llm: Any) -> None:
        self._llm = llm

    @property
    def name(self) -> str:
        return "summarize"

    def _run(
        self,
        question:  str = "",
        passages:  Optional[list] = None,
        max_tokens: int = 800,
        **kwargs:  Any,
    ) -> ToolResult:
        """
        Parameters
        ----------
        question   : The original user question.
        passages   : List of RetrievedPassage or dicts from passage_search.
        max_tokens : LLM max output tokens.
        """
        if not passages:
            return ToolResult(
                success=False,
                data=None,
                summary="No passages provided for summarization",
                confidence=Confidence.LOW,
                error_message="passages is empty",
            )

        if self._llm is None:
            # Stub: concatenate first passage summaries
            texts = []
            for p in passages[:3]:
                t = p.get("text", str(p)) if isinstance(p, dict) else getattr(p, "text", str(p))
                texts.append(t[:300])
            stub_answer = " [...] ".join(texts)
            return ToolResult(
                success=True,
                data=stub_answer,
                summary="[STUB] LLM not injected; returning raw passage excerpt",
                confidence=Confidence.GENERATED,
            )

        t0            = time.time()
        passages_text = _format_passages(passages)
        user          = _USER_TEMPLATE.format(
            question=question,
            passages_text=passages_text,
        )

        try:
            answer = self._llm.chat(
                model      = self._settings.LLM_MODEL,
                system     = _SYSTEM_PROMPT,
                user       = user,
                max_tokens = max_tokens,
            )
        except Exception as exc:  # noqa: BLE001
            return ToolResult(
                success=False,
                data=None,
                summary=f"LLM summarization error: {exc}",
                confidence=Confidence.LOW,
                execution_time_s=time.time() - t0,
                error_message=str(exc),
            )

        citations = []
        for p in passages:
            if isinstance(p, dict):
                citations.append({
                    "doc_id":        p.get("doc_id", ""),
                    "provider_name": p.get("provider_name", ""),
                    "page_number":   p.get("page_number"),
                    "section":       p.get("clause_type") or p.get("section"),
                })
            elif hasattr(p, "as_citation"):
                citations.append(p.as_citation())

        return ToolResult(
            success=True,
            data=answer,
            summary=answer[:200],
            citations=citations,
            confidence=Confidence.GENERATED,   # LLM synthesis = GENERATED per policy
            execution_time_s=time.time() - t0,
        )
