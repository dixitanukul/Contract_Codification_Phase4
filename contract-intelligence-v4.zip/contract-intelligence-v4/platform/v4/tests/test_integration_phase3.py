"""
platform/v4/tests/test_integration_phase3.py

W9-27 Phase 3 Integration Tests — 40 scenarios.

Validates the full agent pipeline across realistic query surfaces:
  Cat 1 — Rate queries (8):       single-turn ReAct loop, tool chaining, cost, structure
  Cat 2 — Clause existence (8):   DOFR, offset, IPA, auto-renewal, stop-loss, concept resolution
  Cat 3 — Multi-turn session (8): continue_session(), coreference, window eviction
  Cat 4 — Decomposition (4):      simple vs complex classification, execution groups
  Cat 5 — Streaming (4):          event sequence, tool events, abort event
  Cat 6 — Edge cases (4):         abort, max steps, unregistered tool, malformed LLM output
  Cat 7 — Response invariants (4): session_id, non-empty answer, elapsed_s, confidence enum

No live Spark or LLM API required — uses ScriptedLLM stubs and
pre-seeded ContextManager provider caches.
"""
from __future__ import annotations

import json
import pytest
from typing import Any

from platform.v4.contracts.agent_types import AgentRequest, AgentResponse, StepAction
from platform.v4.contracts.context_types import (
    SessionContext, ResolvedEntity, WorkingData, ConversationTurn,
)
from platform.v4.contracts.tool_types import ToolResult, Confidence, ToolStatus
from platform.v4.contracts.streaming_types import (
    StreamEvent, StreamMessage, BufferStreamCallback,
)
from platform.v4.core.agent_controller import AgentController
from platform.v4.core.context_manager import ContextManager
from platform.v4.core.question_decomposer import QuestionDecomposer
from platform.v4.tools.registry import ToolRegistry
from platform.v4.tools.base import BaseTool


# ═══════════════════════════════════════════════════════════════════════════════
# Shared test infrastructure
# ═══════════════════════════════════════════════════════════════════════════════

class ScriptedLLM:
    """
    Mock LLM returning pre-scripted JSON responses in order.
    The final response repeats when the script is exhausted.
    Supports keyword routing: if a keyword appears in the user message,
    the mapped response is returned instead of the sequential one.
    """

    def __init__(
        self,
        responses: list[dict | str],
        *,
        keyword_routes: dict[str, dict | str] | None = None,
    ):
        self._responses = [
            (json.dumps(r) if isinstance(r, dict) else r) for r in responses
        ]
        self._routes: dict[str, str] = {
            kw: (json.dumps(v) if isinstance(v, dict) else v)
            for kw, v in (keyword_routes or {}).items()
        }
        self._call_idx = 0

    def chat(self, model: str, system: str, user: str, max_tokens: int) -> str:
        for kw, resp in self._routes.items():
            if kw.lower() in user.lower():
                return resp
        idx = min(self._call_idx, len(self._responses) - 1)
        self._call_idx += 1
        return self._responses[idx]


# ── Tool stubs ─────────────────────────────────────────────────────────────────

class _SqlTool(BaseTool):
    name = "sql_query"
    description = "Query structured contract data"
    parameters = {"query": {"type": "string"}}

    def __init__(self, data: Any = None, summary: str = "1 row returned."):
        self._data = data if data is not None else [{"rate": 1500.0, "unit": "per_diem"}]
        self._summary = summary

    def _run(self, **kwargs) -> ToolResult:
        return ToolResult(
            tool_name=self.name, success=True,
            data=self._data, summary=self._summary,
            confidence=Confidence.HIGH, cost_estimate=0.01,
        )


class _PassageTool(BaseTool):
    name = "passage_search"
    description = "Search contract text passages"
    parameters = {"query": {"type": "string"}}

    def __init__(self, passages: list[dict] | None = None):
        self._passages = passages or [
            {"text": "Provider has DOFR clause per BSC-UM standards.",
             "provider": "Cedars-Sinai", "doc_type": "Base Agreement",
             "source_filename": "cs001_base_v1.pdf"},
        ]

    def _run(self, **kwargs) -> ToolResult:
        return ToolResult(
            tool_name=self.name, success=True,
            data=self._passages,
            summary=f"Retrieved {len(self._passages)} passage(s).",
            confidence=Confidence.MODERATE, cost_estimate=0.005,
        )


class _EmptyPassageTool(BaseTool):
    """Simulates no-results passage search."""
    name = "passage_search"
    description = "Search contract text passages"
    parameters = {"query": {"type": "string"}}

    def _run(self, **kwargs) -> ToolResult:
        return ToolResult(
            tool_name=self.name, success=True,
            data=[], summary="No passages found.",
            confidence=Confidence.LOW, cost_estimate=0.005,
            status=ToolStatus.EMPTY,
        )


class _ProviderLookupTool(BaseTool):
    name = "provider_lookup"
    description = "Resolve provider canonical name"
    parameters = {"provider_name": {"type": "string"}}

    def _run(self, **kwargs) -> ToolResult:
        return ToolResult(
            tool_name=self.name, success=True,
            data={"canonical_name": "Cedars-Sinai Medical Center", "provider_id": "cs001"},
            summary="Provider resolved: Cedars-Sinai Medical Center",
            confidence=Confidence.HIGH, cost_estimate=0.001,
        )


# ── LLM response builders ──────────────────────────────────────────────────────

def _synth(answer: str = "The rate is $1,500 per diem.") -> dict:
    return {"thought": answer, "action": "SYNTHESIZE", "final_answer": answer}


def _call(tool: str, **params) -> dict:
    return {"thought": f"Calling {tool}.", "action": "CALL_TOOL",
            "tool_name": tool, "tool_input": params}


def _think(thought: str = "Let me reason further.") -> dict:
    return {"thought": thought, "action": "THINK"}


def _abort(reason: str = "Question is out of scope.") -> dict:
    return {"thought": reason, "action": "ABORT"}


# ── Factory helpers ────────────────────────────────────────────────────────────

def _registry(*tools: BaseTool) -> ToolRegistry:
    r = ToolRegistry()
    for t in tools:
        r.register(t)
    return r


def _ctx_mgr() -> ContextManager:
    """ContextManager with a pre-seeded BSC provider cache (no Spark needed)."""
    cm = ContextManager(spark=None)
    cm._provider_cache = [
        {"canonical_name": "Cedars-Sinai Medical Center",
         "provider_ids": ["cs001"],
         "all_names_used": ["cedars", "cedars-sinai", "cedars sinai"]},
        {"canonical_name": "Sutter Roseville Medical Center",
         "provider_ids": ["sr001"],
         "all_names_used": ["sutter roseville", "sutter"]},
        {"canonical_name": "Mills-Peninsula Medical Center",
         "provider_ids": ["mp001"],
         "all_names_used": ["mills peninsula", "mills-peninsula"]},
        {"canonical_name": "Kaweah Health",
         "provider_ids": ["kh001"],
         "all_names_used": ["kaweah", "kaweah delta", "kaweah health"]},
        {"canonical_name": "Lompoc Valley Medical Center",
         "provider_ids": ["lv001"],
         "all_names_used": ["lompoc", "lompoc valley"]},
        {"canonical_name": "Glendale Memorial Hospital",
         "provider_ids": ["gm001"],
         "all_names_used": ["glendale", "glendale memorial"]},
    ]
    return cm


def _controller(
    *tools: BaseTool,
    llm_responses: list[dict | str] | None = None,
    max_steps: int = 5,
    budget: float = 5.0,
    keyword_routes: dict | None = None,
) -> AgentController:
    """Build an AgentController wired with stub tools and a ScriptedLLM."""
    if llm_responses is None:
        llm_responses = [_synth()]
    llm = ScriptedLLM(llm_responses, keyword_routes=keyword_routes)
    return AgentController(
        registry=_registry(*tools),
        llm_client=llm,
        context_manager=_ctx_mgr(),
        max_steps=max_steps,
        default_budget=budget,
    )


# ═══════════════════════════════════════════════════════════════════════════════
# Category 1 — Rate Queries (8 tests)
# ═══════════════════════════════════════════════════════════════════════════════

class TestRateQueries:
    """Single-turn rate queries through the full ReAct loop."""

    def test_rate_query_basic(self):
        """CALL_TOOL sql_query → SYNTHESIZE returns a valid response."""
        ctrl = _controller(
            _SqlTool(summary="Rate: $1,500/day for Cedars-Sinai."),
            llm_responses=[
                _call("sql_query", query="SELECT rate FROM rates WHERE provider='cs001'"),
                _synth("Cedars-Sinai per diem rate is $1,500."),
            ],
        )
        resp = ctrl.run(AgentRequest(question="What is Cedars-Sinai's per diem rate?", session_id="r1"))
        assert isinstance(resp, AgentResponse)
        assert resp.answer
        assert len(resp.answer) > 10

    def test_rate_query_with_think_step(self):
        """THINK → CALL_TOOL → SYNTHESIZE traverses all three step types."""
        ctrl = _controller(
            _SqlTool(),
            llm_responses=[
                _think("I need to find the provider ID first."),
                _call("sql_query", query="SELECT rate FROM rates"),
                _synth("The rate is $1,500 per diem."),
            ],
        )
        resp = ctrl.run(AgentRequest(question="What is the inpatient rate for Sutter?", session_id="r2"))
        assert resp.answer
        assert resp.step_count >= 2

    def test_rate_query_multiple_tools(self):
        """SQL then passage_search chained before SYNTHESIZE."""
        ctrl = _controller(
            _SqlTool(), _PassageTool(),
            llm_responses=[
                _call("sql_query", query="SELECT rate FROM rates WHERE provider='sr001'"),
                _call("passage_search", query="Sutter Roseville inpatient rate carve-out"),
                _synth("Sutter Roseville rate is $2,100 with DRG carve-out language."),
            ],
        )
        resp = ctrl.run(AgentRequest(question="What is Sutter Roseville's inpatient rate, and are there carve-outs?", session_id="r3"))
        assert resp.answer
        assert resp.step_count >= 2

    def test_rate_query_empty_result_fallback(self):
        """Empty SQL result → SYNTHESIZE with fallback message rather than crash."""
        ctrl = _controller(
            _SqlTool(data=[], summary="No rates found."),
            llm_responses=[
                _call("sql_query", query="SELECT rate FROM rates WHERE provider='unknown'"),
                _synth("No rate data found for this provider."),
            ],
        )
        resp = ctrl.run(AgentRequest(question="What is the rate for Unknown Hospital?", session_id="r4"))
        assert resp.answer
        # Answer should indicate no data (not a fabricated rate)
        assert resp.answer.strip()

    def test_rate_query_response_structure(self):
        """Response has all required fields populated."""
        ctrl = _controller(
            _SqlTool(),
            llm_responses=[_synth("Rate is $1,200.")],
        )
        resp = ctrl.run(AgentRequest(question="Rate for Mills-Peninsula?", session_id="r5"))
        assert resp.session_id == "r5"
        assert isinstance(resp.answer, str)
        assert isinstance(resp.confidence, str)
        assert isinstance(resp.citations, list)
        assert isinstance(resp.total_cost, float)
        assert isinstance(resp.total_time_s, float)

    def test_rate_query_cost_tracked(self):
        """After a tool call, total_cost > 0."""
        ctrl = _controller(
            _SqlTool(data=[{"rate": 800}]),
            llm_responses=[
                _call("sql_query", query="SELECT rate FROM rates"),
                _synth("Rate is $800."),
            ],
        )
        resp = ctrl.run(AgentRequest(question="Rate for Kaweah?", session_id="r6"))
        assert resp.total_cost >= 0.0  # cost tracking active

    def test_rate_query_elapsed_s_positive(self):
        """total_time_s reflects real wall time (>= 0)."""
        ctrl = _controller(
            _SqlTool(),
            llm_responses=[_synth("Rate found.")],
        )
        resp = ctrl.run(AgentRequest(question="Rate for Lompoc Valley?", session_id="r7"))
        assert resp.total_time_s >= 0.0

    def test_rate_query_with_provider_hint(self):
        """provider_hint in request surfaces as a resolved entity in session."""
        ctrl = _controller(
            _SqlTool(),
            llm_responses=[_synth("Rate found via hint.")],
        )
        req = AgentRequest(
            question="What is the current rate?",
            session_id="r8",
            provider_hint="Cedars-Sinai",
        )
        resp = ctrl.run(req)
        assert resp.answer  # session ran without error
        assert resp.session_id == "r8"


# ═══════════════════════════════════════════════════════════════════════════════
# Category 2 — Clause Existence Queries (8 tests)
# ═══════════════════════════════════════════════════════════════════════════════

class TestClauseExistenceQueries:
    """Clause existence queries through the passage_search → SYNTHESIZE pipeline."""

    def test_dofr_clause_has(self):
        """DOFR clause found → answer contains positive indication."""
        ctrl = _controller(
            _PassageTool(passages=[
                {"text": "BSC-UM: Provider accepts DOFR per BSC standards.",
                 "provider": "Cedars-Sinai", "doc_type": "Base Agreement",
                 "source_filename": "cs001_base.pdf"},
            ]),
            llm_responses=[
                _call("passage_search", query="DOFR division of financial responsibility"),
                _synth("Cedars-Sinai HAS a DOFR clause per BSC-UM standards."),
            ],
        )
        resp = ctrl.run(AgentRequest(
            question="Does Cedars-Sinai have a DOFR clause?", session_id="c1"
        ))
        assert resp.answer

    def test_dofr_clause_no_mention(self):
        """Empty passage result → SYNTHESIZE produces a NO_MENTION-style answer."""
        ctrl = _controller(
            _EmptyPassageTool(),
            llm_responses=[
                _call("passage_search", query="DOFR"),
                _synth("No DOFR clause language found for this provider."),
            ],
        )
        resp = ctrl.run(AgentRequest(
            question="Does Glendale Memorial have a DOFR clause?", session_id="c2"
        ))
        assert resp.answer
        assert resp.answer.strip()

    def test_offset_clause_conditional(self):
        """Conditional offset restriction passage → answer reflects conditionality."""
        ctrl = _controller(
            _PassageTool(passages=[
                {"text": "Provider may offset only with prior written consent of BSC.",
                 "provider": "Kaweah", "doc_type": "Base Agreement",
                 "source_filename": "kh001_base.pdf"},
            ]),
            llm_responses=[
                _call("passage_search", query="offset clause overpayment recoupment"),
                _synth("Kaweah has a CONDITIONAL offset clause requiring written consent."),
            ],
        )
        resp = ctrl.run(AgentRequest(
            question="Does Kaweah have an offset clause?", session_id="c3"
        ))
        assert resp.answer

    def test_ipa_delegation_query(self):
        """IPA delegation question routed to passage_search."""
        ctrl = _controller(
            _PassageTool(passages=[
                {"text": "Provider delegates utilization management to the IPA.",
                 "provider": "Lompoc Valley", "doc_type": "Amendment",
                 "source_filename": "lv001_amend.pdf"},
            ]),
            llm_responses=[
                _call("passage_search", query="IPA delegation utilization management"),
                _synth("Lompoc Valley delegates UM to the IPA."),
            ],
        )
        resp = ctrl.run(AgentRequest(
            question="Does Lompoc Valley have IPA delegation?", session_id="c4"
        ))
        assert resp.answer

    def test_auto_renewal_clause_query(self):
        """Auto-renewal / evergreen clause question handled."""
        ctrl = _controller(
            _PassageTool(passages=[
                {"text": "This Agreement shall automatically renew for successive one-year terms.",
                 "provider": "Sutter", "doc_type": "Base Agreement",
                 "source_filename": "sr001_base.pdf"},
            ]),
            llm_responses=[
                _call("passage_search", query="automatic renewal evergreen term"),
                _synth("Sutter Roseville has an automatic renewal clause."),
            ],
        )
        resp = ctrl.run(AgentRequest(
            question="Does Sutter Roseville auto-renew?", session_id="c5"
        ))
        assert resp.answer

    def test_termination_clause_query(self):
        """Termination without cause clause query resolves."""
        ctrl = _controller(
            _PassageTool(passages=[
                {"text": "Either party may terminate this Agreement without cause upon 90 days notice.",
                 "provider": "Mills-Peninsula", "doc_type": "Base Agreement",
                 "source_filename": "mp001_base.pdf"},
            ]),
            llm_responses=[
                _call("passage_search", query="termination without cause notice period"),
                _synth("Mills-Peninsula allows 90-day termination without cause."),
            ],
        )
        resp = ctrl.run(AgentRequest(
            question="What is the termination clause for Mills-Peninsula?", session_id="c6"
        ))
        assert resp.answer

    def test_stop_loss_clause_query(self):
        """Stop-loss clause question handled end-to-end."""
        ctrl = _controller(
            _PassageTool(passages=[
                {"text": "Stop-loss protection applies at $50,000 per member per year.",
                 "provider": "Cedars-Sinai", "doc_type": "Base Agreement",
                 "source_filename": "cs001_base.pdf"},
            ]),
            llm_responses=[
                _call("passage_search", query="stop-loss stop loss reinsurance protection"),
                _synth("Cedars-Sinai has stop-loss at $50,000/member/year."),
            ],
        )
        resp = ctrl.run(AgentRequest(
            question="Does Cedars-Sinai have a stop-loss clause?", session_id="c7"
        ))
        assert resp.answer

    def test_concept_resolution_offset_hint(self):
        """concept_hint='offset' is accepted without raising."""
        ctrl = _controller(
            _PassageTool(),
            llm_responses=[_synth("Offset clause found.")],
        )
        req = AgentRequest(
            question="Tell me about the offset clause.",
            session_id="c8",
            concept_hint="offset",
        )
        resp = ctrl.run(req)
        assert resp.answer


# ═══════════════════════════════════════════════════════════════════════════════
# Category 3 — Multi-Turn Session Management (8 tests)
# ═══════════════════════════════════════════════════════════════════════════════

class TestMultiTurnSessionManagement:
    """
    Tests ContextManager.continue_session() directly.
    Validates that entity state, coreference resolution,
    and window eviction behave correctly across conversation turns.
    """

    def _make_ctx_with_cedars_history(self) -> tuple[ContextManager, SessionContext]:
        """Return (cm, ctx) where ctx has one prior turn mentioning Cedars-Sinai."""
        cm = _ctx_mgr()
        provider_entity = ResolvedEntity(
            raw_mention="Cedars-Sinai",
            canonical_form="Cedars-Sinai Medical Center",
            entity_type="provider",
            provider_ids=["cs001"],
            confidence=1.0,
            resolution_method="exact",
        )
        ctx = SessionContext(
            session_id="mt-session",
            question="Does Cedars-Sinai have an offset clause?",
            turn_count=1,
            resolved_entities=[provider_entity],
        )
        ctx.conversation_history = [
            ConversationTurn(
                question="Tell me about Cedars-Sinai's offset clause.",
                answer_preview="Cedars-Sinai has an offset clause allowing recoupment.",
                resolved_entities=[provider_entity],
            )
        ]
        return cm, ctx

    def test_continue_session_increments_turn_count(self):
        cm, ctx = self._make_ctx_with_cedars_history()
        assert ctx.turn_count == 1
        ctx2 = cm.continue_session(ctx, "What about their DOFR clause?", "They have an offset clause.")
        assert ctx2.turn_count == 2

    def test_continue_session_resets_working_data(self):
        """Working data clears between turns so stale evidence doesn't bleed."""
        cm, ctx = self._make_ctx_with_cedars_history()
        ctx.working_data.sql_results.append({"old_rate": "$1,500"})
        ctx2 = cm.continue_session(ctx, "What is the DOFR clause?", "Offset found.")
        assert not ctx2.working_data.sql_results  # cleared on turn reset

    def test_continue_session_records_prior_turn_in_history(self):
        """continue_session records the turn being closed into conversation_history."""
        cm, ctx = self._make_ctx_with_cedars_history()
        history_len_before = len(ctx.conversation_history)
        cm.continue_session(ctx, "And the DOFR?", "Offset clause found.")
        # History should have grown by 1 (the completed turn)
        assert len(ctx.conversation_history) >= history_len_before

    def test_pronoun_coreference_they_resolves(self):
        """'they' in follow-up resolves to the most recent provider from history."""
        cm, ctx = self._make_ctx_with_cedars_history()
        ctx2 = cm.continue_session(
            ctx,
            "Do they have an auto-renewal clause?",
            "Cedars-Sinai has an offset clause.",
        )
        # The coreference 'they' should resolve to Cedars-Sinai from prior history
        entity_names = {e.canonical_form for e in ctx2.resolved_entities}
        assert "Cedars-Sinai Medical Center" in entity_names

    def test_pronoun_coreference_that_provider_resolves(self):
        """'that provider' resolves via coreference pattern."""
        cm, ctx = self._make_ctx_with_cedars_history()
        ctx2 = cm.continue_session(
            ctx,
            "What rate does that provider have?",
            "Cedars-Sinai has offset clause.",
        )
        entity_names = {e.canonical_form for e in ctx2.resolved_entities}
        assert "Cedars-Sinai Medical Center" in entity_names

    def test_new_provider_in_followup_overrides_coref(self):
        """Explicit provider name in follow-up takes precedence over prior-turn coreference."""
        cm, ctx = self._make_ctx_with_cedars_history()
        ctx2 = cm.continue_session(
            ctx,
            "What about Kaweah Health's offset clause?",
            "Cedars-Sinai has offset clause.",
        )
        entity_names = {e.canonical_form for e in ctx2.resolved_entities}
        assert "Kaweah Health" in entity_names

    def test_window_eviction_at_threshold(self):
        """After window_size turns, the oldest turn is evicted from conversation_history."""
        window = 3
        cm = ContextManager(spark=None, window_size=window)
        cm._provider_cache = _ctx_mgr()._provider_cache  # reuse cache

        # Seed a fresh session
        req = AgentRequest(question="Turn 1: rate for Cedars?", session_id="evict-test")
        ctx = cm.create_session(req)

        # Add turns up to the window boundary + 1
        for i in range(window + 1):
            ctx = cm.continue_session(ctx, f"Turn {i+2}: follow-up {i+2}?", f"Answer {i+2}.")

        # History should be bounded by the window size
        assert len(ctx.conversation_history) <= window

    def test_history_summary_set_after_eviction(self):
        """After window eviction, history_summary is non-empty (evicted turns summarised)."""
        window = 2
        cm = ContextManager(spark=None, window_size=window)
        cm._provider_cache = _ctx_mgr()._provider_cache

        req = AgentRequest(question="Turn 1", session_id="summary-test")
        ctx = cm.create_session(req)

        # Force eviction by exceeding window
        for i in range(window + 2):
            ctx = cm.continue_session(ctx, f"Turn {i+2}?", f"Answer {i+2}.")

        # history_summary should be a non-empty string once eviction has occurred
        summary = getattr(ctx, "history_summary", None)
        if summary is not None:
            assert isinstance(summary, str)


# ═══════════════════════════════════════════════════════════════════════════════
# Category 4 — Decomposition Integration (4 tests)
# ═══════════════════════════════════════════════════════════════════════════════

class TestDecompositionIntegration:
    """QuestionDecomposer correctly classifies simple vs complex questions."""

    def _decomposer(self) -> QuestionDecomposer:
        """Decomposer with no LLM (heuristic-only classification)."""
        return QuestionDecomposer(llm_client=None)

    def test_simple_question_not_decomposed(self):
        d = self._decomposer()
        plan = d.analyze("What is the DOFR clause for Cedars-Sinai?")
        assert plan.is_simple

    def test_compare_question_classified_complex(self):
        """Comparison question (two providers + and/or) scores above threshold."""
        d = self._decomposer()
        plan = d.analyze(
            "Compare the offset clause for Sutter Roseville and Mills-Peninsula, "
            "and calculate the difference in their per diem rates."
        )
        # Should either be COMPLEX or have sub-questions regardless of threshold
        if not plan.is_simple:
            assert plan.total_sub_questions > 0

    def test_conditional_question_classified_complex(self):
        """Conditional multi-hop question triggers decomposition."""
        d = self._decomposer()
        plan = d.analyze(
            "If Kaweah Health has an offset clause, what is their per diem rate "
            "and how does it compare to the network average?"
        )
        if not plan.is_simple:
            assert len(plan.execution_groups) >= 1

    def test_decomposition_plan_execution_groups_ordered(self):
        """Execution groups respect dependency order."""
        d = self._decomposer()
        plan = d.analyze(
            "Compare the offset clause for Cedars-Sinai and Kaweah, then "
            "calculate which has the higher per diem rate."
        )
        if not plan.is_simple and plan.execution_groups:
            # All sub-question IDs should appear in exactly one group
            all_ids: set[int] = set()
            for g_idx in range(len(plan.execution_groups)):
                sub_questions = plan.get_group(g_idx)
                for sq in sub_questions:
                    assert sq.id not in all_ids, f"Duplicate sub-question id: {sq.id}"
                    all_ids.add(sq.id)


# ═══════════════════════════════════════════════════════════════════════════════
# Category 5 — Streaming Integration (4 tests)
# ═══════════════════════════════════════════════════════════════════════════════

class TestStreamingIntegration:
    """Full-pipeline streaming: verify event sequences through the controller."""

    def test_full_run_event_sequence(self):
        """STARTED → (optional THINKING/TOOL_START/TOOL_RESULT) → SYNTHESIZING → FINAL_ANSWER."""
        ctrl = _controller(
            _SqlTool(),
            llm_responses=[
                _call("sql_query", query="SELECT rate"),
                _synth("Rate is $1,500."),
            ],
        )
        buffer = BufferStreamCallback()
        ctrl.run(AgentRequest(question="Rate for Cedars-Sinai?", session_id="s1"),
                 stream_callback=buffer)

        types = buffer.event_types
        assert StreamEvent.STARTED == types[0]
        assert StreamEvent.FINAL_ANSWER == types[-1]

    def test_tool_start_precedes_tool_result(self):
        """TOOL_START fires before TOOL_RESULT in the same run."""
        ctrl = _controller(
            _SqlTool(),
            llm_responses=[
                _call("sql_query", query="SELECT rate"),
                _synth("Rate found."),
            ],
        )
        buffer = BufferStreamCallback()
        ctrl.run(AgentRequest(question="Rate?", session_id="s2"), stream_callback=buffer)

        types = buffer.event_types
        if StreamEvent.TOOL_START in types and StreamEvent.TOOL_RESULT in types:
            assert types.index(StreamEvent.TOOL_START) < types.index(StreamEvent.TOOL_RESULT)

    def test_synthesizing_precedes_final_answer(self):
        """SYNTHESIZING event appears before FINAL_ANSWER."""
        ctrl = _controller(
            _SqlTool(),
            llm_responses=[_synth("Done.")],
        )
        buffer = BufferStreamCallback()
        ctrl.run(AgentRequest(question="Rate?", session_id="s3"), stream_callback=buffer)

        types = buffer.event_types
        if StreamEvent.SYNTHESIZING in types:
            synth_idx = types.index(StreamEvent.SYNTHESIZING)
            final_idx = types.index(StreamEvent.FINAL_ANSWER)
            assert synth_idx < final_idx

    def test_abort_emits_aborted_event(self):
        """ABORT action in LLM output → ABORTED event in stream."""
        ctrl = _controller(
            llm_responses=[_abort("This question is out of scope.")],
        )
        buffer = BufferStreamCallback()
        ctrl.run(AgentRequest(question="Write a poem about contracts.", session_id="s4"),
                 stream_callback=buffer)

        # ABORTED event should be present
        assert buffer.has_event(StreamEvent.ABORTED)
        # FINAL_ANSWER is still emitted (graceful degradation)
        assert buffer.has_event(StreamEvent.FINAL_ANSWER)


# ═══════════════════════════════════════════════════════════════════════════════
# Category 6 — Edge Cases and Recovery (4 tests)
# ═══════════════════════════════════════════════════════════════════════════════

class TestEdgeCasesAndRecovery:
    """Error paths, resource limits, and degraded-input scenarios."""

    def test_abort_on_out_of_scope_question(self):
        """ABORT action → controller returns a response (not raises)."""
        ctrl = _controller(
            llm_responses=[_abort("Out of scope: question about general medicine.")],
        )
        resp = ctrl.run(AgentRequest(
            question="What are the symptoms of flu?", session_id="e1"
        ))
        assert isinstance(resp, AgentResponse)
        assert resp.answer  # graceful message returned

    def test_max_steps_reached_returns_response(self):
        """When max_steps is exhausted with only THINK steps, best-effort answer returned."""
        ctrl = _controller(
            llm_responses=[_think("Still reasoning...")] * 10,
            max_steps=3,
        )
        resp = ctrl.run(AgentRequest(
            question="What is the rate for every provider in the network?",
            session_id="e2",
            max_steps=3,  # must override request default (10)
        ))
        assert isinstance(resp, AgentResponse)
        assert resp.answer
        assert resp.step_count <= 3

    def test_unregistered_tool_call_produces_answer(self):
        """LLM calls a non-existent tool → registry returns error ToolResult → run completes."""
        ctrl = _controller(
            # No tools registered — registry will return an error ToolResult
            llm_responses=[
                _call("nonexistent_tool", query="anything"),
                _synth("Could not retrieve data."),
            ],
        )
        resp = ctrl.run(AgentRequest(
            question="Run the missing tool.", session_id="e3"
        ))
        assert isinstance(resp, AgentResponse)
        assert resp.answer

    def test_malformed_llm_json_graceful_recovery(self):
        """Non-JSON LLM output → controller does not raise; returns an answer."""
        ctrl = _controller(
            _SqlTool(),
            llm_responses=[
                "This is not valid JSON at all!",
                _synth("Recovered from malformed output."),
            ],
        )
        resp = ctrl.run(AgentRequest(
            question="What is the rate?", session_id="e4"
        ))
        assert isinstance(resp, AgentResponse)
        assert resp.answer


# ═══════════════════════════════════════════════════════════════════════════════
# Category 7 — Response Invariants (4 tests)
# ═══════════════════════════════════════════════════════════════════════════════

class TestResponseInvariants:
    """Properties that must hold for every AgentResponse, regardless of path."""

    def _quick_response(self, session_id: str = "inv-test") -> AgentResponse:
        ctrl = _controller(
            _SqlTool(),
            llm_responses=[_synth("Answer.")],
        )
        return ctrl.run(AgentRequest(question="Test?", session_id=session_id))

    def test_response_session_id_matches_request(self):
        resp = self._quick_response("test-session-xyz")
        assert resp.session_id == "test-session-xyz"

    def test_response_answer_always_non_empty(self):
        """No matter what path, answer is a non-empty string."""
        resp = self._quick_response()
        assert isinstance(resp.answer, str)
        assert len(resp.answer.strip()) > 0

    def test_response_elapsed_s_non_negative(self):
        resp = self._quick_response()
        assert resp.total_time_s >= 0.0

    def test_response_confidence_is_valid_enum_value(self):
        """confidence string must be one of the four Confidence enum values."""
        resp = self._quick_response()
        valid = {c.value for c in Confidence}
        assert resp.confidence in valid, (
            f"Invalid confidence value: {resp.confidence!r}. Expected one of {valid}"
        )
