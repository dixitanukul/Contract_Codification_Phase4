"""Tests for QuestionRouter (P5)."""
from __future__ import annotations

import pytest

from platform.v4.core.question_router import (
    QuestionRouter,
    RoutingDecision,
    ROUTE_TO_TOOL,
    VALID_ROUTES,
)


# ── Mock helpers ─────────────────────────────────────────────────────────────

class MockProviderService:
    def __init__(self, names=None):
        self._names = names or [
            "Sutter Health", "Kaiser Permanente", "Providence Health",
            "UCSF Medical Center", "Cedars-Sinai Medical Center", "Dignity Health",
        ]

    def all_names(self):
        return self._names


class MockLLMClient:
    def __init__(self, response=None):
        self._response = response
        self.calls = []

    def chat(self, model, system, user, max_tokens, temperature=0.0):
        self.calls.append(user[:60])
        return self._response or "{}"


def make_router(names=None, llm_response=None):
    ps = MockProviderService(names=names)
    llm = MockLLMClient(response=llm_response) if llm_response is not None else None
    return QuestionRouter(provider_service=ps, llm_client=llm)


# ── RoutingDecision ───────────────────────────────────────────────────────────

class TestRoutingDecision:
    def test_default_fields(self):
        rd = RoutingDecision(route="clause_existence", tool_name="clause_existence")
        assert rd.providers == []
        assert rd.concepts == []
        assert rd.confidence == "heuristic"
        assert rd.unresolvable_comparison is False
        assert rd.target_concept is None

    def test_to_tool_input_keys(self):
        rd = RoutingDecision(
            route="comparison", tool_name="comparison",
            providers=["Sutter", "Kaiser"],
            concepts=["offset clause"],
            target_concept="offset clause",
            is_negative=False,
        )
        ti = rd.to_tool_input()
        assert "providers" in ti
        assert "concept" in ti
        assert "concepts" in ti
        assert ti["providers"] == ["Sutter", "Kaiser"]
        assert ti["concept"] == "offset clause"


# ── ROUTE_TO_TOOL mapping ─────────────────────────────────────────────────────

class TestRouteToTool:
    def test_all_eight_routes_mapped(self):
        # Updated to 9 routes after adding sql_query
        expected_tools = {
            "clause_existence", "field_extraction", "provider_deep_dive",
            "comparison", "rate_query", "explanation", "multi_concept", "temporal_analysis",
            "sql_query",
        }
        assert set(ROUTE_TO_TOOL.values()) == expected_tools

    def test_valid_routes_matches_keys(self):
        assert VALID_ROUTES == frozenset(ROUTE_TO_TOOL.keys())

    @pytest.mark.parametrize("route,expected_tool", [
        ("clause_existence",      "clause_existence"),
        ("structured_extraction", "field_extraction"),
        ("single_provider",       "provider_deep_dive"),
        ("comparison",            "comparison"),
        ("rate_query",            "rate_query"),
        ("explanation",           "explanation"),
        ("multi_concept",         "multi_concept"),
        ("temporal",              "temporal_analysis"),
        ("sql_query",             "sql_query"),
    ])
    def test_each_route(self, route, expected_tool):
        assert ROUTE_TO_TOOL[route] == expected_tool


# ── Provider detection ────────────────────────────────────────────────────────

class TestProviderDetection:
    def test_detects_single_provider(self):
        r = make_router()
        providers = r._detect_providers("Show me Sutter Health's contracts")
        assert "Sutter Health" in providers

    def test_detects_multiple_providers(self):
        r = make_router()
        providers = r._detect_providers("Compare Sutter Health vs Kaiser Permanente on termination")
        assert "Sutter Health" in providers
        assert "Kaiser Permanente" in providers

    def test_min_length_4_enforced(self):
        r = make_router(names=["AB", "ABC", "ABCD", "ABCDE"])
        # "AB" and "ABC" are below the 4-char minimum
        providers = r._detect_providers("AB ABC ABCD ABCDE")
        assert "AB" not in providers
        assert "ABC" not in providers
        assert "ABCD" in providers

    def test_longest_match_preferred(self):
        r = make_router(names=["Sutter", "Sutter Health"])
        providers = r._detect_providers("Explain Sutter Health contracts")
        assert "Sutter Health" in providers
        # "Sutter" should also match (it's a substring of "Sutter Health")
        # but "Sutter Health" should appear (longest-match sorted first)
        assert providers[0] == "Sutter Health"

    def test_no_providers_returns_empty(self):
        r = make_router()
        providers = r._detect_providers("Which providers have offset clause?")
        assert providers == []

    def test_caps_at_five(self):
        names = [f"Provider {i} Health" for i in range(10)]
        r = make_router(names=names)
        q = " ".join(names)
        providers = r._detect_providers(q)
        assert len(providers) <= 5


# ── Heuristic routing ─────────────────────────────────────────────────────────

class TestHeuristicRoute:
    def setup_method(self):
        self.router = make_router()

    def test_temporal_keyword(self):
        result = self.router._heuristic_route("What changed in Sutter's 2024 amendment?", [])
        assert result["route"] == "temporal"

    def test_rate_keyword(self):
        result = self.router._heuristic_route("What is the average per diem rate?", [])
        assert result["route"] == "rate_query"

    def test_comparison_two_providers(self):
        result = self.router._heuristic_route(
            "Compare Sutter vs Kaiser on termination", ["Sutter Health", "Kaiser Permanente"]
        )
        assert result["route"] == "comparison"

    def test_comparison_one_provider_not_comparison(self):
        result = self.router._heuristic_route("Compare Sutter on termination", ["Sutter Health"])
        assert result["route"] != "comparison"

    def test_explanation_keyword(self):
        result = self.router._heuristic_route("Explain the dispute resolution process", [])
        assert result["route"] == "explanation"

    def test_single_provider_when_one_detected(self):
        # Must not trigger explanation/temporal/rate keywords — use neutral phrasing
        result = self.router._heuristic_route("What are Sutter Health contract terms?", ["Sutter Health"])
        assert result["route"] == "single_provider"

    def test_default_is_clause_existence(self):
        result = self.router._heuristic_route("Which providers have offset clause?", [])
        assert result["route"] == "clause_existence"

    def test_is_negative_detected(self):
        result = self.router._heuristic_route("Which providers don't have auto-renewal?", [])
        assert result["is_negative"] is True

    def test_concept_extracted(self):
        result = self.router._heuristic_route("Which providers have an offset clause?", [])
        assert "offset" in result.get("target_concept", "") or "offset" in " ".join(result.get("concepts", []))


# ── Override rules ────────────────────────────────────────────────────────────

class TestOverrideRE1RateSignalRescue:
    """RE-1: clause_existence → rate_query when rate keywords dominate."""

    def setup_method(self):
        self.router = make_router()

    def test_rate_keyword_without_clause_phrase_rescues(self):
        raw = {"route": "clause_existence", "providers": [], "concepts": []}
        result = self.router._apply_overrides(raw, "What is the average inpatient rate?")
        assert result["route"] == "rate_query"

    def test_clause_phrase_prevents_rescue(self):
        raw = {"route": "clause_existence", "providers": [], "concepts": []}
        result = self.router._apply_overrides(raw, "Which providers have a rate schedule clause?")
        assert result["route"] == "clause_existence"

    def test_non_clause_existence_not_affected(self):
        raw = {"route": "explanation", "providers": [], "concepts": []}
        result = self.router._apply_overrides(raw, "What is the average per diem rate?")
        assert result["route"] != "rate_query"


class TestOverrideRE2UnresolvableComparison:
    """RE-2: flag unresolvable comparison intent."""

    def setup_method(self):
        self.router = make_router()

    def test_compare_no_providers_sets_flag(self):
        raw = {"route": "clause_existence", "providers": [], "concepts": []}
        result = self.router._apply_overrides(raw, "How do Kaiser and Sutter compare?")
        assert result.get("_unresolvable_comparison") is True

    def test_compare_with_providers_no_flag(self):
        raw = {"route": "comparison", "providers": ["Sutter Health", "Kaiser"], "concepts": []}
        result = self.router._apply_overrides(raw, "Compare Sutter Health vs Kaiser")
        assert not result.get("_unresolvable_comparison")


class TestOverrideCEFIXConceptRescue:
    """CE-FIX: extract target_concept for clause_existence when LLM omits it."""

    def setup_method(self):
        self.router = make_router()

    def test_offset_clause_extracted(self):
        raw = {"route": "clause_existence", "providers": [], "concepts": [], "target_concept": None}
        result = self.router._apply_overrides(raw, "Which providers have an offset clause?")
        assert result.get("target_concept") is not None
        assert "offset" in result["target_concept"].lower()

    def test_dofr_extracted(self):
        raw = {"route": "clause_existence", "providers": [], "concepts": [], "target_concept": None}
        result = self.router._apply_overrides(raw, "Which providers have DOFR?")
        assert result.get("target_concept") is not None
        assert "dofr" in result["target_concept"].lower()

    def test_concepts_populated_from_target(self):
        raw = {"route": "clause_existence", "providers": [], "concepts": [], "target_concept": None}
        result = self.router._apply_overrides(raw, "Which providers have arbitration?")
        assert result.get("concepts")

    def test_already_set_not_overwritten(self):
        raw = {
            "route": "clause_existence",
            "providers": [],
            "concepts": ["my concept"],
            "target_concept": "my concept",
        }
        result = self.router._apply_overrides(raw, "Which providers have an offset clause?")
        assert result["target_concept"] == "my concept"

    def test_non_ce_route_not_affected(self):
        raw = {"route": "explanation", "providers": [], "concepts": [], "target_concept": None}
        result = self.router._apply_overrides(raw, "Explain the offset clause")
        assert result.get("target_concept") is None


class TestOverrideExtractionSignal:
    """EXTR: clause_existence/explanation → field_extraction on value-seeking questions."""

    def setup_method(self):
        self.router = make_router()

    def test_notice_period_rescues_to_extraction(self):
        raw = {"route": "clause_existence", "providers": [], "concepts": []}
        result = self.router._apply_overrides(raw, "What is the notice period in days?")
        assert result["route"] == "structured_extraction"

    def test_explanation_also_rescues(self):
        raw = {"route": "explanation", "providers": [], "concepts": []}
        result = self.router._apply_overrides(raw, "How many days notice is required?")
        assert result["route"] == "structured_extraction"

    def test_rate_query_not_affected(self):
        raw = {"route": "rate_query", "providers": [], "concepts": []}
        result = self.router._apply_overrides(raw, "What is the notice period in days?")
        assert result["route"] == "rate_query"

    def test_extraction_signal_without_value_word_no_rescue(self):
        raw = {"route": "clause_existence", "providers": [], "concepts": []}
        result = self.router._apply_overrides(raw, "What is the offset clause?")
        # "what is the" is an extraction signal but "offset clause" doesn't contain a value word
        # (no "days", "months", "amount", etc.) — should NOT reroute
        assert result["route"] != "structured_extraction"


class TestOverrideConstraints:
    """CONSTR: comparison needs 2+ providers; single_provider needs ≥1."""

    def setup_method(self):
        self.router = make_router()

    def test_comparison_one_provider_becomes_single_provider(self):
        raw = {"route": "comparison", "providers": ["Sutter Health"], "concepts": []}
        result = self.router._apply_overrides(raw, "Compare Sutter Health")
        assert result["route"] == "single_provider"

    def test_comparison_no_providers_becomes_clause_existence(self):
        raw = {"route": "comparison", "providers": [], "concepts": []}
        result = self.router._apply_overrides(raw, "Compare providers on offset")
        assert result["route"] == "clause_existence"

    def test_single_provider_no_providers_becomes_clause_existence(self):
        raw = {"route": "single_provider", "providers": [], "concepts": []}
        result = self.router._apply_overrides(raw, "Show me contract details")
        assert result["route"] == "clause_existence"

    def test_invalid_route_corrected(self):
        raw = {"route": "nonsense_route", "providers": [], "concepts": []}
        result = self.router._apply_overrides(raw, "Which providers have offset?")
        assert result["route"] in VALID_ROUTES


# ── LLM routing ───────────────────────────────────────────────────────────────

class TestLLMRoute:
    def test_llm_response_used_when_valid(self):
        import json
        llm_resp = json.dumps({
            "route": "explanation",
            "providers": [],
            "concepts": ["dispute resolution"],
            "search_keywords": ["dispute"],
            "semantic_query": "Explain dispute resolution",
            "is_negative": False,
            "target_concept": "dispute resolution",
            "analysis_type": "explanation",
            "scope_filter": None,
        })
        r = make_router(llm_response=llm_resp)
        decision = r.route("Explain dispute resolution")
        assert decision.confidence == "llm"
        assert decision.route == "explanation"

    def test_llm_parse_failure_falls_back_to_heuristic(self):
        r = make_router(llm_response="not valid json at all")
        decision = r.route("Explain dispute resolution")
        # Should not raise — falls back to heuristic
        assert decision.route in VALID_ROUTES

    def test_no_llm_uses_heuristic(self):
        r = make_router()  # no llm
        decision = r.route("Which providers have offset clause?")
        assert decision.confidence == "heuristic"

    def test_llm_called_with_question(self):
        import json
        llm_resp = json.dumps({
            "route": "temporal", "providers": [], "concepts": [],
            "search_keywords": [], "semantic_query": "q",
            "is_negative": False, "target_concept": None,
            "analysis_type": "temporal", "scope_filter": None,
        })
        llm = MockLLMClient(response=llm_resp)
        r = QuestionRouter(provider_service=MockProviderService(), llm_client=llm)
        r.route("What changed in Sutter's 2024 amendment?")
        assert len(llm.calls) == 1


# ── Full route() method ───────────────────────────────────────────────────────

class TestFullRoute:
    def test_clause_existence_with_concept(self):
        r = make_router()
        d = r.route("Which providers have an offset clause?")
        assert d.route == "clause_existence"
        assert d.tool_name == "clause_existence"
        assert d.target_concept is not None

    def test_rate_query_question(self):
        r = make_router()
        d = r.route("What is the average inpatient per diem rate?")
        assert d.route == "rate_query"
        assert d.tool_name == "rate_query"

    def test_temporal_question(self):
        r = make_router()
        d = r.route("What changed in the 2024 amendment?")
        assert d.route == "temporal"
        assert d.tool_name == "temporal_analysis"

    def test_explanation_question(self):
        r = make_router()
        d = r.route("Explain the dispute resolution process")
        assert d.route == "explanation"
        assert d.tool_name == "explanation"

    def test_two_providers_comparison(self):
        r = make_router()
        d = r.route("Compare Sutter Health vs Kaiser Permanente on termination")
        assert d.route == "comparison"
        assert len(d.providers) >= 2

    def test_decision_is_routing_decision_instance(self):
        r = make_router()
        d = r.route("Which providers have offset clause?")
        assert isinstance(d, RoutingDecision)

    def test_tool_name_always_valid(self):
        r = make_router()
        questions = [
            "Which providers have offset?",
            "Compare Sutter vs Kaiser",
            "What is the per diem rate?",
            "Explain dispute resolution",
            "What changed in 2024?",
            "Show me Sutter Health details",
        ]
        for q in questions:
            d = r.route(q)
            assert d.tool_name in set(ROUTE_TO_TOOL.values()), f"Invalid tool for: {q}"
