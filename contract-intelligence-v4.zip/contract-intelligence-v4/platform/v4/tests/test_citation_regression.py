"""
P3-REG-2: V3 Citation Verification Regression Tests

Tests CitationVerifier against:
  - 30 known-good citations  (grounded, current)  → should all PASS
  - 10 known-bad citations   (ungrounded or wrong numbers) → should all FAIL
  - F1 score gate: precision >= 0.90, recall (bad detection) >= 0.80, F1 >= 0.85

Key verifier behaviour (CheckStatus):
  - supersession → WARN if non-current  (never FAIL; verdict.passed still True)
  - grounding    → FAIL if overlap < threshold or passage < 20 chars
  - numerical    → FAIL if strict_numerical=True and numbers mismatch
  - temporal     → WARN only

All tests run without Spark. No live dependencies.

Run:
    pytest platform/v4/tests/test_citation_regression.py -v
"""
from __future__ import annotations

import sys as _sys
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

import pytest

_BASE = str(Path(__file__).resolve().parents[4])
if _BASE not in sys.path:
    sys.path.insert(0, _BASE)

# Fix stdlib 'platform' collision (mirrors Cell 24 / existing test approach)
import types as _types_ns
if "platform.v4" not in sys.modules:
    _v3_pkg = _types_ns.ModuleType("platform.v4")
    _v3_pkg.__path__ = [f"{_BASE}/platform/v3"]  # type: ignore[assignment]
    _v3_pkg.__package__ = "platform.v4"
    _v3_pkg.__spec__ = None
    sys.modules["platform.v4"] = _v3_pkg
    sys.modules["platform"].v3 = _v3_pkg  # type: ignore[attr-defined]


from platform.v4.services.verification.citation_verifier import (
    CitationVerdict,
    CitationVerifier,
    CheckStatus,
    VerificationResult,
)


# ---------------------------------------------------------------------------
# Minimal citation-like dataclass (mirrors CitationAdapter output)
# ---------------------------------------------------------------------------

@dataclass
class _Cite:
    passage_text:          str
    source_filename:       str  = "contract.pdf"
    is_current_effective:  bool = True
    doc_role:              str  = "current"
    effective_date:        str  = "2023-01-01"


def _c(d: Dict) -> _Cite:
    return _Cite(
        passage_text         = d["passage"],
        source_filename      = d.get("filename", "contract.pdf"),
        is_current_effective = d.get("current", True),
        doc_role             = "current" if d.get("current", True) else "historical",
    )


# ---------------------------------------------------------------------------
# 30 known-good fixtures — grounded + current → PASS
# ---------------------------------------------------------------------------

KNOWN_GOOD: List[Dict] = [
    # --- Offset clause citations ---
    {"claim": "Provider is subject to an offset clause",
     "passage": "Provider agrees to the offset clause as defined in Section 3.2 of this agreement.",
     "current": True, "filename": "Sutter_BaseAgreement_2023.pdf"},
    {"claim": "Provider shall allow offset of amounts owed",
     "passage": "Provider shall allow offset of amounts owed to BSC against any payments due to Provider.",
     "current": True, "filename": "BSC_Offset_2022.pdf"},
    {"claim": "Cedars-Sinai has a conditional offset restriction",
     "passage": "Cedars-Sinai Medical Center has a conditional offset restriction applied to capitation payments.",
     "current": True, "filename": "Cedars_2023.pdf"},
    {"claim": "The contract includes a payment offset provision",
     "passage": "This contract includes a payment offset provision that allows BSC to deduct outstanding balances.",
     "current": True, "filename": "Generic_2023.pdf"},
    {"claim": "Offset deductions are capped at a monthly percentage",
     "passage": "Offset deductions shall not exceed the monthly capitation payment cap as stated in the agreement.",
     "current": True, "filename": "Rate_2023.pdf"},
    # --- Numeric match citations ---
    {"claim": "The capitation rate is $350 per member per month",
     "passage": "The capitation rate is set at $350 per member per month effective January 2023.",
     "current": True, "filename": "Capitation_2023.pdf"},
    {"claim": "Provider receives a 5% annual rate increase",
     "passage": "Provider shall receive a 5% annual rate increase commencing on the anniversary date.",
     "current": True, "filename": "Rate_Schedule_2023.pdf"},
    {"claim": "Agreement terminates with 90 days written notice",
     "passage": "Either party may terminate this agreement by providing 90 days written notice to the other party.",
     "current": True, "filename": "Termination_2023.pdf"},
    {"claim": "DOFR allocation splits financial responsibility between BSC and Provider",
     "passage": "Division of Financial Responsibility allocates covered services between BSC and the contracted Provider.",
     "current": True, "filename": "DOFR_2023.pdf"},
    {"claim": "The settlement resolves all outstanding claims",
     "passage": "The parties agree to a settlement to resolve all outstanding claims and disputes under this agreement.",
     "current": True, "filename": "Settlement_2023.pdf"},
    # --- Temporal citations ---
    {"claim": "The agreement is effective January 1, 2023",
     "passage": "This agreement is effective as of January 1, 2023 and supersedes all prior agreements.",
     "current": True, "filename": "BaseAgreement_2023.pdf"},
    {"claim": "Amendment effective March 15, 2023",
     "passage": "This Amendment No. 5 is effective March 15, 2023 and modifies Section 4 of the base agreement.",
     "current": True, "filename": "Amendment_5_2023.pdf"},
    # --- DOFR citations ---
    {"claim": "BSC assumes financial responsibility for specialist referrals",
     "passage": "BSC shall assume financial responsibility for all specialist referrals under the DOFR provisions.",
     "current": True, "filename": "DOFR_Specialist_2023.pdf"},
    {"claim": "Provider is responsible for inpatient facility costs",
     "passage": "Provider shall be responsible for inpatient facility costs as specified in the DOFR schedule.",
     "current": True, "filename": "DOFR_Schedule_2022.pdf"},
    {"claim": "The DOFR requires mutual consent for amendments",
     "passage": "Any modification to the Division of Financial Responsibility requires written mutual consent.",
     "current": True, "filename": "DOFR_Consent_2022.pdf"},
    # --- Rate / incentive citations ---
    {"claim": "IPA delegation applies to contracted providers",
     "passage": "IPA delegation requirements apply to all contracted providers within the service area.",
     "current": True, "filename": "IPA_2023.pdf"},
    {"claim": "Steerage bonus is a percentage of annual capitation",
     "passage": "Provider may earn a steerage bonus based on a percentage of annual capitation for achieving network targets.",
     "current": True, "filename": "Incentive_2023.pdf"},
    {"claim": "Quality bonus payment is per member per year",
     "passage": "Quality bonus payment is payable per member per year upon achieving HEDIS benchmarks.",
     "current": True, "filename": "Quality_2023.pdf"},
    {"claim": "Risk corridor applies above target medical expense",
     "passage": "Risk corridor provisions apply when total medical costs exceed the target medical expense threshold.",
     "current": True, "filename": "Risk_2023.pdf"},
    {"claim": "Provider must maintain minimum primary care physician ratio",
     "passage": "Provider shall maintain a minimum ratio of primary care physicians per enrolled members.",
     "current": True, "filename": "Network_2023.pdf"},
    # --- Termination / amendment citations ---
    {"claim": "Termination for cause requires advance written notice",
     "passage": "Termination for cause may be effected upon advance written notice following notice of the breach.",
     "current": True, "filename": "Termination_Cause_2023.pdf"},
    {"claim": "Amendment increases contracted rates",
     "passage": "This Amendment to the Base Agreement increases all contracted rates effective July 2022.",
     "current": True, "filename": "Amendment_3_2022.pdf"},
    {"claim": "Contract renews automatically unless cancelled",
     "passage": "This agreement shall renew automatically for successive one-year terms unless cancelled by either party.",
     "current": True, "filename": "Renewal_2023.pdf"},
    # --- Miscellaneous ---
    {"claim": "BSC may audit provider records",
     "passage": "Blue Shield of California may conduct an audit of provider financial and medical records.",
     "current": True, "filename": "Audit_2023.pdf"},
    {"claim": "Provider agrees to participate in quality improvement programs",
     "passage": "Provider agrees to actively participate in BSC quality improvement programs and report metrics.",
     "current": True, "filename": "Quality_Program_2023.pdf"},
    {"claim": "Network adequacy requires continuous coverage",
     "passage": "Network adequacy standards require providers to ensure continuous access to covered services.",
     "current": True, "filename": "Network_Standards_2022.pdf"},
    {"claim": "Claims must be submitted within a specified number of days",
     "passage": "All claims must be submitted within the specified number of days of the date of service.",
     "current": True, "filename": "Claims_Policy_2023.pdf"},
    {"claim": "Provider assigns capitation risk for specified service categories",
     "passage": "Provider hereby assigns capitation risk to BSC for the service categories specified in Exhibit B.",
     "current": True, "filename": "Risk_Assignment_2023.pdf"},
    {"claim": "BSC shall provide advance notice of fee schedule changes",
     "passage": "BSC shall provide no less than 60 days advance written notice prior to any changes to the fee schedule.",
     "current": True, "filename": "Fee_Schedule_2023.pdf"},
    {"claim": "Dispute resolution requires binding arbitration",
     "passage": "Any dispute arising under this agreement shall be resolved by binding arbitration.",
     "current": True, "filename": "Dispute_2023.pdf"},
]

# ---------------------------------------------------------------------------
# 10 known-bad fixtures — grounding or numerical failures → FAIL
# (supersession alone is WARN, not FAIL; these combine with real failures)
# ---------------------------------------------------------------------------

KNOWN_BAD: List[Dict] = [
    # --- Grounding failures (passage text unrelated to claim) ---
    {"claim": "Capitation rate is $500 per member per month",
     "passage": "This document discusses general network adequacy and provider credentialing requirements.",
     "current": True, "filename": "Credentialing_2023.pdf",
     "expected_failure": "grounding"},
    {"claim": "Provider has a 5% withholding arrangement for risk",
     "passage": "This amendment establishes credentialing standards for specialist physicians.",
     "current": True, "filename": "Credentialing_Amendment_2023.pdf",
     "expected_failure": "grounding"},
    {"claim": "IPA delegation requires prior authorization for all referrals",
     "passage": "This section covers billing codes and reimbursement methodologies for ancillary services.",
     "current": True, "filename": "Billing_Guide_2023.pdf",
     "expected_failure": "grounding"},
    {"claim": "The offset clause requires monthly reconciliation process",
     "passage": "Provider compliance with state licensing requirements is outlined in Appendix D.",
     "current": True, "filename": "Compliance_2023.pdf",
     "expected_failure": "grounding"},
    {"claim": "DOFR split allocates specialist costs to BSC",
     "passage": "Member grievance and appeal procedures are described in the Member Rights section.",
     "current": True, "filename": "Member_Rights_2023.pdf",
     "expected_failure": "grounding"},
    # --- Empty passage (trivially short — fails grounding) ---
    {"claim": "The offset clause requires monthly reconciliation",
     "passage": "",
     "current": True, "filename": "Empty_Doc.pdf",
     "expected_failure": "grounding"},
    # --- Numerical failures (strict_numerical=True) ---
    {"claim": "Termination notice period is 30 days",
     "passage": "Either party may terminate this agreement with 90 days written notice to the other party.",
     "current": True, "filename": "Termination_Notice_2023.pdf",
     "expected_failure": "numerical"},
    {"claim": "BSC retains 25% of capitation risk",
     "passage": "BSC assumes financial responsibility, retaining only 10% of the capitation risk pool.",
     "current": True, "filename": "Risk_Retention_2022.pdf",
     "expected_failure": "numerical"},
    {"claim": "Provider receives 12% quality bonus",
     "passage": "Provider quality bonus is capped at 3% of total annual capitation payments.",
     "current": True, "filename": "Quality_Bonus_2023.pdf",
     "expected_failure": "numerical"},
    {"claim": "Rate increase is 15% effective next year",
     "passage": "The contracted rate increase shall be 2.5% for the upcoming contract year.",
     "current": True, "filename": "Rate_Increase_2023.pdf",
     "expected_failure": "numerical"},
]


# ===========================================================================
# TestCitationVerifierKnownGood
# ===========================================================================

class TestCitationVerifierKnownGood:
    """All 30 known-good citations pass CitationVerifier."""

    @pytest.fixture
    def verifier(self) -> CitationVerifier:
        # Lenient threshold for unit tests (real corpus may have loose phrasing)
        return CitationVerifier(grounding_threshold=0.15, strict_numerical=False)

    @pytest.mark.parametrize("idx,fixture", list(enumerate(KNOWN_GOOD)))
    def test_known_good_passes(self, verifier: CitationVerifier, idx: int, fixture: Dict):
        """Each known-good citation must pass verification."""
        citation = _c(fixture)
        result   = verifier.verify(fixture["claim"], [citation])
        assert len(result.verdicts) == 1
        verdict = result.verdicts[0]
        assert verdict.passed, (
            f"Known-good #{idx} unexpectedly FAILED:\n"
            f"  Claim:   {fixture['claim']}\n"
            f"  Passage: {fixture['passage'][:100]}\n"
            f"  Failures: {verdict.failure_details}"
        )

    def test_bulk_pass_rate_at_least_90pct(self, verifier: CitationVerifier):
        """>=90% of known-good citations pass (bulk gate)."""
        failures: List[str] = []
        for i, f in enumerate(KNOWN_GOOD):
            result = verifier.verify(f["claim"], [_c(f)])
            if not result.verdicts[0].passed:
                failures.append(f"  #{i}: {f['claim'][:60]}")
        pass_rate = (len(KNOWN_GOOD) - len(failures)) / len(KNOWN_GOOD)
        assert pass_rate >= 0.90, (
            f"Known-good pass rate {pass_rate:.1%} < 90%\nFailing:\n"
            + "\n".join(failures[:5])
        )

    def test_current_docs_have_no_supersession_warn(self, verifier: CitationVerifier):
        """Current documents produce no supersession warning."""
        current_fixtures = [f for f in KNOWN_GOOD if f["current"]]
        for f in current_fixtures:
            result  = verifier.verify(f["claim"], [_c(f)])
            verdict = result.verdicts[0]
            supers  = [
                c for c in verdict.checks
                if c.check_name == "supersession" and c.status == CheckStatus.WARN
            ]
            assert not supers, (
                f"Current doc got supersession WARN: {f['filename']}"
            )

    def test_verifier_result_has_verdicts_list(self, verifier: CitationVerifier):
        f = KNOWN_GOOD[0]
        result = verifier.verify(f["claim"], [_c(f)])
        assert isinstance(result, VerificationResult)
        assert isinstance(result.verdicts, list)
        assert len(result.verdicts) == 1

    def test_verdict_has_check_results(self, verifier: CitationVerifier):
        f = KNOWN_GOOD[0]
        result  = verifier.verify(f["claim"], [_c(f)])
        verdict = result.verdicts[0]
        assert isinstance(verdict, CitationVerdict)
        assert isinstance(verdict.checks, list)
        assert len(verdict.checks) > 0


# ===========================================================================
# TestCitationVerifierKnownBad
# ===========================================================================

class TestCitationVerifierKnownBad:
    """All 10 known-bad citations fail CitationVerifier."""

    @pytest.fixture
    def verifier(self) -> CitationVerifier:
        # strict_numerical=True so numeric mismatches produce FAIL
        return CitationVerifier(grounding_threshold=0.15, strict_numerical=True)

    @pytest.mark.parametrize("idx,fixture", list(enumerate(KNOWN_BAD)))
    def test_known_bad_fails(self, verifier: CitationVerifier, idx: int, fixture: Dict):
        """Each known-bad citation must fail verification."""
        citation = _c(fixture)
        result   = verifier.verify(fixture["claim"], [citation])
        assert len(result.verdicts) == 1
        verdict = result.verdicts[0]
        assert not verdict.passed, (
            f"Known-bad #{idx} ({fixture['expected_failure']}) unexpectedly PASSED:\n"
            f"  Claim:   {fixture['claim']}\n"
            f"  Passage: {fixture['passage'][:100]}"
        )

    def test_bulk_detection_rate_at_least_80pct(self, verifier: CitationVerifier):
        """>=80% of known-bad citations are correctly flagged (bulk gate)."""
        missed: List[str] = []
        for i, f in enumerate(KNOWN_BAD):
            result = verifier.verify(f["claim"], [_c(f)])
            if result.verdicts[0].passed:
                missed.append(
                    f"  #{i} ({f['expected_failure']}): {f['claim'][:60]}"
                )
        detection_rate = (len(KNOWN_BAD) - len(missed)) / len(KNOWN_BAD)
        assert detection_rate >= 0.80, (
            f"Known-bad detection {detection_rate:.1%} < 80%\nMissed:\n"
            + "\n".join(missed)
        )

    def test_empty_passage_fails_grounding(self, verifier: CitationVerifier):
        """Empty passage always fails grounding check."""
        empty_fixture = next(f for f in KNOWN_BAD if f["passage"] == "")
        result  = verifier.verify(empty_fixture["claim"], [_c(empty_fixture)])
        verdict = result.verdicts[0]
        assert not verdict.passed, "Empty passage should fail grounding"
        grounding_fails = [
            c for c in verdict.checks
            if c.check_name == "grounding" and c.status == CheckStatus.FAIL
        ]
        assert grounding_fails, "Expected explicit grounding FAIL for empty passage"

    def test_numerical_failures_have_numerical_check_fail(self, verifier: CitationVerifier):
        """Numerical-failure fixtures have a FAIL on the numerical check."""
        num_fixtures = [f for f in KNOWN_BAD if f["expected_failure"] == "numerical"]
        for f in num_fixtures:
            result  = verifier.verify(f["claim"], [_c(f)])
            verdict = result.verdicts[0]
            num_fail = [
                c for c in verdict.checks
                if c.check_name == "numerical" and c.status == CheckStatus.FAIL
            ]
            assert num_fail, (
                f"Numerical fixture did not produce numerical FAIL:\n"
                f"  Claim:   {f['claim']}\n"
                f"  Passage: {f['passage'][:80]}\n"
                f"  Checks:  {[(c.check_name, c.status.value) for c in verdict.checks]}"
            )

    def test_grounding_failures_have_grounding_check_fail(self, verifier: CitationVerifier):
        """Grounding-failure fixtures have a FAIL on the grounding check."""
        grd_fixtures = [f for f in KNOWN_BAD if f["expected_failure"] == "grounding"]
        for f in grd_fixtures:
            result  = verifier.verify(f["claim"], [_c(f)])
            verdict = result.verdicts[0]
            grd_fail = [
                c for c in verdict.checks
                if c.check_name == "grounding" and c.status == CheckStatus.FAIL
            ]
            assert grd_fail, (
                f"Grounding fixture did not produce grounding FAIL:\n"
                f"  Claim:   {f['claim']}\n"
                f"  Passage: {f['passage'][:80]}"
            )


# ===========================================================================
# TestCitationSupersessionWarn — non-current docs produce WARN
# ===========================================================================

class TestCitationSupersessionWarn:
    """Supersession check emits WARN (not FAIL) for non-current documents."""

    @pytest.fixture
    def verifier(self) -> CitationVerifier:
        return CitationVerifier(grounding_threshold=0.15, strict_numerical=False)

    def test_non_current_document_produces_warn(self, verifier: CitationVerifier):
        """A grounded citation from a non-current document produces has_warnings=True."""
        citation = _Cite(
            passage_text         = "The offset clause applies to all contracted providers.",
            source_filename      = "Sutter_2019_SUPERSEDED.pdf",
            is_current_effective = False,
            doc_role             = "historical",
        )
        result  = verifier.verify("Provider has an offset clause", [citation])
        verdict = result.verdicts[0]
        # Grounded + non-current: should PASS (WARN only, not FAIL)
        assert verdict.passed, (
            "Grounded non-current citation should pass (supersession is WARN only)"
        )
        assert verdict.has_warnings, (
            "Non-current citation should produce has_warnings=True"
        )

    def test_non_current_has_supersession_warn(self, verifier: CitationVerifier):
        citation = _Cite(
            passage_text         = "Offset provisions under this agreement apply.",
            is_current_effective = False,
            doc_role             = "historical",
        )
        result  = verifier.verify("Provider has offset provisions", [citation])
        verdict = result.verdicts[0]
        supers_warn = [
            c for c in verdict.checks
            if c.check_name == "supersession" and c.status == CheckStatus.WARN
        ]
        assert supers_warn, "Non-current document should produce supersession WARN"

    def test_current_document_no_supersession_warn(self, verifier: CitationVerifier):
        citation = _Cite(
            passage_text         = "Offset clause applies.",
            is_current_effective = True,
            doc_role             = "current",
        )
        result  = verifier.verify("offset clause", [citation])
        verdict = result.verdicts[0]
        supers_warn = [
            c for c in verdict.checks
            if c.check_name == "supersession" and c.status == CheckStatus.WARN
        ]
        assert not supers_warn, "Current document should not produce supersession WARN"


# ===========================================================================
# TestCitationF1Parity — F1 aggregate gate (P3-REG-2 core criterion)
# ===========================================================================

class TestCitationF1Parity:
    """
    F1 >= 0.85 on 30 GOOD + 10 BAD classification.
    Precision (good-pass rate) >= 0.90.
    Recall (bad-detection rate) >= 0.80.
    """

    @pytest.fixture
    def verifier(self) -> CitationVerifier:
        return CitationVerifier(grounding_threshold=0.15, strict_numerical=True)

    def _classify(self, verifier: CitationVerifier, fixtures: List[Dict]) -> List[bool]:
        return [
            verifier.verify(f["claim"], [_c(f)]).verdicts[0].passed
            for f in fixtures
        ]

    def test_precision_good_citations(self, verifier: CitationVerifier):
        """Precision (GOOD correctly passed): >=90%."""
        results    = self._classify(verifier, KNOWN_GOOD)
        pass_count = sum(results)
        precision  = pass_count / len(KNOWN_GOOD)
        assert precision >= 0.90, (
            f"Precision {precision:.1%} < 90%  ({pass_count}/{len(KNOWN_GOOD)} GOOD passed)"
        )

    def test_recall_bad_citations(self, verifier: CitationVerifier):
        """Recall (BAD correctly flagged): >=80%."""
        results     = self._classify(verifier, KNOWN_BAD)
        fail_count  = sum(1 for r in results if not r)
        recall      = fail_count / len(KNOWN_BAD)
        assert recall >= 0.80, (
            f"Bad-detection recall {recall:.1%} < 80%  ({fail_count}/{len(KNOWN_BAD)} BAD flagged)"
        )

    def test_f1_parity_gate(self, verifier: CitationVerifier):
        """
        P3-REG-2 gate: F1 >= 0.85.
        tp = GOOD correctly passed; fp = BAD incorrectly passed;
        fn = GOOD incorrectly failed; tn = BAD correctly flagged.
        """
        tp = sum(1 for f in KNOWN_GOOD if verifier.verify(f["claim"], [_c(f)]).verdicts[0].passed)
        fp = sum(1 for f in KNOWN_BAD  if verifier.verify(f["claim"], [_c(f)]).verdicts[0].passed)
        fn = len(KNOWN_GOOD) - tp
        tn = len(KNOWN_BAD)  - fp

        precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
        recall    = tp / (tp + fn) if (tp + fn) > 0 else 0.0
        f1        = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0.0

        assert f1 >= 0.85, (
            f"P3-REG-2 F1 FAIL: {f1:.3f} < 0.85\n"
            f"  TP={tp}, FP={fp}, TN={tn}, FN={fn}\n"
            f"  Precision={precision:.3f}, Recall={recall:.3f}"
        )


# ===========================================================================
# TestCitationEdgeCases
# ===========================================================================

class TestCitationEdgeCases:
    """Edge cases: empty lists, short claims, multiple citations, unicode."""

    @pytest.fixture
    def verifier(self) -> CitationVerifier:
        return CitationVerifier()

    def test_empty_citations_list(self, verifier: CitationVerifier):
        result = verifier.verify("Some claim text", [])
        assert isinstance(result, VerificationResult)
        assert result.verdicts == []

    def test_single_citation(self, verifier: CitationVerifier):
        c = _Cite("The offset clause applies to monthly payment adjustments.")
        result = verifier.verify("Provider has an offset clause", [c])
        assert len(result.verdicts) == 1

    def test_multiple_citations(self, verifier: CitationVerifier):
        citations = [
            _Cite("First passage about offset clause"),
            _Cite("Second passage about rate adjustments"),
        ]
        result = verifier.verify("offset clause rate adjustment", citations)
        assert len(result.verdicts) == 2

    def test_unicode_no_crash(self, verifier: CitationVerifier):
        c = _Cite("Provider agrees to the \u201coffset\u201d provision \u2014 $350 per member.")
        result = verifier.verify("Provider has an offset provision of $350", [c])
        assert result is not None

    def test_very_long_passage_no_crash(self, verifier: CitationVerifier):
        c = _Cite("offset clause payment deduction " * 300)
        result = verifier.verify("offset clause", [c])
        assert result is not None

    def test_short_claim_returns_skip_or_pass(self, verifier: CitationVerifier):
        """Claim < 10 chars skips grounding check (returns SKIP, not FAIL)."""
        c = _Cite("Provider has an offset clause for payment deductions.")
        result = verifier.verify("ok", [c])
        assert result is not None
        # Should not raise; verdict may be PASS or have SKIP checks

    def test_n_citations_property(self, verifier: CitationVerifier):
        citations = [_Cite("passage one"), _Cite("passage two"), _Cite("passage three")]
        result = verifier.verify("passage content claim", citations)
        assert result.n_citations == 3

    def test_n_passed_property(self, verifier: CitationVerifier):
        good = _Cite("The offset clause applies to all contracted providers.")
        result = verifier.verify("offset clause providers", [good])
        assert result.n_passed >= 0
        assert result.n_passed <= result.n_citations
