"""
Tests for TemporalAnalysisTool (P4B-TEMP-1).
Validates amendment retrieval, registry, version tracking,
concept evolution, LLM summarization, and golden regression queries.
"""
import pytest
import pandas as pd
from collections import OrderedDict

import sys, types
_V3_BASE = "/Workspace/Users/adixit01@blueshieldca.com/Contract_Codification_Pipeline"
if _V3_BASE not in sys.path:
    sys.path.insert(0, _V3_BASE)
if "platform.v4" not in sys.modules:
    _pkg = types.ModuleType("platform.v4")
    _pkg.__path__ = [f"{_V3_BASE}/platform/v3"]
    _pkg.__package__ = "platform.v4"
    sys.modules["platform.v4"] = _pkg

from platform.v4.tools.temporal_analysis import TemporalAnalysisTool, TemporalResult
from platform.v4.contracts.tool_types import ToolStatus, Confidence


# ─── Mock Infrastructure ─────────────────────────────────────────────────────

class MockSparkResult:
    def __init__(self, pdf: pd.DataFrame):
        self._pdf = pdf

    def toPandas(self):
        return self._pdf.copy()


class MockSparkSession:
    """Mock Spark that returns DataFrames based on substring matching."""

    def __init__(self, responses: dict = None):
        self._responses = OrderedDict(responses or {})

    def sql(self, query: str) -> MockSparkResult:
        q_lower = query.lower()
        for key, df in self._responses.items():
            if key.lower() in q_lower:
                return MockSparkResult(df)
        return MockSparkResult(pd.DataFrame())


class MockProviderService:
    def __init__(self, resolved=None, method="canonical_exact", provider_ids=None):
        self._resolved = resolved or ["Test Hospital"]
        self._method = method
        self._ids = provider_ids or ["P001", "P002"]
        self._names = ["Test Hospital", "Community Medical Center", "Kaiser Permanente"]

    def resolve(self, name):
        return self._resolved, self._method, self._ids

    def all_names(self):
        return self._names


class MockLLMClient:
    def __init__(self, response="LLM summary of changes"):
        self._response = response
        self.calls = []

    def chat(self, model, system, user, max_tokens):
        self.calls.append({"model": model, "system": system, "user": user})
        return self._response


# ─── Helper DataFrames ───────────────────────────────────────────────────────

def _make_amendments_df():
    return pd.DataFrame([
        {"provider_name": "Test Hospital", "document_type": "Base Agreement",
         "summary_of_changes": "Initial contract established with standard terms",
         "amendment_order": 0, "source_filename": "test_v1.pdf"},
        {"provider_name": "Test Hospital", "document_type": "Amendment",
         "summary_of_changes": "Rate increase 5% across all categories",
         "amendment_order": 1, "source_filename": "test_v2.pdf"},
        {"provider_name": "Test Hospital", "document_type": "Amendment",
         "summary_of_changes": "Added telehealth services and updated termination notice to 90 days",
         "amendment_order": 2, "source_filename": "test_v3.pdf"},
        {"provider_name": "Test Hospital", "document_type": "Amendment",
         "summary_of_changes": "Revised capitation rates for age bands 0-17",
         "amendment_order": 3, "source_filename": "test_v4.pdf"},
    ])


def _make_registry_df():
    return pd.DataFrame([
        {"provider_name": "Test Hospital", "contract_id": "C-001",
         "status": "ACTIVE", "effective_date": "2022-01-01",
         "termination_date": None, "source_filename": "test_v1.pdf"},
        {"provider_name": "Test Hospital", "contract_id": "C-002",
         "status": "SUPERSEDED", "effective_date": "2020-01-01",
         "termination_date": "2021-12-31", "source_filename": "old_v1.pdf"},
    ])


def _make_versions_df():
    return pd.DataFrame([
        {"provider_name": "Test Hospital", "source_filename": "test_v4.pdf",
         "doc_role": "Amendment", "effective_date": "2024-06-01"},
        {"provider_name": "Test Hospital", "source_filename": "test_v3.pdf",
         "doc_role": "Amendment", "effective_date": "2024-01-01"},
        {"provider_name": "Test Hospital", "source_filename": "test_v2.pdf",
         "doc_role": "Amendment", "effective_date": "2023-07-01"},
        {"provider_name": "Test Hospital", "source_filename": "test_v1.pdf",
         "doc_role": "Base Agreement", "effective_date": "2022-01-01"},
    ])


def _make_evolution_df():
    return pd.DataFrame([
        {"source_filename": "test_v1.pdf", "chunk_text": "Offset clause: standard 30 day offset period applies", "page_number": 5},
        {"source_filename": "test_v1.pdf", "chunk_text": "The offset provision shall apply to all claims", "page_number": 6},
        {"source_filename": "test_v3.pdf", "chunk_text": "Revised offset clause: 60 day offset period effective immediately", "page_number": 8},
    ])


# ─── Test Classes ────────────────────────────────────────────────────────────

class TestProviderResolution:
    """Test provider resolution in temporal context."""

    def test_resolves_explicit_provider(self):
        spark = MockSparkSession({"tbl_genie_amendment_timeline": _make_amendments_df()})
        tool = TemporalAnalysisTool(spark, MockProviderService())
        result = tool(question="test", provider_name="Test Hospital")
        assert result.success
        assert result.data["provider_name"] == "Test Hospital"

    def test_extracts_provider_from_question(self):
        spark = MockSparkSession({"tbl_genie_amendment_timeline": _make_amendments_df()})
        tool = TemporalAnalysisTool(spark, MockProviderService())
        result = tool(question="Show amendment history for Kaiser Permanente")
        assert result.success
        assert result.data["provider_name"] == "Test Hospital"

    def test_works_without_provider(self):
        """Temporal tool should work without a provider (show all)."""
        spark = MockSparkSession({"tbl_genie_amendment_timeline": _make_amendments_df()})
        tool = TemporalAnalysisTool(spark, MockProviderService())
        result = tool(question="Show all recent amendments")
        # No provider match in question, should still succeed with LIKE fallback
        assert result.success or result.status == ToolStatus.EMPTY


class TestAmendments:
    """Test amendment timeline fetching."""

    def test_fetches_amendments(self):
        spark = MockSparkSession({"tbl_genie_amendment_timeline": _make_amendments_df()})
        tool = TemporalAnalysisTool(spark, MockProviderService())
        result = tool(question="test", provider_name="Test Hospital")
        assert len(result.data["amendments"]) == 4
        assert result.data["amendments"][0]["amendment_order"] == 0
        assert result.data["amendments"][3]["amendment_order"] == 3

    def test_amendments_ordered(self):
        spark = MockSparkSession({"tbl_genie_amendment_timeline": _make_amendments_df()})
        tool = TemporalAnalysisTool(spark, MockProviderService())
        result = tool(question="test", provider_name="Test Hospital")
        orders = [a["amendment_order"] for a in result.data["amendments"]]
        assert orders == sorted(orders)

    def test_empty_amendments_returns_empty_status(self):
        spark = MockSparkSession({})
        tool = TemporalAnalysisTool(spark, MockProviderService())
        result = tool(question="test", provider_name="Test Hospital")
        assert result.status == ToolStatus.EMPTY


class TestRegistry:
    """Test contract registry fetching."""

    def test_fetches_registry(self):
        spark = MockSparkSession({
            "tbl_genie_amendment_timeline": _make_amendments_df(),
            "tbl_v2_contract_registry": _make_registry_df(),
        })
        tool = TemporalAnalysisTool(spark, MockProviderService())
        result = tool(question="test", provider_name="Test Hospital")
        assert len(result.data["registry"]) == 2
        assert result.data["active_contracts"] == 1

    def test_active_contracts_count(self):
        spark = MockSparkSession({
            "tbl_genie_amendment_timeline": _make_amendments_df(),
            "tbl_v2_contract_registry": _make_registry_df(),
        })
        tool = TemporalAnalysisTool(spark, MockProviderService())
        result = tool(question="test", provider_name="Test Hospital")
        assert result.data["active_contracts"] == 1


class TestVersions:
    """Test document version tracking."""

    def test_fetches_versions(self):
        spark = MockSparkSession({
            "tbl_genie_amendment_timeline": _make_amendments_df(),
            "tbl_contract_documents_master": _make_versions_df(),
        })
        tool = TemporalAnalysisTool(spark, MockProviderService())
        result = tool(question="test", provider_name="Test Hospital")
        assert len(result.data["versions"]) == 4

    def test_versions_include_doc_role(self):
        spark = MockSparkSession({
            "tbl_genie_amendment_timeline": _make_amendments_df(),
            "tbl_contract_documents_master": _make_versions_df(),
        })
        tool = TemporalAnalysisTool(spark, MockProviderService())
        result = tool(question="test", provider_name="Test Hospital")
        roles = [v["doc_role"] for v in result.data["versions"]]
        assert "Base Agreement" in roles
        assert "Amendment" in roles


class TestConceptEvolution:
    """Test concept tracking across versions."""

    def test_tracks_concept_across_versions(self):
        spark = MockSparkSession({
            "tbl_genie_amendment_timeline": _make_amendments_df(),
            "tbl_vs_unified_ready": _make_evolution_df(),
        })
        tool = TemporalAnalysisTool(spark, MockProviderService())
        result = tool(question="test", provider_name="Test Hospital", concept="offset clause")
        evo = result.data["concept_evolution"]
        assert len(evo) == 2  # 2 distinct filenames
        assert evo[0]["filename"] == "test_v1.pdf"
        assert evo[0]["passage_count"] == 2
        assert evo[1]["filename"] == "test_v3.pdf"
        assert evo[1]["passage_count"] == 1

    def test_concept_evolution_sorted_by_version(self):
        spark = MockSparkSession({
            "tbl_genie_amendment_timeline": _make_amendments_df(),
            "tbl_vs_unified_ready": _make_evolution_df(),
        })
        tool = TemporalAnalysisTool(spark, MockProviderService())
        result = tool(question="test", provider_name="Test Hospital", concept="offset")
        evo = result.data["concept_evolution"]
        versions = [e["version"] for e in evo]
        assert versions == sorted(versions)

    def test_no_concept_means_no_evolution(self):
        spark = MockSparkSession({"tbl_genie_amendment_timeline": _make_amendments_df()})
        tool = TemporalAnalysisTool(spark, MockProviderService())
        result = tool(question="test", provider_name="Test Hospital")
        assert result.data["concept_evolution"] == []


class TestLLMSummary:
    """Test LLM change summarization."""

    def test_generates_llm_summary(self):
        spark = MockSparkSession({"tbl_genie_amendment_timeline": _make_amendments_df()})
        llm = MockLLMClient(response="Rates increased 5%, telehealth added, capitation revised.")
        tool = TemporalAnalysisTool(spark, MockProviderService(), llm_client=llm)
        result = tool(question="test", provider_name="Test Hospital", summarize=True)
        assert result.data["llm_summary"] == "Rates increased 5%, telehealth added, capitation revised."
        assert len(llm.calls) == 1

    def test_no_summary_without_llm(self):
        spark = MockSparkSession({"tbl_genie_amendment_timeline": _make_amendments_df()})
        tool = TemporalAnalysisTool(spark, MockProviderService(), llm_client=None)
        result = tool(question="test", provider_name="Test Hospital", summarize=True)
        assert result.data["llm_summary"] == ""

    def test_no_summary_when_disabled(self):
        spark = MockSparkSession({"tbl_genie_amendment_timeline": _make_amendments_df()})
        llm = MockLLMClient()
        tool = TemporalAnalysisTool(spark, MockProviderService(), llm_client=llm)
        result = tool(question="test", provider_name="Test Hospital", summarize=False)
        assert result.data["llm_summary"] == ""
        assert len(llm.calls) == 0

    def test_no_summary_without_amendments(self):
        spark = MockSparkSession({})  # No amendments
        llm = MockLLMClient()
        tool = TemporalAnalysisTool(spark, MockProviderService(), llm_client=llm)
        result = tool(question="test", provider_name="Test Hospital", summarize=True)
        assert result.data["llm_summary"] == ""
        assert len(llm.calls) == 0

    def test_llm_receives_recent_amendments(self):
        spark = MockSparkSession({"tbl_genie_amendment_timeline": _make_amendments_df()})
        llm = MockLLMClient()
        tool = TemporalAnalysisTool(spark, MockProviderService(), llm_client=llm)
        tool(question="test", provider_name="Test Hospital")
        # Should include amendment text in LLM prompt
        prompt = llm.calls[0]["user"]
        assert "Rate increase 5%" in prompt
        assert "telehealth" in prompt


class TestConceptExtraction:
    """Test concept extraction from question text."""

    def test_extracts_quoted_concept(self):
        spark = MockSparkSession({"tbl_genie_amendment_timeline": _make_amendments_df()})
        tool = TemporalAnalysisTool(spark, MockProviderService())
        concept = tool._extract_concept('How has "offset clause" evolved?')
        assert concept == "offset clause"

    def test_extracts_evolution_pattern(self):
        spark = MockSparkSession({})
        tool = TemporalAnalysisTool(spark, MockProviderService())
        concept = tool._extract_concept("Show evolution of \'termination notice\' for this provider")
        assert concept == "termination notice"

    def test_returns_none_for_no_concept(self):
        spark = MockSparkSession({})
        tool = TemporalAnalysisTool(spark, MockProviderService())
        concept = tool._extract_concept("Show all amendments")
        assert concept is None


class TestEdgeCases:
    """Test error handling and edge cases."""

    def test_spark_failures_dont_crash(self):
        class FailingSpark:
            def sql(self, query):
                raise RuntimeError("Connection lost")

        tool = TemporalAnalysisTool(FailingSpark(), MockProviderService())
        result = tool(question="test", provider_name="Test Hospital")
        # Should still return a result (EMPTY status)
        assert result.status == ToolStatus.EMPTY
        assert result.data["amendments"] == []

    def test_validate_inputs_requires_question(self):
        spark = MockSparkSession({})
        tool = TemporalAnalysisTool(spark, MockProviderService())
        errors = tool.validate_inputs(provider_name="Test")
        assert len(errors) > 0

    def test_confidence_low_when_no_data(self):
        spark = MockSparkSession({})
        tool = TemporalAnalysisTool(spark, MockProviderService())
        result = tool(question="test", provider_name="Test Hospital")
        assert result.confidence == Confidence.LOW

    def test_confidence_high_when_data_present(self):
        spark = MockSparkSession({"tbl_genie_amendment_timeline": _make_amendments_df()})
        tool = TemporalAnalysisTool(spark, MockProviderService())
        result = tool(question="test", provider_name="Test Hospital")
        assert result.confidence == Confidence.HIGH


class TestGoldenTemporal:
    """Golden regression tests — 5 temporal queries matching V2 Branch G structure."""

    @pytest.mark.parametrize("question,provider,expect_concept", [
        ("What changed in Test Hospital\'s latest amendment?", "Test Hospital", None),
        ("Show amendment history for Test Hospital", "Test Hospital", None),
        ("How has \'offset clause\' changed in Test Hospital contracts?", "Test Hospital", "offset clause"),
        ("Show me Kaiser Permanente\'s contract timeline", "Kaiser Permanente", None),
        ("Track evolution of \'termination notice\' across versions", "Test Hospital", "termination notice"),
    ])
    def test_golden_temporal(self, question, provider, expect_concept):
        spark = MockSparkSession({
            "tbl_genie_amendment_timeline": _make_amendments_df(),
            "tbl_v2_contract_registry": _make_registry_df(),
            "tbl_contract_documents_master": _make_versions_df(),
            "tbl_vs_unified_ready": _make_evolution_df(),
        })
        llm = MockLLMClient(response="Summary of changes for this provider.")
        tool = TemporalAnalysisTool(spark, MockProviderService(), llm_client=llm)
        result = tool(question=question, provider_name=provider, concept=expect_concept)
        assert result.success
        assert result.data["provider_name"] == "Test Hospital"
        assert len(result.data["amendments"]) > 0
        if expect_concept:
            assert len(result.data["concept_evolution"]) > 0
