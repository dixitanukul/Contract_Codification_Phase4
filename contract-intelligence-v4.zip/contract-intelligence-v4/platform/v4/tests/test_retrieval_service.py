"""
platform/v4/tests/test_retrieval_service.py

P3-TEST-1: Integration tests for RetrievalService and RecallBoostService.

Covers:
  TestRetrievalServiceRetrieve       — retrieve() happy path, filtering, scoring, dedup
  TestRetrievalServiceFilterSafety   — keep_minimum safety-net
  TestRetrievalServiceRetrieveLegal  — retrieve_legal() output shape
  TestRetrievalServiceFactory        — build_retrieval_service() factory
  TestRetrievalServiceProviderResolve— provider alias resolution
  TestRecallBoostKeywordScan         — keyword_scan() with mocked Spark
  TestRecallBoostRescueFalseNeg      — rescue_false_negatives() with mocked Spark
  TestRecallBoostAugment             — boost_recall() dedup behaviour
  TestRetrievalAdapterNativePath     — adapter._call_native via is_ready / retrieve()
  TestRetrievalAdapterBackwardCompat — adapter with legacy retrieve_fn unchanged
"""
from __future__ import annotations

import sys
import types
import unittest
from unittest.mock import MagicMock, patch

# ---------------------------------------------------------------------------
# Path bootstrap (mirrors Cell 23 approach)
# ---------------------------------------------------------------------------
_V3_BASE = "/Workspace/Users/adixit01@blueshieldca.com/Contract_Codification_Pipeline"
if _V3_BASE not in sys.path:
    sys.path.insert(0, _V3_BASE)

if "platform.v4" not in sys.modules:
    _v3_pkg = types.ModuleType("platform.v4")
    _v3_pkg.__path__ = [f"{_V3_BASE}/platform/v3"]
    _v3_pkg.__package__ = "platform.v4"
    _v3_pkg.__spec__ = None
    sys.modules["platform.v4"] = _v3_pkg
    sys.modules["platform"].v3 = _v3_pkg  # type: ignore[attr-defined]


# ---------------------------------------------------------------------------
# Shared test fixtures
# ---------------------------------------------------------------------------

def _make_vs_row(
    provider_name="Sutter Roseville",
    source_filename="sutter_roseville_v2.pdf",
    page_number=12,
    chunk_text="The plan shall have the right to offset and recoup overpayments from future capitation payments.",
    chunk_index=5,
) -> list:
    """Build a fake VS data_array row in PAGE_LEVEL_COLUMNS order."""
    return [provider_name, source_filename, page_number, chunk_text, chunk_index]


def _make_vs_dict(
    provider_name="Sutter Roseville",
    source_filename="sutter_roseville_v2.pdf",
    page_number=12,
    unit_text="The plan shall have the right to offset and recoup overpayments.",
    chunk_index=5,
    score=0.91,
    channel="semantic",
) -> dict:
    """Build a fake structured passage dict (output of VectorSearchService.retrieve)."""
    return {
        "unit_id":         source_filename,
        "provider_name":   provider_name,
        "source_filename": source_filename,
        "page_number":     page_number,
        "unit_text":       unit_text,
        "chunk_index":     chunk_index,
        "score":           score,
        "channel":         channel,
        "is_current":      True,
    }


def _mock_vs_service(results=None, legal_rows=None):
    """Build a mocked VectorSearchService."""
    mock = MagicMock()
    mock.retrieve.return_value  = results if results is not None else [_make_vs_dict()]
    mock.search.return_value    = legal_rows if legal_rows is not None else []
    mock._index_legal           = "dev_adb.raw.idx_legal_units_v2"
    mock._LEGAL_COLUMNS         = ["unit_text", "provider_name", "source_filename", "section_type"]
    mock.is_degraded            = False
    return mock


def _mock_filter(current_filenames=None):
    """Build a mocked CurrentEffectiveFilter."""
    filenames = set(current_filenames or ["sutter_roseville_v2.pdf", "kaiser_v3.pdf"])
    mock = MagicMock()
    mock.is_current.side_effect = lambda fn: fn in filenames
    return mock


# ---------------------------------------------------------------------------
# 1. TestRetrievalServiceRetrieve
# ---------------------------------------------------------------------------

class TestRetrievalServiceRetrieve(unittest.TestCase):
    """RetrievalService.retrieve() happy-path and filtering."""

    def setUp(self):
        from platform.v4.services.retrieval_service import RetrievalService
        self.RetrievalService = RetrievalService

    def test_returns_list_of_dicts(self):
        """retrieve() returns a list of dicts from VS."""
        svc = self.RetrievalService(
            vs_service=_mock_vs_service(),
            current_filter=_mock_filter(),
        )
        results = svc.retrieve("offset clause")
        self.assertIsInstance(results, list)
        self.assertGreater(len(results), 0)

    def test_results_have_required_keys(self):
        """Each result dict has the required keys for _normalise_chunk."""
        svc = self.RetrievalService(
            vs_service=_mock_vs_service(),
            current_filter=_mock_filter(),
        )
        for r in svc.retrieve("offset clause"):
            for key in ("unit_id", "provider_name", "source_filename",
                        "page_number", "unit_text", "chunk_index", "score", "channel"):
                self.assertIn(key, r, f"Missing key: {key}")

    def test_known_provider_sutter_roseville(self):
        """retrieve() can filter to Sutter Roseville."""
        sutter_row = _make_vs_dict(provider_name="Sutter Roseville",
                                   source_filename="sutter_roseville_v2.pdf")
        mock_vs = _mock_vs_service(results=[sutter_row])
        svc = self.RetrievalService(
            vs_service=mock_vs,
            current_filter=_mock_filter(current_filenames={"sutter_roseville_v2.pdf"}),
        )
        results = svc.retrieve("offset clause", provider_name="Sutter Roseville")
        self.assertGreater(len(results), 0)
        self.assertEqual(results[0]["provider_name"], "Sutter Roseville")
        # VS called with provider_name
        mock_vs.retrieve.assert_called_once_with(
            "offset clause", top_k=10, provider_name="Sutter Roseville"
        )

    def test_current_effective_filter_applied(self):
        """retrieve() removes passages from expired files."""
        current_row  = _make_vs_dict(source_filename="current.pdf")
        expired_row  = _make_vs_dict(source_filename="expired.pdf")
        mock_vs      = _mock_vs_service(results=[current_row, expired_row])
        mock_filter  = _mock_filter(current_filenames={"current.pdf"})
        svc = self.RetrievalService(vs_service=mock_vs, current_filter=mock_filter)
        results = svc.retrieve("offset clause", current_only=True)
        filenames = [r["source_filename"] for r in results]
        self.assertIn("current.pdf", filenames)
        self.assertNotIn("expired.pdf", filenames)

    def test_current_only_false_skips_filter(self):
        """retrieve(current_only=False) returns all results including expired."""
        current_row = _make_vs_dict(source_filename="current.pdf")
        expired_row = _make_vs_dict(source_filename="expired.pdf")
        mock_vs     = _mock_vs_service(results=[current_row, expired_row])
        mock_filter = _mock_filter(current_filenames={"current.pdf"})
        svc = self.RetrievalService(vs_service=mock_vs, current_filter=mock_filter)
        results = svc.retrieve("offset clause", current_only=False)
        filenames = [r["source_filename"] for r in results]
        self.assertIn("current.pdf", filenames)
        self.assertIn("expired.pdf", filenames)

    def test_relevance_score_added(self):
        """retrieve() adds _relevance_score to each result."""
        svc = self.RetrievalService(
            vs_service=_mock_vs_service(),
            current_filter=_mock_filter(),
        )
        for r in svc.retrieve("offset clause"):
            self.assertIn("_relevance_score", r)

    def test_dedup_by_filename(self):
        """retrieve() deduplicates: same source_filename kept only once."""
        row_a = _make_vs_dict(source_filename="same.pdf", score=0.9)
        row_b = _make_vs_dict(source_filename="same.pdf", score=0.7)
        mock_vs = _mock_vs_service(results=[row_a, row_b])
        svc = self.RetrievalService(
            vs_service=mock_vs,
            current_filter=_mock_filter(current_filenames={"same.pdf"}),
        )
        results = svc.retrieve("offset")
        self.assertEqual(
            sum(1 for r in results if r["source_filename"] == "same.pdf"), 1
        )

    def test_no_filter_returns_all(self):
        """retrieve() without a filter returns all VS results."""
        rows = [_make_vs_dict(source_filename=f"file_{i}.pdf") for i in range(5)]
        mock_vs = _mock_vs_service(results=rows)
        svc = self.RetrievalService(vs_service=mock_vs, current_filter=None)
        results = svc.retrieve("offset clause")
        self.assertEqual(len(results), 5)

    def test_empty_vs_response(self):
        """retrieve() returns empty list when VS returns nothing."""
        mock_vs = _mock_vs_service(results=[])
        svc = self.RetrievalService(vs_service=mock_vs, current_filter=None)
        results = svc.retrieve("offset clause")
        self.assertEqual(results, [])

    def test_provider_id_kwarg_alias(self):
        """retrieve() accepts provider_id kwarg (backward-compat alias)."""
        mock_vs = _mock_vs_service()
        svc = self.RetrievalService(vs_service=mock_vs, current_filter=None)
        svc.retrieve("offset", provider_id="Kaiser")
        # provider_id should be resolved to provider_name kwarg for VS
        mock_vs.retrieve.assert_called_once_with("offset", top_k=10, provider_name="Kaiser")


# ---------------------------------------------------------------------------
# 2. TestRetrievalServiceFilterSafety
# ---------------------------------------------------------------------------

class TestRetrievalServiceFilterSafety(unittest.TestCase):
    """Keep-minimum safety-net: if filter would leave < keep_minimum results, return all."""

    def setUp(self):
        from platform.v4.services.retrieval_service import RetrievalService
        self.RetrievalService = RetrievalService

    def test_safety_net_returns_all_when_filter_below_minimum(self):
        """If only 1 current passage but 4 total, return all 4 (keep_minimum=3)."""
        rows = [
            _make_vs_dict(source_filename="current.pdf"),
            _make_vs_dict(source_filename="expired_a.pdf"),
            _make_vs_dict(source_filename="expired_b.pdf"),
            _make_vs_dict(source_filename="expired_c.pdf"),
        ]
        mock_vs     = _mock_vs_service(results=rows)
        mock_filter = _mock_filter(current_filenames={"current.pdf"})
        svc = self.RetrievalService(vs_service=mock_vs, current_filter=mock_filter)
        results = svc.retrieve("offset clause", keep_minimum=3)
        # Safety-net fires: 1 current < 3 minimum, return all 4
        self.assertEqual(len(results), 4)

    def test_safety_net_stamps_is_current_effective(self):
        """When safety-net fires, each result has is_current_effective flag."""
        rows = [
            _make_vs_dict(source_filename="current.pdf"),
            _make_vs_dict(source_filename="expired_a.pdf"),
            _make_vs_dict(source_filename="expired_b.pdf"),
            _make_vs_dict(source_filename="expired_c.pdf"),
        ]
        mock_vs     = _mock_vs_service(results=rows)
        mock_filter = _mock_filter(current_filenames={"current.pdf"})
        svc = self.RetrievalService(vs_service=mock_vs, current_filter=mock_filter)
        results = svc.retrieve("offset clause", keep_minimum=3)
        for r in results:
            self.assertIn("is_current_effective", r)

    def test_no_safety_net_when_enough_current(self):
        """Safety-net does NOT fire when enough current results after filter."""
        rows = [
            _make_vs_dict(source_filename="current_a.pdf"),
            _make_vs_dict(source_filename="current_b.pdf"),
            _make_vs_dict(source_filename="current_c.pdf"),
            _make_vs_dict(source_filename="expired.pdf"),
        ]
        mock_vs     = _mock_vs_service(results=rows)
        mock_filter = _mock_filter(current_filenames={"current_a.pdf", "current_b.pdf", "current_c.pdf"})
        svc = self.RetrievalService(vs_service=mock_vs, current_filter=mock_filter)
        results = svc.retrieve("offset clause", keep_minimum=3)
        filenames = [r["source_filename"] for r in results]
        self.assertNotIn("expired.pdf", filenames)
        self.assertEqual(len(results), 3)


# ---------------------------------------------------------------------------
# 3. TestRetrievalServiceRetrieveLegal
# ---------------------------------------------------------------------------

class TestRetrievalServiceRetrieveLegal(unittest.TestCase):
    """retrieve_legal() returns correctly shaped dicts from legal index."""

    def setUp(self):
        from platform.v4.services.retrieval_service import RetrievalService
        self.RetrievalService = RetrievalService

    def test_retrieve_legal_shape(self):
        """retrieve_legal() returns dicts with legal-specific fields."""
        legal_rows = [
            ["Offset rights are granted", "Sutter Roseville", "sutter_legal.pdf", "OFFSET"],
            ["Plan may recoup overpayments", "Kaiser", "kaiser_legal.pdf", "RECOUPMENT"],
        ]
        mock_vs = _mock_vs_service(legal_rows=legal_rows)
        svc = self.RetrievalService(vs_service=mock_vs, current_filter=None)
        results = svc.retrieve_legal("offset clause", top_k=5)
        self.assertEqual(len(results), 2)
        for r in results:
            self.assertEqual(r["channel"], "legal")
            self.assertIn("unit_text", r)
            self.assertIn("provider_name", r)
            self.assertIn("source_filename", r)
            self.assertIn("section_type", r)

    def test_retrieve_legal_calls_search_with_legal_index(self):
        """retrieve_legal() calls vs_service.search() with the legal index name."""
        mock_vs = _mock_vs_service(legal_rows=[])
        svc = self.RetrievalService(vs_service=mock_vs, current_filter=None)
        svc.retrieve_legal("overpayment", top_k=3)
        mock_vs.search.assert_called_once()
        call_kwargs = mock_vs.search.call_args
        self.assertIn("dev_adb.raw.idx_legal_units_v2", str(call_kwargs))

    def test_retrieve_legal_scores_decreasing(self):
        """Legal results have decreasing scores (0.03 step)."""
        legal_rows = [
            ["text one", "ProvA", "file_a.pdf", "OFFSET"],
            ["text two", "ProvB", "file_b.pdf", "DOFR"],
            ["text three", "ProvC", "file_c.pdf", "IPA"],
        ]
        mock_vs = _mock_vs_service(legal_rows=legal_rows)
        svc = self.RetrievalService(vs_service=mock_vs, current_filter=None)
        results = svc.retrieve_legal("offset")
        for i in range(len(results) - 1):
            self.assertGreater(results[i]["score"], results[i + 1]["score"])

    def test_retrieve_legal_empty(self):
        """retrieve_legal() returns empty list when VS returns nothing."""
        mock_vs = _mock_vs_service(legal_rows=[])
        svc = self.RetrievalService(vs_service=mock_vs, current_filter=None)
        self.assertEqual(svc.retrieve_legal("offset"), [])


# ---------------------------------------------------------------------------
# 4. TestRetrievalServiceFactory
# ---------------------------------------------------------------------------

class TestRetrievalServiceFactory(unittest.TestCase):
    """build_retrieval_service() factory function."""

    def test_factory_with_explicit_vs_service(self):
        """build_retrieval_service() with explicit vs_service skips SDK init."""
        from platform.v4.services.retrieval_service import build_retrieval_service, RetrievalService
        mock_vs = _mock_vs_service()
        svc = build_retrieval_service(vs_service=mock_vs)
        self.assertIsInstance(svc, RetrievalService)
        self.assertIs(svc._vs, mock_vs)

    def test_factory_without_spark_no_filter(self):
        """build_retrieval_service() without spark produces no current_filter."""
        from platform.v4.services.retrieval_service import build_retrieval_service
        mock_vs = _mock_vs_service()
        svc = build_retrieval_service(spark=None, vs_service=mock_vs)
        self.assertIsNone(svc._filter)

    def test_factory_with_spark_creates_filter(self):
        """build_retrieval_service() with spark auto-creates CurrentEffectiveFilter."""
        from platform.v4.services.retrieval_service import build_retrieval_service
        from platform.v4.core.current_effective_filter import CurrentEffectiveFilter
        mock_spark = MagicMock()
        mock_vs    = _mock_vs_service()
        svc = build_retrieval_service(spark=mock_spark, vs_service=mock_vs)
        self.assertIsInstance(svc._filter, CurrentEffectiveFilter)

    def test_factory_explicit_filter_used(self):
        """build_retrieval_service() with explicit filter uses it."""
        from platform.v4.services.retrieval_service import build_retrieval_service
        mock_vs     = _mock_vs_service()
        mock_filter = _mock_filter()
        svc = build_retrieval_service(vs_service=mock_vs, current_filter=mock_filter)
        self.assertIs(svc._filter, mock_filter)


# ---------------------------------------------------------------------------
# 5. TestRetrievalServiceProviderResolve
# ---------------------------------------------------------------------------

class TestRetrievalServiceProviderResolve(unittest.TestCase):
    """Provider alias resolution via ProviderService."""

    def setUp(self):
        from platform.v4.services.retrieval_service import RetrievalService
        self.RetrievalService = RetrievalService

    def test_no_provider_service_passes_name_direct(self):
        """Without ProviderService, provider_name is passed directly to VS."""
        mock_vs = _mock_vs_service()
        svc = self.RetrievalService(vs_service=mock_vs, current_filter=None)
        svc.retrieve("offset", provider_name="Sutter")
        mock_vs.retrieve.assert_called_once_with("offset", top_k=10, provider_name="Sutter")

    def test_provider_service_resolves_alias(self):
        """ProviderService.resolve_name() is called and resolution used."""
        mock_vs = _mock_vs_service()
        mock_ps = MagicMock()
        mock_ps.resolve_name.return_value = "Sutter Roseville Medical Center"
        svc = self.RetrievalService(
            vs_service=mock_vs,
            current_filter=None,
            provider_service=mock_ps,
        )
        svc.retrieve("offset", provider_name="Sutter Roseville")
        mock_ps.resolve_name.assert_called_once_with("Sutter Roseville")
        mock_vs.retrieve.assert_called_once_with(
            "offset", top_k=10, provider_name="Sutter Roseville Medical Center"
        )

    def test_provider_service_exception_falls_back(self):
        """If ProviderService.resolve_name() raises, original name is used."""
        mock_vs = _mock_vs_service()
        mock_ps = MagicMock()
        mock_ps.resolve_name.side_effect = RuntimeError("service down")
        svc = self.RetrievalService(
            vs_service=mock_vs,
            current_filter=None,
            provider_service=mock_ps,
        )
        svc.retrieve("offset", provider_name="Sutter")
        mock_vs.retrieve.assert_called_once_with("offset", top_k=10, provider_name="Sutter")


# ---------------------------------------------------------------------------
# 6. TestRecallBoostKeywordScan
# ---------------------------------------------------------------------------

class TestRecallBoostKeywordScan(unittest.TestCase):
    """RecallBoostService.keyword_scan() with mocked Spark."""

    def _make_spark_with_df(self, rows, columns):
        """Build a mock spark that returns a pandas DataFrame."""
        import pandas as pd
        df = pd.DataFrame(rows, columns=columns)
        mock_spark = MagicMock()
        mock_result = MagicMock()
        mock_result.toPandas.return_value = df
        mock_spark.sql.return_value = mock_result
        return mock_spark

    def test_known_concept_runs_sql(self):
        """keyword_scan() for a known concept executes a SQL query."""
        from platform.v4.services.recall_boost import RecallBoostService
        mock_spark = self._make_spark_with_df([], ["provider_name", "source_filename",
                                                   "page_number", "chunk_text",
                                                   "text_length", "kw_score", "file_version"])
        svc = RecallBoostService(spark=mock_spark)
        svc.keyword_scan("offset clause")
        mock_spark.sql.assert_called_once()
        sql_text = mock_spark.sql.call_args[0][0]
        # SQL should contain LIKE clause with known offset signal
        self.assertIn("offset", sql_text.lower())

    def test_returns_passage_dicts(self):
        """keyword_scan() returns list of passage dicts."""
        from platform.v4.services.recall_boost import RecallBoostService
        import pandas as pd
        rows = [{
            "provider_name":   "Sutter Roseville",
            "source_filename": "sutter_kw.pdf",
            "page_number":     5,
            "chunk_text":      "Plan has right to offset overpayments.",
            "text_length":     50,
            "kw_score":        2,
            "file_version":    1,
        }]
        mock_spark = self._make_spark_with_df(
            rows,
            ["provider_name", "source_filename", "page_number", "chunk_text",
             "text_length", "kw_score", "file_version"]
        )
        svc = RecallBoostService(spark=mock_spark)
        results = svc.keyword_scan("offset clause")
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]["provider_name"], "Sutter Roseville")
        self.assertEqual(results[0]["channel"], "keyword")

    def test_unknown_concept_returns_empty(self):
        """keyword_scan() for concept with no recall signals returns []."""
        from platform.v4.services.recall_boost import RecallBoostService
        mock_spark = MagicMock()
        svc = RecallBoostService(spark=mock_spark)
        results = svc.keyword_scan("nonexistent_concept_xyz")
        self.assertEqual(results, [])
        mock_spark.sql.assert_not_called()

    def test_provider_filter_applied_in_sql(self):
        """keyword_scan(provider_name=...) includes provider filter in SQL."""
        from platform.v4.services.recall_boost import RecallBoostService
        import pandas as pd
        mock_spark = self._make_spark_with_df(
            [], ["provider_name", "source_filename", "page_number", "chunk_text",
                 "text_length", "kw_score", "file_version"]
        )
        svc = RecallBoostService(spark=mock_spark)
        svc.keyword_scan("offset clause", provider_name="Sutter Roseville")
        sql_text = mock_spark.sql.call_args[0][0].lower()
        self.assertIn("sutter roseville", sql_text)

    def test_sql_failure_returns_empty(self):
        """keyword_scan() returns [] when Spark SQL raises."""
        from platform.v4.services.recall_boost import RecallBoostService
        mock_spark = MagicMock()
        mock_spark.sql.side_effect = RuntimeError("Spark error")
        svc = RecallBoostService(spark=mock_spark)
        results = svc.keyword_scan("offset clause")
        self.assertEqual(results, [])


# ---------------------------------------------------------------------------
# 7. TestRecallBoostRescueFalseNeg
# ---------------------------------------------------------------------------

class TestRecallBoostRescueFalseNeg(unittest.TestCase):
    """RecallBoostService.rescue_false_negatives()."""

    def _make_spark_with_df(self, rows, columns):
        import pandas as pd
        df = pd.DataFrame(rows, columns=columns)
        mock_spark = MagicMock()
        mock_result = MagicMock()
        mock_result.toPandas.return_value = df
        mock_spark.sql.return_value = mock_result
        return mock_spark

    def test_rescues_provider_with_strong_signal(self):
        """Provider with strong-signal text is rescued."""
        from platform.v4.services.recall_boost import RecallBoostService
        rows = [{
            "provider_name":   "Kaweah Delta",
            "source_filename": "kaweah_delta.pdf",
            "chunk_text":      "The plan shall have the right to offset and recoup overpayments from future payments.",
            "page_number":     7,
            "total_hits":      3,
        }]
        mock_spark = self._make_spark_with_df(
            rows, ["provider_name", "source_filename", "chunk_text", "page_number", "total_hits"]
        )
        svc = RecallBoostService(spark=mock_spark)
        rescued = svc.rescue_false_negatives("offset clause", ["Kaweah Delta"])
        self.assertIn("Kaweah Delta", rescued)

    def test_does_not_rescue_without_strong_signal(self):
        """Provider with only weak keyword hits (no strong phrase) is NOT rescued."""
        from platform.v4.services.recall_boost import RecallBoostService
        rows = [{
            "provider_name":   "Some Provider",
            "source_filename": "some_provider.pdf",
            "chunk_text":      "This contract discusses payments and reimbursement schedules.",
            "page_number":     2,
            "total_hits":      1,
        }]
        mock_spark = self._make_spark_with_df(
            rows, ["provider_name", "source_filename", "chunk_text", "page_number", "total_hits"]
        )
        svc = RecallBoostService(spark=mock_spark)
        rescued = svc.rescue_false_negatives("offset clause", ["Some Provider"])
        self.assertNotIn("Some Provider", rescued)

    def test_empty_providers_returns_empty(self):
        """rescue_false_negatives() returns [] immediately for empty input."""
        from platform.v4.services.recall_boost import RecallBoostService
        mock_spark = MagicMock()
        svc = RecallBoostService(spark=mock_spark)
        rescued = svc.rescue_false_negatives("offset clause", [])
        self.assertEqual(rescued, [])
        mock_spark.sql.assert_not_called()

    def test_sql_failure_returns_empty(self):
        """rescue_false_negatives() returns [] on SQL error."""
        from platform.v4.services.recall_boost import RecallBoostService
        mock_spark = MagicMock()
        mock_spark.sql.side_effect = RuntimeError("connection dropped")
        svc = RecallBoostService(spark=mock_spark)
        rescued = svc.rescue_false_negatives("offset clause", ["Provider A"])
        self.assertEqual(rescued, [])

    def test_unknown_concept_returns_empty(self):
        """rescue_false_negatives() returns [] for concept with no signals."""
        from platform.v4.services.recall_boost import RecallBoostService
        mock_spark = MagicMock()
        svc = RecallBoostService(spark=mock_spark)
        rescued = svc.rescue_false_negatives("unknown_xyz", ["Provider A"])
        self.assertEqual(rescued, [])
        mock_spark.sql.assert_not_called()


# ---------------------------------------------------------------------------
# 8. TestRecallBoostAugment
# ---------------------------------------------------------------------------

class TestRecallBoostAugment(unittest.TestCase):
    """RecallBoostService.boost_recall() merging and dedup."""

    def _make_spark_returning(self, results):
        """Mock spark that returns the given passage dicts from keyword_scan."""
        import pandas as pd
        if not results:
            df = pd.DataFrame(columns=["provider_name", "source_filename", "page_number",
                                       "chunk_text", "text_length", "kw_score", "file_version"])
        else:
            rows = [
                {
                    "provider_name":   r.get("provider_name", "P"),
                    "source_filename": r.get("source_filename", "f.pdf"),
                    "page_number":     r.get("page_number", 0),
                    "chunk_text":      r.get("unit_text", ""),
                    "text_length":     len(r.get("unit_text", "")),
                    "kw_score":        r.get("score", 1),
                    "file_version":    r.get("file_version", 0),
                }
                for r in results
            ]
            df = pd.DataFrame(rows)
        mock_spark = MagicMock()
        mock_result = MagicMock()
        mock_result.toPandas.return_value = df
        mock_spark.sql.return_value = mock_result
        return mock_spark

    def test_appends_new_results(self):
        """boost_recall() appends keyword results not in initial_results."""
        from platform.v4.services.recall_boost import RecallBoostService
        initial = [_make_vs_dict(source_filename="vs_file.pdf")]
        kw_result = [{"provider_name": "Kaiser", "source_filename": "kaiser_kw.pdf",
                      "unit_text": "right of recoupment stated here"}]
        mock_spark = self._make_spark_returning(kw_result)
        svc = RecallBoostService(spark=mock_spark)
        result = svc.boost_recall("offset clause", initial_results=initial)
        filenames = [r["source_filename"] for r in result]
        self.assertIn("vs_file.pdf",   filenames)
        self.assertIn("kaiser_kw.pdf", filenames)

    def test_does_not_duplicate_existing_files(self):
        """boost_recall() skips keyword results already in initial_results."""
        from platform.v4.services.recall_boost import RecallBoostService
        initial   = [_make_vs_dict(source_filename="sutter_roseville_v2.pdf")]
        kw_result = [{"provider_name": "Sutter Roseville",
                      "source_filename": "sutter_roseville_v2.pdf",  # same file
                      "unit_text": "overpayment recoup right"}]
        mock_spark = self._make_spark_returning(kw_result)
        svc = RecallBoostService(spark=mock_spark)
        result = svc.boost_recall("offset clause", initial_results=initial)
        # Should not duplicate
        self.assertEqual(
            sum(1 for r in result if r["source_filename"] == "sutter_roseville_v2.pdf"),
            1,
        )

    def test_no_initial_results_returns_keyword_only(self):
        """boost_recall() with no initial_results returns keyword scan results only."""
        from platform.v4.services.recall_boost import RecallBoostService
        kw_result = [{"provider_name": "P1", "source_filename": "p1.pdf",
                      "unit_text": "recoup overpayment"}]
        mock_spark = self._make_spark_returning(kw_result)
        svc = RecallBoostService(spark=mock_spark)
        result = svc.boost_recall("offset clause")
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]["source_filename"], "p1.pdf")


# ---------------------------------------------------------------------------
# 9. TestRetrievalAdapterNativePath
# ---------------------------------------------------------------------------

class TestRetrievalAdapterNativePath(unittest.TestCase):
    """RetrievalAdapter with native RetrievalService (P3-RET-3)."""

    def setUp(self):
        from platform.v4.adapters.retrieval_adapter import RetrievalAdapter
        from platform.v4.services.retrieval_service import RetrievalService
        self.RetrievalAdapter  = RetrievalAdapter
        self.RetrievalService  = RetrievalService

    def _make_native_adapter(self, results=None):
        mock_vs  = _mock_vs_service(results=results or [_make_vs_dict()])
        mock_flt = _mock_filter()
        svc      = self.RetrievalService(vs_service=mock_vs, current_filter=mock_flt)
        return self.RetrievalAdapter(
            retrieve_fn=None,
            retrieval_service=svc,
        )

    def test_is_ready_with_service_no_fn(self):
        """Adapter is_ready=True when retrieval_service provided, even with no retrieve_fn."""
        adapter = self._make_native_adapter()
        self.assertTrue(adapter.is_ready)

    def test_is_ready_false_with_nothing(self):
        """Adapter is_ready=False when neither fn nor service provided."""
        adapter = self.RetrievalAdapter(retrieve_fn=None, retrieval_service=None)
        self.assertFalse(adapter.is_ready)

    def test_retrieve_returns_tool_result_success(self):
        """Adapter.retrieve() with native service returns ToolResult success=True."""
        adapter = self._make_native_adapter()
        result  = adapter.retrieve("offset clause")
        self.assertTrue(result.success)
        self.assertIsInstance(result.data, list)

    def test_retrieve_returns_passages(self):
        """Adapter.retrieve() via native path returns RetrievedPassage objects."""
        from platform.v4.adapters.retrieval_adapter import RetrievedPassage
        adapter = self._make_native_adapter()
        result  = adapter.retrieve("offset clause")
        for p in result.data:
            self.assertIsInstance(p, RetrievedPassage)

    def test_retrieve_legal_uses_service(self):
        """Adapter.retrieve_legal() via native path succeeds."""
        mock_vs = _mock_vs_service(legal_rows=[
            ["Offset rights granted", "Sutter", "sutter_legal.pdf", "OFFSET"]
        ])
        svc     = self.RetrievalService(vs_service=mock_vs, current_filter=None)
        adapter = self.RetrievalAdapter(retrieve_fn=None, retrieval_service=svc)
        result  = adapter.retrieve_legal("offset clause")
        self.assertTrue(result.success)

    def test_stub_returned_with_no_fn_no_service(self):
        """Adapter returns STUB ToolResult when nothing is wired."""
        adapter = self.RetrievalAdapter(retrieve_fn=None, retrieval_service=None)
        result  = adapter.retrieve("offset clause")
        self.assertFalse(result.success)
        self.assertIn("STUB", result.summary)

    def test_native_path_metadata_tag(self):
        """Adapter native path sets metadata.path = 'native'."""
        adapter = self._make_native_adapter()
        result  = adapter.retrieve("offset clause")
        self.assertEqual(result.metadata.get("path"), "native")


# ---------------------------------------------------------------------------
# 10. TestRetrievalAdapterBackwardCompat
# ---------------------------------------------------------------------------

class TestRetrievalAdapterBackwardCompat(unittest.TestCase):
    """Adapter with legacy retrieve_fn continues to work (P3-RET-3 backward compat)."""

    def setUp(self):
        from platform.v4.adapters.retrieval_adapter import RetrievalAdapter
        self.RetrievalAdapter = RetrievalAdapter

    def _make_legacy_fn(self):
        """Return a mock retrieve_fn that returns a list of raw dicts."""
        fn = MagicMock(return_value=[_make_vs_dict()])
        return fn

    def test_legacy_fn_takes_priority(self):
        """When retrieve_fn is provided, it is used instead of retrieval_service."""
        legacy_fn  = self._make_legacy_fn()
        mock_svc   = MagicMock()  # should NOT be called
        adapter    = self.RetrievalAdapter(
            retrieve_fn=legacy_fn,
            retrieval_service=mock_svc,
        )
        result = adapter.retrieve("offset clause")
        legacy_fn.assert_called_once()
        mock_svc.retrieve.assert_not_called()

    def test_legacy_fn_returns_success(self):
        """Legacy retrieve_fn path still returns ToolResult success=True."""
        legacy_fn = self._make_legacy_fn()
        adapter   = self.RetrievalAdapter(retrieve_fn=legacy_fn)
        result    = adapter.retrieve("offset clause")
        self.assertTrue(result.success)

    def test_is_ready_with_legacy_fn_only(self):
        """Adapter is_ready=True when only retrieve_fn is provided."""
        adapter = self.RetrievalAdapter(retrieve_fn=self._make_legacy_fn())
        self.assertTrue(adapter.is_ready)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    unittest.main(verbosity=2)
