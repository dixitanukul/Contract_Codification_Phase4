"""
platform/v4/tests/test_hallucination_guard.py

Unit tests for HallucinationGuard.

All tests operate on in-memory strings — no Spark, LLM, or adapters needed.
"""
import pytest

from ..contracts.tool_types import Confidence, ToolResult
from ..core.hallucination_guard import HallucinationGuard, GuardResult


class TestHallucinationGuard:

    def _guard(self, strict: bool = False) -> HallucinationGuard:
        return HallucinationGuard(strict=strict)

    def test_clean_answer_passes(self):
        guard  = self._guard()
        result = guard.check(
            answer="The rate for Cedars-Sinai is 110.50 per unit.",
            citations=[{"doc_id": "doc1", "provider_name": "Cedars-Sinai", "page_number": 3}],
            tool_results=[ToolResult(
                success=True,
                data=[{"rate_amount": 110.50, "provider_name": "Cedars-Sinai"}],
                summary="Rate found",
                confidence=Confidence.HIGH,
            )],
        )
        assert isinstance(result, GuardResult)
        assert not result.has_blocks

    def test_no_citations_triggers_warning(self):
        guard  = self._guard()
        result = guard.check(
            answer="The rate is $500.00 per day.",
            citations=[],
            tool_results=[],
        )
        assert result.has_warnings or not result.passed

    def test_implausible_year_flagged(self):
        guard  = self._guard()
        result = guard.check(
            answer="This contract was signed in 1885.",
            citations=[{"doc_id": "d1", "provider_name": "Test Hospital"}],
        )
        year_findings = [f for f in result.findings if f.check == "implausible_date"]
        assert len(year_findings) > 0

    def test_plausible_year_passes(self):
        guard  = self._guard()
        result = guard.check(
            answer="The contract effective date is January 1, 2024.",
            citations=[{"doc_id": "d1"}],
        )
        year_findings = [f for f in result.findings if f.check == "implausible_date"]
        assert len(year_findings) == 0

    def test_numeric_mismatch_flagged(self):
        guard  = self._guard()
        result = guard.check(
            answer="The rate is $99999.99 per day.",   # not in source data
            citations=[{"doc_id": "d1", "provider_name": "Test Hospital"}],
            tool_results=[ToolResult(
                success=True,
                data=[{"rate_amount": 100.0}],  # different number
                summary="Rate",
                confidence=Confidence.HIGH,
            )],
        )
        numeric_findings = [f for f in result.findings if f.check == "numeric_mismatch"]
        assert len(numeric_findings) > 0

    def test_adjusted_confidence_lowered_when_no_citations(self):
        guard  = self._guard()
        result = guard.check(
            answer="Some answer without citations.",
            citations=[],
            tool_results=[],
        )
        if result.adjusted_confidence:
            assert result.adjusted_confidence in {Confidence.MODERATE, Confidence.LOW}

    def test_guard_result_summary(self):
        guard  = self._guard()
        result = guard.check(answer="Clean answer.", citations=[{"doc_id": "d1"}])
        summary = result.summary()
        assert isinstance(summary, str)
        assert len(summary) > 0
