"""
platform/v4/tests/test_context_manager.py

Unit tests for ContextManager.

Tests use stub Spark and pre-populated cache — no live SQL required.
"""
import pytest
from unittest.mock import MagicMock

from ..core.context_manager import ContextManager
from ..contracts.context_types import SessionContext, ConversationTurn, ResolvedEntity
from ..contracts.agent_types import AgentRequest


class TestContextManager:

    def _make_manager(self) -> ContextManager:
        cm = ContextManager(spark=None)
        # Pre-populate cache with known providers
        from ..adapters.provider_adapter import CanonicalProvider
        cm._canonical_cache = {
            "cedars sinai":     CanonicalProvider("cs001", "Cedars-Sinai Medical Center"),
            "kaiser":           CanonicalProvider("k001",  "Kaiser Permanente"),
            "st john hospital": CanonicalProvider("sj001", "St. John's Regional Medical Center"),
        }
        return cm

    def test_resolve_exact_match(self):
        cm     = self._make_manager()
        result = cm.resolve("cedars sinai")
        assert result is not None
        assert "Cedars-Sinai" in result.canonical_name

    def test_resolve_case_insensitive(self):
        cm     = self._make_manager()
        result = cm.resolve("KAISER")
        assert result is not None
        assert result.canonical_name == "Kaiser Permanente"

    def test_resolve_unknown_returns_none(self):
        cm     = self._make_manager()
        result = cm.resolve("Some Random Hospital XYZ")
        # Should return None or a low-confidence result when not in cache + no Spark
        assert result is None or not result.canonical_name

    def test_set_provider_cache(self):
        from ..adapters.provider_adapter import CanonicalProvider
        cm    = ContextManager(spark=None)
        cache = {"test provider": CanonicalProvider("t001", "Test Provider Inc")}
        cm.set_provider_cache(cache)
        result = cm.resolve("test provider")
        assert result is not None

    def test_resolve_concept_returns_known(self):
        cm      = self._make_manager()
        concept = cm.resolve_concept("offset clause")
        assert concept is not None
        assert isinstance(concept, str)
        assert len(concept) > 0

    def test_resolve_unknown_concept(self):
        cm      = self._make_manager()
        concept = cm.resolve_concept("some_unknown_concept_xyz")
        # Unknown concepts return None or the key itself
        assert concept is None or isinstance(concept, str)
