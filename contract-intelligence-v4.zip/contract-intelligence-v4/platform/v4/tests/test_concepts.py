"""
platform/v4/tests/test_concepts.py

Step 1.7: Tests for the unified concept registry (services/concepts.py).

Uses importlib pattern for standalone execution (avoids platform stdlib conflict).

Test classes
------------
TestConceptRegistryStructure   (7)  -- registry completeness, schema, polarity values
TestGetTaxonomy                (4)  -- known, unknown, case-insensitive, copy isolation
TestGetRecallSignals           (4)  -- known, unknown, case-insensitive, keys present
TestGetPolarityCodes           (4)  -- GRANT/RESTRICT/ABSENT buckets, unknown, absence
TestBackwardCompatGlobals      (4)  -- KNOWN_TAXONOMIES, KNOWN_RECALL_SIGNALS, ABSENCE_CODES
TestAccessorHelpers            (4)  -- is_known_concept, all_concept_names, assign_polarity,
                                       category_polarity_map

Total: 27 tests
"""
from __future__ import annotations

import importlib.util
import os
import sys

import pytest

# ============================================================
# MODULE LOADING  (standalone-compatible, avoids stdlib `platform` conflict)
# ============================================================

PROJECT_ROOT = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "..", "..", "..")
)
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

_spec = importlib.util.spec_from_file_location(
    "concepts",
    os.path.join(PROJECT_ROOT, "platform", "v4", "services", "concepts.py"),
)
_mod = importlib.util.module_from_spec(_spec)
sys.modules["concepts"] = _mod
_spec.loader.exec_module(_mod)

# Pull all exported symbols into module scope
CONCEPT_REGISTRY      = _mod.CONCEPT_REGISTRY
KNOWN_TAXONOMIES      = _mod.KNOWN_TAXONOMIES
KNOWN_RECALL_SIGNALS  = _mod.KNOWN_RECALL_SIGNALS
ABSENCE_CODES         = _mod.ABSENCE_CODES
get_taxonomy          = _mod.get_taxonomy
get_recall_signals    = _mod.get_recall_signals
get_polarity_codes    = _mod.get_polarity_codes
is_known_concept      = _mod.is_known_concept
all_concept_names     = _mod.all_concept_names
assign_polarity       = _mod.assign_polarity
category_polarity_map = _mod.category_polarity_map


# ============================================================
# Shared fixtures / constants
# ============================================================

_KNOWN = [
    "offset clause",
    "division of financial responsibility",
    "ipa delegation",
    "ab 352 reproductive health",
    "encounters reconciliation",
    "auto renewal",
]

_ABSENCE_EXPECTED = {
    "DOFR_NOT_SPECIFIED",
    "NO_IPA_RELATIONSHIP",
    "AB352_NOT_PRESENT",
    "NO_RECONCILIATION_REQUIREMENT",
    "FIXED_TERM_NO_RENEWAL",
}


# ===========================================================================
# TestConceptRegistryStructure
# ===========================================================================

class TestConceptRegistryStructure:
    """Validate that every entry in CONCEPT_REGISTRY has the required schema."""

    def test_registry_has_six_concepts(self):
        assert len(CONCEPT_REGISTRY) == 6

    def test_all_expected_concepts_present(self):
        for name in _KNOWN:
            assert name in CONCEPT_REGISTRY, f"Missing concept: {name!r}"

    def test_every_entry_has_required_keys(self):
        required = {"display_name", "description", "first_pass", "strong", "taxonomy"}
        for name, defn in CONCEPT_REGISTRY.items():
            missing = required - defn.keys()
            assert not missing, f"Concept {name!r} missing keys: {missing}"

    def test_every_taxonomy_entry_has_required_keys(self):
        required = {"code", "label", "description", "is_denial", "polarity"}
        for name, defn in CONCEPT_REGISTRY.items():
            for entry in defn["taxonomy"]:
                missing = required - entry.keys()
                assert not missing, (
                    f"Concept {name!r} entry {entry.get('code')!r} missing: {missing}"
                )

    def test_polarity_values_are_valid(self):
        valid = {"GRANT", "RESTRICT", "ABSENT"}
        for name, defn in CONCEPT_REGISTRY.items():
            for entry in defn["taxonomy"]:
                assert entry["polarity"] in valid, (
                    f"Concept {name!r} code {entry['code']!r} has invalid polarity "
                    f"{entry['polarity']!r}"
                )

    def test_every_concept_has_nonempty_first_pass(self):
        for name, defn in CONCEPT_REGISTRY.items():
            assert defn["first_pass"], f"Concept {name!r} has empty first_pass"

    def test_every_concept_has_nonempty_strong(self):
        for name, defn in CONCEPT_REGISTRY.items():
            assert defn["strong"], f"Concept {name!r} has empty strong phrases"


# ===========================================================================
# TestGetTaxonomy
# ===========================================================================

class TestGetTaxonomy:
    def test_known_concept_returns_list_of_dicts(self):
        tax = get_taxonomy("offset clause")
        assert isinstance(tax, list) and len(tax) > 0
        assert all(isinstance(e, dict) for e in tax)

    def test_unknown_concept_returns_none(self):
        assert get_taxonomy("nonexistent concept xyz") is None

    def test_case_insensitive_lookup(self):
        assert get_taxonomy("OFFSET CLAUSE") is not None
        assert get_taxonomy("Offset Clause") is not None

    def test_returns_independent_copy(self):
        """Mutating the returned list must not affect the registry."""
        original_len = len(CONCEPT_REGISTRY["auto renewal"]["taxonomy"])
        tax = get_taxonomy("auto renewal")
        tax.append({"code": "INJECTED", "label": "x", "description": "x",
                    "is_denial": False, "polarity": "GRANT"})
        assert len(get_taxonomy("auto renewal")) == original_len


# ===========================================================================
# TestGetRecallSignals
# ===========================================================================

class TestGetRecallSignals:
    def test_known_concept_returns_both_keys(self):
        sig = get_recall_signals("offset clause")
        assert sig is not None
        assert "first_pass" in sig and "strong" in sig

    def test_unknown_concept_returns_none(self):
        assert get_recall_signals("unknown xyz") is None

    def test_case_insensitive(self):
        sig = get_recall_signals("IPA DELEGATION")
        assert sig is not None

    def test_first_pass_is_nonempty_list(self):
        for name in _KNOWN:
            sig = get_recall_signals(name)
            assert isinstance(sig["first_pass"], list) and len(sig["first_pass"]) > 0


# ===========================================================================
# TestGetPolarityCodes
# ===========================================================================

class TestGetPolarityCodes:
    def test_offset_has_grant_and_restrict_buckets(self):
        pc = get_polarity_codes("offset clause")
        assert pc is not None
        assert len(pc["GRANT"]) > 0, "offset clause must have GRANT codes"
        assert len(pc["RESTRICT"]) > 0, "offset clause must have RESTRICT codes"
        assert "NO_OFFSET_RIGHTS" in pc["RESTRICT"]
        assert "CONDITIONAL_OFFSET_RESTRICTION" in pc["RESTRICT"]

    def test_dofr_has_absent_bucket(self):
        pc = get_polarity_codes("division of financial responsibility")
        assert "DOFR_NOT_SPECIFIED" in pc["ABSENT"]

    def test_ipa_delegation_no_restrict(self):
        pc = get_polarity_codes("ipa delegation")
        assert len(pc["RESTRICT"]) == 0

    def test_unknown_returns_none(self):
        assert get_polarity_codes("not a concept") is None


# ===========================================================================
# TestBackwardCompatGlobals
# ===========================================================================

class TestBackwardCompatGlobals:
    def test_known_taxonomies_keys_match_registry(self):
        assert set(KNOWN_TAXONOMIES.keys()) == set(CONCEPT_REGISTRY.keys())

    def test_known_taxonomies_values_are_taxonomy_lists(self):
        for concept, tax in KNOWN_TAXONOMIES.items():
            assert isinstance(tax, list) and len(tax) > 0

    def test_known_recall_signals_keys_match_registry(self):
        assert set(KNOWN_RECALL_SIGNALS.keys()) == set(CONCEPT_REGISTRY.keys())

    def test_absence_codes_matches_expected(self):
        assert ABSENCE_CODES == _ABSENCE_EXPECTED


# ===========================================================================
# TestAccessorHelpers
# ===========================================================================

class TestAccessorHelpers:
    def test_is_known_concept_true_for_known(self):
        for name in _KNOWN:
            assert is_known_concept(name), f"Expected known: {name!r}"

    def test_is_known_concept_false_for_unknown(self):
        assert not is_known_concept("capitation pooling")
        assert not is_known_concept("")

    def test_all_concept_names_returns_all_six(self):
        names = all_concept_names()
        assert len(names) == 6
        for name in _KNOWN:
            assert name in names

    def test_assign_polarity_explicit_field_takes_precedence(self):
        entry = {"code": "X", "polarity": "RESTRICT", "is_denial": False}
        assert assign_polarity(entry) == "RESTRICT"

    def test_assign_polarity_absence_code_detected(self):
        entry = {"code": "DOFR_NOT_SPECIFIED", "is_denial": False}
        assert assign_polarity(entry) == "ABSENT"

    def test_assign_polarity_legacy_is_denial_fallback(self):
        entry = {"code": "SOME_DENIAL", "is_denial": True}
        assert assign_polarity(entry) == "RESTRICT"

    def test_category_polarity_map_basic(self):
        taxonomy = [
            {"code": "A", "polarity": "GRANT"},
            {"code": "B", "polarity": "RESTRICT"},
            {"code": "C", "polarity": "ABSENT"},
        ]
        cpm = category_polarity_map(taxonomy)
        assert cpm == {"A": "GRANT", "B": "RESTRICT", "C": "ABSENT"}
