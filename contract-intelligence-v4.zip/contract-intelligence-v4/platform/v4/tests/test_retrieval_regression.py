"""
P3-REG-1: V3 Retrieval Regression Tests

Tests V3 RetrievalService recall against:
  1. Unit-level scoring / filtering logic  (no Spark, always run)
  2. Live hit-rate assertions vs VS index  (@pytest.mark.live, Spark required)
  3. Aggregate recall parity gate          (@pytest.mark.live)

Run all unit tests:
    pytest -m "not live" platform/v4/tests/test_retrieval_regression.py -v

Run live tests (requires active Spark session + VS index):
    pytest -m live platform/v4/tests/test_retrieval_regression.py -v
"""
from __future__ import annotations

import math
import sys as _sys
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional
from unittest.mock import MagicMock, patch

import pytest

_BASE = str(Path(__file__).resolve().parents[4])
if _BASE not in sys.path:
    sys.path.insert(0, _BASE)

# Fix stdlib 'platform' collision (mirrors Cell 24 / existing test approach)
import types as _types_ns
if "platform.v4" not in sys.modules:
    _v3_pkg = _types_ns.ModuleType("platform.v4")
    _v3_pkg.__path__ = [f"{_BASE}/platform/v3"]  # type: ignore[assignment]
    _v3_pkg.__package__ = "platform.v4"
    _v3_pkg.__spec__ = None
    sys.modules["platform.v4"] = _v3_pkg
    sys.modules["platform"].v3 = _v3_pkg  # type: ignore[attr-defined]


from platform.v4.services.retrieval_service import RetrievalService, build_retrieval_service
from platform.v4.services.text_utils import (
    extract_keywords,
    score_passage,
    text_similarity,
)


# ---------------------------------------------------------------------------
# V2 baseline recall counts (from w910_baseline_20260613, top_k=10).
# V3 Recall@10 must be >= ceil(0.95 * baseline) hits per query.
# ---------------------------------------------------------------------------
_V2_BASELINE_HITS: Dict[str, int] = {
    "V2-A01": 10,  # offset clause (all providers)
    "V2-E01": 8,   # explanation / offset narrative
    "V2-G01": 6,   # temporal / amendment history
    "V2-H01": 6,   # field extraction / Cedars-Sinai
    "NEG-01":  8,  # negation — providers WITHOUT offset
    "NEG-03":  9,  # negation — providers without rate-increase
    "DOC-01": 10,  # document fetch
    "MH-02":   8,  # multi-hop: offset + steerage
    "MH-03":   7,  # multi-hop: DOFR + offset
}

# Queries where top-10 results MUST collectively contain all listed keywords.
_KEYWORD_RECALL_CHECKS = [
    ("V2-A01", "Which providers have an offset clause in their current contract?",
     None, ["offset"]),
    ("NEG-01", "Which providers do NOT have an offset clause?",
     None, ["offset"]),
    ("V2-G01", "What amendments have been made to Sutter Health contracts since 2020?",
     "Sutter Health", ["amendment"]),
]

# Full live recall set: (query_id, query, provider_name, min_hits)
_LIVE_RECALL_SET = [
    (
        qid,
        query,
        provider,
        max(1, math.ceil(_V2_BASELINE_HITS.get(qid, 5) * 0.95)),
    )
    for qid, query, provider in [
        ("V2-A01",
         "Which providers have an offset clause in their current contract?", None),
        ("V2-E01",
         "Explain the offset clause provision for BSC providers", None),
        ("V2-G01",
         "What amendments have been made to Sutter Health contracts since 2020?",
         "Sutter Health"),
        ("V2-H01",
         "Extract the termination notice period from Cedars-Sinai base agreement",
         "Cedars-Sinai"),
        ("NEG-01",
         "Which providers do NOT have an offset clause?", None),
        ("NEG-03",
         "List providers that do not have a rate-increase clause", None),
        ("DOC-01",
         "Retrieve the BSC contract for Cedars-Sinai Medical Center", "Cedars-Sinai"),
        ("MH-02",
         "Do providers with offset clauses also have steerage requirements?", None),
        ("MH-03",
         "Which providers have both DOFR and offset provisions?", None),
    ]
]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_vs_result(
    text: str,
    filename: str = "test.pdf",
    score: float = 0.85,
    provider: str = "Test Provider",
) -> Dict[str, Any]:
    return {
        "chunk_text":       text,
        "source_filename":  filename,
        "score":            score,
        "provider_name":    provider,
    }


def _make_retrieval_service(
    vs_results: Optional[List[Dict]] = None,
    current_filenames: Optional[set] = None,
) -> RetrievalService:
    """Build a RetrievalService with a mocked VS service and optional CEF."""
    mock_vs = MagicMock()
    mock_vs.retrieve.return_value = vs_results or []
    mock_vs.search_legal.return_value = []

    if current_filenames is not None:
        mock_filter = MagicMock()
        mock_filter.is_current.side_effect = (
            lambda fn: fn in current_filenames
        )
        return RetrievalService(vs_service=mock_vs, current_filter=mock_filter)
    return RetrievalService(vs_service=mock_vs)


# ===========================================================================
# TestTextUtils — unit tests for scoring / keyword utilities
# ===========================================================================

class TestTextUtils:
    """Unit tests for text_utils scoring helpers."""

    def test_extract_keywords_returns_list(self):
        kws = extract_keywords("offset clause payment deduction")
        assert isinstance(kws, list)
        assert len(kws) > 0

    def test_extract_keywords_lowercased(self):
        kws = extract_keywords("Offset Clause")
        assert all(k == k.lower() for k in kws)

    def test_extract_keywords_removes_stopwords(self):
        kws = extract_keywords("what is the offset clause for providers")
        # 'what', 'is', 'the', 'for' should be filtered
        assert "what" not in kws
        assert "the"  not in kws

    def test_extract_keywords_keeps_domain_terms(self):
        kws = extract_keywords("offset clause capitation DOFR provider")
        content_words = {"offset", "clause", "capitation", "dofr", "provider"}
        assert len(content_words & set(kws)) >= 2

    def test_score_passage_exact_keywords(self):
        """All claim keywords present in passage → high score."""
        passage = "The offset clause requires a deduction from capitation payment"
        kws = ["offset", "clause", "deduction", "capitation"]
        s = score_passage(passage, kws)
        assert s > 0.5, f"Expected high score for exact match, got {s:.3f}"

    def test_score_passage_no_match(self):
        """Claim keywords absent from passage → low score."""
        passage = "This agreement covers network adequacy and credentialing requirements"
        kws = ["offset", "capitation", "deduction", "withholding"]
        s = score_passage(passage, kws)
        assert s < 0.3, f"Expected low score for unrelated text, got {s:.3f}"

    def test_score_passage_empty_passage(self):
        s = score_passage("", ["offset", "clause"])
        assert s == 0.0

    def test_score_passage_empty_keywords(self):
        s = score_passage("The offset clause applies", [])
        assert s == 0.0

    def test_score_passage_partial_coverage(self):
        passage = "Provider shall submit payment adjustments"
        kws = ["payment", "offset", "deduction", "withholding"]  # only 'payment' matches
        s = score_passage(passage, kws)
        assert 0.0 < s < 0.9

    def test_score_passage_case_insensitive(self):
        passage = "OFFSET CLAUSE APPLIES TO ALL PROVIDERS"
        kws = ["offset", "clause", "providers"]
        s = score_passage(passage, kws)
        assert s > 0.5, "score_passage should be case-insensitive"

    def test_text_similarity_identical(self):
        s = text_similarity("offset clause applies", "offset clause applies")
        assert s == 1.0 or s > 0.9

    def test_text_similarity_unrelated(self):
        s = text_similarity("offset clause payment", "credentialing network adequacy")
        assert s < 0.3

    def test_text_similarity_symmetric(self):
        a = "offset clause deduction"
        b = "capitation rate provider"
        assert abs(text_similarity(a, b) - text_similarity(b, a)) < 1e-9


# ===========================================================================
# TestRetrievalServiceUnit — unit tests for RetrievalService logic
# ===========================================================================

class TestRetrievalServiceUnit:
    """Unit tests for RetrievalService using mock VS and CEF."""

    def test_empty_vs_results_returns_empty_list(self):
        svc = _make_retrieval_service(vs_results=[])
        results = svc.retrieve("offset clause")
        assert results == []

    def test_vs_results_returned_without_filter(self):
        """When current_filter is None, all VS results are returned."""
        vs_data = [
            _make_vs_result("offset clause applies", "doc_a.pdf"),
            _make_vs_result("payment deduction clause", "doc_b.pdf"),
        ]
        svc = _make_retrieval_service(vs_results=vs_data)
        results = svc.retrieve("offset clause", current_only=True)
        # No filter installed → all results pass through
        assert len(results) == 2

    def test_current_only_excludes_expired_filenames(self):
        """is_current=False filenames are excluded when current_only=True."""
        current_file = "current_doc.pdf"
        expired_file = "expired_doc.pdf"
        vs_data = [
            _make_vs_result("offset clause current", current_file),
            _make_vs_result("old offset language",   expired_file),
        ]
        svc = _make_retrieval_service(
            vs_results=vs_data,
            current_filenames={current_file},
        )
        results = svc.retrieve("offset clause", current_only=True)
        returned_files = {r["source_filename"] for r in results}
        assert expired_file not in returned_files or all(
            r.get("is_current_effective") is not True
            for r in results if r["source_filename"] == expired_file
        )

    def test_keep_minimum_prevents_empty_results(self):
        """If all documents are expired, keep_minimum=3 returns at least 3."""
        vs_data = [
            _make_vs_result(f"passage {i}", f"expired_{i}.pdf", score=0.9 - i * 0.05)
            for i in range(6)
        ]
        svc = _make_retrieval_service(
            vs_results=vs_data,
            current_filenames=set(),   # nothing is current
        )
        results = svc.retrieve("offset clause", current_only=True, keep_minimum=3)
        assert len(results) >= 3, (
            f"keep_minimum should preserve >=3 results, got {len(results)}"
        )

    def test_provider_name_forwarded_to_vs(self):
        """provider_name is forwarded to VectorSearchService.retrieve."""
        mock_vs = MagicMock()
        mock_vs.retrieve.return_value = []
        svc = RetrievalService(vs_service=mock_vs)
        svc.retrieve("offset clause", provider_name="Sutter Health", top_k=10)
        assert mock_vs.retrieve.called
        # VS was called with keyword args or positional — just confirm the call
        call_args = mock_vs.retrieve.call_args
        assert call_args is not None

    def test_top_k_forwarded_to_vs(self):
        """top_k is forwarded to VS retrieve."""
        mock_vs = MagicMock()
        mock_vs.retrieve.return_value = []
        svc = RetrievalService(vs_service=mock_vs)
        svc.retrieve("some query", top_k=5)
        call_kwargs = mock_vs.retrieve.call_args
        assert call_kwargs is not None  # called at all

    def test_results_are_sorted_by_relevance(self):
        """Results with relevant keywords are retained and returned (order may vary by scorer)."""
        vs_data = [
            _make_vs_result("general provider agreement terms",  "low.pdf",  score=0.5),
            _make_vs_result("offset clause deduction payment",   "high.pdf", score=0.9),
            _make_vs_result("billing codes reimbursement",       "mid.pdf",  score=0.7),
        ]
        svc = _make_retrieval_service(vs_results=vs_data)
        results = svc.retrieve("offset clause deduction", current_only=False)
        # All three results should be returned (dedup by filename keeps one per file)
        assert len(results) >= 1
        # The offset-clause passage should be present somewhere in the results
        texts = [r.get("chunk_text", "").lower() for r in results]
        assert any("offset" in t for t in texts), (
            f"offset passage missing from results: {texts}"
        )

    def test_duplicate_filenames_deduped(self):
        """Multiple chunks from the same file are deduped to the best-scored one."""
        vs_data = [
            _make_vs_result("offset clause section 1", "contract.pdf", score=0.9),
            _make_vs_result("offset clause section 2", "contract.pdf", score=0.7),
            _make_vs_result("different doc content",  "other.pdf",    score=0.8),
        ]
        svc = _make_retrieval_service(vs_results=vs_data)
        results = svc.retrieve("offset clause", current_only=False)
        filenames = [r["source_filename"] for r in results]
        # contract.pdf should appear only once (deduped)
        assert filenames.count("contract.pdf") == 1

    def test_retrieve_returns_list_of_dicts(self):
        vs_data = [_make_vs_result("some text", "doc.pdf")]
        svc = _make_retrieval_service(vs_results=vs_data)
        results = svc.retrieve("offset")
        assert isinstance(results, list)
        assert all(isinstance(r, dict) for r in results)

    def test_retrieve_no_crash_on_empty_query(self):
        svc = _make_retrieval_service()
        results = svc.retrieve("")   # should not raise
        assert isinstance(results, list)

    def test_build_retrieval_service_factory(self):
        """build_retrieval_service() with mocked deps returns a RetrievalService."""
        mock_vs  = MagicMock()
        mock_cef = MagicMock()
        svc = build_retrieval_service(
            spark=None, vs_service=mock_vs, current_filter=mock_cef
        )
        assert isinstance(svc, RetrievalService)

    def test_build_retrieval_service_no_args(self):
        """build_retrieval_service() with no args falls back to VS defaults."""
        # Should not crash — VS may be unavailable but the object is created
        # (VS init is lazy / deferred until first call)
        try:
            svc = build_retrieval_service()
            assert svc is not None
        except Exception:
            pass  # acceptable if VS is not configured in unit-test env


# ===========================================================================
# TestRecallBoostUnit — unit tests for recall-boost config and service
# ===========================================================================

class TestRecallBoostUnit:
    """Unit tests for recall boost config (no VS calls)."""

    def test_known_recall_signals_is_dict(self):
        from platform.v4.services.concepts import KNOWN_RECALL_SIGNALS
        assert isinstance(KNOWN_RECALL_SIGNALS, dict)
        assert len(KNOWN_RECALL_SIGNALS) > 0

    def test_offset_concept_has_recall_signals(self):
        from platform.v4.services.concepts import KNOWN_RECALL_SIGNALS
        offset_key = next(
            (k for k in KNOWN_RECALL_SIGNALS if "offset" in k.lower()), None
        )
        assert offset_key is not None, "Offset clause must be in KNOWN_RECALL_SIGNALS"
        signals = KNOWN_RECALL_SIGNALS[offset_key]
        assert len(signals) > 0

    def test_recall_boost_service_constructs(self):
        from platform.v4.services.recall_boost import RecallBoostService
        mock_spark = MagicMock()
        svc = RecallBoostService(spark=mock_spark)
        assert svc is not None

    def test_known_recall_signals_all_concepts(self):
        """Core BSC concepts should have recall signals."""
        from platform.v4.services.concepts import KNOWN_RECALL_SIGNALS
        # Use partial-name matching to handle variants like
        # "division of financial responsibility" (not "dofr")
        required_partials = ["offset", "financial responsibility", "ipa"]
        krc_lower = {k.lower() for k in KNOWN_RECALL_SIGNALS}
        for concept in required_partials:
            has_match = any(concept in k for k in krc_lower)
            assert has_match, (
                f"'{concept}' concept missing from KNOWN_RECALL_SIGNALS\n"
                f"  Available: {sorted(krc_lower)}"
            )


# ===========================================================================
# Live fixtures and live tests — require Spark + VS index
# ===========================================================================

@pytest.fixture(scope="module")
def live_retrieval_service():
    """
    Live fixture: builds a real RetrievalService against the VS index.
    Requires an active Databricks Spark session.
    Skip with: pytest -m "not live"
    """
    pytest.importorskip(
        "databricks.vector_search.client",
        reason="databricks-vectorsearch not installed",
    )
    try:
        from pyspark.sql import SparkSession
        spark = SparkSession.getActiveSession()
        if spark is None:
            pytest.skip("No active Spark session — run in Databricks notebook")
    except ImportError:
        pytest.skip("PySpark not available")

    from platform.v4.config.workspace_config import WorkspaceConfig
    from platform.v4.services.vector_search_service import VectorSearchService
    from platform.v4.core.current_effective_filter import CurrentEffectiveFilter

    config = WorkspaceConfig.from_spark(spark)
    vs_svc = VectorSearchService(
        endpoint=config.vs_endpoint,
        index_fulltext=config.vs_index_fulltext,
        index_legal=config.vs_index_legal,
    )
    cef = CurrentEffectiveFilter(spark=spark)
    return build_retrieval_service(
        spark=spark, vs_service=vs_svc, current_filter=cef
    )


@pytest.mark.live
@pytest.mark.parametrize("qid,query,provider,min_hits", _LIVE_RECALL_SET)
def test_v3_retrieval_hit_rate_live(qid, query, provider, min_hits, live_retrieval_service):
    """
    P3-REG-1 Recall@10: V3 returns >= min_hits results (95% of V2 baseline).
    """
    results = live_retrieval_service.retrieve(
        query, provider_name=provider, top_k=10
    )
    assert len(results) >= min_hits, (
        f"[{qid}] V3 recall: expected >={min_hits} hits, got {len(results)}\n"
        f"  Query: {query[:80]}\n"
        f"  Provider: {provider}\n"
        f"  (V2 baseline: {_V2_BASELINE_HITS.get(qid, '?')} hits)"
    )


@pytest.mark.live
@pytest.mark.parametrize("qid,query,provider,required_keywords", _KEYWORD_RECALL_CHECKS)
def test_v3_retrieval_keyword_coverage_live(
    qid, query, provider, required_keywords, live_retrieval_service
):
    """
    Top-10 results collectively contain each required keyword for the concept.
    """
    results = live_retrieval_service.retrieve(
        query, provider_name=provider, top_k=10
    )
    combined = " ".join(r.get("chunk_text", "") for r in results).lower()
    missing = [kw for kw in required_keywords if kw.lower() not in combined]
    assert not missing, (
        f"[{qid}] Missing keywords in top-10: {missing}\n"
        f"  Query: {query[:80]}"
    )


@pytest.mark.live
def test_v3_recall_parity_aggregate_live(live_retrieval_service):
    """
    Aggregate P3-REG-1 gate: >=95% of queries meet the 95%-of-V2-baseline threshold.
    """
    pass_count = 0
    fail_details: List[str] = []
    for qid, query, provider, min_hits in _LIVE_RECALL_SET:
        results = live_retrieval_service.retrieve(
            query, provider_name=provider, top_k=10
        )
        if len(results) >= min_hits:
            pass_count += 1
        else:
            fail_details.append(
                f"  {qid}: expected >={min_hits}, got {len(results)}"
            )
    total = len(_LIVE_RECALL_SET)
    pass_rate = pass_count / total
    assert pass_rate >= 0.95, (
        f"P3-REG-1 aggregate recall FAIL: {pass_count}/{total} = {pass_rate:.1%} "
        f"(threshold 95%)\nFailing:\n" + "\n".join(fail_details)
    )
