"""
Tests for platform/v4/core/current_effective_filter.py

W7-2: Current-effective document filter for retrieval results.
"""
import time
from dataclasses import dataclass, field
from typing import Optional
from unittest.mock import MagicMock, patch

import pytest

from platform.v4.core.current_effective_filter import CurrentEffectiveFilter


# ---------------------------------------------------------------------------
# Test fixtures
# ---------------------------------------------------------------------------

@dataclass
class FakePassage:
    """Mimics RetrievedPassage for testing."""
    doc_id: str = ""
    provider_name: str = ""
    text: str = "sample passage text"
    score: float = 0.9
    channel: str = "semantic"
    page_number: Optional[int] = 1
    section: Optional[str] = None
    is_current_effective: bool = False
    metadata: dict = field(default_factory=dict)


def _make_passage(filename: str, provider: str = "TestProvider") -> FakePassage:
    return FakePassage(
        doc_id=filename,
        provider_name=provider,
        metadata={"source_filename": filename, "rank": 0},
    )


def _mock_spark_with_filenames(current_filenames: list, total: int = 10, expired: int = 2):
    """Create a mock Spark session that returns specified current filenames."""
    mock_spark = MagicMock()

    # Mock for the SELECT DISTINCT query
    filename_rows = [MagicMock(source_filename=f) for f in current_filenames]
    # Mock for the COUNT query
    stats_row = MagicMock(total=total, expired=expired)

    def sql_side_effect(query):
        result = MagicMock()
        if "COUNT" in query:
            result.collect.return_value = [stats_row]
        elif "DISTINCT source_filename" in query:
            result.collect.return_value = filename_rows
        else:
            result.collect.return_value = []
        return result

    mock_spark.sql.side_effect = sql_side_effect
    return mock_spark


# ---------------------------------------------------------------------------
# Tests: Initialization and caching
# ---------------------------------------------------------------------------

class TestCacheLoading:
    """Tests for lazy-load and TTL cache behavior."""

    def test_lazy_load_on_first_apply(self):
        """Cache is NOT loaded until first apply() call."""
        spark = _mock_spark_with_filenames(["file_a.pdf", "file_b.pdf"])
        filt = CurrentEffectiveFilter(spark=spark)
        # Not loaded yet
        assert filt._current_filenames is None
        spark.sql.assert_not_called()

    def test_loads_on_first_apply(self):
        """First apply() triggers SQL query."""
        spark = _mock_spark_with_filenames(["file_a.pdf", "file_b.pdf"])
        filt = CurrentEffectiveFilter(spark=spark)
        passages = [_make_passage("file_a.pdf")]
        result = filt.apply(passages)
        assert spark.sql.called
        assert filt._current_filenames == {"file_a.pdf", "file_b.pdf"}

    def test_cache_reused_within_ttl(self):
        """Second call within TTL reuses cache (no new SQL)."""
        spark = _mock_spark_with_filenames(["file_a.pdf"])
        filt = CurrentEffectiveFilter(spark=spark, ttl_seconds=3600)
        filt.apply([_make_passage("file_a.pdf")])
        call_count = spark.sql.call_count
        filt.apply([_make_passage("file_a.pdf")])
        assert spark.sql.call_count == call_count  # no new calls

    def test_cache_refreshes_after_ttl(self):
        """Cache refreshes when TTL expires."""
        spark = _mock_spark_with_filenames(["file_a.pdf"])
        filt = CurrentEffectiveFilter(spark=spark, ttl_seconds=1)
        filt.apply([_make_passage("file_a.pdf")])
        initial_calls = spark.sql.call_count
        # Simulate time passing beyond TTL
        filt._loaded_at = time.time() - 2
        filt.apply([_make_passage("file_a.pdf")])
        assert spark.sql.call_count > initial_calls

    def test_invalidate_forces_reload(self):
        """invalidate() clears cache; next call reloads."""
        spark = _mock_spark_with_filenames(["file_a.pdf"])
        filt = CurrentEffectiveFilter(spark=spark)
        filt.apply([_make_passage("file_a.pdf")])
        filt.invalidate()
        assert filt._current_filenames is None
        filt.apply([_make_passage("file_a.pdf")])
        # Two loads total (initial + post-invalidate)
        assert spark.sql.call_count == 4  # 2 queries per load


# ---------------------------------------------------------------------------
# Tests: Filtering logic
# ---------------------------------------------------------------------------

class TestFilterLogic:
    """Tests for correct passage filtering."""

    def test_keeps_current_passages(self):
        """Passages from current-effective docs are kept."""
        spark = _mock_spark_with_filenames(["current_a.pdf", "current_b.pdf"])
        filt = CurrentEffectiveFilter(spark=spark)
        passages = [
            _make_passage("current_a.pdf"),
            _make_passage("current_b.pdf"),
        ]
        result = filt.apply(passages)
        assert len(result) == 2

    def test_removes_expired_passages(self):
        """Passages from expired docs are removed."""
        spark = _mock_spark_with_filenames(["current.pdf"])
        filt = CurrentEffectiveFilter(spark=spark)
        passages = [
            _make_passage("current.pdf"),
            _make_passage("expired_2020.pdf"),
            _make_passage("expired_2021.pdf"),
        ]
        result = filt.apply(passages, keep_minimum=0)
        assert len(result) == 1
        assert result[0].metadata["source_filename"] == "current.pdf"

    def test_mixed_current_and_expired(self):
        """Mix of current and expired: only current survive."""
        spark = _mock_spark_with_filenames(["active_1.pdf", "active_2.pdf"])
        filt = CurrentEffectiveFilter(spark=spark)
        passages = [
            _make_passage("active_1.pdf"),
            _make_passage("old_1.pdf"),
            _make_passage("active_2.pdf"),
            _make_passage("old_2.pdf"),
        ]
        result = filt.apply(passages, keep_minimum=0)
        assert len(result) == 2
        fnames = [p.metadata["source_filename"] for p in result]
        assert "active_1.pdf" in fnames
        assert "active_2.pdf" in fnames

    def test_marks_current_passages_is_current_true(self):
        """Surviving passages get is_current_effective=True."""
        spark = _mock_spark_with_filenames(["current.pdf"])
        filt = CurrentEffectiveFilter(spark=spark)
        passages = [_make_passage("current.pdf")]
        result = filt.apply(passages)
        assert result[0].is_current_effective is True

    def test_empty_passages_returns_empty(self):
        """Empty input returns empty output."""
        spark = _mock_spark_with_filenames(["x.pdf"])
        filt = CurrentEffectiveFilter(spark=spark)
        assert filt.apply([]) == []

    def test_all_expired_below_minimum(self):
        """When ALL passages are expired but count >= keep_minimum, return filtered (empty)."""
        spark = _mock_spark_with_filenames(["current.pdf"])
        filt = CurrentEffectiveFilter(spark=spark)
        # 2 expired passages, keep_minimum=3 -> returns original (safety)
        passages = [
            _make_passage("expired_a.pdf"),
            _make_passage("expired_b.pdf"),
        ]
        result = filt.apply(passages, keep_minimum=3)
        # Only 2 passages total < keep_minimum of 3, so filter applies normally
        # (keep_minimum only relaxes when len(passages) >= keep_minimum)
        assert len(result) == 0


# ---------------------------------------------------------------------------
# Tests: Safety — keep_minimum
# ---------------------------------------------------------------------------

class TestKeepMinimum:
    """Tests for the safety valve that prevents zero-result starvation."""

    def test_relaxes_when_would_reduce_below_minimum(self):
        """If filtering drops below keep_minimum but original has enough, return all."""
        spark = _mock_spark_with_filenames(["current.pdf"])
        filt = CurrentEffectiveFilter(spark=spark)
        # 5 passages but only 1 is current; keep_minimum=3
        passages = [
            _make_passage("current.pdf"),
            _make_passage("expired_1.pdf"),
            _make_passage("expired_2.pdf"),
            _make_passage("expired_3.pdf"),
            _make_passage("expired_4.pdf"),
        ]
        result = filt.apply(passages, keep_minimum=3)
        # Relaxed: returns all 5, but marks non-current
        assert len(result) == 5
        current_flags = [p.is_current_effective for p in result]
        assert current_flags.count(True) == 1
        assert current_flags.count(False) == 4

    def test_does_not_relax_when_enough_current(self):
        """No relaxation needed when enough passages pass filter."""
        spark = _mock_spark_with_filenames(["a.pdf", "b.pdf", "c.pdf"])
        filt = CurrentEffectiveFilter(spark=spark)
        passages = [
            _make_passage("a.pdf"),
            _make_passage("b.pdf"),
            _make_passage("c.pdf"),
            _make_passage("expired.pdf"),
        ]
        result = filt.apply(passages, keep_minimum=3)
        assert len(result) == 3  # 3 current, expired removed

    def test_default_keep_minimum_is_3(self):
        """Default keep_minimum=3 is applied."""
        spark = _mock_spark_with_filenames(["only.pdf"])
        filt = CurrentEffectiveFilter(spark=spark)
        passages = [
            _make_passage("only.pdf"),
            _make_passage("old1.pdf"),
            _make_passage("old2.pdf"),
            _make_passage("old3.pdf"),
        ]
        # 1 current < keep_minimum=3, and total >= 3: relaxes
        result = filt.apply(passages)
        assert len(result) == 4  # all returned with flags


# ---------------------------------------------------------------------------
# Tests: is_current() single-file check
# ---------------------------------------------------------------------------

class TestIsCurrent:
    """Tests for the single-file predicate."""

    def test_current_file_returns_true(self):
        spark = _mock_spark_with_filenames(["active.pdf"])
        filt = CurrentEffectiveFilter(spark=spark)
        assert filt.is_current("active.pdf") is True

    def test_expired_file_returns_false(self):
        spark = _mock_spark_with_filenames(["active.pdf"])
        filt = CurrentEffectiveFilter(spark=spark)
        assert filt.is_current("expired.pdf") is False

    def test_empty_cache_returns_true(self):
        """Fail-open: if cache is empty, assume current."""
        spark = _mock_spark_with_filenames([])
        filt = CurrentEffectiveFilter(spark=spark)
        assert filt.is_current("anything.pdf") is True


# ---------------------------------------------------------------------------
# Tests: Fail-open behavior
# ---------------------------------------------------------------------------

class TestFailOpen:
    """Tests for graceful degradation when Spark query fails."""

    def test_spark_exception_returns_all_passages(self):
        """If Spark SQL throws, filter returns all passages (fail open)."""
        spark = MagicMock()
        spark.sql.side_effect = Exception("Connection lost")
        filt = CurrentEffectiveFilter(spark=spark)
        passages = [
            _make_passage("a.pdf"),
            _make_passage("b.pdf"),
        ]
        result = filt.apply(passages)
        # Fail open: returns all
        assert len(result) == 2

    def test_null_filenames_skipped(self):
        """Rows with NULL source_filename are excluded from cache."""
        mock_spark = MagicMock()
        rows = [
            MagicMock(source_filename="good.pdf"),
            MagicMock(source_filename=None),
            MagicMock(source_filename=""),
        ]
        stats_row = MagicMock(total=3, expired=0)

        def sql_side_effect(query):
            result = MagicMock()
            if "DISTINCT source_filename" in query:
                result.collect.return_value = rows
            else:
                result.collect.return_value = [stats_row]
            return result

        mock_spark.sql.side_effect = sql_side_effect
        filt = CurrentEffectiveFilter(spark=mock_spark)
        filt.apply([_make_passage("good.pdf")])
        # Only "good.pdf" in cache (None and "" skipped)
        assert filt._current_filenames == {"good.pdf"}


# ---------------------------------------------------------------------------
# Tests: Stats property
# ---------------------------------------------------------------------------

class TestStats:
    """Tests for the stats/telemetry property."""

    def test_stats_before_load(self):
        spark = _mock_spark_with_filenames([])
        filt = CurrentEffectiveFilter(spark=spark)
        stats = filt.stats
        assert stats["cached_filenames"] == 0
        assert stats["cache_age_s"] is None

    def test_stats_after_load(self):
        spark = _mock_spark_with_filenames(["a.pdf", "b.pdf"], total=10, expired=3)
        filt = CurrentEffectiveFilter(spark=spark)
        filt.apply([_make_passage("a.pdf")])
        stats = filt.stats
        assert stats["cached_filenames"] == 2
        assert stats["total_docs"] == 10
        assert stats["expired_docs"] == 3
        assert stats["ttl_s"] == 3600
        assert stats["cache_age_s"] is not None


# ---------------------------------------------------------------------------
# Tests: Integration with RetrievalAdapter (current_only param)
# ---------------------------------------------------------------------------

class TestAdapterIntegration:
    """Tests for the current_only bypass in RetrievalAdapter._call()."""

    def test_current_only_false_skips_filter(self):
        """When current_only=False, filter is not applied."""
        from platform.v4.adapters.retrieval_adapter import RetrievalAdapter

        spark = _mock_spark_with_filenames(["current.pdf"])
        filt = CurrentEffectiveFilter(spark=spark)

        # Mock retrieve_fn returns raw chunks
        def mock_retrieve(query, top_k=10, **kwargs):
            return [
                {"unit_id": "expired.pdf", "unit_text": "text", "provider_name": "P",
                 "source_filename": "expired.pdf", "score": 0.9, "channel": "bm25"},
            ]

        adapter = RetrievalAdapter(
            retrieve_fn=mock_retrieve,
            current_effective_filter=filt,
        )
        result = adapter.retrieve("test query", current_only=False)
        # Should NOT be filtered — expired.pdf survives
        assert result.success
        assert len(result.data) == 1

    def test_current_only_true_applies_filter(self):
        """When current_only=True (default), filter is applied."""
        from platform.v4.adapters.retrieval_adapter import RetrievalAdapter

        spark = _mock_spark_with_filenames(["current.pdf"])
        filt = CurrentEffectiveFilter(spark=spark)

        def mock_retrieve(query, top_k=10, **kwargs):
            return [
                {"unit_id": "current.pdf", "unit_text": "text1", "provider_name": "P",
                 "source_filename": "current.pdf", "score": 0.9, "channel": "bm25"},
                {"unit_id": "expired.pdf", "unit_text": "text2", "provider_name": "P",
                 "source_filename": "expired.pdf", "score": 0.8, "channel": "bm25"},
            ]

        adapter = RetrievalAdapter(
            retrieve_fn=mock_retrieve,
            current_effective_filter=filt,
        )
        result = adapter.retrieve("test query", current_only=True)
        assert result.success
        # Only current.pdf survives (but keep_minimum=3 might relax...)
        # With 2 passages, 1 current, keep_minimum=3 won't relax (2 < 3)
        # So only current.pdf returned
        assert len(result.data) == 1
        assert result.data[0].metadata["source_filename"] == "current.pdf"

    def test_no_filter_when_not_injected(self):
        """When no filter is injected, all passages returned."""
        from platform.v4.adapters.retrieval_adapter import RetrievalAdapter

        def mock_retrieve(query, top_k=10, **kwargs):
            return [
                {"unit_id": "expired.pdf", "unit_text": "text", "provider_name": "P",
                 "source_filename": "expired.pdf", "score": 0.9, "channel": "bm25"},
            ]

        adapter = RetrievalAdapter(
            retrieve_fn=mock_retrieve,
            current_effective_filter=None,
        )
        result = adapter.retrieve("test query", current_only=True)
        assert result.success
        assert len(result.data) == 1  # No filter, all pass through


# ---------------------------------------------------------------------------
# Tests: Edge cases
# ---------------------------------------------------------------------------

class TestEdgeCases:
    """Edge cases and boundary conditions."""

    def test_passage_with_no_metadata(self):
        """Passage without metadata dict is included (fail open)."""
        spark = _mock_spark_with_filenames(["current.pdf"])
        filt = CurrentEffectiveFilter(spark=spark)
        passage = FakePassage(doc_id="unknown.pdf", metadata={})
        result = filt.apply([passage])
        # No source_filename in metadata, but doc_id='unknown.pdf' not in cache
        # However fallback checks doc_id: 'unknown.pdf' not in {current.pdf}
        # -> filtered out, BUT only 1 passage < keep_minimum=3, AND len(passages)=1 < 3
        # -> keep_minimum does NOT relax, returns empty
        assert len(result) == 0

    def test_passage_with_doc_id_fallback(self):
        """When metadata has no source_filename, falls back to doc_id."""
        spark = _mock_spark_with_filenames(["via_docid.pdf"])
        filt = CurrentEffectiveFilter(spark=spark)
        passage = FakePassage(doc_id="via_docid.pdf", metadata={})
        result = filt.apply([passage])
        assert len(result) == 1

    def test_large_cache(self):
        """Filter handles large caches efficiently."""
        filenames = [f"contract_{i:05d}.pdf" for i in range(1000)]
        spark = _mock_spark_with_filenames(filenames, total=1200, expired=200)
        filt = CurrentEffectiveFilter(spark=spark)
        passages = [_make_passage(f"contract_{i:05d}.pdf") for i in range(50)]
        result = filt.apply(passages)
        assert len(result) == 50  # all in cache

    def test_custom_table_name(self):
        """Custom table name is used in SQL query."""
        spark = _mock_spark_with_filenames(["a.pdf"])
        filt = CurrentEffectiveFilter(spark=spark, table="prod.contracts.documents")
        filt.apply([_make_passage("a.pdf")])
        # Verify the custom table was used in the query
        sql_calls = [str(c) for c in spark.sql.call_args_list]
        assert any("prod.contracts.documents" in s for s in sql_calls)
