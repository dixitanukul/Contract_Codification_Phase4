"""Tests for MultiConceptTool (P4F)."""
from __future__ import annotations

from collections import OrderedDict
from unittest.mock import MagicMock
import pandas as pd
import pytest

from platform.v4.tools.multi_concept import MultiConceptTool
from platform.v4.contracts.tool_types import ToolStatus


# ── Mock helpers ─────────────────────────────────────────────────────────────

class MockDF:
    def __init__(self, pdf):
        self._pdf = pdf
    def toPandas(self):
        return self._pdf


class MockSpark:
    def __init__(self, patterns: "OrderedDict"):
        self._patterns = patterns

    def sql(self, query: str) -> MockDF:
        for pattern, pdf in self._patterns.items():
            if pattern in query:
                return MockDF(pdf)
        return MockDF(pd.DataFrame({"provider_name": []}))


class MockProviderService:
    def __init__(self, universe=None):
        self._universe = universe or ["Sutter Health", "Kaiser", "Providence", "UCSF", "Dignity Health"]

    def corpus_universe(self):
        return self._universe

    def all_names(self):
        return self._universe

    def resolve(self, name):
        return ([name], "unresolved", [])


class MockLLMClient:
    def __init__(self, response='["offset clause", "auto-renewal"]'):
        self._response = response

    def chat(self, model, system, user, max_tokens, temperature=0.0):
        return self._response


FULLTEXT_OFFSET = pd.DataFrame({"provider_name": ["Sutter Health", "Kaiser", "Providence"]})
FULLTEXT_RENEWAL = pd.DataFrame({"provider_name": ["Kaiser", "Dignity Health"]})
TERMS_EMPTY = pd.DataFrame({"provider_name": []})


# ── Init ─────────────────────────────────────────────────────────────────────

class TestMultiConceptToolInit:
    def test_name(self):
        t = MultiConceptTool(spark=None, provider_service=MockProviderService())
        assert t.name == "multi_concept"

    def test_not_adapter_backed(self):
        t = MultiConceptTool(spark=None, provider_service=MockProviderService())
        assert t.is_adapter_backed is False

    def test_llm_optional(self):
        t = MultiConceptTool(spark=None, provider_service=MockProviderService())
        assert t._llm_client is None


# ── Validation ────────────────────────────────────────────────────────────────

class TestMultiConceptToolValidation:
    def test_requires_question(self):
        t = MultiConceptTool(spark=None, provider_service=MockProviderService())
        errors = t.validate_inputs()
        assert errors

    def test_passes_with_question(self):
        t = MultiConceptTool(spark=None, provider_service=MockProviderService())
        errors = t.validate_inputs(question="Which providers have offset AND auto-renewal?")
        assert errors == []


# ── Operator detection ────────────────────────────────────────────────────────

class TestOperatorDetection:
    def setup_method(self):
        self.tool = MultiConceptTool(spark=None, provider_service=MockProviderService())

    def test_and_gives_intersection(self):
        assert self.tool._detect_operator("have offset clause and auto-renewal") == "INTERSECTION"

    def test_but_not_gives_difference(self):
        assert self.tool._detect_operator("have offset but not auto-renewal") == "DIFFERENCE"

    def test_without_gives_difference(self):
        assert self.tool._detect_operator("have offset without auto-renewal") == "DIFFERENCE"

    def test_or_gives_union(self):
        assert self.tool._detect_operator("have offset or auto-renewal") == "UNION"

    def test_default_is_intersection(self):
        assert self.tool._detect_operator("some question") == "INTERSECTION"


# ── Concept extraction ────────────────────────────────────────────────────────

class TestConceptExtraction:
    def setup_method(self):
        self.tool = MultiConceptTool(spark=None, provider_service=MockProviderService())

    def test_have_and_pattern(self):
        cs = self.tool._extract_concepts("Which providers have offset clause and auto-renewal?")
        assert len(cs) == 2
        assert "offset clause" in cs[0]
        assert "auto-renewal" in cs[1]

    def test_have_but_not_pattern(self):
        cs = self.tool._extract_concepts("Which providers have offset clause but not auto-renewal?")
        assert len(cs) == 2

    def test_both_and_pattern(self):
        cs = self.tool._extract_concepts("providers with both DOFR and IPA delegation?")
        assert len(cs) == 2

    def test_llm_fallback_used_when_no_regex_match(self):
        llm = MockLLMClient('["offset clause", "dispute resolution"]')
        t = MultiConceptTool(spark=None, provider_service=MockProviderService(), llm_client=llm)
        cs = t._extract_concepts("complicated question without clear pattern")
        assert len(cs) == 2

    def test_llm_fallback_handles_invalid_json(self):
        llm = MockLLMClient("not valid json")
        t = MultiConceptTool(spark=None, provider_service=MockProviderService(), llm_client=llm)
        cs = t._extract_concepts("some question")
        assert cs == []

    def test_returns_empty_when_no_match_and_no_llm(self):
        cs = self.tool._extract_concepts("some unstructured question")
        assert cs == []


# ── Search concept ────────────────────────────────────────────────────────────

class TestSearchConcept:
    def test_returns_union_of_fulltext_and_terms(self):
        patterns = OrderedDict([
            ("tbl_vs_unified_ready", pd.DataFrame({"provider_name": ["Sutter", "Kaiser"]})),
            ("vw_genie_contract_terms", pd.DataFrame({"provider_name": ["Providence"]})),
        ])
        t = MultiConceptTool(spark=MockSpark(patterns), provider_service=MockProviderService())
        concept, pset = t._search_concept("offset clause")
        assert "Sutter" in pset
        assert "Kaiser" in pset
        assert "Providence" in pset

    def test_handles_sql_exception_gracefully(self):
        class BrokenSpark:
            def sql(self, q):
                raise RuntimeError("error")

        t = MultiConceptTool(spark=BrokenSpark(), provider_service=MockProviderService())
        concept, pset = t._search_concept("offset clause")
        assert concept == "offset clause"
        assert pset == set()


# ── Full _run ─────────────────────────────────────────────────────────────────

class TestMultiConceptToolRun:
    def test_insufficient_concepts_returns_error(self):
        t = MultiConceptTool(spark=None, provider_service=MockProviderService())
        result = t._run("Which providers have offset clause?")
        assert not result.success

    def test_explicit_concepts_bypass_extraction(self):
        patterns = OrderedDict([
            ("tbl_vs_unified_ready", pd.DataFrame({"provider_name": ["Sutter"]})),
            ("vw_genie_contract_terms", pd.DataFrame({"provider_name": []})),
        ])
        t = MultiConceptTool(spark=MockSpark(patterns), provider_service=MockProviderService())
        result = t._run("?", concepts=["offset clause", "auto-renewal"])
        assert result.success
        assert result.data["concepts"] == ["offset clause", "auto-renewal"]

    def test_intersection_result(self):
        # set_a = {Sutter, Kaiser}, set_b = {Kaiser, Providence}
        # intersection = {Kaiser}
        call_count = [0]
        provider_sets = [
            pd.DataFrame({"provider_name": ["Sutter Health", "Kaiser"]}),
            pd.DataFrame({"provider_name": ["Kaiser", "Providence"]}),
        ]

        class SequentialSpark:
            def sql(self, q):
                if "tbl_vs_unified_ready" in q:
                    idx = call_count[0]
                    call_count[0] += 1
                    return MockDF(provider_sets[min(idx, 1)])
                return MockDF(pd.DataFrame({"provider_name": []}))

        t = MultiConceptTool(
            spark=SequentialSpark(), provider_service=MockProviderService()
        )
        result = t._run("?", concepts=["concept_a", "concept_b"], operator="INTERSECTION")
        assert result.success
        assert result.data["operator"] == "INTERSECTION"
        assert result.data["venn"]["both"] >= 0

    def test_difference_result(self):
        patterns = OrderedDict([
            ("tbl_vs_unified_ready", pd.DataFrame({"provider_name": ["Sutter", "Kaiser"]})),
            ("vw_genie_contract_terms", pd.DataFrame({"provider_name": []})),
        ])
        t = MultiConceptTool(spark=MockSpark(patterns), provider_service=MockProviderService())
        result = t._run("?", concepts=["offset", "auto-renewal"], operator="DIFFERENCE")
        assert result.success
        assert result.data["operator"] == "DIFFERENCE"

    def test_union_result(self):
        patterns = OrderedDict([
            ("tbl_vs_unified_ready", pd.DataFrame({"provider_name": ["Sutter"]})),
            ("vw_genie_contract_terms", pd.DataFrame({"provider_name": []})),
        ])
        t = MultiConceptTool(spark=MockSpark(patterns), provider_service=MockProviderService())
        result = t._run("?", concepts=["offset", "renewal"], operator="UNION")
        assert result.data["operator"] == "UNION"

    def test_completeness_keys(self):
        patterns = OrderedDict([
            ("tbl_vs_unified_ready", pd.DataFrame({"provider_name": []})),
        ])
        t = MultiConceptTool(spark=MockSpark(patterns), provider_service=MockProviderService())
        result = t._run("?", concepts=["a", "b"])
        keys = set(result.data["completeness"].keys())
        assert "concept_a_count" in keys
        assert "universe_size" in keys

    def test_venn_keys(self):
        patterns = OrderedDict([
            ("tbl_vs_unified_ready", pd.DataFrame({"provider_name": []})),
        ])
        t = MultiConceptTool(spark=MockSpark(patterns), provider_service=MockProviderService())
        result = t._run("?", concepts=["a", "b"])
        assert {"only_a", "both", "only_b", "neither"} <= set(result.data["venn"].keys())

    def test_empty_result_set_gives_empty_status(self):
        # universe = ["X"], but concept SQL returns nothing
        patterns = OrderedDict([
            ("tbl_vs_unified_ready", pd.DataFrame({"provider_name": []})),
            ("vw_genie_contract_terms", pd.DataFrame({"provider_name": []})),
        ])
        t = MultiConceptTool(
            spark=MockSpark(patterns),
            provider_service=MockProviderService(universe=["X"]),
        )
        result = t._run("?", concepts=["alpha", "beta"], operator="INTERSECTION")
        assert result.status == ToolStatus.EMPTY
