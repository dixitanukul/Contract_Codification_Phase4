"""
platform/v4/tests/test_provenance.py

W9-17: Tests for source provenance chain.
"""
from __future__ import annotations

import pytest

from platform.v4.core.provenance import ProvenanceChain, ProvenanceResolver


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def resolver_no_spark():
    """ProvenanceResolver without Spark — builds partial chains."""
    return ProvenanceResolver(spark=None)


def _sample_citation(**overrides) -> dict:
    base = {
        "passage_text": "Provider shall offset amounts owed against overpayments.",
        "source_filename": "129075504_Sutter_Coast_Hospital_440185687_Base_v1.pdf",
        "page_number": 12,
        "chunk_index": 3,
        "total_pages": 45,
        "provider_name": "Sutter Coast Hospital",
        "source_doc_id": "chunk_12345",
        "score": 0.87,
        "is_current_effective": True,
        "doc_role": "base_agreement",
    }
    base.update(overrides)
    return base


# ---------------------------------------------------------------------------
# ProvenanceChain dataclass
# ---------------------------------------------------------------------------

class TestProvenanceChain:
    def test_complete_chain(self):
        chain = ProvenanceChain(
            passage_text="Some text",
            source_filename="129075504_Hosp_440185687_Base_v1.pdf",
            pdf_path="/Volumes/dev_adb/raw/files/129075504_Hosp_440185687_Base_v1.pdf",
            contract_id="440185687",
        )
        assert chain.is_complete
        assert not chain.is_partial

    def test_partial_chain_no_pdf_path(self):
        chain = ProvenanceChain(
            passage_text="Some text",
            source_filename="file.pdf",
            pdf_path="",
            contract_id="",
        )
        assert chain.is_partial
        assert not chain.is_complete

    def test_empty_chain(self):
        chain = ProvenanceChain()
        assert not chain.is_complete
        assert not chain.is_partial

    def test_to_dict_has_all_fields(self):
        chain = ProvenanceChain(
            claim_text="offset clause exists",
            passage_text="Provider shall offset...",
            source_filename="test.pdf",
            pdf_path="/Volumes/dev_adb/raw/files/test.pdf",
            contract_id="123456",
            provider_name="Test Hospital",
            doc_role="base_agreement",
            effective_date="2024-01-01",
            page_number=5,
        )
        d = chain.to_dict()
        assert d["claim_text"] == "offset clause exists"
        assert d["source_filename"] == "test.pdf"
        assert d["pdf_path"] == "/Volumes/dev_adb/raw/files/test.pdf"
        assert d["contract_id"] == "123456"
        assert d["page_number"] == 5
        assert d["is_complete"] is True

    def test_to_display_str(self):
        chain = ProvenanceChain(
            provider_name="Sutter Coast Hospital",
            source_filename="test.pdf",
            page_number=12,
            total_pages=45,
            doc_role="amendment",
            effective_date="2024-03-15",
            contract_id="440185687",
        )
        display = chain.to_display_str()
        assert "Sutter Coast Hospital" in display
        assert "test.pdf" in display
        assert "12/45" in display
        assert "amendment" in display
        assert "2024-03-15" in display
        assert "440185687" in display

    def test_passage_preview_truncation(self):
        long_text = "A" * 500
        chain = ProvenanceChain(passage_text=long_text)
        assert len(chain.to_dict()["passage_preview"]) == 200


# ---------------------------------------------------------------------------
# ProvenanceResolver — no Spark
# ---------------------------------------------------------------------------

class TestProvenanceResolverNoSpark:
    def test_resolve_builds_partial_chain(self, resolver_no_spark):
        cit = _sample_citation()
        chain = resolver_no_spark.resolve(cit, claim_text="test claim")

        assert chain.claim_text == "test claim"
        assert chain.passage_text == cit["passage_text"]
        assert chain.page_number == 12
        assert chain.source_filename == cit["source_filename"]
        assert chain.provider_name == "Sutter Coast Hospital"
        assert chain.retrieval_score == 0.87
        assert chain.pdf_path.endswith(cit["source_filename"])

    def test_pdf_path_built_from_filename(self, resolver_no_spark):
        cit = _sample_citation(source_filename="test_file.pdf")
        chain = resolver_no_spark.resolve(cit)
        assert chain.pdf_path == "/Volumes/dev_adb/raw/files/test_file.pdf"

    def test_empty_filename_gives_empty_path(self, resolver_no_spark):
        cit = _sample_citation(source_filename="")
        chain = resolver_no_spark.resolve(cit)
        assert chain.pdf_path == ""

    def test_contract_id_parsed_from_filename(self, resolver_no_spark):
        cit = _sample_citation(
            source_filename="129075504_Sutter_Coast_Hospital_440185687_Base_v1.pdf"
        )
        chain = resolver_no_spark.resolve(cit)
        assert chain.contract_id == "440185687"

    def test_contract_id_parsing_amendment(self, resolver_no_spark):
        cit = _sample_citation(
            source_filename="129097205_Desert_Regional_Medical_Center_355258177_NineteenthAmend_v2.PDF"
        )
        chain = resolver_no_spark.resolve(cit)
        assert chain.contract_id == "355258177"

    def test_contract_id_provided_in_citation(self, resolver_no_spark):
        cit = _sample_citation(contract_id="999888777")
        chain = resolver_no_spark.resolve(cit)
        assert chain.contract_id == "999888777"  # Uses provided, not parsed

    def test_doc_role_from_citation(self, resolver_no_spark):
        cit = _sample_citation(doc_role="amendment")
        chain = resolver_no_spark.resolve(cit)
        assert chain.doc_role == "amendment"

    def test_chunk_text_fallback(self, resolver_no_spark):
        """Supports chunk_text key from VS ready table."""
        cit = {"chunk_text": "Some passage", "source_filename": "f.pdf"}
        chain = resolver_no_spark.resolve(cit)
        assert chain.passage_text == "Some passage"

    def test_unit_text_fallback(self, resolver_no_spark):
        """Supports unit_text key from legal units index."""
        cit = {"unit_text": "Legal unit passage", "source_filename": "g.pdf"}
        chain = resolver_no_spark.resolve(cit)
        assert chain.passage_text == "Legal unit passage"

    def test_resolve_batch(self, resolver_no_spark):
        citations = [_sample_citation(page_number=i) for i in range(5)]
        chains = resolver_no_spark.resolve_batch(citations, claim_text="batch test")
        assert len(chains) == 5
        assert chains[0].page_number == 0
        assert chains[4].page_number == 4
        assert all(c.claim_text == "batch test" for c in chains)

    def test_resolve_batch_empty(self, resolver_no_spark):
        assert resolver_no_spark.resolve_batch([]) == []

    def test_is_ready_without_spark(self, resolver_no_spark):
        assert not resolver_no_spark.is_ready

    def test_custom_pdf_root(self):
        resolver = ProvenanceResolver(spark=None, pdf_volume_root="/custom/path")
        cit = _sample_citation(source_filename="test.pdf")
        chain = resolver.resolve(cit)
        assert chain.pdf_path == "/custom/path/test.pdf"


# ---------------------------------------------------------------------------
# Contract ID parsing edge cases
# ---------------------------------------------------------------------------

class TestContractIdParsing:
    def test_simple_base_agreement(self):
        result = ProvenanceResolver._parse_contract_id(
            "129075504_Sutter_Coast_Hospital_440185687_Base_v1.pdf"
        )
        assert result == "440185687"

    def test_amendment_with_multiple_numbers(self):
        result = ProvenanceResolver._parse_contract_id(
            "240291377_Lodi_Memorial_Hospital_Inc_West_240295763_FirstAmend_v1.pdf"
        )
        assert result == "240295763"

    def test_no_contract_id_in_filename(self):
        result = ProvenanceResolver._parse_contract_id("unknown_file.pdf")
        assert result == ""

    def test_single_numeric_is_provider_id_only(self):
        # Only one numeric segment = provider_id, no contract_id
        result = ProvenanceResolver._parse_contract_id("129075504_Hospital_Base_v1.pdf")
        assert result == ""

    def test_uppercase_extension(self):
        result = ProvenanceResolver._parse_contract_id(
            "129097205_Desert_355258177_NineteenthAmend_v2.PDF"
        )
        assert result == "355258177"
