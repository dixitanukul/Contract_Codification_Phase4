"""
Tests for ProviderDeepDiveTool (P4B-SP-1).
Validates provider resolution, section fetching, concept search,
and structured ToolResult output.
"""
import pytest
import pandas as pd
from collections import OrderedDict

import sys, types
_V3_BASE = "/Workspace/Users/adixit01@blueshieldca.com/Contract_Codification_Pipeline"
if _V3_BASE not in sys.path:
    sys.path.insert(0, _V3_BASE)
if "platform.v4" not in sys.modules:
    _pkg = types.ModuleType("platform.v4")
    _pkg.__path__ = [f"{_V3_BASE}/platform/v3"]
    _pkg.__package__ = "platform.v4"
    sys.modules["platform.v4"] = _pkg

from platform.v4.tools.provider_deep_dive import ProviderDeepDiveTool, ProviderProfile, DeepDiveResult
from platform.v4.contracts.tool_types import ToolStatus, Confidence


# ─── Mock Infrastructure ─────────────────────────────────────────────────────

class MockSparkResult:
    def __init__(self, pdf: pd.DataFrame):
        self._pdf = pdf

    def toPandas(self):
        return self._pdf.copy()


class MockSparkSession:
    """Mock Spark that returns DataFrames based on substring matching in SQL."""

    def __init__(self, responses: dict = None):
        self._responses = OrderedDict(responses or {})

    def sql(self, query: str) -> MockSparkResult:
        q_lower = query.lower()
        for key, df in self._responses.items():
            if key.lower() in q_lower:
                return MockSparkResult(df)
        return MockSparkResult(pd.DataFrame())


class MockProviderService:
    def __init__(self, resolved=None, method="canonical_exact", provider_ids=None):
        self._resolved = resolved or ["Test Hospital"]
        self._method = method
        self._ids = provider_ids or ["P001", "P002"]
        self._names = ["Test Hospital", "Community Medical Center", "Kaiser Permanente"]

    def resolve(self, name):
        return self._resolved, self._method, self._ids

    def all_names(self):
        return self._names


class MockRetrievalService:
    def __init__(self, results=None):
        self._results = results or []

    def retrieve(self, query, provider_name=None, top_k=20, current_only=True):
        return self._results


# ─── Helper DataFrames ───────────────────────────────────────────────────────

def _make_profile_df():
    return pd.DataFrame([{
        "provider_name": "Test Hospital",
        "agreement_type": "IPA",
        "total_rates": 45,
        "total_amendments": 12,
        "avg_inpatient_per_diem": 2500.0,
    }])


def _make_rates_df():
    return pd.DataFrame([
        {"rate_category": "Inpatient", "service_category": "Med/Surg",
         "rate_text": "$2,500 per diem", "rate_numeric": 2500.0,
         "rate_type_detail": "Per Diem", "formula": None,
         "effective_date_parsed": "2024-01-01", "program_normalized": "Commercial"},
        {"rate_category": "Outpatient", "service_category": "Surgery",
         "rate_text": "150% of Medicare", "rate_numeric": 3200.0,
         "rate_type_detail": "% Medicare", "formula": "1.5 * Medicare",
         "effective_date_parsed": "2024-01-01", "program_normalized": "Commercial"},
        {"rate_category": "Inpatient", "service_category": "ICU",
         "rate_text": "$4,000 per diem", "rate_numeric": 4000.0,
         "rate_type_detail": "Per Diem", "formula": None,
         "effective_date_parsed": "2024-01-01", "program_normalized": "Commercial"},
    ])


def _make_terms_df():
    return pd.DataFrame([
        {"topic": "Termination", "title": "Termination for Convenience",
         "content_text": "Either party may terminate with 90 days written notice.",
         "content_type": "provision", "source_filename": "test_v3.pdf"},
        {"topic": "Termination", "title": "Termination for Cause",
         "content_text": "Breach not cured within 30 days constitutes cause.",
         "content_type": "provision", "source_filename": "test_v3.pdf"},
        {"topic": "Audit", "title": "Right to Audit",
         "content_text": "Health plan may audit records with 30 days notice.",
         "content_type": "provision", "source_filename": "test_v3.pdf"},
    ])


def _make_amendments_df():
    return pd.DataFrame([
        {"document_type": "Base Agreement", "summary_of_changes": "Initial contract terms",
         "amendment_order": 0, "source_filename": "test_v1.pdf"},
        {"document_type": "Amendment", "summary_of_changes": "Rate increase 5%",
         "amendment_order": 1, "source_filename": "test_v2.pdf"},
        {"document_type": "Amendment", "summary_of_changes": "Added telehealth services",
         "amendment_order": 2, "source_filename": "test_v3.pdf"},
    ])


# ─── Test Classes ────────────────────────────────────────────────────────────

class TestProviderResolution:
    """Test provider name resolution and extraction."""

    def test_resolves_explicit_provider_name(self):
        spark = MockSparkSession({"tbl_genie_provider_profile": _make_profile_df()})
        tool = ProviderDeepDiveTool(spark, MockProviderService())
        result = tool(question="Show me details", provider_name="Test Hospital")
        assert result.success
        assert result.data["provider_name"] == "Test Hospital"

    def test_extracts_provider_from_question(self):
        spark = MockSparkSession({"tbl_genie_provider_profile": _make_profile_df()})
        tool = ProviderDeepDiveTool(spark, MockProviderService())
        result = tool(question="Deep dive into Kaiser Permanente contracts")
        assert result.success
        assert result.data["provider_name"] == "Test Hospital"

    def test_returns_error_when_no_provider(self):
        spark = MockSparkSession({})
        tool = ProviderDeepDiveTool(spark, MockProviderService())
        result = tool(question="Show me contract details")
        # "contract details" doesn't match any known name
        # but MockProviderService.all_names has some names... let me check
        # Actually "Community Medical Center" and "Kaiser Permanente" won't be in "Show me contract details"
        # "Test Hospital" won't be either. So it should fail.
        assert not result.success
        assert "No provider" in result.error_message

    def test_returns_error_when_unresolved(self):
        spark = MockSparkSession({})
        svc = MockProviderService(resolved=[], method="unresolved", provider_ids=[])
        tool = ProviderDeepDiveTool(spark, svc)
        result = tool(question="test", provider_name="Nonexistent Hospital")
        assert not result.success
        assert "Could not resolve" in result.error_message

    def test_resolution_method_in_output(self):
        spark = MockSparkSession({"tbl_genie_provider_profile": _make_profile_df()})
        svc = MockProviderService(method="fuzzy_80")
        tool = ProviderDeepDiveTool(spark, svc)
        result = tool(question="test", provider_name="Test Hosp")
        assert result.data["resolution_method"] == "fuzzy_80"


class TestProfileSection:
    """Test profile fetching."""

    def test_fetches_profile(self):
        spark = MockSparkSession({"tbl_genie_provider_profile": _make_profile_df()})
        tool = ProviderDeepDiveTool(spark, MockProviderService())
        result = tool(question="test", provider_name="Test Hospital")
        profile = result.data["profile"]
        assert profile is not None
        assert profile["agreement_type"] == "IPA"
        assert profile["total_rates"] == 45
        assert profile["total_amendments"] == 12
        assert profile["avg_inpatient_per_diem"] == 2500.0

    def test_handles_missing_profile(self):
        spark = MockSparkSession({})  # No profile match
        tool = ProviderDeepDiveTool(spark, MockProviderService())
        result = tool(question="test", provider_name="Test Hospital")
        assert result.success
        assert result.data["profile"] is None


class TestRatesSection:
    """Test rate schedule fetching."""

    def test_fetches_current_rates(self):
        spark = MockSparkSession({
            "tbl_genie_provider_profile": _make_profile_df(),
            "rate_category": _make_rates_df(),
        })
        tool = ProviderDeepDiveTool(spark, MockProviderService())
        result = tool(question="test", provider_name="Test Hospital")
        assert len(result.data["rates"]) == 3
        assert result.data["rate_stats"]["total_entries"] == 3
        assert result.data["rate_stats"]["categories"] == 2

    def test_rate_stats_computed(self):
        spark = MockSparkSession({
            "tbl_genie_provider_profile": _make_profile_df(),
            "rate_category": _make_rates_df(),
        })
        tool = ProviderDeepDiveTool(spark, MockProviderService())
        result = tool(question="test", provider_name="Test Hospital")
        stats = result.data["rate_stats"]
        assert stats["avg_rate"] > 0
        assert stats["max_rate"] == 4000.0
        assert stats["min_rate"] == 2500.0

    def test_historical_rates_flag(self):
        """When include_historical=True, uses full table not current subquery."""
        queries = []
        class CaptureSpark:
            def sql(self, query):
                queries.append(query)
                return MockSparkResult(pd.DataFrame())
        
        tool = ProviderDeepDiveTool(CaptureSpark(), MockProviderService())
        tool(question="test", provider_name="Test Hospital", include_historical=True)
        # Should NOT use the INNER JOIN subquery for current rates
        rate_query = [q for q in queries if "rate_category" in q.lower() or "rate_numeric" in q.lower()]
        if rate_query:
            assert "INNER JOIN" not in rate_query[0]

    def test_handles_empty_rates(self):
        spark = MockSparkSession({"tbl_genie_provider_profile": _make_profile_df()})
        tool = ProviderDeepDiveTool(spark, MockProviderService())
        result = tool(question="test", provider_name="Test Hospital")
        assert result.success
        assert result.data["rates"] == []
        assert result.data["rate_stats"] == {}


class TestTermsSection:
    """Test contract terms fetching."""

    def test_fetches_terms(self):
        spark = MockSparkSession({
            "tbl_genie_provider_profile": _make_profile_df(),
            "vw_genie_contract_terms": _make_terms_df(),
        })
        tool = ProviderDeepDiveTool(spark, MockProviderService())
        result = tool(question="test", provider_name="Test Hospital")
        assert len(result.data["terms"]) == 3
        assert "Termination" in result.data["terms_by_topic"]
        assert result.data["terms_by_topic"]["Termination"] == 2

    def test_handles_empty_terms(self):
        spark = MockSparkSession({"tbl_genie_provider_profile": _make_profile_df()})
        tool = ProviderDeepDiveTool(spark, MockProviderService())
        result = tool(question="test", provider_name="Test Hospital")
        assert result.data["terms"] == []
        assert result.data["terms_by_topic"] == {}


class TestAmendmentsSection:
    """Test amendment timeline fetching."""

    def test_fetches_amendments(self):
        spark = MockSparkSession({
            "tbl_genie_provider_profile": _make_profile_df(),
            "tbl_genie_amendment_timeline": _make_amendments_df(),
        })
        tool = ProviderDeepDiveTool(spark, MockProviderService())
        result = tool(question="test", provider_name="Test Hospital")
        assert len(result.data["amendments"]) == 3
        assert result.data["amendments"][0]["amendment_order"] == 0
        assert result.data["amendments"][2]["summary_of_changes"] == "Added telehealth services"


class TestConceptSearch:
    """Test concept-specific passage retrieval."""

    def test_concept_search_with_retrieval_service(self):
        passages = [
            {"chunk_text": "The offset clause states...", "source_filename": "test.pdf", "score": 0.9},
            {"chunk_text": "Offset provisions apply to...", "source_filename": "test2.pdf", "score": 0.8},
        ]
        retrieval = MockRetrievalService(results=passages)
        spark = MockSparkSession({"tbl_genie_provider_profile": _make_profile_df()})
        tool = ProviderDeepDiveTool(spark, MockProviderService(), retrieval_service=retrieval)
        result = tool(question="test", provider_name="Test Hospital", concept="offset clause")
        assert len(result.data["concept_results"]) == 2
        assert "offset clause" in result.data["concept_results"][0]["text"].lower()

    def test_concept_search_without_retrieval_service(self):
        spark = MockSparkSession({"tbl_genie_provider_profile": _make_profile_df()})
        tool = ProviderDeepDiveTool(spark, MockProviderService(), retrieval_service=None)
        result = tool(question="test", provider_name="Test Hospital", concept="offset clause")
        assert result.data["concept_results"] == []

    def test_concept_activates_section(self):
        spark = MockSparkSession({"tbl_genie_provider_profile": _make_profile_df()})
        retrieval = MockRetrievalService(results=[])
        tool = ProviderDeepDiveTool(spark, MockProviderService(), retrieval_service=retrieval)
        result = tool(question="test", provider_name="Test Hospital", concept="auto-renewal")
        assert result.data["target_concept"] == "auto-renewal"


class TestSections:
    """Test selective section loading."""

    def test_can_limit_sections(self):
        queries = []
        class CaptureSpark:
            def sql(self, query):
                queries.append(query)
                return MockSparkResult(pd.DataFrame())

        tool = ProviderDeepDiveTool(CaptureSpark(), MockProviderService())
        result = tool(question="test", provider_name="Test Hospital", sections=["profile", "rates"])
        # Should NOT query terms or amendments
        terms_queries = [q for q in queries if "vw_genie_contract_terms" in q.lower()]
        amend_queries = [q for q in queries if "tbl_genie_amendment_timeline" in q.lower()]
        assert len(terms_queries) == 0
        assert len(amend_queries) == 0


class TestOutputStructure:
    """Test ToolResult output format."""

    def test_success_result_structure(self):
        spark = MockSparkSession({
            "tbl_genie_provider_profile": _make_profile_df(),
            "rate_category": _make_rates_df(),
            "vw_genie_contract_terms": _make_terms_df(),
            "tbl_genie_amendment_timeline": _make_amendments_df(),
        })
        tool = ProviderDeepDiveTool(spark, MockProviderService())
        result = tool(question="test", provider_name="Test Hospital")
        assert result.success
        assert result.status == ToolStatus.SUCCESS
        assert result.confidence == Confidence.HIGH
        assert "Deep dive: Test Hospital" in result.summary

    def test_summary_includes_counts(self):
        spark = MockSparkSession({
            "tbl_genie_provider_profile": _make_profile_df(),
            "rate_category": _make_rates_df(),
            "vw_genie_contract_terms": _make_terms_df(),
            "tbl_genie_amendment_timeline": _make_amendments_df(),
        })
        tool = ProviderDeepDiveTool(spark, MockProviderService())
        result = tool(question="test", provider_name="Test Hospital")
        assert "3 rates" in result.summary
        assert "3 terms" in result.summary
        assert "3 amendments" in result.summary

    def test_validate_inputs_requires_question(self):
        spark = MockSparkSession({})
        tool = ProviderDeepDiveTool(spark, MockProviderService())
        errors = tool.validate_inputs(provider_name="Test")
        assert len(errors) > 0


class TestEdgeCases:
    """Test error handling and edge cases."""

    def test_spark_exception_returns_empty_sections(self):
        """If Spark throws, sections return empty but tool doesn't crash."""
        class FailingSpark:
            def sql(self, query):
                raise RuntimeError("Connection lost")

        tool = ProviderDeepDiveTool(FailingSpark(), MockProviderService())
        result = tool(question="test", provider_name="Test Hospital")
        assert result.success
        assert result.data["profile"] is None
        assert result.data["rates"] == []
        assert result.data["terms"] == []
        assert result.data["amendments"] == []

    def test_provider_extraction_longest_match(self):
        """Should prefer longest matching provider name."""
        svc = MockProviderService()
        svc._names = ["Community", "Community Medical Center"]
        spark = MockSparkSession({"tbl_genie_provider_profile": _make_profile_df()})
        tool = ProviderDeepDiveTool(spark, svc)
        # The extraction should find "Community Medical Center" not just "Community"
        extracted = tool._extract_provider("Tell me about Community Medical Center rates")
        assert extracted == "Community Medical Center"


class TestRegressionGolden:
    """Golden regression tests matching V2 Branch B output structure."""

    @pytest.mark.parametrize("question,provider,expect_sections", [
        ("Deep dive into Kaiser Permanente", "Kaiser Permanente", {"profile", "rates", "terms", "amendments"}),
        ("Show rate schedule for Test Hospital", "Test Hospital", {"profile", "rates", "terms", "amendments"}),
        ("What are the contract terms for Community Medical Center?", "Community Medical Center", {"profile", "rates", "terms", "amendments"}),
        ("Tell me about Test Hospital offset clause", "Test Hospital", {"profile", "rates", "terms", "amendments", "concept"}),
    ])
    def test_golden_structure(self, question, provider, expect_sections):
        spark = MockSparkSession({
            "tbl_genie_provider_profile": _make_profile_df(),
            "rate_category": _make_rates_df(),
            "vw_genie_contract_terms": _make_terms_df(),
            "tbl_genie_amendment_timeline": _make_amendments_df(),
        })
        concept = "offset clause" if "offset" in question else None
        retrieval = MockRetrievalService(results=[{"chunk_text": "offset language", "source_filename": "x.pdf", "score": 0.9}]) if concept else None
        tool = ProviderDeepDiveTool(spark, MockProviderService(), retrieval_service=retrieval)
        result = tool(question=question, provider_name=provider, concept=concept)
        assert result.success
        # All standard sections should have data keys
        for section in expect_sections:
            if section == "profile":
                assert "profile" in result.data
            elif section == "rates":
                assert "rates" in result.data
            elif section == "terms":
                assert "terms" in result.data
            elif section == "amendments":
                assert "amendments" in result.data
            elif section == "concept":
                assert result.data["target_concept"] is not None
