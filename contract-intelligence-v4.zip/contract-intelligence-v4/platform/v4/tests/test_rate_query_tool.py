"""
platform/v4/tests/test_rate_query_tool.py

P4A-RATE-3: Unit + regression tests for the native RateQueryTool.

Test groups:
    1. TestHeuristicClassification - query type detection without LLM
    2. TestProviderExtraction - provider name extraction from questions
    3. TestProviderRates - provider_rates query path
    4. TestBenchmark - benchmark query path
    5. TestAggregation - aggregation query path
    6. TestCapitation - capitation/PMPM query path
    7. TestStopLoss - stop-loss query path
    8. TestDistribution - distribution query path
    9. TestTopN - top-N providers query path
    10. TestLLMClassification - LLM-based classification with mock
    11. TestEdgeCases - error handling, empty results, validation
    12. TestRegressionGolden - 10 golden rate queries for V2 parity
"""
from __future__ import annotations

import pytest
from unittest.mock import MagicMock, patch
from typing import Any, Dict, List

import pandas as pd

from platform.v4.tools.rate_query import (
    RateQueryTool,
    RateQueryType,
    RateQueryPlan,
    _classify_query_type_heuristic,
)
from platform.v4.contracts.tool_types import Confidence, ToolResult, ToolStatus
from platform.v4.services.provider_service import ProviderService


# -- Fixtures ---------------------------------------------------------------


class MockSparkSession:
    """Mock SparkSession that returns controlled DataFrames."""

    def __init__(self, responses: Dict[str, pd.DataFrame] = None):
        self._responses = responses or {}
        self._default = pd.DataFrame()
        self._last_sql: str = ""

    def sql(self, query: str) -> "MockSparkResult":
        self._last_sql = query
        # Match based on substrings in the query
        for key, df in self._responses.items():
            if key.lower() in query.lower():
                return MockSparkResult(df)
        return MockSparkResult(self._default)


class MockSparkResult:
    """Mock Spark DataFrame result."""

    def __init__(self, pdf: pd.DataFrame):
        self._pdf = pdf

    def toPandas(self) -> pd.DataFrame:
        return self._pdf.copy()


class MockProviderService:
    """Mock ProviderService with configurable resolution."""

    def __init__(self, resolutions: Dict[str, tuple] = None):
        self._resolutions = resolutions or {}
        self._all_names = ["Kaiser Permanente", "Cedars-Sinai", "Sutter Health",
                          "Dignity Health", "Stanford Health Care"]

    def resolve(self, user_input: str) -> tuple:
        key = user_input.lower().strip()
        if key in self._resolutions:
            return self._resolutions[key]
        # Default: exact match returns single name + ID
        return ([user_input], "canonical_exact", [f"ID_{user_input[:6]}"])

    def all_names(self) -> List[str]:
        return self._all_names

    def sql_filter(self, name: str, column: str = "provider_id") -> str:
        _, _, ids = self.resolve(name)
        if ids:
            return f"{column} = \'{ids[0]}\'"
        return f"LOWER(provider_name) LIKE \'%{name.lower()}%\'"


def _make_rates_df(n: int = 5) -> pd.DataFrame:
    """Create a sample rates DataFrame."""
    return pd.DataFrame({
        "rate_category": ["inpatient"] * 2 + ["outpatient"] * 2 + ["emergency"],
        "service_category": ["per diem", "DRG", "APC", "fee schedule", "ER visit"],
        "rate_text": ["$1,500/day", "150% Medicare", "$450/visit", "$200/service", "$800/visit"],
        "rate_numeric": [1500.0, 3200.0, 450.0, 200.0, 800.0],
        "rate_type_detail": ["per diem", "case rate", "APC", "fee", "visit"],
        "formula": [None, "CMS_DRG * 1.50", None, None, None],
        "effective_date_parsed": ["2024-01-01"] * 5,
        "program_normalized": ["Commercial"] * 5,
    })



def _make_rate_summary_df() -> pd.DataFrame:
    """Create a sample rate summary DataFrame (provider_rate_summary output)."""
    return pd.DataFrame({
        "rate_category": ["inpatient", "outpatient", "emergency"],
        "entry_count": [2, 2, 1],
        "avg_rate": [2350.0, 325.0, 800.0],
        "max_rate": [3200.0, 450.0, 800.0],
        "min_rate": [1500.0, 200.0, 800.0],
    })


def _make_benchmark_df() -> pd.DataFrame:
    """Create a sample benchmark DataFrame."""
    return pd.DataFrame({
        "service_line": ["inpatient", "outpatient", "emergency"],
        "p10": [800.0, 150.0, 400.0],
        "p25": [1000.0, 200.0, 500.0],
        "p50_median": [1500.0, 350.0, 700.0],
        "p75": [2000.0, 500.0, 900.0],
        "p90": [3000.0, 700.0, 1200.0],
        "mean_rate": [1600.0, 380.0, 750.0],
        "provider_count": [250, 300, 280],
    })


def _make_agg_df() -> pd.DataFrame:
    """Create a sample aggregation DataFrame."""
    return pd.DataFrame({
        "rate_category": ["inpatient", "outpatient", "emergency"],
        "rate_value": [1800.0, 400.0, 750.0],
        "n_entries": [5000, 8000, 3000],
        "n_providers": [200, 250, 230],
    })


def _make_capitation_df() -> pd.DataFrame:
    """Create a sample capitation DataFrame."""
    return pd.DataFrame({
        "provider_name": ["Kaiser"] * 3,
        "age_gender_band": ["0-17", "18-64", "65+"],
        "rate_text": ["$45 PMPM", "$125 PMPM", "$280 PMPM"],
        "pmpm_rate": [45.0, 125.0, 280.0],
    })


def _make_stop_loss_df() -> pd.DataFrame:
    """Create a sample stop-loss DataFrame."""
    return pd.DataFrame({
        "provider_name": ["Kaiser", "Kaiser"],
        "protection_type": ["individual", "aggregate"],
        "sub_type": ["per member", "annual"],
        "threshold_text": ["$500,000", "$5,000,000"],
        "threshold_amount": [500000.0, 5000000.0],
    })


def _make_distribution_df() -> pd.DataFrame:
    """Create a sample distribution DataFrame."""
    return pd.DataFrame({
        "provider_name": [f"Provider_{i}" for i in range(10)],
        "rate_category": ["inpatient"] * 10,
        "rate_numeric": [1000.0, 1200.0, 1400.0, 1600.0, 1800.0,
                         2000.0, 2200.0, 2400.0, 2600.0, 3000.0],
        "decile": list(range(1, 11)),
    })


def _make_top_n_df() -> pd.DataFrame:
    """Create a sample top-N DataFrame."""
    return pd.DataFrame({
        "provider_name": [f"Provider_{i}" for i in range(5)],
        "avg_rate": [3500.0, 3200.0, 2900.0, 2700.0, 2500.0],
        "n_rules": [15, 12, 20, 8, 10],
    })


@pytest.fixture
def mock_spark():
    """Spark mock with all response types loaded.

    Keys are matched in insertion order; more specific keys come first
    to avoid e.g. 'rates_current' matching before 'entry_count'.
    """
    return MockSparkSession(responses={
        # Most specific first to avoid false matches
        "entry_count": _make_rate_summary_df(),        # provider_rate_summary
        "having count": _make_top_n_df(),               # top_n_providers
        "ntile": _make_distribution_df(),               # distribution
        "tbl_intel_benchmark_results": _make_benchmark_df(),
        "tbl_serving_capitation_card": _make_capitation_df(),
        "tbl_reimb_stop_loss": _make_stop_loss_df(),
        "n_providers": _make_agg_df(),                  # aggregation
        "rate_type_detail": _make_rates_df(),           # provider_rates
    })


@pytest.fixture
def mock_provider_service():
    """Provider service with known resolutions."""
    return MockProviderService(resolutions={
        "kaiser": (["Kaiser Permanente"], "canonical_exact", ["129088335"]),
        "kaiser permanente": (["Kaiser Permanente"], "canonical_exact", ["129088335"]),
        "cedars-sinai": (["Cedars-Sinai Medical Center"], "canonical_exact", ["129088001"]),
        "sutter": (["Sutter Health"], "canonical_contains", ["129088200", "129088201"]),
        "sutter health": (["Sutter Health"], "canonical_exact", ["129088200", "129088201"]),
    })


@pytest.fixture
def tool(mock_spark, mock_provider_service):
    """RateQueryTool instance with mocked dependencies."""
    return RateQueryTool(
        spark=mock_spark,
        provider_service=mock_provider_service,
        llm_client=None,
    )


# ==========================================================================
# 1. Heuristic Classification
# ==========================================================================


class TestHeuristicClassification:
    """Test query type classification without LLM."""

    def test_benchmark_keywords(self):
        assert _classify_query_type_heuristic(
            "How does Kaiser compare to portfolio benchmarks?", True
        ) == RateQueryType.BENCHMARK

    def test_capitation_keywords(self):
        assert _classify_query_type_heuristic(
            "What are the PMPM rates for Sutter?", True
        ) == RateQueryType.CAPITATION

    def test_stop_loss_keywords(self):
        assert _classify_query_type_heuristic(
            "Show stop-loss thresholds", False
        ) == RateQueryType.STOP_LOSS

    def test_distribution_keywords(self):
        assert _classify_query_type_heuristic(
            "What is the distribution of inpatient rates?", False
        ) == RateQueryType.DISTRIBUTION

    def test_top_n_keywords(self):
        assert _classify_query_type_heuristic(
            "Show top 10 highest rate providers", False
        ) == RateQueryType.TOP_N

    def test_aggregation_keywords(self):
        assert _classify_query_type_heuristic(
            "What is the average rate across all providers?", False
        ) == RateQueryType.AGGREGATION

    def test_default_with_provider(self):
        """With a provider but no special keyword, defaults to provider_rates."""
        assert _classify_query_type_heuristic(
            "Show me Kaiser's rates", True
        ) == RateQueryType.PROVIDER_RATES

    def test_default_without_provider(self):
        """Without provider, defaults to aggregation."""
        assert _classify_query_type_heuristic(
            "What are the current rates?", False
        ) == RateQueryType.AGGREGATION


# ==========================================================================
# 2. Provider Extraction
# ==========================================================================


class TestProviderExtraction:
    """Test provider name extraction from question text."""

    def test_extracts_known_provider(self, tool):
        providers, ids, method = tool._resolve_provider(
            "What are Kaiser Permanente's inpatient rates?", None
        )
        assert "Kaiser Permanente" in providers
        assert ids

    def test_explicit_name_overrides(self, tool):
        providers, ids, method = tool._resolve_provider(
            "What are the rates?", "Cedars-Sinai"
        )
        assert "Cedars-Sinai Medical Center" in providers

    def test_no_provider_found(self, tool):
        providers, ids, method = tool._resolve_provider(
            "What is the average inpatient rate?", None
        )
        assert providers == []
        assert method == "none"


# ==========================================================================
# 3. Provider Rates
# ==========================================================================


class TestProviderRates:
    """Test provider_rates query path."""

    def test_returns_rates_for_known_provider(self, tool):
        result = tool(question="What are Kaiser's inpatient rates?", provider_name="Kaiser")
        assert result.success
        assert result.status == ToolStatus.SUCCESS
        assert result.data["query_type"] == "provider_rates"
        assert result.data["summary"]["total_entries"] == 5
        assert result.data["summary"]["categories"] == 3

    def test_includes_numeric_stats(self, tool):
        result = tool(question="Show Kaiser rates", provider_name="Kaiser")
        assert result.data["summary"]["median_rate"] > 0
        assert result.data["summary"]["avg_rate"] > 0

    def test_empty_when_no_provider(self, tool):
        """No provider specified -> EMPTY status."""
        result = tool(
            question="Show rates",
            query_type="provider_rates",
        )
        assert result.status == ToolStatus.EMPTY
        assert "No provider" in result.summary

    def test_temporal_filter_in_metadata(self, tool):
        result = tool(question="Kaiser rates", provider_name="Kaiser")
        assert result.metadata.get("temporal") == "current_effective"

    def test_historical_mode(self, tool):
        result = tool(
            question="Kaiser historical rates",
            provider_name="Kaiser",
            include_historical=True,
        )
        assert result.success
        assert result.data["summary"]["temporal_filter"] == "all"


# ==========================================================================
# 4. Benchmark
# ==========================================================================


class TestBenchmark:
    """Test benchmark query path."""

    def test_benchmark_returns_percentile_positions(self, tool):
        result = tool(
            question="How does Kaiser compare to portfolio benchmarks?",
            provider_name="Kaiser",
        )
        assert result.success
        assert result.data["query_type"] == "benchmark"
        assert result.data["service_lines_compared"] > 0
        rows = result.data["benchmark"]
        assert any("percentile_position" in r for r in rows)

    def test_benchmark_requires_provider(self, tool):
        result = tool(
            question="Show benchmarks",
            query_type="benchmark",
        )
        assert result.status == ToolStatus.EMPTY


# ==========================================================================
# 5. Aggregation
# ==========================================================================


class TestAggregation:
    """Test aggregation query path."""

    def test_aggregation_returns_grouped_stats(self, tool):
        result = tool(
            question="What is the average rate across all providers?",
        )
        assert result.success
        assert result.data["query_type"] == "aggregation"
        assert result.data["n_categories"] > 0

    def test_aggregation_metric_detection(self, tool):
        result = tool(question="What is the maximum inpatient rate?")
        assert result.success


# ==========================================================================
# 6. Capitation
# ==========================================================================


class TestCapitation:
    """Test capitation/PMPM query path."""

    def test_capitation_returns_data(self, tool):
        result = tool(
            question="What are the PMPM capitation rates for Kaiser?",
            provider_name="Kaiser",
        )
        assert result.success
        assert result.data["query_type"] == "capitation"
        assert result.data["n_entries"] == 3

    def test_capitation_empty_for_unknown(self, mock_provider_service):
        """Unknown provider returns empty capitation."""
        spark = MockSparkSession(responses={})
        tool = RateQueryTool(spark=spark, provider_service=mock_provider_service)
        result = tool(
            question="PMPM rates for UnknownProvider",
            provider_name="UnknownProvider",
        )
        assert result.status == ToolStatus.EMPTY


# ==========================================================================
# 7. Stop-Loss
# ==========================================================================


class TestStopLoss:
    """Test stop-loss query path."""

    def test_stop_loss_returns_data(self, tool):
        result = tool(
            question="What are Kaiser's stop-loss protections?",
            provider_name="Kaiser",
        )
        assert result.success
        assert result.data["query_type"] == "stop_loss"
        assert result.data["n_entries"] == 2

    def test_stop_loss_selects_display_columns(self, tool):
        result = tool(
            question="Show stop-loss thresholds for Kaiser",
            provider_name="Kaiser",
        )
        rows = result.data["rows"]
        assert "protection_type" in rows[0]
        assert "threshold_text" in rows[0]


# ==========================================================================
# 8. Distribution
# ==========================================================================


class TestDistribution:
    """Test distribution query path."""

    def test_distribution_returns_stats(self, tool):
        result = tool(
            question="What is the distribution of inpatient rates?",
        )
        assert result.success
        assert result.data["query_type"] == "distribution"
        stats = result.data["statistics"]
        assert "mean" in stats
        assert "median" in stats
        assert stats["count"] > 0


# ==========================================================================
# 9. Top-N
# ==========================================================================


class TestTopN:
    """Test top-N providers query path."""

    def test_top_n_returns_ranked_providers(self, tool):
        result = tool(
            question="Show top 10 highest rate providers",
        )
        assert result.success
        assert result.data["query_type"] == "top_n"
        rows = result.data["rows"]
        assert len(rows) > 0
        rates = [r["avg_rate"] for r in rows]
        assert rates == sorted(rates, reverse=True)


# ==========================================================================
# 10. LLM Classification
# ==========================================================================


class TestLLMClassification:
    """Test LLM-based query classification."""

    def test_llm_classification_success(self, mock_spark, mock_provider_service):
        mock_llm = MagicMock()
        mock_llm.chat.return_value = "benchmark"
        tool = RateQueryTool(
            spark=mock_spark,
            provider_service=mock_provider_service,
            llm_client=mock_llm,
        )
        result = tool(
            question="Compare Kaiser's rates to the market",
            provider_name="Kaiser",
        )
        assert result.success
        assert result.data["query_type"] == "benchmark"
        mock_llm.chat.assert_called_once()

    def test_llm_fallback_on_error(self, mock_spark, mock_provider_service):
        mock_llm = MagicMock()
        mock_llm.chat.side_effect = RuntimeError("LLM timeout")
        tool = RateQueryTool(
            spark=mock_spark,
            provider_service=mock_provider_service,
            llm_client=mock_llm,
        )
        result = tool(
            question="Show Kaiser's rates",
            provider_name="Kaiser",
        )
        assert result.success

    def test_llm_invalid_response_falls_back(self, mock_spark, mock_provider_service):
        mock_llm = MagicMock()
        mock_llm.chat.return_value = "invalid_type_xyz"
        tool = RateQueryTool(
            spark=mock_spark,
            provider_service=mock_provider_service,
            llm_client=mock_llm,
        )
        result = tool(
            question="Show Kaiser's rates",
            provider_name="Kaiser",
        )
        assert result.success


# ==========================================================================
# 11. Edge Cases
# ==========================================================================


class TestEdgeCases:
    """Test error handling and edge cases."""

    def test_missing_question_validation(self, tool):
        result = tool()
        assert not result.success
        assert result.status == ToolStatus.ERROR
        assert "question" in result.summary.lower()

    def test_empty_question_validation(self, tool):
        result = tool(question="")
        assert not result.success
        assert result.status == ToolStatus.ERROR

    def test_sql_exception_handled(self, mock_provider_service):
        """SQL error is caught and returned as ERROR ToolResult."""
        bad_spark = MagicMock()
        bad_spark.sql.side_effect = Exception("Table not found")
        tool = RateQueryTool(
            spark=bad_spark, provider_service=mock_provider_service
        )
        result = tool(question="Kaiser rates", provider_name="Kaiser")
        assert not result.success
        assert result.status == ToolStatus.ERROR
        assert "SQL execution failed" in result.summary

    def test_explicit_query_type_override(self, tool):
        """Explicit query_type skips classification."""
        result = tool(
            question="something about Kaiser",
            provider_name="Kaiser",
            query_type="provider_rates",
        )
        assert result.success
        assert result.data["query_type"] == "provider_rates"

    def test_confidence_is_high_for_sql_results(self, tool):
        result = tool(question="Kaiser rates", provider_name="Kaiser")
        assert result.confidence == Confidence.HIGH

    def test_tool_name_and_description(self, tool):
        assert tool.name == "rate_query"
        assert "rate" in tool.description.lower()
        assert not tool.is_adapter_backed


# ==========================================================================
# 12. Regression Golden Queries
# ==========================================================================


class TestRegressionGolden:
    """
    Golden regression queries for V2 parity.

    These verify that the V3 tool produces the same structural output
    as V2 Branch D for canonical rate questions.
    """

    GOLDEN_QUERIES = [
        ("What are Kaiser Permanente's inpatient rates?", "Kaiser", "provider_rates", 1),
        ("How does Cedars-Sinai compare to portfolio benchmarks?", "Cedars-Sinai", "benchmark", 1),
        ("Show average rates by service category", None, "aggregation", 1),
        ("What are the PMPM capitation rates for Kaiser?", "Kaiser", "capitation", 1),
        ("What stop-loss protections does Kaiser have?", "Kaiser", "stop_loss", 1),
        ("What is the distribution of inpatient rates?", None, "distribution", 1),
        ("Show top 10 highest rate providers", None, "top_n", 1),
        ("What is the average outpatient rate across all providers?", None, "aggregation", 1),
        ("Show Sutter Health's rate schedule", "Sutter", "provider_rates", 1),
        ("Compare Kaiser's rates to the P50 median", "Kaiser", "benchmark", 1),
    ]

    @pytest.mark.parametrize(
        "question,provider,expected_type,min_rows",
        GOLDEN_QUERIES,
        ids=[f"GOLDEN-{i:02d}" for i in range(1, 11)],
    )
    def test_golden_query(self, tool, question, provider, expected_type, min_rows):
        kwargs = {"question": question}
        if provider:
            kwargs["provider_name"] = provider
        result = tool(**kwargs)

        # Must succeed
        assert result.success, f"Failed: {result.summary}"
        assert result.status == ToolStatus.SUCCESS

        # Must produce correct query type
        assert result.data["query_type"] == expected_type, (
            f"Expected {expected_type}, got {result.data['query_type']}"
        )

        # Must have data
        data_key = next(
            (k for k in ("rates", "benchmark", "rows", "statistics") if k in result.data),
            None,
        )
        assert data_key is not None, f"No data key found in {list(result.data.keys())}"
        data = result.data[data_key]
        if isinstance(data, list):
            assert len(data) >= min_rows, (
                f"Expected >= {min_rows} rows, got {len(data)}"
            )
        elif isinstance(data, dict):
            assert len(data) > 0
