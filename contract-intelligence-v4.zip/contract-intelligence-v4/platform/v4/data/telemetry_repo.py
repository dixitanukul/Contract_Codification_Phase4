"""
platform/v4/data/telemetry_repo.py

Repository for V4 telemetry — retrieval events and performance metrics.

Writes to:
  fact_retrieval_telemetry  (V4-owned retrieval logging)

All writes are fire-and-forget: telemetry failures never break the
agent's main execution path.
"""
from __future__ import annotations

import json
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Optional

from ..config.settings import CATALOG, SCHEMA

RETRIEVAL_TABLE     = f"{CATALOG}.{SCHEMA}.fact_retrieval_telemetry"


@dataclass
class RetrievalEvent:
    query:           str
    channel:         str
    hits:            int
    latency_s:       float
    provider_filter: Optional[str] = None
    clause_filter:   Optional[str] = None
    event_id:        str           = field(default_factory=lambda: str(uuid.uuid4()))
    created_at:      float         = field(default_factory=time.time)

    def as_row(self) -> dict:
        return {
            "event_id":       self.event_id,
            "query":          self.query[:500],
            "channel":        self.channel,
            "hits":           self.hits,
            "latency_s":      round(self.latency_s, 3),
            "provider_filter": self.provider_filter or "",
            "clause_filter":  self.clause_filter or "",
            "created_at":     int(self.created_at * 1000),
        }


class TelemetryRepo:
    """
    Fire-and-forget telemetry writer.

    All public methods return silently on error — never raise.

    Parameters
    ----------
    spark : Active Spark session.
    """

    def __init__(self, spark: Optional[Any] = None) -> None:
        self._spark  = spark
        self._buffer: list[dict] = []   # in-memory fallback

    def set_spark(self, spark: Any) -> None:
        self._spark = spark

    def log_retrieval(self, event_dict: dict) -> None:
        """Log a retrieval event from RetrievalAdapter.

        Accepts the raw dict from RetrievalAdapter._log_telemetry() and maps
        it to the fact_retrieval_telemetry table schema.

        Adapter event_dict keys:
            query, channel, hits, latency_s, provider_filter, clause_filter

        Table columns:
            query_id, query_timestamp, query_text, route, provider_filter,
            total_latency_ms, routing_latency_ms, retrieval_latency_ms,
            reranking_latency_ms, llm_latency_ms, result_count, empty_result,
            temporal_precision, retrieval_channels_used, tokens_used,
            source, user_id
        """
        from datetime import datetime, timezone

        latency_ms = int(event_dict.get("latency_s", 0) * 1000)
        hits = event_dict.get("hits", 0)

        row = {
            "query_id":               str(uuid.uuid4()),
            "query_timestamp":        datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S"),
            "query_text":             (event_dict.get("query") or "")[:500],
            "route":                  event_dict.get("channel", "passage_search"),
            "provider_filter":        event_dict.get("provider_filter") or "",
            "total_latency_ms":       latency_ms,
            "routing_latency_ms":     None,
            "retrieval_latency_ms":   latency_ms,
            "reranking_latency_ms":   None,
            "llm_latency_ms":         None,
            "result_count":           hits,
            "empty_result":           hits == 0,
            "temporal_precision":      None,
            "retrieval_channels_used": event_dict.get("channel", "semantic"),
            "tokens_used":            None,
            "source":                 "v4_agent",
            "user_id":                None,
        }
        self._write_sql(RETRIEVAL_TABLE, row)

    def flush_buffer(self) -> int:
        """Flush the in-memory buffer to Delta.  Returns rows written."""
        if not self._buffer or self._spark is None:
            return 0
        try:
            # Group by table
            by_table: dict[str, list[dict]] = {}
            for item in self._buffer:
                tbl = item.pop("__table__", RETRIEVAL_TABLE)
                by_table.setdefault(tbl, []).append(item)
            total = 0
            for tbl, rows in by_table.items():
                df = self._spark.createDataFrame(rows)
                df.write.format("delta").mode("append").saveAsTable(tbl)
                total += len(rows)
            self._buffer.clear()
            return total
        except Exception:  # noqa: BLE001
            return 0

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------


    def _write_sql(self, table: str, row: dict) -> None:
        """Write one row via INSERT INTO SQL — handles NULLs and types cleanly."""
        if self._spark is None:
            row["__table__"] = table
            self._buffer.append(row)
            return
        try:
            cols = list(row.keys())
            vals = []
            for v in row.values():
                if v is None:
                    vals.append("NULL")
                elif isinstance(v, bool):
                    vals.append(str(v).lower())
                elif isinstance(v, (int, float)):
                    vals.append(str(v))
                else:
                    esc = str(v).replace("'", "''")
                    vals.append(f"'{esc}'")
            col_str = ", ".join(cols)
            val_str = ", ".join(vals)
            self._spark.sql(f"INSERT INTO {table} ({col_str}) VALUES ({val_str})")
        except Exception:  # noqa: BLE001
            row["__table__"] = table
            self._buffer.append(row)
