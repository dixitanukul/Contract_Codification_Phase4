"""
platform/v4/data/session_repo.py

Repository for V4 agent session persistence (tbl_agent_sessions).

W9-22 Enhanced: multi-turn session resume via conversation history
reconstruction.  Each row in tbl_agent_sessions represents one turn.
Session resume loads prior turns, rebuilds ConversationTurn objects,
and populates SessionContext.conversation_history for coreference
resolution (W9-21).

Session data includes: session_id, user_id, question, answer,
confidence, cost, latency, step count, tool usage, and resolved entities.

30-day TTL enforced via `purge_expired()`.
"""
from __future__ import annotations

import json
import time
import uuid
from dataclasses import asdict, dataclass, field
from typing import Any, Optional

from ..config.settings import CATALOG, SCHEMA

TABLE   = f"{CATALOG}.{SCHEMA}.tbl_agent_sessions"
SESSION_TTL_DAYS = 30


@dataclass
class SessionRecord:
    session_id:       str
    question:         str
    answer:           str
    confidence:       str
    total_cost:       float
    execution_time_s: float
    step_count:       int
    tool_calls:       list[str]
    citation_count:   int
    created_at:       float = field(default_factory=time.time)
    user_id:          str   = ""
    question_type:    str   = ""
    error:            Optional[str] = None
    resolved_entities_json: Optional[str] = None  # W9-22

    def as_row(self) -> dict:
        d = asdict(self)
        d["tool_calls"]  = json.dumps(d["tool_calls"])
        d["created_at"]  = int(d["created_at"] * 1000)   # milliseconds
        return d


class SessionRepo:
    """
    Persist and retrieve V4 agent sessions.

    Parameters
    ----------
    spark : Active Spark session.
    """

    def __init__(self, spark: Optional[Any] = None) -> None:
        self._spark = spark
        self._buffer: list[SessionRecord] = []   # in-memory fallback

    def set_spark(self, spark: Any) -> None:
        self._spark = spark

    def save(self, record: SessionRecord) -> bool:
        """
        Save a session record.  Returns True on success.
        Falls back to in-memory buffer if Spark is unavailable.

        Bug-5b fix: detects WarehouseSpark (no createDataFrame) and uses an
        INSERT INTO SQL path so multi-turn sessions persist in the App container.

        MT-BUFFER-FIX: always add to in-memory buffer so that same-process
        load_session() calls (e.g. the very next turn) find the record
        immediately, even before the async Delta write completes.
        """
        # MT-BUFFER-FIX: buffer unconditionally for same-process fast retrieval
        self._buffer.append(record)

        if self._spark is None:
            return True

        # WarehouseSpark (Statement Execution API in App container) does not
        # implement createDataFrame — use INSERT INTO instead.
        if not hasattr(self._spark, 'createDataFrame'):
            return self._sql_insert(record)

        try:
            df = self._spark.createDataFrame([record.as_row()])
            df.write.format("delta").mode("append").saveAsTable(TABLE)
            return True
        except Exception:  # noqa: BLE001
            # Spark Connect can fail on createDataFrame with None-typed columns.
            # Fall back to SQL INSERT (same path as WarehouseSpark).
            return self._sql_insert(record)

    def _ensure_table(self) -> None:
        """CREATE TABLE IF NOT EXISTS — needed before first INSERT in App container."""
        try:
            self._spark.sql(f"""
                CREATE TABLE IF NOT EXISTS {TABLE} (
                    session_id              STRING,
                    question                STRING,
                    answer                  STRING,
                    confidence              STRING,
                    total_cost              DOUBLE,
                    execution_time_s        DOUBLE,
                    step_count              INT,
                    tool_calls              STRING,
                    citation_count          INT,
                    created_at              BIGINT,
                    user_id                 STRING,
                    question_type           STRING,
                    error                   STRING,
                    resolved_entities_json  STRING
                ) USING DELTA
                TBLPROPERTIES ('delta.autoOptimize.optimizeWrite' = 'true')
            """)
        except Exception:  # noqa: BLE001
            pass  # Table already exists or user lacks CREATE — INSERT will fail gracefully

    def _sql_insert(self, record: SessionRecord) -> bool:
        """INSERT INTO path for WarehouseSpark (no createDataFrame support)."""
        try:
            self._ensure_table()
            row = record.as_row()

            def _esc(v: Any) -> str:
                if v is None:
                    return "NULL"
                if isinstance(v, bool):
                    return "true" if v else "false"
                if isinstance(v, (int, float)):
                    return str(v)
                # Escape single quotes; truncate to avoid oversized statements
                safe = str(v).replace("\\", "\\\\").replace("'", "''")[:4000]
                return f"'{safe}'"

            cols = list(row.keys())
            vals = [_esc(row[c]) for c in cols]
            sql  = (
                f"INSERT INTO {TABLE} ({', '.join(cols)}) "
                f"VALUES ({', '.join(vals)})"
            )
            self._spark.sql(sql)
            return True
        except Exception:  # noqa: BLE001
            self._buffer.append(record)
            return False

    def flush_buffer(self) -> int:
        """Flush in-memory buffer to Delta.  Returns count flushed."""
        if not self._buffer or self._spark is None:
            return 0
        try:
            rows = [r.as_row() for r in self._buffer]
            df   = self._spark.createDataFrame(rows)
            df.write.format("delta").mode("append").saveAsTable(TABLE)
            flushed = len(self._buffer)
            self._buffer.clear()
            return flushed
        except Exception:  # noqa: BLE001
            return 0

    def get_recent(self, n: int = 10) -> list[dict]:
        """Return the most recent N sessions."""
        if self._spark is None:
            return [asdict(r) for r in self._buffer[-n:]]
        try:
            df = self._spark.sql(f"SELECT * FROM {TABLE} ORDER BY created_at DESC LIMIT {n}")
            rows = [r.asDict() for r in df.collect()]
            return rows
        except Exception as exc:  # noqa: BLE001
            import logging
            logging.getLogger(__name__).error("SessionRepo.get_recent failed: %s", exc)
            return []

    # ── W9-22: Multi-turn session resume ──────────────────────────────────────

    def load_session(self, session_id: str) -> list[dict]:
        """
        Load all turns for a session, ordered by timestamp.

        Returns list of row dicts with keys matching tbl_agent_sessions columns.
        Used by ContextManager to rebuild conversation_history on resume.

        MT-BUFFER-FIX: merges in-memory buffer with DB rows so that same-process
        turns that haven't yet committed to Delta (fire-and-forget write lag)
        are still visible to the next turn's context loader.
        """
        # Always check buffer for same-process turns (fire-and-forget write lag fix)
        buffer_rows = [asdict(r) for r in self._buffer if r.session_id == session_id]

        if self._spark is None:
            return buffer_rows

        try:
            df = self._spark.sql(f"""
                SELECT *
                FROM {TABLE}
                WHERE session_id = '{session_id}'
                ORDER BY created_at ASC
            """)
            db_rows = [r.asDict() for r in df.collect()]
            # Merge DB rows with buffer rows; dedup by question text
            if buffer_rows:
                seen_qs = {r.get('question') for r in db_rows}
                for br in buffer_rows:
                    if br.get('question') not in seen_qs:
                        db_rows.append(br)
                        seen_qs.add(br.get('question'))
                db_rows.sort(key=lambda r: r.get('created_at') or 0)
            return db_rows
        except Exception:  # noqa: BLE001
            # SQL failed — fall back to in-memory buffer so multi-turn still works
            # within the current process even when the warehouse is unreachable.
            return buffer_rows

    def session_exists(self, session_id: str) -> bool:
        """Check if a session has at least one row."""
        if self._spark is None:
            return any(r.session_id == session_id for r in self._buffer)
        try:
            count = self._spark.sql(f"""
                SELECT COUNT(*) AS n FROM {TABLE}
                WHERE session_id = '{session_id}'
            """).collect()[0]["n"]
            return count > 0
        except Exception:  # noqa: BLE001
            return False

    def purge_expired(self, ttl_days: int = SESSION_TTL_DAYS) -> int:
        """
        Delete sessions older than ttl_days.  Returns rows removed.

        Should be scheduled daily (e.g., via Lakeflow Job).
        """
        if self._spark is None:
            return 0
        cutoff_ms = int((time.time() - ttl_days * 86_400) * 1000)
        try:
            before = self._spark.sql(f"SELECT COUNT(*) AS n FROM {TABLE}").collect()[0]["n"]
            self._spark.sql(f"""
                DELETE FROM {TABLE}
                WHERE created_at < {cutoff_ms}
            """)
            after = self._spark.sql(f"SELECT COUNT(*) AS n FROM {TABLE}").collect()[0]["n"]
            return before - after
        except Exception:  # noqa: BLE001
            return 0
