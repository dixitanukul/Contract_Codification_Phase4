"""
platform/v4/data/feedback_repo.py

Repository for user feedback on V4 agent responses (tbl_user_feedback).

Stores thumbs-up/down ratings, free-text comments, and correction flags.
Feedback is used to identify bad responses for golden-set expansion
and model improvement.
"""
from __future__ import annotations

import json
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Optional

from ..config.settings import CATALOG, SCHEMA

TABLE   = f"{CATALOG}.{SCHEMA}.tbl_user_feedback"

# Rating constants
RATING_UP   = "UP"
RATING_DOWN = "DOWN"
RATING_SKIP = "SKIP"


@dataclass
class FeedbackRecord:
    session_id:    str
    question:      str
    answer:        str
    rating:        str           # UP | DOWN | SKIP
    comment:       str           = ""
    correction:    str           = ""   # User-provided corrected answer
    is_bad_answer: bool          = False
    feedback_id:   str           = field(default_factory=lambda: str(uuid.uuid4()))
    created_at:    float         = field(default_factory=time.time)
    user_id:       str           = ""

    def as_row(self) -> dict:
        return {
            "feedback_id":   self.feedback_id,
            "session_id":    self.session_id,
            "question":      self.question[:1000],
            "answer":        self.answer[:2000],
            "rating":        self.rating,
            "comment":       self.comment[:500],
            "correction":    self.correction[:2000],
            "is_bad_answer": self.is_bad_answer,
            "user_id":       self.user_id,
            "created_at":    int(self.created_at * 1000),
        }


class FeedbackRepo:
    """
    Store and retrieve user feedback on agent responses.

    Parameters
    ----------
    spark : Active Spark session.
    """

    def __init__(self, spark: Optional[Any] = None) -> None:
        self._spark  = spark
        self._buffer: list[FeedbackRecord] = []

    def set_spark(self, spark: Any) -> None:
        self._spark = spark

    def submit(self, record: FeedbackRecord) -> bool:
        """Save a feedback record. Returns True on success."""
        if self._spark is None:
            self._buffer.append(record)
            return True

        # WarehouseSpark (Statement Execution API) has no createDataFrame —
        # use INSERT INTO SQL path instead.
        if not hasattr(self._spark, 'createDataFrame'):
            return self._sql_insert(record)

        try:
            df = self._spark.createDataFrame([record.as_row()])
            df.write.format("delta").mode("append").saveAsTable(TABLE)
            return True
        except Exception:  # noqa: BLE001
            return self._sql_insert(record)

    def _sql_insert(self, record: FeedbackRecord) -> bool:
        """INSERT INTO path for WarehouseSpark (no createDataFrame support)."""
        try:
            row = record.as_row()

            def _esc(v) -> str:
                if v is None:
                    return "NULL"
                if isinstance(v, bool):
                    return "true" if v else "false"
                if isinstance(v, (int, float)):
                    return str(v)
                safe = str(v).replace("\\", "\\\\").replace("'", "''")[:4000]
                return f"'{safe}'"

            cols = list(row.keys())
            vals = [_esc(row[c]) for c in cols]
            sql = (
                f"INSERT INTO {TABLE} ({', '.join(cols)}) "
                f"VALUES ({', '.join(vals)})"
            )
            self._spark.sql(sql)
            return True
        except Exception:  # noqa: BLE001
            self._buffer.append(record)
            return False

    def thumbs_up(self, session_id: str, question: str, answer: str, comment: str = "") -> bool:
        return self.submit(FeedbackRecord(
            session_id=session_id, question=question, answer=answer,
            rating=RATING_UP, comment=comment,
        ))

    def thumbs_down(
        self,
        session_id: str,
        question:   str,
        answer:     str,
        comment:    str = "",
        correction: str = "",
    ) -> bool:
        return self.submit(FeedbackRecord(
            session_id=session_id, question=question, answer=answer,
            rating=RATING_DOWN, comment=comment, correction=correction,
            is_bad_answer=True,
        ))

    def get_bad_answers(self, limit: int = 50) -> list[dict]:
        """Return recent bad answers for golden-set review."""
        if self._spark is None:
            return [r.as_row() for r in self._buffer if r.is_bad_answer][:limit]
        try:
            df = self._spark.sql(f"""
                SELECT * FROM {TABLE}
                WHERE is_bad_answer = true
                ORDER BY created_at DESC
                LIMIT {limit}
            """)
            return [r.asDict() for r in df.collect()]
        except Exception:  # noqa: BLE001
            return []

    def flush_buffer(self) -> int:
        """Flush in-memory buffer to Delta. Returns count flushed."""
        if not self._buffer or self._spark is None:
            return 0
        try:
            rows = [r.as_row() for r in self._buffer]
            df   = self._spark.createDataFrame(rows)
            df.write.format("delta").mode("append").saveAsTable(TABLE)
            flushed = len(self._buffer)
            self._buffer.clear()
            return flushed
        except Exception:  # noqa: BLE001
            return 0
