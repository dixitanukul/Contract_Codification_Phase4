"""
platform/v4/data/query_cache_repo.py

Repository for V4 query result caching (tbl_query_cache).

Caches deterministic query results (SQL-only, no LLM synthesis) keyed
on a hash of the normalised question + provider context.
Cache is only active when V3_QUERY_CACHE_ENABLED = True.

Cache TTL: configurable (default 24h).  Stale entries are filtered on
read; a periodic job should run VACUUM to purge expired rows.
"""
from __future__ import annotations

import hashlib
import json
import time
from dataclasses import dataclass, field
from typing import Any, Optional

from ..config.settings import CATALOG, SCHEMA, Settings

TABLE     = f"{CATALOG}.{SCHEMA}.tbl_query_cache"
DEFAULT_TTL_S = 86400  # 24 hours


def _make_cache_key(question: str, provider: Optional[str] = None) -> str:
    """Produce a stable SHA-256 hash key for a question + provider pair."""
    raw = json.dumps({"q": question.strip().lower(), "p": (provider or "").lower()})
    return hashlib.sha256(raw.encode()).hexdigest()


@dataclass
class CacheEntry:
    cache_key:    str
    question:     str
    answer:       str
    confidence:   str
    citations:    list[dict]
    created_at:   float = field(default_factory=time.time)
    ttl_s:        int   = DEFAULT_TTL_S
    provider:     str   = ""

    @property
    def is_expired(self) -> bool:
        return (time.time() - self.created_at) > self.ttl_s

    def as_row(self) -> dict:
        return {
            "cache_key":  self.cache_key,
            "question":   self.question,
            "answer":     self.answer,
            "confidence": self.confidence,
            "citations":  json.dumps(self.citations),
            "created_at": int(self.created_at * 1000),
            "ttl_s":      self.ttl_s,
            "provider":   self.provider,
        }


class QueryCacheRepo:
    """
    Read/write query result cache.

    In-memory L1 cache is always active.
    Delta L2 persistence is active only when V3_QUERY_CACHE_ENABLED=True.

    Parameters
    ----------
    spark    : Active Spark session.
    settings : Settings instance.
    """

    def __init__(
        self,
        spark:    Optional[Any]      = None,
        settings: Optional[Settings] = None,
    ) -> None:
        self._spark    = spark
        self._settings = settings or Settings()
        self._l1: dict[str, CacheEntry] = {}   # in-memory L1 cache

    def set_spark(self, spark: Any) -> None:
        self._spark = spark

    @property
    def enabled(self) -> bool:
        return self._settings.V3_QUERY_CACHE_ENABLED

    def get(
        self,
        question: str,
        provider: Optional[str] = None,
    ) -> Optional[CacheEntry]:
        """Return a cached entry if available and not expired.  None otherwise."""
        if not self.enabled:
            return None

        key = _make_cache_key(question, provider)

        # L1 check
        if key in self._l1:
            entry = self._l1[key]
            if not entry.is_expired:
                return entry
            del self._l1[key]

        # L2 Delta check
        if self._spark is not None:
            return self._l2_get(key)
        return None

    def put(
        self,
        question:   str,
        answer:     str,
        confidence: str,
        citations:  list[dict],
        provider:   Optional[str] = None,
        ttl_s:      int           = DEFAULT_TTL_S,
    ) -> None:
        """Store a result in cache (L1 + L2)."""
        if not self.enabled:
            return

        key   = _make_cache_key(question, provider)
        entry = CacheEntry(
            cache_key=key,
            question=question,
            answer=answer,
            confidence=confidence,
            citations=citations,
            ttl_s=ttl_s,
            provider=provider or "",
        )
        self._l1[key] = entry

        if self._spark is not None:
            self._l2_put(entry)

    def invalidate(self, question: str, provider: Optional[str] = None) -> None:
        key = _make_cache_key(question, provider)
        self._l1.pop(key, None)

    def clear_l1(self) -> None:
        self._l1.clear()

    # ------------------------------------------------------------------
    # L2 Delta helpers
    # ------------------------------------------------------------------

    def _l2_get(self, key: str) -> Optional[CacheEntry]:
        cutoff_ms = int((time.time() - DEFAULT_TTL_S) * 1000)
        try:
            df   = self._spark.sql(f"""
                SELECT * FROM {TABLE}
                WHERE cache_key = '{key}'
                  AND created_at > {cutoff_ms}
                LIMIT 1
            """)
            rows = df.collect()
            if not rows:
                return None
            r = rows[0].asDict()
            entry = CacheEntry(
                cache_key  = r["cache_key"],
                question   = r["question"],
                answer     = r["answer"],
                confidence = r["confidence"],
                citations  = json.loads(r.get("citations", "[]")),
                created_at = r["created_at"] / 1000,
                ttl_s      = r.get("ttl_s", DEFAULT_TTL_S),
                provider   = r.get("provider", ""),
            )
            self._l1[key] = entry
            return entry
        except Exception:  # noqa: BLE001
            return None

    def _l2_put(self, entry: CacheEntry) -> None:
        """Persist cache entry to Delta via SQL INSERT (WarehouseSpark compatible)."""
        try:
            row = entry.as_row()

            def _esc(v) -> str:
                if v is None:
                    return "NULL"
                if isinstance(v, bool):
                    return "true" if v else "false"
                if isinstance(v, (int, float)):
                    return str(v)
                safe = str(v).replace("\\", "\\\\").replace("'", "''")[:4000]
                return f"'{safe}'"

            cols = list(row.keys())
            vals = [_esc(row[c]) for c in cols]
            sql = (
                f"INSERT INTO {TABLE} ({', '.join(cols)}) "
                f"VALUES ({', '.join(vals)})"
            )
            self._spark.sql(sql)
        except Exception:  # noqa: BLE001
            pass
