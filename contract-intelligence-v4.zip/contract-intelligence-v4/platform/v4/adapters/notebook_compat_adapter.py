"""
platform/v4/adapters/notebook_compat_adapter.py

Thin compatibility shim: allows old V2 notebook UX entrypoints to
delegate to the V3 runtime without modifying V2 notebook cells.

Usage (Phase 5 only — after V3 passes regression)
--------------------------------------------------
In V2 notebook Cell 4 (router), add ONE line behind the feature flag:

    if V4_AGENT_ENABLED:
        from platform.v4.adapters.notebook_compat_adapter import compat_dispatch
        return compat_dispatch(question, **kwargs)
    # ... existing V2 dispatch logic continues below ...

This is the ONLY permitted edit to the V2 notebook for V3 integration.
All other V3 logic stays inside platform/v4/.

Rules
-----
- This file is Phase 5 only.  Do not call it before V3 passes regression.
- It must not import V2 notebook globals; it only calls V3 runtime.
- V2 stays fully operational when V4_AGENT_ENABLED = False.
"""
from __future__ import annotations

import time
from typing import Any, Optional

from ..config.settings import Settings
from ..contracts.tool_types import Confidence, ToolResult
# Deferred import to break notebook_entry ↔ adapters circular dependency.
# get_runtime / NotebookRuntime are imported lazily inside functions below.


def compat_dispatch(
    question:      str,
    provider_name: Optional[str] = None,
    concept_key:   Optional[str] = None,
    session_id:    Optional[str] = None,
    **kwargs:      Any,
) -> dict:
    """
    Compatibility shim: accepts V2-style dispatch() parameters and
    calls the V3 runtime.  Returns a dict shaped like V2 dispatch output
    so existing callers (including Cell 14 enrichment) don't break.

    Only active when V4_AGENT_ENABLED = True.
    Returns a V2-compatible dict on both success and failure.
    """
    settings = Settings()
    if not settings.V4_AGENT_ENABLED:
        raise RuntimeError(
            "compat_dispatch called but V4_AGENT_ENABLED=False. "
            "This shim must only be invoked behind the feature flag."
        )

    from ..runtime.notebook_entry import get_runtime  # lazy — avoids circular import
    runtime = get_runtime()
    if runtime is None:
        return _error_response(question, "V3 runtime not initialised")

    t0 = time.time()
    try:
        response = runtime.ask(
            question=question,
            provider_name=provider_name,
            session_id=session_id,
        )
    except Exception as exc:  # noqa: BLE001
        return _error_response(question, str(exc))

    elapsed = time.time() - t0

    # Shape the response to match V2 dispatch output convention
    return {
        "answer":         response.answer,
        "confidence":     response.confidence,
        "citations":      response.citations,
        "cost_estimate":  response.total_cost,
        "execution_time_s": elapsed,
        "source":         "v3",
        "session_id":     response.session_id,
        "steps":          [
            {"action": s.action, "tool": s.tool_name, "summary": getattr(s.result, "summary", "")}
            for s in response.steps
        ],
    }


def _error_response(question: str, error: str) -> dict:
    return {
        "answer":         f"V3 agent error: {error}",
        "confidence":     Confidence.LOW,
        "citations":      [],
        "cost_estimate":  0.0,
        "execution_time_s": 0.0,
        "source":         "v3_error",
        "error":          error,
    }
