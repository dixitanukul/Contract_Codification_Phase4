"""
platform/v4/adapters/legacy_branch_adapter.py

Clean V3 wrapper around Contract_Intelligence_V2 Branches A–H.

Design
------
- A `dispatch_fn` callable is injected at runtime from the notebook
  entry point (or test harness).  The adapter itself never imports
  notebook globals directly.
- Each V2 branch is mapped to a canonical V3 tool name so the agent
  does not need to know about nuid or branch letters.
- All results are normalized to ToolResult regardless of what the
  legacy branch returns.
- Cost / latency metadata is pre-set from measured baselines so the
  CostController can account for legacy calls.

V2 Branch map (from branch_test_results.md)
--------------------------------------------
  Branch | nuid     | V3 tool name      | Cost   | Latency
  -------|----------|-------------------|--------|---------
  A hlp  | 75f7c1b2 | (internal helper) | —      | —
  A orch | c6fa4c41 | clause_existence  | $5-6   | 5-10 min
  B      | c02c2bf0 | single_provider   | $0.50  | 11 s
  C      | b35f866f | comparison        | $0.50  | 32 s
  D      | c2c16a6c | rate_query        | $0.10  | 7 s
  E      | 428481f5 | explanation       | $0.30  | 25 s
  F      | 47ad4591 | multi_concept     | $12.00 | long
  G      | 09ff5eaa | temporal          | $0.30  | 13 s
  H      | 0d5f613b | field_extraction  | $1.00  | 96 s

Usage (from notebook entry)
----------------------------
from platform.v4.adapters.legacy_branch_adapter import LegacyBranchAdapter

adapter = LegacyBranchAdapter(dispatch_fn=dispatch)   # dispatch from V2 Cell 4
result = adapter.call("single_provider", question="What is the rate for Cedars-Sinai?")
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

from ..contracts.tool_types import Confidence, ToolResult, ToolStatus


# ---------------------------------------------------------------------------
# Branch metadata
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class _BranchMeta:
    letter:        str
    nuid:          str
    tool_name:     str
    cost_estimate: float
    latency_s:     float   # typical latency in seconds


_BRANCH_REGISTRY: list[_BranchMeta] = [
    _BranchMeta("A_ORCH", "c6fa4c41", "clause_existence",  5.50,   300.0),
    _BranchMeta("B",      "c02c2bf0", "single_provider",   0.50,    11.0),
    _BranchMeta("C",      "b35f866f", "comparison",        0.50,    32.0),
    _BranchMeta("D",      "c2c16a6c", "rate_query",        0.10,     7.0),
    _BranchMeta("E",      "428481f5", "explanation",       0.30,    25.0),
    _BranchMeta("F",      "47ad4591", "multi_concept",    12.00,   600.0),
    _BranchMeta("G",      "09ff5eaa", "temporal",          0.30,    13.0),
    _BranchMeta("H",      "0d5f613b", "field_extraction",  1.00,    96.0),
]

# tool_name → metadata
_BY_TOOL: dict[str, _BranchMeta] = {m.tool_name: m for m in _BRANCH_REGISTRY}
# nuid → metadata (for direct nuid lookups)
_BY_NUID: dict[str, _BranchMeta] = {m.nuid: m for m in _BRANCH_REGISTRY}


def available_branch_tools() -> list[str]:
    """Return the list of V3 tool names exposed by this adapter."""
    return list(_BY_TOOL.keys())


# ---------------------------------------------------------------------------
# Result normaliser
# ---------------------------------------------------------------------------

def _normalise_legacy_result(
    raw: Any,
    meta: _BranchMeta,
    elapsed: float,
) -> ToolResult:
    """
    Convert whatever the V2 dispatch() returns into a ToolResult.

    V2 branches return dicts with varying shapes.  The adapter
    normalises to the canonical V3 contract.
    """
    if raw is None:
        return ToolResult(
            success=False,
            data=None,
            summary="Branch returned None",
            confidence=Confidence.LOW,
            cost_estimate=meta.cost_estimate,
            execution_time_s=elapsed,
            error_message="dispatch() returned None",
        )

    if isinstance(raw, ToolResult):
        # Already normalised (e.g. from a test stub)
        return raw

    if isinstance(raw, dict):
        error = raw.get("error") or raw.get("error_message")
        if error:
            return ToolResult(
                success=False,
                data=raw,
                summary=str(error),
                confidence=Confidence.LOW,
                cost_estimate=meta.cost_estimate,
                execution_time_s=elapsed,
                error_message=str(error),
            )

        # Extract common keys from V2 result dicts
        answer    = raw.get("answer") or raw.get("response") or raw.get("result")
        citations = raw.get("citations") or raw.get("sources") or []
        summary   = raw.get("summary") or (str(answer)[:200] if answer else "")
        confidence_raw = raw.get("confidence", "MODERATE")
        confidence = (
            confidence_raw
            if confidence_raw in {Confidence.HIGH, Confidence.MODERATE, Confidence.LOW, Confidence.GENERATED}
            else Confidence.MODERATE
        )

        return ToolResult(
            success=True,
            data=raw,
            summary=summary,
            citations=citations if isinstance(citations, list) else [],
            confidence=confidence,
            cost_estimate=raw.get("cost_estimate", meta.cost_estimate),
            execution_time_s=elapsed,
            metadata={"branch": meta.letter, "nuid": meta.nuid},
        )

    # Scalar / string result
    return ToolResult(
        success=True,
        data=raw,
        summary=str(raw)[:300],
        confidence=Confidence.MODERATE,
        cost_estimate=meta.cost_estimate,
        execution_time_s=elapsed,
        metadata={"branch": meta.letter, "nuid": meta.nuid},
    )


# ---------------------------------------------------------------------------
# LegacyBranchAdapter
# ---------------------------------------------------------------------------

class LegacyBranchAdapter:
    """
    Wraps V2 Branches A–H behind a stable V3 interface.

    Parameters
    ----------
    dispatch_fn : callable
        The V2 ``dispatch()`` function from Cell 4 of Contract_Intelligence_V2.
        Signature: dispatch(routing: dict, question: str) -> dict
        Must be injected by the runtime entry point; never imported directly.
    """

    def __init__(self, dispatch_fn: Optional[Callable] = None) -> None:
        self._dispatch = dispatch_fn

    def set_dispatch(self, fn: Callable) -> None:
        """Late-bind the dispatch function (useful for notebook cells that load V2 first)."""
        self._dispatch = fn

    @property
    def is_ready(self) -> bool:
        """True when a dispatch_fn has been injected."""
        return self._dispatch is not None

    def call(
        self,
        tool_name: str,
        question: str,
        **kwargs: Any,
    ) -> ToolResult:
        """
        Call a V2 branch by its V3 tool name.

        Parameters
        ----------
        tool_name : str
            One of: clause_existence, single_provider, comparison, rate_query,
            explanation, multi_concept, temporal, field_extraction
        question  : str
            The natural-language question to pass to the branch.
        **kwargs  : Additional parameters forwarded to dispatch().
        """
        meta = _BY_TOOL.get(tool_name)
        if meta is None:
            return ToolResult(
                success=False,
                data=None,
                summary=f"Unknown branch tool: {tool_name}",
                confidence=Confidence.LOW,
                error_message=f"No branch mapping for tool '{tool_name}'",
            )

        if self._dispatch is None:
            # Graceful stub — returns a clearly labelled GENERATED result
            return ToolResult(
                success=False,
                data=None,
                summary=f"[STUB] dispatch_fn not injected — branch {meta.letter} unavailable",
                confidence=Confidence.GENERATED,
                cost_estimate=0.0,
                error_message="LegacyBranchAdapter.dispatch_fn is None; inject from notebook entry.",
            )

        t0 = time.time()
        try:
            # V2 dispatch() signature: dispatch(routing: dict, question: str)
            # Build routing dict from tool_name + kwargs.
            _TOOL_TO_ROUTE = {
                "clause_existence": "clause_existence",
                "single_provider":  "single_provider",
                "comparison":       "comparison",
                "rate_query":       "rate_query",
                "explanation":      "explanation",
                "multi_concept":    "multi_concept",
                "temporal":         "temporal",
                "field_extraction": "structured_extraction",
            }
            _prov = kwargs.pop("provider_name", None) or kwargs.pop("provider", None)
            routing = {
                "route":     _TOOL_TO_ROUTE.get(tool_name, tool_name),
                "concepts":  kwargs.pop("concepts", []),
                "providers": [_prov] if _prov else kwargs.pop("providers", []),
            }
            raw = self._dispatch(routing, question, **kwargs)
        except Exception as exc:  # noqa: BLE001
            return ToolResult(
                success=False,
                data=None,
                summary=f"Branch {meta.letter} raised: {exc}",
                confidence=Confidence.LOW,
                cost_estimate=meta.cost_estimate,
                execution_time_s=time.time() - t0,
                error_message=str(exc),
            )

        return _normalise_legacy_result(raw, meta, elapsed=time.time() - t0)

    def call_by_nuid(
        self,
        nuid: str,
        question: str,
        **kwargs: Any,
    ) -> ToolResult:
        """Call a branch directly by its cell nuid (for low-level debugging)."""
        meta = _BY_NUID.get(nuid)
        if meta is None:
            return ToolResult(
                success=False,
                data=None,
                summary=f"Unknown nuid: {nuid}",
                confidence=Confidence.LOW,
                error_message=f"No branch found with nuid '{nuid}'",
            )
        return self.call(meta.tool_name, question, **kwargs)

    def describe(self) -> list[dict]:
        """Return a list of branch metadata dicts (for registry introspection)."""
        return [
            {
                "tool_name":      m.tool_name,
                "branch_letter":  m.letter,
                "nuid":           m.nuid,
                "cost_estimate":  m.cost_estimate,
                "latency_s":      m.latency_s,
                "is_ready":       self.is_ready,
            }
            for m in _BRANCH_REGISTRY
        ]
