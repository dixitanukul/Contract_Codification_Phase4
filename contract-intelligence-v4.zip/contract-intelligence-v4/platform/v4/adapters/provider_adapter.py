"""
platform/v4/adapters/provider_adapter.py

Canonical provider resolution for V3.

Reads from dim_provider_canonical and related tables via Spark SQL.
All provider lookups in V3 flow through this adapter; no other module
may query provider tables directly.

Tables used
-----------
  dev_adb.raw.dim_provider_canonical   531 rows  (531 IDs → 305 unique facilities)
  dev_adb.raw.tbl_genie_provider_profile  305 rows
  dev_adb.raw.tbl_genie_rates_current     51,109 rows
  dev_adb.raw.tbl_genie_amendment_timeline  6,609 rows

Key facts (from branch_test_results.md)
----------------------------------------
  - dim_provider_canonical.all_names_used contains alias arrays
  - Cedars-Sinai: 16 alias entries loaded including hyphen-stripped variants
  - Kaiser: 0 rows in corpus — not a contracted provider
  - Provider ID is NOT a unique key; name deduplication required
"""
from __future__ import annotations

import re
import time
from dataclasses import dataclass, field
from typing import Any, Optional

from ..contracts.tool_types import Confidence, ToolResult


# ---------------------------------------------------------------------------
# Canonical provider dataclass
# ---------------------------------------------------------------------------

@dataclass
class CanonicalProvider:
    """Resolved canonical provider identity."""
    canonical_id:   str
    canonical_name: str
    all_names:      list[str] = field(default_factory=list)
    provider_ids:   list[str] = field(default_factory=list)
    profile:        dict      = field(default_factory=dict)
    match_score:    float     = 1.0   # 0–1 fuzzy confidence
    match_method:   str       = "exact"

    def as_dict(self) -> dict:
        return {
            "canonical_id":   self.canonical_id,
            "canonical_name": self.canonical_name,
            "all_names":      self.all_names,
            "provider_ids":   self.provider_ids,
            "match_score":    self.match_score,
            "match_method":   self.match_method,
        }


# ---------------------------------------------------------------------------
# ProviderAdapter
# ---------------------------------------------------------------------------

CATALOG = "dev_adb"
SCHEMA  = "raw"


class ProviderAdapter:
    """
    Canonical provider resolution and profile retrieval.

    Parameters
    ----------
    spark : SparkSession, optional
        Active Spark session.  Must be injected before use.
    cache : dict, optional
        In-memory provider cache (pre-populated from context_manager or
        injected from the notebook entry point).  Key: lower-cased provider name.
    """

    def __init__(
        self,
        spark:  Optional[Any] = None,
        cache:  Optional[dict] = None,
    ) -> None:
        self._spark = spark
        self._cache: dict[str, CanonicalProvider] = cache or {}

    def set_spark(self, spark: Any) -> None:
        self._spark = spark

    def set_cache(self, cache: dict) -> None:
        """Inject a pre-built provider cache (e.g. from ContextManager._CANONICAL_CACHE)."""
        self._cache = cache

    @property
    def is_ready(self) -> bool:
        return self._spark is not None

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    def resolve(self, provider_name: str) -> ToolResult:
        """
        Resolve a free-text provider name to its canonical identity.

        Lookup order:
          1. In-memory cache (exact, then normalised)
          2. dim_provider_canonical SQL lookup (name + alias match)
          3. Fuzzy SQL LIKE fallback
        """
        t0    = time.time()
        name  = provider_name.strip()
        norm  = self._normalise(name)

        # --- Cache hit ---
        if norm in self._cache:
            cp = self._cache[norm]
            return ToolResult(
                success=True,
                data=cp,
                summary=f"Resolved '{name}' → '{cp.canonical_name}' (cache)",
                confidence=Confidence.HIGH,
                execution_time_s=time.time() - t0,
                metadata={"method": "cache"},
            )

        if self._spark is None:
            return ToolResult(
                success=False,
                data=None,
                summary=f"[STUB] spark not injected — cannot resolve '{name}'",
                confidence=Confidence.GENERATED,
                error_message="ProviderAdapter.spark is None; inject from notebook entry.",
            )

        # --- SQL lookup ---
        cp = self._sql_resolve(name, norm)
        elapsed = time.time() - t0

        if cp is None:
            return ToolResult(
                success=False,
                data=None,
                summary=f"Provider '{name}' not found in dim_provider_canonical",
                confidence=Confidence.LOW,
                execution_time_s=elapsed,
                error_message=f"No canonical match for '{name}'",
            )

        # Populate cache
        self._cache[norm] = cp
        self._cache[self._normalise(cp.canonical_name)] = cp

        return ToolResult(
            success=True,
            data=cp,
            summary=f"Resolved '{name}' → '{cp.canonical_name}' ({cp.match_method})",
            confidence=Confidence.HIGH if cp.match_score > 0.8 else Confidence.MODERATE,
            execution_time_s=elapsed,
            metadata={"method": cp.match_method, "score": cp.match_score},
        )

    def get_profile(self, canonical_name: str) -> ToolResult:
        """
        Return provider profile from tbl_genie_provider_profile.
        Includes contract count, specialty, network tier, etc.
        """
        if self._spark is None:
            return ToolResult(
                success=False,
                data=None,
                summary="[STUB] spark not injected",
                confidence=Confidence.GENERATED,
                error_message="ProviderAdapter.spark is None",
            )
        t0 = time.time()
        try:
            df = self._spark.sql(f"""
                SELECT *
                FROM {CATALOG}.{SCHEMA}.tbl_genie_provider_profile
                WHERE LOWER(provider_name) = LOWER('{canonical_name.replace("'", "''")}')
                LIMIT 1
            """)
            rows = df.collect()
            if not rows:
                return ToolResult(
                    success=False,
                    data=None,
                    summary=f"No profile found for '{canonical_name}'",
                    confidence=Confidence.LOW,
                    execution_time_s=time.time() - t0,
                )
            profile = rows[0].asDict()
            return ToolResult(
                success=True,
                data=profile,
                summary=f"Profile loaded for '{canonical_name}'",
                confidence=Confidence.HIGH,
                execution_time_s=time.time() - t0,
            )
        except Exception as exc:  # noqa: BLE001
            return ToolResult(
                success=False,
                data=None,
                summary=f"Profile query error: {exc}",
                confidence=Confidence.LOW,
                execution_time_s=time.time() - t0,
                error_message=str(exc),
            )

    def list_providers(self, limit: int = 50) -> ToolResult:
        """Return a list of all canonical providers (for disambiguation)."""
        if self._spark is None:
            return ToolResult(
                success=False,
                data=[],
                summary="[STUB] spark not injected",
                confidence=Confidence.GENERATED,
                error_message="ProviderAdapter.spark is None",
            )
        t0 = time.time()
        try:
            df = self._spark.sql(f"""
                SELECT DISTINCT canonical_name, provider_id
                FROM {CATALOG}.{SCHEMA}.dim_provider_canonical
                WHERE is_primary_id = TRUE
                ORDER BY canonical_name
                LIMIT {limit}
            """)
            rows = [r.asDict() for r in df.collect()]
            return ToolResult(
                success=True,
                data=rows,
                summary=f"Listed {len(rows)} canonical providers",
                confidence=Confidence.HIGH,
                execution_time_s=time.time() - t0,
            )
        except Exception as exc:  # noqa: BLE001
            return ToolResult(
                success=False,
                data=[],
                summary=f"List providers error: {exc}",
                confidence=Confidence.LOW,
                execution_time_s=time.time() - t0,
                error_message=str(exc),
            )

    def preload_cache(self) -> int:
        """
        Load all canonical provider names into the in-memory cache.
        Returns the number of entries loaded.
        Call from notebook_entry.py at startup.
        """
        if self._spark is None:
            return 0
        try:
            df = self._spark.sql(f"""
                SELECT provider_id, canonical_name, all_names_used
                FROM {CATALOG}.{SCHEMA}.dim_provider_canonical
                WHERE is_primary_id = TRUE
            """)
            count = 0
            for row in df.collect():
                cp = CanonicalProvider(
                    canonical_id   = str(row["provider_id"]),
                    canonical_name = row["canonical_name"],
                    all_names      = list(row["all_names_used"] or []),
                    provider_ids   = [str(row["provider_id"])],
                    match_method   = "preload",
                )
                key = self._normalise(row["canonical_name"])
                self._cache[key] = cp
                for alias in (row["all_names_used"] or []):
                    self._cache[self._normalise(str(alias))] = cp
                count += 1
            return count
        except Exception:  # noqa: BLE001
            return 0

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _normalise(name: str) -> str:
        """Normalise a provider name for cache key comparison."""
        return re.sub(r"[^a-z0-9]", " ", name.lower()).strip()

    def _sql_resolve(self, name: str, norm: str) -> Optional[CanonicalProvider]:
        """Run SQL against dim_provider_canonical to find a match."""
        escaped = name.replace("'", "''")
        try:
            # Exact canonical name match
            df = self._spark.sql(f"""
                SELECT provider_id, canonical_name, all_names_used
                FROM {CATALOG}.{SCHEMA}.dim_provider_canonical
                WHERE LOWER(canonical_name) = LOWER('{escaped}')
                  AND is_primary_id = TRUE
                LIMIT 1
            """)
            rows = df.collect()
            if rows:
                r = rows[0]
                return CanonicalProvider(
                    canonical_id   = str(r["provider_id"]),
                    canonical_name = r["canonical_name"],
                    all_names      = list(r["all_names_used"] or []),
                    match_method   = "exact_sql",
                    match_score    = 1.0,
                )

            # Alias match: search within all_names_used array
            df_alias = self._spark.sql(f"""
                SELECT provider_id, canonical_name, all_names_used
                FROM {CATALOG}.{SCHEMA}.dim_provider_canonical
                WHERE ARRAY_CONTAINS(TRANSFORM(all_names_used, x -> LOWER(x)), LOWER('{escaped}'))
                  AND is_primary_id = TRUE
                LIMIT 1
            """)
            rows_alias = df_alias.collect()
            if rows_alias:
                r = rows_alias[0]
                return CanonicalProvider(
                    canonical_id   = str(r["provider_id"]),
                    canonical_name = r["canonical_name"],
                    all_names      = list(r["all_names_used"] or []),
                    match_method   = "alias_sql",
                    match_score    = 0.9,
                )

            # LIKE fallback (leading/trailing wildcard on canonical_name)
            df2 = self._spark.sql(f"""
                SELECT provider_id, canonical_name, all_names_used
                FROM {CATALOG}.{SCHEMA}.dim_provider_canonical
                WHERE LOWER(canonical_name) LIKE '%{escaped.lower()}%'
                  AND is_primary_id = TRUE
                ORDER BY LENGTH(canonical_name)
                LIMIT 1
            """)
            rows2 = df2.collect()
            if rows2:
                r = rows2[0]
                return CanonicalProvider(
                    canonical_id   = str(r["provider_id"]),
                    canonical_name = r["canonical_name"],
                    all_names      = list(r["all_names_used"] or []),
                    match_method   = "like_sql",
                    match_score    = 0.75,
                )
        except Exception as _exc:  # noqa: BLE001
            import logging
            logging.getLogger(__name__).warning("_sql_resolve failed: %s", _exc)
        return None
