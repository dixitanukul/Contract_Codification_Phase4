"""
platform/v4/adapters/retrieval_adapter.py

V4 wrapper around the V4 retrieval services.

Design
------
- A `retrieve_fn` callable is injected from the notebook entry point;
  the adapter never imports retrieval engine internals directly.
- Supports two call modes:
    1. retrieve(query, ...) → list[RetrievedPassage]    (4-channel hybrid + RRF)
    2. retrieve_legal(query, ...) → list[RetrievedPassage] (routes to unified index)
- Normalises results to a canonical V4 RetrievedPassage shape.
- Logs retrieval telemetry through the telemetry_repo
  (injected; optional — skipped if not set).

V4 retrieval assets (dev_adb.raw)
----------------------------------
  VS index (unified) : dev_adb.raw.idx_unified_v4          (727,875 chunks, GTE-1024d)
  Backing table      : dev_adb.raw.tbl_vs_unified_ready     (727,875 rows)

Both retrieve() and retrieve_legal() route to idx_unified_v4.
retrieve_legal() applies chunk_type filtering to target structured
legal-unit chunks within the same unified index.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

from ..contracts.tool_types import Confidence, ToolResult


# ---------------------------------------------------------------------------
# V3 canonical retrieval result shape
# ---------------------------------------------------------------------------

@dataclass
class RetrievedPassage:
    """One retrieved passage in V3 canonical form."""
    doc_id:        str
    provider_name: str
    page_number:   Optional[int]
    section:       Optional[str]
    text:          str
    score:         float
    channel:       str      # bm25 | semantic | legal | metadata
    contract_id:   Optional[str] = None
    effective_date: Optional[str] = None
    is_current_effective: bool = False
    metadata:      dict = field(default_factory=dict)

    def as_citation(self) -> dict:
        """W9-17: Full provenance citation including source_filename."""
        return {
            "doc_id":          self.doc_id,
            "provider_name":   self.provider_name,
            "page_number":     self.page_number,
            "section":         self.section,
            "contract_id":     self.contract_id,
            "source_filename": self.metadata.get("source_filename", ""),
        }


# ---------------------------------------------------------------------------
# Field extraction helper
# ---------------------------------------------------------------------------

_SENTINEL = object()


def _get(raw: Any, *keys: str, default: Any = None) -> Any:
    """
    Return the first non-None value found under any of `keys` in `raw`.

    Works for both dicts (raw.get) and arbitrary objects (getattr), so
    ScoredChunk dataclasses (which may have class-level attrs that are
    invisible to vars()) are handled correctly.
    """
    for k in keys:
        if isinstance(raw, dict):
            val = raw.get(k, _SENTINEL)
        else:
            val = getattr(raw, k, _SENTINEL)
        if val is not _SENTINEL and val is not None:
            return val
    return default


def _normalise_chunk(raw: Any, rank: int) -> RetrievedPassage:
    """
    Convert a legacy ScoredChunk (dataclass OR dict) to a V3 RetrievedPassage.

    Uses _get() rather than vars()/dict conversion so it handles both:
    - @dataclass instances (whose attrs may live on the class, not the instance __dict__)
    - plain dict results from other retrieval paths

    ScoredChunk field mapping:
        unit_id       -> doc_id   (preferred; fallback: doc_id, document_id, source_filename)
        unit_text     -> text     (preferred; fallback: text, chunk_text, passage)
        section_type  -> section  (preferred; fallback: section, clause_type)
        is_current    -> is_current_effective (preferred; fallback: is_current_effective)
        source_filename carried into metadata as a stable document key.
    """
    doc_id = _get(raw, "unit_id", "doc_id", "document_id", "source_filename", default="")
    text   = _get(raw, "unit_text", "text", "chunk_text", "passage", default="")
    section = _get(raw, "section_type", "section", "clause_type")
    score   = _get(raw, "rrf_score", "score", default=0.0)

    # is_current (ScoredChunk) vs is_current_effective (generic dicts)
    is_current_raw = _get(raw, "is_current", "is_current_effective")
    is_current = bool(is_current_raw) if is_current_raw is not None else False

    return RetrievedPassage(
        doc_id          = doc_id,
        provider_name   = _get(raw, "provider_name", "provider", default=""),
        page_number     = _get(raw, "page_number", "page"),
        section         = section,
        text            = text,
        score           = float(score) if score else 0.0,
        channel         = _get(raw, "channel", default="unknown"),
        contract_id     = _get(raw, "contract_id"),
        effective_date  = _get(raw, "effective_date"),
        is_current_effective = is_current,
        metadata        = {
            "rank":            rank,
            "source_filename": _get(raw, "source_filename", default=""),
            "unit_type":       _get(raw, "unit_type", default=""),
            "rate_domain":     _get(raw, "rate_domain", default=""),
        },
    )


# ---------------------------------------------------------------------------
# RetrievalAdapter
# ---------------------------------------------------------------------------

class RetrievalAdapter:
    """
    Wraps the legacy 4-channel hybrid retrieval engine for V3.

    P3-RET-3 update: also accepts a ``retrieval_service`` (RetrievalService)
    as a drop-in replacement for the ``retrieve_fn`` closure.  When
    ``retrieval_service`` is provided and ``retrieve_fn`` is None, the adapter
    uses the native service path (``_call_native``) instead of the legacy
    closure path.  This enables zero-V2-dependency operation from
    ``init_runtime_standalone``.

    Backward compatibility: passing ``retrieve_fn`` continues to work exactly
    as before; ``retrieval_service`` is only used when ``retrieve_fn`` is None.

    Parameters
    ----------
    retrieve_fn      : callable, optional
        A callable with signature:
            retrieve_fn(query: str, top_k: int = 30, provider_id: str = None)
                -> RetrievalResult | list[ScoredChunk | dict]

        In practice this is either:
          - a bound method: HybridRetriever().retrieve
          - a plain function matching the same contract

    retrieval_service : RetrievalService, optional
        V3-native RetrievalService (P3-RET-1).  Used when retrieve_fn is None.

    retrieve_legal_fn: callable, optional
        The legal-unit index retrieval function. Same signature as retrieve_fn.
        Falls back to retrieve_fn if not provided.

    telemetry_repo   : object, optional
        If provided, calls telemetry_repo.log_retrieval(event_dict) for each
        retrieve call.  Injected from runtime entry point.
    """

    def __init__(
        self,
        retrieve_fn:              Optional[Callable] = None,
        retrieve_legal_fn:        Optional[Callable] = None,
        telemetry_repo:           Optional[Any]       = None,
        current_effective_filter: Optional[Any]       = None,
        retrieval_service:        Optional[Any]       = None,  # P3-RET-3
    ) -> None:
        self._retrieve           = retrieve_fn
        self._retrieve_legal     = retrieve_legal_fn
        self._telemetry          = telemetry_repo
        self._current_filter     = current_effective_filter
        self._retrieval_service  = retrieval_service  # P3-RET-3

    def set_fns(
        self,
        retrieve_fn:       Callable,
        retrieve_legal_fn: Optional[Callable] = None,
    ) -> None:
        """Late-bind retrieval functions (useful in notebook cells)."""
        self._retrieve       = retrieve_fn
        self._retrieve_legal = retrieve_legal_fn

    @property
    def is_ready(self) -> bool:
        # P3-RET-3: also ready when a native RetrievalService is wired in
        return self._retrieve is not None or self._retrieval_service is not None

    # ------------------------------------------------------------------
    # Public retrieval interface
    # ------------------------------------------------------------------

    def retrieve(
        self,
        query:      str,
        top_k:      int = 10,
        provider:   Optional[str] = None,
        clause_type: Optional[str] = None,
        current_only: bool = True,
        **kwargs:   Any,
    ) -> ToolResult:
        """
        4-channel hybrid retrieval (fulltext + semantic + legal + metadata).

        Returns a ToolResult where .data is a list[RetrievedPassage].

        Parameters
        ----------
        current_only : bool
            If True (default), filters results to only include passages from
            current-effective documents (not expired). Set False for temporal/
            amendment analysis that needs historical docs.

        Note: `clause_type` is accepted for forward-compatibility but is not
        passed to the legacy HybridRetriever (which does not support it).
        """
        return self._call(
            fn=self._retrieve,
            fn_name="retrieve",
            query=query,
            top_k=top_k,
            provider=provider,
            clause_type=clause_type,
            current_only=current_only,
            **kwargs,
        )

    def retrieve_legal(
        self,
        query:   str,
        top_k:   int = 10,
        **kwargs: Any,
    ) -> ToolResult:
        """
        Legal-unit retrieval via idx_unified_v4 (chunk_type filtering).

        Falls back to retrieve() if retrieve_legal_fn is not injected.
        """
        fn = self._retrieve_legal or self._retrieve
        return self._call(
            fn=fn,
            fn_name="retrieve_legal",
            query=query,
            top_k=top_k,
            **kwargs,
        )

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _call(
        self,
        fn:       Optional[Callable],
        fn_name:  str,
        query:    str,
        top_k:    int,
        current_only: bool = True,
        **kwargs: Any,
    ) -> ToolResult:
        # P3-RET-3: if legacy fn is absent but native service is wired, use it
        if fn is None and self._retrieval_service is not None:
            return self._call_native(
                fn_name=fn_name,
                query=query,
                top_k=top_k,
                current_only=current_only,
                **kwargs,
            )

        if fn is None:
            return ToolResult(
                success=False,
                data=[],
                summary=f"[STUB] {fn_name} not injected — retrieval unavailable",
                confidence=Confidence.GENERATED,
                error_message=f"RetrievalAdapter.{fn_name} is None; inject from notebook entry.",
            )

        # ------------------------------------------------------------------
        # Translate adapter kwargs to legacy HybridRetriever kwargs.
        #   adapter `provider`    → legacy `provider_id`
        #   adapter `clause_type` → NOT supported by HybridRetriever; dropped
        # ------------------------------------------------------------------
        call_kwargs: dict = {}
        if kwargs.get("provider"):
            call_kwargs["provider_id"] = kwargs["provider"]
        # Drop clause_type — not accepted by HybridRetriever.retrieve()
        # Propagate any other explicit legacy kwargs (e.g. provider_id if caller passed it directly)
        for k, v in kwargs.items():
            if k not in ("provider", "clause_type") and k not in call_kwargs:
                call_kwargs[k] = v

        t0 = time.time()
        try:
            raw_result = fn(query, top_k=top_k, **call_kwargs)
        except Exception as exc:  # noqa: BLE001
            return ToolResult(
                success=False,
                data=[],
                summary=f"Retrieval error: {exc}",
                confidence=Confidence.LOW,
                execution_time_s=time.time() - t0,
                error_message=str(exc),
            )

        elapsed = time.time() - t0

        # ------------------------------------------------------------------
        # Unpack result — handle RetrievalResult dataclass from HybridRetriever
        # or a plain list from other retrieval callables.
        # ------------------------------------------------------------------
        should_refuse = False
        refuse_message = ""

        if hasattr(raw_result, "results"):
            # RetrievalResult from HybridRetriever
            should_refuse  = bool(getattr(raw_result, "should_refuse", False))
            refuse_message = getattr(raw_result, "message", "")
            raw_chunks     = raw_result.results if not should_refuse else []
        elif isinstance(raw_result, list):
            raw_chunks = raw_result
        else:
            raw_chunks = []

        if should_refuse:
            return ToolResult(
                success=False,
                data=[],
                summary=refuse_message or "Retrieval refused: insufficient evidence",
                confidence=Confidence.LOW,
                execution_time_s=elapsed,
                error_message=refuse_message,
            )

        if not isinstance(raw_chunks, list):
            raw_chunks = []

        passages  = [_normalise_chunk(c, i) for i, c in enumerate(raw_chunks)]

        # W7-2: Apply current-effective filter (removes expired docs)
        if current_only and self._current_filter is not None:
            passages = self._current_filter.apply(passages)

        # Recency sort: surface the most recently dated amendment first.
        # Purely data-driven — uses the effective_date already on each passage.
        # When is_current marks too many historical docs as current (data quality
        # issue), this ensures the LLM context window is dominated by the newest
        # contract terms.  No hard-coded dates, providers, or document names.
        if current_only and passages:
            def _date_key(p: Any) -> str:
                d = getattr(p, 'effective_date', None)
                if not d:
                    return ''
                s = str(d).strip()
                # ISO format (YYYY-MM-DD) — already sortable
                if len(s) >= 10 and s[4:5] == '-':
                    return s[:10]
                # Month-name format: "January 1, 2009" → "2009-01-01"
                # Without this, 'J' (74) > '2' (50) in ASCII so "July 2007"
                # wrongly sorts above "2025-06-01".
                import re as _re_dk
                _DK_MONTHS = {
                    'january':'01','february':'02','march':'03','april':'04',
                    'may':'05','june':'06','july':'07','august':'08',
                    'september':'09','october':'10','november':'11','december':'12',
                }
                _dm = _re_dk.match(r'(\w+)\s+(\d+),?\s+(\d{4})', s, _re_dk.IGNORECASE)
                if _dm:
                    mo, dy, yr = _dm.group(1).lower(), _dm.group(2).zfill(2), _dm.group(3)
                    if mo in _DK_MONTHS:
                        return f"{yr}-{_DK_MONTHS[mo]}-{dy}"
                return s
            passages = sorted(passages, key=_date_key, reverse=True)

        citations = [p.as_citation() for p in passages]

        summary = (
            f"Retrieved {len(passages)} passages for: {query[:80]}"
            if passages
            else f"No passages found for: {query[:80]}"
        )

        confidence = Confidence.HIGH if passages else Confidence.LOW

        self._log_telemetry(query, fn_name, len(passages), elapsed, kwargs)

        return ToolResult(
            success=True,
            data=passages,
            summary=summary,
            citations=citations,
            confidence=confidence,
            execution_time_s=elapsed,
            metadata={"query": query, "top_k": top_k, "channel": fn_name},
        )

    def _call_native(
        self,
        fn_name:      str,
        query:        str,
        top_k:        int,
        current_only: bool = True,
        **kwargs:     Any,
    ) -> ToolResult:
        """
        P3-RET-3: Native service path via RetrievalService.

        Used when retrieve_fn is None but retrieval_service is wired.  The
        service already applies current-effective filtering (when current_only
        is True), so we do NOT re-apply self._current_filter here.
        """
        provider_name = kwargs.get("provider") or kwargs.get("provider_id")
        t0 = time.time()
        try:
            if fn_name == "retrieve_legal":
                raw_chunks: list = self._retrieval_service.retrieve_legal(
                    query, top_k=top_k
                )
            else:
                raw_chunks = self._retrieval_service.retrieve(
                    query,
                    provider_name=provider_name,
                    top_k=top_k,
                    current_only=current_only,
                )
        except Exception as exc:  # noqa: BLE001
            return ToolResult(
                success=False,
                data=[],
                summary=f"RetrievalService error: {exc}",
                confidence=Confidence.LOW,
                execution_time_s=time.time() - t0,
                error_message=str(exc),
            )

        elapsed = time.time() - t0

        # Normalise to V3 RetrievedPassage objects (same as legacy path)
        # Note: _current_filter NOT re-applied — service already filtered
        passages  = [_normalise_chunk(c, i) for i, c in enumerate(raw_chunks)]

        # Recency sort: surface the most recently dated amendment first.
        # Purely data-driven — same logic as legacy path (no hard coding).
        if current_only and passages:
            def _date_key_native(p: Any) -> str:
                d = getattr(p, 'effective_date', None)
                if not d:
                    return ''
                s = str(d).strip()
                if len(s) >= 10 and s[4:5] == '-':
                    return s[:10]
                import re as _re_dkn
                _DKN_MONTHS = {
                    'january':'01','february':'02','march':'03','april':'04',
                    'may':'05','june':'06','july':'07','august':'08',
                    'september':'09','october':'10','november':'11','december':'12',
                }
                _dnm = _re_dkn.match(r'(\w+)\s+(\d+),?\s+(\d{4})', s, _re_dkn.IGNORECASE)
                if _dnm:
                    mo, dy, yr = _dnm.group(1).lower(), _dnm.group(2).zfill(2), _dnm.group(3)
                    if mo in _DKN_MONTHS:
                        return f"{yr}-{_DKN_MONTHS[mo]}-{dy}"
                return s
            passages = sorted(passages, key=_date_key_native, reverse=True)

        citations = [p.as_citation() for p in passages]

        summary = (
            f"Retrieved {len(passages)} passages for: {query[:80]}"
            if passages
            else f"No passages found for: {query[:80]}"
        )

        confidence = Confidence.HIGH if passages else Confidence.LOW

        self._log_telemetry(query, fn_name, len(passages), elapsed, kwargs)

        return ToolResult(
            success=True,
            data=passages,
            summary=summary,
            citations=citations,
            confidence=confidence,
            execution_time_s=elapsed,
            metadata={"query": query, "top_k": top_k, "channel": fn_name, "path": "native"},
        )

    def _log_telemetry(
        self,
        query:    str,
        channel:  str,
        n_hits:   int,
        elapsed:  float,
        kwargs:   dict,
    ) -> None:
        """Fire-and-forget telemetry log; swallow all errors."""
        if self._telemetry is None:
            return
        try:
            self._telemetry.log_retrieval({
                "query":          query[:200],
                "channel":        channel,
                "hits":           n_hits,
                "latency_s":      round(elapsed, 3),
                "provider_filter": kwargs.get("provider"),
                "clause_filter":  kwargs.get("clause_type"),
            })
        except Exception:  # noqa: BLE001
            pass
