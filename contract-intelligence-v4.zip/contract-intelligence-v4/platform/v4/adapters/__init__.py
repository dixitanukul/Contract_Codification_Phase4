"""platform/v4/adapters — Clean wrappers over legacy V2 assets."""
from .legacy_branch_adapter import LegacyBranchAdapter
from .retrieval_adapter import RetrievalAdapter
from .citation_adapter import CitationAdapter
from .provider_adapter import ProviderAdapter
from .notebook_compat_adapter import compat_dispatch

__all__ = [
    "LegacyBranchAdapter", "RetrievalAdapter", "CitationAdapter",
    "ProviderAdapter", "compat_dispatch",
]
