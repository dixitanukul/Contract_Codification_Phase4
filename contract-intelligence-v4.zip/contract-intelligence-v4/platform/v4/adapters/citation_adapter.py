"""
platform/v4/adapters/citation_adapter.py

Clean V3 wrapper around platform/07_citation_verification.py.

Design
------
- A `verify_fn` callable is injected from the notebook entry point, OR
  three separate legacy check functions are injected via set_fns().
- The adapter exposes a single `verify(passages)` method that runs
  all available verification checks and returns a VerificationResult.
- If verify_fn is not injected, the adapter returns a graceful stub
  so the agent can still run without citation verification.

Legacy verification checks (platform/07_citation_verification.py)
------------------------------------------------------------------
  The legacy module exposes THREE separate functions (no unified verify()):

  1. check_supersession_risk(source_filenames, provider_name=None)
         -> SupersessionRisk(has_risk, at_risk_sources, warning_message)

  2. verify_key_phrase(key_phrase, passage_text, window=20) -> bool

  3. verify_numerical_claims(claim_text, evidence_text) -> Dict

  Injection via set_fn(fn):
      Pass a pre-built unified wrapper if you need custom composition.

  Injection via set_fns(check_supersession_fn, verify_phrase_fn, verify_numerical_fn):
      Preferred for direct wiring from notebook_entry.py — the adapter
      builds the unified wrapper internally.

  The internal wrapper (built by set_fns) calls each available check
  and aggregates results into the unified dict expected by _normalise_result.

Canonical types (platform/v4/contracts/citation_types.py)
----------------------------------------------------------
  VerificationStatus: VERIFIED | SUPERSEDED | UNVERIFIABLE | HALLUCINATED | PENDING
  Citation fields   : source_doc_id, provider_name, passage_text, page_number,
                      clause_type, effective_date, is_current_effective, doc_role,
                      amendment_order, confidence, retrieval_score
  VerificationResult fields: claim_text, status, supporting_citations, risk_flags,
                              numerical_check_passed, temporal_check_passed,
                              supersession_risk, notes
  Citation.to_dict() (NOT .as_dict())
"""
from __future__ import annotations

import time
from typing import Any, Callable, Optional

from ..contracts.citation_types import (
    Citation,
    VerificationResult,
    VerificationStatus,
)
from ..contracts.tool_types import Confidence, ToolResult


# ---------------------------------------------------------------------------
# CitationAdapter
# ---------------------------------------------------------------------------

class CitationAdapter:
    """
    Wraps the legacy citation verification engine for V3.

    Parameters
    ----------
    verify_fn : callable, optional
        A unified verify() function with signature:
            verify_fn(passages: list[dict], **kwargs) -> dict
        Use set_fns() instead when injecting the three separate legacy functions
        directly from platform/07_citation_verification.py.
    """

    def __init__(self, verify_fn: Optional[Callable] = None) -> None:
        self._verify = verify_fn

    # ------------------------------------------------------------------
    # Injection interface
    # ------------------------------------------------------------------

    def set_fn(self, fn: Callable) -> None:
        """Late-bind a pre-built unified verification function."""
        self._verify = fn

    def set_fns(
        self,
        check_supersession_fn: Optional[Callable] = None,
        verify_phrase_fn:      Optional[Callable] = None,
        verify_numerical_fn:   Optional[Callable] = None,
    ) -> None:
        """
        Late-bind the three separate legacy verification functions from
        platform/07_citation_verification.py.

        The adapter builds a unified wrapper internally so the agent
        calls a single verify(passages) interface regardless of what
        the legacy module exposes.

        Parameters
        ----------
        check_supersession_fn : check_supersession_risk(source_filenames, provider_name=None)
                                    -> SupersessionRisk(has_risk, at_risk_sources, warning_message)
        verify_phrase_fn      : verify_key_phrase(key_phrase, passage_text, window=20) -> bool
        verify_numerical_fn   : verify_numerical_claims(claim_text, evidence_text) -> Dict
        """
        _sup_fn = check_supersession_fn
        _phr_fn = verify_phrase_fn
        _num_fn = verify_numerical_fn

        def _unified_verify(passages: list, **kw: Any) -> dict:
            """
            Unified wrapper built from the three separate legacy check functions.
            Runs available checks and returns a normalised dict compatible with
            _normalise_result().
            """
            # ---- 1. Supersession check --------------------------------
            source_filenames = [
                p.get("source_filename") or p.get("source_doc_id") or p.get("doc_id", "")
                for p in passages
                if (p.get("source_filename") or p.get("source_doc_id") or p.get("doc_id"))
            ]
            provider_name = kw.get("provider_name") or kw.get("provider")

            supersession_risk    = False
            at_risk_sources: list = []
            supersession_warning = ""

            if _sup_fn and source_filenames:
                try:
                    sup = _sup_fn(source_filenames, provider_name=provider_name)
                    supersession_risk    = bool(getattr(sup, "has_risk", False))
                    at_risk_sources      = list(getattr(sup, "at_risk_sources", []))
                    supersession_warning = getattr(sup, "warning_message", "")
                except Exception as e:  # noqa: BLE001
                    supersession_warning = f"Supersession check failed (non-fatal): {e}"

            at_risk_files = {r.get("source_filename", "") for r in at_risk_sources}

            # ---- 2. Key-phrase grounding per passage ------------------
            phrase = kw.get("key_phrase") or kw.get("phrase")
            citations_out: list[dict] = []
            risk_flags: list[str]     = []

            for p in passages:
                # src_file = filename used for supersession lookup (source_filename preferred)
                src_file  = (
                    p.get("source_filename")
                    or p.get("source_doc_id")
                    or p.get("doc_id", "")
                )
                # citation_key = canonical doc identity (source_doc_id preferred over filename)
                citation_key = (
                    p.get("source_doc_id")
                    or p.get("unit_id")
                    or p.get("doc_id")
                    or src_file
                )
                text      = p.get("unit_text") or p.get("passage_text") or p.get("text") or ""
                page      = p.get("page_number") or p.get("page")
                clause    = p.get("section_type") or p.get("clause_type") or ""
                eff_date  = p.get("effective_date")
                is_curr   = bool(p.get("is_current_effective") or p.get("is_current", True))
                doc_role  = p.get("doc_role", "")
                amend_ord = p.get("amendment_order")
                score     = float(p.get("score") or p.get("rrf_score") or p.get("retrieval_score", 0.0))
                prov_name = p.get("provider_name") or p.get("provider", "")

                superseded = src_file in at_risk_files if src_file else False

                grounded = True
                if _phr_fn and phrase and text:
                    try:
                        grounded = bool(_phr_fn(phrase, text))
                    except Exception:  # noqa: BLE001
                        grounded = True  # non-fatal

                if superseded:
                    status_str = "SUPERSEDED"
                    risk_flags.append(f"superseded:{src_file}")
                elif not grounded:
                    status_str = "HALLUCINATED"
                    risk_flags.append(f"not_grounded:{src_file}")
                else:
                    status_str = "VERIFIED"

                citations_out.append({
                    "source_doc_id":      citation_key,   # canonical identity, not filename
                    "provider_name":      prov_name,
                    "passage_text":       text,
                    "page_number":        page,
                    "clause_type":        clause,
                    "effective_date":     eff_date,
                    "is_current_effective": is_curr,
                    "doc_role":           doc_role,
                    "amendment_order":    amend_ord,
                    "retrieval_score":    score,
                    "status":             status_str,
                })

            # ---- 3. Overall status -----------------------------------
            statuses = {c["status"] for c in citations_out}
            if "HALLUCINATED" in statuses:
                overall = "HALLUCINATED"
            elif "SUPERSEDED" in statuses and "VERIFIED" not in statuses:
                overall = "SUPERSEDED"
            elif "SUPERSEDED" in statuses:
                overall = "UNVERIFIABLE"    # mixed superseded + verified
            else:
                overall = "VERIFIED"

            return {
                "status":            overall,
                "citations":         citations_out,
                "notes":             supersession_warning,
                "risk_flags":        risk_flags,
                "supersession_risk": supersession_risk,
            }

        self._verify = _unified_verify

    @property
    def is_ready(self) -> bool:
        return self._verify is not None

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    def verify(
        self,
        passages:  list[dict],
        claim_text: str = "",
        **kwargs:  Any,
    ) -> ToolResult:
        """
        Run citation verification checks on a list of passages.

        Parameters
        ----------
        passages   : list[dict]
            Passage dicts as returned by the retrieval adapter.
            Should have at least: source_doc_id (or doc_id/unit_id), passage_text (or text/unit_text).
        claim_text : str
            The claim being verified (optional; used as label in VerificationResult).

        Returns
        -------
        ToolResult
            .data is a VerificationResult with per-citation verdicts.
        """
        if not passages:
            return ToolResult(
                success=True,
                data=VerificationResult(
                    claim_text=claim_text,
                    status=VerificationStatus.PENDING,
                    notes="No passages to verify",
                ),
                summary="No passages to verify",
                confidence=Confidence.LOW,
            )

        if self._verify is None:
            # Graceful stub — mark all citations PENDING so the agent
            # can still run but the confidence stays MODERATE
            stub_citations = self._build_stub_citations(passages)
            return ToolResult(
                success=True,
                data=VerificationResult(
                    claim_text=claim_text,
                    status=VerificationStatus.PENDING,
                    supporting_citations=stub_citations,
                    notes="[STUB] verify_fn not injected; all citations unverified",
                ),
                summary=f"[STUB] {len(passages)} passages unverified (verify_fn not injected)",
                confidence=Confidence.MODERATE,
                metadata={"stub": True},
            )

        t0 = time.time()
        try:
            raw = self._verify(passages, **kwargs)
        except Exception as exc:  # noqa: BLE001
            return ToolResult(
                success=False,
                data=None,
                summary=f"Verification error: {exc}",
                confidence=Confidence.LOW,
                execution_time_s=time.time() - t0,
                error_message=str(exc),
            )

        elapsed = time.time() - t0
        result  = self._normalise_result(raw, passages, claim_text)
        cit_dicts = [c.to_dict() for c in result.supporting_citations]

        return ToolResult(
            success=True,
            data=result,
            summary=self._build_summary(result),
            citations=cit_dicts,
            confidence=self._result_confidence(result),
            execution_time_s=elapsed,
            metadata={"supersession_risk": result.supersession_risk},
        )

    def verify_single(self, passage: dict, claim_text: str = "", **kwargs: Any) -> ToolResult:
        """Convenience wrapper for verifying a single passage."""
        return self.verify([passage], claim_text=claim_text, **kwargs)

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _normalise_result(
        self,
        raw:        Any,
        passages:   list[dict],
        claim_text: str = "",
    ) -> VerificationResult:
        """
        Convert whatever the legacy verify() returns to a VerificationResult.
        Handles pre-built VerificationResult, normalised dict from set_fns wrapper,
        or unexpected types.
        """
        if isinstance(raw, VerificationResult):
            return raw

        if not isinstance(raw, dict):
            return VerificationResult(
                claim_text=claim_text,
                status=VerificationStatus.UNVERIFIABLE,
                notes=f"Unexpected verify() return type: {type(raw).__name__}",
            )

        # Map status string to enum
        status_raw = raw.get("status") or raw.get("overall_status", "PENDING")
        status = {
            "VERIFIED":     VerificationStatus.VERIFIED,
            "SUPERSEDED":   VerificationStatus.SUPERSEDED,
            "UNVERIFIABLE": VerificationStatus.UNVERIFIABLE,
            "HALLUCINATED": VerificationStatus.HALLUCINATED,
            "PENDING":      VerificationStatus.PENDING,
            # Legacy aliases
            "PARTIAL":      VerificationStatus.UNVERIFIABLE,
            "UNVERIFIED":   VerificationStatus.PENDING,
        }.get(str(status_raw).upper(), VerificationStatus.PENDING)

        # Build Citation list from raw dicts
        raw_cits = raw.get("citations") or raw.get("results") or []
        citations: list[Citation] = []
        for rc in raw_cits:
            if isinstance(rc, Citation):
                citations.append(rc)
            elif isinstance(rc, dict):
                citations.append(Citation(
                    source_doc_id        = rc.get("source_doc_id") or rc.get("doc_id", ""),
                    provider_name        = rc.get("provider_name") or rc.get("provider", ""),
                    passage_text         = rc.get("passage_text") or rc.get("text") or rc.get("unit_text", ""),
                    page_number          = rc.get("page_number") or rc.get("page"),
                    clause_type          = rc.get("clause_type") or rc.get("section_type") or rc.get("section", ""),
                    effective_date       = rc.get("effective_date"),
                    is_current_effective = bool(rc.get("is_current_effective", True)),
                    doc_role             = rc.get("doc_role", ""),
                    amendment_order      = rc.get("amendment_order"),
                    confidence           = float(rc.get("confidence", 1.0)),
                    retrieval_score      = float(rc.get("retrieval_score") or rc.get("score", 0.0)),
                ))

        if not citations:
            citations = self._build_stub_citations(passages)

        return VerificationResult(
            claim_text          = claim_text,
            status              = status,
            supporting_citations = citations,
            risk_flags          = list(raw.get("risk_flags", [])),
            supersession_risk   = bool(raw.get("supersession_risk", False)),
            notes               = raw.get("notes", ""),
        )

    @staticmethod
    def _build_stub_citations(passages: list[dict]) -> list[Citation]:
        return [
            Citation(
                source_doc_id  = (
                    p.get("source_doc_id")
                    or p.get("unit_id")
                    or p.get("doc_id", "")
                ),
                provider_name  = p.get("provider_name") or p.get("provider", ""),
                passage_text   = p.get("unit_text") or p.get("passage_text") or p.get("text", ""),
                page_number    = p.get("page_number") or p.get("page"),
                clause_type    = p.get("section_type") or p.get("clause_type", ""),
                effective_date = p.get("effective_date"),
                is_current_effective = bool(p.get("is_current_effective") or p.get("is_current", True)),
                doc_role       = p.get("doc_role", ""),
                retrieval_score = float(p.get("score") or p.get("rrf_score", 0.0)),
            )
            for p in passages
        ]

    @staticmethod
    def _result_confidence(result: VerificationResult) -> str:
        return {
            VerificationStatus.VERIFIED:     Confidence.HIGH,
            VerificationStatus.SUPERSEDED:   Confidence.LOW,
            VerificationStatus.UNVERIFIABLE: Confidence.MODERATE,
            VerificationStatus.HALLUCINATED: Confidence.LOW,
            VerificationStatus.PENDING:      Confidence.MODERATE,
        }.get(result.status, Confidence.MODERATE)

    @staticmethod
    def _build_summary(result: VerificationResult) -> str:
        cits         = result.supporting_citations
        n            = len(cits)
        n_verified   = sum(1 for c in cits if c.confidence >= 0.8)
        n_superseded = int(result.supersession_risk)
        parts        = [f"Verified {n_verified}/{n} citations"]
        if result.risk_flags:
            parts.append(f"{len(result.risk_flags)} risk flag(s)")
        if n_superseded:
            parts.append("supersession risk flagged")
        if result.notes:
            parts.append(result.notes[:100])
        return "; ".join(parts)
