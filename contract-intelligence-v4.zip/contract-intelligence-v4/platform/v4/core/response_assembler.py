"""
platform/v4/core/response_assembler.py

Assembles the final AgentResponse from completed ReAct steps.

Responsibilities
----------------
- Collect + deduplicate citations from all tool results
- Aggregate confidence (most-conservative wins)
- Synthesize the natural-language answer when the controller has not
  provided one (looks for last SYNTHESIZE step, then falls back to
  concatenating summaries)
- Produce a structured cost / performance summary
- Provide a markdown renderer for notebook and Genie display
- Step 1.2: Auto-build ClauseReport from clause_existence tool results
  (MIXED/DENIED classification propagation)
- V4: Surface inactive provider notes when retrieved evidence comes
  from providers with is_active=FALSE in the profile
"""
from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any, Optional

from ..contracts.agent_types import AgentResponse, AgentStep
from ..contracts.tool_types import Confidence, ToolResult, ToolStatus

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Confidence aggregation
# ---------------------------------------------------------------------------

_CONFIDENCE_RANK: dict[str, int] = {
    Confidence.HIGH: 3,
    Confidence.MODERATE: 2,
    Confidence.LOW: 1,
    Confidence.GENERATED: 0,
}
_RANK_TO_CONFIDENCE: dict[int, str] = {v: k for k, v in _CONFIDENCE_RANK.items()}


def _aggregate_confidence(confidences: list[str]) -> str:
    """Return the minimum (most conservative) confidence across a result set."""
    if not confidences:
        return Confidence.GENERATED
    min_rank = min(_CONFIDENCE_RANK.get(c, 0) for c in confidences)
    return _RANK_TO_CONFIDENCE.get(min_rank, Confidence.GENERATED)


# ---------------------------------------------------------------------------
# Citation deduplication
# ---------------------------------------------------------------------------

def _deduplicate_citations(raw: list[dict]) -> list[dict]:
    """Remove exact-duplicate citations keyed on (source_filename, page_number, section).

    W9-17: Uses source_filename as primary key (more stable than doc_id for
    provenance). Falls back to doc_id when filename is absent.
    """
    seen: set[tuple] = set()
    out: list[dict] = []
    for c in raw:
        key = (
            c.get("source_filename") or c.get("doc_id", ""),
            c.get("page_number", ""),
            c.get("section", ""),
        )
        if key not in seen:
            seen.add(key)
            out.append(c)
    return out


def _enrich_citation(citation: dict, tool_metadata: dict) -> dict:
    """
    W9-17: Thread source provenance from ToolResult.metadata into citations
    that are missing provenance fields.

    ToolResult.metadata may carry:
      - source_filename (from document_fetch or passage_search context)
      - contract_id (from tool-level resolution)
      - provider_id (resolved canonical)
    """
    enriched = citation.copy()
    # Only fill missing fields — tool-level metadata is lower priority
    # than passage-level provenance.
    provenance_fields = ["source_filename", "contract_id", "provider_id"]
    for field_name in provenance_fields:
        if not enriched.get(field_name) and tool_metadata.get(field_name):
            enriched[field_name] = tool_metadata[field_name]
    return enriched


# ---------------------------------------------------------------------------
# Inactive provider note (V4)
# ---------------------------------------------------------------------------

_INACTIVE_NOTE_TEMPLATE = (
    "\n\n---\n"
    "**Note**: {provider_text} {verb} currently inactive in the BSC network "
    "(no current-effective rates). Information shown is based on historical "
    "contract data and may not reflect the current contractual relationship."
)


def _build_inactive_note(inactive_names: list[str]) -> str:
    """Build a user-facing note about inactive providers referenced in the answer."""
    if len(inactive_names) == 1:
        return _INACTIVE_NOTE_TEMPLATE.format(
            provider_text=inactive_names[0],
            verb="is",
        )
    elif len(inactive_names) <= 3:
        joined = ", ".join(inactive_names[:-1]) + f" and {inactive_names[-1]}"
        return _INACTIVE_NOTE_TEMPLATE.format(
            provider_text=joined,
            verb="are",
        )
    else:
        joined = ", ".join(inactive_names[:3]) + f" and {len(inactive_names) - 3} others"
        return _INACTIVE_NOTE_TEMPLATE.format(
            provider_text=joined,
            verb="are",
        )


# ---------------------------------------------------------------------------
# ResponseAssembler
# ---------------------------------------------------------------------------

class ResponseAssembler:
    """
    Builds a final AgentResponse after the ReAct loop finishes.

    Usage
    -----
    assembler = ResponseAssembler(
        provenance_resolver=resolver,
        current_effective_filter=cef,
    )
    response = assembler.assemble(
        question="...",
        steps=[...],
        start_time=t0,
        session_id="session-xyz",
    )
    """

    def __init__(
        self,
        provenance_resolver: Optional[Any] = None,
        current_effective_filter: Optional[Any] = None,
    ) -> None:
        """
        Parameters
        ----------
        provenance_resolver : ProvenanceResolver (W9-17)
            Resolves source_filename → PDF path + metadata.
        current_effective_filter : CurrentEffectiveFilter (V4)
            Provides is_provider_active() checks for inactive provider notes.
        """
        self._provenance = provenance_resolver
        self._cef = current_effective_filter

    def assemble(
        self,
        question: str,
        steps: list[AgentStep],
        start_time: float,
        session_id: str = "",
        final_answer: Optional[str] = None,
    ) -> AgentResponse:
        """
        Assemble a complete AgentResponse from executed steps.

        Parameters
        ----------
        question     : The original user question.
        steps        : All completed AgentStep objects.
        start_time   : Unix timestamp when processing began (time.time()).
        session_id   : Session identifier for tracking.
        final_answer : Optional pre-formed answer string from the controller.
        """
        tool_results = self._extract_tool_results(steps)
        citations    = self._collect_citations(tool_results)
        confidence   = self._compute_confidence(tool_results)
        total_cost   = sum(r.cost_estimate for r in tool_results)
        elapsed      = time.time() - start_time

        answer = final_answer or self._synthesize_answer(question, steps, tool_results)

        # V4: Append inactive provider note if applicable
        answer = self._maybe_append_inactive_note(answer, citations, tool_results)

        # Step 1.2: Auto-build ClauseReport from clause_existence results
        metadata = self._build_report_metadata(tool_results, question, total_cost)

        return AgentResponse(
            answer=answer,
            confidence=confidence,
            citations=citations,
            steps=steps,
            total_cost=total_cost,
            execution_time_s=elapsed,
            session_id=session_id,
            metadata=metadata,
        )

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _extract_tool_results(self, steps: list[AgentStep]) -> list[ToolResult]:
        """Collect all ToolResult objects from completed steps."""
        results: list[ToolResult] = []
        for step in steps:
            if step.result is not None and isinstance(step.result, ToolResult):
                results.append(step.result)
        return results

    def _collect_citations(self, results: list[ToolResult]) -> list[dict]:
        """Collect, enrich, and deduplicate citations from all tool results.

        W9-17: Now enriches each citation with tool-level provenance metadata
        (source_filename, contract_id, provider_id) when available.
        """
        raw: list[dict] = []
        for r in results:
            if r.citations:
                tool_meta = r.metadata or {}
                for cit in r.citations:
                    enriched = _enrich_citation(cit, tool_meta)
                    raw.append(enriched)

        # W9-17: Resolve provenance if resolver is available
        if self._provenance and raw:
            try:
                filenames = [c.get("source_filename", "") for c in raw if c.get("source_filename")]
                if filenames:
                    batch = self._provenance.resolve_batch(filenames)
                    for cit in raw:
                        fn = cit.get("source_filename", "")
                        if fn in batch:
                            prov = batch[fn]
                            for k, v in prov.items():
                                if v and not cit.get(k):
                                    cit[k] = v
            except Exception:  # noqa: BLE001
                pass  # Fail-open: provenance is best-effort

        return _deduplicate_citations(raw)

    def _compute_confidence(self, results: list[ToolResult]) -> str:
        """Aggregate confidence across all tool results (most conservative wins)."""
        confidences = [r.confidence for r in results if r.confidence]
        return _aggregate_confidence(confidences)

    def _synthesize_answer(
        self,
        question: str,
        steps: list[AgentStep],
        results: list[ToolResult],
    ) -> str:
        """
        Produce a final answer string.

        Priority:
          1. Look for a SYNTHESIZE step with non-empty action_input
          2. Use the last successful ToolResult summary
          3. Fall back to concatenation of all successful summaries
        """
        # Check for SYNTHESIZE step
        for step in reversed(steps):
            if (step.action and step.action.upper() == "SYNTHESIZE"
                    and step.action_input):
                return step.action_input

        # Use the last successful result — format SQL data rows if present
        last_successful = [r for r in results if r.success and r.summary]
        if last_successful:
            last = last_successful[-1]
            # If the result has actual data rows (from SqlQueryTool), format them
            # into a readable answer instead of returning raw "SQL returned N row(s)"
            if isinstance(last.data, list) and last.data and isinstance(last.data[0], dict):
                rows = last.data
                # Format up to 20 rows as a readable table
                header = list(rows[0].keys())
                lines = [f"Query: {question}"]
                lines.append(f"Results ({len(rows)} row{'s' if len(rows) != 1 else ''}):\n")
                # Column-aligned output
                for row in rows[:20]:
                    parts = [f"{k}: {v}" for k, v in row.items() if v is not None]
                    lines.append("  " + ", ".join(parts))
                if len(rows) > 20:
                    lines.append(f"  ... and {len(rows) - 20} more rows")
                return "\n".join(lines)
            return last.summary

        # Concatenate all summaries
        summaries = [r.summary for r in results if r.success and r.summary]
        if summaries:
            return "\n\n".join(summaries)

        return "Unable to produce an answer from the available data."

    # ------------------------------------------------------------------
    # V4: Inactive provider detection and note appending
    # ------------------------------------------------------------------

    def _maybe_append_inactive_note(
        self,
        answer: str,
        citations: list[dict],
        tool_results: list[ToolResult],
    ) -> str:
        """
        Check if any providers referenced in citations or tool results are
        inactive, and append a user-facing note if so.

        Design principles:
        - Fail-open: if CurrentEffectiveFilter is unavailable, no note appended
        - Only appends if we found concrete inactive providers in the response
        - Does NOT suppress the answer — only adds informational context
        - Deduplicates provider names
        """
        if not self._cef:
            return answer

        try:
            inactive_names = self._find_inactive_providers(citations, tool_results)
            if inactive_names:
                note = _build_inactive_note(inactive_names)
                logger.info(
                    "V4: Appending inactive provider note for: %s",
                    ", ".join(inactive_names),
                )
                return answer + note
        except Exception:  # noqa: BLE001
            # Fail-open: never block an answer over activity checks
            pass

        return answer

    def _find_inactive_providers(
        self,
        citations: list[dict],
        tool_results: list[ToolResult],
    ) -> list[str]:
        """
        Identify inactive providers referenced in the response.

        Sources checked (in order):
        1. Citation metadata (provider_id from provenance resolution)
        2. Tool result metadata (provider_id from tool context)
        3. Tool result data (SQL rows with provider_id/provider_name fields)

        Returns a deduplicated list of provider names (not IDs) for display.
        """
        if not self._cef:
            return []

        # Collect all provider_ids and names from response artifacts
        pid_to_name: dict[str, str] = {}

        # From citations
        for cit in citations:
            pid = cit.get("provider_id")
            pname = cit.get("provider_name")
            if pid:
                pid_to_name[str(pid)] = pname or str(pid)

        # From tool result metadata
        for r in tool_results:
            if r.metadata:
                pid = r.metadata.get("provider_id")
                pname = r.metadata.get("provider_name")
                if pid:
                    pid_to_name[str(pid)] = pname or str(pid)

        # From SQL result data rows
        for r in tool_results:
            if isinstance(r.data, list) and r.data:
                for row in r.data[:50]:  # cap scan to avoid perf issues
                    if isinstance(row, dict):
                        pid = row.get("provider_id")
                        pname = row.get("provider_name")
                        if pid:
                            pid_to_name[str(pid)] = pname or str(pid)

        if not pid_to_name:
            return []

        # Check each against CurrentEffectiveFilter
        inactive_names: list[str] = []
        seen_names: set[str] = set()
        for pid, name in pid_to_name.items():
            if not self._cef.is_provider_active(pid):
                display_name = name or pid
                if display_name not in seen_names:
                    inactive_names.append(display_name)
                    seen_names.add(display_name)

        return inactive_names

    # ------------------------------------------------------------------
    # Step 1.2: ClauseReport metadata
    # ------------------------------------------------------------------

    def _build_report_metadata(
        self,
        tool_results: list[ToolResult],
        question: str,
        total_cost: float,
    ) -> dict:
        """Step 1.2: Detect clause_existence tool results and build typed ClauseReport.

        The report is stored in metadata["clause_report"] for downstream
        consumers (Excel export, HTML rendering, report validator).

        This is the CRITICAL integration that propagates MIXED/DENIED
        classification from the tool output into the presentation layer.
        Without this, the report defaults to all-HAS because the raw tool
        result dict never gets mapped to ProviderStatus enum values.
        """
        metadata: dict = {}

        for r in tool_results:
            if not r.success or not isinstance(r.data, dict):
                continue
            # Detect clause_existence result by presence of key fields
            if "provider_data" in r.data and "classified" in r.data and "taxonomy" in r.data:
                try:
                    from ..presentation.report_builder import build_clause_report
                    report = build_clause_report(
                        r.data,
                        question=question,
                        cost_estimate=total_cost,
                    )
                    metadata["clause_report"] = report
                    metadata["report_summary"] = {
                        "has_count": report.has_count,
                        "mixed_count": report.mixed_count,
                        "denied_count": report.denied_count,
                        "no_mention_count": report.no_mention_count,
                        "total_universe": report.total_universe,
                        "passages": len(report.classified_passages),
                    }
                    logger.info(
                        "Step 1.2: ClauseReport built and attached to response metadata "
                        "(HAS=%d, MIXED=%d, DENIED=%d, NO_MENTION=%d)",
                        report.has_count, report.mixed_count,
                        report.denied_count, report.no_mention_count,
                    )
                except Exception as e:  # noqa: BLE001
                    logger.warning("Failed to build ClauseReport from tool result: %s", e)
                break  # Only one report per response

        return metadata

    # ------------------------------------------------------------------
    # Display / formatting helpers
    # ------------------------------------------------------------------

    @staticmethod
    def format_for_display(response: AgentResponse) -> str:
        """
        Render an AgentResponse as a human-readable markdown string.
        Suitable for notebook display or Genie output.
        """
        lines: list[str] = []

        lines.append(response.answer)
        lines.append("")

        conf_badge = {
            Confidence.HIGH:      "\U0001f7e2 HIGH",
            Confidence.MODERATE:  "\U0001f7e1 MODERATE",
            Confidence.LOW:       "\U0001f534 LOW",
            Confidence.GENERATED: "\u26aa GENERATED",
        }.get(response.confidence, f"\u2753 {response.confidence}")

        lines.append(
            f"**Confidence**: {conf_badge}  "
            f"| **Cost**: ${response.total_cost:.3f}  "
            f"| **Time**: {response.execution_time_s:.1f}s"
        )

        # Step 1.2: Show report summary if available
        report_summary = response.metadata.get("report_summary")
        if report_summary:
            lines.append("")
            lines.append("**Classification**")
            lines.append(
                f"  HAS: {report_summary['has_count']}  "
                f"| MIXED: {report_summary['mixed_count']}  "
                f"| DENIED: {report_summary['denied_count']}  "
                f"| NO_MENTION: {report_summary['no_mention_count']}  "
                f"({report_summary['total_universe']} providers)"
            )

        if response.citations:
            lines.append("")
            lines.append("**Sources**")
            for i, cit in enumerate(response.citations[:10], 1):
                provider = cit.get("provider_name", "Unknown")
                doc_id   = cit.get("doc_id", "")
                page     = cit.get("page_number", "")
                section  = cit.get("section", "")
                parts    = [f"{i}. {provider}"]
                if doc_id:
                    parts.append(f"Doc {doc_id}")
                if page:
                    parts.append(f"p.{page}")
                if section:
                    parts.append(f"\u00a7{section}")
                lines.append(" \u2014 ".join(parts))
            if len(response.citations) > 10:
                lines.append(f"  _\u2026and {len(response.citations) - 10} more_")

        return "\n".join(lines)

    @staticmethod
    def format_cost_summary(response: AgentResponse) -> dict[str, Any]:
        """Return a structured cost / performance summary dict."""
        return {
            "total_cost_usd":    round(response.total_cost, 4),
            "execution_time_s":  round(response.execution_time_s, 2),
            "steps_executed":    len(response.steps),
            "citations_found":   len(response.citations),
            "confidence":        response.confidence,
            "session_id":        response.session_id,
        }
