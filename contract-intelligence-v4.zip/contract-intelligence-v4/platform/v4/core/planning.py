"""
platform/v4/core/planning.py

Question-level planning layer for the V3 agent.

The Planner analyses an incoming question and returns a structured Plan
before the ReAct loop begins executing.  Pre-planning:

  - reduces exploratory tool calls for common question shapes
  - ensures provider context is resolved first whenever a provider is
    mentioned in the question
  - orders steps so dependencies (e.g. calculate after sql_query) are
    respected

Design rules
------------
- Planner is stateless: (question, available_tools, context) → Plan
- Tool selection is heuristic-first (regex patterns)
- The Plan is advisory: AgentController may deviate on tool failure
- Steps include explicit rationale for transparency / debugging
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Optional

from ..config.settings import Settings
from ..contracts.agent_types import AgentRequest

# ---------------------------------------------------------------------------
# Plan dataclasses
# ---------------------------------------------------------------------------

@dataclass
class PlannedStep:
    """One planned tool invocation."""
    tool_name:   str
    rationale:   str
    inputs:      dict        = field(default_factory=dict)
    is_required: bool        = True
    depends_on:  list[str]   = field(default_factory=list)  # tool_names this needs first


@dataclass
class Plan:
    """Ordered sequence of PlannedSteps for the agent to execute."""
    question:       str
    steps:          list[PlannedStep] = field(default_factory=list)
    estimated_cost: float             = 0.0
    question_type:  str               = "UNKNOWN"   # SQL | RETRIEVAL | CALCULATION | COMPARISON | MIXED | GENERATIVE
    complexity:     str               = "SIMPLE"    # SIMPLE | MODERATE | COMPLEX

    def tool_names(self) -> list[str]:
        return [s.tool_name for s in self.steps]


# ---------------------------------------------------------------------------
# Question-classification heuristics
# ---------------------------------------------------------------------------

_SQL_PATTERNS: list[str] = [
    r"\bhow (many|much)\b",
    r"\brate[s]?\b.*\bprovider\b",
    r"\bcount\b",
    r"\baverage\b|\bavg\b",
    r"\bwhich provider[s]?\b",
    r"\blist (all|the)\b",
    r"\btotal\b.*\bpayment\b",
    r"\bcontract[s]? (expire|expir|renew)\b",
    r"\bamendment[s]?\b.*\bdate\b",
    r"\bstop.?loss\b",
    r"\bescalat[oe]r\b",
    r"\bcapitation\b",
    r"\bcurrent.?effective\b",
]

_RETRIEVAL_PATTERNS: list[str] = [
    r"\bclause\b",
    r"\bsection\b",
    r"\blanguage\b",
    r"\bpassage\b",
    r"\bdoes.*contract\b",
    r"\bwhat does.*say\b",
    r"\boffset\b",
    r"\bdofr\b",
    r"\bipa\b",
    r"\bdelegat\b",
    r"\btermination\b",
    r"\bauto.?renew\b",
    r"\bencounters?\b.*\breconcili\b",
    r"\bab[- ]?352\b",
]

_CALC_PATTERNS: list[str] = [
    r"\bpercentile\b",
    r"\bbenchmark\b",
    r"\bdifference\b",
    r"\bcompare\b.*\brate[s]?\b",
    r"\b(higher|lower) than\b",
    r"\b\d+%\b",
    r"\bcalculat\b",
    r"\bvs\.?\b",
    r"\bversus\b",
]

_COMPARISON_PATTERNS: list[str] = [
    r"\bcompare\b.*\bprovider\b",
    r"\bboth\b.*\bprovider\b",
    r"\bside.?by.?side\b",
    r"\bvs\.?\b.*\bprovider\b",
]

_COMPILED: dict[str, list[re.Pattern]] = {
    "SQL":         [re.compile(p, re.I) for p in _SQL_PATTERNS],
    "RETRIEVAL":   [re.compile(p, re.I) for p in _RETRIEVAL_PATTERNS],
    "CALCULATION": [re.compile(p, re.I) for p in _CALC_PATTERNS],
    "COMPARISON":  [re.compile(p, re.I) for p in _COMPARISON_PATTERNS],
}


def _classify_question(question: str) -> tuple[str, str]:
    """
    Return (question_type, complexity).

    question_type : SQL | RETRIEVAL | CALCULATION | COMPARISON | MIXED | GENERATIVE
    complexity    : SIMPLE | MODERATE | COMPLEX
    """
    hits: dict[str, int] = {k: 0 for k in _COMPILED}
    for qtype, patterns in _COMPILED.items():
        for p in patterns:
            if p.search(question):
                hits[qtype] += 1

    max_hits = max(hits.values())
    if max_hits == 0:
        qtype = "GENERATIVE"
    else:
        winners = [k for k, v in hits.items() if v == max_hits]
        qtype = "MIXED" if len(winners) > 1 else winners[0]

    total_signals = sum(hits.values())
    if total_signals <= 1:
        complexity = "SIMPLE"
    elif total_signals <= 3:
        complexity = "MODERATE"
    else:
        complexity = "COMPLEX"

    return qtype, complexity


# ---------------------------------------------------------------------------
# Per-tool cost estimates (rough USD, used for budget checks)
# ---------------------------------------------------------------------------

TOOL_COST_EST: dict[str, float] = {
    "sql_query":        0.01,
    "calculate":        0.00,
    "provider_lookup":  0.00,
    "document_fetch":   0.01,
    "passage_search":   0.05,
    "citation_verify":  0.02,
    "summarize":        0.10,
    "draft_text":       0.20,
    "chart_generate":   0.00,
    "export_data":      0.00,
    # legacy branch tools
    "single_provider":  0.50,
    "comparison":       0.50,
    "rate_query":       0.10,
    "explanation":      0.30,
    "temporal":         0.30,
    "field_extraction": 1.00,
    "clause_existence": 5.00,
    "multi_concept":    12.00,
}


# ---------------------------------------------------------------------------
# Planner
# ---------------------------------------------------------------------------

class Planner:
    """
    Produces a Plan (ordered tool sequence) for a given AgentRequest.

    Parameters
    ----------
    available_tools : list of tool names registered in the ToolRegistry.
    settings        : Settings instance (optional; defaults to Settings()).
    """

    def __init__(
        self,
        available_tools: list[str],
        settings: Optional[Settings] = None,
    ) -> None:
        self._tools    = set(available_tools)
        self._settings = settings or Settings()

    def plan(self, request: AgentRequest) -> Plan:
        """
        Build a Plan for the given request.

        Always resolves provider context first when a provider name is present.
        Selects tool sequence based on question type heuristics.
        Filters planned steps to only those available in the registry.
        """
        question           = request.question
        qtype, complexity  = _classify_question(question)

        steps: list[PlannedStep] = []

        # --- Provider resolution always comes first ---
        provider_hint = getattr(getattr(request, "context", None), "provider_name", None)
        if provider_hint:
            steps.append(PlannedStep(
                tool_name="provider_lookup",
                rationale="Resolve canonical provider identity before further lookups",
                inputs={"provider_name": provider_hint},
                is_required=True,
            ))

        # --- Type-specific step sequence ---
        builders = {
            "SQL":         self._sql_steps,
            "RETRIEVAL":   self._retrieval_steps,
            "CALCULATION": self._calculation_steps,
            "COMPARISON":  self._comparison_steps,
            "MIXED":       self._mixed_steps,
            "GENERATIVE":  self._generative_steps,
        }
        steps.extend(builders.get(qtype, self._generative_steps)(question))

        # Filter to available tools (keep required steps even if missing, so
        # the controller can raise a clear error rather than silently skip)
        available_steps = [
            s for s in steps
            if s.tool_name in self._tools or s.is_required
        ]

        estimated_cost = sum(
            TOOL_COST_EST.get(s.tool_name, 0.05) for s in available_steps
        )

        return Plan(
            question=question,
            steps=available_steps,
            estimated_cost=estimated_cost,
            question_type=qtype,
            complexity=complexity,
        )

    # ------------------------------------------------------------------
    # Step builders
    # ------------------------------------------------------------------

    def _sql_steps(self, question: str) -> list[PlannedStep]:
        return [
            PlannedStep(
                tool_name="sql_query",
                rationale="Execute structured SQL query against contract data tables",
                inputs={"question": question},
            ),
        ]

    def _retrieval_steps(self, question: str) -> list[PlannedStep]:
        return [
            PlannedStep(
                tool_name="passage_search",
                rationale="Search contract corpus for relevant passages",
                inputs={"query": question},
            ),
            PlannedStep(
                tool_name="citation_verify",
                rationale="Verify retrieved passages for supersession and grounding",
                inputs={},
                depends_on=["passage_search"],
            ),
        ]

    def _calculation_steps(self, question: str) -> list[PlannedStep]:
        return [
            PlannedStep(
                tool_name="sql_query",
                rationale="Fetch raw numbers needed for calculation",
                inputs={"question": question},
            ),
            PlannedStep(
                tool_name="calculate",
                rationale="Perform numeric comparison or benchmark calculation",
                inputs={},
                depends_on=["sql_query"],
            ),
        ]

    def _comparison_steps(self, question: str) -> list[PlannedStep]:
        return [
            PlannedStep(
                tool_name="sql_query",
                rationale="Fetch data for the providers being compared",
                inputs={"question": question},
            ),
            PlannedStep(
                tool_name="calculate",
                rationale="Compute difference or percentile comparison",
                inputs={},
                depends_on=["sql_query"],
            ),
        ]

    def _mixed_steps(self, question: str) -> list[PlannedStep]:
        return [
            PlannedStep(
                tool_name="sql_query",
                rationale="Fetch structured data component",
                inputs={"question": question},
            ),
            PlannedStep(
                tool_name="passage_search",
                rationale="Fetch unstructured contract language component",
                inputs={"query": question},
                is_required=False,
            ),
        ]

    def _generative_steps(self, question: str) -> list[PlannedStep]:
        return [
            PlannedStep(
                tool_name="passage_search",
                rationale="Search for relevant contract passages",
                inputs={"query": question},
                is_required=False,
            ),
            PlannedStep(
                tool_name="summarize",
                rationale="Synthesize a natural-language answer from retrieved passages",
                inputs={"question": question},
                depends_on=["passage_search"],
                is_required=False,
            ),
        ]
