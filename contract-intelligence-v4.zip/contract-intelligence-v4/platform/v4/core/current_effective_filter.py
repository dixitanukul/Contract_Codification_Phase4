"""
platform/v4/core/current_effective_filter.py

Filters retrieval results to only include passages from current-effective
contract documents (i.e., documents that have not expired) and optionally
deprioritizes passages from inactive providers.

Design
------
- Lazy-loads the set of current-effective source_filenames from
  tbl_contract_documents_master on first use.
- Lazy-loads the set of active provider_ids from tbl_genie_provider_profile.
- Caches both sets for the session lifetime (avoids repeated queries).
- Provides both filter-in-place and predicate modes.
- Handles documents with no expiration_date as perpetually effective.
- Thread-safe (single-writer pattern via lazy init).

Definition of "current effective"
----------------------------------
A document is current-effective if:
  1. expiration_date IS NULL (no stated end — assumed still active), OR
  2. expiration_date >= CURRENT_DATE()

This is a conservative filter that removes clearly expired contracts.
It does NOT handle version supersession (e.g., contract_v1.pdf superseded
by contract_v2.pdf where both share the same expiration logic). Version
preference is handled separately in passage scoring/ranking.

Provider Activity (V4 enhancement)
-----------------------------------
A provider is "active" if is_active = TRUE in tbl_genie_provider_profile
(dual condition: provider has current rates in tbl_contract_rates_all AND
a non-expired document in tbl_contract_documents_master).
272 active, 33 inactive as of last validation (2026-07-03).
CAUTION: 29 providers are is_active=FALSE but still have current_rates > 0
because their document expired. Do not treat is_active=FALSE as equivalent
to "has no rates".

Passages from inactive providers are NOT removed (they may contain valid
clause/contract information), but are flagged with
`is_provider_active = False` so downstream can surface this context
(e.g., "Note: this provider's contract document has expired").

Usage
-----
    filter = CurrentEffectiveFilter(spark=spark)
    passages = adapter.retrieve(query, top_k=20).data
    current_passages = filter.apply(passages)  # only current-effective

    # Provider activity check (for agent context)
    if not filter.is_provider_active(provider_id):
        # Append note: "This provider is inactive (no current rates)"
"""
from __future__ import annotations

import logging
import time
from typing import Any, Dict, Optional, Set

logger = logging.getLogger(__name__)

# Default tables for metadata lookup
_DEFAULT_DOCS_TABLE = "dev_adb.raw.tbl_contract_documents_master"
_DEFAULT_PROFILE_TABLE = "dev_adb.raw.tbl_genie_provider_profile"


class CurrentEffectiveFilter:
    """
    Post-retrieval filter that removes passages from expired documents
    and flags passages from inactive providers.

    Parameters
    ----------
    spark : SparkSession
        Active Spark session for querying document metadata.
    docs_table : str
        Fully qualified table name for document master metadata.
    profile_table : str
        Fully qualified table name for provider profile (is_active column).
    ttl_seconds : int
        Cache TTL in seconds. After this, the filename set is refreshed
        on the next call. Default: 3600 (1 hour).
    """

    def __init__(
        self,
        spark: Any,
        table: str = _DEFAULT_DOCS_TABLE,
        docs_table: str | None = None,
        profile_table: str = _DEFAULT_PROFILE_TABLE,
        ttl_seconds: int = 3600,
    ) -> None:
        self._spark = spark
        # Support both old `table` param and new `docs_table` param
        self._docs_table = docs_table or table
        self._profile_table = profile_table
        self._ttl = ttl_seconds

        # Document-level cache
        self._current_filenames: Optional[Set[str]] = None
        self._loaded_at: float = 0.0
        self._total_docs: int = 0
        self._expired_docs: int = 0

        # Provider-level cache (V4)
        self._active_provider_ids: Optional[Set[str]] = None
        self._inactive_provider_ids: Optional[Set[str]] = None
        self._provider_loaded_at: float = 0.0

        # Provider → is_active lookup (keyed by provider_id)
        self._provider_activity: Optional[Dict[str, bool]] = None

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    def apply(self, passages: list, keep_minimum: int = 3) -> list:
        """
        Filter passages to only those from current-effective documents.
        Also annotates passages with provider activity status.

        Parameters
        ----------
        passages : list[RetrievedPassage]
            Passages from RetrievalAdapter (must have .metadata['source_filename']).
        keep_minimum : int
            If filtering would reduce results below this count AND there are
            passages available, relax the filter and return all. This prevents
            the agent from getting zero results on queries where all evidence
            happens to come from expired docs (rare but possible).

        Returns
        -------
        list[RetrievedPassage]
            Filtered passages (only current-effective), or original list if
            filtering would reduce below keep_minimum.
        """
        if not passages:
            return passages

        current_filenames = self._get_current_filenames()
        if not current_filenames:
            # If we couldn't load the filter (Spark error, empty table),
            # fail open — return all passages rather than blocking retrieval.
            logger.warning("CurrentEffectiveFilter: cache empty, returning all passages")
            return passages

        filtered = [
            p for p in passages
            if self._is_current(p, current_filenames)
        ]

        # Safety: don't starve the agent of results
        if len(filtered) < keep_minimum and len(passages) >= keep_minimum:
            logger.info(
                "CurrentEffectiveFilter: would reduce %d → %d passages "
                "(below minimum=%d), returning unfiltered",
                len(passages), len(filtered), keep_minimum,
            )
            # Mark non-current passages so downstream can deprioritize
            for p in passages:
                if not self._is_current(p, current_filenames):
                    p.is_current_effective = False
                else:
                    p.is_current_effective = True
            # Annotate provider activity
            self._annotate_provider_activity(passages)
            return passages

        # Mark surviving passages as current
        for p in filtered:
            p.is_current_effective = True

        # Annotate provider activity on filtered results
        self._annotate_provider_activity(filtered)

        return filtered

    def is_current(self, source_filename: str) -> bool:
        """
        Check if a single filename is from a current-effective document.
        Useful for one-off checks without a full passage list.
        """
        current_filenames = self._get_current_filenames()
        if not current_filenames:
            return True  # fail open
        return source_filename in current_filenames

    def is_provider_active(self, provider_id: str) -> bool:
        """
        Check if a provider is active (has current rates).

        Uses pre-computed is_active from tbl_genie_provider_profile.
        Returns True on cache miss or error (fail-open).
        """
        activity = self._get_provider_activity()
        if not activity:
            return True  # fail open
        # Default to True for unknown providers (fail-open)
        return activity.get(provider_id, True)

    def get_inactive_providers(self) -> Set[str]:
        """Return set of inactive provider_ids (for agent context)."""
        self._ensure_provider_cache()
        return self._inactive_provider_ids or set()

    def get_active_providers(self) -> Set[str]:
        """Return set of active provider_ids."""
        self._ensure_provider_cache()
        return self._active_provider_ids or set()

    @property
    def stats(self) -> dict:
        """Cache statistics for telemetry/debugging."""
        return {
            "cached_filenames": len(self._current_filenames or set()),
            "total_docs": self._total_docs,
            "expired_docs": self._expired_docs,
            "cache_age_s": round(time.time() - self._loaded_at, 1) if self._loaded_at else None,
            "active_providers": len(self._active_provider_ids or set()),
            "inactive_providers": len(self._inactive_provider_ids or set()),
            "provider_cache_age_s": (
                round(time.time() - self._provider_loaded_at, 1)
                if self._provider_loaded_at else None
            ),
            "ttl_s": self._ttl,
        }

    def invalidate(self) -> None:
        """Force cache refresh on next access."""
        self._current_filenames = None
        self._loaded_at = 0.0
        self._active_provider_ids = None
        self._inactive_provider_ids = None
        self._provider_activity = None
        self._provider_loaded_at = 0.0

    # ------------------------------------------------------------------
    # Private helpers — Document filtering
    # ------------------------------------------------------------------

    def _is_current(self, passage: Any, current_filenames: Set[str]) -> bool:
        """
        Determine if a passage is from a current-effective document.

        Checks source_filename in metadata dict (RetrievedPassage shape).
        Falls back to doc_id if source_filename is missing.
        """
        # Primary: check metadata.source_filename
        if hasattr(passage, "metadata") and isinstance(passage.metadata, dict):
            fname = passage.metadata.get("source_filename", "")
            if fname:
                return fname in current_filenames

        # Fallback: check doc_id (sometimes source_filename is stored there)
        if hasattr(passage, "doc_id") and passage.doc_id:
            return passage.doc_id in current_filenames

        # Unknown provenance — fail open (include it)
        return True

    def _get_current_filenames(self) -> Set[str]:
        """
        Lazy-load and cache the set of current-effective filenames.
        Refreshes if cache is stale (beyond TTL).
        """
        now = time.time()
        if self._current_filenames is not None and (now - self._loaded_at) < self._ttl:
            return self._current_filenames

        try:
            t0 = time.time()
            rows = self._spark.sql(f"""
                SELECT DISTINCT source_filename
                FROM {self._docs_table}
                WHERE TRY_CAST(expiration_date AS DATE) IS NULL
                   OR TRY_CAST(expiration_date AS DATE) >= current_date()
                   -- TRY_CAST: NULL expiration and non-parseable values (e.g. 'Evergreen')
                   -- both resolve to NULL, which IS NULL → treated as perpetually active
            """).collect()

            self._current_filenames = {
                r.source_filename for r in rows
                if r.source_filename  # skip nulls
            }

            # Also get total count for stats
            total_row = self._spark.sql(f"""
                SELECT
                    COUNT(DISTINCT source_filename) AS total,
                    COUNT(DISTINCT CASE
                        WHEN TRY_CAST(expiration_date AS DATE) IS NOT NULL
                         AND TRY_CAST(expiration_date AS DATE) < current_date()
                        THEN source_filename
                    END) AS expired
                FROM {self._docs_table}
            """).collect()[0]

            self._total_docs = total_row.total
            self._expired_docs = total_row.expired
            self._loaded_at = time.time()

            elapsed = time.time() - t0
            logger.info(
                "CurrentEffectiveFilter: loaded %d current-effective filenames "
                "(%d expired excluded) in %.2fs",
                len(self._current_filenames),
                self._expired_docs,
                elapsed,
            )
            return self._current_filenames

        except Exception as exc:  # noqa: BLE001
            logger.error("CurrentEffectiveFilter: failed to load filenames: %s", exc)
            # Fail open: return empty set (which triggers the "cache empty" guard)
            if self._current_filenames is None:
                self._current_filenames = set()
            return self._current_filenames

    # ------------------------------------------------------------------
    # Private helpers — Provider activity (V4)
    # ------------------------------------------------------------------

    def _ensure_provider_cache(self) -> None:
        """Ensure provider activity cache is loaded."""
        now = time.time()
        if self._provider_activity is not None and (now - self._provider_loaded_at) < self._ttl:
            return
        self._load_provider_activity()

    def _get_provider_activity(self) -> Dict[str, bool]:
        """
        Lazy-load provider_id → is_active mapping from profile table.
        """
        self._ensure_provider_cache()
        return self._provider_activity or {}

    def _load_provider_activity(self) -> None:
        """
        Load active/inactive provider sets from tbl_genie_provider_profile.
        Uses the pre-computed is_active column (validated: 293 active, 33 inactive).
        """
        try:
            t0 = time.time()
            rows = self._spark.sql(f"""
                SELECT provider_id, is_active
                FROM {self._profile_table}
                WHERE provider_id IS NOT NULL
            """).collect()

            self._provider_activity = {}
            self._active_provider_ids = set()
            self._inactive_provider_ids = set()

            for r in rows:
                pid = str(r.provider_id)
                is_active = bool(r.is_active) if r.is_active is not None else True
                self._provider_activity[pid] = is_active
                if is_active:
                    self._active_provider_ids.add(pid)
                else:
                    self._inactive_provider_ids.add(pid)

            self._provider_loaded_at = time.time()
            elapsed = time.time() - t0
            logger.info(
                "CurrentEffectiveFilter: loaded provider activity — "
                "%d active, %d inactive in %.2fs",
                len(self._active_provider_ids),
                len(self._inactive_provider_ids),
                elapsed,
            )

        except Exception as exc:  # noqa: BLE001
            logger.error(
                "CurrentEffectiveFilter: failed to load provider activity: %s", exc
            )
            # Fail open: all providers treated as active
            if self._provider_activity is None:
                self._provider_activity = {}
                self._active_provider_ids = set()
                self._inactive_provider_ids = set()
            self._provider_loaded_at = time.time()

    def _annotate_provider_activity(self, passages: list) -> None:
        """
        Annotate each passage with `is_provider_active` flag based on the
        provider_id in its metadata.

        This does NOT filter — it only adds the flag so downstream
        (ResponseAssembler, agent) can surface "Provider X is inactive" context.
        """
        activity = self._get_provider_activity()
        if not activity:
            return

        for p in passages:
            pid = self._extract_provider_id(p)
            if pid:
                p.is_provider_active = activity.get(pid, True)
            else:
                p.is_provider_active = True  # unknown → assume active

    @staticmethod
    def _extract_provider_id(passage: Any) -> Optional[str]:
        """Extract provider_id from a passage's metadata."""
        if hasattr(passage, "metadata") and isinstance(passage.metadata, dict):
            pid = passage.metadata.get("provider_id")
            if pid:
                return str(pid)
        if hasattr(passage, "provider_id") and passage.provider_id:
            return str(passage.provider_id)
        return None
