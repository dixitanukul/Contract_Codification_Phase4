"""
CostController — budget tracking and enforcement for the V3 ReAct loop.

One CostController is created per AgentRequest and threaded through every
reasoning step. It is the single source of truth for how much has been spent
and whether the budget has been exhausted.
"""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class CostRecord:
    """One line item in the cost ledger."""
    step: int
    tool_name: str
    amount: float
    note: str = ""


class CostController:
    """
    Per-session budget tracker.

    Usage:
        ctrl = CostController(budget=5.0)
        ctrl.record(0.02, step=1, tool_name="passage_search")
        if ctrl.is_exhausted():
            abort()
        print(ctrl.remaining())   # 4.98
    """

    def __init__(self, budget: float = 5.0, budget_usd: float | None = None, warn_at_pct: float = 0.80):
        if budget_usd is not None:
            budget = budget_usd
        if budget <= 0:
            raise ValueError(f"Budget must be positive, got {budget}")
        self.budget = budget
        self._warn_at = budget * warn_at_pct
        self._ledger: list[CostRecord] = []

    # ── Core API ──────────────────────────────────────────────────────────────

    def record(
        self,
        amount: float,
        step: int = 0,
        tool_name: str = "reasoning",
        note: str = "",
    ) -> None:
        """Add a cost entry to the ledger."""
        if amount < 0:
            raise ValueError(f"Cost amount must be non-negative, got {amount}")
        self._ledger.append(CostRecord(step=step, tool_name=tool_name, amount=amount, note=note))

    @property
    def spent(self) -> float:
        return sum(r.amount for r in self._ledger)

    def remaining(self) -> float:
        return max(0.0, self.budget - self.spent)

    def is_exhausted(self, margin: float = 0.01) -> bool:
        """
        True if remaining budget is below margin.
        margin defaults to $0.01 to avoid stopping right at the limit.
        """
        return self.remaining() < margin

    def is_warning(self) -> bool:
        """True if we've crossed the warning threshold (default 80%)."""
        return self.spent >= self._warn_at

    def can_afford(self, estimated_cost: float) -> bool:
        """True if there is enough budget for a tool call of this cost."""
        return self.remaining() >= estimated_cost

    # ── Reporting ─────────────────────────────────────────────────────────────

    def summary(self) -> dict:
        return {
            "budget": self.budget,
            "spent": round(self.spent, 4),
            "remaining": round(self.remaining(), 4),
            "pct_used": round(100 * self.spent / self.budget, 1),
            "entries": len(self._ledger),
        }

    def breakdown(self) -> list[dict]:
        """Return per-tool cost aggregates."""
        by_tool: dict[str, float] = {}
        for r in self._ledger:
            by_tool[r.tool_name] = by_tool.get(r.tool_name, 0.0) + r.amount
        return [{"tool": t, "cost": round(c, 4)} for t, c in sorted(
            by_tool.items(), key=lambda x: x[1], reverse=True
        )]

    def __repr__(self) -> str:
        return (
            f"<CostController budget=${self.budget:.2f} "
            f"spent=${self.spent:.3f} remaining=${self.remaining():.3f}>"
        )
