"""V3 services layer — standalone replacements for V2 Cell 3 capabilities."""
