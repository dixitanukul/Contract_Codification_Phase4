"""
platform/v4/services/recall_boost.py

P3-RET-2: SQL keyword recall expansion.

Extracted from V2 Cell 6 Steps 2 (keyword scan) and 6.5 (false-negative rescue).
Provides a Spark SQL-backed supplement to VS semantic retrieval for concepts
with strong lexical signals (offset clause, DOFR, IPA delegation, etc.).

Methods
-------
boost_recall(concept, provider_name, initial_results, top_k_per_provider)
    Augment VS results with SQL keyword-scan hits. Returns merged list.

keyword_scan(concept, provider_name, top_k_per_provider)
    SQL LIKE scan on tbl_vs_unified_ready using first-pass signals.
    Mirrors V2 Cell 6 Step 2 (version-aware, top-N per provider).

rescue_false_negatives(concept, no_mention_providers)
    Check NO_MENTION providers for genuine strong-signal passages (Step 6.5).
    Returns list of provider names that are genuine false negatives.

Usage
-----
    from platform.v4.services.recall_boost import RecallBoostService

    boost = RecallBoostService(spark=spark)
    augmented = boost.boost_recall("offset clause", initial_results=vs_results)
    rescued   = boost.rescue_false_negatives("offset clause", no_mention_providers)
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from ..config.settings import TBL_VS_UNIFIED_READY
from ..config.taxonomies import get_recall_signals

logger = logging.getLogger(__name__)


class RecallBoostService:
    """
    SQL-backed keyword recall expansion.

    Wraps V2 Cell 6 Steps 2 (keyword SQL scan) and 6.5 (false-negative rescue)
    as a reusable V3 service.  Requires a live Spark session because it runs
    SQL against tbl_vs_unified_ready.

    Parameters
    ----------
    spark : SparkSession
        Active Spark session for SQL queries.
    table : str
        Fully qualified corpus table name.
        Defaults to dev_adb.raw.tbl_vs_unified_ready.
    """

    _DEFAULT_TABLE = TBL_VS_UNIFIED_READY

    def __init__(
        self,
        spark: Any,
        table: str = _DEFAULT_TABLE,
    ) -> None:
        self._spark = spark
        self._table = table

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def boost_recall(
        self,
        concept: str,
        provider_name: Optional[str] = None,
        initial_results: Optional[List[Dict[str, Any]]] = None,
        top_k_per_provider: int = 7,
    ) -> List[Dict[str, Any]]:
        """
        Augment initial VS results with SQL keyword-scan results.

        Deduplicates against ``initial_results`` by source_filename.  New
        passages are appended with ``channel="keyword"``.  If concept has no
        configured recall signals, returns ``initial_results`` unchanged.

        Parameters
        ----------
        concept : str
            Target concept (must match a key in KNOWN_RECALL_SIGNALS).
        provider_name : str, optional
            Restrict the SQL scan to a single provider.
        initial_results : list[dict], optional
            Passages already obtained from VS retrieval.
        top_k_per_provider : int
            Maximum keyword-scan rows per provider.
        """
        initial = initial_results or []
        initial_filenames = {r.get("source_filename", "") for r in initial}

        keyword_results = self.keyword_scan(
            concept,
            provider_name=provider_name,
            top_k_per_provider=top_k_per_provider,
        )

        new_results = [
            r for r in keyword_results
            if r.get("source_filename", "") not in initial_filenames
        ]

        if new_results:
            logger.debug(
                "RecallBoostService.boost_recall: added %d new passages for concept=%r",
                len(new_results), concept,
            )

        return initial + new_results

    def keyword_scan(
        self,
        concept: str,
        provider_name: Optional[str] = None,
        top_k_per_provider: int = 7,
    ) -> List[Dict[str, Any]]:
        """
        SQL LIKE scan on the fulltext corpus using first-pass recall signals.

        Mirrors V2 Cell 6 Step 2:
          - Score all matching passages by keyword hit count
          - Extract file version from _vN.pdf pattern for recency preference
          - Dedup to best passage per file, then top-N per provider
          - Return ordered by: latest file version > keyword score > length

        Returns passage dicts with ``channel="keyword"`` compatible with
        ``RetrievalAdapter._normalise_chunk()``.
        """
        signals = get_recall_signals(concept)
        if not signals:
            logger.debug(
                "RecallBoostService.keyword_scan: no recall signals for concept=%r", concept
            )
            return []

        first_pass = signals.get("first_pass", [])
        if not first_pass:
            return []

        # Build SQL fragments (escape single quotes in keyword strings)
        esc_kws = [kw.replace("'", "''") for kw in first_pass]
        like_clauses = " OR ".join(
            f"LOWER(chunk_text) LIKE '%{kw}%'" for kw in esc_kws
        )

        # Score expression: sum of per-keyword hit indicators (max first 8)
        score_kws = esc_kws[:8]
        score_parts = [
            f"CASE WHEN LOWER(chunk_text) LIKE '%{kw}%' THEN 1 ELSE 0 END"
            for kw in score_kws
        ]
        score_sql = " + ".join(score_parts) if score_parts else "1"

        # Optional provider filter
        provider_clause = ""
        if provider_name:
            safe_prov = provider_name.replace("'", "''")
            provider_clause = f"AND LOWER(provider_name) LIKE '%{safe_prov.lower()}%'"

        sql = f"""
        WITH matched AS (
            SELECT
                provider_name,
                source_filename,
                page_number_est AS page_number,
                SUBSTRING(chunk_text, 1, 1200) AS chunk_text,
                LENGTH(chunk_text)             AS text_length,
                ({score_sql})                  AS kw_score,
                COALESCE(
                    TRY_CAST(
                        REGEXP_EXTRACT(source_filename, '_v(\\d+)\\.pdf, 1)
                    AS INT),
                    0
                ) AS file_version
            FROM {self._table}
            WHERE ({like_clauses})
              AND LENGTH(chunk_text) >= 50
              {provider_clause}
        ),
        file_deduped AS (
            SELECT
                *,
                ROW_NUMBER() OVER (
                    PARTITION BY source_filename
                    ORDER BY kw_score DESC, text_length DESC
                ) AS file_rn
            FROM matched
            WHERE kw_score >= 1
        ),
        provider_ranked AS (
            SELECT
                *,
                ROW_NUMBER() OVER (
                    PARTITION BY provider_name
                    ORDER BY file_version DESC, kw_score DESC, text_length DESC
                ) AS prov_rn
            FROM file_deduped
            WHERE file_rn = 1
        )
        SELECT
            provider_name, source_filename, page_number, chunk_text,
            text_length, kw_score, file_version
        FROM provider_ranked
        WHERE prov_rn <= {int(top_k_per_provider)}
        """

        try:
            df = self._spark.sql(sql).toPandas()
        except Exception as exc:  # noqa: BLE001
            logger.warning("RecallBoostService.keyword_scan SQL failed: %s", exc)
            return []

        if df.empty:
            return []

        results: List[Dict[str, Any]] = []
        for _, row in df.iterrows():
            results.append({
                "unit_id":              str(row.get("source_filename", "")),
                "provider_name":        str(row.get("provider_name", "")),
                "source_filename":      str(row.get("source_filename", "")),
                "page_number":          int(row.get("page_number", 0) or 0),
                "unit_text":            str(row.get("chunk_text", ""))[:1200],
                "chunk_index":          0,
                "score":                float(row.get("kw_score", 1.0)),
                "channel":              "keyword",
                "is_current":           True,
                "is_current_effective": True,
                "file_version":         int(row.get("file_version", 0) or 0),
            })

        logger.debug(
            "RecallBoostService.keyword_scan: %d rows for concept=%r, provider=%r",
            len(results), concept, provider_name,
        )
        return results

    def rescue_false_negatives(
        self,
        concept: str,
        no_mention_providers: List[str],
    ) -> List[str]:
        """
        Check NO_MENTION providers for genuine strong-signal passages (Step 6.5).

        For each provider in ``no_mention_providers``:
          1. SQL scan using first-pass keyword hits as a coarse filter
          2. Verify at least one chunk contains a strong-signal phrase
          3. If verified, add to the rescued list

        This mirrors V2 Cell 6 Step 6.5 with concept-driven signal selection
        (KNOWN_RECALL_SIGNALS[concept]["strong"]) instead of hard-coded lists.

        Parameters
        ----------
        concept : str
            Target concept.
        no_mention_providers : list[str]
            Provider names currently classified as NO_MENTION.

        Returns
        -------
        list[str]
            Provider names confirmed as genuine false negatives
            (i.e., they DO have concept language in the corpus).
        """
        if not no_mention_providers:
            return []

        signals = get_recall_signals(concept)
        if not signals:
            return []

        first_pass = signals.get("first_pass", [])
        strong     = signals.get("strong", [])

        if not first_pass or not strong:
            return []

        # Build SQL fragments
        esc_first = [kw.replace("'", "''") for kw in first_pass]
        like_clauses = " OR ".join(
            f"LOWER(chunk_text) LIKE '%{kw}%'" for kw in esc_first
        )
        prov_list = ", ".join(
            f"'{p.replace(chr(39), chr(39)*2)}'" for p in no_mention_providers
        )

        try:
            df = self._spark.sql(f"""
                SELECT
                    provider_name,
                    source_filename,
                    chunk_text,
                    page_number_est AS page_number,
                    COUNT(*) OVER (PARTITION BY provider_name) AS total_hits
                FROM {self._table}
                WHERE provider_name IN ({prov_list})
                  AND ({like_clauses})
                  AND LENGTH(chunk_text) >= 80
                ORDER BY provider_name, LENGTH(chunk_text) DESC
            """).toPandas()
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "RecallBoostService.rescue_false_negatives SQL failed: %s", exc
            )
            return []

        rescued: List[str] = []
        for prov in no_mention_providers:
            prov_df = df[df["provider_name"] == prov]
            if prov_df.empty:
                continue
            for _, row in prov_df.iterrows():
                text_lower = str(row.get("chunk_text", "")).lower()
                if any(sig.lower() in text_lower for sig in strong):
                    rescued.append(prov)
                    logger.debug(
                        "RecallBoostService: rescued false-negative provider=%r", prov
                    )
                    break

        return rescued
