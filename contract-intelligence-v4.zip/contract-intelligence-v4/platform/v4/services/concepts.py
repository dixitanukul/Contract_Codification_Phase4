"""
platform/v4/services/concepts.py

Step 1.7: CONCEPT_KEYWORDS single source of truth.

CONCEPT_REGISTRY is the canonical definition of every clause concept the platform
recognises.  Every other module that needs taxonomy entries, recall signals, polarity
codes, or absence codes MUST import from here — not from config/taxonomies.py
(which now re-exports this module for backward compatibility).

Registry schema per concept
---------------------------
display_name    str               Human-readable label (title-cased)
description     str               One-sentence definition used in LLM prompts
first_pass      List[str]         Broad keywords — SQL LIKE scan, low-cost triage
strong          List[str]         High-precision phrases — genuine false-negative gate
taxonomy        List[dict]        Full taxonomy entries (code, label, description,
                                  is_denial, polarity).  Consumed by TaxonomyBuilder,
                                  ClauseClassifier, ReportBuilder.
                                  polarity values: GRANT | RESTRICT | ABSENT

Accessor functions (identical signatures to the old config/taxonomies.py helpers so
every call-site can drop-in replace the import with no other changes):

    get_taxonomy(concept)          -> Optional[List[dict]]
    get_recall_signals(concept)    -> Optional[Dict[str, List[str]]]
    get_polarity_codes(concept)    -> Optional[Dict[str, List[str]]]
    is_known_concept(concept)      -> bool
    all_concept_names()            -> List[str]
    assign_polarity(entry)         -> str
    category_polarity_map(taxonomy)-> Dict[str, str]

Backward-compatible derived globals (do NOT edit these directly):

    KNOWN_TAXONOMIES     Dict[str, List[dict]]  computed from CONCEPT_REGISTRY
    KNOWN_RECALL_SIGNALS Dict[str, Dict]        computed from CONCEPT_REGISTRY
    ABSENCE_CODES        Set[str]               computed from CONCEPT_REGISTRY
"""
from __future__ import annotations

from typing import Dict, List, Optional, Set


# ==============================================================================
# CONCEPT REGISTRY  — single source of truth
# ==============================================================================

CONCEPT_REGISTRY: Dict[str, Dict] = {

    # ── Offset Clause ──────────────────────────────────────────────────────────
    "offset clause": {
        "display_name": "Offset Clause",
        "description": (
            "Contractual right to deduct (offset) amounts owed by one party "
            "against future payments owed by the other party."
        ),
        "first_pass": [
            "offset", "set-off", "set off", "setoff", "deduct and offset",
            "recoup", "recoupment", "overpayment", "overpayment recovery",
            "right to offset", "right of offset", "withhold and offset",
            "deduct such payment",
        ],
        "strong": [
            # Specific offset-clause phrases only.
            # "recoup" and "overpayment" removed: too broad — they appear in
            # standard payment terms of virtually all contracts and caused
            # FalseNegativeRescuer to over-rescue ~15 genuine NO_MENTION
            # providers, producing hallucinated "all providers have offset"
            # answers. They remain in first_pass for initial retrieval.
            "right to offset", "deduct and offset", "right to deduct",
            "offset such payment", "withhold and offset", "set off against",
            "offset from any amount", "right of setoff", "right of offset",
            "right of recoupment",
        ],
        "taxonomy": [
            {"code": "OVERPAYMENT_OFFSET", "label": "Overpayment Recovery",
             "description": "Plan recovers erroneous overpayments by deducting from future payments",
             "is_denial": False, "polarity": "GRANT"},
            {"code": "GENERAL_OFFSET", "label": "General Offset Rights",
             "description": "Broad mutual right to offset amounts owed between parties",
             "is_denial": False, "polarity": "GRANT"},
            {"code": "RECONCILIATION_OFFSET", "label": "Reconciliation Offset",
             "description": "Periodic reconciliation offsets",
             "is_denial": False, "polarity": "GRANT"},
            {"code": "AUDIT_OFFSET", "label": "Audit-Based Offset",
             "description": "Audit findings deducted from future payments",
             "is_denial": False, "polarity": "GRANT"},
            {"code": "CAPITATION_OFFSET", "label": "Capitation Offset",
             "description": "Plan deducts from monthly capitation payments",
             "is_denial": False, "polarity": "GRANT"},
            {"code": "NO_OFFSET_RIGHTS", "label": "No Offset Rights",
             "description": "Contract explicitly and totally prohibits offset (no carve-outs)",
             "is_denial": True, "polarity": "RESTRICT"},
            {"code": "CONDITIONAL_OFFSET_RESTRICTION",
             "label": "Conditional Offset Restriction",
             "description": (
                 "Contract imposes a significant restriction on offset rights: requires "
                 "prior written approval, prohibits offset of disputed amounts during "
                 "pending dispute, or requires mutual written agreement.  Use this even "
                 "when the contract also has general offset rights elsewhere — it IS a "
                 "denial code."
             ),
             "is_denial": True, "polarity": "RESTRICT"},
        ],
    },

    # ── Division of Financial Responsibility ───────────────────────────────────
    "division of financial responsibility": {
        "display_name": "Division of Financial Responsibility",
        "description": (
            "Contractual specification of which party (BSC or provider/IPA) is "
            "responsible for utilization management, claims processing, and other "
            "administrative functions."
        ),
        "first_pass": [
            "division of financial responsibility", "dofr",
            "utilization management", "prior authorization",
            "claims processing", "claims adjudication",
            "medical management", "financial responsibility",
        ],
        "strong": [
            "division of financial responsibility",
            "responsible for utilization management",
            "shall perform utilization management",
            "responsible for claims payment",
        ],
        "taxonomy": [
            {"code": "BSC_UM_RESPONSIBLE", "label": "BSC Responsible for UM",
             "description": "Blue Shield performs utilization management, medical review, and prior authorizations",
             "is_denial": False, "polarity": "GRANT"},
            {"code": "PROVIDER_UM_RESPONSIBLE", "label": "Provider/IPA Responsible for UM",
             "description": "Provider or IPA performs utilization management and clinical reviews under delegation",
             "is_denial": False, "polarity": "GRANT"},
            {"code": "SHARED_UM_RESPONSIBILITY", "label": "Shared UM Responsibility",
             "description": "UM responsibility divided between BSC and provider by service type, LOB, or clinical category",
             "is_denial": False, "polarity": "GRANT"},
            {"code": "BSC_CLAIMS_RESPONSIBLE", "label": "BSC Responsible for Claims",
             "description": "BSC processes, adjudicates, and pays claims directly to providers",
             "is_denial": False, "polarity": "GRANT"},
            {"code": "DELEGATED_CLAIMS", "label": "Delegated Claims Processing",
             "description": "Claims processing and payment delegated to provider, IPA, or third party",
             "is_denial": False, "polarity": "GRANT"},
            {"code": "FULL_DELEGATION", "label": "Fully Delegated (All Functions)",
             "description": "Provider/IPA assumes full financial responsibility for UM, claims, and credentialing",
             "is_denial": False, "polarity": "GRANT"},
            {"code": "DOFR_NOT_SPECIFIED", "label": "No DOFR Defined",
             "description": "Contract does not specify division of financial responsibility between parties",
             "is_denial": False, "polarity": "ABSENT"},
        ],
    },

    # ── IPA Delegation ─────────────────────────────────────────────────────────
    "ipa delegation": {
        "display_name": "IPA Delegation",
        "description": (
            "Extent to which BSC delegates utilization management, claims, "
            "credentialing, or risk to an IPA under the contract."
        ),
        "first_pass": [
            "ipa", "independent practice association", "delegat", "capitation",
            "risk arrangement", "utilization management",
        ],
        "strong": [
            "delegated to ipa", "ipa shall be responsible",
            "independent practice association", "global capitation",
            "delegation agreement", "delegated utilization",
        ],
        "taxonomy": [
            {"code": "FULL_DELEGATION_IPA", "label": "Fully Delegated to IPA",
             "description": "IPA performs all functions: utilization management, claims, credentialing, and quality",
             "is_denial": False, "polarity": "GRANT"},
            {"code": "PARTIAL_DELEGATION_UM", "label": "UM Only Delegated to IPA",
             "description": "Only utilization management and clinical review delegated to IPA; BSC retains claims",
             "is_denial": False, "polarity": "GRANT"},
            {"code": "PARTIAL_DELEGATION_CLAIMS", "label": "Claims Only Delegated to IPA",
             "description": "Only claims processing delegated to IPA; BSC retains UM authority",
             "is_denial": False, "polarity": "GRANT"},
            {"code": "BSC_RETAINED_ALL", "label": "BSC Retains All Functions",
             "description": "No delegation to IPA — BSC performs all UM, claims, and administrative functions",
             "is_denial": False, "polarity": "GRANT"},
            {"code": "SHARED_RISK_ARRANGEMENT", "label": "Shared Risk Arrangement",
             "description": "Risk shared between BSC and IPA with defined risk corridors or surplus sharing",
             "is_denial": False, "polarity": "GRANT"},
            {"code": "FULL_RISK_IPA", "label": "Full Risk Capitation to IPA",
             "description": "IPA accepts full financial risk under global capitation with no BSC risk share",
             "is_denial": False, "polarity": "GRANT"},
            {"code": "NO_IPA_RELATIONSHIP", "label": "No IPA Relationship",
             "description": "Contract is direct provider agreement with no IPA involvement",
             "is_denial": False, "polarity": "ABSENT"},
        ],
    },

    # ── AB 352 Reproductive Health ─────────────────────────────────────────────
    "ab 352 reproductive health": {
        "display_name": "AB 352 Reproductive Health",
        "description": (
            "Presence of California AB 352 reproductive and sexual health "
            "information privacy protections in the contract."
        ),
        "first_pass": [
            "ab 352", "ab352", "reproductive health", "sexual health",
            "reproductive and sexual", "confidential communication",
        ],
        "strong": [
            "ab 352", "reproductive health information", "sexual health information",
            "reproductive or sexual health", "reproductive and sexual health",
        ],
        "taxonomy": [
            {"code": "AB352_FULL_COMPLIANCE", "label": "Full AB 352 Compliance Language",
             "description": "Complete AB 352 reproductive and sexual health information privacy protections",
             "is_denial": False, "polarity": "GRANT"},
            {"code": "AB352_PARTIAL_LANGUAGE", "label": "Partial AB 352 Language",
             "description": "Some reproductive health information protections present but not complete",
             "is_denial": False, "polarity": "GRANT"},
            {"code": "AB352_REFERENCE_ONLY", "label": "AB 352 Referenced but Not Quoted",
             "description": "Contract references AB 352 by citation but does not include full operative language",
             "is_denial": False, "polarity": "GRANT"},
            {"code": "GENERAL_CONFIDENTIALITY_ONLY", "label": "General Confidentiality Only",
             "description": (
                 "General PHI/confidentiality provisions that may cover reproductive health "
                 "but no AB 352 specific language"
             ),
             "is_denial": False, "polarity": "GRANT"},
            {"code": "AB352_NOT_PRESENT", "label": "No AB 352 Language",
             "description": "Contract contains no AB 352, reproductive health, or sexual health privacy language",
             "is_denial": False, "polarity": "ABSENT"},
        ],
    },

    # ── Encounters Reconciliation ──────────────────────────────────────────────
    "encounters reconciliation": {
        "display_name": "Encounters Reconciliation",
        "description": (
            "Contractual requirement for the provider to submit and reconcile "
            "encounter data with BSC on a specified schedule."
        ),
        "first_pass": ["encounter", "reconciliation", "reconcile", "encounter data"],
        "strong": [
            "encounter data reconciliation", "reconciliation of encounter",
            "encounter data submission", "reconcile encounter data",
        ],
        "taxonomy": [
            {"code": "MANDATORY_RECONCILIATION", "label": "Mandatory Reconciliation Participation",
             "description": "Provider contractually required to participate in encounters reconciliation",
             "is_denial": False, "polarity": "GRANT"},
            {"code": "VOLUNTARY_RECONCILIATION", "label": "Voluntary/Best Efforts Reconciliation",
             "description": "Provider encouraged but not mandated to participate in reconciliation",
             "is_denial": False, "polarity": "GRANT"},
            {"code": "RECONCILIATION_WITH_CAP", "label": "Reconciliation with CAP/Penalty",
             "description": "Reconciliation required with corrective action plan or financial penalty",
             "is_denial": False, "polarity": "GRANT"},
            {"code": "DATA_SUBMISSION_REQUIRED", "label": "Data Submission Required",
             "description": "Provider must submit encounter data per specified timelines and formats",
             "is_denial": False, "polarity": "GRANT"},
            {"code": "NO_RECONCILIATION_REQUIREMENT", "label": "No Reconciliation Requirement",
             "description": "Contract does not address encounters reconciliation participation",
             "is_denial": False, "polarity": "ABSENT"},
        ],
    },

    # ── Auto Renewal ───────────────────────────────────────────────────────────
    "auto renewal": {
        "display_name": "Auto Renewal",
        "description": (
            "Whether the contract automatically renews for successive terms without "
            "requiring affirmative action from either party."
        ),
        "first_pass": [
            "auto renew", "auto-renew", "automatic renewal", "evergreen",
            "successive term", "shall be automatically renewed",
        ],
        "strong": [
            "automatically renew", "auto-renewal", "successive term",
            "shall be automatically renewed", "shall automatically renew",
        ],
        "taxonomy": [
            {"code": "AUTO_RENEWAL_ENABLED", "label": "Auto-Renewal Enabled",
             "description": "Contract automatically renews for successive terms unless terminated with proper notice",
             "is_denial": False, "polarity": "GRANT"},
            {"code": "AUTO_RENEWAL_WITH_NOTICE", "label": "Auto-Renewal with Notice Period",
             "description": "Contract auto-renews but requires written notice within specified period to prevent renewal",
             "is_denial": False, "polarity": "GRANT"},
            {"code": "EVERGREEN_CONTRACT", "label": "Evergreen/Continuous",
             "description": "Contract continues indefinitely until either party terminates; no fixed renewal cycle",
             "is_denial": False, "polarity": "GRANT"},
            {"code": "FIXED_TERM_NO_RENEWAL", "label": "Fixed Term - No Auto-Renewal",
             "description": "Contract expires at end of term with no automatic renewal provision",
             "is_denial": False, "polarity": "ABSENT"},
            {"code": "MUTUAL_RENEWAL_REQUIRED", "label": "Mutual Agreement Required",
             "description": "Renewal requires affirmative mutual written agreement of both parties",
             "is_denial": True, "polarity": "RESTRICT"},
        ],
    },
}


# ==============================================================================
# BACKWARD-COMPATIBLE DERIVED GLOBALS
# ==============================================================================
# Derived from CONCEPT_REGISTRY — do NOT edit directly.
# Existing code that imports from config/taxonomies.py (now a re-export shim)
# continues to work without modification.

KNOWN_TAXONOMIES: Dict[str, List[dict]] = {
    concept: defn["taxonomy"]
    for concept, defn in CONCEPT_REGISTRY.items()
}

KNOWN_RECALL_SIGNALS: Dict[str, Dict[str, List[str]]] = {
    concept: {"first_pass": defn["first_pass"], "strong": defn["strong"]}
    for concept, defn in CONCEPT_REGISTRY.items()
}

ABSENCE_CODES: Set[str] = {
    entry["code"]
    for defn in CONCEPT_REGISTRY.values()
    for entry in defn["taxonomy"]
    if entry.get("polarity") == "ABSENT"
}


# ==============================================================================
# ACCESSOR FUNCTIONS
# ==============================================================================

def _normalize(concept: str) -> str:
    """Lowercase-strip a concept name for registry lookup."""
    return concept.lower().strip()


def get_taxonomy(concept: str) -> Optional[List[dict]]:
    """Return taxonomy entries for a known concept (case-insensitive), or None."""
    defn = CONCEPT_REGISTRY.get(_normalize(concept))
    return list(defn["taxonomy"]) if defn else None


def get_recall_signals(concept: str) -> Optional[Dict[str, List[str]]]:
    """
    Return ``{"first_pass": [...], "strong": [...]}`` for a known concept,
    or None if the concept is not registered.
    """
    defn = CONCEPT_REGISTRY.get(_normalize(concept))
    if defn is None:
        return None
    return {"first_pass": list(defn["first_pass"]), "strong": list(defn["strong"])}


def get_polarity_codes(concept: str) -> Optional[Dict[str, List[str]]]:
    """
    Return ``{"GRANT": [...], "RESTRICT": [...], "ABSENT": [...]}`` code lists
    for a known concept, or None.  Useful for report validation and test fixtures.
    """
    defn = CONCEPT_REGISTRY.get(_normalize(concept))
    if defn is None:
        return None
    buckets: Dict[str, List[str]] = {"GRANT": [], "RESTRICT": [], "ABSENT": []}
    for entry in defn["taxonomy"]:
        pol = entry.get("polarity", "GRANT").upper()
        buckets.setdefault(pol, []).append(entry["code"])
    return buckets


def is_known_concept(concept: str) -> bool:
    """Return True if concept has a registered definition."""
    return _normalize(concept) in CONCEPT_REGISTRY


def all_concept_names() -> List[str]:
    """Return all registered concept names in definition order."""
    return list(CONCEPT_REGISTRY.keys())


def assign_polarity(entry: dict) -> str:
    """
    Derive polarity string for a taxonomy entry dict.

    Precedence: explicit ``polarity`` field > ABSENCE_CODES set > legacy ``is_denial``.
    Handles both native registry entries and LLM-generated entries that may
    lack a polarity field.
    """
    if entry.get("polarity"):
        return str(entry["polarity"]).upper()
    if str(entry.get("code", "")).upper() in ABSENCE_CODES:
        return "ABSENT"
    return "RESTRICT" if entry.get("is_denial") else "GRANT"


def category_polarity_map(taxonomy: List[dict]) -> Dict[str, str]:
    """Return ``{code: polarity}`` for a taxonomy list (known OR LLM-generated)."""
    return {
        c["code"]: (c.get("polarity") or assign_polarity(c)).upper()
        for c in taxonomy
    }
