"""
platform/v4/services/tier_service.py

P2-TIER-1: Provider confidence tier cache.

Extracted from V2 Cell 14 REPORT_CONFIG confidence_weights/thresholds.
Provides get_tier(provider) based on document count, extraction status,
and latest-doc availability.

Usage
-----
    from platform.v4.services.tier_service import TierService

    tiers = TierService(spark=spark)
    tier = tiers.get_tier("Sutter Roseville Medical Center")
    # → "high" | "moderate" | "low"
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Dict, Optional

from ..config.settings import CATALOG, SCHEMA

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class TierConfig:
    """Confidence tier configuration (from REPORT_CONFIG)."""
    # Weights must sum to 1.0
    weight_doc_count: float = 0.50
    weight_extraction_tier: float = 0.30
    weight_has_latest_doc: float = 0.20

    doc_count_scale: int = 3  # Normalize doc_count by dividing by this

    threshold_high: float = 0.75
    threshold_moderate: float = 0.40


DEFAULT_TIER_CONFIG = TierConfig()


class TierService:
    """
    Provider confidence tier assignment.

    Tiers: high (>= 0.75), moderate (>= 0.40), low (< 0.40).
    Score = weighted combination of:
      - doc_count: number of distinct documents (capped at scale)
      - extraction_tier: extraction completeness (0.0 - 1.0)
      - has_latest_doc: whether provider has a currently-effective document
    """

    def __init__(self, spark: Any, config: Optional[TierConfig] = None) -> None:
        self._spark = spark
        self._config = config or DEFAULT_TIER_CONFIG
        self._cache: Dict[str, str] = {}  # provider_name → tier
        self._scores: Dict[str, float] = {}  # provider_name → raw score
        self._loaded = False

    def get_tier(self, provider_name: str) -> str:
        """Get confidence tier for a provider."""
        if not self._loaded:
            self._load()
        return self._cache.get(provider_name, "low")

    def get_score(self, provider_name: str) -> float:
        """Get raw confidence score for a provider."""
        if not self._loaded:
            self._load()
        return self._scores.get(provider_name, 0.0)

    def get_all_tiers(self) -> Dict[str, str]:
        """Get all provider tiers."""
        if not self._loaded:
            self._load()
        return dict(self._cache)

    @property
    def tier_distribution(self) -> Dict[str, int]:
        """Count of providers per tier."""
        if not self._loaded:
            self._load()
        dist: Dict[str, int] = {"high": 0, "moderate": 0, "low": 0}
        for tier in self._cache.values():
            dist[tier] = dist.get(tier, 0) + 1
        return dist

    def _load(self) -> None:
        """Load tier data from Delta tables."""
        try:
            df = self._spark.sql(f"""
                WITH doc_counts AS (
                    SELECT provider_name,
                           COUNT(DISTINCT source_filename) AS doc_count
                    FROM {CATALOG}.{SCHEMA}.tbl_vs_unified_ready
                    GROUP BY provider_name
                ),
                current_docs AS (
                    SELECT DISTINCT f.provider_name
                    FROM {CATALOG}.{SCHEMA}.tbl_vs_unified_ready f
                    JOIN {CATALOG}.{SCHEMA}.tbl_contract_documents_master m
                      ON f.source_filename = m.source_filename
                    WHERE m.expiration_date IS NULL
                       OR TRY_CAST(m.expiration_date AS DATE) IS NULL
                       OR TRY_CAST(m.expiration_date AS DATE) >= CURRENT_DATE()
                )
                SELECT d.provider_name,
                       d.doc_count,
                       CASE WHEN c.provider_name IS NOT NULL THEN 1.0 ELSE 0.0 END AS has_latest
                FROM doc_counts d
                LEFT JOIN current_docs c ON d.provider_name = c.provider_name
            """).toPandas()

            cfg = self._config
            for _, row in df.iterrows():
                prov = row["provider_name"]
                doc_score = min(float(row["doc_count"]) / cfg.doc_count_scale, 1.0)
                extraction_score = 1.0  # Assume full extraction for loaded providers
                latest_score = float(row["has_latest"])

                score = (
                    cfg.weight_doc_count * doc_score
                    + cfg.weight_extraction_tier * extraction_score
                    + cfg.weight_has_latest_doc * latest_score
                )

                self._scores[prov] = round(score, 3)
                if score >= cfg.threshold_high:
                    self._cache[prov] = "high"
                elif score >= cfg.threshold_moderate:
                    self._cache[prov] = "moderate"
                else:
                    self._cache[prov] = "low"

            self._loaded = True
            logger.info("TierService loaded %d providers", len(self._cache))

        except Exception as e:
            logger.error("TierService load failed: %s", e)
            self._loaded = True  # Prevent retry loops
