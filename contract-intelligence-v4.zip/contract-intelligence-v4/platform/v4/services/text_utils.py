"""
platform/v4/services/text_utils.py

P2-NORM-1: Text normalization helpers.

Extracted from V2 Cell 5/6 (Branch A helpers): chunk dedup, passage scoring,
keyword extraction, and stopword lists.

Used by clause_existence, explanation, and other retrieval-heavy tools.

Usage
-----
    from platform.v4.services.text_utils import (
        score_passages, dedup_by_provider, extract_keywords,
        normalize_chunk, STOPWORDS,
    )
"""
from __future__ import annotations

import re
from typing import Dict, List, Optional, Set


# ==============================================================================
# STOPWORDS
# ==============================================================================

STOPWORDS: Set[str] = {
    "the", "a", "an", "is", "are", "was", "were", "be", "been", "being",
    "have", "has", "had", "do", "does", "did", "will", "would", "could",
    "should", "may", "might", "shall", "can", "need", "must",
    "of", "in", "to", "for", "with", "on", "at", "from", "by", "about",
    "as", "into", "through", "during", "before", "after", "above", "below",
    "between", "under", "over", "out", "up", "down", "off",
    "and", "but", "or", "nor", "not", "so", "yet", "both", "either",
    "neither", "each", "every", "all", "any", "few", "more", "most",
    "other", "some", "such", "no", "only", "own", "same", "than",
    "too", "very", "just", "also", "then", "there", "here", "when",
    "where", "why", "how", "what", "which", "who", "whom", "this",
    "that", "these", "those", "it", "its", "he", "she", "they", "them",
    "we", "you", "i", "me", "my", "your", "his", "her", "our", "their",
    "provider", "contract", "agreement", "section", "article",
    "pursuant", "herein", "hereof", "thereof", "hereby",
}


# ==============================================================================
# TEXT NORMALIZATION
# ==============================================================================

def normalize_chunk(text: str) -> str:
    """Normalize a text chunk for comparison.

    - Lowercases
    - Collapses whitespace
    - Strips leading/trailing whitespace
    """
    if not text:
        return ""
    return re.sub(r"\s+", " ", text.lower().strip())


def extract_keywords(text: str, max_keywords: int = 8) -> List[str]:
    """Extract meaningful keywords from text (removes stopwords)."""
    words = re.findall(r"\b[a-z]{3,}\b", text.lower())
    seen: Set[str] = set()
    keywords: List[str] = []
    for w in words:
        if w not in STOPWORDS and w not in seen:
            seen.add(w)
            keywords.append(w)
            if len(keywords) >= max_keywords:
                break
    return keywords


def text_similarity(a: str, b: str) -> float:
    """Simple token overlap similarity (Jaccard-like)."""
    if not a or not b:
        return 0.0
    tokens_a = set(re.findall(r"\b\w{3,}\b", a.lower())) - STOPWORDS
    tokens_b = set(re.findall(r"\b\w{3,}\b", b.lower())) - STOPWORDS
    if not tokens_a or not tokens_b:
        return 0.0
    intersection = tokens_a & tokens_b
    union = tokens_a | tokens_b
    return len(intersection) / len(union) if union else 0.0


# ==============================================================================
# PASSAGE SCORING & DEDUP
# ==============================================================================

def score_passage(text: str, concept_keywords: List[str]) -> float:
    """Score a passage by keyword density relative to concept.

    Higher = more relevant to the concept.
    """
    if not text or not concept_keywords:
        return 0.0
    text_lower = text.lower()
    hits = sum(1 for kw in concept_keywords if kw.lower() in text_lower)
    # Normalize by keyword count; boost longer passages slightly
    base_score = hits / len(concept_keywords)
    length_bonus = min(len(text) / 500.0, 1.0) * 0.1
    return base_score + length_bonus


def score_passages(
    passages: List[Dict],
    concept: str,
    text_key: str = "text",
    max_per_provider: Optional[int] = None,
) -> List[Dict]:
    """Score and rank passages by relevance to a concept.

    Args:
        passages: List of passage dicts (must have text_key and 'provider' keys).
        concept: The target concept for scoring.
        text_key: Key in dict containing the text.
        max_per_provider: Cap passages per provider (None = no cap).

    Returns: Scored passages sorted by score descending.
    """
    concept_keywords = extract_keywords(concept)
    for p in passages:
        p["_score"] = score_passage(p.get(text_key, ""), concept_keywords)

    scored = sorted(passages, key=lambda x: x.get("_score", 0), reverse=True)

    if max_per_provider:
        scored = _cap_by_provider(scored, max_per_provider)

    return scored


def dedup_by_provider(
    passages: List[Dict],
    text_key: str = "text",
    provider_key: str = "provider",
    max_per_provider: int = 20,
    min_length: int = 30,
) -> List[Dict]:
    """Deduplicate passages: cap per provider, remove duplicates and short text.

    This replicates V2 Cell 6 Step 4 (Merge + Dedup).
    """
    # Remove short passages
    valid = [p for p in passages if len(p.get(text_key, "")) >= min_length]

    # Dedup by normalized content
    seen_texts: Set[str] = set()
    deduped: List[Dict] = []
    for p in valid:
        norm = normalize_chunk(p.get(text_key, ""))[:200]  # First 200 chars as key
        if norm not in seen_texts:
            seen_texts.add(norm)
            deduped.append(p)

    # Cap per provider
    return _cap_by_provider(deduped, max_per_provider, provider_key)


def _cap_by_provider(
    passages: List[Dict], cap: int, provider_key: str = "provider"
) -> List[Dict]:
    """Keep at most `cap` passages per provider."""
    counts: Dict[str, int] = {}
    result: List[Dict] = []
    for p in passages:
        prov = p.get(provider_key, "Unknown")
        counts[prov] = counts.get(prov, 0) + 1
        if counts[prov] <= cap:
            result.append(p)
    return result


# ==============================================================================
# KEYWORD RECALL (for scoring/evaluation)
# ==============================================================================

def keyword_recall(actual: str, expected: str) -> float:
    """Fraction of expected content words found in actual answer.

    Used by evaluation scoring (replaces Jaccard).
    Stopwords excluded from both sides.
    """
    if not expected or not actual:
        return 0.0
    expected_words = set(re.findall(r"\b\w{3,}\b", expected.lower())) - STOPWORDS
    if not expected_words:
        return 1.0  # Nothing expected = trivially recalled
    actual_lower = actual.lower()
    recalled = sum(1 for w in expected_words if w in actual_lower)
    return recalled / len(expected_words)
