"""
platform/v4/services/provider_service.py

P1-PROV-1/2: V3 provider resolution service.

Replaces V2 Cell 3 canonical provider resolution logic:
  - _CANONICAL_CACHE, _CANONICAL_ID_MAP, _CANONICAL_NAMES
  - resolve_provider(), provider_sql_filter(), provider_display_name()
  - get_provider_universe()

Loads dim_provider_canonical at construction time. Thread-safe for reads.

Usage
-----
    from platform.v4.services.provider_service import ProviderService

    svc = ProviderService(spark=spark)
    names, method, ids = svc.resolve("Sutter")
    sql_clause = svc.sql_filter("Cedars-Sinai", column="provider_id")
"""
from __future__ import annotations

import logging
import warnings
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set, Tuple

from ..config.settings import CATALOG, SCHEMA, TBL_DIM_PROVIDER_CANONICAL

logger = logging.getLogger(__name__)


@dataclass
class CanonicalEntry:
    """One canonical provider facility."""
    canonical_name: str
    provider_ids: List[str] = field(default_factory=list)
    primary_id: Optional[str] = None


class ProviderService:
    """
    Canonical provider resolution service.

    Resolution hierarchy (same as V2):
      1. canonical_exact  — exact lowercase match
      2. canonical_contains — input is substring of cache key
      3. canonical_reverse  — cache key is substring of input
      4. canonical_tokens   — all input words appear in cache key
      5. canonical_prefix   — first token matches cache key prefix
      6. unresolved         — fallback (LIKE-based SQL)
    """

    def __init__(self, spark: Any) -> None:
        self._spark = spark
        self._cache: Dict[str, CanonicalEntry] = {}      # lower_key → entry
        self._id_to_name: Dict[str, str] = {}            # provider_id → canonical_name
        self._canonical_names: List[str] = []            # sorted unique names
        self._corpus_universe: Optional[List[str]] = None
        self._load()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    # ── Health system umbrella name aliases ─────────────────────────────────────
    # Maps common health system names (that are NOT in dim_provider_canonical)
    # to their constituent facility search tokens for contains-matching.
    _SYSTEM_NAME_TOKENS: dict = {
        "sharp healthcare": "sharp",
        "sharp health care": "sharp",
        "dignity health": "mercy",   # Mercy General / Mercy Hospitals are the canonical DH acute-care facilities
        "dignity": "mercy",
        "commonspirit health": "mercy",  # CommonSpirit = Dignity Health parent → all Mercy facilities
    }

    def resolve(self, user_input: str) -> Tuple[List[str], str, List[str]]:
        """
        Resolve a user-provided name to canonical facility name(s) and provider_ids.

        Returns: (matched_names, method, provider_ids)
        """
        # Lazy reload: if startup SQL failed (e.g., missing CAN_USE on warehouse
        # at boot time), the cache is empty. Attempt a reload on the first real
        # lookup so the app self-heals without requiring a redeploy.
        if not self._cache and self._spark is not None:
            logger.warning(
                "ProviderService cache empty — lazy reload from %s.",
                TBL_DIM_PROVIDER_CANONICAL,
            )
            self._load()

        if not user_input:
            return ([], "none", [])

        input_lower = user_input.lower().strip()
        
        # Pre-check: health system umbrella names → redirect to facility token
        _sys_token = self._SYSTEM_NAME_TOKENS.get(input_lower)
        if _sys_token:
            # Resolve using the facility token instead (e.g. "sharp healthcare" → "sharp")
            contains_matches = [
                (k, v) for k, v in self._cache.items() if _sys_token in k
            ]
            if contains_matches:
                names = [v.canonical_name for _, v in contains_matches]
                ids = [pid for _, v in contains_matches for pid in v.provider_ids]
                return (names, "system_alias", ids)

        # Period + hyphen normalization: "St. Mary" → "st mary", "Cedars-Sinai" → "cedarssinai"
        # so they match canonical forms like "st mary medical center", "cedarssinai medical center"
        # Non-numeric periods are removed (preserves "2.5" but removes "St.")
        import re as _re
        input_normalized = _re.sub(r'(?<!\d)\.(?!\d)', '', input_lower).strip()
        # Remove hyphens between word chars ("cedars-sinai" → "cedarssinai")
        input_normalized = input_normalized.replace('-', '')
        # Collapse multiple spaces from period removal
        input_normalized = _re.sub(r'\s{2,}', ' ', input_normalized)

        # 1. Exact canonical name match (try both raw and normalized)
        if input_lower in self._cache:
            entry = self._cache[input_lower]
            return ([entry.canonical_name], "canonical_exact", entry.provider_ids)
        if input_normalized != input_lower and input_normalized in self._cache:
            entry = self._cache[input_normalized]
            return ([entry.canonical_name], "canonical_exact", entry.provider_ids)

        # 2. Input is substring of canonical name (try both raw and period-normalized)
        contains_matches = [
            (k, v) for k, v in self._cache.items() if input_lower in k
        ]
        if not contains_matches and input_normalized != input_lower:
            contains_matches = [
                (k, v) for k, v in self._cache.items() if input_normalized in k
            ]
        if contains_matches:
            names = [v.canonical_name for _, v in contains_matches]
            ids = [pid for _, v in contains_matches for pid in v.provider_ids]
            return (names, "canonical_contains", ids)

        # 3. Canonical name is substring of input (try both raw and normalized)
        # MIN-LENGTH GUARD: only consider cache keys >= 8 chars to prevent
        # single-character / short-alias cache pollution from creating false matches.
        reverse_matches = [
            (k, v) for k, v in self._cache.items() if k in input_lower and len(k) >= 8
        ]
        if not reverse_matches and input_normalized != input_lower:
            reverse_matches = [
                (k, v) for k, v in self._cache.items() if k in input_normalized and len(k) >= 8
            ]
        if reverse_matches:
            names = [v.canonical_name for _, v in reverse_matches]
            ids = [pid for _, v in reverse_matches for pid in v.provider_ids]
            return (names, "canonical_reverse", ids)

        # 4. All input tokens appear in canonical name (use normalized tokens)
        input_tokens = set(input_normalized.split())
        if len(input_tokens) >= 2:
            token_matches = [
                (k, v) for k, v in self._cache.items()
                if all(t in k for t in input_tokens)
            ]
            if token_matches:
                names = [v.canonical_name for _, v in token_matches]
                ids = [pid for _, v in token_matches for pid in v.provider_ids]
                return (names, "canonical_tokens", ids)

        # 5. First-token prefix
        first_token = input_lower.split()[0] if input_lower.split() else ""
        if len(first_token) >= 4:
            prefix_matches = [
                (k, v) for k, v in self._cache.items() if k.startswith(first_token)
            ]
            if prefix_matches:
                names = [v.canonical_name for _, v in prefix_matches]
                ids = [pid for _, v in prefix_matches for pid in v.provider_ids]
                return (names, "canonical_prefix", ids)

        # 6. Unresolved
        return ([user_input], "unresolved", [])

    def sql_filter(self, provider_name: str, column: str = "provider_id") -> str:
        """
        Build a SQL WHERE clause fragment for provider matching.
        Uses canonical resolution for exact ID-based filtering.
        Falls back to LIKE only when canonical resolution fails.
        """
        _, method, provider_ids = self.resolve(provider_name)

        if provider_ids:
            if len(provider_ids) == 1:
                return f"{column} = '{provider_ids[0]}'"
            safe_ids = ", ".join(f"'{pid}'" for pid in provider_ids)
            return f"{column} IN ({safe_ids})"

        # Fallback: LIKE-based (emit warning)
        warnings.warn(
            f"[V-03] provider_sql_filter: LIKE-based query for '{provider_name}' — "
            "canonical resolution failed. Check spelling or add to dim_provider_canonical.",
            UserWarning, stacklevel=2,
        )
        safe = provider_name.lower().replace("'", "''")
        name_col = "provider_name" if column == "provider_id" else column
        return f"LOWER({name_col}) LIKE '%{safe}%'"

    def display_name(self, provider_name: str) -> str:
        """Get canonical display name for a provider."""
        resolved, method, _ = self.resolve(provider_name)
        if method != "unresolved" and resolved:
            return resolved[0]
        return provider_name

    def all_names(self) -> List[str]:
        """Return all canonical facility names (sorted)."""
        return self._canonical_names

    def corpus_universe(self) -> List[str]:
        """Return all distinct provider_names from tbl_vs_unified_ready."""
        if self._corpus_universe is None:
            try:
                self._corpus_universe = (
                    self._spark.sql(f"""
                        SELECT DISTINCT provider_name
                        FROM {CATALOG}.{SCHEMA}.tbl_vs_unified_ready
                        WHERE provider_name IS NOT NULL
                        ORDER BY provider_name
                    """)
                    .toPandas()["provider_name"]
                    .tolist()
                )
            except Exception as e:
                logger.warning("Failed to load corpus universe: %s", e)
                self._corpus_universe = self._canonical_names
        return self._corpus_universe

    def id_to_name(self, provider_id: str) -> Optional[str]:
        """Lookup canonical name by provider_id."""
        return self._id_to_name.get(provider_id)

    @property
    def facility_count(self) -> int:
        """Number of canonical facilities loaded."""
        return len(self._canonical_names)

    @property
    def id_count(self) -> int:
        """Number of distinct provider IDs loaded."""
        return len(self._id_to_name)

    # ------------------------------------------------------------------
    # Internal loading
    # ------------------------------------------------------------------

    def _load(self) -> None:
        """Load canonical providers from Delta table."""
        try:
            df = self._spark.sql(f"""
                SELECT provider_id, canonical_name, primary_provider_id, is_primary_id
                FROM {TBL_DIM_PROVIDER_CANONICAL}
                ORDER BY canonical_name, rank_in_facility
            """).toPandas()

            # Build canonical_name → provider_ids mapping
            for _, row in df.iterrows():
                cn = row["canonical_name"]
                cn_lower = cn.lower()
                pid = row["provider_id"]
                if cn_lower not in self._cache:
                    self._cache[cn_lower] = CanonicalEntry(canonical_name=cn)
                self._cache[cn_lower].provider_ids.append(pid)
                if row["is_primary_id"]:
                    self._cache[cn_lower].primary_id = pid
                self._id_to_name[pid] = cn

            self._canonical_names = sorted(
                set(v.canonical_name for v in self._cache.values())
            )

            # Load aliases (all_names_used column)
            self._load_aliases()

            logger.info(
                "ProviderService loaded: %d facilities from %d IDs",
                len(self._canonical_names), len(self._id_to_name),
            )

        except Exception as e:
            logger.error("ProviderService: failed to load canonical providers: %s", e)
            self._canonical_names = []

    def _load_aliases(self) -> None:
        """Load all_names_used aliases into cache."""
        try:
            alias_df = self._spark.sql(f"""
                SELECT canonical_name, all_names_used,
                       COLLECT_LIST(provider_id) AS provider_ids
                FROM {TBL_DIM_PROVIDER_CANONICAL}
                WHERE all_names_used IS NOT NULL AND SIZE(all_names_used) > 1
                GROUP BY canonical_name, all_names_used
            """).toPandas()

            alias_count = 0
            # Collect all canonical name tokens for cross-provider conflict detection
            _canonical_tokens = set()
            for k in self._cache.keys():
                for word in k.split():
                    if len(word) >= 4:  # skip short words
                        _canonical_tokens.add(word)
            
            for _, row in alias_df.iterrows():
                cn = row["canonical_name"]
                pids = list(row["provider_ids"])
                cn_lower = cn.lower()
                cn_words = set(cn_lower.split())
                for alias in row["all_names_used"]:
                    al = alias.lower().strip()
                    # ALIAS-POLLUTION GUARD: skip empty or very short aliases.
                    # These arise when all_names_used is serialized as a string
                    # instead of an array, causing iteration over individual characters.
                    # A real provider alias is always >= 4 characters.
                    if len(al) < 4:
                        continue
                    if al not in self._cache and al != cn_lower:
                        # STALE ALIAS GUARD: Skip aliases whose significant words
                        # match a DIFFERENT existing canonical provider name.
                        # E.g., 'Scripps Physicians Medical Group' as alias for Optum
                        # conflicts with 'Scripps Memorial Hospital' (a real provider).
                        _alias_sig_words = {w for w in al.split() if len(w) >= 5 and w not in {
                            'medical', 'center', 'hospital', 'health', 'group', 'inc',
                            'services', 'care', 'community', 'regional', 'memorial',
                        }}
                        _conflicts_other = False
                        for _existing_key in list(self._cache.keys()):
                            if _existing_key == cn_lower:
                                continue
                            if any(sw in _existing_key for sw in _alias_sig_words):
                                _conflicts_other = True
                                logger.debug(
                                    "Alias '%s' for '%s' conflicts with existing key '%s' — skipped",
                                    al, cn, _existing_key,
                                )
                                break
                        if _conflicts_other:
                            continue
                        self._cache[al] = CanonicalEntry(
                            canonical_name=cn, provider_ids=pids
                        )
                        alias_count += 1

            # Add hyphen-stripped variants
            hyphen_adds = {}
            for key, entry in list(self._cache.items()):
                if "-" in key:
                    no_h = key.replace("-", "")
                    if no_h not in self._cache:
                        hyphen_adds[no_h] = entry
                    sp_h = key.replace("-", " ")
                    if sp_h not in self._cache:
                        hyphen_adds[sp_h] = entry
            self._cache.update(hyphen_adds)
            alias_count += len(hyphen_adds)

            logger.info("ProviderService: loaded %d aliases", alias_count)

        except Exception:
            pass  # Non-fatal: aliases are an optimization
