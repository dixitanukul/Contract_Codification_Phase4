"""platform/v4/services/citation_validator.py

Step 1.5: Citation validation layer — ensures every answer is verifiable.

Extends the stateless CitationVerifier with Spark-dependent checks that
confirm citations actually trace back to real data:

  1. Source existence — source_filename resolves to tbl_contract_documents_master
  2. Passage integrity — chunk_text actually exists in tbl_vs_unified_ready
  3. Claim-to-evidence NLI — LLM-based natural language inference (when keyword
     overlap is borderline)

These three checks run IN ADDITION to the existing CitationVerifier checks
(supersession, grounding, numerical, temporal).

Architecture
------------
    CitationValidator (this file)
      +-- CitationVerifier (stateless, no Spark)
      +-- Spark session (SQL checks)
      +-- LLM client (optional, for NLI)

Usage
-----
    from platform.v4.services.citation_validator import CitationValidator

    validator = CitationValidator(spark=spark, llm_client=llm_client)
    result = validator.validate(
        answer="Sutter has a $50,000 offset cap effective Jan 1, 2024",
        citations=[citation1, citation2],
    )
    if not result.all_passed:
        print(f"Validation failed: {result.failure_summary}")
        print(f"Pass rate: {result.pass_rate:.0%}")
"""
from __future__ import annotations

import hashlib
import logging
from dataclasses import dataclass, field
from typing import Any, Optional, Sequence

logger = logging.getLogger(__name__)

# Default table references (can be overridden via constructor)
from ..config.settings import CATALOG as _DEFAULT_CATALOG, SCHEMA as _DEFAULT_SCHEMA
_DEFAULT_DOCUMENTS_TABLE = "tbl_contract_documents_master"
_DEFAULT_FULLTEXT_TABLE = "tbl_vs_unified_ready"  # V4 unified corpus (Step 0.3)

# NLI prompt template
_NLI_PROMPT = """You are a citation verification system. Determine whether the passage SUPPORTS the claim.

Rules:
- Answer ONLY "SUPPORTS", "CONTRADICTS", or "INSUFFICIENT".
- SUPPORTS: The passage contains information that directly backs the claim.
- CONTRADICTS: The passage contains information that directly contradicts the claim.
- INSUFFICIENT: The passage does not contain enough information to verify or deny the claim.

Claim: {claim}

Passage: {passage}

Verdict:"""


# ============================================================
# TYPES
# ============================================================


class CheckStatus:
    """Individual check outcome (mirrors verification.citation_verifier.CheckStatus)."""
    PASS = "PASS"
    WARN = "WARN"
    FAIL = "FAIL"
    SKIP = "SKIP"


@dataclass(frozen=True)
class CheckResult:
    """Result of a single validation check on one citation."""
    check_name: str
    status: str  # CheckStatus value
    detail: str
    confidence_impact: float = 0.0


@dataclass
class CitationValidation:
    """Full validation result for a single citation (all 6 checks)."""
    citation_index: int
    source_filename: str
    checks: list[CheckResult] = field(default_factory=list)

    @property
    def passed(self) -> bool:
        return not any(c.status == CheckStatus.FAIL for c in self.checks)

    @property
    def has_warnings(self) -> bool:
        return any(c.status == CheckStatus.WARN for c in self.checks)

    @property
    def failure_reasons(self) -> list[str]:
        return [c.detail for c in self.checks if c.status == CheckStatus.FAIL]

    @property
    def warning_reasons(self) -> list[str]:
        return [c.detail for c in self.checks if c.status == CheckStatus.WARN]

    @property
    def confidence_penalty(self) -> float:
        return sum(c.confidence_impact for c in self.checks)


@dataclass
class ValidationResult:
    """Aggregate validation result across all citations for an answer."""
    answer: str
    validations: list[CitationValidation] = field(default_factory=list)

    @property
    def n_citations(self) -> int:
        return len(self.validations)

    @property
    def n_passed(self) -> int:
        return sum(1 for v in self.validations if v.passed)

    @property
    def n_failed(self) -> int:
        return sum(1 for v in self.validations if not v.passed)

    @property
    def all_passed(self) -> bool:
        return self.n_failed == 0

    @property
    def has_failures(self) -> bool:
        return self.n_failed > 0

    @property
    def pass_rate(self) -> float:
        if not self.validations:
            return 0.0
        return self.n_passed / self.n_citations

    @property
    def failure_summary(self) -> str:
        reasons = []
        for v in self.validations:
            for r in v.failure_reasons:
                reasons.append(f"[{v.source_filename}] {r}")
        return "; ".join(reasons[:5])

    @property
    def overall_confidence_penalty(self) -> float:
        if not self.validations:
            return 0.0
        return sum(v.confidence_penalty for v in self.validations) / self.n_citations


# ============================================================
# VALIDATOR CLASS
# ============================================================


class CitationValidator:
    """Full citation validation service with Spark-dependent checks.

    Performs 6 checks on each citation:
      1. Source existence — source_filename in tbl_contract_documents_master
      2. Passage integrity — chunk_text matches tbl_vs_unified_ready
      3. Supersession — is document current? (recency check)
      4. Grounding — keyword overlap + optional LLM NLI
      5. Numerical — numbers in claim match passage
      6. Temporal — dates consistent

    Checks 1-2 are Spark-dependent. Checks 3-6 are stateless.

    Parameters
    ----------
    spark : SparkSession
        Active Spark session for SQL checks.
    llm_client : optional
        LLM client with `.chat(model, system, user)` method for NLI.
        If None, NLI check is skipped.
    catalog : str
        Unity Catalog name (default "dev_adb").
    schema : str
        Schema name (default "raw").
    nli_model : str
        Model endpoint for NLI calls.
    grounding_threshold : float
        Keyword overlap threshold for grounding check (default 0.25).
    nli_on_warn : bool
        If True, run LLM NLI when keyword grounding is WARN (borderline).
    """

    def __init__(
        self,
        spark: Any,
        llm_client: Optional[Any] = None,
        catalog: str = _DEFAULT_CATALOG,
        schema: str = _DEFAULT_SCHEMA,
        nli_model: str = "databricks-claude-sonnet-4",
        grounding_threshold: float = 0.25,
        nli_on_warn: bool = True,
    ):
        self._spark = spark
        self._llm_client = llm_client
        self._catalog = catalog
        self._schema = schema
        self._nli_model = nli_model
        self._grounding_threshold = grounding_threshold
        self._nli_on_warn = nli_on_warn

        # Fully qualified table names
        self._documents_table = f"{catalog}.{schema}.{_DEFAULT_DOCUMENTS_TABLE}"
        self._fulltext_table = f"{catalog}.{schema}.{_DEFAULT_FULLTEXT_TABLE}"

        # Cache: source_filename -> exists (bool)
        self._source_cache: dict[str, bool] = {}
        # Cache: chunk_text hash -> exists (bool)
        self._passage_cache: dict[str, bool] = {}

    # ------------------------------------------------------------------
    # PUBLIC API
    # ------------------------------------------------------------------

    def validate(
        self,
        answer: str,
        citations: Sequence[Any],
    ) -> ValidationResult:
        """Validate all citations against an answer.

        Parameters
        ----------
        answer : str
            The answer text or specific claim being made.
        citations : sequence
            Citation objects or dicts with keys: passage_text, source_filename,
            is_current_effective, doc_role, effective_date, chunk_text (optional).

        Returns
        -------
        ValidationResult with per-citation validations and aggregate stats.
        """
        if not citations:
            return ValidationResult(answer=answer[:500], validations=[])

        # Pre-warm source existence cache (batch SQL)
        filenames = [_get(c, "source_filename", "") for c in citations]
        self._batch_check_sources(filenames)

        validations = []
        for idx, cit in enumerate(citations):
            validation = self._validate_single(answer, cit, idx)
            validations.append(validation)

        return ValidationResult(answer=answer[:500], validations=validations)

    def validate_single(
        self,
        answer: str,
        citation: Any,
    ) -> CitationValidation:
        """Validate a single citation against an answer."""
        return self._validate_single(answer, citation, 0)

    # ------------------------------------------------------------------
    # INTERNAL: Single citation validation
    # ------------------------------------------------------------------

    def _validate_single(
        self, answer: str, citation: Any, index: int
    ) -> CitationValidation:
        """Run all checks on a single citation."""
        source_filename = _get(citation, "source_filename", "")
        passage_text = _get(citation, "passage_text", "") or _get(citation, "chunk_text", "")
        is_current = _get(citation, "is_current_effective", True)
        doc_role = _get(citation, "doc_role", "")
        effective_date = _get(citation, "effective_date", "")

        checks: list[CheckResult] = []

        # Check 1: Source existence (Spark)
        checks.append(self._check_source_existence(source_filename))

        # Check 2: Passage integrity (Spark)
        checks.append(self._check_passage_integrity(passage_text, source_filename))

        # Check 3: Supersession / Recency
        checks.append(self._check_recency(is_current, doc_role))

        # Check 4: Grounding (keyword + optional NLI)
        checks.append(self._check_grounding(answer, passage_text))

        # Check 5: Numerical consistency
        checks.append(self._check_numerical(answer, passage_text))

        # Check 6: Temporal consistency
        checks.append(self._check_temporal(answer, passage_text, effective_date))

        return CitationValidation(
            citation_index=index,
            source_filename=source_filename,
            checks=checks,
        )

    # ------------------------------------------------------------------
    # CHECK 1: Source Existence
    # ------------------------------------------------------------------

    def _check_source_existence(self, source_filename: str) -> CheckResult:
        """Verify source_filename resolves to a real document."""
        if not source_filename or not source_filename.strip():
            return CheckResult(
                check_name="source_existence",
                status=CheckStatus.FAIL,
                detail="No source_filename provided",
                confidence_impact=-0.4,
            )

        exists = self._source_exists(source_filename)
        if exists:
            return CheckResult(
                check_name="source_existence",
                status=CheckStatus.PASS,
                detail=f"Source '{source_filename}' confirmed in documents master",
            )
        else:
            return CheckResult(
                check_name="source_existence",
                status=CheckStatus.FAIL,
                detail=f"Source '{source_filename}' NOT found in {self._documents_table}",
                confidence_impact=-0.5,
            )

    def _source_exists(self, filename: str) -> bool:
        """Check if filename exists (uses cache)."""
        if filename in self._source_cache:
            return self._source_cache[filename]

        try:
            safe_fn = filename.replace("'", "''")
            row = self._spark.sql(f"""
                SELECT 1 FROM {self._documents_table}
                WHERE source_filename = '{safe_fn}'
                LIMIT 1
            """).count()
            exists = row > 0
        except Exception as e:
            logger.warning("Source existence check failed for %s: %s", filename, e)
            exists = True  # Fail-open on SQL error

        self._source_cache[filename] = exists
        return exists

    def _batch_check_sources(self, filenames: list[str]) -> None:
        """Pre-warm the source existence cache for a batch of filenames."""
        uncached = [f for f in filenames if f and f not in self._source_cache]
        if not uncached:
            return

        # Deduplicate
        unique = list(set(uncached))
        if len(unique) > 500:
            unique = unique[:500]  # Safety cap

        try:
            safe_fns = ", ".join(f"'{f.replace(chr(39), chr(39)+chr(39))}'" for f in unique)
            df = self._spark.sql(f"""
                SELECT DISTINCT source_filename
                FROM {self._documents_table}
                WHERE source_filename IN ({safe_fns})
            """).toPandas()
            found = set(df["source_filename"].tolist())

            for fn in unique:
                self._source_cache[fn] = fn in found
        except Exception as e:
            logger.warning("Batch source check failed: %s", e)
            # Fail-open: mark all as existing
            for fn in unique:
                self._source_cache[fn] = True

    # ------------------------------------------------------------------
    # CHECK 2: Passage Integrity
    # ------------------------------------------------------------------

    def _check_passage_integrity(self, passage_text: str, source_filename: str) -> CheckResult:
        """Verify cited passage actually exists in the unified corpus."""
        if not passage_text or len(passage_text.strip()) < 20:
            return CheckResult(
                check_name="passage_integrity",
                status=CheckStatus.SKIP,
                detail="Passage text too short to verify integrity",
            )

        exists = self._passage_exists(passage_text, source_filename)
        if exists:
            return CheckResult(
                check_name="passage_integrity",
                status=CheckStatus.PASS,
                detail="Passage text confirmed in unified corpus",
            )
        else:
            return CheckResult(
                check_name="passage_integrity",
                status=CheckStatus.WARN,
                detail="Passage text not found verbatim in corpus (may be truncated/reformatted)",
                confidence_impact=-0.15,
            )

    def _passage_exists(self, passage_text: str, source_filename: str) -> bool:
        """Check if passage exists in corpus (substring match on first 100 chars)."""
        cache_key = hashlib.md5(passage_text[:200].encode()).hexdigest()
        if cache_key in self._passage_cache:
            return self._passage_cache[cache_key]

        try:
            # Use first 100 chars as search anchor (handles truncation)
            anchor = passage_text[:100].replace("'", "''").replace("%", "%%")
            safe_fn = source_filename.replace("'", "''") if source_filename else ""

            where_clause = f"chunk_text LIKE '{anchor}%'"
            if safe_fn:
                where_clause += f" AND source_filename = '{safe_fn}'"

            row = self._spark.sql(f"""
                SELECT 1 FROM {self._fulltext_table}
                WHERE {where_clause}
                LIMIT 1
            """).count()
            exists = row > 0
        except Exception as e:
            logger.warning("Passage integrity check failed: %s", e)
            exists = True  # Fail-open

        self._passage_cache[cache_key] = exists
        return exists

    # ------------------------------------------------------------------
    # CHECK 3: Recency / Supersession
    # ------------------------------------------------------------------

    _SUPERSEDED_DOC_ROLES = frozenset({"superseded", "replaced", "prior_version"})

    def _check_recency(self, is_current: bool, doc_role: str) -> CheckResult:
        """Verify the cited document is still current."""
        if not is_current:
            return CheckResult(
                check_name="recency",
                status=CheckStatus.WARN,
                detail="Citation from non-current document (expired or superseded)",
                confidence_impact=-0.3,
            )
        if doc_role and doc_role.lower() in self._SUPERSEDED_DOC_ROLES:
            return CheckResult(
                check_name="recency",
                status=CheckStatus.WARN,
                detail=f"Document role '{doc_role}' indicates supersession",
                confidence_impact=-0.2,
            )
        return CheckResult(
            check_name="recency",
            status=CheckStatus.PASS,
            detail="Document is current",
        )

    # ------------------------------------------------------------------
    # CHECK 4: Grounding (keyword + optional LLM NLI)
    # ------------------------------------------------------------------

    def _check_grounding(self, claim: str, passage_text: str) -> CheckResult:
        """Verify passage supports the claim (keyword overlap + optional NLI)."""
        import re as _re

        if not passage_text or len(passage_text.strip()) < 20:
            return CheckResult(
                check_name="grounding",
                status=CheckStatus.FAIL,
                detail="Passage text empty or trivially short",
                confidence_impact=-0.5,
            )
        if not claim or len(claim.strip()) < 10:
            return CheckResult(
                check_name="grounding",
                status=CheckStatus.SKIP,
                detail="Claim too short to verify grounding",
            )

        # Keyword overlap
        overlap = self._keyword_overlap(claim, passage_text)

        if overlap >= self._grounding_threshold:
            return CheckResult(
                check_name="grounding",
                status=CheckStatus.PASS,
                detail=f"Keyword overlap {overlap:.0%} >= {self._grounding_threshold:.0%}",
            )
        elif overlap >= self._grounding_threshold * 0.5:
            # Borderline — try LLM NLI if available
            if self._nli_on_warn and self._llm_client:
                nli_result = self._run_nli(claim, passage_text)
                if nli_result == "SUPPORTS":
                    return CheckResult(
                        check_name="grounding",
                        status=CheckStatus.PASS,
                        detail=f"Keyword overlap {overlap:.0%} borderline but NLI confirms support",
                    )
                elif nli_result == "CONTRADICTS":
                    return CheckResult(
                        check_name="grounding",
                        status=CheckStatus.FAIL,
                        detail=f"NLI: passage CONTRADICTS claim (keyword overlap {overlap:.0%})",
                        confidence_impact=-0.5,
                    )
            # No LLM or NLI=INSUFFICIENT -> WARN
            return CheckResult(
                check_name="grounding",
                status=CheckStatus.WARN,
                detail=f"Weak grounding: overlap {overlap:.0%} (threshold {self._grounding_threshold:.0%})",
                confidence_impact=-0.2,
            )
        else:
            # Very low overlap -> FAIL
            return CheckResult(
                check_name="grounding",
                status=CheckStatus.FAIL,
                detail=f"Passage does not support claim: overlap {overlap:.0%} < {self._grounding_threshold:.0%}",
                confidence_impact=-0.5,
            )

    def _run_nli(self, claim: str, passage: str) -> str:
        """Run LLM-based NLI. Returns 'SUPPORTS', 'CONTRADICTS', or 'INSUFFICIENT'."""
        try:
            prompt = _NLI_PROMPT.format(
                claim=claim[:500],
                passage=passage[:1200],
            )
            response = self._llm_client.chat(
                model=self._nli_model,
                system="You are a citation verification system. Respond with exactly one word.",
                user=prompt,
                max_tokens=10,
                temperature=0.0,
            )
            result = response.strip().upper()
            if "SUPPORT" in result:
                return "SUPPORTS"
            elif "CONTRADICT" in result:
                return "CONTRADICTS"
            else:
                return "INSUFFICIENT"
        except Exception as e:
            logger.warning("NLI check failed: %s", e)
            return "INSUFFICIENT"

    # ------------------------------------------------------------------
    # CHECK 5: Numerical Consistency
    # ------------------------------------------------------------------

    _NUMBER_PAT_STR = (
        r"\$[\d,]+(?:\.\d+)?|"  # $1,234.56
        r"\d+\.\d+%|"            # 95.5%
        r"\d+%|"                    # 95%
        r"\d{1,3}(?:,\d{3})+|"   # 1,234,567
        r"\d+\.\d+|"            # 12.5
        r"\b\d{2,}\b"           # 2+ digit integers
    )

    def _check_numerical(self, claim: str, passage_text: str) -> CheckResult:
        """Verify numbers in claim appear in passage."""
        import re as _re
        pat = _re.compile(self._NUMBER_PAT_STR, _re.IGNORECASE)

        claim_numbers = self._extract_numbers(claim, pat)
        if not claim_numbers:
            return CheckResult(
                check_name="numerical",
                status=CheckStatus.SKIP,
                detail="No numbers in claim to verify",
            )

        passage_numbers = self._extract_numbers(passage_text, pat)
        if not passage_numbers:
            return CheckResult(
                check_name="numerical",
                status=CheckStatus.WARN,
                detail=f"Claim has {len(claim_numbers)} number(s) but passage has none",
                confidence_impact=-0.15,
            )

        matched = claim_numbers & passage_numbers
        match_rate = len(matched) / len(claim_numbers) if claim_numbers else 0

        if match_rate >= 0.8:
            return CheckResult(
                check_name="numerical",
                status=CheckStatus.PASS,
                detail=f"{len(matched)}/{len(claim_numbers)} claim numbers in passage",
            )
        elif match_rate >= 0.5:
            missing = sorted(claim_numbers - passage_numbers)[:3]
            return CheckResult(
                check_name="numerical",
                status=CheckStatus.WARN,
                detail=f"{len(matched)}/{len(claim_numbers)} matched; missing: {missing}",
                confidence_impact=-0.15,
            )
        else:
            missing = sorted(claim_numbers - passage_numbers)[:3]
            return CheckResult(
                check_name="numerical",
                status=CheckStatus.FAIL,
                detail=f"Only {len(matched)}/{len(claim_numbers)} numbers found; missing: {missing}",
                confidence_impact=-0.3,
            )

    # ------------------------------------------------------------------
    # CHECK 6: Temporal Consistency
    # ------------------------------------------------------------------

    def _check_temporal(self, claim: str, passage_text: str, effective_date: str) -> CheckResult:
        """Verify dates in claim are consistent with passage."""
        import re as _re

        claim_dates = self._extract_dates(claim, _re)
        if not claim_dates:
            return CheckResult(
                check_name="temporal",
                status=CheckStatus.SKIP,
                detail="No dates in claim to verify",
            )

        passage_dates = self._extract_dates(passage_text, _re)
        if effective_date:
            passage_dates |= self._extract_dates(effective_date, _re)

        if not passage_dates:
            return CheckResult(
                check_name="temporal",
                status=CheckStatus.WARN,
                detail=f"Claim has {len(claim_dates)} date(s) but passage/metadata has none",
                confidence_impact=-0.1,
            )

        matched = claim_dates & passage_dates
        if matched:
            return CheckResult(
                check_name="temporal",
                status=CheckStatus.PASS,
                detail=f"{len(matched)}/{len(claim_dates)} claim dates found in passage",
            )

        # Year-level fallback
        claim_years = {d for d in claim_dates if len(d) == 4 and d.isdigit()}
        passage_years = {d for d in passage_dates if len(d) == 4 and d.isdigit()}
        year_match = claim_years & passage_years
        if year_match:
            return CheckResult(
                check_name="temporal",
                status=CheckStatus.PASS,
                detail=f"Year-level match: {sorted(year_match)[:3]}",
            )

        return CheckResult(
            check_name="temporal",
            status=CheckStatus.WARN,
            detail=f"No date overlap: claim={sorted(claim_dates)[:3]} vs passage={sorted(passage_dates)[:3]}",
            confidence_impact=-0.15,
        )

    # ------------------------------------------------------------------
    # UTILITIES
    # ------------------------------------------------------------------

    @staticmethod
    def _keyword_overlap(text_a: str, text_b: str, min_word_len: int = 4) -> float:
        """Fraction of significant words in text_a that appear in text_b."""
        import re as _re
        if not text_a or not text_b:
            return 0.0
        words_a = {w.lower() for w in _re.findall(r"\b\w+\b", text_a) if len(w) >= min_word_len}
        words_b = {w.lower() for w in _re.findall(r"\b\w+\b", text_b) if len(w) >= min_word_len}
        if not words_a:
            return 1.0
        return len(words_a & words_b) / len(words_a)

    @staticmethod
    def _extract_numbers(text: str, pat) -> set[str]:
        """Extract normalized numbers from text."""
        if not text:
            return set()
        raw = pat.findall(text)
        normalized = set()
        for n in raw:
            clean = n.replace("$", "").replace(",", "").strip()
            if clean:
                normalized.add(clean)
        return normalized

    @staticmethod
    def _extract_dates(text: str, re_module) -> set[str]:
        """Extract date strings from text."""
        if not text:
            return set()
        patterns = [
            re_module.compile(
                r"\b(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|"
                r"Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|"
                r"Nov(?:ember)?|Dec(?:ember)?)\s+\d{1,2},?\s*\d{4}\b", re_module.I),
            re_module.compile(r"\b\d{1,2}/\d{1,2}/\d{2,4}\b"),
            re_module.compile(r"\b\d{4}-\d{2}-\d{2}\b"),
            re_module.compile(r"\b\d{4}\b"),
        ]
        dates = set()
        for p in patterns:
            for m in p.finditer(text):
                dates.add(m.group(0).lower().strip())
        return dates


# ============================================================
# UTILITY
# ============================================================


def _get(obj: Any, attr: str, default: Any = None) -> Any:
    """Get attribute from dataclass or key from dict."""
    if isinstance(obj, dict):
        return obj.get(attr, default)
    return getattr(obj, attr, default)
