"""platform/v4/services/verification/citation_verifier.py

P3-VER-1: Native citation verification service.

Verifies that citations (passage-level evidence) properly support the
claims made in agent answers. Replaces the dependency on V2's
platform/07_citation_verification.py by implementing four checks natively:

  1. Supersession — is the cited document still current (not superseded)?
  2. Grounding   — does the passage text actually support the claim?
  3. Numerical   — do numbers quoted in the claim appear in the passage?
  4. Temporal    — are dates/periods consistent between claim and source?

Each check returns a per-citation verdict with confidence and detail.
The aggregate result determines whether citations are trustworthy enough
to present to the user.

Zero Spark dependency — importable without a running cluster.

Usage
-----
    from platform.v4.services.verification.citation_verifier import CitationVerifier

    verifier = CitationVerifier()
    result = verifier.verify(
        claim="Sutter's offset clause starts on Jan 1, 2024 with a cap of $50,000",
        citations=[citation1, citation2],
    )
    if result.has_failures:
        print(f"Citation issues: {result.failure_summary}")
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Sequence

logger = logging.getLogger(__name__)


# ============================================================
# TYPES
# ============================================================


class CheckStatus(str, Enum):
    """Individual check outcome."""
    PASS = "PASS"
    WARN = "WARN"
    FAIL = "FAIL"
    SKIP = "SKIP"  # check not applicable


@dataclass(frozen=True)
class CheckResult:
    """Result of a single verification check on one citation."""
    check_name: str
    status: CheckStatus
    detail: str
    confidence_impact: float = 0.0  # -1.0 to 0.0 (penalty applied to citation confidence)


@dataclass
class CitationVerdict:
    """Aggregate verdict for a single citation."""
    citation_index: int
    source_filename: str
    checks: list[CheckResult] = field(default_factory=list)

    @property
    def passed(self) -> bool:
        return not any(c.status == CheckStatus.FAIL for c in self.checks)

    @property
    def has_warnings(self) -> bool:
        return any(c.status == CheckStatus.WARN for c in self.checks)

    @property
    def confidence_penalty(self) -> float:
        """Total confidence penalty from all checks (0.0 = no penalty)."""
        return sum(c.confidence_impact for c in self.checks)

    @property
    def adjusted_confidence(self, base: float = 1.0) -> float:
        return max(0.0, base + self.confidence_penalty)

    @property
    def failure_reasons(self) -> list[str]:
        return [c.detail for c in self.checks if c.status == CheckStatus.FAIL]

    @property
    def warning_reasons(self) -> list[str]:
        return [c.detail for c in self.checks if c.status == CheckStatus.WARN]


@dataclass
class VerificationResult:
    """Aggregate result across all citations for a claim."""
    claim: str
    verdicts: list[CitationVerdict] = field(default_factory=list)

    @property
    def n_citations(self) -> int:
        return len(self.verdicts)

    @property
    def n_passed(self) -> int:
        return sum(1 for v in self.verdicts if v.passed)

    @property
    def n_failed(self) -> int:
        return sum(1 for v in self.verdicts if not v.passed)

    @property
    def has_failures(self) -> bool:
        return self.n_failed > 0

    @property
    def all_passed(self) -> bool:
        return self.n_failed == 0

    @property
    def pass_rate(self) -> float:
        if not self.verdicts:
            return 0.0
        return self.n_passed / self.n_citations

    @property
    def failure_summary(self) -> str:
        """One-line summary of all failures."""
        reasons = []
        for v in self.verdicts:
            for r in v.failure_reasons:
                reasons.append(f"[{v.source_filename}] {r}")
        return "; ".join(reasons[:5])

    @property
    def overall_confidence(self) -> float:
        """Average adjusted confidence across all citations."""
        if not self.verdicts:
            return 0.0
        return sum(v.adjusted_confidence for v in self.verdicts) / self.n_citations


# ============================================================
# VERIFICATION CHECKS
# ============================================================


# --- Regex patterns for number extraction ---
_NUMBER_PAT = re.compile(
    r"\$[\d,]+(?:\.\d+)?|"     # $1,234.56
    r"\d+\.\d+%|"               # 95.5%
    r"\d+%|"                      # 95%
    r"\d{1,3}(?:,\d{3})+|"      # 1,234,567
    r"\d+\.\d+|"               # 12.5
    r"\b\d{2,}\b"              # 2+ digit integers (skip single digits as noise)
, re.IGNORECASE)

# --- Regex patterns for date extraction ---
_DATE_PATTERNS = [
    re.compile(r"\b(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|"
               r"Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|"
               r"Nov(?:ember)?|Dec(?:ember)?)\s+\d{1,2},?\s*\d{4}\b", re.I),
    re.compile(r"\b\d{1,2}/\d{1,2}/\d{2,4}\b"),
    re.compile(r"\b\d{4}-\d{2}-\d{2}\b"),
    re.compile(r"\b\d{4}\b"),  # standalone 4-digit year
]

_SUPERSEDED_DOC_ROLES = {"superseded", "replaced", "prior_version"}


def _extract_numbers(text: str) -> set[str]:
    """Extract normalized number strings from text."""
    if not text:
        return set()
    raw = _NUMBER_PAT.findall(text)
    # Normalize: strip $, commas, leading zeros
    normalized = set()
    for n in raw:
        clean = n.replace("$", "").replace(",", "").strip()
        if clean:
            normalized.add(clean)
    return normalized


def _extract_dates(text: str) -> set[str]:
    """Extract date strings from text (normalized to lowercase)."""
    if not text:
        return set()
    dates = set()
    for pat in _DATE_PATTERNS:
        for m in pat.finditer(text):
            dates.add(m.group(0).lower().strip())
    return dates


def _keyword_overlap(text_a: str, text_b: str, min_word_len: int = 4) -> float:
    """Fraction of significant words in text_a that appear in text_b."""
    if not text_a or not text_b:
        return 0.0
    words_a = {w.lower() for w in re.findall(r"\b\w+\b", text_a)
               if len(w) >= min_word_len}
    words_b = {w.lower() for w in re.findall(r"\b\w+\b", text_b)
               if len(w) >= min_word_len}
    if not words_a:
        return 1.0  # nothing to check
    overlap = words_a & words_b
    return len(overlap) / len(words_a)


# ============================================================
# VERIFIER CLASS
# ============================================================


class CitationVerifier:
    """Native citation verification service.

    Performs four checks on each citation:
      1. Supersession: flag if document is marked superseded/not-current
      2. Grounding: verify claim keywords appear in passage text
      3. Numerical: verify numbers in claim appear in passage
      4. Temporal: verify dates in claim are consistent with passage

    Configuration
    -------------
    grounding_threshold : float
        Minimum keyword overlap (claim → passage) to pass grounding check.
        Default 0.25 (at least 25% of claim's significant words in passage).
    strict_numerical : bool
        If True, missing numbers are FAIL. If False, they are WARN.
        Default False.
    """

    def __init__(
        self,
        grounding_threshold: float = 0.25,
        strict_numerical: bool = False,
    ):
        self.grounding_threshold = grounding_threshold
        self.strict_numerical = strict_numerical

    def verify(
        self,
        claim: str,
        citations: Sequence[Any],
    ) -> VerificationResult:
        """Verify all citations against a claim.

        Parameters
        ----------
        claim : str
            The answer text or specific claim being made.
        citations : sequence
            Citation objects (dataclass with passage_text, source_filename,
            is_current_effective, doc_role, effective_date fields) or dicts
            with those keys.

        Returns
        -------
        VerificationResult with per-citation verdicts.
        """
        verdicts = []
        for idx, cit in enumerate(citations):
            verdict = self._verify_single(claim, cit, idx)
            verdicts.append(verdict)
        return VerificationResult(claim=claim[:500], verdicts=verdicts)

    def verify_single(
        self,
        claim: str,
        citation: Any,
    ) -> CitationVerdict:
        """Verify a single citation against a claim."""
        return self._verify_single(claim, citation, 0)

    def _verify_single(self, claim: str, citation: Any, index: int) -> CitationVerdict:
        """Run all checks on a single citation."""
        # Normalize citation access (support both dataclass and dict)
        passage_text = _get(citation, "passage_text", "")
        source_filename = _get(citation, "source_filename", "")
        is_current = _get(citation, "is_current_effective", True)
        doc_role = _get(citation, "doc_role", "")
        effective_date = _get(citation, "effective_date", "")

        checks: list[CheckResult] = []

        # --- Check 1: Supersession ---
        checks.append(self._check_supersession(is_current, doc_role))

        # --- Check 2: Grounding ---
        checks.append(self._check_grounding(claim, passage_text))

        # --- Check 3: Numerical ---
        checks.append(self._check_numerical(claim, passage_text))

        # --- Check 4: Temporal ---
        checks.append(self._check_temporal(claim, passage_text, effective_date))

        return CitationVerdict(
            citation_index=index,
            source_filename=source_filename,
            checks=checks,
        )

    # ------------------------------------------------------------------
    # Individual checks
    # ------------------------------------------------------------------

    def _check_supersession(self, is_current: bool, doc_role: str) -> CheckResult:
        """Check 1: Is the cited document still current?"""
        if not is_current:
            return CheckResult(
                check_name="supersession",
                status=CheckStatus.WARN,
                detail="Citation from non-current document (expired or superseded)",
                confidence_impact=-0.3,
            )
        if doc_role and doc_role.lower() in _SUPERSEDED_DOC_ROLES:
            return CheckResult(
                check_name="supersession",
                status=CheckStatus.WARN,
                detail=f"Document role is '{doc_role}' (likely superseded)",
                confidence_impact=-0.2,
            )
        return CheckResult(
            check_name="supersession",
            status=CheckStatus.PASS,
            detail="Document is current",
        )

    def _check_grounding(self, claim: str, passage_text: str) -> CheckResult:
        """Check 2: Does the passage text support the claim?"""
        if not passage_text or len(passage_text.strip()) < 20:
            return CheckResult(
                check_name="grounding",
                status=CheckStatus.FAIL,
                detail="Passage text is empty or trivially short",
                confidence_impact=-0.5,
            )
        if not claim or len(claim.strip()) < 10:
            return CheckResult(
                check_name="grounding",
                status=CheckStatus.SKIP,
                detail="Claim too short to verify grounding",
            )

        overlap = _keyword_overlap(claim, passage_text)
        if overlap >= self.grounding_threshold:
            return CheckResult(
                check_name="grounding",
                status=CheckStatus.PASS,
                detail=f"Keyword overlap {overlap:.0%} >= threshold {self.grounding_threshold:.0%}",
            )
        elif overlap >= self.grounding_threshold * 0.5:
            return CheckResult(
                check_name="grounding",
                status=CheckStatus.WARN,
                detail=f"Weak grounding: overlap {overlap:.0%} (threshold {self.grounding_threshold:.0%})",
                confidence_impact=-0.2,
            )
        else:
            return CheckResult(
                check_name="grounding",
                status=CheckStatus.FAIL,
                detail=f"Passage does not support claim: overlap {overlap:.0%} < {self.grounding_threshold:.0%}",
                confidence_impact=-0.5,
            )

    def _check_numerical(self, claim: str, passage_text: str) -> CheckResult:
        """Check 3: Do numbers in the claim appear in the passage?"""
        claim_numbers = _extract_numbers(claim)
        if not claim_numbers:
            return CheckResult(
                check_name="numerical",
                status=CheckStatus.SKIP,
                detail="No numbers in claim to verify",
            )

        passage_numbers = _extract_numbers(passage_text)
        if not passage_numbers:
            status = CheckStatus.FAIL if self.strict_numerical else CheckStatus.WARN
            return CheckResult(
                check_name="numerical",
                status=status,
                detail=f"Claim has {len(claim_numbers)} number(s) but passage has none",
                confidence_impact=-0.3 if status == CheckStatus.FAIL else -0.15,
            )

        # Check: what fraction of claim numbers appear in passage
        matched = claim_numbers & passage_numbers
        match_rate = len(matched) / len(claim_numbers)

        if match_rate >= 0.8:
            return CheckResult(
                check_name="numerical",
                status=CheckStatus.PASS,
                detail=f"{len(matched)}/{len(claim_numbers)} claim numbers found in passage",
            )
        elif match_rate >= 0.5:
            missing = claim_numbers - passage_numbers
            return CheckResult(
                check_name="numerical",
                status=CheckStatus.WARN,
                detail=f"{len(matched)}/{len(claim_numbers)} matched; missing: {sorted(missing)[:3]}",
                confidence_impact=-0.15,
            )
        else:
            missing = claim_numbers - passage_numbers
            status = CheckStatus.FAIL if self.strict_numerical else CheckStatus.WARN
            return CheckResult(
                check_name="numerical",
                status=status,
                detail=f"Only {len(matched)}/{len(claim_numbers)} numbers found; missing: {sorted(missing)[:3]}",
                confidence_impact=-0.3 if status == CheckStatus.FAIL else -0.2,
            )

    def _check_temporal(self, claim: str, passage_text: str, effective_date: str) -> CheckResult:
        """Check 4: Are dates/temporal references consistent?"""
        claim_dates = _extract_dates(claim)
        if not claim_dates:
            return CheckResult(
                check_name="temporal",
                status=CheckStatus.SKIP,
                detail="No dates in claim to verify",
            )

        passage_dates = _extract_dates(passage_text)
        # Also consider the document's effective_date
        if effective_date:
            passage_dates |= _extract_dates(effective_date)

        if not passage_dates:
            return CheckResult(
                check_name="temporal",
                status=CheckStatus.WARN,
                detail=f"Claim has {len(claim_dates)} date(s) but passage/metadata has none",
                confidence_impact=-0.1,
            )

        # Check overlap (at least one claim date matches passage)
        matched = claim_dates & passage_dates
        if matched:
            return CheckResult(
                check_name="temporal",
                status=CheckStatus.PASS,
                detail=f"{len(matched)}/{len(claim_dates)} claim dates found in passage/metadata",
            )
        else:
            # Try partial matching (year-level)
            claim_years = {d for d in claim_dates if re.fullmatch(r"\d{4}", d)}
            passage_years = {d for d in passage_dates if re.fullmatch(r"\d{4}", d)}
            year_match = claim_years & passage_years
            if year_match:
                return CheckResult(
                    check_name="temporal",
                    status=CheckStatus.PASS,
                    detail=f"Year-level match: {sorted(year_match)[:3]}",
                )
            return CheckResult(
                check_name="temporal",
                status=CheckStatus.WARN,
                detail=f"No date overlap between claim and passage ({sorted(claim_dates)[:3]} vs {sorted(passage_dates)[:3]})",
                confidence_impact=-0.15,
            )


# ============================================================
# UTILITIES
# ============================================================


def _get(obj: Any, attr: str, default: Any = None) -> Any:
    """Get attribute from dataclass or key from dict."""
    if isinstance(obj, dict):
        return obj.get(attr, default)
    return getattr(obj, attr, default)
