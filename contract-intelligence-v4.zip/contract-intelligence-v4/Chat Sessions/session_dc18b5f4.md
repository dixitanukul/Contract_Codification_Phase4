# Contract Intelligence — Session Export

**Session:** dc18b5f4-44ff-496d-bf31-9562d0c82fca  
**Exported:** 2026-07-21 05:58 UTC  
**Messages:** 6

---

## Q1 (05:55)

what all questions we can ask you


### Answer (confidence: MODERATE)

## What Can You Ask Me?

Im the **Contract Intelligence V4 Agent** for Blue Shield of California (BSC) provider contracts. Heres a comprehensive guide to the types of questions I can answer:

---

### 📋 Contract & Clause Questions
- *"Does [Provider] have an offset clause?"*
- *"Show me the termination provisions for [Provider]."*
- *"Which providers have an auto-renewal clause?"*
- *"What does the dispute resolution clause say for [Provider]?"*
- *"Which providers have indemnification language?"*
- *"Compare the confidentiality clauses between [Provider A] and [Provider B]."*

**Supported clause types:** Offset, Termination, Auto-Renewal, Dispute Resolution, UM/Prior Auth, Grievance & Appeals, Records Retention, HIPAA/Confidentiality, Emergency Care, COB, Assignment Prohibition, Insurance Requirements, Quality Reporting, Audit Rights, Language Access, Indemnification, Continuity of Care, Claim Submission, Credentialing, Telehealth, Network Adequacy.

---

### 💰 Rates & Financial Questions
- *"What are the current rates for [Provider]?"*
- *"Show me the per diem rates for [Provider]."*
- *"What is the average case rate across the portfolio?"*
- *"Which providers have the highest inpatient case rates?"*
- *"What would happen to costs if we changed [Provider]s rates by 5%?"*
- *"Show me the rate escalator terms for [Provider]."*
- *"What is the contracted spend exposure for [Provider]?"*

---

### 📊 DOFR (Division of Financial Responsibility)
- *"Does [Provider] have a DOFR clause?"*
- *"Show me the DOFR matrix for [Provider]."*
- *"Which services is the IPA/Group responsible for under [Provider]s contract?"*
- *"How many providers have a DOFR clause?"*
- *"Who is responsible for behavioral health services across the network?"*
- *"Show me the DOFR matrix for any IPA provider."*

---

### 🏥 Provider Profile & Network Questions
- *"Is [Provider] active in the BSC network?"*
- *"What line of business does [Provider] cover (Commercial, Medicare, Medi-Cal)?"*
- *"Whic


---

## Q2 (05:56)

Show me the termination provisions for any one provider


### Answer (confidence: HIGH)

## Termination Provisions — Mercy General Hospital

*Using **Mercy General Hospital** as an example (most amendments in the BSC contracted network — 97 total).*

---

### Section 12.1 — Term & Termination Mechanics

> *"This Agreement shall become effective as of January 1, 2023 and shall continue in effect through July 31st, 2026, thereafter (the Renewal Term), unless earlier terminated as set forth in this Agreement. Unless either party notifies [the other party of its intent not to renew]..."*

**Key provisions extracted:**

| Element | Detail |
|---|---|
| **Effective Date** | January 1, 2023 |
| **Initial Term End** | July 31, 2026 |
| **Renewal Term** | Automatic renewal for successive one (1) year terms after July 31, 2026 |
| **Auto-Renewal Trigger** | Unless either party provides notice of intent not to renew |
| **Termination Basis** | Earlier termination permitted as set forth in the Agreement |

---

### Auto-Renewal Clause (Related)

The contract also contains an explicit auto-renewal provision (from Amendment effective August 1, 2022):

> *"When executed by both parties, this Amendment shall be effective as of August 1, 2022 through July 31, 2026 (Renewal Term). Thereafter, this Amendment will automatically renew for successive one (1) year terms, unless and until terminated or modified in accordance with [the Agreement]."*

---

**Source:** Mercy General Hospital — Base FFS Hospital Agreement, Amendment XIV (current version)

> 💡 **Want more?** I can show termination provisions for a specific provider, compare termination notice periods across multiple providers, or retrieve the full termination clause text including for-cause and without-cause termination rights. Just ask!


---

## Q3 (05:58)

retrieve the full termination clause text including for-cause and without-cause termination rights of the above provider


### Answer (confidence: LOW)

| Provider | Clause Category | Clause Subcategory | Clause Status | Clause Text | Is Current | Amendment # | Document | Extraction Method |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sharp Memorial Hospital | TERMINATION_PROVISIONS | Termination Mechanics | Yes | terminated as set forth in this Agreement.

2. Section 6.2 of the Agreement is hereby deleted and replaced in its entirety to read in full as follows:

6.2 Termination Without Cause. During the Renewal Term, neither party may terminate this Agreement without cause. Thereafter, either party may terminate this Agreement without cause by giving to the other party at least one hundred twenty (120) days’ prior written notice of termination. Any termination pursuant to this Section 6.2 shall become effective the first day of the calendar month following the

Sharp Healthcare - Hosp Services Agreement for Medi-Cal_Amend 10 10-01-24 (v7)_Clean 8-1-24
Base 12-22-20
Proprietary and Confidential – Blue Shield of California Promise Health Plan

2

DocuSign Envelope ID: AEC77449-1A87-4EDC-A305-19F3816B | Yes | 10 | 320973542_Sharp_Memorial_Hospital_449244177_TenthAmend_v1.pdf | PATTERN_MATCH |
| Sierra Nevada Memorial Hospital | TERMINATION_PROVISIONS | Termination Mechanics | Yes | spitals Charge Master "Modification Allowance" is specified in the table 
below: 
MODIFICATION ALLOWANCE EFFECTIVE  10/1/2022 
Charge Master Limit 0%

4. Section 10.1 of the Agreement is hereby deleted and replaced in its entirety to read in full 
as follows: 
10.1 Term.  This Agreement shall become effective as of August 1, 2022 and shall 
continue in effect until July 31, 2026, thereafter (the “Renewal Term”) unless 
earlier terminated as set forth in this Agreement. Unless either party notifies the 
other party at least one hundred eighty (180) days prior to the expiration of the 
Renewal Term, this Agreement shall automatically renew for additional terms of 
one (1) year each, unless and until terminated as set forth in t


---
