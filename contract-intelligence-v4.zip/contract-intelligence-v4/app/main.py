"""
Contract Intelligence Platform V4 — FastAPI Application

Phase 4 complete. All endpoints fully implemented:
  /health, /api/v1/query (streaming + non-streaming), /api/v1/sessions,
  /api/v1/feedback, /api/v1/providers, /api/v1/report, /api/v1/concepts,
  /api/v1/export, /api/v1/documents, /api/v1/status/metrics
Static React frontend served from app/static/.
"""
from __future__ import annotations

# ── CRITICAL: Fix platform package shadowing ──────────────────────────────────
# In the Databricks App container, stdlib 'platform' (a .py file) gets cached in
# sys.modules before our custom 'platform/' package directory is found. We fix
# this by: (1) ensuring project root is first on sys.path, (2) evicting the
# stdlib module from cache. Later, when _lifespan_init does
# `from platform.v4...`, Python will find our package directory.
import sys as _sys
import os as _os
import uuid

_APP_ROOT = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))

# Ensure project root is FIRST on sys.path
if _APP_ROOT in _sys.path:
    _sys.path.remove(_APP_ROOT)
_sys.path.insert(0, _APP_ROOT)

# Evict stdlib platform if already cached (uvicorn/requests import it early)
if "platform" in _sys.modules:
    _cached = _sys.modules["platform"]
    # stdlib platform is a module (file), not a package (directory)
    if not hasattr(_cached, "__path__"):
        del _sys.modules["platform"]
        for _k in list(_sys.modules.keys()):
            if _k.startswith("platform."):
                del _sys.modules[_k]
# PRE-WARM: import platform.v4 package eagerly so the background lifespan task
# never races against a cold import cache (fixes 'No module named platform.v4.tools.clause_existence'
# timing error when TestClient starts the background init before sys.modules is warm).
try:
    import platform as _plat_pkg  # noqa: F401  (our package, not stdlib)
    import platform.v4.tools.clause_existence  # noqa: F401
except Exception as _pre_warm_exc:
    logger.warning("platform.v4 pre-warm import failed (non-fatal): %s", _pre_warm_exc)
# ── End platform fix ──────────────────────────────────────────────────────────

import asyncio
import concurrent.futures
import json
import logging
import os
import re
import time
from contextlib import asynccontextmanager
from typing import AsyncIterator, Optional

from pathlib import Path

from fastapi import Depends, FastAPI, HTTPException, Query, Request, Response, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles


# ── NaN-safe JSON serialisation (prevents ValueError on float NaN in responses) ──
import json as _stdlib_json
import math as _math

class NaNSafeJSONResponse(JSONResponse):
    """JSONResponse that silently converts float NaN/Inf to null before serialising.
    
    Databricks (and strict JSON parsers) reject IEEE 754 NaN/Infinity.  Any pandas
    NULL numeric column that survives a .toPandas().to_dict() call becomes float NaN
    in Python; this class catches those values globally without requiring callers to
    sanitise every dict.
    """

    @staticmethod
    def _sanitize(obj):
        if isinstance(obj, float) and not _math.isfinite(obj):
            return None
        if isinstance(obj, dict):
            return {k: NaNSafeJSONResponse._sanitize(v) for k, v in obj.items()}
        if isinstance(obj, list):
            return [NaNSafeJSONResponse._sanitize(v) for v in obj]
        return obj

    def render(self, content) -> bytes:
        return _stdlib_json.dumps(
            NaNSafeJSONResponse._sanitize(content),
            ensure_ascii=False,
            allow_nan=False,
        ).encode("utf-8")

from pydantic import BaseModel, Field

# ── Rate limiting (P0 security fix) ──────────────────────────────────────────
try:
    from slowapi import Limiter, _rate_limit_exceeded_handler
    from slowapi.util import get_remote_address
    from slowapi.errors import RateLimitExceeded
    _limiter = Limiter(key_func=get_remote_address, default_limits=["120/minute"])
    _RATE_LIMITING_AVAILABLE = True
except ImportError:
    _RATE_LIMITING_AVAILABLE = False
    _limiter = None

logger = logging.getLogger(__name__)

# ── PII redaction middleware (Phase 7, Step 7.1 — LLM-001) ───────────────────
# Applied to every chunk BEFORE it is inserted into a Claude prompt.
# This is defense-in-depth: corpus redaction is the permanent fix,
# but this guard protects against any PII that re-enters through new ingestion.

_SSN_RE   = re.compile(r"\b\d{3}-\d{2}-\d{4}\b")
_DOB_RE   = re.compile(r"\b(?:DOB|Date of Birth)[:\s]+\d{1,2}/\d{1,2}/\d{2,4}\b", re.IGNORECASE)
_ADDR_RE  = re.compile(r"\b\d{1,5}\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+){1,3}\s+(?:St|Ave|Blvd|Dr|Rd|Ln|Way|Ct)\b")


def redact_pii(text: str) -> str:
    """Strip SSN, DOB, and street address patterns from a passage before LLM injection."""
    text = _SSN_RE.sub("[SSN REDACTED]", text)
    text = _DOB_RE.sub("[DOB REDACTED]", text)
    text = _ADDR_RE.sub("[ADDRESS REDACTED]", text)
    return text


# ── Input sanitization (P0 security — SQL injection prevention) ───────────────

_SAFE_SEARCH_RE = re.compile(r"[^a-zA-Z0-9 .\-_&'/()]")  # Whitelist: alphanumeric + common name chars


def _sanitize_like_input(value: str, max_len: int = 100) -> str:
    """Sanitize user input for use in SQL LIKE clauses.
    
    1. Truncate to max_len
    2. Strip characters outside the safe whitelist  
    3. Escape SQL LIKE wildcards (% and _)
    4. Escape single quotes
    """
    value = value[:max_len].strip()
    value = _SAFE_SEARCH_RE.sub("", value)
    value = value.replace("'", "''")
    value = value.replace("%", "")
    value = value.replace("_", "\\_")
    return value.lower()


# ── Request / Response models ─────────────────────────────────────────────────

class QueryRequest(BaseModel):
    question: str       = Field(..., description="Natural language question about a provider contract")
    provider_name: str  = Field("", description="Optional provider filter (exact or fuzzy)")
    stream: bool        = Field(True,  description="Stream tokens via SSE if True")
    session_id: str     = Field("",    description="Conversation session ID for multi-turn context")


class QueryResponse(BaseModel):
    answer: str
    confidence: str         = Field("UNKNOWN", description="HIGH / MODERATE / LOW / UNCERTAIN")
    confidence_score: float = Field(0.0, ge=0.0, le=1.0)
    citations: list[dict]   = Field(default_factory=list)
    session_id: str         = ""
    latency_ms: int         = 0
    tool_calls: int         = 0
    cost_usd: float         = 0.0


class HealthResponse(BaseModel):
    status: str
    dependencies: dict[str, str]
    version: str         = "4.0.0-dev"
    uptime_s: int        = 0
    circuit_breakers: list[dict] = []
    error: str           = ""


_CONFIDENCE_SCORES: dict[str, float] = {
    "HIGH": 0.90, "MODERATE": 0.65, "LOW": 0.35, "UNCERTAIN": 0.15,
}


def _parse_confidence(raw: str) -> tuple[str, float]:
    """Normalise AgentResponse.confidence to (label_str, score_float)."""
    label = str(raw).upper().split(".")[-1]
    return label, _CONFIDENCE_SCORES.get(label, 0.5)


# ── Lifespan (startup / shutdown) ─────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    """Initialise platform/v4 runtime on startup. Fail-open: app serves frontend even if runtime fails."""
    logger.info("Contract Intelligence V4 starting up...")
    app.state.start_time = time.time()
    app.state.runtime = None
    app.state.startup_error = None
    app.state.startup_detail = None
    app.state.runtime_ready = False

    # Defer heavy init (Spark Connect, VS, LLM) to a background task.
    # This ensures FastAPI reaches yield IMMEDIATELY and starts serving
    # the frontend + health endpoint while runtime boots in the background.
    async def _background_init():
        try:
            await asyncio.wait_for(
                asyncio.to_thread(_lifespan_init, app),
                timeout=300.0,
            )
            app.state.runtime_ready = True
            logger.info("Background runtime init completed successfully.")
        except asyncio.TimeoutError:
            logger.error("LIFESPAN INIT TIMED OUT after 180s.")
            app.state.startup_error = "Runtime init timed out after 300s (SQL-only mode — chat unavailable)"
        except Exception as exc:
            import traceback
            tb = traceback.format_exc()
            logger.error("LIFESPAN INIT FAILED: %s\n%s", exc, tb)
            app.state.startup_error = str(exc)
            app.state.startup_detail = tb

    init_task = asyncio.create_task(_background_init())
    yield
    if not init_task.done():
        init_task.cancel()
    logger.info("Contract Intelligence V4 shutting down.")


def _lifespan_init(app: FastAPI):
    """
    Full startup: SQL (WarehouseSpark) + LLM (REST) + Vector Search (REST).
    Replicates init_runtime_api() logic but uses WarehouseSpark instead of
    DatabricksSession, so the full NotebookRuntime (with ask/stream_ask) works.
    """

    # Circuit breakers (Phase 3, Step 3.4)
    try:
        from app.middleware.circuit_breaker import make_sql_breaker, make_vs_breaker, make_llm_breaker
        app.state.sql_breaker = make_sql_breaker()
        app.state.vs_breaker  = make_vs_breaker()
        app.state.llm_breaker = make_llm_breaker()
        logger.info("Circuit breakers initialized.")
    except Exception as exc:
        logger.warning("Circuit breakers unavailable: %s", exc)

    # ── Step 1: SQL via Statement Execution API ──
    try:
        from app.sql_client import WarehouseSpark
        spark = WarehouseSpark()
        app.state.spark = spark
        app.state.sql_only = True
        logger.info("WarehouseSpark SQL client initialized.")
        # C5: SQL warehouse startup probe — ensures warehouse is RUNNING before continuing
        for _probe_attempt in range(4):
            try:
                spark.sql("SELECT 1 AS probe").collect()
                logger.info("SQL warehouse probe: PASS (attempt %d)", _probe_attempt + 1)
                break
            except Exception as _sql_probe_exc:
                if _probe_attempt < 3:
                    logger.warning(
                        "SQL warehouse not ready (attempt %d/4, retrying in 30s): %s",
                        _probe_attempt + 1, _sql_probe_exc,
                    )
                    time.sleep(30)
                else:
                    logger.error(
                        "SQL warehouse did not respond after 4 probe attempts: %s",
                        _sql_probe_exc,
                    )
                    app.state.startup_error = f"SQL warehouse unavailable: {_sql_probe_exc}"
                    return
    except Exception as exc:
        logger.error("WarehouseSpark init failed: %s", exc, exc_info=True)
        app.state.startup_error = f"SQL client init failed: {exc}"
        return  # Can't proceed without SQL

    # ── Fix 'platform' module resolution (BUG-1C fix) ──────────────────────────
    # Load the real platform/__init__.py (not a types.ModuleType stub).
    # This ensures _V3Finder is installed (for platform.v3.* → platform.v4.* redirect)
    # and stdlib symbols (python_implementation, etc.) are properly re-exported.
    import sys as _s, os as _o, importlib.util as _ilu
    _root = _o.path.dirname(_o.path.dirname(_o.path.abspath(__file__)))
    _pkg_dir = _o.path.join(_root, "platform")
    _pkg_init = _o.path.join(_pkg_dir, "__init__.py")
    # Ensure project root is first on sys.path
    if _root not in _s.path:
        _s.path.insert(0, _root)
    elif _s.path[0] != _root:
        _s.path.remove(_root)
        _s.path.insert(0, _root)
    _existing = _s.modules.get("platform")
    if _existing is None or not hasattr(_existing, "__path__"):
        # Stdlib platform is a .py file (no __path__). Replace with real package.
        # Evict stdlib platform and any stale platform.* submodules.
        for _k in list(_s.modules.keys()):
            if _k == "platform" or _k.startswith("platform."):
                del _s.modules[_k]
        # Load the real platform/__init__.py — installs _V3Finder and re-exports stdlib
        if _o.path.isfile(_pkg_init):
            _spec = _ilu.spec_from_file_location(
                "platform", _pkg_init,
                submodule_search_locations=[_pkg_dir],
            )
            _our_platform = _ilu.module_from_spec(_spec)
            _spec.loader.exec_module(_our_platform)
            _s.modules["platform"] = _our_platform
            logger.info(
                "platform package loaded from disk: %s (python_implementation=%s)",
                _pkg_init,
                getattr(_our_platform, "python_implementation", lambda: "N/A")(),
            )
        else:
            logger.error("platform/__init__.py not found at %s — imports will fail", _pkg_init)
    else:
        logger.info("platform package already registered: %s", getattr(_existing, "__file__", "?"))

    # C7b: Post-init validation — fail fast if platform.v4 core is still broken
    try:
        from platform.v4.core.agent_controller import AgentController  # noqa: F401
        logger.info("platform.v4 import validation: PASS")
    except ImportError as _plat_validate_exc:
        logger.error(
            "platform.v4 import FAILED after module fix — runtime init will fail: %s",
            _plat_validate_exc,
        )
        app.state.startup_error = f"platform.v4 package broken: {_plat_validate_exc}"
        return

    # ── Step 2: LLM client (SDK-native, OAuth-compatible) ──
    llm_client = None
    try:
        from platform.v4.runtime.databricks_llm_client import DatabricksLLMClient
        llm_client = DatabricksLLMClient.from_sdk()
        logger.info("LLM client initialized (SDK auth, token rotation enabled).")
        # C6: LLM endpoint probe — validates model is reachable before serving requests
        try:
            from platform.v4.config.settings import LLM_REASONING as _LLM_MODEL
            llm_client.chat_multi(
                model=_LLM_MODEL,
                messages=[{"role": "user", "content": "ping"}],
                max_tokens=3,
            )
            logger.info("LLM endpoint probe: PASS")
        except Exception as _llm_probe_exc:
            logger.warning(
                "LLM endpoint probe failed (chat may be degraded on first query): %s",
                _llm_probe_exc,
            )
    except Exception as exc:
        logger.warning("LLM client init failed (chat will be unavailable): %s", exc)

    # ── Step 3: Vector Search service — explicit credentials from WorkspaceConfig ──
    # IMPORTANT: In Databricks Apps the JVM notebook auth token is unavailable.
    # AISearchClient() with no args falls back to auto-discovery which may fail.
    # We pass workspace_url + personal_access_token explicitly so the VS SDK
    # uses the app SP's OAuth token (auto-rotated by the Databricks Apps runtime).
    vs_service = None
    try:
        from platform.v4.services.vector_search_service import VectorSearchService
        from platform.v4.config.workspace_config import WorkspaceConfig
        _vs_wc = WorkspaceConfig.from_sdk()
        vs_service = VectorSearchService(
            workspace_url=_vs_wc.workspace_url,
            personal_access_token=_vs_wc.api_token,
        )
        logger.info(
            "Vector Search service initialized (explicit credentials, url=%s, token=...%s).",
            _vs_wc.workspace_url[:40],
            _vs_wc.api_token[-6:] if _vs_wc.api_token else "MISSING",
        )
        # C4: VS endpoint startup probe with retry
        for _vs_attempt in range(3):
            try:
                _vs_probe_results = vs_service.search("provider contract rate", top_k=1)
                logger.info(
                    "VS endpoint probe: PASS (%d results, attempt %d)",
                    len(_vs_probe_results), _vs_attempt + 1,
                )
                break
            except Exception as _vs_probe_exc:
                if _vs_attempt < 2:
                    logger.warning(
                        "VS endpoint probe attempt %d/3 failed (retrying in 30s): %s",
                        _vs_attempt + 1, _vs_probe_exc,
                    )
                    time.sleep(30)
                else:
                    logger.error(
                        "VS endpoint not ready after 3 probe attempts — retrieval will be degraded: %s",
                        _vs_probe_exc,
                    )
                    # VS failure is non-fatal — SQL + LLM still work
                    vs_service = None
    except Exception as exc:
        logger.warning("Vector Search init failed (retrieval degraded): %s", exc)

    # ── Step 4: Build full NotebookRuntime (with ask/stream_ask) ──
    try:
        from platform.v4.runtime.notebook_entry import init_runtime
        from platform.v4.config.settings import Settings
        from platform.v4.core.current_effective_filter import CurrentEffectiveFilter
        from platform.v4.services.retrieval_service import build_retrieval_service
        from platform.v4.data.telemetry_repo import TelemetryRepo
        from platform.v4.core.provenance import ProvenanceResolver
        from platform.v4.services.provider_service import ProviderService

        _settings = Settings()
        current_filter = CurrentEffectiveFilter(spark=spark)
        retrieval_service = build_retrieval_service(
            spark=spark,
            vs_service=vs_service,
            current_filter=current_filter,
        ) if vs_service else None
        telemetry_repo = TelemetryRepo(spark=spark)
        provenance = ProvenanceResolver(spark=spark)
        provider_service = ProviderService(spark=spark)

        # Build GenieClient so GenieQueryTool (GENIE_ENABLED=True) has a live client.
        # Uses SDK auth (same token already used for LLM and VS).
        _genie_client = None
        try:
            from platform.v4.tools.genie_query import GenieClient
            from platform.v4.config.workspace_config import WorkspaceConfig
            _wc = WorkspaceConfig.from_sdk()
            _genie_client = GenieClient(
                workspace_url=_wc.workspace_url,
                api_token=_wc.api_token,
            )
            logger.info("GenieClient initialized (workspace=%s).", _wc.workspace_url[:40])
        except Exception as _g_exc:
            logger.warning("GenieClient init failed (genie_query will be unavailable): %s", _g_exc)

        runtime = init_runtime(
            spark=spark,
            dispatch_fn=None,
            retrieve_fn=None,
            llm_client=llm_client,
            settings=_settings,
            genie_client=_genie_client,
            telemetry_repo=telemetry_repo,
            provenance_resolver=provenance,
            retrieval_service=retrieval_service,
            provider_service=provider_service,
        )
        app.state.runtime = runtime
        app.state.sql_only = False   # full runtime ready — chat is available
        logger.info("Full NotebookRuntime initialized (ask/stream_ask available).")
    except Exception as exc:
        logger.error("Full runtime init failed, falling back to SQL-only: %s", exc, exc_info=True)
        # Fallback already set in step 1 — providers/reports continue working.
        # sql_only remains True — chat endpoint surfaces a clear message.
        app.state.startup_error = f"Full runtime failed (SQL-only mode): {exc}"

    # ── Step 5: Telemetry writer ──
    app.state.telemetry = None
    try:
        from platform.v4.services.telemetry_writer import TelemetryWriter
        from platform.v4.config.settings import Settings as _S2
        _s = _S2()
        app.state.telemetry = TelemetryWriter(spark=spark, table=_s.TBL_APP_QUERY_TELEMETRY)
        logger.info("TelemetryWriter wired.")
    except Exception as exc:
        logger.warning("TelemetryWriter init failed (non-fatal): %s", exc)

    # ── Step 6: Session + Feedback repos ──
    try:
        from platform.v4.data.session_repo import SessionRepo
        _shared_session_repo = SessionRepo(spark=spark)
        app.state.session_repo = _shared_session_repo
        # MT-SHARE-FIX: share the same SessionRepo instance with the runtime so
        # in-memory buffer from fire-and-forget writes is visible to load_session()
        if app.state.runtime is not None and hasattr(app.state.runtime, '_session_repo'):
            app.state.runtime._session_repo = _shared_session_repo
            import logging as _lg
            _lg.getLogger(__name__).info("MT-SHARE-FIX: shared SessionRepo instance with runtime")
        logger.info("SessionRepo initialized.")
    except Exception as exc:
        logger.warning("SessionRepo init failed: %s", exc)
        app.state.session_repo = None

    try:
        from platform.v4.data.feedback_repo import FeedbackRepo
        app.state.feedback_repo = FeedbackRepo(spark=spark)
        logger.info("FeedbackRepo initialized.")
    except Exception as exc:
        logger.warning("FeedbackRepo init failed: %s", exc)
        app.state.feedback_repo = None




# ── App factory ───────────────────────────────────────────────────────────────

def create_app() -> FastAPI:
    app = FastAPI(
        title="Contract Intelligence Platform V4",
        description="Blue Shield of California — Provider Contract Intelligence API",
        version="4.0.0",
        lifespan=lifespan,
        default_response_class=NaNSafeJSONResponse,
    )

    # ── Rate limiting (P0 security) ───────────────────────────────────────────
    if _RATE_LIMITING_AVAILABLE:
        app.state.limiter = _limiter
        app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

    # ── CORS: restrict to deployed app domain + local dev ─────────────────────
    _ALLOWED_ORIGINS = [
        "https://contract-intelligence-640321604414221.1.azure.databricksapps.com",
        "http://localhost:5173",   # Vite dev server
        "http://localhost:8000",   # Local uvicorn
    ]
    app.add_middleware(
        CORSMiddleware,
        allow_origins=_ALLOWED_ORIGINS,
        allow_methods=["GET", "POST", "PATCH", "OPTIONS"],
        allow_headers=["Content-Type", "Authorization", "X-Request-ID"],
        expose_headers=["X-Request-ID"],
        max_age=3600,
    )

    # ── Security headers middleware (P2) ──────────────────────────────────────
    @app.middleware("http")
    async def security_headers(request: Request, call_next):
        response = await call_next(request)
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "SAMEORIGIN"
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
        if request.url.scheme == "https":
            response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
        return response

    # ── Request ID middleware (P2 observability) ──────────────────────────────
    @app.middleware("http")
    async def request_id_middleware(request: Request, call_next):
        import uuid as _uuid
        request_id = request.headers.get("X-Request-ID") or str(_uuid.uuid4())
        request.state.request_id = request_id
        response = await call_next(request)
        response.headers["X-Request-ID"] = request_id
        return response

    return app


app = create_app()


# ── Health endpoint (Step 3.6) ────────────────────────────────────────────────

@app.get("/health", response_model=HealthResponse, tags=["ops"])
async def health(request: Request):
    """
    Dependency health check. Returns overall status + per-dependency state + circuit breakers.
    Reads live circuit breaker states when available.
    """
    deps: dict[str, str] = {}
    cb_list: list[dict] = []
    runtime = getattr(request.app.state, "runtime", None)
    runtime_ready = getattr(request.app.state, "runtime_ready", False)
    startup_error = getattr(request.app.state, "startup_error", None)

    # Surface runtime readiness explicitly so health reflects chat availability.
    if startup_error:
        # If SQL warehouse is still available, it's a partial failure (DEGRADED), not DOWN.
        # DOWN is only for catastrophic SQL failure where no queries can run.
        _spark_ok = getattr(request.app.state, "spark", None) is not None
        _partial_fail = (
            _spark_ok                                      # SQL works → at most DEGRADED
            or "SQL-only mode" in (startup_error or "")    # explicit SQL-only mode
            or "Full runtime failed" in (startup_error or "")  # step-4 partial failure
            or "timed out" in (startup_error or "").lower()    # init timeout (SQL still OK)
        )
        deps["runtime"] = "DEGRADED" if _partial_fail else "DOWN"
    elif runtime is not None and runtime_ready and hasattr(runtime, "ask"):
        deps["runtime"] = "OK"
    else:
        deps["runtime"] = "NOT_INITIALIZED"

    # Check individual circuit breakers set by _lifespan_init
    for name in ["sql", "vs", "llm"]:
        cb = getattr(request.app.state, f"{name}_breaker", None)
        if cb:
            state = cb.state.value if hasattr(cb.state, 'value') else str(cb.state) if hasattr(cb, 'state') else 'UNKNOWN'
            deps[name] = state
            cb_list.append({"name": name, "state": state, "failure_count": getattr(cb, 'failure_count', 0)})
        else:
            deps[name] = "NOT_INITIALIZED"

    # Show WarehouseSpark availability explicitly
    _spark_inst = getattr(request.app.state, "spark", None)
    deps["spark_warehouse"] = "UP" if _spark_inst is not None else "NOT_INITIALIZED"

    # Override: if runtime is available, SQL is functional
    if runtime is not None:
        deps["sql"] = deps.get("sql", "CLOSED") if deps.get("sql") != "NOT_INITIALIZED" else "CLOSED"

    # Determine overall status
    dep_values = list(deps.values())
    if any(v in ("OPEN", "DOWN") for v in dep_values):
        overall = "DOWN"
    elif any(v in ("HALF_OPEN", "UNKNOWN", "NOT_INITIALIZED", "NOT_CONFIGURED", "DEGRADED") for v in dep_values):
        # "DEGRADED" dep (e.g. runtime in SQL-only mode) must bubble up to overall DEGRADED
        overall = "DEGRADED"
    else:
        overall = "OK"

    uptime = int(time.time() - getattr(request.app.state, "start_time", time.time()))
    return HealthResponse(status=overall, dependencies=deps, circuit_breakers=cb_list, uptime_s=uptime, error=startup_error or "")


@app.get("/api/v1/startup-status", tags=["ops"])
async def startup_status(request: Request):
    """Diagnostic: shows runtime init state without requiring runtime to be ready."""
    return {
        "runtime_ready": getattr(request.app.state, "runtime_ready", False),
        "runtime_available": getattr(request.app.state, "runtime", None) is not None,
        "startup_error": getattr(request.app.state, "startup_error", None),
        "uptime_s": int(time.time() - getattr(request.app.state, "start_time", time.time())),
        "session_repo": getattr(request.app.state, "session_repo", None) is not None,
        "feedback_repo": getattr(request.app.state, "feedback_repo", None) is not None,
        "telemetry": getattr(request.app.state, "telemetry", None) is not None,
    }



@app.get("/api/v1/status/metrics", tags=["ops"])
async def status_metrics(request: Request):
    """
    Operational metrics from telemetry table + data freshness.
    Returns empty defaults if telemetry table doesn't exist yet.
    """
    runtime = getattr(request.app.state, "runtime", None)
    # Use app.state.spark directly for SQL queries — available before full runtime.
    _sql = _get_spark(request)
    from platform.v4.config.settings import CATALOG, SCHEMA
    telemetry_table = f"{CATALOG}.{SCHEMA}.app_query_telemetry"
    sessions_table = f"{CATALOG}.{SCHEMA}.tbl_agent_sessions"

    loop = asyncio.get_running_loop()

    # --- Telemetry metrics (graceful if table doesn't exist) ---
    def _fetch_telemetry():
        _spark = (runtime._spark if runtime else None) or _sql
        if not _spark:
            return None
        try:
            # Check existence
            _spark.sql(f"DESCRIBE TABLE {telemetry_table}")
        except Exception:
            return None  # Table not yet created
        try:
            stats = _spark.sql(f"""
                SELECT COUNT(*) as total_queries,
                       AVG(total_latency_ms) as avg_latency_ms,
                       PERCENTILE(total_latency_ms, 0.95) as p95_latency_ms,
                       SUM(CASE WHEN error_class IS NOT NULL THEN 1 ELSE 0 END) / COUNT(*) as error_rate,
                       SUM(cost_estimate_usd) as total_cost_usd
                FROM {telemetry_table}
                WHERE event_ts >= CURRENT_DATE - INTERVAL 7 DAYS
            """).toPandas().iloc[0].to_dict()

            # Daily trends (last 7 days)
            trends = _spark.sql(f"""
                SELECT DATE(event_ts) as day,
                       COUNT(*) as queries,
                       AVG(total_latency_ms) as avg_latency,
                       SUM(CASE WHEN error_class IS NOT NULL THEN 1 ELSE 0 END) / COUNT(*) as err_rate,
                       SUM(cost_estimate_usd) as daily_cost
                FROM {telemetry_table}
                WHERE event_ts >= CURRENT_DATE - INTERVAL 7 DAYS
                GROUP BY DATE(event_ts)
                ORDER BY day
            """).toPandas()

            # Top providers
            top_provs = _spark.sql(f"""
                SELECT provider_scope as provider, COUNT(*) as count
                FROM {telemetry_table}
                WHERE provider_scope IS NOT NULL AND provider_scope != ''
                  AND event_ts >= CURRENT_DATE - INTERVAL 7 DAYS
                GROUP BY provider_scope
                ORDER BY count DESC LIMIT 5
            """).toPandas().to_dict(orient='records')

            # Confidence distribution
            conf_dist = _spark.sql(f"""
                SELECT confidence_label, COUNT(*) as cnt
                FROM {telemetry_table}
                WHERE event_ts >= CURRENT_DATE - INTERVAL 7 DAYS
                GROUP BY confidence_label
            """).toPandas()
            conf_map = dict(zip(conf_dist['confidence_label'], conf_dist['cnt'])) if len(conf_dist) > 0 else {}

            return {
                "stats": stats,
                "trends": trends,
                "top_providers": top_provs,
                "confidence_distribution": conf_map,
            }
        except Exception:
            return None

    # --- Data freshness ---
    def _fetch_freshness():
        _spark = (runtime._spark if runtime else None) or _sql
        if not _spark:
            return []
        tables_to_check = [
            f"{CATALOG}.{SCHEMA}.tbl_genie_provider_profile",
            f"{CATALOG}.{SCHEMA}.tbl_contract_rates_all",
            f"{CATALOG}.{SCHEMA}.tbl_contract_documents_master",
            f"{CATALOG}.{SCHEMA}.tbl_genie_amendment_timeline",
            f"{CATALOG}.{SCHEMA}.tbl_compliance_tracking",
            f"{CATALOG}.{SCHEMA}.tbl_dofr_matrix_extracted",
            f"{CATALOG}.{SCHEMA}.tbl_contract_deadlines",
            f"{CATALOG}.{SCHEMA}.tbl_alert_queue",
            f"{CATALOG}.{SCHEMA}.tbl_contract_risk_scores",
            f"{CATALOG}.{SCHEMA}.tbl_financial_exposure",
            f"{CATALOG}.{SCHEMA}.tbl_contract_clauses",
            f"{CATALOG}.{SCHEMA}.tbl_agent_sessions",
        ]
        freshness = []
        for tbl in tables_to_check:
            try:
                info = _spark.sql(f"DESCRIBE DETAIL {tbl}").toPandas().iloc[0]
                row_count = _spark.sql(f"SELECT COUNT(*) FROM {tbl}").collect()[0][0]
                freshness.append({
                    "table_name": tbl.split('.')[-1],
                    "last_updated": str(info.get('lastModified', '')),
                    "row_count": int(row_count),
                })
            except Exception:
                freshness.append({"table_name": tbl.split('.')[-1], "last_updated": "UNKNOWN", "row_count": 0})
        return freshness

    # --- Session count ---
    def _fetch_session_count():
        _spark = (runtime._spark if runtime else None) or _sql
        if not _spark:
            return 0
        try:
            return _spark.sql(f"SELECT COUNT(*) FROM {sessions_table}").collect()[0][0]
        except Exception:
            return 0

    try:
        # P2 performance: run all 3 queries in parallel instead of sequentially
        telemetry, freshness, session_count = await asyncio.gather(
            loop.run_in_executor(_EXECUTOR, _fetch_telemetry),
            loop.run_in_executor(_EXECUTOR, _fetch_freshness),
            loop.run_in_executor(_EXECUTOR, _fetch_session_count),
            return_exceptions=True,
        )
        # Handle individual failures gracefully
        if isinstance(telemetry, Exception):
            telemetry = None
        if isinstance(freshness, Exception):
            freshness = []
        if isinstance(session_count, Exception):
            session_count = 0
    except Exception:
        telemetry, freshness, session_count = None, [], 0

    # Build response
    if telemetry and telemetry.get("stats"):
        s = telemetry["stats"]
        trends_df = telemetry["trends"]
        latency_trend = [{"timestamp": str(r['day']), "value": round(r['avg_latency'] or 0, 1)} for _, r in trends_df.iterrows()]
        error_trend = [{"timestamp": str(r['day']), "value": round((r['err_rate'] or 0) * 100, 1)} for _, r in trends_df.iterrows()]
        cost_trend = [{"timestamp": str(r['day']), "value": round(r['daily_cost'] or 0, 3)} for _, r in trends_df.iterrows()]
        queries_trend = [{"timestamp": str(r['day']), "value": int(r['queries'])} for _, r in trends_df.iterrows()]

        return {
            "total_queries": int(s.get("total_queries") or 0),
            "total_sessions": int(session_count),
            "avg_latency_ms": round(s.get("avg_latency_ms") or 0, 1),
            "p95_latency_ms": round(s.get("p95_latency_ms") or 0, 1),
            "error_rate": round((s.get("error_rate") or 0) * 100, 1),
            "total_cost_usd": round(s.get("total_cost_usd") or 0, 2),
            "latency_trend": latency_trend,
            "error_trend": error_trend,
            "cost_trend": cost_trend,
            "queries_trend": queries_trend,
            "top_providers_queried": telemetry.get("top_providers", []),
            "confidence_distribution": telemetry.get("confidence_distribution", {}),
            "data_freshness": freshness,
        }
    else:
        # No telemetry data yet — return defaults
        return {
            "total_queries": 0,
            "total_sessions": int(session_count),
            "avg_latency_ms": 0,
            "p95_latency_ms": 0,
            "error_rate": 0,
            "total_cost_usd": 0,
            "latency_trend": [],
            "error_trend": [],
            "cost_trend": [],
            "queries_trend": [],
            "top_providers_queried": [],
            "confidence_distribution": {},
            "data_freshness": freshness,
        }


# ── Thread pool for blocking runtime calls ────────────────────────────────────

_EXECUTOR = concurrent.futures.ThreadPoolExecutor(max_workers=8, thread_name_prefix="v4-agent")

def _check_sql_breaker(request: Request) -> None:
    """Check SQL circuit breaker before executing a query. Raises 503 if open."""
    cb = getattr(request.app.state, "sql_breaker", None)
    if cb and not cb.allow():
        raise HTTPException(
            status_code=503,
            detail="SQL warehouse temporarily unavailable (circuit breaker open). Retry in 30s.",
            headers={"Retry-After": "30"},
        )


def _record_sql_success(request: Request) -> None:
    """Record a successful SQL execution for the circuit breaker."""
    cb = getattr(request.app.state, "sql_breaker", None)
    if cb:
        cb.record_success()


def _record_sql_failure(request: Request) -> None:
    """Record a failed SQL execution for the circuit breaker."""
    cb = getattr(request.app.state, "sql_breaker", None)
    if cb:
        cb.record_failure()


def _get_spark(request: Request):
    """Return the best available SQL client without requiring full runtime.

    Priority: app.state.spark (WarehouseSpark, set in lifespan step 1, available
    within ~5-15s of startup) over runtime._spark (requires full NotebookRuntime,
    step 4, may take 60-180s).  SQL-only endpoints (providers, report) use this so
    they work immediately without waiting for the LLM/VS layer to come up.
    """
    spark = getattr(request.app.state, "spark", None)
    if spark is not None:
        return spark
    runtime = getattr(request.app.state, "runtime", None)
    if runtime is not None:
        return getattr(runtime, "_spark", None)
    return None


def _sql_rows(spark, query: str) -> list[dict]:
    """Execute SQL and return a list of JSON-safe dicts.

    Converts the pandas DataFrame through to_json() so NaN/NaT values become
    JSON null instead of float('nan'), which would break FastAPI serialization.
    Raises on SQL error — callers wrap in try/except.
    """
    import json as _json
    df = spark.sql(query).toPandas()
    return _json.loads(df.to_json(orient='records', date_format='iso'))





# ── Query endpoint (Step 4.3) ─────────────────────────────────────────────────

@app.post("/api/v1/query", response_model=QueryResponse, tags=["agent"])
async def query(req: QueryRequest, request: Request):
    """
    Primary question-answering endpoint. Runs the V4 ReAct agent.
    Streams tokens via SSE when req.stream=True; returns JSON otherwise.
    Phase 4.3: wired to NotebookRuntime.stream_ask() / ask().
    """
    runtime = getattr(request.app.state, "runtime", None)
    _spark_ok = getattr(request.app.state, "spark", None) is not None
    if runtime is None or not hasattr(runtime, "ask"):
        # C10: Structured 503 — tells frontend ETA + what IS available right now
        _uptime_s = int(time.time() - getattr(request.app.state, "start_time", time.time()))
        _eta_s = max(0, 150 - _uptime_s)
        _available = ["providers", "reports", "status"] if _spark_ok else ["status"]
        _msg = (
            f"AI assistant warming up (~{_eta_s}s remaining). "
            + ("Provider Explorer and Reports are available now." if _spark_ok else "App is starting…")
        )
        return JSONResponse(
            status_code=503,
            content={"detail": _msg, "retry_after_s": 30, "available_features": _available},
            headers={"Retry-After": "30"},
        )

    # ── MULTI-TURN FIX: ensure every query has a stable session_id ──
    # First message from frontend sends session_id="" — generate a UUID so
    # the turn is persisted and multi-turn context works on follow-ups.
    _effective_sid = (req.session_id or "").strip() or str(uuid.uuid4())
    # Only pass session_id to runtime when it's a FOLLOW-UP (frontend sent one).
    # For first messages (we generated the UUID), skip load_session to avoid
    # unnecessary WarehouseSpark round-trip latency (~5-15s).
    _runtime_sid = _effective_sid if (req.session_id or "").strip() else None

    if req.stream:
        return StreamingResponse(
            _stream_generator(runtime, req, request, _effective_sid, _runtime_sid),
            media_type="text/event-stream",
            headers={"X-Accel-Buffering": "no", "Cache-Control": "no-cache"},
        )

    # Non-streaming: run synchronous ask() in thread pool
    loop = asyncio.get_running_loop()
    t0 = time.time()
    try:
        response = await loop.run_in_executor(
            _EXECUTOR,
            lambda: runtime.ask(
                question=req.question,
                provider_name=req.provider_name or None,
                session_id=_runtime_sid,
            ),
        )
    except Exception as exc:
        logger.error("Query failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=500, detail=str(exc)[:500])

    elapsed_ms = int((time.time() - t0) * 1000)
    label, score = _parse_confidence(str(response.confidence or ""))

    # MT-SYNC-BUFFER-FIX: Write to in-memory buffer IMMEDIATELY (synchronous) so
    # the next turn's load_session() finds this turn without waiting for the
    # async Delta write to commit. The fire-and-forget task persists to Delta
    # for cross-process and cross-session durability.
    _sync_repo = getattr(request.app.state, "session_repo", None)
    if _sync_repo is not None and _effective_sid:
        try:
            from platform.v4.data.session_repo import SessionRecord as _SR
            _resolved_json = (response.metadata or {}).get('resolved_entities_json')
            _sync_repo._buffer.append(_SR(
                session_id=_effective_sid,
                question=req.question[:1000],
                answer=(response.answer or "")[:2000],
                confidence=str(response.confidence or ""),
                total_cost=float(response.total_cost or 0.0),
                execution_time_s=elapsed_ms / 1000.0,
                step_count=len(response.steps or []),
                tool_calls=[str(getattr(tc, "tool_name", tc)) for tc in (response.tool_calls or [])][:20],
                citation_count=len(response.citations or []),
                resolved_entities_json=_resolved_json,
            ))
        except Exception as _buf_exc:
            logger.debug("Sync buffer write failed (non-fatal): %s", _buf_exc)

    # Persist turn for multi-turn history (fire-and-forget Delta write)
    # SYNC-PERSIST: await the Delta write so session context is committed
    # before the next turn's load_session() runs (fixes 12-A2 batch timing).
    try:
        await asyncio.to_thread(
            _persist_turn, request, req.question, response, _effective_sid, elapsed_ms,
        )
    except Exception as _pe:
        logger.warning("_persist_turn failed (non-fatal): %s", _pe)

    return QueryResponse(
        answer=response.answer or "",
        confidence=label,
        confidence_score=score,
        citations=response.citations or [],
        session_id=_effective_sid,
        latency_ms=elapsed_ms,
        tool_calls=len(response.tool_calls or []),
        cost_usd=round(float(response.total_cost or 0.0), 4),
    )


async def _stream_generator(runtime, req: QueryRequest, request: Request, effective_session_id: str, runtime_session_id: str | None = None) -> AsyncIterator[str]:
    """
    Wraps the synchronous stream_ask() iterator into an async generator
    that yields NDJSON lines for the SSE frontend consumer.
    Multi-turn fix: uses effective_session_id (always non-empty) so sessions
    are always persisted and the frontend always receives a session_id.
    """
    loop = asyncio.get_running_loop()

    def _run_stream():
        """Run stream_ask() in thread, collect events into a list."""
        return list(runtime.stream_ask(
            question=req.question,
            provider_name=req.provider_name or None,
            session_id=runtime_session_id,
        ))

    try:
        events = await loop.run_in_executor(_EXECUTOR, _run_stream)
    except Exception as exc:
        error_payload = json.dumps({"type": "error", "message": str(exc)[:500]})
        yield error_payload + "\n"
        return

    # Reconstruct response fields for session persistence
    _answer_parts: list[str] = []
    _session_id = effective_session_id
    _confidence  = ""
    _cost_usd    = 0.0
    _latency_ms  = 0
    _tool_cnt    = 0
    # BUG-6 fix: capture resolved_entities_json from done event so
    # _persist_turn can store multi-turn context in the streaming path.
    _resolved_entities_json = None

    for event in events:
        etype = event.get("type", "")
        if etype == "answer_chunk":
            _answer_parts.append(event.get("content", ""))
        elif etype == "confidence":
            _confidence = event.get("label", "")
        elif etype == "done":
            # Override the done event's session_id with our effective one
            # so the frontend always receives a valid session_id.
            event["session_id"] = effective_session_id
            _latency_ms = event.get("latency_ms", 0)
            _cost_usd   = event.get("cost_usd", 0.0)
            _tool_cnt   = event.get("tool_calls", 0)
            _resolved_entities_json = event.get("resolved_entities_json")
        yield json.dumps(event) + "\n"

    # Fire-and-forget persist after all events yielded
    class _StreamResp:
        answer     = "".join(_answer_parts)
        confidence = _confidence
        total_cost = _cost_usd
        steps      = []
        tool_calls = list(range(_tool_cnt))
        citations  = []
        session_id = _session_id
        # BUG-6 fix: expose metadata dict so _persist_turn can read
        # resolved_entities_json for multi-turn context recovery.
        metadata   = {'resolved_entities_json': _resolved_entities_json}
    asyncio.create_task(asyncio.to_thread(
        _persist_turn, request, req.question,
        _StreamResp(), _session_id, _latency_ms,
    ))


def _persist_turn(request: Request, question: str, response, session_id: str, elapsed_ms: int) -> None:
    """
    Fire-and-forget: persist a query turn to the session table.
    Non-blocking — failures are logged but never surface to the user.
    """
    repo = getattr(request.app.state, "session_repo", None)
    if repo is None or not session_id:
        return
    try:
        from platform.v4.data.session_repo import SessionRecord
        # W9-22c: Extract resolved_entities_json from response metadata for multi-turn context
        _resolved_json = (response.metadata or {}).get('resolved_entities_json')
        record = SessionRecord(
            session_id=session_id,
            question=question[:1000],
            answer=(response.answer or "")[:2000],
            confidence=str(response.confidence or ""),
            total_cost=float(response.total_cost or 0.0),
            execution_time_s=elapsed_ms / 1000.0,
            step_count=len(response.steps or []),
            tool_calls=[str(getattr(tc, "tool_name", tc)) for tc in (response.tool_calls or [])][:20],
            citation_count=len(response.citations or []),
            resolved_entities_json=_resolved_json,
        )
        repo.save(record)
    except Exception as exc:
        logger.warning("Session persist failed (non-fatal): %s", exc)


# ── Session endpoints (Phase 4, Step 4.4) ───────────────────────────────

class CreateSessionRequest(BaseModel):
    title: str = Field("", description="Optional initial session title")


class SessionSummary(BaseModel):
    session_id: str
    title: str
    created_at: str
    updated_at: str
    message_count: int = 0


@app.post("/api/v1/sessions", response_model=SessionSummary, tags=["sessions"])
async def create_session(req: CreateSessionRequest):
    """Create a new chat session. Returns a fresh session_id."""
    import uuid
    from datetime import datetime, timezone
    session_id = str(uuid.uuid4())
    now = datetime.now(timezone.utc).isoformat()
    return SessionSummary(
        session_id=session_id,
        title=req.title or "New conversation",
        created_at=now,
        updated_at=now,
        message_count=0,
    )


@app.get("/api/v1/sessions", tags=["sessions"])
async def list_sessions(
    request: Request,
    limit: int = Query(20, ge=1, le=100),
    offset: int = Query(0, ge=0),
):
    """List recent sessions with paginated limit/offset semantics."""
    spark = getattr(request.app.state, "spark", None)
    if spark is None:
        # Backend is still warming up — return 503 with Retry-After so the
        # frontend knows to retry rather than show a false "No sessions" state.
        raise HTTPException(
            status_code=503,
            detail="Database warming up — sessions will be available in a moment.",
            headers={"Retry-After": "10"},
        )

    from datetime import datetime, timezone
    import math

    def _fetch():
        """Direct SQL fetch — bypasses SessionRepo for robustness."""
        from platform.v4.config.settings import CATALOG, SCHEMA
        table = f"{CATALOG}.{SCHEMA}.tbl_agent_sessions"
        try:
            page_sql = f"""
                WITH base AS (
                    SELECT
                        session_id,
                        question,
                        created_at,
                        ROW_NUMBER() OVER (PARTITION BY session_id ORDER BY created_at ASC) AS rn_first,
                        COUNT(*) OVER (PARTITION BY session_id) AS turn_count,
                        MAX(created_at) OVER (PARTITION BY session_id) AS updated_ms
                    FROM {table}
                ),
                session_rollup AS (
                    SELECT
                        session_id,
                        question AS title_question,
                        created_at AS created_ms,
                        updated_ms,
                        turn_count
                    FROM base
                    WHERE rn_first = 1
                ),
                ranked AS (
                    SELECT
                        session_id,
                        title_question,
                        created_ms,
                        updated_ms,
                        turn_count,
                        ROW_NUMBER() OVER (ORDER BY updated_ms DESC, session_id ASC) AS row_num
                    FROM session_rollup
                )
                SELECT session_id, title_question, created_ms, updated_ms, turn_count
                FROM ranked
                WHERE row_num > {offset} AND row_num <= {offset + limit}
                ORDER BY updated_ms DESC, session_id ASC
            """
            total_sql = f"SELECT COUNT(DISTINCT session_id) AS total FROM {table}"
            page_df = spark.sql(page_sql).toPandas()
            total_df = spark.sql(total_sql).toPandas()
            total = int(total_df.iloc[0]["total"]) if not total_df.empty else 0
            return page_df, total
        except Exception as _tbl_exc:
            # Table may not exist yet (first run). Silently return empty frame.
            logger.info("list_sessions: table query failed (may not exist yet): %s", _tbl_exc)
            import pandas as _pd
            return _pd.DataFrame(columns=["session_id", "title_question", "created_ms", "updated_ms", "turn_count"]), 0

    loop = asyncio.get_running_loop()
    try:
        df, total = await loop.run_in_executor(_EXECUTOR, _fetch)
    except Exception as exc:
        logger.error("list_sessions: SQL fetch failed: %s", exc)
        return {"sessions": [], "total": 0, "limit": limit, "offset": offset, "has_more": False}

    if df is None or df.empty:
        return {"sessions": [], "total": total, "limit": limit, "offset": offset, "has_more": False}

    sessions = []
    for _, row in df.iterrows():
        sid = str(row.get("session_id", "") or "")
        if not sid:
            continue
        try:
            title = str(row.get("title_question", "") or "")[:60] or "Untitled"
            created_ms = row.get("created_ms", 0)
            updated_ms = row.get("updated_ms", 0)
            turn_count = row.get("turn_count", 0)
            try:
                created_ms = int(created_ms) if created_ms and not (isinstance(created_ms, float) and math.isnan(created_ms)) else 0
            except (TypeError, ValueError):
                created_ms = 0
            try:
                updated_ms = int(updated_ms) if updated_ms and not (isinstance(updated_ms, float) and math.isnan(updated_ms)) else 0
            except (TypeError, ValueError):
                updated_ms = 0
            try:
                turn_count = int(turn_count) if turn_count and not (isinstance(turn_count, float) and math.isnan(turn_count)) else 0
            except (TypeError, ValueError):
                turn_count = 0

            sessions.append({
                "session_id": sid,
                "title": title,
                "created_at": datetime.fromtimestamp(created_ms / 1000, tz=timezone.utc).isoformat() if created_ms else "",
                "updated_at": datetime.fromtimestamp(updated_ms / 1000, tz=timezone.utc).isoformat() if updated_ms else "",
                "message_count": turn_count * 2,
            })
        except Exception as exc:
            logger.warning("list_sessions: error processing session %s: %s", sid[:12], exc)
            continue

    return {
        "sessions": sessions,
        "total": total,
        "limit": limit,
        "offset": offset,
        "has_more": (offset + len(sessions)) < total,
    }


@app.get("/api/v1/sessions/{session_id}", tags=["sessions"])
async def get_session_detail(session_id: str, request: Request):
    """Get full session detail including message history."""
    repo = getattr(request.app.state, "session_repo", None)
    if repo is None:
        raise HTTPException(status_code=404, detail="Session not found (session store unavailable)")

    loop = asyncio.get_running_loop()
    turns = await loop.run_in_executor(_EXECUTOR, lambda: repo.load_session(session_id))

    if not turns:
        raise HTTPException(status_code=404, detail="Session not found")

    from datetime import datetime, timezone
    messages = []
    for turn in turns:
        ts_ms = turn.get("created_at", 0)
        ts_iso = datetime.fromtimestamp(ts_ms / 1000, tz=timezone.utc).isoformat() if ts_ms else ""
        messages.append({"role": "user", "content": turn.get("question", ""), "timestamp": ts_iso})
        messages.append({
            "role": "assistant",
            "content": turn.get("answer", ""),
            "timestamp": ts_iso,
            "confidence": turn.get("confidence", ""),
            "latency_ms": int(turn.get("execution_time_s", 0) * 1000),
            "cost_usd": float(turn.get("total_cost", 0.0)),
        })

    title = str(turns[0].get("question", ""))[:60] if turns else "Untitled"
    first_ts = turns[0].get("created_at", 0) if turns else 0
    last_ts = turns[-1].get("created_at", 0) if turns else 0
    from datetime import datetime, timezone
    return {
        "session_id": session_id,
        "title": title,
        "created_at": datetime.fromtimestamp(first_ts / 1000, tz=timezone.utc).isoformat() if first_ts else "",
        "updated_at": datetime.fromtimestamp(last_ts / 1000, tz=timezone.utc).isoformat() if last_ts else "",
        "messages": messages,
    }


@app.patch("/api/v1/sessions/{session_id}", tags=["sessions"])
async def rename_session(session_id: str, req: CreateSessionRequest, request: Request):
    """Rename a session title. Persists to session metadata if repo available."""
    repo = getattr(request.app.state, "session_repo", None)
    if repo and req.title:
        loop = asyncio.get_running_loop()
        try:
            await loop.run_in_executor(
                _EXECUTOR,
                lambda: repo.update_title(session_id, req.title[:100]),
            )
        except Exception as exc:
            logger.warning("Session rename persist failed (non-fatal): %s", exc)
    return {"session_id": session_id, "title": req.title, "updated": True}


# ── Concepts + Report endpoints (Step 4.8) ─────────────────────────────────────

_CONCEPT_COL_MAP = {
    "offset_clause": "offset_clause_status",
    "division_of_financial_responsibility": "dofr_status",
    "ipa_delegation": "ipa_delegation_status",
    "auto_renewal": "auto_renewal",
    "ab_352_reproductive_health": "ab_352_status",
    "encounters_reconciliation": "encounters_reconciliation_status",
}

_CONCEPT_LABELS = {
    "offset_clause": "Offset Clause",
    "division_of_financial_responsibility": "Division of Financial Responsibility",
    "ipa_delegation": "IPA Delegation",
    "auto_renewal": "Auto Renewal",
    "ab_352_reproductive_health": "AB 352 Reproductive Health",
    "encounters_reconciliation": "Encounters Reconciliation",
}


@app.get("/api/v1/concepts", tags=["report"])
async def list_concepts():
    """Return the list of available classification concepts."""
    concepts = [
        {"key": k, "label": v, "column": _CONCEPT_COL_MAP[k]}
        for k, v in _CONCEPT_LABELS.items()
    ]
    return {"concepts": concepts}


@app.post("/api/v1/report", tags=["report"])
async def generate_report(request: Request, body: dict):
    """
    Generate a classification matrix report across providers and concepts.
    ReportRequest: { concept_keys: str[], provider_filter?: str, lob_filter?: str, active_only?: bool }
    Returns: { total_providers, concept_keys, summary, results }
    """
    spark = _get_spark(request)
    if spark is None:
        raise HTTPException(
            status_code=503,
            detail="Database unavailable — SQL warehouse is starting up. Retry in a moment.",
            headers={"Retry-After": "10"},
        )

    from platform.v4.config.settings import CATALOG, SCHEMA
    table = f"{CATALOG}.{SCHEMA}.tbl_genie_provider_profile"

    concept_keys = body.get("concept_keys", list(_CONCEPT_COL_MAP.keys())[:3])
    provider_filter = body.get("provider_filter", "")
    lob_filter = body.get("lob_filter", "")
    active_only = body.get("active_only", True)

    # Validate concepts
    valid_keys = [k for k in concept_keys if k in _CONCEPT_COL_MAP]
    if not valid_keys:
        raise HTTPException(status_code=400, detail="No valid concept_keys provided")

    # Build columns to select
    cols = ["provider_name"]
    for k in valid_keys:
        col = _CONCEPT_COL_MAP[k]
        cols.append(f"COALESCE({col}, 'UNCLASSIFIED') AS `{k}`")

    conditions = []
    if active_only:
        conditions.append("is_active = true")
    if provider_filter:
        safe = _sanitize_like_input(provider_filter)
        conditions.append(f"LOWER(provider_name) LIKE '%{safe}%'")
    if lob_filter:
        safe = _sanitize_like_input(lob_filter)
        conditions.append(f"LOWER(lob_normalized) LIKE '%{safe}%'")

    where = ("WHERE " + " AND ".join(conditions)) if conditions else ""
    sql = f"SELECT {', '.join(cols)} FROM {table} {where} ORDER BY provider_name LIMIT 500"

    loop = asyncio.get_running_loop()
    def _q():
        return spark.sql(sql).toPandas()

    _check_sql_breaker(request)
    try:
        df = await loop.run_in_executor(_EXECUTOR, _q)
        _record_sql_success(request)
    except Exception as exc:
        _record_sql_failure(request)
        raise HTTPException(status_code=500, detail=str(exc)[:300])

    # Build summary and results
    summary = {}
    for k in valid_keys:
        counts = df[k].value_counts().to_dict() if k in df.columns else {}
        summary[k] = {status: int(cnt) for status, cnt in counts.items()}

    results = []
    for _, row in df.iterrows():
        classifications = {k: row.get(k, "UNCLASSIFIED") for k in valid_keys}
        results.append({"provider_name": row["provider_name"], "classifications": classifications})

    return {
        "total_providers": len(results),
        "concept_keys": valid_keys,
        "summary": summary,
        "results": results,
    }


# ── Provider endpoints (Step 4.5) ────────────────────────────────────────────

@app.get("/api/v1/providers", tags=["providers"])
async def list_providers(
    request: Request,
    search: str = "",
    lob: str = "",
    payment_type: str = "",
    active: str = "",
    limit: int = 50,
    offset: int = 0,
):
    """
    List/search providers from tbl_genie_provider_profile.
    Returns summary rows suitable for grid display.
    """
    spark = _get_spark(request)
    if spark is None:
        raise HTTPException(
            status_code=503,
            detail="Database unavailable — SQL warehouse is starting up. Retry in a moment.",
            headers={"Retry-After": "10"},
        )

    from platform.v4.config.settings import CATALOG, SCHEMA
    table = f"{CATALOG}.{SCHEMA}.tbl_genie_provider_profile"

    conditions = []
    if search:
        safe = _sanitize_like_input(search)
        conditions.append(f"LOWER(provider_name) LIKE '%{safe}%'")
    if lob:
        safe = _sanitize_like_input(lob)
        conditions.append(f"LOWER(lob_normalized) LIKE '%{safe}%'")
    if payment_type:
        safe = _sanitize_like_input(payment_type)
        conditions.append(f"LOWER(payment_type) LIKE '%{safe}%'")
    # Default to showing active providers when no filter specified
    if active.lower() in ("true", "false"):
        conditions.append(f"is_active = {active.lower()}")
    elif not active:
        conditions.append("is_active = true")

    where = ("WHERE " + " AND ".join(conditions)) if conditions else ""

    sql = f"""
        SELECT provider_id, provider_name, payment_type, lob_normalized,
               is_active, total_documents, total_amendments,
               latest_amendment_date, total_rates, current_rates,
               agreement_type
        FROM {table}
        {where}
        ORDER BY provider_name
        LIMIT {min(limit, 200)} OFFSET {offset}
    """
    count_sql = f"SELECT COUNT(*) AS total FROM {table} {where}"

    loop = asyncio.get_running_loop()
    def _query():
        rows = spark.sql(sql).toPandas().to_dict(orient="records")
        total = spark.sql(count_sql).collect()[0]["total"]
        return rows, total

    _check_sql_breaker(request)
    try:
        providers, total = await loop.run_in_executor(_EXECUTOR, _query)
        total = int(total)
        _record_sql_success(request)
    except Exception as exc:
        _record_sql_failure(request)
        logger.error("Provider list failed: %s", exc)
        raise HTTPException(status_code=500, detail=str(exc)[:300])

    results = []
    for p in providers:
        results.append({
            "provider_name": p.get("provider_name", ""),
            "provider_id": p.get("provider_id", ""),
            "lob": [x.strip() for x in (p.get("lob_normalized") or "").split("+")] if p.get("lob_normalized") else [],
            "payment_types": [p.get("payment_type", "")] if p.get("payment_type") else [],
            "active": bool(p.get("is_active")),
            "contract_count": int(p.get("total_documents") or 0),
            "amendment_count": int(p.get("total_amendments") or 0),
            "latest_effective_date": str(p.get("latest_amendment_date") or ""),
        })

    return {"providers": results, "total": total}
    # END list_providers (was: raise HTTPException(status_code=503, detail="Not yet implemented — Phase 4, Step 4.5")


@app.get("/api/v1/providers/{provider_name}", tags=["providers"])
async def get_provider(provider_name: str, request: Request):
    """Full provider profile: rates, amendments, documents, clause coverage."""
    spark = _get_spark(request)
    if spark is None:
        raise HTTPException(
            status_code=503,
            detail="Database unavailable — SQL warehouse is starting up. Retry in a moment.",
            headers={"Retry-After": "10"},
        )
    from platform.v4.config.settings import CATALOG, SCHEMA
    from urllib.parse import unquote
    name = unquote(provider_name)
    loop = asyncio.get_running_loop()
    def _detail():
        sn = name.replace("'", "''")
        ptbl = f"{CATALOG}.{SCHEMA}.tbl_genie_provider_profile"
        rtbl = f"{CATALOG}.{SCHEMA}.tbl_contract_rates_all"
        dtbl = f"{CATALOG}.{SCHEMA}.tbl_contract_documents_master"
        prof = spark.sql(f"SELECT * FROM {ptbl} WHERE provider_name='{sn}' LIMIT 1").toPandas().to_dict(orient='records')
        rts = spark.sql(f"SELECT service_category,rate_category,rate_numeric,CAST(effective_date_parsed AS STRING) AS effective_date,rate_type_detail AS unit FROM {rtbl} WHERE provider_name='{sn}' AND status='current' AND is_valid_rate=true ORDER BY rate_numeric DESC NULLS LAST LIMIT 30").toPandas().to_dict(orient='records')
        dcs = spark.sql(f"SELECT COALESCE(contract_id, source_filename) AS doc_id, doc_role, source_filename, effective_date_parsed, amendment_order FROM {dtbl} WHERE provider_name='{sn}' ORDER BY effective_date_parsed DESC LIMIT 50").toPandas().to_dict(orient='records')
        return prof, rts, dcs
    try:
        prof, rts, dcs = await loop.run_in_executor(_EXECUTOR, _detail)
    except Exception as exc:
        logger.error("Provider detail failed: %s", exc)
        raise HTTPException(status_code=500, detail=str(exc)[:300])
    if not prof:
        raise HTTPException(status_code=404, detail=f"Provider not found: {name}")
    p = prof[0]
    rates = [{"service_category": r.get("service_category",""), "rate_type": r.get("rate_category",""), "rate_numeric": float(r.get("rate_numeric") or 0), "effective_date": str(r.get("effective_date") or "")} for r in rts]
    documents = [{"doc_id": str(d.get("doc_id") or d.get("source_filename") or ""), "doc_role": d.get("doc_role",""), "filename": d.get("source_filename",""), "effective_date": str(d.get("effective_date_parsed") or ""), "page_count": int(d.get("amendment_order") or 0)} for d in dcs]
    amendments = [{"doc_id": d["doc_id"], "effective_date": d["effective_date"], "page_count": d["page_count"]} for d in documents if d.get("doc_role")=="amendment"]
    clause_coverage = [{"concept_key": k, "concept_label": l, "status": p.get(k,"NO_MENTION") or "NO_MENTION"} for k,l in [("offset_clause_status","Offset Clause"),("dofr_status","DOFR"),("ipa_delegation_status","IPA Delegation")]]
    return {"provider_name": p.get("provider_name",""), "provider_id": p.get("provider_id",""), "lob": [x.strip() for x in (p.get("lob_normalized") or "").split("+")] if p.get("lob_normalized") else [], "payment_types": [p.get("payment_type","")] if p.get("payment_type") else [], "active": bool(p.get("is_active")), "rates": rates, "amendments": amendments, "documents": documents, "clause_coverage": clause_coverage}
    # END get_provider (was: raise HTTPException 503, detail="Not yet implemented — Phase 4, Step 4.5")


# ── Document / PDF endpoints (Phase 4, Step 4.10) ───────────────────────

_PDF_VOLUME_BASE = "/Volumes/prod_adb/default/ext-data-volume-stmlz/Health_Plan_Ops_Transformation/Provider_Contracts"


@app.get("/api/v1/documents/{filename:path}/pdf", tags=["documents"])
async def serve_document_pdf(filename: str):
    """
    Stream a contract PDF from the UC Volume.
    Volume structure: Provider_Contracts/{Provider_Name}/{source_filename}
    The frontend embeds this URL in an iframe with #page=N for deep-linking.
    """
    import os
    # Reject obviously malicious patterns
    if '..' in filename or filename.startswith('/'):
        raise HTTPException(status_code=400, detail="Invalid path")
    # Resolve and verify path stays within the volume base
    candidate = os.path.normpath(os.path.join(_PDF_VOLUME_BASE, filename))
    if not candidate.startswith(os.path.normpath(_PDF_VOLUME_BASE)):
        raise HTTPException(status_code=400, detail="Path traversal denied")
    if not os.path.isfile(candidate):
        raise HTTPException(status_code=404, detail=f"Document not found: {filename}")
    return FileResponse(
        path=candidate,
        media_type="application/pdf",
        filename=os.path.basename(candidate),
        headers={"Content-Disposition": "inline"},
    )


@app.get("/api/v1/documents/{source_filename}/resolve", tags=["documents"])
async def resolve_document_path(source_filename: str, request: Request):
    """
    Resolve a source_filename to its full volume path (provider_folder/filename).
    Looks up provider_name from tbl_contract_documents_master and constructs
    the volume-relative path: {provider_name}/{source_filename}
    """
    spark = _get_spark(request)
    if spark is None:
        raise HTTPException(
            status_code=503,
            detail="Database unavailable — SQL warehouse is starting up. Retry in a moment.",
            headers={"Retry-After": "10"},
        )
    from platform.v4.config.settings import CATALOG, SCHEMA
    safe = source_filename.replace("'", "''")
    sql = f"SELECT provider_id, provider_name, source_filename FROM {CATALOG}.{SCHEMA}.tbl_contract_documents_master WHERE source_filename = '{safe}' LIMIT 1"
    loop = asyncio.get_running_loop()
    def _q():
        return spark.sql(sql).toPandas().to_dict(orient='records')
    try:
        rows = await loop.run_in_executor(_EXECUTOR, _q)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)[:300])
    if not rows:
        raise HTTPException(status_code=404, detail=f"Document not found in catalog: {source_filename}")
    provider = rows[0].get("provider_name", "")
    # Provider folder name uses the provider_name as-is (folder matches provider_name)
    volume_path = f"{provider}/{source_filename}"
    return {"source_filename": source_filename, "provider_name": provider, "volume_path": volume_path, "pdf_url": f"/api/v1/documents/{volume_path}/pdf"}


@app.get("/api/v1/documents/lookup", tags=["documents"])
async def lookup_document(source: str = "", provider: str = "", request: Request = None):
    """
    Resolve a citation source string to a document record.
    Supports lookup by source_filename substring or provider_name + doc_role.
    Returns document metadata including the filename needed for PDF viewing.
    """
    spark = _get_spark(request)
    if spark is None:
        raise HTTPException(
            status_code=503,
            detail="Database unavailable — SQL warehouse is starting up. Retry in a moment.",
            headers={"Retry-After": "10"},
        )

    from platform.v4.config.settings import CATALOG, SCHEMA
    table = f"{CATALOG}.{SCHEMA}.tbl_contract_documents_master"

    if source:
        safe = source.replace("'", "''").replace("%", "")
        sql = f"SELECT source_filename, provider_name, doc_role, document_type, effective_date_parsed, amendment_order FROM {table} WHERE LOWER(source_filename) LIKE '%{safe.lower()}%' LIMIT 5"
    elif provider:
        safe = provider.replace("'", "''")
        sql = f"SELECT source_filename, provider_name, doc_role, document_type, effective_date_parsed, amendment_order FROM {table} WHERE provider_name = '{safe}' ORDER BY effective_date_parsed DESC LIMIT 10"
    else:
        raise HTTPException(status_code=400, detail="Provide 'source' or 'provider' parameter")

    loop = asyncio.get_running_loop()
    def _q():
        return spark.sql(sql).toPandas().to_dict(orient='records')

    try:
        rows = await loop.run_in_executor(_EXECUTOR, _q)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)[:300])

    docs = [{"source_filename": r.get("source_filename", ""), "provider_name": r.get("provider_name", ""), "doc_role": r.get("doc_role", ""), "document_type": r.get("document_type", ""), "effective_date": str(r.get("effective_date_parsed") or "")} for r in rows]
    return {"documents": docs, "total": len(docs)}


# ── Export endpoint (Step 4.7) ────────────────────────────────────────────────

@app.get("/api/v1/export/{session_id}", tags=["export"])
async def export_session(session_id: str, format: str = "markdown", request: Request = None):
    """
    Export a session as markdown or JSON.
    Formats: markdown (default), json, csv
    """
    repo = getattr(request.app.state, "session_repo", None)
    if repo is None:
        raise HTTPException(status_code=404, detail="Session not found (session store unavailable)")

    loop = asyncio.get_running_loop()
    turns = await loop.run_in_executor(_EXECUTOR, lambda: repo.load_session(session_id))
    if not turns:
        raise HTTPException(status_code=404, detail="Session not found")

    from datetime import datetime, timezone

    if format == "json":
        messages = []
        for turn in turns:
            ts_ms = turn.get("created_at", 0)
            ts_iso = datetime.fromtimestamp(ts_ms / 1000, tz=timezone.utc).isoformat() if ts_ms else ""
            messages.append({"role": "user", "content": turn.get("question", ""), "timestamp": ts_iso})
            messages.append({"role": "assistant", "content": turn.get("answer", ""), "timestamp": ts_iso, "confidence": turn.get("confidence", ""), "citations": turn.get("citations", [])})
        return {"session_id": session_id, "exported_at": datetime.now(timezone.utc).isoformat(), "message_count": len(messages), "messages": messages}

    elif format == "csv":
        import csv, io
        buf = io.StringIO()
        writer = csv.writer(buf)
        writer.writerow(["timestamp", "role", "content", "confidence"])
        for turn in turns:
            ts_ms = turn.get("created_at", 0)
            ts_iso = datetime.fromtimestamp(ts_ms / 1000, tz=timezone.utc).isoformat() if ts_ms else ""
            writer.writerow([ts_iso, "user", turn.get("question", ""), ""])
            writer.writerow([ts_iso, "assistant", turn.get("answer", ""), turn.get("confidence", "")])
        return Response(content=buf.getvalue(), media_type="text/csv", headers={"Content-Disposition": f"attachment; filename=session_{session_id[:8]}.csv"})

    else:  # markdown
        title = str(turns[0].get("question", ""))[:60] if turns else "Session"
        lines = [f"# Contract Intelligence — Session Export\n", f"**Session:** {session_id}  \n**Exported:** {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}  \n**Messages:** {len(turns) * 2}\n", "---\n"]
        for i, turn in enumerate(turns, 1):
            ts_ms = turn.get("created_at", 0)
            ts_str = datetime.fromtimestamp(ts_ms / 1000, tz=timezone.utc).strftime('%H:%M') if ts_ms else ""
            lines.append(f"## Q{i} ({ts_str})\n")
            lines.append(f"{turn.get('question', '')}\n\n")
            lines.append(f"### Answer (confidence: {turn.get('confidence', 'N/A')})\n")
            lines.append(f"{turn.get('answer', '')}\n\n")
            lines.append("---\n")
        md_content = "\n".join(lines)
        return Response(content=md_content, media_type="text/markdown", headers={"Content-Disposition": f"attachment; filename=session_{session_id[:8]}.md"})
    # END export_session (was 503 stub, now implemented — Phase 4, Step 4.7")


# ── Feedback endpoint (Phase 4, Step 4.5) ───────────────────────────────────

class FeedbackRequest(BaseModel):
    session_id: str
    query_id:   str       = Field("", description="Message ID within session")
    thumbs_up:  Optional[bool] = Field(None, description="True=positive, False=negative feedback")
    rating:     Optional[str]  = Field(None, description="Frontend compat: 'up' or 'down'")
    correction: str       = Field("", description="User-provided corrected answer")
    note:       str       = Field("", description="Optional free-text note")

    @property
    def is_positive(self) -> bool:
        """Resolve thumbs_up from either field (backward compat)."""
        if self.thumbs_up is not None:
            return self.thumbs_up
        if self.rating:
            return self.rating.lower() == "up"
        return True  # default to positive if neither provided


@app.post("/api/v1/feedback", tags=["feedback"])
async def submit_feedback(req: FeedbackRequest, request: Request):
    """
    Capture user thumbs up/down and optional corrections.
    Writes to tbl_user_feedback via FeedbackRepo.
    """
    repo = getattr(request.app.state, "feedback_repo", None)
    if repo is None:
        # Return 200 silently — don't break the UI for a non-critical feature
        return {"status": "skipped", "feedback_id": req.query_id or req.session_id}

    loop = asyncio.get_running_loop()

    if req.is_positive:
        success = await loop.run_in_executor(
            _EXECUTOR,
            lambda: repo.thumbs_up(
                session_id=req.session_id,
                question=req.query_id,  # query_id maps to the question context
                answer="",
                comment=req.note,
            ),
        )
    else:
        success = await loop.run_in_executor(
            _EXECUTOR,
            lambda: repo.thumbs_down(
                session_id=req.session_id,
                question=req.query_id,
                answer="",
                comment=req.note,
                correction=req.correction,
            ),
        )

    if not success:
        raise HTTPException(status_code=500, detail="Failed to persist feedback")

    return {"status": "accepted", "feedback_id": req.query_id or req.session_id}


# ── Risk & Alerts endpoints (Phase 10B-1) ─────────────────────────────────────────

@app.get("/api/v1/alerts", tags=["risk"])
async def get_alerts(request: Request, priority: str = None, limit: int = 50):
    """Return active alerts from tbl_alert_queue, optionally filtered by priority."""
    spark = _get_spark(request)
    if spark is None:
        raise HTTPException(status_code=503, detail="Database unavailable", headers={"Retry-After": "10"})
    from platform.v4.config.settings import CATALOG, SCHEMA
    tbl = f"{CATALOG}.{SCHEMA}.tbl_alert_queue"
    priority_clause = f"AND alert_priority = '{priority.upper()}'" if priority else ""
    sql = f"""
        SELECT alert_id, provider_name, deadline_type, action_required_by,
               days_until_due, alert_priority, alert_status, context_text,
               source_deadline_id, created_at
        FROM {tbl}
        WHERE alert_status = 'NEW' {priority_clause}
        ORDER BY days_until_due ASC
        LIMIT {min(limit, 200)}
    """
    loop = asyncio.get_running_loop()
    _check_sql_breaker(request)
    try:
        rows = await loop.run_in_executor(_EXECUTOR, lambda: spark.sql(sql).toPandas().to_dict(orient="records"))
        _record_sql_success(request)
    except Exception as exc:
        _record_sql_failure(request)
        logger.error("get_alerts failed: %s", exc)
        raise HTTPException(status_code=500, detail=str(exc)[:300])
    for r in rows:
        r["action_required_by"] = str(r.get("action_required_by") or "")
        r["created_at"] = str(r.get("created_at") or "")
    return {"alerts": rows, "count": len(rows)}


@app.get("/api/v1/alerts/summary", tags=["risk"])
async def get_alerts_summary(request: Request):
    """Return aggregate counts by priority for the active alert queue."""
    spark = _get_spark(request)
    if spark is None:
        raise HTTPException(status_code=503, detail="Database unavailable", headers={"Retry-After": "10"})
    from platform.v4.config.settings import CATALOG, SCHEMA
    tbl = f"{CATALOG}.{SCHEMA}.tbl_alert_queue"
    sql = f"""
        SELECT alert_priority, COUNT(*) AS cnt
        FROM {tbl}
        WHERE alert_status = 'NEW'
        GROUP BY alert_priority
    """
    loop = asyncio.get_running_loop()
    _check_sql_breaker(request)
    try:
        rows = await loop.run_in_executor(_EXECUTOR, lambda: spark.sql(sql).collect())
        _record_sql_success(request)
    except Exception as exc:
        _record_sql_failure(request)
        raise HTTPException(status_code=500, detail=str(exc)[:300])
    counts = {r["alert_priority"]: int(r["cnt"]) for r in rows}
    total = sum(counts.values())
    return {
        "critical": counts.get("CRITICAL", 0),
        "high":     counts.get("HIGH", 0),
        "medium":   counts.get("MEDIUM", 0),
        "total":    total,
    }


@app.get("/api/v1/risk/scores", tags=["risk"])
async def get_risk_scores(request: Request, tier: str = None, sort_by: str = "risk_score", limit: int = 50):
    """Return provider risk scores, optionally filtered by risk_tier."""
    spark = _get_spark(request)
    if spark is None:
        raise HTTPException(status_code=503, detail="Database unavailable", headers={"Retry-After": "10"})
    from platform.v4.config.settings import CATALOG, SCHEMA
    tbl = f"{CATALOG}.{SCHEMA}.tbl_contract_risk_scores"
    _allowed_sort = {"risk_score", "days_to_expiry", "contracted_spend", "provider_name"}
    sort_col = sort_by if sort_by in _allowed_sort else "risk_score"
    tier_clause = f"WHERE UPPER(risk_tier) = '{tier.upper()}'" if tier else ""
    sql = f"""
        SELECT provider_id, provider_name, lob, payment_type, risk_score, risk_tier,
               days_to_expiry, compliance_gap, clause_gap, contracted_spend, scored_at
        FROM {tbl}
        {tier_clause}
        ORDER BY {sort_col} DESC NULLS LAST
        LIMIT {min(limit, 200)}
    """
    loop = asyncio.get_running_loop()
    _check_sql_breaker(request)
    try:
        rows = await loop.run_in_executor(_EXECUTOR, lambda: spark.sql(sql).toPandas().to_dict(orient="records"))
        _record_sql_success(request)
    except Exception as exc:
        _record_sql_failure(request)
        raise HTTPException(status_code=500, detail=str(exc)[:300])
    for r in rows:
        r["scored_at"] = str(r.get("scored_at") or "")
        r["contracted_spend"] = float(r.get("contracted_spend") or 0)
    return {"scores": rows, "count": len(rows)}


@app.get("/api/v1/risk/{provider_name}", tags=["risk"])
async def get_provider_risk(provider_name: str, request: Request):
    """Return combined risk score, active alerts, and upcoming deadlines for one provider."""
    spark = _get_spark(request)
    if spark is None:
        raise HTTPException(status_code=503, detail="Database unavailable", headers={"Retry-After": "10"})
    from platform.v4.config.settings import CATALOG, SCHEMA
    from urllib.parse import unquote
    name = unquote(provider_name)
    sn = name.replace("'", "''")
    loop = asyncio.get_running_loop()
    def _risk_detail():
        rtbl = f"{CATALOG}.{SCHEMA}.tbl_contract_risk_scores"
        atbl = f"{CATALOG}.{SCHEMA}.tbl_alert_queue"
        dtbl = f"{CATALOG}.{SCHEMA}.tbl_contract_deadlines"
        risk = spark.sql(f"SELECT * FROM {rtbl} WHERE LOWER(provider_name) LIKE LOWER('%{sn}%') LIMIT 5").toPandas().to_dict(orient="records")
        alerts = spark.sql(f"SELECT alert_id, deadline_type, action_required_by, days_until_due, alert_priority, context_text FROM {atbl} WHERE LOWER(provider_name) LIKE LOWER('%{sn}%') AND alert_status = 'NEW' ORDER BY days_until_due ASC LIMIT 20").toPandas().to_dict(orient="records")
        deadlines = spark.sql(f"SELECT DISTINCT deadline_id, deadline_type, event_date, action_required_by, days_until_action, priority_tier, notice_days FROM {dtbl} WHERE LOWER(provider_name) LIKE LOWER('%{sn}%') AND priority_tier != 'EXPIRED' ORDER BY days_until_action ASC LIMIT 20").toPandas().to_dict(orient="records")
        return risk, alerts, deadlines
    _check_sql_breaker(request)
    try:
        risk, alerts, deadlines = await loop.run_in_executor(_EXECUTOR, _risk_detail)
        _record_sql_success(request)
    except Exception as exc:
        _record_sql_failure(request)
        raise HTTPException(status_code=500, detail=str(exc)[:300])
    for r in risk:
        r["scored_at"] = str(r.get("scored_at") or "")
    for a in alerts:
        a["action_required_by"] = str(a.get("action_required_by") or "")
    for d in deadlines:
        d["event_date"] = str(d.get("event_date") or "")
        d["action_required_by"] = str(d.get("action_required_by") or "")
    return {"risk": risk[0] if risk else None, "alerts": alerts, "deadlines": deadlines}


@app.get("/api/v1/deadlines", tags=["risk"])
async def get_deadlines(request: Request, days_ahead: int = 90, priority: str = None):
    """Return upcoming contract deadlines within days_ahead days."""
    spark = _get_spark(request)
    if spark is None:
        raise HTTPException(status_code=503, detail="Database unavailable", headers={"Retry-After": "10"})
    from platform.v4.config.settings import CATALOG, SCHEMA
    tbl = f"{CATALOG}.{SCHEMA}.tbl_contract_deadlines"
    priority_clause = f"AND priority_tier = '{priority.upper()}'" if priority else ""
    sql = f"""
        SELECT deadline_id, provider_name, deadline_type, event_date,
               action_required_by, days_until_action, priority_tier, notice_days
        FROM (
            SELECT deadline_id, provider_name, deadline_type, event_date,
                   action_required_by, days_until_action, priority_tier, notice_days,
                   ROW_NUMBER() OVER (
                       PARTITION BY provider_name, deadline_type, event_date
                       ORDER BY days_until_action ASC, deadline_id ASC
                   ) AS _rn
            FROM {tbl}
            WHERE days_until_action BETWEEN 0 AND {min(days_ahead, 730)}
              AND priority_tier != 'EXPIRED'
              {priority_clause}
        ) _d
        WHERE _rn = 1
        ORDER BY days_until_action ASC
        LIMIT 100
    """
    loop = asyncio.get_running_loop()
    _check_sql_breaker(request)
    try:
        rows = await loop.run_in_executor(_EXECUTOR, lambda: spark.sql(sql).toPandas().to_dict(orient="records"))
        _record_sql_success(request)
    except Exception as exc:
        _record_sql_failure(request)
        raise HTTPException(status_code=500, detail=str(exc)[:300])
    for r in rows:
        r["event_date"] = str(r.get("event_date") or "")
        r["action_required_by"] = str(r.get("action_required_by") or "")
    return {"deadlines": rows, "count": len(rows)}

# ── Financial Intelligence endpoints (Phase 10B-2) ──────────────────────────────

@app.get("/api/v1/financial/exposure", tags=["financial"])
async def get_financial_exposure(request: Request, sort_by: str = "contracted_spend", limit: int = 50):
    """Return financial exposure summary aggregated by provider."""
    spark = _get_spark(request)
    if spark is None:
        raise HTTPException(status_code=503, detail="Database unavailable", headers={"Retry-After": "10"})
    from platform.v4.config.settings import CATALOG, SCHEMA
    fe  = f"{CATALOG}.{SCHEMA}.tbl_financial_exposure"
    prf = f"{CATALOG}.{SCHEMA}.tbl_genie_provider_profile"
    _allowed_sort = {"contracted_spend", "actual_spend", "variance_pct", "provider_name"}
    sort_col = sort_by if sort_by in _allowed_sort else "contracted_spend"
    sql = f"""
        SELECT p.provider_name, e.line_of_business,
               CAST(SUM(e.contracted_spend) AS DOUBLE) AS contracted_spend,
               CAST(SUM(e.actual_spend)     AS DOUBLE) AS actual_spend,
               ROUND(AVG(e.variance_pct), 4)            AS avg_variance_pct,
               MAX(e.estimate_confidence)               AS estimate_confidence
        FROM {fe} e
        JOIN {prf} p ON p.provider_id = e.provider_id
        GROUP BY p.provider_name, e.line_of_business
        ORDER BY {sort_col} DESC
        LIMIT {min(limit, 200)}
    """
    loop = asyncio.get_running_loop()
    _check_sql_breaker(request)
    try:
        rows = await loop.run_in_executor(_EXECUTOR, lambda: spark.sql(sql).toPandas().to_dict(orient="records"))
        _record_sql_success(request)
    except Exception as exc:
        _record_sql_failure(request)
        raise HTTPException(status_code=500, detail=str(exc)[:300])
    for r in rows:
        r["contracted_spend"] = float(r.get("contracted_spend") or 0)
        r["actual_spend"]     = float(r.get("actual_spend") or 0)
        r["avg_variance_pct"] = float(r.get("avg_variance_pct") or 0)
    return {"exposure": rows, "count": len(rows)}


@app.get("/api/v1/financial/exposure/{provider_name}", tags=["financial"])
async def get_provider_financial_exposure(request: Request, provider_name: str):
    """Return financial exposure detail for a specific provider."""
    spark = _get_spark(request)
    if spark is None:
        raise HTTPException(status_code=503, detail="Database unavailable", headers={"Retry-After": "10"})
    from platform.v4.config.settings import CATALOG, SCHEMA
    fe  = f"{CATALOG}.{SCHEMA}.tbl_financial_exposure"
    prf = f"{CATALOG}.{SCHEMA}.tbl_genie_provider_profile"
    safe_name = provider_name.replace("'", "''")
    sql = f"""
        SELECT p.provider_name, e.line_of_business, e.period_start, e.period_end,
               CAST(e.contracted_spend AS DOUBLE) AS contracted_spend,
               CAST(e.actual_spend     AS DOUBLE) AS actual_spend,
               e.variance_pct, e.assigned_members, e.inpatient_admits,
               e.outpatient_visits, e.estimate_confidence
        FROM {fe} e
        JOIN {prf} p ON p.provider_id = e.provider_id
        WHERE LOWER(p.provider_name) = LOWER('{safe_name}')
        ORDER BY e.period_start DESC
    """
    loop = asyncio.get_running_loop()
    _check_sql_breaker(request)
    try:
        rows = await loop.run_in_executor(_EXECUTOR, lambda: spark.sql(sql).toPandas().to_dict(orient="records"))
        _record_sql_success(request)
    except Exception as exc:
        _record_sql_failure(request)
        raise HTTPException(status_code=500, detail=str(exc)[:300])
    for r in rows:
        r["contracted_spend"] = float(r.get("contracted_spend") or 0)
        r["actual_spend"]     = float(r.get("actual_spend") or 0)
        r["period_start"]     = str(r.get("period_start") or "")
        r["period_end"]       = str(r.get("period_end") or "")
    return {"provider_name": provider_name, "exposure": rows, "count": len(rows)}


@app.get("/api/v1/financial/repricing/{provider_name}", tags=["financial"])
async def get_provider_repricing(request: Request, provider_name: str):
    """Repricing scenarios. Labels: SCENARIO_MINUS_5PCT|PLUS_3PCT|PLUS_5PCT|PLUS_10PCT"""
    spark = _get_spark(request)
    if spark is None:
        raise HTTPException(status_code=503, detail="Database unavailable", headers={"Retry-After": "10"})
    from platform.v4.config.settings import CATALOG, SCHEMA
    tbl = f"{CATALOG}.{SCHEMA}.tbl_repricing_scenarios"
    safe_name = provider_name.replace("'", "''")
    sql = f"""
        SELECT provider_name, scenario_label, rate_category,
               avg_rate, simulated_rate, rate_delta_pct,
               rate_delta, estimated_annual_impact, rate_row_count,
               CAST(simulated_at AS STRING) AS simulated_at
        FROM {tbl}
        WHERE LOWER(provider_name) = LOWER('{safe_name}')
        ORDER BY scenario_label, rate_category
    """
    loop = asyncio.get_running_loop()
    _check_sql_breaker(request)
    try:
        rows = await loop.run_in_executor(_EXECUTOR, lambda: spark.sql(sql).toPandas().to_dict(orient="records"))
        _record_sql_success(request)
    except Exception as exc:
        _record_sql_failure(request)
        raise HTTPException(status_code=500, detail=str(exc)[:300])
    for r in rows:
        r["avg_rate"]                = float(r.get("avg_rate") or 0)
        r["simulated_rate"]          = float(r.get("simulated_rate") or 0)
        r["rate_delta_pct"]          = float(r.get("rate_delta_pct") or 0)
        r["estimated_annual_impact"] = float(r.get("estimated_annual_impact") or 0)
    return {"provider_name": provider_name, "scenarios": rows, "count": len(rows)}


@app.get("/api/v1/rates/{provider_name}/history", tags=["financial"])
async def get_rate_version_history(request: Request, provider_name: str):
    """Rate supersession history. fact_supersession.provider_id ALL NULL: join via superseding_filename."""
    spark = _get_spark(request)
    if spark is None:
        raise HTTPException(status_code=503, detail="Database unavailable", headers={"Retry-After": "10"})
    from platform.v4.config.settings import CATALOG, SCHEMA
    fs  = f"{CATALOG}.{SCHEMA}.fact_supersession"
    cdm = f"{CATALOG}.{SCHEMA}.tbl_contract_documents_master"
    safe_name = provider_name.replace("'", "''")
    sql = f"""
        SELECT fs.superseding_filename, fs.superseded_filename,
               fs.superseding_effective_date, fs.superseded_effective_date,
               fs.supersession_type, fs.supersession_scope, fs.change_summary,
               fs.rate_change_pct, fs.confidence, fs.derivation_method,
               cdm.provider_name, cdm.document_status, cdm.lob_normalized
        FROM {fs} fs
        JOIN {cdm} cdm ON cdm.source_filename = fs.superseding_filename
        WHERE LOWER(cdm.provider_name) = LOWER('{safe_name}')
        ORDER BY fs.superseding_effective_date DESC
        LIMIT 50
    """
    loop = asyncio.get_running_loop()
    _check_sql_breaker(request)
    try:
        rows = await loop.run_in_executor(_EXECUTOR, lambda: spark.sql(sql).toPandas().to_dict(orient="records"))
        _record_sql_success(request)
    except Exception as exc:
        _record_sql_failure(request)
        raise HTTPException(status_code=500, detail=str(exc)[:300])
    for r in rows:
        r["superseding_effective_date"] = str(r.get("superseding_effective_date") or "")
        r["superseded_effective_date"]  = str(r.get("superseded_effective_date") or "")
        r["rate_change_pct"] = float(r.get("rate_change_pct") or 0)
        r["confidence"]      = float(r.get("confidence") or 0)
    return {"provider_name": provider_name, "history": rows, "count": len(rows)}


@app.get("/api/v1/rates/{provider_name}/escalators", tags=["financial"])
async def get_rate_escalators(request: Request, provider_name: str):
    """Rate escalator clauses from tbl_rate_escalators."""
    spark = _get_spark(request)
    if spark is None:
        raise HTTPException(status_code=503, detail="Database unavailable", headers={"Retry-After": "10"})
    from platform.v4.config.settings import CATALOG, SCHEMA
    tbl = f"{CATALOG}.{SCHEMA}.tbl_rate_escalators"
    safe_name = provider_name.replace("'", "''")
    sql = f"""
        SELECT provider_name, escalator_type, base_index, adjustment_pct,
               floor_pct, cap_pct, frequency, amendment_order,
               formula_text, source_filename
        FROM {tbl}
        WHERE LOWER(provider_name) = LOWER('{safe_name}')
        ORDER BY amendment_order DESC
    """
    loop = asyncio.get_running_loop()
    _check_sql_breaker(request)
    try:
        rows = await loop.run_in_executor(_EXECUTOR, lambda: spark.sql(sql).toPandas().to_dict(orient="records"))
        _record_sql_success(request)
    except Exception as exc:
        _record_sql_failure(request)
        raise HTTPException(status_code=500, detail=str(exc)[:300])
    for r in rows:
        r["adjustment_pct"] = float(r.get("adjustment_pct") or 0)
        r["floor_pct"]      = float(r.get("floor_pct") or 0)
        r["cap_pct"]        = float(r.get("cap_pct") or 0)
    return {"provider_name": provider_name, "escalators": rows, "count": len(rows)}


# ── Network & Geography endpoints (Phase 10B-3) ──────────────────────────────

@app.get("/api/v1/network/systems")
async def get_health_systems(request: Request):
    """All health systems with member provider counts."""
    spark = _get_spark(request)
    try:
        rows = _sql_rows(spark, """
            SELECT
                hs.system_id,
                hs.system_name,
                hs.system_type,
                hs.facility_count,
                COUNT(psm.provider_id) AS member_count
            FROM dev_adb.raw.dim_health_system hs
            LEFT JOIN dev_adb.raw.tbl_provider_system_membership psm
                ON hs.system_id = psm.system_id
            GROUP BY hs.system_id, hs.system_name, hs.system_type, hs.facility_count
            ORDER BY member_count DESC
        """)
    except Exception as exc:
        _record_sql_failure(request)
        raise HTTPException(status_code=500, detail=str(exc)[:300])
    return {
        "systems": rows,
        "count": len(rows),
        "note": "63% of providers are not mapped to any health system.",
    }


@app.get("/api/v1/network/systems/{system_name}")
async def get_system_members(system_name: str, request: Request):
    """Providers belonging to a specific health system."""
    spark = _get_spark(request)
    safe_name = system_name.replace("'", "''")
    try:
        rows = _sql_rows(spark, f"""
            SELECT
                p.canonical_name AS provider_name,
                p.provider_id,
                psm.membership_type,
                psm.effective_date,
                psm.source
            FROM dev_adb.raw.tbl_provider_system_membership psm
            JOIN dev_adb.raw.dim_provider_canonical p
                ON psm.provider_id = p.provider_id
            JOIN dev_adb.raw.dim_health_system hs
                ON psm.system_id = hs.system_id
            WHERE LOWER(hs.system_name) LIKE LOWER('%{safe_name}%')
            ORDER BY p.canonical_name
        """)
    except Exception as exc:
        _record_sql_failure(request)
        raise HTTPException(status_code=500, detail=str(exc)[:300])
    for r in rows:
        if r.get("effective_date"):
            r["effective_date"] = str(r["effective_date"])
    return {
        "system_name": system_name,
        "members": rows,
        "count": len(rows),
        "note": "Showing mapped providers only (63% of providers are unaffiliated).",
    }


@app.get("/api/v1/network/{provider_name}/membership")
async def get_provider_system_membership(provider_name: str, request: Request):
    """Which health system(s) a provider belongs to."""
    spark = _get_spark(request)
    safe_name = provider_name.replace("'", "''")
    try:
        rows = _sql_rows(spark, f"""
            SELECT
                hs.system_id,
                hs.system_name,
                hs.system_type,
                hs.facility_count,
                psm.membership_type,
                psm.effective_date,
                psm.source
            FROM dev_adb.raw.tbl_provider_system_membership psm
            JOIN dev_adb.raw.dim_health_system hs
                ON psm.system_id = hs.system_id
            JOIN dev_adb.raw.dim_provider_canonical p
                ON psm.provider_id = p.provider_id
            WHERE LOWER(p.provider_name) LIKE LOWER('%{safe_name}%')
        """)
    except Exception as exc:
        _record_sql_failure(request)
        raise HTTPException(status_code=500, detail=str(exc)[:300])
    for r in rows:
        if r.get("effective_date"):
            r["effective_date"] = str(r["effective_date"])
    affiliated = len(rows) > 0
    return {
        "provider_name": provider_name,
        "affiliated": affiliated,
        "memberships": rows,
        "count": len(rows),
        "note": None if affiliated else "Provider is not affiliated with any tracked health system.",
    }


@app.get("/api/v1/network/{provider_name}/service-area")
async def get_provider_service_area(provider_name: str, request: Request):
    """Geographic service area for a provider."""
    spark = _get_spark(request)
    safe_name = provider_name.replace("'", "''")
    try:
        rows = _sql_rows(spark, f"""
            SELECT
                sa.provider_id,
                sa.provider_name,
                sa.region,
                sa.county,
                sa.assignment_method
            FROM dev_adb.raw.tbl_service_areas sa
            WHERE LOWER(sa.provider_name) LIKE LOWER('%{safe_name}%')
            ORDER BY sa.provider_name
        """)
    except Exception as exc:
        _record_sql_failure(request)
        raise HTTPException(status_code=500, detail=str(exc)[:300])
    return {
        "provider_name": provider_name,
        "service_areas": rows,
        "count": len(rows),
    }



# ── Compliance & Quality endpoints (Phase 10B-4) ─────────────────────────────

@app.get("/api/v1/compliance/summary")
async def get_compliance_summary(request: Request):
    """Overall compliance status distribution across all regulations."""
    spark = _get_spark(request)
    try:
        rows = _sql_rows(spark, """
            SELECT regulation,
                   compliance_status,
                   COUNT(*) AS provider_count,
                   ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER (PARTITION BY regulation), 1)
                       AS pct_of_regulation
            FROM dev_adb.raw.tbl_compliance_tracking
            GROUP BY regulation, compliance_status
            ORDER BY regulation, provider_count DESC
        """)
    except Exception as exc:
        _record_sql_failure(request)
        raise HTTPException(status_code=500, detail=str(exc)[:300])
    return {
        "compliance_by_regulation": rows,
        "count": len(rows),
        "note": (
            "PARTIAL/UNKNOWN does not mean non-compliant — it means contractual language "
            "was not found or only partially found by extraction. "
            "compliance_status values: PARTIAL | UNKNOWN | COMPLIANT | EXEMPT"
        ),
    }


@app.get("/api/v1/compliance/{provider_name}")
async def get_provider_compliance(provider_name: str, request: Request):
    """Regulatory compliance status for a specific provider."""
    spark = _get_spark(request)
    safe = provider_name.replace("'", "''")
    try:
        rows = _sql_rows(spark, f"""
            SELECT regulation, requirement_category, compliance_status,
                   risk_level, evidence_text, source_filename, amendment_order
            FROM dev_adb.raw.tbl_compliance_tracking
            WHERE LOWER(provider_name) LIKE LOWER('%{safe}%')
            ORDER BY regulation, compliance_status
        """)
    except Exception as exc:
        _record_sql_failure(request)
        raise HTTPException(status_code=500, detail=str(exc)[:300])
    compliant  = sum(1 for r in rows if r.get("compliance_status") == "COMPLIANT")
    partial    = sum(1 for r in rows if r.get("compliance_status") == "PARTIAL")
    unknown    = sum(1 for r in rows if r.get("compliance_status") == "UNKNOWN")
    return {
        "provider_name": provider_name,
        "compliance_records": rows,
        "count": len(rows),
        "summary": {"compliant": compliant, "partial": partial, "unknown": unknown},
    }


@app.get("/api/v1/quality/{provider_name}")
async def get_provider_quality(provider_name: str, request: Request):
    """Quality performance program terms for a provider."""
    spark = _get_spark(request)
    safe = provider_name.replace("'", "''")
    try:
        rows = _sql_rows(spark, f"""
            SELECT program_name, metric_name, target_value,
                   penalty_pct, bonus_pct, payment_mechanism, formula_text
            FROM dev_adb.raw.tbl_quality_performance
            WHERE LOWER(provider_name) LIKE LOWER('%{safe}%')
            ORDER BY program_name
        """)
    except Exception as exc:
        _record_sql_failure(request)
        raise HTTPException(status_code=500, detail=str(exc)[:300])
    for r in rows:
        for k in ("penalty_pct", "bonus_pct", "target_value"):
            if r.get(k) is not None:
                try:
                    r[k] = float(r[k])
                except (TypeError, ValueError):
                    pass
    return {
        "provider_name": provider_name,
        "quality_programs": rows,
        "count": len(rows),
        "note": "bonus_pct/penalty_pct are NULL for contracts that express values as prose.",
    }


@app.get("/api/v1/notifications/{provider_name}")
async def get_provider_notifications(provider_name: str, request: Request):
    """Contract notification requirements for a provider."""
    spark = _get_spark(request)
    safe = provider_name.replace("'", "''")
    try:
        rows = _sql_rows(spark, f"""
            SELECT notification_type, trigger_event, notice_days,
                   notice_direction, delivery_method, cure_period_days, notice_text
            FROM dev_adb.raw.tbl_contract_notifications
            WHERE LOWER(provider_name) LIKE LOWER('%{safe}%')
            ORDER BY notification_type
        """)
    except Exception as exc:
        _record_sql_failure(request)
        raise HTTPException(status_code=500, detail=str(exc)[:300])
    return {
        "provider_name": provider_name,
        "notifications": rows,
        "count": len(rows),
    }



# ── Clause Intelligence endpoints (Phase 10B-5) ──────────────────────────────

@app.get("/api/v1/clauses/{provider_name}")
async def get_provider_clauses(
    provider_name: str,
    request: Request,
    category: str = None,
    current_only: bool = True,
):
    """Verbatim clause text for a provider. Filter by ?category=OFFSET_CLAUSE&current_only=true."""
    spark = _get_spark(request)
    safe = provider_name.replace("'", "''")
    cat_filter  = f"AND clause_category = '{category.upper()}'" if category else ""
    curr_filter = "AND is_current = true" if current_only else ""
    try:
        rows = _sql_rows(spark, f"""
            SELECT provider_name, clause_category, clause_subcategory,
                   clause_status, clause_text, amendment_order,
                   source_filename, extraction_method
            FROM dev_adb.raw.tbl_contract_clauses
            WHERE LOWER(provider_name) LIKE LOWER('%{safe}%')
              AND clause_status = 'HAS'
              {cat_filter}
              {curr_filter}
            ORDER BY clause_category
            LIMIT 25
        """)
    except Exception as exc:
        _record_sql_failure(request)
        raise HTTPException(status_code=500, detail=str(exc)[:300])
    return {
        "provider_name": provider_name,
        "clauses": rows,
        "count": len(rows),
        "filters": {"category": category, "current_only": current_only},
        "note": "clause_status=HAS only. FALSE_POSITIVE rows excluded.",
    }


@app.get("/api/v1/clauses/{provider_name}/summary")
async def get_provider_clause_summary(provider_name: str, request: Request):
    """All 21 clause categories with counts for a provider."""
    spark = _get_spark(request)
    safe = provider_name.replace("'", "''")
    try:
        rows = _sql_rows(spark, f"""
            SELECT clause_category,
                   COUNT(*) AS total_rows,
                   SUM(CASE WHEN clause_status = 'HAS' THEN 1 ELSE 0 END) AS has_count,
                   SUM(CASE WHEN is_current THEN 1 ELSE 0 END) AS current_count,
                   MAX(amendment_order) AS latest_amendment
            FROM dev_adb.raw.tbl_contract_clauses
            WHERE LOWER(provider_name) LIKE LOWER('%{safe}%')
            GROUP BY clause_category
            ORDER BY clause_category
        """)
    except Exception as exc:
        _record_sql_failure(request)
        raise HTTPException(status_code=500, detail=str(exc)[:300])
    return {
        "provider_name": provider_name,
        "categories": rows,
        "count": len(rows),
    }


@app.get("/api/v1/clauses/network/{category}")
async def get_network_clause_norms(category: str, request: Request):
    """Network-wide stats for a clause category (% of providers with HAS)."""
    spark = _get_spark(request)
    safe_cat = category.upper().replace(" ", "_")
    try:
        rows = _sql_rows(spark, f"""
            SELECT provider_name, clause_status, network_baseline,
                   network_has_pct, network_absent_pct,
                   deviation_type, severity
            FROM dev_adb.raw.tbl_clause_deviations
            WHERE clause_category = '{safe_cat}'
            ORDER BY severity DESC, provider_name
        """)
    except Exception as exc:
        _record_sql_failure(request)
        raise HTTPException(status_code=500, detail=str(exc)[:300])
    for r in rows:
        for k in ("network_has_pct", "network_absent_pct"):
            if r.get(k) is not None:
                r[k] = float(r[k])
    deviations = [r for r in rows if r.get("deviation_type") == "DEVIATION"]
    conformant  = [r for r in rows if r.get("deviation_type") == "CONFORMANT"]
    network_pct = rows[0]["network_has_pct"] if rows else None
    return {
        "category": safe_cat,
        "providers": rows,
        "count": len(rows),
        "network_has_pct": network_pct,
        "deviations": len(deviations),
        "conformant": len(conformant),
    }


@app.get("/api/v1/clauses/{provider_name}/deviations")
async def get_provider_deviations(provider_name: str, request: Request):
    """How a provider deviates from network norms across all 21 clause categories."""
    spark = _get_spark(request)
    safe = provider_name.replace("'", "''")
    try:
        rows = _sql_rows(spark, f"""
            SELECT clause_category, clause_status, network_baseline,
                   network_has_pct, network_absent_pct, deviation_type, severity
            FROM dev_adb.raw.tbl_clause_deviations
            WHERE LOWER(provider_name) LIKE LOWER('%{safe}%')
            ORDER BY severity DESC, clause_category
        """)
    except Exception as exc:
        _record_sql_failure(request)
        raise HTTPException(status_code=500, detail=str(exc)[:300])
    for r in rows:
        for k in ("network_has_pct", "network_absent_pct"):
            if r.get(k) is not None:
                r[k] = float(r[k])
    deviations = [r for r in rows if r.get("deviation_type") == "DEVIATION"]
    return {
        "provider_name": provider_name,
        "deviations": rows,
        "count": len(rows),
        "deviation_count": len(deviations),
        "note": "CONFORMANT = matches network norm. DEVIATION = outlier vs network.",
    }



# ── Provenance & Audit (Phase 10B-6) ─────────────────────────────────────────

@app.get("/api/v1/provenance/summary")
async def provenance_summary():
    """Fleet-wide extraction audit — all tables, methods, confidence bands."""
    def _run():
        tool = _get_tool("provenance")
        return tool._run(query_type="extraction_summary")
    result = await asyncio.get_event_loop().run_in_executor(_executor, _run)
    if not result.success:
        raise HTTPException(status_code=500, detail=result.summary)
    return {
        "data":    result.data,
        "summary": result.summary,
        "total_extractions": sum(r.get("extraction_count", 0) for r in result.data),
    }


@app.get("/api/v1/provenance/{provider_name}")
async def provider_provenance(
    provider_name: str,
    target_table: str = "",
    limit: int = 50,
):
    """All extraction provenance records for a provider, optionally filtered by table."""
    def _run():
        tool = _get_tool("provenance")
        return tool._run(
            query_type="provider_provenance",
            provider=provider_name,
            target_table=target_table,
            limit=limit,
        )
    result = await asyncio.get_event_loop().run_in_executor(_executor, _run)
    if not result.success:
        raise HTTPException(status_code=500, detail=result.summary)
    return {
        "provider": provider_name,
        "data":     result.data,
        "summary":  result.summary,
    }


@app.get("/api/v1/provenance/document/{filename:path}")
async def document_lineage(filename: str, limit: int = 50):
    """Supersession chain for a specific document filename."""
    def _run():
        tool = _get_tool("provenance")
        return tool._run(
            query_type="document_lineage",
            filename=filename,
            limit=limit,
        )
    result = await asyncio.get_event_loop().run_in_executor(_executor, _run)
    if not result.success:
        raise HTTPException(status_code=500, detail=result.summary)
    return {
        "filename": filename,
        "data":     result.data,
        "summary":  result.summary,
    }


@app.get("/api/v1/provenance/quality")
async def extraction_quality(target_table: str = ""):
    """Per-table confidence and quality stats across all extractions."""
    def _run():
        tool = _get_tool("provenance")
        return tool._run(
            query_type="extraction_quality",
            target_table=target_table,
        )
    result = await asyncio.get_event_loop().run_in_executor(_executor, _run)
    if not result.success:
        raise HTTPException(status_code=500, detail=result.summary)
    return {
        "target_table": target_table or "all",
        "data":         result.data,
        "summary":      result.summary,
    }


# ── Static asset serving (Phase 4, Step 4.2) ─────────────────────────────────
# Serves the React frontend build from app/static/.
# Vite builds into ../app/static (relative to frontend/).

_STATIC_DIR = Path(__file__).parent / "static"

if _STATIC_DIR.exists() and (_STATIC_DIR / "assets").exists():
    # Mount /assets for JS, CSS and other hashed build artefacts.
    app.mount("/assets", StaticFiles(directory=str(_STATIC_DIR / "assets")), name="static-assets")

    @app.get("/favicon.svg", include_in_schema=False)
    async def favicon():
        """Serve the Contract Intelligence favicon.

        Must be an explicit route — the /{full_path:path} SPA fallback below
        would otherwise return index.html (text/html) for /favicon.svg,
        causing the browser to display a broken icon.
        """
        _fav = _STATIC_DIR / "favicon.svg"
        if _fav.exists():
            return FileResponse(str(_fav), media_type="image/svg+xml")
        raise HTTPException(status_code=404, detail="favicon.svg not found")

    @app.get("/favicon.ico", include_in_schema=False)
    async def favicon_ico():
        """Redirect legacy .ico requests to the SVG favicon."""
        from fastapi.responses import RedirectResponse
        return RedirectResponse(url="/favicon.svg", status_code=301)

    @app.get("/{full_path:path}", include_in_schema=False)
    async def spa_fallback(full_path: str):
        """SPA fallback: serve index.html for all unmatched routes."""
        index = _STATIC_DIR / "index.html"
        if index.exists():
            return FileResponse(str(index))
        raise HTTPException(status_code=404, detail="Frontend not built")


# ── Dev runner ────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
