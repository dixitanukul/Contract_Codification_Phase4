"""
V2 Step 3: V1 → V2 Reimbursement Data Migration
=================================================
Migrates V1 tables into V2 schema with corrected column mappings.
Adaptations from original V2_REIMB_02_migration.sql:
  - tbl_contract_rates_all: no lesser_of_language col → derive from rate_text/formula
  - tbl_contract_financial_protections: no applies_to_services → use sub_type
  - tbl_serving_capitation_card: flat schema (age_gender_band, pmpm_rate) not multi-year

P1-10: Replaced uuid() with sha2(concat_ws('|', ...)) for deterministic IDs.
       rule_id, stop_loss_id, carve_out_id, lesser_of_id are now stable across reruns.
       FK subqueries use ORDER BY for deterministic LIMIT 1.
P1-11: TRUNCATE TABLE + INSERT INTO → INSERT OVERWRITE (atomic idempotency).
       Migration 4a uses INSERT INTO (appends capitation after M1's OVERWRITE).

Run AFTER: 01_execute_ddl.py
Run BEFORE: 02_state_engine.py
"""

from datetime import datetime
from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()

CATALOG = "dev_adb"
SCHEMA = "raw"
FQ = f"{CATALOG}.{SCHEMA}"


def log_step(name, status, details=""):
    ts = datetime.now().strftime("%H:%M:%S")
    icon = "✓" if status == "SUCCESS" else "✗" if status == "FAILED" else "○"
    print(f"[{ts}] {icon} {name}: {status}")
    if details:
        print(f"    {details}")


def run_sql(stmt, desc=""):
    """Execute SQL, return result or None on error."""
    try:
        return spark.sql(stmt)
    except Exception as e:
        print(f"  ERROR ({desc}): {str(e)[:200]}")
        return None


def table_exists(table_name):
    return spark.catalog.tableExists(table_name)


def main():
    print("=" * 60)
    print("V2 REIMBURSEMENT MIGRATION — V1 → V2")
    print(f"  Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)

    spark.sql(f"USE CATALOG {CATALOG}")
    spark.sql(f"USE SCHEMA {SCHEMA}")

    # P1-11: INSERT OVERWRITE handles idempotency atomically (no separate TRUNCATE).
    # Each migration below overwrites its target table in a single statement.
    # Migration 4a (capitation) appends via INSERT INTO after M1's OVERWRITE.

    # ============================================================
    # MIGRATION 1: tbl_contract_rates_all → tbl_reimb_rate_rules
    # ============================================================
    log_step("Migration 1: Rates → rate_rules", "RUNNING")

    migration_1 = f"""
    INSERT OVERWRITE {FQ}.tbl_reimb_rate_rules (
        rule_id, contract_id, provider_id, provider_name,
        rate_domain, service_line, service_category_raw,
        formula_type, formula_json,
        rate_numeric, rate_text, rate_unit,
        program, network, revenue_codes, procedure_codes, drg_codes,
        source_filename, exhibit_reference, effective_date,
        has_stop_loss, has_carve_outs, has_escalator, has_conditions,
        extracted_at, confidence_score
    )
    SELECT
        -- P1-10: deterministic rule_id (stable across reruns, preserves FK integrity)
        sha2(concat_ws('|', r.provider_id, r.source_filename, COALESCE(r.rate_category, ''), COALESCE(r.service_category, ''), COALESCE(CAST(r.rate_numeric AS STRING), '')), 256) AS rule_id,
        sha2(concat_ws('|', r.provider_id, r.source_filename), 256) AS contract_id,
        r.provider_id,
        r.provider_name,
        CASE
            WHEN r.rate_category ILIKE '%inpatient%' OR r.rate_category ILIKE '%per_diem%' THEN 'INPATIENT'
            WHEN r.rate_category ILIKE '%outpatient%' OR r.rate_category ILIKE '%ambulatory%' THEN 'OUTPATIENT'
            WHEN r.rate_category ILIKE '%capitation%' OR r.rate_category ILIKE '%pmpm%' THEN 'CAPITATION'
            WHEN r.rate_category ILIKE '%professional%' OR r.rate_category ILIKE '%physician%' THEN 'PROFESSIONAL'
            ELSE 'INPATIENT'
        END AS rate_domain,
        COALESCE(r.service_category, 'Unclassified') AS service_line,
        r.service_category AS service_category_raw,
        CASE
            WHEN r.formula ILIKE '%DRG%' OR r.formula ILIKE '%drg%weight%' THEN 'DRG_WEIGHTED'
            WHEN r.formula ILIKE '%CF%' OR r.formula ILIKE '%conversion%factor%' THEN 'CONVERSION_FACTOR'
            WHEN r.rate_category ILIKE '%per_diem%' OR r.rate_category ILIKE '%per diem%' THEN 'PER_DIEM'
            -- P1-3 guard: only classify as PERCENTAGE when the value is actually a ratio (<100)
            -- and the rate_text doesn't start with a dollar sign (which signals a dollar amount)
            WHEN (r.formula ILIKE '%percent%' OR r.formula ILIKE '%pct%' OR r.rate_category ILIKE '%pct%')
                 AND COALESCE(CAST(r.rate_numeric AS DOUBLE), 0) < 100
                 AND r.rate_text NOT LIKE '$%'             THEN 'PERCENTAGE'
            WHEN r.rate_text ILIKE '%lesser%of%' OR r.formula ILIKE '%lesser%' THEN 'LESSER_OF'
            WHEN r.rate_category ILIKE '%case_rate%' OR r.rate_category ILIKE '%case rate%' THEN 'FIXED'
            WHEN r.rate_category ILIKE '%capitation%' THEN 'FIXED'
            ELSE 'FIXED'
        END AS formula_type,
        CASE
            WHEN r.formula ILIKE '%DRG%' THEN
                concat('{{"formula_type":"DRG_WEIGHTED","base_rate":', COALESCE(CAST(r.rate_numeric AS STRING), '0'), ',"weight_source":"CMS_DRG_WEIGHTS"}}')
            WHEN r.formula ILIKE '%CF%' THEN
                concat('{{"formula_type":"CONVERSION_FACTOR","conversion_factor":', COALESCE(CAST(r.rate_numeric AS STRING), '0'), ',"multiplied_by":"RVU"}}')
            WHEN r.rate_category ILIKE '%per_diem%' OR r.rate_category ILIKE '%per diem%' THEN
                concat('{{"formula_type":"PER_DIEM","base_rate":', COALESCE(CAST(r.rate_numeric AS STRING), '0'), ',"unit":"day"}}')
            -- P1-3 guard: same condition as formula_type branch above
            WHEN (r.formula ILIKE '%percent%' OR r.formula ILIKE '%pct%')
                 AND COALESCE(CAST(r.rate_numeric AS DOUBLE), 0) < 100
                 AND r.rate_text NOT LIKE '$%' THEN
                concat('{{"formula_type":"PERCENTAGE","percentage":', COALESCE(CAST(r.rate_numeric AS STRING), '0'), ',"of":"BILLED_CHARGES"}}')
            WHEN r.rate_text ILIKE '%lesser%of%' OR r.formula ILIKE '%lesser%' THEN
                concat('{{"formula_type":"LESSER_OF","operands":[{{"formula_type":"FIXED","amount":', COALESCE(CAST(r.rate_numeric AS STRING), '0'), '}},{{"formula_type":"REFERENCE","reference":"BILLED_CHARGES"}}]}}')
            ELSE
                concat('{{"formula_type":"FIXED","amount":', COALESCE(CAST(r.rate_numeric AS STRING), '0'), '}}')
        END AS formula_json,
        r.rate_numeric,
        r.rate_text,
        CASE
            WHEN r.rate_category ILIKE '%per_diem%' THEN 'day'
            WHEN r.rate_category ILIKE '%capitation%' THEN 'member_month'
            WHEN r.rate_category ILIKE '%case_rate%' THEN 'case'
            ELSE 'case'
        END AS rate_unit,
        r.program_normalized AS program,
        r.network,
        r.revenue_codes,
        NULL AS procedure_codes,
        NULL AS drg_codes,
        r.source_filename,
        NULL AS exhibit_reference,
        r.effective_date_parsed AS effective_date,
        FALSE AS has_stop_loss,
        FALSE AS has_carve_outs,
        FALSE AS has_escalator,
        FALSE AS has_conditions,
        current_timestamp() AS extracted_at,
        0.7 AS confidence_score
    FROM {FQ}.tbl_contract_rates_all r
    WHERE r.status = 'current'
    """

    run_sql(migration_1, "rates migration")
    count_1 = spark.sql(f"SELECT COUNT(*) AS n FROM {FQ}.tbl_reimb_rate_rules").collect()[0]["n"]
    log_step("Migration 1: Rates", "SUCCESS", f"{count_1} rules created")

    # ============================================================
    # P1-3: POST-MIGRATION PERCENTAGE MISCLASSIFICATION CORRECTION
    # Self-healing block: catches any dollar amounts that slipped through
    # the PERCENTAGE guard due to NULL rate_numeric or edge-case rate_text.
    # Two sub-fixes:
    #   A) CAPITATION domain: dollar PMPM values (e.g. $519.51, $184.08)
    #      → FIXED with unit=member_month (matches Migration 4 capitation format)
    #   B) All other domains: dollar amounts (e.g. $5,571 outpatient case rate)
    #      → FIXED plain amount
    # ============================================================
    log_step("P1-3: PERCENTAGE correction", "RUNNING")

    fix_pct_capitation = f"""
        UPDATE {FQ}.tbl_reimb_rate_rules
        SET
            formula_type = 'FIXED',
            formula_json = concat(
                '{{"formula_type":"FIXED","amount":',
                CAST(rate_numeric AS STRING),
                ',"unit":"member_month"}}'
            )
        WHERE formula_type = 'PERCENTAGE'
          AND rate_domain = 'CAPITATION'
          AND CAST(get_json_object(formula_json, '$.percentage') AS DOUBLE) > 100
    """

    fix_pct_other = f"""
        UPDATE {FQ}.tbl_reimb_rate_rules
        SET
            formula_type = 'FIXED',
            formula_json = concat(
                '{{"formula_type":"FIXED","amount":',
                CAST(rate_numeric AS STRING),
                '}}'
            )
        WHERE formula_type = 'PERCENTAGE'
          AND rate_domain != 'CAPITATION'
          AND CAST(get_json_object(formula_json, '$.percentage') AS DOUBLE) > 100
    """

    run_sql(fix_pct_capitation, "P1-3 PERCENTAGE→FIXED capitation")
    run_sql(fix_pct_other, "P1-3 PERCENTAGE→FIXED other domains")

    remaining_pct = spark.sql(f"""
        SELECT COUNT(*) AS n FROM {FQ}.tbl_reimb_rate_rules
        WHERE formula_type = 'PERCENTAGE'
          AND CAST(get_json_object(formula_json, '$.percentage') AS DOUBLE) > 100
    """).collect()[0]["n"]
    log_step(
        "P1-3: PERCENTAGE correction",
        "SUCCESS" if remaining_pct == 0 else "WARN",
        f"Misclassified rows remaining: {remaining_pct} (expect 0)"
    )

    # ============================================================
    # MIGRATION 2: Financial protections → tbl_reimb_stop_loss
    # ============================================================
    log_step("Migration 2: Stop-loss", "RUNNING")

    # P1-4 FIX: Stop-loss column confusion (days vs dollars).
    # Problem: sub_type='per_diem_stop_loss' has 2 distinct semantics:
    #   A) threshold < 100 → threshold is DAY COUNT, reimbursement_pct is $/day rate
    #      e.g. "After 3 days, plan pays $1,500/day" → attachment_unit=TOTAL_DAYS,
    #      reimburse_rate=$1500, reimburse_percentage=NULL
    #   B) threshold >= 100 AND reimbursement_pct > 100 → both are DOLLAR amounts
    #      e.g. "Stop-loss at $25K charges, cap $50K" → attachment stays dollars,
    #      reimburse_rate=dollar_cap, reimburse_percentage=NULL
    #   C) All others (reimburse_pct <= 100 or NULL) → correct as-is
    migration_2 = f"""
    INSERT OVERWRITE {FQ}.tbl_reimb_stop_loss (
        stop_loss_id, rule_id, contract_id, provider_id,
        stop_loss_type, attachment_level, attachment_unit,
        reimburse_formula_type, reimburse_rate, reimburse_percentage,
        aggregate_cap, corridor_amount,
        applies_to_services, revenue_codes,
        source_filename, exhibit_reference, effective_date
    )
    SELECT
        -- P1-10: deterministic stop_loss_id
        sha2(concat_ws('|', fp.provider_id, fp.source_filename, COALESCE(fp.protection_type, ''), COALESCE(fp.sub_type, ''), COALESCE(CAST(fp.threshold_numeric AS STRING), '')), 256) AS stop_loss_id,
        -- P1-10: deterministic FK lookup (ORDER BY ensures stable LIMIT 1)
        COALESCE(
            (SELECT rr.rule_id FROM {FQ}.tbl_reimb_rate_rules rr
             WHERE rr.provider_id = fp.provider_id AND rr.rate_domain = 'INPATIENT'
             ORDER BY rr.rule_id
             LIMIT 1),
            'UNLINKED'
        ) AS rule_id,
        sha2(concat_ws('|', fp.provider_id, fp.source_filename), 256) AS contract_id,
        fp.provider_id,
        -- P1-4: per_diem_stop_loss with day thresholds → PER_DIEM type
        CASE
            WHEN fp.sub_type ILIKE '%per_diem%' AND fp.threshold_numeric < 100 THEN 'PER_DIEM'
            WHEN fp.protection_type ILIKE '%per diem%' OR fp.protection_type ILIKE '%per_diem%' THEN 'PER_DIEM'
            WHEN fp.protection_type ILIKE '%aggregate%' OR fp.protection_type ILIKE '%annual%' THEN 'AGGREGATE'
            WHEN fp.protection_type ILIKE '%corridor%' THEN 'CORRIDOR'
            ELSE 'CASE_RATE'
        END AS stop_loss_type,
        try_cast(fp.threshold_numeric AS FLOAT) AS attachment_level,
        -- P1-4: Classify attachment_unit based on threshold semantics
        CASE
            WHEN fp.sub_type ILIKE '%per_diem%' AND fp.threshold_numeric < 100 THEN 'TOTAL_DAYS'
            ELSE 'TOTAL_CHARGES'
        END AS attachment_unit,
        -- P1-4: Correctly classify reimbursement formula
        CASE
            WHEN fp.sub_type ILIKE '%per_diem%' AND fp.threshold_numeric < 100 THEN 'FIXED_PER_DIEM'
            WHEN fp.reimbursement_pct_numeric > 100 THEN 'CHARGES_LESS_THRESHOLD'
            WHEN fp.reimbursement_pct_numeric IS NOT NULL THEN 'PERCENTAGE'
            ELSE 'FIXED_PER_DIEM'
        END AS reimburse_formula_type,
        -- P1-4: Dollar amounts that were in reimburse_percentage → reimburse_rate
        CASE
            WHEN fp.sub_type ILIKE '%per_diem%' AND fp.threshold_numeric < 100
                THEN try_cast(fp.reimbursement_pct_numeric AS FLOAT)  -- $/day rate
            WHEN fp.reimbursement_pct_numeric > 100
                THEN try_cast(fp.reimbursement_pct_numeric AS FLOAT)  -- dollar cap
            ELSE NULL
        END AS reimburse_rate,
        -- P1-4: Only true percentages stay in reimburse_percentage
        CASE
            WHEN fp.reimbursement_pct_numeric IS NOT NULL AND fp.reimbursement_pct_numeric <= 100
                 AND NOT (fp.sub_type ILIKE '%per_diem%' AND fp.threshold_numeric < 100)
                THEN try_cast(fp.reimbursement_pct_numeric AS FLOAT)
            ELSE NULL
        END AS reimburse_percentage,
        try_cast(fp.aggregate_cap AS FLOAT) AS aggregate_cap,
        try_cast(fp.corridor AS FLOAT) AS corridor_amount,
        fp.sub_type AS applies_to_services,
        fp.revenue_codes,
        fp.source_filename,
        fp.exhibit_reference,
        fp.effective_date_parsed AS effective_date
    FROM {FQ}.tbl_contract_financial_protections fp
    WHERE fp.protection_type ILIKE '%stop%loss%'
       OR fp.protection_type ILIKE '%outlier%'
       OR fp.protection_type ILIKE '%threshold%'
    """

    run_sql(migration_2, "stop-loss migration")
    count_2 = spark.sql(f"SELECT COUNT(*) AS n FROM {FQ}.tbl_reimb_stop_loss").collect()[0]["n"]
    log_step("Migration 2: Stop-loss", "SUCCESS", f"{count_2} provisions created")

    # ============================================================
    # MIGRATION 3: Financial protections → tbl_reimb_carve_outs
    # ============================================================
    log_step("Migration 3: Carve-outs", "RUNNING")

    # P1-5 FIX: The original filter required protection_type ILIKE '%carve%' etc.,
    # but actual data uses protection_type='exception' for ALL carve-out provisions.
    # The 4,174 exception rows include implants, drugs, devices, and procedures
    # that are billed separately outside the base case rate.
    # Carve-out type is now derived from sub_type (which carries the specific service name)
    # rather than protection_type (which is always 'exception').
    migration_3 = f"""
    INSERT OVERWRITE {FQ}.tbl_reimb_carve_outs (
        carve_out_id, contract_id, provider_id,
        carve_out_type, description,
        threshold_amount, threshold_type,
        reimburse_formula_type, reimburse_percentage, reimburse_fixed, reimburse_of,
        base_rule_id, relationship,
        revenue_codes, procedure_codes, ndc_codes,
        source_filename, effective_date
    )
    SELECT
        -- P1-10: deterministic carve_out_id
        sha2(concat_ws('|', fp.provider_id, fp.source_filename, 'CARVEOUT', COALESCE(fp.sub_type, ''), COALESCE(CAST(fp.threshold_numeric AS STRING), '')), 256) AS carve_out_id,
        sha2(concat_ws('|', fp.provider_id, fp.source_filename), 256) AS contract_id,
        fp.provider_id,
        -- P1-5: classify from sub_type (the specific carve-out service name)
        CASE
            WHEN fp.sub_type ILIKE '%implant%'
              OR fp.sub_type ILIKE '%prosthetic%'
              OR fp.sub_type ILIKE '%orthotic%'
              OR fp.sub_type ILIKE '%pacemaker%'
              OR fp.sub_type ILIKE '%stent%'
              OR fp.sub_type ILIKE '%aicd%'
              OR fp.sub_type ILIKE '%brachytherapy%'
              OR fp.sub_type ILIKE '%hip replacement%'
              OR fp.sub_type ILIKE '%knee replacement%'
              OR fp.sub_type ILIKE '%spinal fusion%'
              OR fp.sub_type ILIKE '%bi-ventricular%'
              OR fp.sub_type ILIKE '%biventricular%'        THEN 'IMPLANT'
            WHEN fp.sub_type ILIKE '%device%'               THEN 'DEVICE'
            WHEN fp.sub_type ILIKE '%drug%'
              OR fp.sub_type ILIKE '%pharm%'
              OR fp.sub_type ILIKE '%medication%'
              OR fp.sub_type ILIKE '%ndc%'
              OR fp.sub_type ILIKE '%rx%'                   THEN 'DRUG'
            WHEN fp.sub_type ILIKE '%dialysis%'
              OR fp.sub_type ILIKE '%hemodialysis%'
              OR fp.sub_type ILIKE '%laborator%'
              OR fp.sub_type ILIKE '% lab %'
              OR fp.sub_type ILIKE '%clinic visit%'
              OR fp.sub_type ILIKE '%therapy%'
              OR fp.sub_type ILIKE '%radiation%'
              OR fp.sub_type ILIKE '%transplant%'           THEN 'PROCEDURE'
            WHEN fp.sub_type ILIKE '%supply%'
              OR fp.sub_type ILIKE '%supplies%'             THEN 'SUPPLY'
            ELSE 'SUPPLY'  -- safe fallback for 'other' and unmapped sub_types
        END AS carve_out_type,
        COALESCE(fp.threshold_text, fp.sub_type) AS description,
        try_cast(fp.threshold_numeric AS FLOAT) AS threshold_amount,
        CASE
            WHEN fp.sub_type ILIKE '%dialysis%'
              OR fp.sub_type ILIKE '%hemodialysis%'
              OR fp.sub_type ILIKE '%clinic visit%'
              OR fp.sub_type ILIKE '%therapy%'  THEN 'PER_SERVICE'
            WHEN fp.sub_type ILIKE '%drug%'
              OR fp.sub_type ILIKE '%pharm%'    THEN 'PER_DISPENSE'
            ELSE 'PER_ITEM'
        END AS threshold_type,
        CASE
            WHEN fp.threshold_text ILIKE '%cost%plus%'
              OR fp.threshold_text ILIKE '%cost +%'         THEN 'COST_PLUS'
            WHEN fp.reimbursement_pct_numeric IS NOT NULL
              AND CAST(fp.reimbursement_pct_numeric AS DOUBLE) <= 100 THEN 'PERCENTAGE'
            WHEN fp.reimbursement_pct_numeric IS NOT NULL
              AND CAST(fp.reimbursement_pct_numeric AS DOUBLE) > 100  THEN 'FIXED_AMOUNT'
            ELSE 'COST_PLUS'
        END AS reimburse_formula_type,
        CASE
            WHEN fp.reimbursement_pct_numeric IS NOT NULL
              AND CAST(fp.reimbursement_pct_numeric AS DOUBLE) <= 100
            THEN try_cast(fp.reimbursement_pct_numeric AS FLOAT)
            ELSE NULL
        END AS reimburse_percentage,
        CASE
            WHEN fp.reimbursement_pct_numeric IS NOT NULL
              AND CAST(fp.reimbursement_pct_numeric AS DOUBLE) > 100
            THEN try_cast(fp.reimbursement_pct_numeric AS FLOAT)
            ELSE NULL
        END AS reimburse_fixed,
        'INVOICE_COST' AS reimburse_of,
        NULL AS base_rule_id,
        'ADDITIONAL_TO' AS relationship,
        fp.revenue_codes,
        NULL AS procedure_codes,
        NULL AS ndc_codes,
        fp.source_filename,
        fp.effective_date_parsed AS effective_date
    FROM {FQ}.tbl_contract_financial_protections fp
    WHERE fp.protection_type = 'exception'
      AND fp.sub_type NOT ILIKE '%stop_loss%'
      AND fp.sub_type NOT ILIKE '%stop loss%'
    """

    run_sql(migration_3, "carve-out migration")
    count_3 = spark.sql(f"SELECT COUNT(*) AS n FROM {FQ}.tbl_reimb_carve_outs").collect()[0]["n"]
    log_step("Migration 3: Carve-outs", "SUCCESS", f"{count_3} provisions created")

    # ============================================================
    # MIGRATION 4: Capitation card → rate_rules + escalators
    # Adapted: tbl_serving_capitation_card has (age_gender_band, pmpm_rate)
    # ============================================================
    log_step("Migration 4: Capitation", "RUNNING")

    migration_4a = f"""
    INSERT INTO {FQ}.tbl_reimb_rate_rules (
        rule_id, contract_id, provider_id, provider_name,
        rate_domain, service_line, service_category_raw,
        formula_type, formula_json,
        rate_numeric, rate_text, rate_unit,
        program, network, revenue_codes, procedure_codes, drg_codes,
        source_filename, exhibit_reference, effective_date,
        has_stop_loss, has_carve_outs, has_escalator, has_conditions,
        extracted_at, confidence_score
    )
    SELECT
        -- P1-10: deterministic rule_id for capitation rules
        sha2(concat_ws('|', c.provider_id, c.source_filename, 'CAPITATION', c.age_gender_band, COALESCE(CAST(c.pmpm_rate AS STRING), '')), 256) AS rule_id,
        sha2(concat_ws('|', 'CAPITATION', c.provider_name, c.source_filename), 256) AS contract_id,
        c.provider_id,
        c.provider_name,
        'CAPITATION' AS rate_domain,
        c.age_gender_band AS service_line,
        c.age_gender_band AS service_category_raw,
        'FIXED' AS formula_type,
        concat('{{"formula_type":"FIXED","amount":', CAST(c.pmpm_rate AS STRING), ',"unit":"member_month"}}') AS formula_json,
        c.pmpm_rate AS rate_numeric,
        concat('$', CAST(c.pmpm_rate AS STRING), ' PMPM') AS rate_text,
        'member_month' AS rate_unit,
        c.program,
        c.network,
        NULL, NULL, NULL,
        c.source_filename,
        NULL AS exhibit_reference,
        c.effective_date_parsed AS effective_date,
        FALSE, FALSE, FALSE, FALSE,
        current_timestamp(),
        0.9 AS confidence_score
    FROM {FQ}.tbl_serving_capitation_card c
    """

    run_sql(migration_4a, "capitation rates")
    count_4 = spark.sql(
        f"SELECT COUNT(*) AS n FROM {FQ}.tbl_reimb_rate_rules WHERE rate_domain = 'CAPITATION'"
    ).collect()[0]["n"]
    log_step("Migration 4: Capitation", "SUCCESS", f"{count_4} capitation rules")

    # ============================================================
    # MIGRATION 5: Lesser-of provisions → tbl_reimb_lesser_of
    # ============================================================
    log_step("Migration 5: Lesser-of", "RUNNING")

    migration_5 = f"""
    INSERT OVERWRITE {FQ}.tbl_reimb_lesser_of (
        lesser_of_id, rule_id, contract_id,
        comparator_1_type, comparator_1_value,
        comparator_2_type, comparator_2_value,
        comparator_3_type, comparator_3_value,
        medicare_version, applies_to_services,
        source_filename, effective_date
    )
    SELECT
        -- P1-10: deterministic lesser_of_id
        sha2(concat_ws('|', g.provider_id, g.source_filename, 'LESSER_OF', COALESCE(g.service_category, ''), COALESCE(CAST(g.rate_numeric AS STRING), '')), 256) AS lesser_of_id,
        -- P1-10: deterministic FK lookup (ORDER BY ensures stable LIMIT 1)
        COALESCE(
            (SELECT rr.rule_id FROM {FQ}.tbl_reimb_rate_rules rr
             WHERE rr.provider_name = g.provider_name
               AND rr.service_category_raw = g.service_category
               AND rr.rate_numeric = g.rate_numeric
             ORDER BY rr.rule_id
             LIMIT 1),
            'UNLINKED'
        ) AS rule_id,
        sha2(concat_ws('|', g.provider_id, g.source_filename), 256) AS contract_id,
        'CONTRACTED_RATE' AS comparator_1_type,
        g.rate_numeric AS comparator_1_value,
        'BILLED_CHARGES' AS comparator_2_type,
        NULL AS comparator_2_value,
        'MEDICARE_RATE' AS comparator_3_type,
        NULL AS comparator_3_value,
        NULL AS medicare_version,
        g.service_category AS applies_to_services,
        g.source_filename,
        g.effective_date_parsed AS effective_date
    FROM {FQ}.tbl_genie_rates_current g
    WHERE g.rate_text ILIKE '%lesser%of%'
       OR g.formula ILIKE '%lesser%'
       OR g.rate_text ILIKE '%lower%of%'
    """

    run_sql(migration_5, "lesser-of migration")
    count_5 = spark.sql(f"SELECT COUNT(*) AS n FROM {FQ}.tbl_reimb_lesser_of").collect()[0]["n"]
    log_step("Migration 5: Lesser-of", "SUCCESS", f"{count_5} provisions created")

    # ============================================================
    # POST-MIGRATION: Update modifier flags
    # ============================================================
    log_step("Post-migration: Modifier flags", "RUNNING")

    run_sql(f"""
    MERGE INTO {FQ}.tbl_reimb_rate_rules AS rr
    USING (
        SELECT DISTINCT rule_id FROM {FQ}.tbl_reimb_stop_loss WHERE rule_id != 'UNLINKED'
    ) AS sl ON rr.rule_id = sl.rule_id
    WHEN MATCHED THEN UPDATE SET rr.has_stop_loss = TRUE
    """, "stop-loss flags")

    if table_exists(f"{FQ}.tbl_reimb_escalators"):
        run_sql(f"""
        MERGE INTO {FQ}.tbl_reimb_rate_rules AS rr
        USING (
            SELECT DISTINCT rule_id FROM {FQ}.tbl_reimb_escalators WHERE rule_id != 'UNLINKED'
        ) AS esc ON rr.rule_id = esc.rule_id
        WHEN MATCHED THEN UPDATE SET rr.has_escalator = TRUE
        """, "escalator flags")
    else:
        print(f"  Skipping escalator flags: {FQ}.tbl_reimb_escalators not found")

    log_step("Post-migration: Modifier flags", "SUCCESS")

    # ============================================================
    # P1-15: Taxonomy Linkage (dim_service_line_patterns → rate_rules)
    # ============================================================
    # Applies 45 ILIKE patterns against service_line to populate:
    #   service_line_id, service_line_code, comparable_group
    # Priority-based dedup picks the most specific match.
    # Domain filtering ensures INPATIENT patterns don't match OUTPATIENT rules.
    # Exclude patterns prevent false positives (e.g. %NICU%II% excludes %III%).
    # Coverage: ~14% of rules have specific enough service_line text to match.
    # Unlinked rules have generic text ("All Inpatient Services", empty, age bands).
    # ============================================================
    log_step("P1-15: Taxonomy linkage", "RUNNING")

    run_sql(f"""
    MERGE INTO {FQ}.tbl_reimb_rate_rules AS rr
    USING (
        WITH matches AS (
            SELECT
                rr2.rule_id,
                p.service_line_id,
                t.service_line_code,
                t.comparable_group,
                ROW_NUMBER() OVER (
                    PARTITION BY rr2.rule_id
                    ORDER BY p.priority DESC, t.service_line_id DESC
                ) AS rn
            FROM {FQ}.tbl_reimb_rate_rules rr2
            JOIN {FQ}.dim_service_line_patterns p
                ON rr2.service_line ILIKE p.pattern_value
                AND (p.applies_to_domain IS NULL OR p.applies_to_domain = rr2.rate_domain)
                AND (p.exclude_pattern IS NULL OR rr2.service_line NOT ILIKE p.exclude_pattern)
            JOIN {FQ}.dim_service_line_taxonomy t
                ON p.service_line_id = t.service_line_id
            WHERE t.is_active = TRUE
        )
        SELECT rule_id, service_line_id, service_line_code, comparable_group
        FROM matches
        WHERE rn = 1
    ) AS m ON rr.rule_id = m.rule_id
    WHEN MATCHED THEN UPDATE SET
        rr.service_line_id = m.service_line_id,
        rr.service_line_code = m.service_line_code,
        rr.comparable_group = m.comparable_group
    """, "taxonomy linkage")

    linked_count = spark.sql(f"""
        SELECT COUNT(*) AS n FROM {FQ}.tbl_reimb_rate_rules
        WHERE service_line_id IS NOT NULL
    """).collect()[0]["n"]
    log_step("P1-15: Taxonomy linkage", "SUCCESS", f"{linked_count} rules linked to taxonomy")

    print("\n" + "=" * 60)
    print("MIGRATION SUMMARY")
    print("=" * 60)
    tables = [
        ("tbl_reimb_rate_rules", "Rate rules (FFS + capitation)"),
        ("tbl_reimb_stop_loss", "Stop-loss provisions"),
        ("tbl_reimb_carve_outs", "Carve-out provisions"),
        ("tbl_reimb_lesser_of", "Lesser-of provisions"),
    ]
    if table_exists(f"{FQ}.tbl_reimb_escalators"):
        tables.append(("tbl_reimb_escalators", "Escalators"))

    summary = {}
    for tbl, desc in tables:
        count = spark.sql(f"SELECT COUNT(*) AS n FROM {FQ}.{tbl}").collect()[0]["n"]
        print(f"  {tbl:<35} {count:>6} rows  ({desc})")
        summary[tbl] = count
    print("=" * 60)

    return summary


if __name__ == "__main__":
    main()
