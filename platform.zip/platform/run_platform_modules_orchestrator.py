# Databricks notebook source
# DBTITLE 1,Define platform module paths
from pathlib import Path

BASE_PATH = Path("/Workspace/Users/adixit01@blueshieldca.com/Contract_Codification_Pipeline/platform")
MODULE_SPECS = [
    ("reimbursement_migration", BASE_PATH / "03_reimbursement_migration.py"),
    ("state_engine", BASE_PATH / "02_state_engine.py"),
    ("intelligence", BASE_PATH / "08_intelligence.py"),
    ("legal_chunking", BASE_PATH / "04_legal_chunking.py"),
]

print(f"Base path: {BASE_PATH}")
for module_name, module_path in MODULE_SPECS:
    print(f"{module_name}: {module_path}")

# COMMAND ----------

# DBTITLE 1,Load platform modules
import importlib.util
import sys


def load_module(module_name, module_path):
    module_path = Path(module_path)
    if not module_path.exists():
        raise FileNotFoundError(f"Module file not found: {module_path}")

    spec = importlib.util.spec_from_file_location(module_name, module_path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Could not create import spec for {module_name} from {module_path}")

    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


loaded_modules = {
    module_name: load_module(module_name, module_path)
    for module_name, module_path in MODULE_SPECS
}

print("Loaded modules:", ", ".join(loaded_modules.keys()))

# COMMAND ----------

# DBTITLE 1,Run platform modules in order
execution_summary = {}

for module_name, _ in MODULE_SPECS:
    module = loaded_modules[module_name]
    if not hasattr(module, "main"):
        raise AttributeError(f"Module {module_name} does not define main()")

    print(f"\nRunning {module_name}.main()")
    result = module.main()
    execution_summary[module_name] = result

    if isinstance(result, dict):
        print("Returned summary:")
        for key, value in result.items():
            print(f"  {key}: {value}")
    else:
        print(f"Returned summary: {result}")

print("\nExecution complete.")
execution_summary