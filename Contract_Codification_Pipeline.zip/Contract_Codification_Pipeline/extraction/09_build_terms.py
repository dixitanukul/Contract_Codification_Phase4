# Databricks notebook source
# DBTITLE 1,Build Terms Overview
# MAGIC %md
# MAGIC # 09 — Build Base Layer: Terms Domain
# MAGIC **Builds 4 terms tables directly from JSON files (zero intermediate dependencies).**
# MAGIC
# MAGIC | Table | Description |
# MAGIC |-------|-------------|
# MAGIC | `tbl_contract_clauses_terms` | Clauses, sections, key definitions, full_clause_text |
# MAGIC | `tbl_contract_codes_events` | CPT, HCPCS, ICD codes + medical events |
# MAGIC | `tbl_contract_parties` | Contracting parties (payer, provider, TPA) |
# MAGIC | `tbl_contract_services_quality` | DOFR services, quality metrics, credentialing |
# MAGIC
# MAGIC | Input | Output |
# MAGIC |-------|--------|
# MAGIC | `json_extract/*.json` | 4 Delta tables in `dev_adb.raw` |
# MAGIC
# MAGIC **Run after:** `08_build_rates`  
# MAGIC **Run before:** `10_build_documents`

# COMMAND ----------

# DBTITLE 1,Load Shared Config
# MAGIC %run ./_config

# COMMAND ----------

# DBTITLE 1,Load JSON Data and Utilities
# ═══ Load JSON data + utility functions (shared with 08_build_rates) ═══
import os, json, re
import pandas as pd
from collections import defaultdict

def safe_str(val, max_len=None):
    if val is None: return None
    s = str(val) if not isinstance(val, str) else val
    return s[:max_len] if max_len and len(s) > max_len else s

def safe_float(val):
    if val is None: return None
    try: return float(val)
    except (ValueError, TypeError): return None

def sanitize_for_spark(df):
    for col in df.columns:
        if df[col].dtype == 'object':
            non_null = df[col].dropna()
            if len(non_null) == 0: continue
            types = set(type(v).__name__ for v in non_null.head(50))
            if types != {'str'}:
                df[col] = df[col].apply(lambda x: str(x) if x is not None and not (isinstance(x, float) and pd.isna(x)) else None)
    return df

def write_base_table(rows, table_name):
    from pyspark.sql.types import NullType
    from pyspark.sql.functions import lit
    SCHEMA = "dev_adb.raw"
    df = sanitize_for_spark(pd.DataFrame(rows))
    sdf = spark.createDataFrame(df)
    for field in sdf.schema.fields:
        if isinstance(field.dataType, NullType):
            target_type = "double" if '_numeric' in field.name else "string"
            sdf = sdf.withColumn(field.name, lit(None).cast(target_type))
    sdf.write.mode("overwrite").option("overwriteSchema", "true").saveAsTable(f"{SCHEMA}.{table_name}")
    return len(rows)

def dedup_extraction_versions(docs_dict):
    groups = defaultdict(list)
    for fname, doc in docs_dict.items():
        fm = doc.get('file_metadata', {})
        co = (doc.get('extracted_content') or {}).get('contract_overview', {}) or {}
        key = (fm.get('provider_id', ''), fm.get('contract_id', ''),
               fm.get('document_type', ''), co.get('effective_date', ''))
        groups[key].append(fname)
    keep = set()
    for key, fnames in groups.items():
        if len(fnames) == 1:
            keep.add(fnames[0])
        else:
            best = max(fnames, key=lambda fn: int(re.search(r'_v(\d+)', fn).group(1)) if re.search(r'_v(\d+)', fn) else 0)
            keep.add(best)
    removed = len(docs_dict) - len(keep)
    if removed > 0:
        print(f"  Version dedup: removed {removed} duplicate extractions")
    return {k: v for k, v in docs_dict.items() if k in keep}

# Load JSONs with quarantine filter + dedup
try:
    _ = individual_docs
    print(f"  Reusing {len(individual_docs)} docs from memory")
except NameError:
    individual_docs = {}
    for jf in sorted(f for f in os.listdir(OUTPUT_DIR) if f.endswith('.json') and not f.startswith('_')):
        with open(os.path.join(OUTPUT_DIR, jf)) as f:
            doc = json.load(f)
        if doc.get('validation', {}).get('quarantined'):
            continue
        individual_docs[jf] = doc
    individual_docs = dedup_extraction_versions(individual_docs)
    print(f"  Loaded {len(individual_docs)} docs (quarantined/duplicates excluded)")

# COMMAND ----------

# DBTITLE 1,Build Terms, Codes, Parties, and Services Tables
# ═══════════════════════════════════════════════════════════════════════════════
# STEP 11b: BUILD BASE LAYER FROM JSON — Terms + Codes + Services
#   Reads directly from json_extract/ — ZERO dependency on source tables.
#   Builds:
#     - tbl_contract_clauses_terms (clauses + sections + key_definitions)
#     - tbl_contract_codes_events (medical_codes + hac_never_events)
#     - tbl_contract_parties (health plan + provider + signatories)
#     - tbl_contract_services_quality (covered_services + quality + dofr)
#
#   JSON paths:
#     clauses: extracted_content.<section_name>.full_clause_text
#     sections: extracted_content.sections[]
#     definitions: extracted_content.key_definitions{term: definition}
#     medical_codes: validation.medical_codes[]
#     HAC: extracted_content.hac_never_events.hac_list[] + .never_events[]
#     parties: extracted_content.parties + signatories
#     services: extracted_content.covered_services, quality_and_performance, delegated_activities
# ═══════════════════════════════════════════════════════════════════════════════
import time

print("\n" + "═"*80)
print("  ▶ STEP 11b: BASE LAYER FROM JSON — Terms + Codes + Services")
print("    No source table dependencies. Reads JSON directly.")
print("═"*80)

t0 = time.time()

# ═══ TABLE 5: tbl_contract_clauses_terms ═══
print("\n  Building tbl_contract_clauses_terms from JSON...")
rows_ct = []

clause_sections = ['termination', 'compliance_and_regulatory', 'grievance_and_appeals',
                   'dispute_resolution', 'confidentiality_and_records', 'indemnification_insurance']

for jf, doc in individual_docs.items():
    fm = doc.get('file_metadata', {})
    ec = doc.get('extracted_content', {}) or {}
    eff_date = (ec.get('contract_overview', {}) or {}).get('effective_date')

    base = {
        'provider_id': fm.get('provider_id'),
        'provider_name': fm.get('provider_name'),
        'source_filename': fm.get('source_filename'),
        'document_type': fm.get('document_type'),
    }

    # Clauses (full verbatim text)
    for section in clause_sections:
        sec_data = ec.get(section, {}) or {}
        if isinstance(sec_data, dict) and sec_data.get('full_clause_text'):
            rows_ct.append({**base,
                'content_type': 'clause',
                'topic': section,
                'section_number': None,
                'title': section,
                'notice_period_text': sec_data.get('notice_period') if section == 'termination' else None,
                'text_length': len(sec_data['full_clause_text']),
                'content_text': sec_data['full_clause_text'],
                'effective_date': eff_date,
                'source_table': 'json_extract/clause_sections',
            })

    # Sections (table of contents / summaries)
    sections = ec.get('sections', [])
    if isinstance(sections, list):
        for sec in sections:
            if not isinstance(sec, dict):
                continue
            content = safe_str(sec.get('content_summary', sec.get('summary', '')), 5000)
            key_prov = safe_str(sec.get('key_provisions', ''), 2000)
            full_text = content
            if key_prov:
                full_text = f"{content} | Key provisions: {key_prov}" if content else f"Key provisions: {key_prov}"
            rows_ct.append({**base,
                'content_type': 'section',
                'topic': safe_str(sec.get('section_title', sec.get('title', ''))),
                'section_number': safe_str(sec.get('section_number', sec.get('number', ''))),
                'title': safe_str(sec.get('section_title', sec.get('title', ''))),
                'notice_period_text': None,
                'text_length': None,
                'content_text': full_text,
                'effective_date': None,
                'source_table': 'json_extract/sections',
            })

    # Definitions (key_definitions dict: {term: definition_text})
    kd = ec.get('key_definitions', {})
    if isinstance(kd, dict):
        for term, definition in kd.items():
            rows_ct.append({**base,
                'content_type': 'definition',
                'topic': term,
                'section_number': None,
                'title': term,
                'notice_period_text': None,
                'text_length': None,
                'content_text': safe_str(definition, 5000),
                'effective_date': None,
                'source_table': 'json_extract/key_definitions',
            })

write_base_table(rows_ct, 'tbl_contract_clauses_terms')
print(f"  ✅ tbl_contract_clauses_terms: {len(rows_ct):,} rows")

# ═══ TABLE 6: tbl_contract_codes_events ═══
print("  Building tbl_contract_codes_events from JSON...")
rows_ce = []

for jf, doc in individual_docs.items():
    fm = doc.get('file_metadata', {})
    val = doc.get('validation', {}) or {}
    ec = doc.get('extracted_content', {}) or {}

    base = {
        'provider_id': fm.get('provider_id'),
        'provider_name': fm.get('provider_name'),
        'source_filename': fm.get('source_filename'),
        'document_type': fm.get('document_type'),
    }

    # Medical codes (from validation section)
    for code in (val.get('medical_codes', []) or []):
        if isinstance(code, dict):
            rows_ce.append({**base,
                'content_type': 'medical_code',
                'category': safe_str(code.get('code_type', '')),
                'code_value': safe_str(code.get('code', '')),
                'context_section': safe_str(val.get('content_bucket', '')),
                'condition_name': None,
                'adjustment_rule': None,
                'is_latest_version': None,
                'source_table': 'json_extract/validation.medical_codes',
            })

    # HAC events (from hac_never_events dict)
    hac_data = ec.get('hac_never_events', {})
    if isinstance(hac_data, dict):
        # HAC list
        for item in (hac_data.get('hac_list', []) or []):
            if isinstance(item, dict):
                rows_ce.append({**base,
                    'content_type': 'hac',
                    'category': 'HAC',
                    'code_value': safe_str(item.get('icd_codes', ''), 500),
                    'context_section': None,
                    'condition_name': safe_str(item.get('condition', '')),
                    'adjustment_rule': safe_str(item.get('adjustment_rule', ''), 1000),
                    'is_latest_version': None,
                    'source_table': 'json_extract/hac_never_events.hac_list',
                })
        # Never events
        for item in (hac_data.get('never_events', []) or []):
            if isinstance(item, dict):
                rows_ce.append({**base,
                    'content_type': 'never_event',
                    'category': 'Never Event',
                    'code_value': safe_str(item.get('icd_codes', ''), 500),
                    'context_section': None,
                    'condition_name': safe_str(item.get('event', item.get('condition', ''))),
                    'adjustment_rule': safe_str(item.get('reimbursement_rule', item.get('adjustment_rule', '')), 1000),
                    'is_latest_version': None,
                    'source_table': 'json_extract/hac_never_events.never_events',
                })

write_base_table(rows_ce, 'tbl_contract_codes_events')
print(f"  ✅ tbl_contract_codes_events: {len(rows_ce):,} rows")

# ═══ TABLE 7: tbl_contract_parties ═══
print("  Building tbl_contract_parties from JSON...")
rows_parties = []

for jf, doc in individual_docs.items():
    fm = doc.get('file_metadata', {})
    ec = doc.get('extracted_content', {}) or {}
    parties = ec.get('parties', {}) or {}

    base = {
        'provider_id': fm.get('provider_id'),
        'provider_name': fm.get('provider_name'),
        'source_filename': fm.get('source_filename'),
        'document_type': fm.get('document_type'),
    }

    hp = parties.get('health_plan', {}) or {}
    if hp.get('name'):
        rows_parties.append({**base,
            'party_role': 'health_plan',
            'party_name': hp.get('name'),
            'party_dba': hp.get('dba'),
            'party_type': hp.get('role'),
            'tax_id': None, 'npi': None, 'pin': None,
            'successor_info': safe_str(hp.get('successor_info'), 500),
            'is_signatory': False, 'signatory_title': None, 'signed_date': None,
        })

    prov = parties.get('provider', {}) or {}
    if prov.get('name'):
        rows_parties.append({**base,
            'party_role': 'provider',
            'party_name': prov.get('name'),
            'party_dba': None,
            'party_type': prov.get('type'),
            'tax_id': safe_str(prov.get('tax_id')),
            'npi': safe_str(prov.get('npi')),
            'pin': safe_str(prov.get('pin')),
            'successor_info': None,
            'is_signatory': False, 'signatory_title': None, 'signed_date': None,
        })

    for sig in (ec.get('signatories') or []):
        if isinstance(sig, dict) and sig.get('name'):
            rows_parties.append({**base,
                'party_role': sig.get('role', 'signatory'),
                'party_name': sig.get('name'),
                'party_dba': None,
                'party_type': sig.get('title'),
                'tax_id': None, 'npi': None, 'pin': None,
                'successor_info': None,
                'is_signatory': True,
                'signatory_title': sig.get('title'),
                'signed_date': safe_str(sig.get('date')),
            })

write_base_table(rows_parties, 'tbl_contract_parties')
print(f"  ✅ tbl_contract_parties: {len(rows_parties):,} rows")

# ═══ TABLE 8: tbl_contract_services_quality ═══
print("  Building tbl_contract_services_quality from JSON...")
rows_sq = []

for jf, doc in individual_docs.items():
    fm = doc.get('file_metadata', {})
    ec = doc.get('extracted_content', {}) or {}

    base = {
        'provider_id': fm.get('provider_id'),
        'provider_name': fm.get('provider_name'),
        'source_filename': fm.get('source_filename'),
        'document_type': fm.get('document_type'),
    }

    # Covered services
    cs = ec.get('covered_services', {})
    if isinstance(cs, dict):
        for svc_type in ['included_services', 'excluded_services', 'carve_outs']:
            for svc in (cs.get(svc_type, []) or []):
                svc_name = svc if isinstance(svc, str) else safe_str(svc.get('service', svc.get('name', ''))) if isinstance(svc, dict) else str(svc)
                if svc_name:
                    rows_sq.append({**base,
                        'item_type': 'covered_service',
                        'category': svc_type.replace('_', ' '),
                        'item_name': svc_name,
                        'delegated_to': None, 'oversight_requirements': None,
                        'reporting_frequency': None, 'program_type': None,
                        'is_latest_version': None,
                        'source_table': 'json_extract/covered_services',
                    })
    elif isinstance(cs, list):
        for svc in cs:
            svc_name = svc if isinstance(svc, str) else safe_str(svc.get('service', '')) if isinstance(svc, dict) else str(svc)
            if svc_name:
                rows_sq.append({**base,
                    'item_type': 'covered_service', 'category': 'included services',
                    'item_name': svc_name, 'delegated_to': None, 'oversight_requirements': None,
                    'reporting_frequency': None, 'program_type': None,
                    'is_latest_version': None, 'source_table': 'json_extract/covered_services',
                })

    # Quality programs
    qp = ec.get('quality_and_performance', {})
    if isinstance(qp, dict):
        metrics = qp.get('quality_metrics', [])
        if isinstance(metrics, list) and metrics:
            for m in metrics:
                if isinstance(m, str):
                    rows_sq.append({**base, 'item_type': 'quality_program', 'category': 'quality_metric',
                        'item_name': m, 'delegated_to': None, 'oversight_requirements': None,
                        'reporting_frequency': None, 'program_type': 'quality_metric',
                        'is_latest_version': None, 'source_table': 'json_extract/quality_and_performance'})
                elif isinstance(m, dict):
                    rows_sq.append({**base, 'item_type': 'quality_program',
                        'category': safe_str(m.get('type', 'quality_metric')),
                        'item_name': safe_str(m.get('name', m.get('metric', ''))),
                        'delegated_to': None, 'oversight_requirements': None,
                        'reporting_frequency': None, 'program_type': safe_str(m.get('type', 'quality_metric')),
                        'is_latest_version': None, 'source_table': 'json_extract/quality_and_performance'})
        elif any(v for v in [qp.get('credentialing_requirements'), qp.get('utilization_management')] if v):
            rows_sq.append({**base, 'item_type': 'quality_program', 'category': 'general',
                'item_name': 'General Quality Program', 'delegated_to': None,
                'oversight_requirements': safe_str(qp.get('credentialing_requirements', ''), 2000),
                'reporting_frequency': None, 'program_type': 'general',
                'is_latest_version': None, 'source_table': 'json_extract/quality_and_performance'})

    # Delegated activities (DOFR)
    for item in (ec.get('delegated_activities', []) or []):
        if isinstance(item, dict):
            rows_sq.append({**base,
                'item_type': 'delegation',
                'category': safe_str(item.get('category', '')),
                'item_name': safe_str(item.get('activity', '')),
                'delegated_to': safe_str(item.get('delegated_to', '')),
                'oversight_requirements': safe_str(item.get('oversight_requirements', ''), 2000),
                'reporting_frequency': safe_str(item.get('reporting_frequency', '')),
                'program_type': None, 'is_latest_version': None,
                'source_table': 'json_extract/delegated_activities',
            })

write_base_table(rows_sq, 'tbl_contract_services_quality')
print(f"  ✅ tbl_contract_services_quality: {len(rows_sq):,} rows")

print(f"\n  Terms+Codes+Services complete: {time.time()-t0:.1f}s")
print(f"  📁 Source: json_extract/ (ZERO table dependencies)")