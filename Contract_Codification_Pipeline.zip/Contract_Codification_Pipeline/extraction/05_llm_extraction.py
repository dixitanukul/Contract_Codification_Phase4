# Databricks notebook source
# DBTITLE 1,LLM Extraction Overview
# MAGIC %md
# MAGIC # 05 — LLM Semantic Extraction Engine
# MAGIC **REST API engine with adaptive concurrency, chunking, and retry for Claude Sonnet 4.5.**
# MAGIC
# MAGIC | Feature | Implementation |
# MAGIC |---------|---------------|
# MAGIC | Concurrency | 3 workers via ThreadPoolExecutor + AdaptiveConcurrency |
# MAGIC | Chunking | Files >150K chars split into 80K segments, merged |
# MAGIC | Retry | 1 retry with 30s backoff on failures |
# MAGIC | JSON Repair | Closes truncated brackets when output hits max_tokens |
# MAGIC | Progress | Real-time `_progress.json` file for external monitoring |
# MAGIC
# MAGIC | Input | Output |
# MAGIC |-------|--------|
# MAGIC | `checkpoints/step2_with_metadata_v2.parquet` | `json_extract/*.json` (one per PDF) |
# MAGIC
# MAGIC **Run after:** `04_llm_prompts`  
# MAGIC **Run before:** `06_validation`

# COMMAND ----------

# DBTITLE 1,Load Shared Config and Prompts
# MAGIC %run ./_config

# COMMAND ----------

# DBTITLE 1,Load Prompts
# MAGIC %run ./04_llm_prompts

# COMMAND ----------

# DBTITLE 1,Adaptive Concurrency and Progress Tracker
# ═══════════════════════════════════════════════════════════════════════════════
import os, json, re, time, math, signal
import pandas as pd
from pyspark.sql.types import StructType, StructField, StringType
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FuturesTimeout

print("\n" + "═"*80)
print("  ▶ STEP 3: LLM SEMANTIC EXTRACTION (Claude Sonnet 4.5) — V6 Delta-Ready Schema")
print("    3a: Initial extraction | 3a-retry: Retry failures | 3b: Re-extract low-score | 3c: Chunked oversized")
print("    Prompts: Base Agreement | Amendment | Cover Memo | Settlement")
print("    Changes: A (rate context) | B (full clause text) | C (supersedes tracking)")
print("═"*80)

# ── Performance-tuned constants ──
REST_CONCURRENCY   = 3            # Parallel REST API workers
TOKENS_PER_CHAR    = 0.3
PROMPT_TOKENS      = 700
CHUNK_SIZE         = 80_000       # reduced from 100K for safer output size
CHUNK_OVERLAP      = 2_000
RETRY_MAX          = 1
RETRY_BACKOFF      = 30
SCORE_CACHE        = f"{CHECKPOINT_DIR}/extraction_scores.parquet"
MAX_SINGLE_CHARS   = 270_000      # Claude 200K tokens; covers ALL corpus files
PER_FILE_TIMEOUT   = 1800         # 30 min per-file HTTP timeout
STEP3_TIME_BUDGET  = 24 * 3600    # 24h budget for full production runs
MIN_SCORE_TEXT_LEN = 5_000        # Skip scoring files shorter than this (emails/memos)
MAX_OUTPUT_TOKENS  = 65536        # Increased from 32768 — V6 full_clause_text needs more room

# ── Adaptive concurrency controller ──
RATE_LIMIT_RE = re.compile(r'429|rate.?limit|throttl|too many requests|capacity|overloaded|quota', re.I)

class AdaptiveConcurrency:
    def __init__(self, max_conc):
        self.max_conc = max_conc; self.current = max_conc
        self.clean_streak = 0; self.baseline = None
    def get(self, n): return min(n, self.current)
    def update(self, bs, elapsed, errs):
        pf = elapsed / max(bs, 1)
        rl = sum(1 for e in errs if e and RATE_LIMIT_RE.search(str(e)))
        if rl > 0:
            self.current = max(2, self.current // 2); self.clean_streak = 0
        elif self.baseline and pf > self.baseline * 3:
            self.current = max(2, int(self.current * 0.75)); self.clean_streak = 0
        else:
            self.clean_streak += 1
            self.baseline = 0.7 * self.baseline + 0.3 * pf if self.baseline else pf
            if self.clean_streak >= 2 and self.current < self.max_conc:
                self.current = min(self.max_conc, int(self.current * 1.25) + 1); self.clean_streak = 0

# ── Progress Tracker — real-time file-level monitoring ──
class ProgressTracker:
    """Tracks per-file extraction progress with live status file."""
    def __init__(self, output_dir, total_target):
        self.output_dir = output_dir
        self.total_target = total_target
        self.progress_file = os.path.join(output_dir, "_progress.json")
        self.completed = []       # list of {filename, status, tier, elapsed_sec, timestamp}
        self.in_progress = []     # filenames currently being processed
        self.errors = []          # list of {filename, error, tier, timestamp}
        self.start_time = time.time()
        self.current_tier = ""
        self._write_progress()

    def start_batch(self, filenames, tier_label):
        """Mark files as in-progress."""
        self.in_progress = list(filenames)
        self.current_tier = tier_label
        self._write_progress()

    def complete_batch(self, ok_fnames, err_fnames, batch_errors, batch_elapsed):
        """Record batch results — per-file status."""
        ts = time.strftime("%H:%M:%S")
        for fname in ok_fnames:
            self.completed.append({
                "filename": fname, "status": "OK", "tier": self.current_tier,
                "elapsed_sec": round(batch_elapsed, 1), "timestamp": ts
            })
            pipe_log.info(f"      ✅ {fname[:70]}")
        for fname, err in zip(err_fnames, batch_errors if batch_errors else ["unknown"]*len(err_fnames)):
            self.errors.append({
                "filename": fname, "error": str(err)[:200], "tier": self.current_tier, "timestamp": ts
            })
            pipe_log.info(f"      ❌ {fname[:70]} — {str(err)[:80]}")
        self.in_progress = []
        self._write_progress()

    def _write_progress(self):
        """Write live progress file (monitorable externally)."""
        elapsed = time.time() - self.start_time
        done = len(self.completed)
        errs = len(self.errors)
        rate = (done + errs) / max(elapsed, 1) * 60
        eta_min = (self.total_target - done - errs) / max(rate, 0.01) if rate > 0 else 0
        status = {
            "last_updated": time.strftime("%Y-%m-%d %H:%M:%S"),
            "elapsed_min": round(elapsed / 60, 1),
            "total_target": self.total_target,
            "completed_ok": done,
            "completed_err": errs,
            "remaining": self.total_target - done - errs,
            "rate_per_min": round(rate, 1),
            "eta_min": round(eta_min, 1),
            "current_tier": self.current_tier,
            "in_progress": self.in_progress[:10],  # show first 10 in-flight
            "in_progress_count": len(self.in_progress),
            "recent_completed": [c["filename"] for c in self.completed[-10:]],
            "recent_errors": [e["filename"] for e in self.errors[-5:]],
        }
        try:
            with open(self.progress_file, 'w') as f:
                json.dump(status, f, indent=2)
        except Exception:
            pass

    def summary(self):
        """Print final summary."""
        elapsed = time.time() - self.start_time
        print(f"\n  ── PROGRESS SUMMARY ──")
        print(f"     Total completed: {len(self.completed)} OK | {len(self.errors)} errors")
        print(f"     Rate: {(len(self.completed)+len(self.errors))/max(elapsed,1)*60:.1f} files/min")
        print(f"     Elapsed: {elapsed/60:.1f} min")
        print(f"     Progress file: {self.progress_file}")




# COMMAND ----------

# DBTITLE 1,V6 Schema Definition
# ══════════════════════════════════════════════════════════════════════════════
# V6 DELTA-READY JSON SCHEMA
# Changes A/B/C: rate_numeric + context on every rate row, full clause text,
# amendments_impact for supersession tracking
# ══════════════════════════════════════════════════════════════════════════════
JSON_SCHEMA = """{
  "contract_overview": {
    "agreement_title": "",
    "agreement_type": "",
    "effective_date": "",
    "execution_date": "",
    "expiration_date": "",
    "prior_agreement_reference": "",
    "renewal_terms": "",
    "auto_renewal": false,
    "amendment_number": null,
    "contract_term_years": null
  },
  "parties": {
    "health_plan": {"name": "", "dba": "", "role": "", "successor_info": ""},
    "provider": {"name": "", "type": "", "role": "", "tax_id": "", "npi": "", "pin": ""}
  },
  "signatories": [{"name": "", "title": "", "organization": "", "date_signed": ""}],
  "sections": [{"section_number": "", "section_title": "", "content_summary": "", "key_provisions": []}],
  "financial_terms": {
    "payment_type": "",
    "payment_timeline": "",
    "billing_requirements": "",
    "withhold_provisions": "",
    "withhold_percentage": "",
    "withhold_amount": "",
    "risk_sharing": "",
    "interest_on_late_payments": ""
  },
  "inpatient_rates": {
    "per_diem_rates": [
      {"service_category": "", "rate": "", "rate_numeric": null, "revenue_codes": "", "effective_date": "", "program": "", "network": "", "exhibit_reference": "", "notes": ""}
    ],
    "case_rates": [
      {"procedure": "", "case_rate": "", "rate_numeric": null, "included_days": null, "stop_loss_per_diem": "", "stop_loss_numeric": null, "procedure_codes": "", "effective_date": "", "program": "", "network": "", "exhibit_reference": ""}
    ],
    "other_inpatient_rates": [
      {"service": "", "rate_type": "", "rate": "", "rate_numeric": null, "revenue_codes": "", "effective_date": "", "program": "", "network": "", "notes": ""}
    ]
  },
  "outpatient_rates": {
    "surgical_tiers": [
      {"tier": "", "base_rate": "", "rate_numeric": null, "description": "", "effective_date": "", "program": "", "network": "", "exhibit_reference": ""}
    ],
    "emergency_services": {
      "rate_type": "",
      "percentage_of_charges": "",
      "cap_amount": "",
      "cap_numeric": null,
      "revenue_codes": "",
      "effective_date": "",
      "program": "",
      "network": ""
    },
    "infusion_therapy": {"per_visit_rate": "", "rate_numeric": null, "revenue_codes": "", "included_services": "", "effective_date": "", "program": "", "network": ""},
    "therapy_services": [
      {"therapy_type": "", "per_visit_rate": "", "rate_numeric": null, "revenue_codes": "", "effective_date": "", "program": "", "network": ""}
    ],
    "radiology_pathology": {
      "formula": "",
      "conversion_factor": "",
      "conversion_factor_numeric": null,
      "multiplier": "",
      "revenue_codes": "",
      "effective_date": "",
      "program": "",
      "network": ""
    },
    "other_outpatient_rates": [
      {"service": "", "rate_type": "", "rate": "", "rate_numeric": null, "revenue_codes": "", "effective_date": "", "program": "", "network": "", "notes": ""}
    ]
  },
  "regional_factors": [
    {"county": "", "outpatient_surgical_factor": "", "practice_expense_factor": "", "malpractice_factor": "", "effective_date": "", "exhibit_reference": ""}
  ],
  "stop_loss_reinsurance": {
    "has_stop_loss": false,
    "per_diem_attachment_level": "",
    "per_diem_attachment_numeric": null,
    "per_diem_stop_loss_rate": "",
    "per_diem_stop_loss_numeric": null,
    "case_rate_stop_loss": "",
    "aggregate_cap": "",
    "corridor": "",
    "reinsurance_details": "",
    "effective_date": "",
    "exhibit_reference": ""
  },
  "exception_provisions": {
    "implants": {
      "threshold_amount": "",
      "threshold_numeric": null,
      "reimbursement_percentage": "",
      "revenue_codes": "",
      "relationship_to_stop_loss": ""
    },
    "exception_drugs": {
      "threshold_amount": "",
      "threshold_numeric": null,
      "reimbursement_percentage": "",
      "revenue_codes": ""
    },
    "other_exceptions": []
  },
  "capitation_table": {
    "is_capitated": false,
    "rates_by_category": [
      {"aid_category": "", "rate": "", "rate_numeric": null, "effective_date": "", "pmpm": true, "program": "", "network": ""}
    ],
    "multi_year_rates": [
      {"aid_category": "", "year_1_rate": "", "year_1_numeric": null, "year_1_effective": "", "year_2_rate": "", "year_2_numeric": null, "year_2_effective": "", "year_3_rate": "", "year_3_numeric": null, "year_3_effective": "", "year_4_rate": "", "year_4_numeric": null, "year_4_effective": "", "program": "", "network": ""}
    ],
    "supplemental_payments": [
      {"payment_type": "", "amount": "", "amount_numeric": null, "conditions": "", "effective_date": ""}
    ],
    "retroactive_adjustment_rules": ""
  },
  "hac_never_events": {
    "has_hac_policy": false,
    "hac_list": [
      {"condition": "", "icd_codes": "", "adjustment_rule": ""}
    ],
    "never_events": [
      {"event": "", "icd_codes": "", "reimbursement_rule": ""}
    ],
    "dispute_process": ""
  },
  "chargemaster_provisions": {
    "notification_days_before_increase": null,
    "requires_signed_amendment": null,
    "fcr_language": null,
    "lesser_of_language": null,
    "medicare_lesser_of_language": null,
    "cob_language": null,
    "other_payor_surcharge": null,
    "midnight_rule_applicable": null
  },
  "cover_memo_metadata": {
    "rate_percent_increase_yr1": "",
    "rate_percent_increase_yr2": "",
    "rate_percent_increase_yr3": "",
    "model_contract_version": "",
    "rate_exhibit_version": "",
    "dofr_exhibit_version": "",
    "retro_hold_language": null,
    "next_renewal_date": "",
    "liability_start_date": "",
    "provider_dispute_timeframe_initial_days": null,
    "provider_dispute_timeframe_final_days": null
  },
  "settlement_terms": {
    "settlement_amount": "",
    "settlement_amount_numeric": null,
    "arbitration_references": "",
    "release_scope": "",
    "payment_timeline": "",
    "exhibits_referenced": "",
    "dispute_background": ""
  },
  "amendments_impact": {
    "exhibits_replaced": [],
    "exhibits_added": [],
    "sections_modified": [],
    "prior_rates_superseded": false,
    "supersedes_effective_date": "",
    "summary_of_changes": ""
  },
  "coordination_of_benefits": {"cob_rules": "", "subrogation_rights": "", "third_party_liability": ""},
  "covered_services": {"included_services": [], "excluded_services": [], "service_area": ""},
  "termination": {
    "notice_period": "",
    "termination_conditions": [],
    "post_termination_obligations": "",
    "continuity_of_care": "",
    "full_clause_text": ""
  },
  "compliance_and_regulatory": {
    "federal_laws": [],
    "state_laws": [],
    "accreditation_requirements": [],
    "reporting_requirements": [],
    "full_clause_text": ""
  },
  "grievance_and_appeals": {
    "member_grievance_process": "",
    "provider_appeal_process": "",
    "appeal_timeline_days": "",
    "has_expedited_appeal": false,
    "external_review": "",
    "full_clause_text": ""
  },
  "delegated_activities": [{"activity": "", "category": "", "delegated_to": "", "oversight_requirements": ""}],
  "behavioral_health": {"services_covered": "", "parity_compliance": "", "carve_out_status": "", "substance_use_treatment": ""},
  "network_access_standards": {"after_hours_requirements": "", "appointment_standards": "", "language_access_requirements": "", "provider_directory_obligations": ""},
  "electronic_claims_technology": {"edi_requirements": "", "claim_formats": "", "ehr_requirements": "", "hie_participation": "", "encounter_data_requirements": ""},
  "indemnification_insurance": {
    "indemnification_obligations": "",
    "hold_harmless": "",
    "insurance_types_required": [],
    "minimum_coverage_amounts": "",
    "full_clause_text": ""
  },
  "rate_incentive_provisions": {"rate_escalators": "", "cpi_cola_adjustments": "", "incentive_programs": "", "performance_bonuses": "", "payment_dispute_process": ""},
  "amendments_and_attachments": [],
  "key_definitions": {},
  "dispute_resolution": {
    "method": "",
    "governing_law": "",
    "venue": "",
    "full_clause_text": ""
  },
  "quality_and_performance": {"quality_metrics": [], "credentialing_requirements": "", "utilization_management": ""},
  "confidentiality_and_records": {
    "record_retention_period": "",
    "confidentiality_obligations": "",
    "audit_rights": "",
    "member_access_rights": "",
    "full_clause_text": ""
  }
}"""

# ══════════════════════════════════════════════════════════════════════════════
# SCHEMA VALIDATION — Updated for V6

# COMMAND ----------

# DBTITLE 1,Validation and JSON Writer
# ══════════════════════════════════════════════════════════════════════════════
REQUIRED_SECTIONS = {'contract_overview', 'parties', 'financial_terms', 'covered_services',
                     'termination', 'compliance_and_regulatory', 'dispute_resolution',
                     'quality_and_performance', 'confidentiality_and_records'}

# Additional sections expected per document type
REQUIRED_FOR_BASE = {'inpatient_rates', 'outpatient_rates', 'stop_loss_reinsurance'}
REQUIRED_FOR_SETTLEMENT = {'settlement_terms'}
REQUIRED_FOR_AMENDMENT = {'amendments_impact'}

def validate_extraction(extracted, fname="", doc_type=""):
    issues = []
    if not isinstance(extracted, dict): return False, ["Root is not a dict"]
    missing = REQUIRED_SECTIONS - set(extracted.keys())
    if missing: issues.append(f"Missing: {missing}")
    co = extracted.get('contract_overview', {})
    if isinstance(co, dict):
        for k in ('agreement_title', 'agreement_type', 'effective_date'):
            if not co.get(k): issues.append(f"Null: {k}")
    # Type-specific validation
    dt_lower = (doc_type or '').lower()
    if 'baseagmt' in dt_lower:
        base_missing = REQUIRED_FOR_BASE - set(extracted.keys())
        if base_missing: issues.append(f"Base missing: {base_missing}")
    if 'settlement' in dt_lower:
        settle_missing = REQUIRED_FOR_SETTLEMENT - set(extracted.keys())
        if settle_missing: issues.append(f"Settlement missing: {settle_missing}")
    if 'amend' in dt_lower or 'lra' in dt_lower:
        amend_missing = REQUIRED_FOR_AMENDMENT - set(extracted.keys())
        if amend_missing: issues.append(f"Amendment missing: {amend_missing}")
    return len(issues) == 0, issues

def _write_json(path, doc):
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(doc, f, indent=2, ensure_ascii=False)


# COMMAND ----------

# DBTITLE 1,REST API Extraction Functions


def clean_json_response(text: str) -> str:
    """Strip markdown code fences and whitespace from raw LLM JSON output."""
    if not text:
        return text
    text = text.strip()
    # Remove opening ```json or ``` fence
    text = re.sub(r'^```(?:json)?\s*', '', text)
    # Remove closing ``` fence
    text = re.sub(r'\s*```\s*$', '', text)
    return text.strip()


def _call_llm_rest(prompt_text, full_text, max_tokens=MAX_OUTPUT_TOKENS, timeout=PER_FILE_TIMEOUT):
    """Call Claude via direct REST API. Returns (response_text, error_msg, usage)."""
    payload = {
        "messages": [{"role": "user", "content": prompt_text + full_text}],
        "max_tokens": max_tokens,
        "temperature": 0.0
    }
    try:
        resp = requests.post(_ENDPOINT_URL, json=payload, headers=_HEADERS, timeout=timeout)
        if resp.status_code == 200:
            data = resp.json()
            content = data['choices'][0]['message']['content']
            usage = data.get('usage', {})
            return content, None, usage
        elif resp.status_code == 429:
            return None, f"Rate limited (429): {resp.text[:200]}", {}
        else:
            return None, f"HTTP {resp.status_code}: {resp.text[:200]}", {}
    except requests.exceptions.Timeout:
        return None, f"HTTP timeout ({timeout}s)", {}
    except requests.exceptions.ConnectionError as e:
        return None, f"Connection error: {str(e)[:100]}", {}
    except Exception as e:
        return None, f"Exception: {type(e).__name__}: {str(e)[:100]}", {}


def _repair_truncated_json(raw_text):
    """Attempt to repair truncated JSON output by closing open brackets/braces."""
    if not raw_text:
        return None
    text = raw_text.rstrip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    open_braces = text.count('{') - text.count('}')
    open_brackets = text.count('[') - text.count(']')
    last_complete = max(text.rfind('},'), text.rfind('],'), text.rfind('",'))
    if last_complete > len(text) * 0.8:
        text = text[:last_complete + 1]
        open_braces = text.count('{') - text.count('}')
        open_brackets = text.count('[') - text.count(']')
    text += ']' * max(0, open_brackets) + '}' * max(0, open_braces)
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        depth = 0
        last_valid_end = -1
        for ci, ch in enumerate(raw_text):
            if ch == '{': depth += 1
            elif ch == '}':
                depth -= 1
                if depth == 0:
                    last_valid_end = ci
                    break
        if last_valid_end > 0:
            try:
                return json.loads(raw_text[:last_valid_end + 1])
            except json.JSONDecodeError:
                pass
    return None


def _extract_single_file(row, attempt=1):
    """Extract a single file via REST API. Returns (filename, doc_dict, error_or_none)."""
    fname = row['filename']
    full_text = row['full_text'] or ''
    text_len = len(full_text)
    doc_type = row.get('document_type', '') or ''
    
    fmeta = {
        "source_filename": fname,
        "provider_id": row.get('provider_id'),
        "provider_name": row.get('provider_name'),
        "contract_id": row.get('contract_id'),
        "document_type": doc_type,
        "version": row.get('version'),
        "num_pages": int(row['num_pages']) if pd.notna(row.get('num_pages')) else 0,
        "text_length": text_len
    }
    
    # For files >150K chars, use chunked extraction
    if text_len > 150_000:
        return _extract_chunked(row, fmeta)
    
    # Single-file extraction
    prompt = _get_prompt_for_doc(doc_type)
    timeout = min(PER_FILE_TIMEOUT, 600 + int(text_len / 1000) * 8)
    
    raw_text, err_msg, usage = _call_llm_rest(prompt, full_text, timeout=timeout)
    
    if err_msg:
        # Retry once on rate limit
        if '429' in str(err_msg) and attempt < 2:
            pipe_log.info(f"      Rate limited, waiting 60s before retry: {fname[:50]}")
            time.sleep(60)
            return _extract_single_file(row, attempt + 1)
        doc = {"file_metadata": fmeta, "extraction_error": err_msg,
               "extracted_content": None, "full_text": full_text}
        return fname, doc, err_msg
    
    cleaned = clean_json_response(raw_text)
    try:
        extracted = json.loads(cleaned)
    except json.JSONDecodeError as e:
        repaired = _repair_truncated_json(cleaned)
        if repaired:
            extracted = repaired
            fmeta['json_repaired'] = True
            pipe_log.info(f"      Repaired JSON: {fname[:50]}")
        else:
            doc = {"file_metadata": fmeta, "extraction_error": f"JSON: {e}",
                   "raw_llm_output": (raw_text or "")[:10000],
                   "extracted_content": None, "full_text": full_text}
            return fname, doc, f"JSON: {e}"
    
    is_valid, issues = validate_extraction(extracted, fname, doc_type)
    if not is_valid:
        fmeta['validation_issues'] = issues[:5]
    
    fmeta['usage'] = usage
    doc = {"file_metadata": fmeta, "extracted_content": extracted, "full_text": full_text}
    return fname, doc, None


def _extract_chunked(row, fmeta):
    """Chunked extraction for files >150K chars."""
    fname = row['filename']
    full_text = row['full_text'] or ''
    text_len = len(full_text)
    doc_type = row.get('document_type', '') or ''
    num_pages = int(row.get('num_pages', 0) or 0)
    
    chunks = []
    start = 0
    while start < text_len:
        end = min(start + CHUNK_SIZE, text_len)
        if end < text_len:
            for sep in ['\n\n', '\n', '. ']:
                brk = full_text.rfind(sep, start + CHUNK_SIZE - 5000, end)
                if brk > start:
                    end = brk + len(sep)
                    break
        chunks.append(full_text[start:end])
        start = end - CHUNK_OVERLAP if end < text_len else end
    
    pipe_log.info(f"      Chunking {fname[:55]} into {len(chunks)} chunks ({text_len:,} chars)")
    
    chunk_results = []
    for ci, chunk in enumerate(chunks):
        chunk_prompt = (
            f"You are an expert legal contract analyst. Extract from chunk {ci+1} of {len(chunks)} "
            f"of a {num_pages}-page healthcare provider contract. Return ONLY valid JSON, no markdown, "
            f"no code fences. Include rate_numeric (plain number) for every dollar amount, effective_date, "
            f"program, network on every rate row. For legal clause sections, copy COMPLETE verbatim text "
            f"into full_clause_text.\n\nUse this schema: {JSON_SCHEMA}\n\nCONTRACT TEXT (CHUNK {ci+1}/{len(chunks)}):\n"
        )
        raw_text, err_msg, usage = _call_llm_rest(chunk_prompt, chunk, max_tokens=MAX_OUTPUT_TOKENS, timeout=PER_FILE_TIMEOUT)
        
        if err_msg:
            pipe_log.warning(f"        Chunk {ci+1}/{len(chunks)} failed: {err_msg[:60]}")
            if '429' in str(err_msg):
                time.sleep(60)  # Rate limit backoff
            continue
        
        cleaned = clean_json_response(raw_text)
        try:
            chunk_results.append(json.loads(cleaned))
        except json.JSONDecodeError:
            repaired = _repair_truncated_json(cleaned)
            if repaired:
                chunk_results.append(repaired)
            else:
                pipe_log.warning(f"        Chunk {ci+1}/{len(chunks)} JSON parse failed")
    
    fmeta['chunked'] = True
    fmeta['num_chunks'] = len(chunks)
    fmeta['chunks_extracted'] = len(chunk_results)
    
    if chunk_results:
        merged = _merge_extractions(chunk_results)
        doc = {"file_metadata": fmeta, "extracted_content": merged, "full_text": full_text}
        return fname, doc, None
    else:
        doc = {"file_metadata": fmeta, "extraction_error": "All chunks failed",
               "extracted_content": None, "full_text": full_text}
        return fname, doc, "All chunks failed"


def _merge_extractions(chunk_results):
    """Merge multiple chunk extraction results into one."""
    merged = {}
    for cr in chunk_results:
        if not isinstance(cr, dict):
            continue
        for k, v in cr.items():
            if v is None or v == '' or v == [] or v == {}:
                continue
            if k not in merged or merged[k] is None or merged[k] == '' or merged[k] == [] or merged[k] == {}:
                merged[k] = v
            elif isinstance(v, list) and isinstance(merged[k], list):
                merged[k].extend(v)
            elif isinstance(v, dict) and isinstance(merged[k], dict):
                for dk, dv in v.items():
                    if dv and (dk not in merged[k] or not merged[k][dk]):
                        merged[k][dk] = dv
    return merged


# COMMAND ----------

# DBTITLE 1,Main Extraction Loop (3a + 3a-retry + 3b + 3c)
# ═══════════════════════════════════════════════════════════════════════════════
# MAIN EXECUTION: Process remaining files with parallel REST API calls
# ═══════════════════════════════════════════════════════════════════════════════
print("\n  Loading metadata and checking existing extractions...")
step3_start = time.time()
step2_df = pd.read_parquet(STEP2_FILE)
existing = {os.path.splitext(f)[0] for f in os.listdir(OUTPUT_DIR) if f.endswith('.json') and not f.startswith('_')}

# Find files that need processing (including previously failed ones)
needs_processing = []
for _, row in step2_df.iterrows():
    base = os.path.splitext(row['filename'])[0]
    json_path = os.path.join(OUTPUT_DIR, f"{base}.json")
    if base not in existing:
        needs_processing.append(row)
    elif os.path.exists(json_path):
        try:
            with open(json_path) as f:
                doc = json.load(f)
            if doc.get('extraction_error'):
                needs_processing.append(row)
        except Exception:
            needs_processing.append(row)

remaining_df = pd.DataFrame(needs_processing).sort_values('text_length', ascending=True).reset_index(drop=True)

pipe_log.info(f"Step 3: {len(existing):,} existing | {len(remaining_df):,} to process")
if len(remaining_df) == 0:
    pipe_log.info("Step 3: All files already extracted successfully!")
else:
    small = remaining_df[remaining_df['text_length'] <= 80_000]
    medium = remaining_df[(remaining_df['text_length'] > 80_000) & (remaining_df['text_length'] <= 150_000)]
    large = remaining_df[remaining_df['text_length'] > 150_000]
    pipe_log.info(f"  Tiers: small={len(small)} | medium(80-150K)={len(medium)} | large(>150K,chunked)={len(large)}")
    
    total_ok = total_err = 0
    tracker = ProgressTracker(OUTPUT_DIR, len(remaining_df))
    processing_order = pd.concat([small, medium, large]).reset_index(drop=True)
    
    pipe_log.info(f"  Starting {REST_CONCURRENCY}-worker parallel extraction via REST API...")
    
    with ThreadPoolExecutor(max_workers=REST_CONCURRENCY) as executor:
        futures = {}
        for idx, row in processing_order.iterrows():
            future = executor.submit(_extract_single_file, row)
            futures[future] = row['filename']
        
        for future in as_completed(futures):
            fname = futures[future]
            row_data = step2_df[step2_df['filename']==fname]
            tl = row_data.iloc[0]['text_length'] if len(row_data) > 0 else 0
            tier_label = "large(>150K)" if tl > 150000 else "medium(80-150K)" if tl > 80000 else "small"
            tracker.current_tier = tier_label
            
            try:
                result_fname, doc, error = future.result(timeout=PER_FILE_TIMEOUT + 120)
                json_path = os.path.join(OUTPUT_DIR, f"{os.path.splitext(result_fname)[0]}.json")
                _write_json(json_path, doc)
                
                if error:
                    total_err += 1
                    tracker.complete_batch([], [result_fname], [error], 0)
                else:
                    total_ok += 1
                    tracker.complete_batch([result_fname], [], [], 0)
                
                elapsed = time.time() - step3_start
                rate = (total_ok + total_err) / max(elapsed, 1) * 60
                eta = (len(remaining_df) - total_ok - total_err) / max(rate, 0.01)
                pipe_log.info(f"    [{total_ok+total_err}/{len(remaining_df)}] OK={total_ok} ERR={total_err} | {rate:.2f}/min | ETA={eta:.0f}min")
                
            except Exception as e:
                total_err += 1
                tracker.complete_batch([], [fname], [str(e)[:200]], 0)
                pipe_log.error(f"    Future error for {fname[:50]}: {e}")
            
            if time.time() - step3_start > STEP3_TIME_BUDGET:
                pipe_log.warning(f"Time budget exhausted. Saving progress.")
                executor.shutdown(wait=False, cancel_futures=True)
                break
    
    tracker.summary()

# Final summary
total_json = len([f for f in os.listdir(OUTPUT_DIR) if f.endswith('.json') and not f.startswith('_')])
total_ok_final = 0
total_err_final = 0
for f in os.listdir(OUTPUT_DIR):
    if not f.endswith('.json') or f.startswith('_'):
        continue
    try:
        with open(os.path.join(OUTPUT_DIR, f)) as fh:
            d = json.load(fh)
        if d.get('extracted_content'):
            total_ok_final += 1
        elif d.get('extraction_error'):
            total_err_final += 1
    except Exception:
        total_err_final += 1

print(f"\n{'='*80}")
print(f"  STEP 3 COMPLETE")
print(f"     Total JSON files: {total_json}")
print(f"     Successful: {total_ok_final}")
print(f"     Failed: {total_err_final}")
print(f"     Elapsed: {(time.time()-step3_start)/60:.1f} min")
print(f"{'='*80}")