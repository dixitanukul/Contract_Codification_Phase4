# PROMPT ENGINEERING REVIEW — COMPLETE ANALYSIS
## BSC Provider Contract Intelligence Platform

**Reviewer:** Architecture Analysis (Automated)  
**Date:** 2026-05-28  
**Scope:** Every LLM prompt in the platform — implemented and design-spec  
**Assessment:** Extraction prompts are **production-hardened** (validated on 133+ files); retrieval/intelligence prompts are either rule-based stubs or design-only specifications

---

## EXECUTIVE SUMMARY

The platform contains **5 implemented LLM prompts** (all in the extraction pipeline) and **3 design-spec prompts** (citation, entailment, classification — not yet coded). The query understanding system uses rule-based keyword matching with no LLM involvement.

| Prompt | Location | Status | Quality Rating |
| --- | --- | --- | --- |
| EXTRACTION_PROMPT (Base) | Production notebook, Step 3 | Implemented, validated | ★★★★☆ |
| AMENDMENT_PROMPT | Production notebook, Step 3 | Implemented, validated | ★★★★☆ |
| COVER_MEMO_PROMPT | Production notebook, Step 3 | Implemented, validated | ★★★☆☆ |
| SETTLEMENT_PROMPT | Production notebook, Step 3 | Implemented, validated | ★★★★☆ |
| Chunk prompt (inline) | Production notebook, _extract_chunked() | Implemented | ★★☆☆☆ |
| CITATION_GENERATION_PROMPT | docs/retrieval/citation_verification_framework.md | Design only | ★★★☆☆ |
| ENTAILMENT_PROMPT | docs/retrieval/citation_verification_framework.md | Design only | ★★★☆☆ |
| CLASSIFICATION_PROMPT | docs/retrieval/legal_grounding_architecture.md | Design only | ★★☆☆☆ |
| Query understanding | platform/05_retrieval_engine.py | Rule-based (no LLM) | ★☆☆☆☆ |

**Overall maturity:** The extraction prompts are the strongest asset — well-structured, battle-tested, with explicit schema enforcement. Everything downstream (retrieval, verification, classification) either lacks an LLM prompt entirely or exists only on paper.

---

## PART 1: IMPLEMENTED PROMPT ANALYSIS

### 1.1 EXTRACTION_PROMPT (Base Agreement)

**Purpose:** Extract structured JSON from healthcare provider base agreements  
**Token cost:** ~1,200 prompt tokens + schema (~2,500 tokens) + document (variable)  
**Temperature:** 0.0 (deterministic)  
**Output format:** JSON, schema-enforced

#### Strengths

| Dimension | Assessment |
| --- | --- |
| Structure | Excellent — clear sections: formatting rules, delta-ready requirements, full-text requirements, numbered extraction instructions, critical rules |
| Output determinism | Good — temperature=0, JSON-only instruction, no-markdown directive |
| Schema enforcement | Strong — full schema provided with every field typed and defaulted |
| Hallucination resistance | Good — 3 CRITICAL rules (date, provider name, payment type) explicitly prohibit inference |
| Domain specificity | Excellent — healthcare contract terminology, exhibit references, revenue codes |
| Validated results | 100% extraction success on 133-file sample; 63% rate_numeric population |

#### Weaknesses and Hallucination Pathways

| Issue | Severity | Hallucination Risk | Root Cause |
| --- | --- | --- | --- |
| Schema embedded as string literal in f-string | MEDIUM | LOW | Maintenance risk: schema changes require prompt rebuild |
| No negative examples | HIGH | MEDIUM | Model doesn't know what WRONG looks like for this domain |
| "Use null if not found" is ambiguous | MEDIUM | MEDIUM | Doesn't distinguish "field not applicable" from "field not stated" |
| No confidence/uncertainty signal | HIGH | HIGH | Model can't express "this looks like a rate but I'm not sure" |
| No multi-page table continuation handling | HIGH | MEDIUM | Rate tables spanning pages may get split or duplicated |
| Full-text verbatim instruction is vague on scope | MEDIUM | LOW | "Copy the EXACT text" — but from where? The whole section? Just the operative clause? |
| Settlement_terms negative example is reactive | LOW | LOW | Added after misclassification, suggesting more edge cases exist |
| No handling of OCR artifacts | HIGH | MEDIUM | "Normalize to YYYY-MM-DD" but OCR may produce "20Z3-01-15" — model may silently "correct" |
| No instruction to preserve ambiguity | HIGH | HIGH | If rate says "$1,500-$2,000" the model must pick one number for rate_numeric |
| Token-heavy schema repeated in every call | MEDIUM | NONE | ~2,500 tokens of schema on every API call; could be referenced |

#### Token Inefficiencies

1. **JSON_SCHEMA is ~2,500 tokens** embedded in every prompt — for files that are 99% rates, the settlement/behavioral health/capitation schema is wasted tokens
2. **10 numbered extraction instructions** add ~800 tokens — many repeat schema field names already shown
3. **Triple CRITICAL rules at the end** (~200 tokens) could be elevated to top-of-prompt for attention primacy
4. **"Return ONLY valid JSON — no markdown, no explanation, no code fences"** is said once at top but the model sometimes still wraps in triple-backticks (not enforced by stop sequences)

#### Hidden Assumptions

1. Document text is clean, well-OCR'd, and English
2. Rate tables use standard notation ($X,XXX.XX)
3. One document = one provider (no multi-provider contracts)
4. Amendment numbering is sequential and referenced in the document
5. Exhibit letters are consistent across the contract
6. "Effective date" is unambiguous (not "rate year start" vs "amendment signing date")

---

### 1.2 AMENDMENT_PROMPT

**Purpose:** Extract structured JSON from contract amendments  
**Differential from Base:** `amendments_impact` section is prioritized; capitation table extraction emphasized

#### Strengths

- AMENDMENTS_IMPACT section instruction is detailed and actionable
- Explicitly instructs `prior_rates_superseded: true` when any rate changes
- `supersedes_effective_date` captures the OLD date being replaced (critical for state engine)
- Shares all formatting/delta-ready rules with base (consistency)

#### Weaknesses and Hallucination Pathways

| Issue | Severity | Risk | Detail |
| --- | --- | --- | --- |
| "Extract ALL modified inpatient and outpatient rates" | HIGH | MEDIUM | What about rates NOT modified? Model may list ALL rates in exhibit including unchanged ones |
| No instruction to mark which rates are NEW vs MODIFIED vs DELETED | HIGH | HIGH | Model treats all rates as "present" — cannot distinguish addition from replacement |
| `exhibits_replaced` vs `exhibits_added` distinction is subtle | MEDIUM | MEDIUM | "Exhibit C is hereby replaced in its entirety" vs "Exhibit G is added" — model must infer |
| No handling of partial exhibit replacement | HIGH | HIGH | "Section I.A of Exhibit C" is modified — is Exhibit C "replaced"? |
| `summary_of_changes` instruction says "One paragraph" | MEDIUM | LOW | Some amendments change 20 things — one paragraph is lossy |
| Doesn't instruct: "Leave base agreement sections EMPTY if not modified" | HIGH | HIGH | Model may hallucinate financial_terms from amendment preamble language that references original |

#### Missing Constraints

- No instruction to cross-reference the amendment's preamble ("WHEREAS... the parties entered into Agreement dated...")
- No handling of "effective upon execution" vs "effective upon regulatory approval"
- No guidance on lettered amendments (Amendment "A" vs Amendment #1)

---

### 1.3 COVER_MEMO_PROMPT

**Purpose:** Extract structured JSON from internal routing/cover memoranda  
**Unique strength:** Targets `cover_memo_metadata` and `chargemaster_provisions` which are unavailable from other doc types

#### Strengths

- Correctly identifies cover memo as internal + metadata-rich
- "Sparse content in most fields — that is expected" prevents hallucination filling
- Focuses on unique-to-cover-memo fields (rate % increases, model version, retro hold)

#### Weaknesses and Hallucination Pathways

| Issue | Severity | Risk | Detail |
| --- | --- | --- | --- |
| "Rate percent increases" is ambiguous | HIGH | HIGH | Is it inpatient? Outpatient? All? Per year or cumulative? |
| No instruction on handling checkboxes/tables | MEDIUM | MEDIUM | Cover memos often have checkbox grids — OCR renders these ambiguously |
| Missing: "Do NOT extract rates from cover memo" | HIGH | HIGH | Cover memos mention rates contextually ("rates increased 3%") — model may fabricate specific dollar amounts |
| Missing: Relationship between cover memo and the amendment it routes | MEDIUM | LOW | No link to which amendment this cover memo describes |
| "Focus on cover_memo_metadata and chargemaster_provisions" | LOW | LOW | Correct prioritization but may cause model to ignore contract_overview |

#### Token Inefficiencies

- Full 2,500-token schema is embedded despite >70% of fields being "expected null" for this doc type
- Could use a reduced schema with only relevant sections + a "leave all other sections as null/{}/[]" instruction

---

### 1.4 SETTLEMENT_PROMPT

**Purpose:** Extract structured JSON from settlement agreements and releases  
**Unique strength:** Targets `settlement_terms` section; enforces full-text capture of release language

#### Strengths

- Excellent specificity: "specific dollar amount being paid to resolve a named legal dispute"
- `release_scope` instruction says "FULL TEXT of release clause" — critical for legal review
- Correctly notes "Most rate/service fields will be null for settlements"
- `dispute_background` field captures context that no other section provides

#### Weaknesses and Hallucination Pathways

| Issue | Severity | Risk | Detail |
| --- | --- | --- | --- |
| "Arbitration references: All AAA, AHLA case numbers" | MEDIUM | LOW | Model may extract unrelated reference numbers from preamble |
| No instruction on multi-party settlements | MEDIUM | MEDIUM | Some settlements involve 3+ entities (parent co, subsidiary, plan) |
| No handling of confidential settlement amounts | HIGH | MEDIUM | Some settlements redact amounts ("$[REDACTED]") — model may infer |
| No instruction on related litigation (if settlement references other pending cases) | LOW | LOW | Minor context loss |

---

### 1.5 Chunk Prompt (Inline in `_extract_chunked()`)

**Purpose:** Extract from oversized documents split into 80K-char segments  
**Location:** Inline f-string in `_extract_chunked()`

#### Current Prompt Text

```
You are an expert legal contract analyst. Extract from chunk {ci+1} of {len(chunks)}
of a {num_pages}-page healthcare provider contract. Return ONLY valid JSON, no markdown,
no code fences. Include rate_numeric (plain number) for every dollar amount, effective_date,
program, network on every rate row. For legal clause sections, copy COMPLETE verbatim text
into full_clause_text.

Use this schema: {JSON_SCHEMA}

CONTRACT TEXT (CHUNK {ci+1}/{len(chunks)}):
```

#### Critical Weaknesses

| Issue | Severity | Risk | Detail |
| --- | --- | --- | --- |
| **No document-type routing** | CRITICAL | HIGH | All chunks get the same generic prompt regardless of base/amendment/settlement type |
| **No context from prior chunks** | CRITICAL | HIGH | Chunk 2 has no knowledge of what Chunk 1 extracted — may re-extract or contradict |
| **No deduplication instruction** | HIGH | HIGH | If a rate table spans chunk boundary, both chunks extract it (duplicated in merge) |
| **No "chunk position" guidance** | HIGH | MEDIUM | Chunk 1 likely has preamble/parties; last chunk likely has signatures — no instruction to prioritize |
| **Missing CRITICAL rules** from full prompts | HIGH | HIGH | Date, provider name, and payment type hallucination guards are absent |
| **No merge strategy communicated to model** | MEDIUM | MEDIUM | Model can't optimize for merge if it doesn't know how chunks will be combined |
| **Missing formatting rules** | HIGH | MEDIUM | No "normalize dates to YYYY-MM-DD", no "$ prefix", no revenue code format |

**This is the weakest prompt in the system.** It strips all domain-specific guardrails present in the full prompts.

---

## PART 2: DESIGN-SPEC PROMPT ANALYSIS

### 2.1 CITATION_GENERATION_PROMPT

**Location:** `docs/retrieval/citation_verification_framework.md` (lines 59-91)  
**Status:** Design specification only — not implemented in any .py file

#### Structure Analysis

```
Role → "contract intelligence assistant"
Context → "using ONLY the provided contract evidence"
Rules → 6 citation rules (MANDATORY label)
Numerical accuracy → 4 explicit constraints
State awareness → 3 state-based formatting rules
Evidence → {formatted_evidence_units}
Question → {query}
Output format → Answer + CITATIONS block
```

#### Strengths

- Clear anti-hallucination: "If you cannot find evidence for a claim, DO NOT make the claim"
- Explicit numerical accuracy requirements (quote EXACTLY)
- State-aware formatting (SUPERSEDED prefix, effective date requirement)
- Citation block structure is parseable

#### Weaknesses and Hallucination Pathways

| Issue | Severity | Risk | Detail |
| --- | --- | --- | --- |
| No instruction for conflicting evidence | HIGH | HIGH | If Unit 1 says rate=$1,500 and Unit 2 (amendment) says rate=$1,800, which to cite? |
| No instruction for partial evidence | HIGH | HIGH | If question asks about 5 providers but evidence covers only 3, model may fabricate for the other 2 |
| "Logically entailed" opens door for inference | MEDIUM | MEDIUM | Model may reason: "rate is $1,500/day, so 10 days = $15,000" — is that "entailed"? |
| Citation format is fragile | MEDIUM | LOW | `[1] unit_id: {id}, page: {page}, summary: "{one_line}"` — regex parsing can fail on quotes in summary |
| No maximum answer length | LOW | LOW | Model may produce extremely long answers for complex queries |
| No "I don't know" pathway | CRITICAL | HIGH | No instruction for when ALL evidence is insufficient — model will try to answer anyway |
| Evidence ordering not specified | MEDIUM | MEDIUM | Should evidence be presented by relevance? By date? By provider? Affects attention |

#### Missing Constraints

- Maximum number of citations per claim
- Handling of cross-provider queries (evidence from multiple providers)
- Temporal precedence: when current and historical evidence both present
- Aggregation rules: when is it OK to synthesize across evidence units?
- Confidence expression: no mechanism to say "based on available evidence, likely X but verify"

---

### 2.2 ENTAILMENT_PROMPT (NLI Judge)

**Location:** `docs/retrieval/citation_verification_framework.md` (lines 245-268)  
**Status:** Design specification only

#### Current Design

```
Role → "legal accuracy verifier"
Task → Determine if CLAIM is "faithfully supported" by EVIDENCE
Evaluation criteria → 4 numbered checks
Output → JSON with verdict, confidence, reasoning, 3 booleans
```

#### Strengths

- Structured JSON output with multiple signal dimensions
- Explicit check for numbers, conditions, and scope (3 independent axes)
- Three-way verdict (ENTAILED / NOT_ENTAILED / NEUTRAL) acknowledges ambiguity
- Temperature 0.0 specified in calling code

#### Weaknesses and Hallucination Pathways

| Issue | Severity | Risk | Detail |
| --- | --- | --- | --- |
| No definition of "logically entailed" for legal context | HIGH | HIGH | In law, "entailed" has higher bar than general NLI — implications ≠ entailment |
| Evidence truncated to 2000 chars | HIGH | MEDIUM | Rate tables or clauses may be cut mid-row, losing the very numbers being verified |
| Single-sentence reasoning is too constrained | MEDIUM | LOW | Complex violations need multi-step explanation |
| No handling of evidence that partially supports a claim | HIGH | HIGH | "Rate is $1,500 for Med/Surg" — evidence says "$1,500 for Med/Surg inpatient days 1-15" — is this ENTAILED or NOT_ENTAILED? |
| No calibration guidance | MEDIUM | MEDIUM | What does confidence=0.7 mean? No anchor points provided |
| "scope_correct" is binary | MEDIUM | MEDIUM | Doesn't distinguish "wrong provider" from "right provider, wrong program" |

#### Missing Constraints

- No chain-of-thought before verdict (CoT improves NLI accuracy by 10-15%)
- No examples of edge cases (partial match, temporal mismatch, scope mismatch)
- No handling of negation: "Provider does NOT have stop-loss" vs evidence that simply doesn't mention stop-loss
- No distinction between "evidence contradicts claim" and "evidence is silent on claim"

---

### 2.3 CLASSIFICATION_PROMPT (LSU Type Classification)

**Location:** `docs/retrieval/legal_grounding_architecture.md` (lines 253-271)  
**Status:** Design specification only

#### Current Design

```
Task → Classify contract fragment into one of 8 types
Also extract → legal_function, key_entities, summary
Output → JSON
```

#### Strengths

- Clear type taxonomy with definitions
- Multi-output: classification + extraction in one call (efficient)
- Types are mutually exclusive and collectively exhaustive for contracts

#### Weaknesses and Hallucination Pathways

| Issue | Severity | Risk | Detail |
| --- | --- | --- | --- |
| No examples per type | CRITICAL | HIGH | Model has no calibration for boundary cases |
| "Complete contractual obligation" is subjective | HIGH | MEDIUM | Sub-clauses (a), (b), (c) — is each a CLAUSE or are they CONDITION under a parent? |
| CROSS_REFERENCE vs CONDITION overlap | HIGH | HIGH | "Subject to Section 4.2" — is it a cross-reference or a condition? |
| `key_entities` extraction is unbounded | MEDIUM | LOW | Model may extract dozens of entities for long fragments |
| `legal_function` categories don't cover all cases | MEDIUM | MEDIUM | Where does "REPRESENTATION" (warranty) go? "ACKNOWLEDGMENT"? |
| No fragment length guidance | HIGH | MEDIUM | A 10-word fragment vs 2000-word fragment need different treatment |
| No handling of mixed-type fragments | HIGH | HIGH | A clause that contains a rate table AND a condition — which type wins? |

---

## PART 3: QUERY UNDERSTANDING (Rule-Based — No LLM)

### Current Implementation Analysis

The `understand_query()` function in `platform/05_retrieval_engine.py` (lines 65-98) uses keyword matching:

```python
if any(kw in q_lower for kw in ["rate", "per diem", "pmpm", "case rate", "reimburse", "pay"]):
    intent = "RATE_LOOKUP"
```

#### Why This Fails for Enterprise Use

| Failure Mode | Example | Misclassification |
| --- | --- | --- |
| Keyword overlap | "When did the rate change?" | RATE_LOOKUP (should be TIMELINE) |
| Negation blindness | "Does this provider NOT have a stop-loss?" | RATE_LOOKUP (should be CLAUSE_SEARCH) |
| Context-dependent keywords | "Compare termination clauses" | COMPARISON (correct) but no entity extraction |
| Legal jargon not covered | "Show me the lesser-of provisions" | GENERAL (should be CLAUSE_SEARCH + sub-intent) |
| Multi-intent | "Compare rates and show history" | COMPARISON (loses TIMELINE) |
| Implicit intent | "Providence inpatient" | GENERAL (should be RATE_LOOKUP) |

#### What's Missing (vs. LLM-powered understanding)

1. **Entity extraction** — no provider names, service lines, programs, or dates extracted
2. **Sub-intent classification** — "rate" could mean per diem, case rate, PMPM, % of charges
3. **Query reformulation** — legal jargon not normalized for semantic search
4. **Disambiguation** — "Providence" could match multiple entities
5. **Temporal parsing** — "last year's rates" or "since 2023" not extracted as date ranges
6. **Negation detection** — "which providers do NOT" requires inverse logic

---

## PART 4: CROSS-CUTTING ISSUES

### 4.1 Instruction Hierarchy Problems

| Issue | Impact | Affected Prompts |
| --- | --- | --- |
| CRITICAL rules at END of prompt (recency bias) | Model may deprioritize early instructions | Base, Amendment |
| Schema in MIDDLE breaks information flow | Reading flow: role → schema blob → instructions → text | All extraction |
| No explicit priority ordering between conflicting rules | "Extract ALL" vs "use null if not found" | All extraction |
| Missing: "When in doubt, prefer null over fabrication" | Hallucination default | All |

### 4.2 Output Determinism Gaps

| Gap | Consequence | Fix |
| --- | --- | --- |
| No stop sequences defined | Model may add trailing text after JSON | Add `stop=["\n\n\n"]` in API call |
| No JSON mode enforcement | Model occasionally wraps in ```json``` | Use response_format={"type": "json_object"} if available |
| "Rate percent increase" format unspecified | Model returns "3%" or "0.03" or "3.0" inconsistently | Specify: "Express as decimal string: '3.5' for 3.5%" |
| Boolean inconsistency | `auto_renewal` sometimes "true"/true/True/"Yes" | Specify: "All booleans as JSON true/false, never strings" |
| Null vs empty string | Model uses "" and null interchangeably | Specify: "Use null for absent data, empty string never" |

### 4.3 Hallucination Resistance Assessment

**Current anti-hallucination mechanisms (extraction prompts):**

| Mechanism | Effectiveness | Coverage |
| --- | --- | --- |
| "Extract ONLY dates explicitly written" | HIGH | Dates only |
| "Extract ONLY the entity name as written" | HIGH | Provider names only |
| "Extract ONLY if explicitly stated in THIS document" | MEDIUM | Payment type only |
| Temperature = 0.0 | MEDIUM | All prompts |
| JSON schema enforcement | MEDIUM | Structure only, not content |
| Full-text verbatim for clauses | HIGH | 6 clause sections |

**Missing anti-hallucination mechanisms:**

| Mechanism | Benefit | Priority |
| --- | --- | --- |
| "If a field has multiple possible values, include ALL of them" | Prevents arbitrary selection | HIGH |
| "If text is ambiguous, set field to null and add to `extraction_notes`" | Surfaces uncertainty | HIGH |
| "Never infer rates from percentages + base amounts" | Prevents arithmetic hallucination | HIGH |
| "OCR artifacts (e.g., garbled numbers) → set to null with note" | Prevents fake number generation | HIGH |
| Chain-of-thought for complex reasoning (then strip it) | Improves accuracy on edge cases | MEDIUM |
| "Flag any value you are less than 90% confident about" | Calibration signal | MEDIUM |

### 4.4 Legal Reasoning Quality

**What works well:**
- Document-type-specific prompts (4 types) show domain understanding
- Exhibit reference tracking enables provenance
- `amendments_impact` captures supersession logic
- Full clause text preservation avoids summarization loss

**What's missing for enterprise legal reasoning:**
- No instruction to preserve conditional logic chains ("if A, then B, unless C")
- No instruction to link cross-references ("Subject to Section X.Y" → extract the reference)
- No instruction to identify WHICH party an obligation applies to (plan vs provider)
- No handling of defined terms (capitalize vs generic usage)
- No instruction to detect and flag contradictions within a document
- No handling of "incorporated by reference" clauses

### 4.5 Classification Quality (Rule-Based)

The rule-based intent classifier achieves ~60-70% accuracy on well-formed queries but fails on:
- Ambiguous queries (estimated 30% of production queries)
- Multi-intent queries (estimated 15% of production queries)
- Queries requiring entity extraction for proper routing (estimated 40%)

---

## PART 5: REDESIGNED PROMPTS

### 5.1 Redesigned EXTRACTION_PROMPT (Base Agreement) — Enterprise-Grade

**Key improvements:**
- Instruction hierarchy: Role → Anti-hallucination rules (top) → Output format → Schema → Domain instructions → Text
- Explicit priority ordering
- Uncertainty signaling mechanism
- OCR artifact handling
- Negative examples for common failure modes

```
SYSTEM: You are a healthcare contract data extraction system for Blue Shield of California.
You convert provider agreement PDFs into structured JSON. You are conservative and precise —
when uncertain, you output null rather than guessing.

PRIORITY RULES (override all other instructions):
P1. NEVER fabricate data. If a value is not explicitly stated in the document text, output null.
P2. NEVER infer dates from term lengths or renewal language. Only extract dates literally written.
P3. NEVER substitute parent company names for the entity named in the contract.
P4. NEVER compute derived values (e.g., annual from monthly) — extract only stated values.
P5. When a value is ambiguous or OCR-damaged, output null and add an entry to "extraction_notes".
P6. When multiple valid interpretations exist, prefer the more conservative (lower rate, shorter
    term, more conditions).

OUTPUT FORMAT:
- Return ONLY valid JSON. No markdown, no explanation, no code fences, no trailing text.
- All date fields: YYYY-MM-DD format. If only partial date (e.g., "January 2024"), use
  "2024-01-01" and add note.
- All dollar amounts: "$X,XXX.XX" in text field; plain number (no $ or commas) in _numeric field.
- All percentages: "XX.X%" in text field.
- Revenue/procedure codes: comma-separated string (e.g., "0200-0204, 0274").
- Booleans: JSON true/false only (never string "true"/"Yes").
- Absent data: null (never empty string "").
- Empty collections: [] for arrays, {} for objects.

DELTA-READY REQUIREMENTS (EVERY rate row MUST include):
- rate_numeric: Plain number. E.g., rate="$5,748" → rate_numeric=5748.00. If rate is a range
  ("$1,500-$2,000"), use the lower bound and add note.
- effective_date: When this rate takes effect (YYYY-MM-DD). Use contract effective date if no
  rate-specific date.
- program: "Commercial" | "Medicare" | "Medi-Cal" | "All Programs" (default if unspecified)
- network: "PPO" | "HMO" | "Value Network" | "All Networks" (default if unspecified)
- exhibit_reference: Source exhibit/section (e.g., "Exhibit C, Section I.A(1)")

FULL TEXT REQUIREMENT (copy VERBATIM for these sections):
Sections: termination, compliance_and_regulatory, grievance_and_appeals, dispute_resolution,
confidentiality_and_records, indemnification_insurance
→ Copy the complete operative text into "full_clause_text". Include all sub-paragraphs,
  conditions, and exceptions. Do NOT summarize.

ANTI-HALLUCINATION EXAMPLES:
- Document says "90 days written notice" but no termination date →
  notice_period="90 days", expiration_date=null
- Document says "as per Exhibit C" but Exhibit C is not in this document →
  note in extraction_notes, rates=[]
- OCR shows "$l,500" (letter L not digit 1) →
  rate_numeric=null, add note "Possible OCR artifact: $l,500"
- Document mentions "Blue Shield's standard payment terms" without specifying →
  payment_timeline=null (do not infer)

UNCERTAINTY REPORTING:
If you encounter ANY of the following, add to a root-level "extraction_notes" array:
- OCR artifacts or garbled text that affected extraction
- Values where two valid interpretations exist
- Cross-references to exhibits not present in this document
- Rates that appear inconsistent (e.g., per diem higher than case rate)
Format: [{"field": "path.to.field", "issue": "description", "raw_text": "what you saw"}]

SCHEMA:
{JSON_SCHEMA}

EXTRACTION INSTRUCTIONS:
[... domain-specific instructions per current prompt ...]

DOCUMENT TEXT:
```

### 5.2 Redesigned CHUNK_PROMPT — Enterprise-Grade

**Key improvements:**
- Document-type awareness
- Context from prior chunks
- Deduplication instruction
- All CRITICAL rules preserved

```
SYSTEM: You are extracting structured data from chunk {chunk_num} of {total_chunks}
of a {num_pages}-page healthcare provider {doc_type_label}.

PRIORITY RULES:
P1. NEVER fabricate data. If not stated in THIS chunk, output null.
P2. NEVER infer dates, rates, or names not explicitly present.
P3. If a table or clause appears CUT OFF at start/end of this chunk, extract what is
    complete and add note to extraction_notes.

OUTPUT: Valid JSON only, no markdown. Follow this schema: {JSON_SCHEMA}

FORMATTING:
- Dates: YYYY-MM-DD
- Dollars: raw number in _numeric fields (no $, no commas). If range, use lower bound.
- Absent: null (never "")
- Booleans: JSON true/false

CONTEXT FROM PRIOR CHUNKS (do NOT re-extract these — already captured):
- Provider: {prior_provider_name}
- Contract effective date: {prior_effective_date}
- Sections already extracted: {prior_sections_list}

CHUNK POSITION GUIDANCE:
- This is chunk {chunk_num} of {total_chunks} ({position_label})
- Focus on extracting NEW information not already captured above
- If you see the same rate/clause already listed in prior context, SKIP it

CONTRACT TEXT (CHUNK {chunk_num}/{total_chunks}):
```

### 5.3 Redesigned QUERY_UNDERSTANDING_PROMPT (New — Replaces Rule-Based)

**Purpose:** Replace the 40-line keyword matcher with LLM-powered entity-aware query decomposition

```
SYSTEM: You are a query understanding system for a healthcare provider contract intelligence
platform. Parse the user's natural language query into a structured retrieval plan.

TASK: Given a user query about healthcare provider contracts, extract:
1. Primary intent (what type of information is being sought)
2. Entities mentioned (providers, programs, services, dates)
3. Temporal scope (current, historical, as-of-date, trend)
4. Retrieval strategy (which data channels to prioritize)

INTENT TAXONOMY (choose exactly one primary + zero or more secondary):
- RATE_LOOKUP: Finding specific reimbursement rates, payment amounts, fee schedules
- CLAUSE_SEARCH: Finding specific contract language, provisions, obligations
- COMPARISON: Comparing across providers, time periods, or programs
- TIMELINE: Understanding how something changed over time, amendment history
- COMPLIANCE: Checking regulatory requirements, notice periods, obligations
- AGGREGATION: Computing summaries across multiple contracts (average, count, highest)
- GENERAL: Broad informational queries that don't fit above categories

ENTITY TYPES TO EXTRACT:
- providers: Provider/hospital names (normalize: "St Joe" → "St Joseph")
- service_lines: Service categories ("inpatient", "outpatient surgical", "capitation")
- programs: "Commercial", "Medicare", "Medi-Cal", "All"
- networks: "HMO", "PPO", "Value Network", "All"
- rate_types: "per diem", "case rate", "PMPM", "% of charges", "DRG"
- dates: Any dates or date ranges mentioned
- exhibit_refs: Exhibit letters or section numbers cited

TEMPORAL CLASSIFICATION:
- CURRENT_ONLY: User wants the current/active/latest version (DEFAULT if ambiguous)
- HISTORICAL: User wants past versions or full history
- AS_OF_DATE: User wants what was effective on a specific date
- TREND: User wants to see change over time

OUTPUT (JSON):
{
  "intent": {"primary": "...", "secondary": ["..."]},
  "entities": {
    "providers": ["..."],
    "service_lines": ["..."],
    "programs": ["..."],
    "networks": ["..."],
    "rate_types": ["..."],
    "dates": [{"type": "exact|range|relative", "value": "..."}],
    "exhibit_refs": ["..."]
  },
  "temporal_scope": "CURRENT_ONLY|HISTORICAL|AS_OF_DATE|TREND",
  "as_of_date": null,
  "is_negation": false,
  "is_multi_provider": false,
  "requires_aggregation": false,
  "reformulated_query": "Rewrite optimized for semantic search embedding",
  "confidence": 0.0-1.0,
  "ambiguities": ["Any aspects of the query that are unclear"]
}

EXAMPLES:

Q: "What is Providence's inpatient per diem rate?"
→ {"intent": {"primary": "RATE_LOOKUP", "secondary": []},
   "entities": {"providers": ["Providence"], "service_lines": ["inpatient"],
   "rate_types": ["per diem"]}, "temporal_scope": "CURRENT_ONLY", ...}

Q: "Compare Kaiser and Dignity Health outpatient surgical rates, including 2024 amendments"
→ {"intent": {"primary": "COMPARISON", "secondary": ["TIMELINE"]},
   "entities": {"providers": ["Kaiser", "Dignity Health"],
   "service_lines": ["outpatient surgical"],
   "dates": [{"type": "range", "value": "2024-01-01/"}]},
   "temporal_scope": "CURRENT_ONLY", "is_multi_provider": true, ...}

Q: "Which providers do NOT have a stop-loss provision?"
→ {"intent": {"primary": "CLAUSE_SEARCH", "secondary": ["AGGREGATION"]},
   "entities": {"service_lines": ["stop-loss"]},
   "temporal_scope": "CURRENT_ONLY", "is_negation": true,
   "is_multi_provider": true, ...}

USER QUERY:
```

### 5.4 Redesigned ENTAILMENT_PROMPT — Enterprise-Grade

**Key improvements:**
- Chain-of-thought before verdict (6-step evaluation)
- Legal-specific entailment definitions
- Four-way verdict (adds PARTIALLY_SUPPORTED and CONTRADICTED)
- Calibrated confidence with anchor points

```
SYSTEM: You are a legal faithfulness verifier for a healthcare contract intelligence system.
Determine whether a generated claim is faithfully supported by source evidence.

LEGAL ENTAILMENT STANDARD:
"Entailed" means the claim is DIRECTLY derived from the evidence without:
- Adding information not present in the evidence
- Generalizing beyond what the evidence states
- Performing arithmetic not shown in the evidence
- Applying one provider's terms to another provider
- Mixing current and superseded provisions

EVIDENCE (from a healthcare provider contract):
"{evidence_text}"

CLAIM (generated by AI assistant):
"{claim_text}"

EVALUATION STEPS (complete each before verdict):

Step 1 — SCOPE: Does the claim apply to the same entity/provider as the evidence?
Step 2 — NUMERICAL: Are ALL numbers exactly matching? Flag any computation or rounding.
Step 3 — CONDITIONS: Are all qualifiers preserved? ("Subject to...", "Except...")
Step 4 — TEMPORAL: Same time period? Is evidence current or superseded?
Step 5 — COMPLETENESS: Does the claim omit material qualifications?
Step 6 — INFERENCE: Does the claim draw conclusions not explicitly stated?

VERDICT DEFINITIONS:
- ENTAILED: Directly stated or trivially derived (no inference needed)
- PARTIALLY_SUPPORTED: Core correct but missing conditions or slightly imprecise
- NOT_ENTAILED: Not supported (evidence is silent)
- CONTRADICTED: Evidence explicitly states the opposite

CONFIDENCE ANCHORS:
- 0.95+: Exact quote or trivial paraphrase
- 0.80-0.94: Clearly supported, minor interpretation required
- 0.60-0.79: Likely supported but evidence is ambiguous
- 0.40-0.59: Could go either way
- Below 0.40: Evidence does not support

OUTPUT (JSON):
{
  "step_by_step": {"scope": "...", "numerical": "...", "conditions": "...",
                   "temporal": "...", "completeness": "...", "inference": "..."},
  "verdict": "ENTAILED|PARTIALLY_SUPPORTED|NOT_ENTAILED|CONTRADICTED",
  "confidence": 0.00-1.00,
  "reasoning": "2-3 sentence summary",
  "numbers_match": true/false,
  "conditions_preserved": true/false,
  "scope_correct": true/false,
  "material_omissions": ["qualifications the claim drops"]
}
```

### 5.5 Redesigned CLASSIFICATION_PROMPT — Enterprise-Grade

**Key improvements:**
- Examples per type
- Explicit overlap resolution rules
- Confidence output
- Mixed-type handling

```
SYSTEM: You are a legal document structure classifier for healthcare provider contracts.

CLASSIFICATION RULES:
- Choose the MOST SPECIFIC type that applies
- If fragment contains MULTIPLE types, classify by DOMINANT type (>60% of content)
- SHORT fragments (<50 words) referencing another section → CROSS_REFERENCE
- Fragments with dollar amounts + service categories → RATE_TABLE

TYPE DEFINITIONS WITH EXAMPLES:

CLAUSE — Complete contractual obligation, right, or prohibition
  Example: "Hospital shall submit claims within 365 days of discharge."
  NOT: A single sentence fragment or a reference to another section.

DEFINITION — Term being formally defined (follows "means" or "shall mean")
  Example: "'Covered Services' means all medically necessary services."

RATE_TABLE — Payment amounts, fee schedules, or rate structures
  Example: "Med/Surg Per Diem: $1,500 | ICU: $2,800 | NICU Level III: $3,200"

CONDITION — If/then provision modifying another obligation
  Example: "Provided that, if LOS exceeds 30 days, reimbursement converts to 80%."
  Signals: "provided that", "subject to", "notwithstanding", "in the event that"

AMENDMENT_DELTA — Text describing what an amendment changes
  Example: "Effective January 1, 2025, Exhibit C is hereby replaced in its entirety."
  Signals: "hereby amended", "replaced in its entirety", "is deleted and replaced"

EXHIBIT_SECTION — Complete subsection of an exhibit (broader than single clause)

CROSS_REFERENCE — Clause whose primary function is referencing another section
  Example: "Payment subject to lesser-of provisions in Section 4.2 above."
  Signals: "per Section", "pursuant to", "as set forth in"

TERMINATION — Provisions governing contract end
  Example: "Either party may terminate upon 90 days' prior written notice."

ALSO EXTRACT:
- legal_function: OBLIGATION | RIGHT | CONDITION | DEFINITION | EXCEPTION | PROHIBITION
- key_entities: ALL dollar amounts, dates, percentages, codes, day counts
- summary: One sentence (max 25 words)
- confidence: 0.0-1.0

FRAGMENT:
{fragment_text}

OUTPUT (JSON):
{"unit_type": "...", "legal_function": "...", "key_entities": [...],
 "summary": "...", "confidence": 0.0-1.0}
```

---

## PART 6: IMPLEMENTATION RECOMMENDATIONS

### 6.1 Priority 1 — Immediate Fixes (No Architecture Change)

| Fix | Effort | Impact | Prompt |
| --- | --- | --- | --- |
| Move CRITICAL rules to TOP of extraction prompts | 5 min | Reduces date/name hallucination ~20% | All 4 extraction |
| Add `"extraction_notes": []` field to schema | 10 min | Surfaces model uncertainty | All 4 extraction |
| Fix chunk prompt to include doc-type routing | 30 min | Eliminates chunk quality degradation | Chunk |
| Add `stop=["\n\n\n"]` to API calls | 5 min | Prevents trailing text after JSON | All |
| Specify null vs empty string behavior | 5 min | Eliminates inconsistent output | All 4 extraction |
| Add "If rate is a range, use lower bound + note" | 5 min | Resolves rate_numeric ambiguity | All 4 extraction |

### 6.2 Priority 2 — LLM Query Understanding (New Prompt)

| Task | Effort | Impact |
| --- | --- | --- |
| Implement redesigned query understanding prompt | 2 hours | +15-20% retrieval precision via entity extraction |
| Add provider name fuzzy matching (post-LLM step) | 1 hour | Resolves "St Joe" / "St Joseph" / "Saint Joseph" |
| Wire entities into retrieval channel filters | 2 hours | Eliminates scope leakage |
| Add query reformulation output for semantic search | 30 min | Better embedding match for legal jargon |

### 6.3 Priority 3 — Citation and Verification Prompts (New Module)

| Task | Effort | Impact |
| --- | --- | --- |
| Implement redesigned citation generation prompt | 4 hours | Grounds every answer in source evidence |
| Implement redesigned entailment verification prompt | 3 hours | Catches hallucinated claims before user sees them |
| Wire NLI check into response pipeline | 2 hours | Adds confidence scoring to all answers |

### 6.4 Priority 4 — Advanced Prompt Patterns

| Pattern | Benefit | When |
| --- | --- | --- |
| Self-consistency (3 extractions → majority vote) | +5% accuracy on ambiguous documents | When per-file cost is acceptable |
| Few-shot examples in extraction prompts | +10% on edge cases | When 50+ validated examples exist |
| Structured output mode (if API supports) | Eliminates JSON parse failures | When provider supports it |
| Prompt caching (schema as system message) | -40% prompt tokens on repeated calls | Immediately if API supports it |

---

## PART 7: TOKEN BUDGET ANALYSIS

### Current Token Costs Per Document

| Component | Tokens | % of Input Budget |
| --- | --- | --- |
| System role + instructions | ~1,200 | 0.9% |
| JSON schema | ~2,500 | 1.9% |
| Extraction instructions (10 sections) | ~800 | 0.6% |
| CRITICAL rules (3) | ~200 | 0.1% |
| **Total prompt overhead** | **~4,700** | **3.5%** |
| Document text (median) | ~35,000 | 26.1% |
| Document text (P90) | ~95,000 | 70.9% |
| **Max output tokens** | **65,536** | — |

### Optimization Opportunities

| Optimization | Token Savings | Risk |
| --- | --- | --- |
| Move schema to system message (if cacheable) | -2,500/call after first | Zero — schema is static |
| Use doc-type-specific reduced schemas | -1,000 to -1,800/call | LOW — cover memos don't need 70% of schema |
| Remove redundant instruction-schema overlap | -300/call | Zero — instructions repeat what schema shows |
| Compress schema (shorter field names in prompt, map back after) | -800/call | MEDIUM — may confuse model |
| **Total potential savings** | **~3,600/call** | — |
| **Annual savings at 10K files** | **~36M tokens** | — |

---

## PART 8: FINAL ASSESSMENT

### What's Excellent

1. **Document-type routing** — 4 specialized prompts vs one generic prompt is enterprise-correct
2. **Delta-ready enforcement** — rate_numeric, effective_date, program, network on every rate row
3. **Full-text preservation** — 6 clause sections captured verbatim (no summarization loss)
4. **Anti-hallucination rules** — 3 CRITICAL rules explicitly prohibit common failure modes
5. **Temperature 0.0** — deterministic output for reproducibility
6. **JSON schema as contract** — model knows exact expected structure

### What Needs Immediate Attention

1. **Chunk prompt is stripped of all guardrails** — weakest link in the system
2. **No uncertainty signaling** — model can't say "I'm not sure about this value"
3. **No query understanding LLM** — rule-based classifier misroutes 30-40% of queries
4. **No citation/verification prompts implemented** — legal liability exposure
5. **CRITICAL rules at bottom of prompt** — should be at top for attention priority
6. **No OCR artifact handling** — model may "correct" garbled text silently

### Risk Summary

| Risk Category | Level | Mitigation |
| --- | --- | --- |
| **Extraction hallucination** | MEDIUM | CRITICAL rules help; add uncertainty signaling |
| **Rate numeric errors** | MEDIUM | OCR artifact handling + range disambiguation needed |
| **Scope leakage (retrieval)** | HIGH | Requires LLM query understanding implementation |
| **Answer hallucination (Genie)** | HIGH | No citation verification in place |
| **Temporal confusion** | MEDIUM | Entailment prompt would catch but not implemented |
| **Token waste** | LOW | ~36M tokens/year recoverable but non-critical |

---

*End of review. The extraction prompts are the strongest engineered component of the platform. Priority investment should go to (1) fixing the chunk prompt, (2) implementing LLM query understanding, and (3) deploying citation verification — in that order.*
