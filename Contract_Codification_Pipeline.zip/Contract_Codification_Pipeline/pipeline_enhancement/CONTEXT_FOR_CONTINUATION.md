# COMPLETE PLATFORM UNDERSTANDING — Context for Continuation

**Created**: May 2026  
**Purpose**: Full architectural understanding of the Contract Codification Pipeline, enabling any new session to continue analysis, refactoring, or enhancement work without re-reading the repository.

**Related documents in this folder**:
- `architectural_analysis.md` — Full platform dependency graph, layer classification, and final judgment
- `extraction_layer_deep_analysis.md` — Module-by-module critique of the extraction pipeline (04-10)

---

## PLATFORM IDENTITY

**What it is**: A vertically-integrated contract intelligence system for Blue Shield of California Provider Contracting.

**What it does**: Extracts structured data from 10,372 provider contract PDFs and serves it through Genie Space (NL queries), Dashboard (portfolio analytics), Retrieval Engine (citation-grounded Q&A), and Intelligence Engine (negotiation support).

**Repository**: `/Workspace/Users/adixit01@blueshieldca.com/Contract_Codification_Pipeline`

**Schema**: `dev_adb.raw` | **Runtime**: DBR 18.0 | **Cloud**: Azure

---

## REPOSITORY STRUCTURE

```
Contract_Codification_Pipeline/
├── extraction/              ← 15 notebooks (01-15): PDF → OCR → LLM → tables
│   ├── 01_file_discovery      Scan Volume, prefetch to SSD, checkpoint
│   ├── 02_ocr_extraction      2-tier: pypdf + ai_parse_document
│   ├── 03_metadata_parsing    Provider_id, doc_type from filenames
│   ├── 04_llm_prompts         4 prompt templates (Base/Amendment/CoverMemo/Settlement)
│   ├── 05_llm_extraction      REST API engine (3 workers, chunking, retry, JSON repair)
│   ├── 06_validation          rate_numeric gap-fill, medical codes, quality scoring
│   ├── 07_consolidation       Per-provider merge, amendment ordering, supersession
│   ├── 08_build_rates         JSON → tbl_contract_rates_all + financial_protections + regional_factors
│   ├── 09_build_terms         JSON → clauses + codes + parties + services tables
│   ├── 10_build_documents     JSON → documents_master + dim_provider_canonical
│   ├── 11_enrich_tables       Program normalization, VS-ready views
│   ├── 12_build_genie         4 AI-optimized serving tables (Genie Space)
│   ├── 13_build_serving       Capitation card, VS-ready table
│   ├── 14_quality_audit       LLM-based extraction quality comparison
│   └── 15_gap_filler          Re-extract fields flagged by audit
├── platform/                ← 12 Python modules (00-11): intelligence runtime
│   ├── 00_config.py           Constants, utilities, feature flags
│   ├── 01_execute_ddl.py      Create 18+ tables + seed taxonomy
│   ├── 02_state_engine.py     Contract + amendment registries (1,948 + 1,570 rows)
│   ├── 03_reimbursement_migration.py  V1→V2 (21K rate_rules, 741 stop_loss)
│   ├── 04_legal_chunking.py   83K legal units + VS delta sync index
│   ├── 05_retrieval_engine.py 4-channel hybrid retrieval
│   ├── 06_reranking_service.py 3-stage reranking (6 legal signals)
│   ├── 07_citation_verification.py 6-check verification + telemetry
│   ├── 08_intelligence.py     Benchmarks + spend + savings + renewal
│   ├── 09_scenario_engine.py  What-if simulation
│   ├── 10_leverage_scoring.py Bilateral leverage scoring
│   └── 11_evaluation_harness.py Golden queries + monitoring
├── sql/                     ← 3 DDL files
│   ├── state_engine_ddl.sql   5 tables (contract_registry, amendment_registry, rate_facts_bitemporal, clause_facts, document_lineage)
│   ├── reimbursement_ddl.sql  9 tables (rate_rules, formula_components, stop_loss, carve_outs, escalators, conditions, lesser_of, taxonomy, patterns)
│   └── taxonomy_seed.sql      ~50 service line taxonomy rows + 45 patterns
├── data/
│   ├── checkpoints/           Extraction resume state
│   ├── json_extract/          Per-PDF LLM outputs (3,519 files)
│   └── json_consolidated/     Per-provider merged (456 files)
├── docs/                    ← 26 design documents
│   ├── state_engine/          6 docs (bitemporal, supersession, point-in-time, etc.)
│   ├── reimbursement/         8 docs + SQL references
│   ├── retrieval/             5 docs (architecture, reranking, citation, evaluation)
│   ├── intelligence/          5 docs (negotiation, spend, renewal, scenarios, leverage)
│   ├── implementation_prompt.md
│   └── contract_corpus_summary.md
├── pipeline_enhancement/    ← This folder (architectural analysis outputs)
└── README.md
```

---

## DATA FLOW (End-to-End)

```
/Volumes/.../Provider_Contracts (10,372 PDFs, 597 folders)
    │
    ▼ [01] File Discovery (scan, prefetch to NVMe SSD, checkpoint)
    │
    ▼ [02] OCR (Tier 1: pypdf 82%, Tier 2: ai_parse_document 18%)
    │
    ▼ [03] Metadata (provider_id, doc_type from filename patterns)
    │
    ▼ [04+05] LLM Extraction (Claude Sonnet 4.5, 4 prompts, 80K chunks)
    │         Output: json_extract/*.json (CANONICAL SOURCE OF TRUTH)
    │
    ├─▼ [06] Validation (rate_numeric fill, medical codes, quality scoring)
    │
    ├─▼ [07] Consolidation (per-provider merge, amendment ordering)
    │         Output: json_consolidated/*.json
    │
    ├─▼ [08] Build Rates → tbl_contract_rates_all (68K)
    │                     tbl_contract_financial_protections (1.5K)
    │                     tbl_contract_regional_factors (2K)
    │
    ├─▼ [09] Build Terms → tbl_contract_clauses_terms (15K)
    │                     tbl_contract_codes_events (3K)
    │                     tbl_contract_parties (1K)
    │                     tbl_contract_services_quality (2K)
    │
    ├─▼ [10] Build Docs  → tbl_contract_documents_master (74 cols)
    │                     dim_provider_canonical (456→278 facilities)
    │
    ├─▼ [11] Enrich (program_normalized, tbl_contract_terms_vs_ready)
    │
    ├─▼ [12] Build Genie → tbl_genie_provider_profile (278)
    │                     tbl_genie_rates_current (deduped)
    │                     tbl_genie_contract_terms
    │                     tbl_genie_amendment_timeline
    │
    ├─▼ [13] Build Serving → tbl_serving_capitation_card
    │
    ├─▼ [platform/02] State Engine → tbl_v2_contract_registry (1,948)
    │                              tbl_v2_amendment_registry (1,570)
    │
    ├─▼ [platform/03] Reimb Migration → tbl_reimb_rate_rules (21K)
    │                                   tbl_reimb_stop_loss (741)
    │
    ├─▼ [platform/04] Legal Chunking → tbl_retrieval_legal_units (83K)
    │                                   idx_legal_units_v2 (VS index)
    │
    ├─▼ [platform/05-07] Retrieval → Reranking → Citation Verification
    │
    └─▼ [platform/08-11] Intelligence → Benchmarks, Spend, Scenarios, Leverage
```

---

## KEY TABLES (dev_adb.raw)

### V1 Tables (from extraction pipeline)
| Table | Rows | Purpose | Key Columns |
| --- | --- | --- | --- |
| tbl_contract_rates_all | ~68K | All rates (current + superseded) | provider_id, rate_category, service_category, rate_numeric, status, amendment_order |
| tbl_contract_financial_protections | ~1.5K | Stop-loss, outlier thresholds | protection_type, threshold_numeric, reimbursement_pct_numeric |
| tbl_contract_clauses_terms | ~15K | Verbatim clause text + sections + definitions | content_type, topic, content_text |
| tbl_contract_documents_master | ~3.5K | 74-col document spine | source_filename, provider_id, document_type, amendment_order, effective_date_parsed |
| dim_provider_canonical | 456 | Identity resolution (456 IDs → 278 facilities) | provider_id, canonical_name, primary_provider_id, is_primary_id |
| tbl_genie_rates_current | ~5K | Deduped current rates for Genie | provider_id, rate_category, rate_numeric, program_normalized |
| tbl_genie_amendment_timeline | ~3.5K | Amendment chain per provider | provider_id, amendment_order, document_type, effective_date_parsed |
| tbl_genie_provider_profile | 278 | Pre-joined facility-level summary | provider_id, provider_name, total_rates, avg_inpatient_per_diem |

### V2 Tables (from platform layer)
| Table | Rows | Purpose | Key Columns |
| --- | --- | --- | --- |
| tbl_v2_contract_registry | 1,948 | Contract-level entity | contract_id, provider_id, status, agreement_type, payment_model |
| tbl_v2_amendment_registry | 1,570 | Amendment scope classification | amendment_id, contract_id, scope_type, scope_confidence |
| tbl_v2_rate_facts_bitemporal | **0 (EMPTY)** | Designed but never populated | valid_from/to, tx_from/to, supersession_type |
| tbl_reimb_rate_rules | 21,074 | V2 rates with formula_json | rule_id, contract_id, formula_type, formula_json, rate_numeric |
| tbl_reimb_stop_loss | 741 | Typed stop-loss provisions | stop_loss_type, attachment_level, reimburse_percentage |
| tbl_retrieval_legal_units | 83,008 | Chunked legal units for VS search | unit_id, unit_text, unit_type, provider_id, is_current |
| tbl_intel_benchmark_results | 1,399 | Percentile rates per service line | rate_domain, service_line, p10/p25/p50/p75/p90 |
| tbl_intel_provider_spend_summary | 348 | Provider-level spend + savings | estimated_annual_spend, pct_above_median, total_savings_opportunity |
| tbl_intel_leverage_scores | 348 | Bilateral leverage | plan_leverage_total, prov_leverage_total, net_leverage, recommended_posture |

---

## FEATURE FLAGS

| Flag | Status | Implication |
| --- | --- | --- |
| CLAIMS_AVAILABLE | **False** | All spend/savings numbers are heuristic (rate × 50 × 12) |
| RERANKER_DEPLOYED | **False** | Cross-encoder disabled; reranking uses score + 0.1 boost |
| FULL_CORPUS_PROCESSED | **False** | Only 199/10,372 PDFs processed (1.9%) |

---

## CRITICAL ARCHITECTURAL FINDINGS

### 1. The platform has TWO MINDS
- **Extraction pipeline** (extraction/): Pragmatic, battle-tested, ships working code
- **Platform layer** (platform/): Aspirational, heavily designed, largely placeholder

### 2. Rate data exists in 5+ representations
1. `json_extract/*.json` (source)
2. `tbl_contract_rates_all` (V1 flat)
3. `tbl_genie_rates_current` (V1 deduped)
4. `tbl_reimb_rate_rules` (V2 with formula_json)
5. `tbl_retrieval_legal_units` (re-textualized for embeddings)
6. `tbl_v2_rate_facts_bitemporal` (**EMPTY** — never populated)

### 3. Supersession computed 3 times independently
1. `07_consolidation` — amendment_order ranking in Python
2. `08_build_rates` 11a-fix — PARTITION BY provider ORDER BY amendment_order DESC
3. `platform/02_state_engine` — reads from tbl_genie_amendment_timeline

### 4. Intelligence layer is fabricated
- `estimated_annual_spend = avg_rate × total_rate_rules × 50` (meaningless heuristic)
- Leverage scores use hardcoded constants (plan_market_share=0.25, plan_quality_lever=0.6)
- Scenarios use `volume_per_line = 50` uniformly

### 5. Retrieval pipeline is 60% placeholder
- Channel 4 (structural): not implemented
- RRF fusion: not coded
- Cross-encoder: disabled (RERANKER_DEPLOYED=False)
- NLI check: keyword overlap proxy, no LLM call
- VS index: may not be synced

### 6. Empty tables (designed but never populated)
- `tbl_v2_rate_facts_bitemporal` (24 columns, dual timelines)
- `tbl_reimb_formula_components` (expression tree decomposition)
- `tbl_reimb_escalators`
- `tbl_reimb_conditions`
- `tbl_retrieval_telemetry`

---

## LAYER CLASSIFICATION

| Layer | Classification |
| --- | --- |
| Extraction Pipeline (01-07) | **Mission Critical** |
| Table Building (08-10) | **Mission Critical** |
| Enrichment + Genie (11-12) | **Mission Critical** |
| Serving/Quality (13-15) | **Valuable** |
| State Engine (platform/02) | **Valuable** |
| Reimbursement Migration (03) | **Nice to Have** |
| Legal Chunking (04) | **Valuable** |
| Retrieval Engine (05) | **Nice to Have** |
| Reranking Service (06) | **Redundant** |
| Citation Verification (07) | **Redundant** |
| Intelligence (08) | **Nice to Have** (without claims) |
| Scenario Engine (09) | **Dead Weight** |
| Leverage Scoring (10) | **Dead Weight** |
| Evaluation Harness (11) | **Nice to Have** |

---

## CORRECT TARGET ARCHITECTURE

```
STRUCTURED (rates, dates, codes) → Extraction-First (keep as-is)
    PDF → JSON → Tables → SQL Analytics

NARRATIVE (clauses, provisions) → Retrieval-First (replace full_clause_text)
    PDF → Chunks → Embeddings → Runtime Reasoning

TEMPORAL (amendments, supersession) → Graph/State-First (consolidate 3 implementations)
    Documents → Amendment Graph → Point-in-Time Query
```

---

## RECOMMENDATIONS (from analysis)

### Keep exactly as-is:
- 04_llm_prompts, 05_llm_extraction, 08_build_rates (core IP)

### Slim down:
- 06_validation → just rate_numeric gap-fill + medical code regex

### Merge into state engine:
- 07_consolidation's amendment ordering → single authoritative implementation

### Convert to retrieval-only:
- full_clause_text extraction → serve from VS index at query time
- sections[].content_summary → generate at query time
- key_definitions{} → extract on demand

### Kill entirely:
- Scenario engine (09), leverage scoring (10)
- tbl_v2_rate_facts_bitemporal DDL
- formula_components DDL
- Reranking service (06), citation verification (07)

### Defer until claims connected:
- Intelligence pipeline (08), spend summaries, savings, renewal priority

### Consolidate:
- Merge V1 and V2 rate tables into ONE canonical rate table
- Single supersession authority (not 3 independent implementations)

---

## TECHNICAL GOTCHAS (from implementation)

- SQL files need quote-aware semicolon splitting (COMMENT strings contain `;`)
- Delta DEFAULT columns need feature flag; fallback: strip DEFAULT and retry
- `exhibits_replaced_count`, `sections_modified_count` are STRING (JSON arrays), not INT
- `prior_rates_superseded` is STRING 'True'/'False', not BOOLEAN
- `aggregate_cap` and `corridor` in financial_protections are STRING (need try_cast)
- Correlated EXISTS subqueries not supported on this runtime — rewrite as JOIN
- `tbl_serving_capitation_card` has flat schema: `age_gender_band`, `pmpm_rate`
- VS SDK needs `%pip install databricks-vectorsearch` + Python restart on shared compute
- LLM extraction: NEVER use Spark SQL ai_query() for large files — use direct REST API
- Largest single extraction call: 46K input + 48K output = 90K total tokens

---

## SERVING LAYER ASSETS

| Asset | ID | Purpose |
| --- | --- | --- |
| Genie Space | `01f14d360bd51f8d801452065b2df600` | Natural language contract queries |
| Dashboard | `01f153b41dc51de8bb4e0a3cf16bb7e1` | Portfolio-level analytics |
| VS Endpoint | `contract_intelligence_vs_endpoint` | Semantic search |
| VS Index | `dev_adb.raw.idx_legal_units_v2` | Delta sync on legal_units |
| Embedding Model | `databricks-gte-large-en` | 1024-dim embeddings |
| LLM | `databricks-claude-sonnet-4-5` | Extraction + reasoning |

---

## FINAL VERDICT

**55-60% genuinely valuable** (extraction, table building, Genie serving, state registries).  
**40-45% complexity without ROI** (V2 schema duplication, placeholder retrieval, fabricated intelligence, empty tables, expression trees nobody evaluates).

**Priority path forward**:
1. Process remaining 10K PDFs (the actual bottleneck)
2. Connect claims data feed (enables real intelligence)
3. Consolidate rate representations (one canonical table)
4. Unify supersession logic (one state engine)
5. Deploy VS index + retrieval for legal clauses
6. THEN rebuild intelligence on real utilization data