# COMPLETE TABLE-BY-TABLE REVIEW
## Provider Contract Intelligence Platform — All Tables Assessment
**Generated**: 2026-05-24  
**Total Tables Reviewed**: 44 (32 tables + 5 empty DDL tables + 4 views + 3 dims)  
**Schema**: `dev_adb.raw`

---

## TABLE INVENTORY SUMMARY

| Layer | Tables | Populated | Empty/Placeholder | Views |
|-------|--------|-----------|-------------------|-------|
| V1 Extraction Base | 11 | 11 | 0 | 0 |
| V1 Genie Serving | 3 | 3 | 0 | 1 |
| V2 State Engine | 7 | 2 | 5 | 0 |
| V2 Reimbursement | 9 | 4 | 5 | 0 |
| V2 Retrieval | 2 | 1 | 1 | 0 |
| V2 Intelligence | 7 | 5 | 2 | 0 |
| V2 Evaluation | 1 | 1 | 0 | 1 |
| Telemetry | 1 | 0 | 1 | 0 |
| **TOTAL** | **41** | **27** | **14** | **2** |

---

## LAYER 1: V1 EXTRACTION BASE TABLES

---

### TABLE 1: `tbl_contract_rates_all`

**Purpose**: Master table of ALL rate entries extracted from contract PDFs — inpatient, outpatient, capitation, case rates across all document versions.

**Why it exists**: The atomic financial fact table. Every dollar amount, per diem, PMPM, DRG weight, or percentage mentioned in a contract becomes a row here.

| Dimension | Assessment |
|-----------|-----------|
| **Upstream** | `json_extract/*.json` → 08_build_rates notebook |
| **Downstream** | 03_reimbursement_migration (→ tbl_reimb_rate_rules), 12_build_genie (→ tbl_genie_rates_current), 04_legal_chunking (RATE_TABLE units) |
| **Foundational/Derived** | FOUNDATIONAL — direct extraction from source PDFs |
| **Actually valuable** | YES — core financial data for the entire platform |
| **Improves retrieval** | YES — bootstraps RATE_TABLE legal units for VS embedding |
| **Improves explainability** | YES — rate_text preserves original contract language |
| **Improves intelligence** | YES — source for benchmarks, renewal scoring, savings |
| **Improves demo** | YES — feeds Genie rates table and KPI calculations |
| **Introduces debt** | YES — document-level supersession heuristic, 37% missing rate_numeric |

**Schema Quality**: GOOD — 30+ columns cover identity, classification, formula, applicability, provenance, status  
**Naming Quality**: GOOD — `rate_category`, `rate_numeric`, `rate_text` are clear  
**Data Typing**: MIXED — rate_numeric is FLOAT (good), but effective_date_parsed is STRING with varied formats  
**Primary Keys**: NONE explicitly — dedup via provider_id + source_filename + rate_category + service_category  
**Foreign Keys**: provider_id links to dim_provider_canonical; source_filename links to documents_master  
**Duplication**: 27.6% pre-V8-fix → 3.7% post-fix — residual duplicates from amendment restatements  
**Denormalization**: Heavy — provider_name repeated on every row (intentional for Spark query patterns)  
**Partitioning**: None explicit — could benefit from Z-ORDER on (provider_id, rate_category)  
**Delta Suitability**: EXCELLENT — append/overwrite pattern, time-travel for audit  
**Query Efficiency**: GOOD for filtered queries; full scans needed for benchmarks (21K+ rows manageable)  
**Amendment Handling**: status column (current/superseded) via doc-level heuristic with scope-aware fallback  
**Temporal Handling**: effective_date_parsed (STRING) — inconsistent formats

| Metric | Score |
|--------|-------|
| Business value | 10/10 — Core financial data |
| Technical value | 8/10 — Well-structured, some typing issues |
| Retrieval value | 7/10 — Bootstraps rate units but synthetic text quality questionable |
| Intelligence value | 10/10 — Source for all financial intelligence |
| Demo value | 9/10 — Powers Genie rates + KPIs |
| Risk | MEDIUM — supersession heuristic can mark valid rates as expired |

**Optimizations**: Z-ORDER by (provider_id, rate_category); add GENERATED ALWAYS AS for rate_numeric parse; fix effective_date to DATE type  
**Should remain**: YES — foundational  
**Should change**: Fix supersession to scope-aware; standardize date format  
**Merge/Split**: No — appropriate granularity

---

### TABLE 2: `tbl_contract_regional_factors`

**Purpose**: County-level geographic rate adjustment factors (multipliers applied to base rates by region).

**Why it exists**: California healthcare contracts often specify different rates by county/region.

| Dimension | Assessment |
|-----------|-----------|
| **Upstream** | `json_extract/*.json` → 08_build_rates |
| **Downstream** | None currently (no consumer) |
| **Foundational/Derived** | FOUNDATIONAL — direct extraction |
| **Actually valuable** | LOW — no downstream consumer, not in Genie/Intelligence/Retrieval |
| **Improves retrieval** | NO |
| **Improves explainability** | POTENTIALLY — could explain rate variations by geography |
| **Improves intelligence** | POTENTIALLY — if linked to rate_rules for geographic benchmarking |
| **Improves demo** | NO — not surfaced anywhere |
| **Introduces debt** | MINIMAL — exists harmlessly |

**Schema Quality**: ADEQUATE — county, factor columns  
**Rows**: 5,710  
**Primary Keys**: None  
**Amendment Handling**: None  
**Temporal Handling**: None

| Metric | Score |
|--------|-------|
| Business value | 4/10 — Useful for geographic rate analysis but unconnected |
| Technical value | 3/10 — No consumer, no optimization |
| Retrieval value | 0/10 |
| Intelligence value | 3/10 — Could enable geographic benchmarking |
| Demo value | 0/10 |
| Risk | LOW — benign |

**Should remain**: YES but should be connected to rate_rules or intelligence layer  
**Should change**: Add contract_id FK; integrate into geographic benchmark computation  
**Merge/Split**: Could merge into rate_rules as geographic modifier metadata

---

### TABLE 3: `tbl_contract_financial_protections`

**Purpose**: Stop-loss, outlier, risk corridor, and exception provisions extracted from contracts.

**Why it exists**: Financial protections are critical for risk management — they cap the plan's exposure per case or in aggregate.

| Dimension | Assessment |
|-----------|-----------|
| **Upstream** | `json_extract/*.json` → 08_build_rates |
| **Downstream** | 03_reimbursement_migration (→ tbl_reimb_stop_loss + tbl_reimb_carve_outs), 12_build_genie (→ provider_profile.has_stop_loss) |
| **Foundational/Derived** | FOUNDATIONAL |
| **Actually valuable** | YES — stop-loss provisions directly affect financial exposure |
| **Improves retrieval** | INDIRECTLY — feeds stop_loss which feeds legal units |
| **Improves intelligence** | YES — has_stop_loss flag in benchmarks |
| **Improves demo** | YES — provider profile shows stop_loss_threshold |
| **Introduces debt** | YES — aggregate_cap and corridor are STRING not FLOAT; requires try_cast |

**Schema Quality**: ADEQUATE — threshold_numeric, reimbursement_pct_numeric available alongside text  
**Naming Quality**: GOOD — protection_type, threshold_text, reimbursement_pct  
**Data Typing**: MIXED — some columns are STRING that should be FLOAT (documented in custom instructions)  
**Rows**: 2,077

| Metric | Score |
|--------|-------|
| Business value | 8/10 — Critical for risk quantification |
| Technical value | 6/10 — STRING typing issues |
| Retrieval value | 4/10 — Indirect (via stop_loss migration) |
| Intelligence value | 7/10 — Stop-loss presence is a key negotiation signal |
| Demo value | 6/10 — Powers provider profile metrics |
| Risk | MEDIUM — mistyped columns require defensive casting |

**Should remain**: YES  
**Should change**: Cast STRING columns to proper FLOAT/NUMERIC types  
**Merge/Split**: No — separate from rates is correct (different cardinality)

---

### TABLE 4: `tbl_contract_clauses_terms`

**Purpose**: Extracted clauses, sections, key definitions, and full verbatim clause text from contracts.

**Why it exists**: The legal content table — every termination clause, confidentiality provision, dispute resolution section as structured rows.

| Dimension | Assessment |
|-----------|-----------|
| **Upstream** | `json_extract/*.json` → 09_build_terms |
| **Downstream** | 12_build_genie (→ vw_genie_contract_terms), 13_build_serving (→ tbl_contract_terms_vs_ready) |
| **Foundational/Derived** | FOUNDATIONAL |
| **Actually valuable** | YES — core legal content for clause search and Q&A |
| **Improves retrieval** | YES — major source for CLAUSE/DEFINITION/SECTION legal units |
| **Improves explainability** | YES — full_clause_text provides verbatim source evidence |
| **Improves intelligence** | INDIRECTLY — clause presence/absence drives negotiation strategy |
| **Improves demo** | YES — powers clause search in "Ask Anything" engine |
| **Introduces debt** | MODERATE — content_text quality varies (some headers only) |

**Schema Quality**: GOOD — content_type taxonomy (clause/section/definition), topic classification  
**Rows**: 31,056  
**Duplication**: Across amendment versions (same clause from base + each amendment)  
**Amendment Handling**: No is_current flag at this layer (added in vw_genie_contract_terms)

| Metric | Score |
|--------|-------|
| Business value | 9/10 — Legal content is the platform's intellectual core |
| Technical value | 7/10 — Good structure, some noise |
| Retrieval value | 9/10 — Primary source for clause/section retrieval |
| Intelligence value | 5/10 — Not directly used in intelligence computations |
| Demo value | 9/10 — Powers both Genie clause queries and Ask Anything |
| Risk | LOW — stable, well-consumed |

**Should remain**: YES — foundational  
**Should change**: Add content quality score; filter headers/noise rows  
**Merge/Split**: No

---

### TABLE 5: `tbl_contract_codes_events`

**Purpose**: Medical codes (CPT, HCPCS, ICD, revenue codes) and clinical events (HAC, never events) extracted from contracts.

**Why it exists**: Revenue code and CPT code applicability determines which services a rate applies to.

| Dimension | Assessment |
|-----------|-----------|
| **Upstream** | `json_extract/*.json` → 09_build_terms |
| **Downstream** | 12_build_genie (→ vw_genie_contract_terms as content_type='medical_code'/'hac'/'never_event') |
| **Foundational/Derived** | FOUNDATIONAL |
| **Actually valuable** | MODERATE — codes are important but rarely queried directly |
| **Improves retrieval** | MINIMAL — medical codes as text chunks have low semantic value |
| **Improves intelligence** | POTENTIALLY — code-to-rate linkage would enable precise cost modeling |
| **Improves demo** | LOW — rarely demonstrated |
| **Introduces debt** | LOW |

**Rows**: 7,473

| Metric | Score |
|--------|-------|
| Business value | 5/10 — Important metadata but underutilized |
| Technical value | 5/10 — Extracted but not linked to rate_rules |
| Retrieval value | 2/10 — Code lists don't embed well |
| Intelligence value | 3/10 — Unlinked to rate applicability |
| Demo value | 2/10 |
| Risk | LOW |

**Should remain**: YES — but needs linkage to rate_rules (which codes apply to which rates)  
**Should change**: Link revenue_codes/procedure_codes to tbl_reimb_rate_rules  
**Merge/Split**: Could merge into rate_rules as applicability metadata

---

### TABLE 6: `tbl_contract_parties`

**Purpose**: Contracting parties — payer, provider, TPA, signatories per contract document.

**Why it exists**: Party information identifies who is bound by each contract.

| Dimension | Assessment |
|-----------|-----------|
| **Upstream** | `json_extract/*.json` → 09_build_terms |
| **Downstream** | 12_build_genie (→ vw_genie_contract_terms as content_type='party') |
| **Foundational/Derived** | FOUNDATIONAL |
| **Actually valuable** | LOW for analytics — party info is static and rarely queried |
| **Improves retrieval** | MINIMAL — party names in embeddings add noise |
| **Improves intelligence** | NO |
| **Improves demo** | LOW |
| **Introduces debt** | MINIMAL |

**Rows**: 7,189

| Metric | Score |
|--------|-------|
| Business value | 3/10 — Necessary for compliance but low analytics value |
| Technical value | 4/10 |
| Retrieval value | 1/10 — Noise in embedding space |
| Intelligence value | 1/10 |
| Demo value | 1/10 |
| Risk | LOW |

**Should remain**: YES — needed for contract completeness  
**Should change**: Consider excluding from VS embedding (PARTY units add noise)  
**Merge/Split**: No

---

### TABLE 7: `tbl_contract_services_quality`

**Purpose**: Covered services, DOFR (Delegation of Financial Responsibility) details, quality metrics, credentialing requirements.

**Why it exists**: Defines which services a provider is responsible for under the contract.

| Dimension | Assessment |
|-----------|-----------|
| **Upstream** | `json_extract/*.json` → 09_build_terms |
| **Downstream** | 12_build_genie (→ vw_genie_contract_terms) |
| **Foundational/Derived** | FOUNDATIONAL |
| **Actually valuable** | MODERATE — DOFR is important for IPA contracts |
| **Improves retrieval** | MODERATE — DOFR provisions are commonly queried |
| **Improves intelligence** | LOW currently — could drive delegation risk scoring |
| **Improves demo** | LOW |
| **Introduces debt** | LOW |

**Rows**: 13,103

| Metric | Score |
|--------|-------|
| Business value | 6/10 — DOFR critical for IPA contracts (22% of corpus) |
| Technical value | 5/10 |
| Retrieval value | 4/10 |
| Intelligence value | 3/10 |
| Demo value | 2/10 |
| Risk | LOW |

**Should remain**: YES  
**Should change**: Link DOFR services to rate applicability  
**Merge/Split**: No

---

### TABLE 8: `tbl_contract_documents_master`

**Purpose**: Document-level metadata — one row per PDF file with amendment ordering, document type, role classification, effective dates.

**Why it exists**: The document lineage backbone. Amendment ordering here drives supersession logic everywhere.

| Dimension | Assessment |
|-----------|-----------|
| **Upstream** | `json_extract/*.json` → 10_build_documents |
| **Downstream** | 02_state_engine (→ contract + amendment registries), 08_build_rates fix (amendment_order for supersession), 12_build_genie (→ amendment_timeline, provider_profile) |
| **Foundational/Derived** | FOUNDATIONAL — most critical metadata table |
| **Actually valuable** | YES — enables all amendment-aware processing |
| **Improves retrieval** | YES — provides is_from_latest_doc signal |
| **Improves explainability** | YES — document lineage shows provenance |
| **Improves intelligence** | YES — amendment depth/count feeds renewal scoring |
| **Improves demo** | YES — amendment timeline directly from this |
| **Introduces debt** | YES — amendment_order derived from filename parsing (fragile) |

**Schema Quality**: GOOD — comprehensive metadata (amendment_order, doc_role, doc_category, effective_date_parsed)  
**Rows**: ~2,254  
**Primary Keys**: provider_id + source_filename (implicit)  
**Amendment Handling**: CENTRAL — amendment_order is THE ordering mechanism  
**Temporal Handling**: effective_date_parsed (STRING with varied formats)

| Metric | Score |
|--------|-------|
| Business value | 10/10 — Structural backbone |
| Technical value | 9/10 — Well-designed, critical FK source |
| Retrieval value | 7/10 — Enables temporal filtering |
| Intelligence value | 8/10 — Amendment depth, renewal dates |
| Demo value | 8/10 — Powers amendment timeline |
| Risk | MEDIUM — amendment_order derived from filename heuristic |

**Should remain**: YES — absolutely foundational  
**Should change**: Standardize effective_date to DATE type; add validation for amendment_order continuity  
**Merge/Split**: No

---

### TABLE 9: `dim_provider_canonical`

**Purpose**: Provider deduplication dimension — maps multiple provider_ids to a single canonical facility name.

**Why it exists**: A single physical facility may have multiple provider IDs (different contracts, different networks). This dimension resolves them to one entity.

| Dimension | Assessment |
|-----------|-----------|
| **Upstream** | 11_enrich_tables (computed from documents_master) |
| **Downstream** | 12_build_genie (ALL Genie tables join through this) |
| **Foundational/Derived** | DERIVED but acts as FOUNDATIONAL dimension |
| **Actually valuable** | YES — prevents double-counting providers |
| **Improves retrieval** | INDIRECTLY — consistent provider_id enables scope filtering |
| **Improves intelligence** | YES — ensures benchmark is per-facility not per-ID |
| **Improves demo** | YES — "271 providers" is the headline number |
| **Introduces debt** | LOW — well-designed conformed dimension |

**Schema Quality**: GOOD — canonical_name, primary_provider_id, is_primary_id, ids_in_facility  
**Rows**: ~271 facilities  
**Naming**: EXCELLENT — follows Kimball dimension naming convention

| Metric | Score |
|--------|-------|
| Business value | 9/10 — Entity resolution is critical |
| Technical value | 9/10 — Clean conformed dimension |
| Retrieval value | 5/10 — Indirect |
| Intelligence value | 8/10 — Correct entity = correct benchmarks |
| Demo value | 9/10 — Headlines depend on accurate count |
| Risk | LOW — stable, well-tested |

**Should remain**: YES  
**Should change**: No — well-designed  
**Merge/Split**: No

---

### TABLE 10: `tbl_contract_terms_vs_ready`

**Purpose**: Pre-processed contract terms formatted for Vector Search embedding — enriched with content_type classification and latest-doc flags.

**Why it exists**: Bridge between raw clauses/terms and the VS-ready format needed for embedding.

| Dimension | Assessment |
|-----------|-----------|
| **Upstream** | tbl_contract_clauses_terms + documents_master → 13_build_serving |
| **Downstream** | 04_legal_chunking (→ tbl_retrieval_legal_units, 69K rows bootstrapped from here) |
| **Foundational/Derived** | DERIVED |
| **Actually valuable** | YES — the structured retrieval corpus |
| **Improves retrieval** | YES — PRIMARY source for legal unit bootstrapping |
| **Improves demo** | INDIRECTLY — feeds VS index used by demo fallback |
| **Introduces debt** | MODERATE — intermediate table that could be a view |

**Rows**: ~69,000  
**Schema Quality**: GOOD — row_id, content_text, content_type, topic, title, is_from_latest_doc, provider_id

| Metric | Score |
|--------|-------|
| Business value | 6/10 — Intermediate |
| Technical value | 7/10 — Well-structured for VS consumption |
| Retrieval value | 9/10 — Direct source for 69K legal units |
| Intelligence value | 2/10 |
| Demo value | 5/10 — Indirect |
| Risk | LOW |

**Should remain**: YES — serves as materialized preparation for VS  
**Should change**: Could become a view if VS sync supports complex queries  
**Merge/Split**: No

---

### TABLE 11: `tbl_contract_fulltext_vs_ready`

**Purpose**: Full OCR text chunked into passages for comprehensive Vector Search — covers ALL text in every PDF, not just structured clauses.

**Why it exists**: The structured terms table only captures recognized clause patterns. This table captures EVERYTHING — enabling discovery of provisions not in the extraction schema.

| Dimension | Assessment |
|-----------|-----------|
| **Upstream** | Full OCR text (step1_parsed) → 13_build_serving (chunking logic) |
| **Downstream** | Demo "Ask Anything" SQL keyword channel; tbl_contract_fulltext_vs_index (VS) |
| **Foundational/Derived** | DERIVED (from raw OCR) |
| **Actually valuable** | YES — enables corpus-wide discovery beyond extraction schema |
| **Improves retrieval** | YES — 1.36M chunks provide exhaustive coverage |
| **Improves demo** | CRITICAL — "Ask Anything" engine's primary retrieval source |
| **Introduces debt** | YES — 1.36M rows, unstable VS sync, expensive full-table scans |

**Rows**: ~1,360,000  
**Schema Quality**: ADEQUATE — chunk_text, provider_name, source_filename, page_number  
**Query Efficiency**: POOR for LIKE scans on 1.36M rows without index  
**VS Suitability**: PROBLEMATIC — VS index historically never reaches READY state at this scale

| Metric | Score |
|--------|-------|
| Business value | 7/10 — Enables discovery of un-extracted provisions |
| Technical value | 5/10 — Scale causes VS instability |
| Retrieval value | 9/10 — Exhaustive corpus coverage |
| Intelligence value | 2/10 — Not used in intelligence computations |
| Demo value | 10/10 — THE primary source for "Ask Anything" |
| Risk | HIGH — VS index instability, expensive scans |

**Should remain**: YES — but needs optimization  
**Should change**: Add bloom filter index on chunk_text; consider reducing to significant passages only  
**Merge/Split**: Consider splitting by provider (partitioning) for query efficiency

---

### TABLE 12: `tbl_serving_capitation_card`

**Purpose**: Capitation PMPM rates by age/gender band for IPA and capitated contracts.

**Why it exists**: Capitation is a fundamentally different payment model (per-member-per-month vs per-service). Stored separately due to different schema needs.

| Dimension | Assessment |
|-----------|-----------|
| **Upstream** | Extraction pipeline (specific capitation table build) |
| **Downstream** | 03_reimbursement_migration (→ CAPITATION domain rate_rules) |
| **Foundational/Derived** | FOUNDATIONAL |
| **Actually valuable** | YES — capitation is 33% of corpus |
| **Improves retrieval** | INDIRECTLY — feeds RATE_TABLE legal units |
| **Improves intelligence** | YES — capitation benchmarks |
| **Introduces debt** | LOW — flat schema (age_gender_band, pmpm_rate) is simple |

**Schema**: Flat — provider_id, provider_name, age_gender_band, pmpm_rate, program, network, source_filename, effective_date_parsed

| Metric | Score |
|--------|-------|
| Business value | 7/10 — Capitation is a major payment model |
| Technical value | 6/10 — Simple but effective |
| Retrieval value | 4/10 |
| Intelligence value | 7/10 — Capitation benchmarking |
| Demo value | 5/10 |
| Risk | LOW |

**Should remain**: YES  
**Should change**: No — migrated into rate_rules correctly  
**Merge/Split**: Already merged into rate_rules via migration



---

## LAYER 2: V1 GENIE SERVING TABLES

---

### TABLE 13: `tbl_genie_provider_profile`

**Purpose**: One row per facility — the provider "baseball card" with all key metrics pre-joined for instant Genie queries.

**Why it exists**: Genie AI generates SQL against this table for provider-level questions. Pre-joining eliminates complex multi-table queries that Genie cannot reliably compose.

| Dimension | Assessment |
|-----------|-----------|
| **Upstream** | dim_provider_canonical + documents_master + rates_all + financial_protections → 12_build_genie |
| **Downstream** | Genie Space, Dashboard, Demo KPIs, Demo charts, Demo provider universe cache |
| **Foundational/Derived** | DERIVED (aggregation of 4 source tables) |
| **Actually valuable** | YES — the primary entry point for all provider questions |
| **Improves retrieval** | NO (not in retrieval path) |
| **Improves explainability** | YES — single source of truth for provider metrics |
| **Improves intelligence** | INDIRECTLY — validation reference for intelligence outputs |
| **Improves demo** | CRITICAL — headline metrics, KPI cards, chart data |
| **Introduces debt** | LOW — well-designed denormalized aggregate |

**Schema Quality**: EXCELLENT — 18 columns, all meaningful, sentinel-safe (no NULLs in key fields)  
**Naming Quality**: EXCELLENT — avg_inpatient_per_diem, total_amendments, has_stop_loss  
**Data Typing**: GOOD — numerics are FLOAT, booleans are BOOLEAN, dates are STRING (minor issue)  
**Rows**: 271  
**Column Comments**: YES — 100% coverage, Genie-optimized  
**Query Efficiency**: EXCELLENT — 271 rows, any query is instant  
**Amendment Handling**: total_amendments, max_amendment_depth, latest_amendment_date aggregated

| Metric | Score |
|--------|-------|
| Business value | 10/10 — The user-facing entry point |
| Technical value | 9/10 — Well-designed aggregate |
| Retrieval value | 2/10 — Not in retrieval path |
| Intelligence value | 5/10 — Validation reference |
| Demo value | 10/10 — Headlines, KPIs, charts |
| Risk | LOW — stable, well-tested |

**Should remain**: YES — essential for Genie  
**Should change**: Convert latest_amendment_date to DATE type  
**Merge/Split**: No — correct granularity

---

### TABLE 14: `tbl_genie_rates_current`

**Purpose**: Deduplicated current-only rates optimized for Genie natural language queries — the "what are X's rates?" table.

**Why it exists**: tbl_contract_rates_all has superseded rates, duplicates from amendment restatements, and no program normalization. This table is the clean, queryable version.

| Dimension | Assessment |
|-----------|-----------|
| **Upstream** | tbl_contract_rates_all + dim_provider_canonical + documents_master → 12_build_genie |
| **Downstream** | Genie Space, 03_reimbursement (lesser_of source), Demo KPI (rate count) |
| **Foundational/Derived** | DERIVED (filtered + deduplicated) |
| **Actually valuable** | YES — the authoritative current-state rate table |
| **Improves retrieval** | INDIRECTLY — feeds lesser_of migration |
| **Improves intelligence** | YES via reimbursement migration chain |
| **Improves demo** | YES — "6,683 rates tracked" headline |
| **Introduces debt** | LOW — V8 dedup reduced residual to 1.3% |

**Schema Quality**: GOOD — rate_category, service_category, rate_numeric, rate_text, program_normalized  
**Rows**: 6,683  
**Deduplication**: V8 amendment-aware: PARTITION BY (provider_name, rate_category, service_category, rate_numeric, effective_date) ORDER BY amendment_order DESC  
**Column Comments**: YES — 100% Genie-optimized  
**Query Efficiency**: EXCELLENT — 6,683 rows, any query instant

| Metric | Score |
|--------|-------|
| Business value | 9/10 — Authoritative current rates |
| Technical value | 8/10 — Good dedup logic, clean schema |
| Retrieval value | 3/10 — Indirect |
| Intelligence value | 6/10 — Via reimbursement chain |
| Demo value | 9/10 — Genie queries, headline metric |
| Risk | LOW — 1.3% residual duplication acceptable |

**Should remain**: YES  
**Should change**: Could add percentile_rank column (pre-computed vs benchmark)  
**Merge/Split**: No

---

### TABLE 15: `vw_genie_contract_terms` (VIEW)

**Purpose**: Unified view of all clause types with is_from_latest_doc flag — the clause search table for Genie.

**Why it exists**: Combines clauses, definitions, codes, parties, medical events into one queryable surface with temporal awareness.

| Dimension | Assessment |
|-----------|-----------|
| **Upstream** | tbl_contract_clauses_terms + codes_events + parties + services_quality + documents_master |
| **Downstream** | Genie Space, Demo "Ask Anything" fallback, Dashboard |
| **Foundational/Derived** | DERIVED (view over base tables) |
| **Actually valuable** | YES — enables "find clause about X" queries |
| **Improves retrieval** | YES — "Ask Anything" uses this as keyword search fallback |
| **Improves demo** | YES — clause search queries in Genie |
| **Introduces debt** | MINIMAL — view, no storage cost |

**Schema**: content_text, content_type, topic, title, provider_name, provider_id, source_filename, is_from_latest_doc  
**Rows**: 45,718  
**Column Comments**: YES — 100% Genie-optimized  
**Key design decision**: is_from_latest_doc enables "current only" filtering without full supersession logic

| Metric | Score |
|--------|-------|
| Business value | 8/10 — Enables clause-level queries |
| Technical value | 8/10 — View is efficient, no materialization cost |
| Retrieval value | 6/10 — Fallback source for demo |
| Intelligence value | 3/10 |
| Demo value | 8/10 — Genie clause queries |
| Risk | LOW — view inherits base table quality |

**Should remain**: YES  
**Should change**: No  
**Merge/Split**: No — correct as view

---

### TABLE 16: `tbl_genie_amendment_timeline`

**Purpose**: One row per document in a provider's amendment chain — shows the chronological history of contract modifications.

**Why it exists**: Enables "show amendment history for X" and "what changed in the latest amendment?" queries.

| Dimension | Assessment |
|-----------|-----------|
| **Upstream** | tbl_contract_documents_master → 12_build_genie |
| **Downstream** | Genie Space |
| **Foundational/Derived** | DERIVED (enriched view of documents_master) |
| **Actually valuable** | YES — amendment tracking is core business need |
| **Improves retrieval** | NO |
| **Improves demo** | MODERATE — "2,254 amendments indexed" headline |
| **Introduces debt** | MODERATE — exhibits_replaced_count/sections_modified_count are STRING JSON arrays (documented in custom instructions) |

**Rows**: 2,254  
**Schema Quality**: GOOD — but STRING-typed columns that should be arrays  
**Column Comments**: YES — 100% Genie-optimized  
**Key schema issue**: prior_rates_superseded is STRING 'True'/'False' not BOOLEAN

| Metric | Score |
|--------|-------|
| Business value | 7/10 — Amendment history is valuable |
| Technical value | 6/10 — STRING typing issues |
| Retrieval value | 2/10 |
| Intelligence value | 4/10 — Amendment depth used in renewal scoring |
| Demo value | 6/10 — Genie queries |
| Risk | LOW — typing issues documented, workarounds in place |

**Should remain**: YES  
**Should change**: Cast STRING booleans to BOOLEAN; parse JSON array STRINGs to actual arrays  
**Merge/Split**: No

---

## LAYER 3: V2 STATE ENGINE TABLES

---

### TABLE 17: `tbl_v2_contract_registry`

**Purpose**: The primary contract entity — one row per legal agreement with lifecycle state, provider linkage, and amendment summary.

**Why it exists**: V1 had no contract-level entity. Documents existed but "which contract does this belong to?" was implicit. This makes it explicit.

| Dimension | Assessment |
|-----------|-----------|
| **Upstream** | tbl_contract_documents_master → 02_state_engine |
| **Downstream** | tbl_v2_amendment_registry (FK), tbl_reimb_rate_rules (FK), 08_intelligence (renewal priority) |
| **Foundational/Derived** | DERIVED but acts as FOUNDATIONAL entity for V2 |
| **Actually valuable** | YES — enables contract-level analytics (not just provider-level) |
| **Improves retrieval** | YES — contract_id enables scope filtering |
| **Improves explainability** | YES — "this rate belongs to contract X which has Y amendments" |
| **Improves intelligence** | YES — renewal priority uses contract effective_to dates |
| **Improves demo** | MODERATE — contract status chart |
| **Introduces debt** | MODERATE — row counts vary (685 vs 1,948) depending on filter conditions |

**Schema Quality**: EXCELLENT — 17 columns covering identity, classification, lifecycle, lineage, audit  
**Primary Keys**: contract_id (SHA-256 of provider_id|base_agreement_doc) — deterministic  
**Data Typing**: GOOD — DATE for temporal, BOOLEAN for flags, FLOAT for term_years  
**CDF**: Enabled  
**Amendment Handling**: total_amendments, latest_amendment_date, latest_amendment_doc pre-computed  
**Temporal Handling**: effective_from/effective_to with status derivation

| Metric | Score |
|--------|-------|
| Business value | 9/10 — The contract entity that V1 lacked |
| Technical value | 8/10 — Well-designed, deterministic IDs |
| Retrieval value | 6/10 — Scope filtering enabled |
| Intelligence value | 9/10 — Drives renewal priority |
| Demo value | 6/10 — Contract status breakdown chart |
| Risk | MEDIUM — varying row counts indicate filter sensitivity |

**Should remain**: YES — core V2 entity  
**Should change**: Stabilize row count issue; add SUPERSEDED/TERMINATED states  
**Merge/Split**: No

---

### TABLE 18: `tbl_v2_amendment_registry`

**Purpose**: Links amendments to contracts with scope classification — declares WHAT each amendment modifies.

**Why it exists**: V1 knew amendment ORDER but not amendment SCOPE. "Amendment 3 exists" vs "Amendment 3 replaces Exhibit B rates only" — this table provides the latter.

| Dimension | Assessment |
|-----------|-----------|
| **Upstream** | tbl_contract_documents_master → 02_state_engine |
| **Downstream** | 08_build_rates fix (scope-aware supersession), potentially 04_legal_chunking |
| **Foundational/Derived** | DERIVED |
| **Actually valuable** | YES — scope classification is the key V2 innovation |
| **Improves retrieval** | POTENTIALLY — could filter "only show me what changed in amendment X" |
| **Improves explainability** | YES — explains WHY a rate was superseded |
| **Improves intelligence** | POTENTIALLY — scope type could predict negotiation complexity |
| **Introduces debt** | MODERATE — classification heuristics use STRING length |

**Schema Quality**: GOOD — scope_type, exhibits_modified (JSON), sections_modified (JSON), confidence, source  
**Primary Keys**: amendment_id (SHA-256 of provider_id|source_filename)  
**Rows**: 1,569  
**Key Innovation**: scope_type (FULL_REPLACEMENT, EXHIBIT_SPECIFIC, RATE_SPECIFIC, SECTION_SPECIFIC, TERM_EXTENSION, ADDENDUM)  
**Confidence**: 0.60-0.90 (hardcoded based on signal strength)

| Metric | Score |
|--------|-------|
| Business value | 8/10 — Scope classification is high-value |
| Technical value | 7/10 — Good design, heuristic classification |
| Retrieval value | 5/10 — Potential scope-filtered retrieval |
| Intelligence value | 6/10 — Complexity signal |
| Demo value | 3/10 — Not directly surfaced |
| Risk | MEDIUM — STRING length heuristics may misclassify |

**Should remain**: YES  
**Should change**: Parse JSON arrays and count elements instead of using LENGTH(); calibrate confidence  
**Merge/Split**: No

---

### TABLES 19-23: EMPTY STATE ENGINE DDL TABLES

**Tables**: `tbl_v2_rate_facts_bitemporal`, `tbl_v2_clause_facts_bitemporal`, `tbl_v2_supersession_decisions`, `tbl_v2_document_lineage`, `tbl_v2_state_computation_log`

**Purpose**: Designed for full bitemporal modeling (valid_time + transaction_time) with supersession audit trail.

**Why they exist**: The design docs describe a complete bitemporal state engine where every clause and rate has temporal validity tracking and supersession decisions are logged.

| Dimension | Assessment |
|-----------|-----------|
| **Upstream** | Would consume: state_engine + amendments + clauses |
| **Downstream** | Would feed: retrieval (point-in-time queries), intelligence (historical comparison) |
| **Actually valuable** | POTENTIALLY — but zero rows means zero value today |
| **Introduces debt** | YES — 5 empty tables create maintenance burden and false expectations |

**Schema Quality**: EXCELLENT (well-thought-out bitemporal design)  
**Rows**: 0 (all five)  
**Implementation**: None — no population logic exists

| Metric | Score |
|--------|-------|
| Business value | 0/10 today (9/10 if implemented) |
| Technical value | 2/10 — Schema-only, no logic |
| Risk | MEDIUM — suggests capability that doesn't exist |

**Should remain**: CONDITIONAL — keep DDL for roadmap, but DROP tables until implementation is resourced  
**Should change**: Either implement or remove to avoid confusion  
**Merge/Split**: N/A — not populated

---

## LAYER 4: V2 REIMBURSEMENT TABLES

---

### TABLE 24: `tbl_reimb_rate_rules`

**Purpose**: Master reimbursement rules with computable formula_json expression trees — the "how to pay this claim" table.

**Why it exists**: V1 rates are descriptive (rate_text, rate_numeric). V2 rate_rules are COMPUTABLE — formula_json can theoretically be executed against a claim to produce a reimbursement amount.

| Dimension | Assessment |
|-----------|-----------|
| **Upstream** | tbl_contract_rates_all + tbl_serving_capitation_card → 03_reimbursement_migration |
| **Downstream** | 04_legal_chunking (RATE_TABLE units), 08_intelligence (benchmarks), 05_retrieval (metadata channel), tbl_reimb_stop_loss (FK) |
| **Foundational/Derived** | DERIVED (migrated from V1) but acts as FOUNDATIONAL for V2 |
| **Actually valuable** | YES — enables programmatic reimbursement logic |
| **Improves retrieval** | YES — metadata channel directly queries this for RATE_LOOKUP intent |
| **Improves intelligence** | YES — benchmarks, renewal scoring use rate_numeric from here |
| **Improves demo** | INDIRECTLY — via benchmarks |
| **Introduces debt** | YES — UUID rule_id breaks FK integrity on re-runs; formula_json not schema-validated |

**Schema Quality**: EXCELLENT — 26 columns covering identity, classification, formula, applicability, provenance, modifiers  
**Primary Keys**: rule_id (UUID) — NOT deterministic, breaks on re-run  
**Foreign Keys**: contract_id → contract_registry; provider_id → dim_provider  
**Rows**: 13,263-21,074 (varies by run)  
**formula_json**: JSON expression tree (FIXED, PER_DIEM, PERCENTAGE, DRG_WEIGHTED, CONVERSION_FACTOR, LESSER_OF)  
**Modifier Flags**: has_stop_loss, has_carve_outs, has_escalator, has_conditions (boolean)

| Metric | Score |
|--------|-------|
| Business value | 9/10 — Computable reimbursement is high-value |
| Technical value | 7/10 — Good schema but UUID + unvalidated JSON |
| Retrieval value | 8/10 — Direct source for metadata retrieval channel |
| Intelligence value | 10/10 — Foundation for all intelligence computations |
| Demo value | 5/10 — Indirect |
| Risk | HIGH — UUID breaks FKs; formula_json may be malformed |

**Should remain**: YES — core V2 table  
**Should change**: Replace UUID with SHA-256 deterministic ID; validate formula_json against schema  
**Merge/Split**: No

---

### TABLE 25: `tbl_reimb_stop_loss`

**Purpose**: Multi-tier stop-loss provisions linked to base rate rules — defines when financial protection kicks in.

**Why it exists**: Stop-loss is the single most important financial protection — caps the plan's exposure per case or in aggregate.

| Dimension | Assessment |
|-----------|-----------|
| **Upstream** | tbl_contract_financial_protections → 03_reimbursement_migration |
| **Downstream** | Post-migration MERGE (→ has_stop_loss flag on rate_rules) |
| **Foundational/Derived** | DERIVED |
| **Actually valuable** | YES — high financial significance |
| **Improves retrieval** | MINIMAL |
| **Improves intelligence** | YES — stop-loss presence is key risk metric |
| **Introduces debt** | MODERATE — many rule_id = 'UNLINKED' (FK not resolved) |

**Rows**: 529-741  
**Schema Quality**: GOOD — stop_loss_type, attachment_level, attachment_unit, reimburse_formula_type  
**FK Issues**: Many rows have rule_id = 'UNLINKED' (correlated subquery couldn't find matching base rate)

| Metric | Score |
|--------|-------|
| Business value | 8/10 — Critical for risk quantification |
| Technical value | 6/10 — UNLINKED FKs are problematic |
| Retrieval value | 3/10 |
| Intelligence value | 7/10 — Informs risk scoring |
| Demo value | 3/10 |
| Risk | MEDIUM — UNLINKED provisions can't be traced to specific rates |

**Should remain**: YES  
**Should change**: Resolve UNLINKED FKs via broader matching logic  
**Merge/Split**: No

---

### TABLE 26: `tbl_reimb_carve_outs`

**Purpose**: Carve-out provisions (implants, drugs, devices) that are reimbursed separately from base rates.

| Dimension | Assessment |
|-----------|-----------|
| **Upstream** | tbl_contract_financial_protections → 03_reimbursement_migration |
| **Downstream** | None currently |
| **Rows**: 0 |
| **Actually valuable** | POTENTIALLY — but produces zero rows |
| **Introduces debt** | YES — empty table suggests broken extraction/migration |

| Metric | Score |
|--------|-------|
| Business value | 0/10 today (7/10 if populated) |
| Technical value | 2/10 — Zero rows |
| Risk | MEDIUM — indicates data gap |

**Should remain**: YES — but fix migration filter (too restrictive pattern matching)  
**Should change**: Debug why WHERE clause matches 0 rows; broaden ILIKE patterns

---

### TABLE 27: `tbl_reimb_lesser_of`

**Purpose**: Lesser-of comparator provisions (contract pays the LESSER of contracted rate, billed charges, or Medicare).

| Dimension | Assessment |
|-----------|-----------|
| **Upstream** | tbl_genie_rates_current → 03_reimbursement_migration |
| **Downstream** | None currently |
| **Rows**: 23 |
| **Actually valuable** | MODERATE — lesser-of is common but under-detected |

| Metric | Score |
|--------|-------|
| Business value | 6/10 — Under-detected |
| Technical value | 5/10 — Only 23 rows from 6,683 rates |
| Risk | MEDIUM — likely significant under-detection |

**Should remain**: YES — but improve detection  
**Should change**: Expand ILIKE patterns; detect "minimum of", "not to exceed", "whichever is less"

---

### TABLES 28-30: EMPTY REIMBURSEMENT TABLES

**Tables**: `tbl_reimb_formula_components`, `tbl_reimb_escalators`, `tbl_reimb_conditions`

**Purpose**: Designed for multi-component formulas, annual rate escalations, and conditional applicability rules.

| Dimension | Assessment |
|-----------|-----------|
| **Rows**: 0 (all three) |
| **Actually valuable** | 0/10 today |
| **Introduces debt** | YES — empty tables, maintenance burden |

**Should remain**: CONDITIONAL — keep if implementation planned within 60 days  
**Should change**: Either implement or DROP

---

### TABLE 31: `dim_service_line_taxonomy`

**Purpose**: Reference dimension mapping service line codes to display names, domains, and hierarchy.

| Dimension | Assessment |
|-----------|-----------|
| **Upstream** | taxonomy_seed.sql → 01_execute_ddl |
| **Downstream** | Designed for: rate_rules.service_line FK, intelligence layer normalization |
| **Rows**: 50 |
| **Actually valuable** | YES — standardizes the 148+ raw service categories into 50 canonical |

| Metric | Score |
|--------|-------|
| Business value | 7/10 — Normalization reference |
| Technical value | 8/10 — Well-designed dimension |
| Risk | LOW |

**Should remain**: YES  
**Should change**: Verify all rate_rules.service_line values map to taxonomy entries

---

### TABLE 32: `dim_service_line_patterns`

**Purpose**: Regex patterns for mapping raw LLM-extracted service category text to canonical service line codes.

| Dimension | Assessment |
|-----------|-----------|
| **Upstream** | taxonomy_seed.sql → 01_execute_ddl |
| **Downstream** | Designed for: automated service_line classification |
| **Rows**: 45 |
| **Actually valuable** | MODERATE — patterns exist but automated classification not implemented |

| Metric | Score |
|--------|-------|
| Business value | 5/10 — Reference only currently |
| Technical value | 6/10 — Good patterns but unused in pipeline |
| Risk | LOW |

**Should remain**: YES  
**Should change**: Integrate into reimbursement migration (auto-classify service_line)



---

## LAYER 5: V2 RETRIEVAL TABLES

---

### TABLE 33: `tbl_retrieval_legal_units`

**Purpose**: The Vector Search source table — 83K semantic legal units with unit_type classification, provider linkage, and temporal state.

**Why it exists**: This is the table that gets embedded. Every row becomes a vector in the VS index. The VS delta sync reads CDF from this table.

| Dimension | Assessment |
|-----------|-----------|
| **Upstream** | tbl_contract_terms_vs_ready (69K) + tbl_reimb_rate_rules (14K) → 04_legal_chunking |
| **Downstream** | idx_legal_units_v2 (VS delta sync index), 05_retrieval_engine (semantic + lexical channels) |
| **Foundational/Derived** | DERIVED but FOUNDATIONAL for retrieval |
| **Actually valuable** | YES — the structured retrieval corpus |
| **Improves retrieval** | CRITICAL — this IS the retrieval corpus for platform |
| **Improves explainability** | YES — unit_type + source_filename enables provenance |
| **Improves intelligence** | NO |
| **Improves demo** | INDIRECTLY — demo fallback uses idx_legal_units_v2 |
| **Introduces debt** | MODERATE — synthetic RATE_TABLE text quality questionable; no chunk overlap |

**Schema Quality**: EXCELLENT — 17 columns covering content, provenance, structure, state, retrieval metadata, audit  
**Primary Keys**: unit_id (from source row_id or rule_id)  
**Naming Quality**: EXCELLENT — unit_text, unit_type, is_current, rate_domain  
**Data Typing**: GOOD — STRING for content, BOOLEAN for state, INT for content_length, DATE for effective  
**Rows**: 83,008  
**CDF**: ENABLED (required for VS delta sync)  
**Partitioning**: None — could benefit from Z-ORDER on (provider_id, unit_type)  
**Delta Properties**: autoOptimize.optimizeWrite=true, columnMapping.mode=name

**Unit Type Distribution**:
| Unit Type | Count | Avg Length | Source |
|-----------|-------|-----------|--------|
| SECTION | ~30K | ~400 chars | terms_vs_ready |
| DEFINITION | ~17K | ~200 chars | terms_vs_ready |
| CLAUSE | ~8K | ~1500 chars | terms_vs_ready |
| RATE_TABLE | ~21K | ~200 chars | rate_rules (synthetic) |
| MEDICAL_CODE | ~5K | ~100 chars | terms_vs_ready |
| PARTY | ~2K | ~150 chars | terms_vs_ready |

**Quality Concerns**:
- RATE_TABLE units use synthetic template text ("Provider: X\nService: Y\nRate: Z") — may not embed well alongside natural legal language
- PARTY and MEDICAL_CODE units add noise to embedding space (short, repetitive)
- No minimum quality filter (some units are just headers)
- No maximum length normalization (CLAUSE units up to 10K chars vs DEFINITION at 200 chars)
- is_current inherits V1 supersession heuristic (known flawed)

| Metric | Score |
|--------|-------|
| Business value | 7/10 — Enables retrieval but value realized through downstream |
| Technical value | 8/10 — Well-designed for VS consumption, CDF correct |
| Retrieval value | 10/10 — THE retrieval corpus |
| Intelligence value | 0/10 |
| Demo value | 6/10 — Indirect via VS index |
| Risk | MEDIUM — synthetic text quality, heterogeneous lengths, no overlap |

**Optimizations**:
1. Remove PARTY and MEDICAL_CODE units from VS (or weight lower)
2. Add 128-token overlap between adjacent sections
3. Normalize CLAUSE units >2000 chars into sub-chunks
4. Improve RATE_TABLE text to be more natural ("X Hospital is paid $Y per day for Z services")
5. Add quality score column; filter low-quality units from embedding

**Should remain**: YES — absolutely critical  
**Should change**: Improve unit quality; add overlap; normalize lengths  
**Merge/Split**: Consider splitting RATE_TABLE units into separate index for precision

---

### TABLE 34: `tbl_retrieval_telemetry`

**Purpose**: Logs per-query retrieval metrics — confidence, checks passed, latency, citations, error flags.

**Why it exists**: Designed to enable monitoring view (v_retrieval_health_daily) and continuous quality measurement.

| Dimension | Assessment |
|-----------|-----------|
| **Upstream** | Would be populated by: 07_citation_verification (UNIMPLEMENTED) |
| **Downstream** | v_retrieval_health_daily (monitoring view) |
| **Rows**: 0 (never populated — citation verification not implemented) |
| **Actually valuable** | POTENTIALLY — essential for production monitoring, but empty |
| **Introduces debt** | YES — monitoring view references columns that may not exist |

| Metric | Score |
|--------|-------|
| Business value | 0/10 today (9/10 if populated) |
| Technical value | 2/10 — Schema-only |
| Demo value | 0/10 |
| Risk | LOW — benign when empty |

**Should remain**: YES — essential for production readiness  
**Should change**: Implement citation verification to populate it; add basic telemetry from HybridRetriever even without full citation checks

---

## LAYER 6: V2 INTELLIGENCE TABLES

---

### TABLE 35: `tbl_intel_benchmark_results`

**Purpose**: Percentile rate distributions per service line / domain / formula type — answers "where does this provider's rate sit vs the network?"

**Why it exists**: Negotiators need context: "Your $1,200 per diem is at the 75th percentile — most hospitals accept $950."

| Dimension | Assessment |
|-----------|-----------|
| **Upstream** | tbl_reimb_rate_rules → 08_intelligence |
| **Downstream** | tbl_intel_renewal_priority (pct_above_median), potential Dashboard |
| **Foundational/Derived** | DERIVED (aggregation of rate_rules) |
| **Actually valuable** | YES — high negotiation value |
| **Improves retrieval** | NO |
| **Improves intelligence** | YES — foundation for all rate positioning analysis |
| **Improves demo** | POTENTIALLY — could show percentile distribution charts |
| **Introduces debt** | LOW — clean computation |

**Schema Quality**: GOOD — benchmark_id, rate_domain, service_line, formula_type, p10 through p90, mean, std_dev  
**Rows**: 728-1,399  
**Computation**: percentile_approx (Spark-native, numerically sound)  
**Filter**: HAVING COUNT(*) >= 3 (minimum sample for statistical validity)  
**Source marker**: "estimated" (vs future "claims_weighted")

| Metric | Score |
|--------|-------|
| Business value | 9/10 — High negotiation value |
| Technical value | 8/10 — Numerically sound |
| Retrieval value | 0/10 |
| Intelligence value | 10/10 — Foundation for positioning |
| Demo value | 6/10 — Could enable rich charts |
| Risk | LOW — computation is sound; limited by input data quality |

**Should remain**: YES  
**Should change**: Add geographic/market segmentation; add confidence intervals  
**Merge/Split**: No

---

### TABLE 36: `tbl_intel_provider_spend_summary`

**Purpose**: Provider-level estimated spend, volume, and savings opportunity.

| Dimension | Assessment |
|-----------|-----------|
| **Rows**: 348 |
| **Actually valuable** | ONLY WHEN claims feed connected — currently PLACEHOLDER with hardcoded volume=50 |
| **Feature Flag**: CLAIMS_AVAILABLE=False → uses fabricated data |
| **Introduces debt** | YES — fabricated data creates misleading analytics |

| Metric | Score |
|--------|-------|
| Business value | 2/10 today (9/10 with real claims) |
| Technical value | 3/10 — Placeholder logic |
| Risk | MEDIUM — fabricated spend data could mislead if feature flag bypassed |

**Should remain**: CONDITIONAL — keep schema, remove fabricated data rows  
**Should change**: Clear table; gate population behind CLAIMS_AVAILABLE flag (current code removed in trimmed version, but old data may persist)

---

### TABLE 37: `tbl_intel_service_line_spend`

**Purpose**: Spend breakdown by service line per provider — enables "where are we overpaying?"

| Dimension | Assessment |
|-----------|-----------|
| **Feature Flag**: CLAIMS_AVAILABLE=False → placeholder |
| **Actually valuable** | NO today |

**Should remain**: CONDITIONAL — same as provider_spend_summary

---

### TABLE 38: `tbl_intel_savings_opportunity`

**Purpose**: Pareto-ranked savings opportunities — "move provider X from 75th to 50th percentile = $Y savings."

| Dimension | Assessment |
|-----------|-----------|
| **Rows**: 500 (Pareto-ranked) |
| **Actually valuable** | NO today — depends on fabricated spend |
| **Feature Flag**: CLAIMS_AVAILABLE=False |

| Metric | Score |
|--------|-------|
| Business value | 2/10 today (10/10 with real claims — this IS the negotiation action list) |
| Risk | MEDIUM — Pareto ranking based on fabricated volumes |

**Should remain**: CONDITIONAL — clear data, keep schema  
**Should change**: Gate behind CLAIMS_AVAILABLE

---

### TABLE 39: `tbl_intel_scenario_results`

**Purpose**: What-if simulation results — "if we reduce Providence per diem by 10%, annual savings = $X."

| Dimension | Assessment |
|-----------|-----------|
| **Rows**: 5 (sample scenarios only) |
| **Actually valuable** | NO today — sample data only |
| **Module**: 09_scenario_engine (NOT IMPLEMENTED in platform/) |

| Metric | Score |
|--------|-------|
| Business value | 1/10 today (8/10 if implemented with real data) |
| Risk | LOW — only 5 sample rows |

**Should remain**: YES — keep for when scenario engine is implemented

---

### TABLE 40: `tbl_intel_leverage_scores`

**Purpose**: Bilateral leverage assessment — plan market share vs provider market power.

| Dimension | Assessment |
|-----------|-----------|
| **Rows**: 348 |
| **Actually valuable** | NO today — uses hardcoded plan_market_share=0.25 |
| **Module**: 10_leverage_scoring (NOT IMPLEMENTED in platform/) |

| Metric | Score |
|--------|-------|
| Business value | 2/10 today (8/10 with real market data) |
| Risk | MEDIUM — hardcoded assumptions produce misleading leverage scores |

**Should remain**: CONDITIONAL — clear fabricated data

---

### TABLE 41: `tbl_intel_renewal_priority`

**Purpose**: Contract renewal priority scoring — which contracts need attention soonest?

**Why it exists**: Proactive contract management — prioritize renewals by urgency (days to expiry) × impact (rate volume) × risk (rates above median).

| Dimension | Assessment |
|-----------|-----------|
| **Upstream** | tbl_v2_contract_registry + tbl_reimb_rate_rules + tbl_intel_benchmark_results → 08_intelligence |
| **Downstream** | Demo KPI (expiring count), Genie Space, Dashboard |
| **Foundational/Derived** | DERIVED |
| **Actually valuable** | YES — real data, real urgency signals |
| **Improves intelligence** | YES — actionable contract management tool |
| **Improves demo** | YES — "X contracts expiring within 90 days" KPI |

**Schema Quality**: GOOD — urgency_score, impact_score, risk_score, priority_score, priority_rank, recommended_action  
**Rows**: 493-1,478  
**Computation**: Multi-factor: days_to_expiry → urgency(0-40) + rate_count → impact(0-40) + pct_above_median → risk(0-20) = total(0-100)  
**Actions**: ALLOW_AUTO_RENEW, NEGOTIATE, ISSUE_NON_RENEWAL, ESCALATE

| Metric | Score |
|--------|-------|
| Business value | 9/10 — Actionable contract management |
| Technical value | 7/10 — Sound scoring; arbitrary scaling factors |
| Retrieval value | 0/10 |
| Intelligence value | 9/10 — Key intelligence output |
| Demo value | 8/10 — Expiring contracts KPI |
| Risk | LOW — uses real data, sound methodology |

**Should remain**: YES — high-value real intelligence  
**Should change**: Replace NULL estimated_spend/savings with explicit "claims feed required" message; add historical calibration for scoring factors  
**Merge/Split**: No

---

## LAYER 7: EVALUATION & MONITORING

---

### TABLE 42: `tbl_eval_golden_queries`

**Purpose**: 20 reference queries with expected retrieval characteristics for quality measurement.

| Dimension | Assessment |
|-----------|-----------|
| **Upstream** | 11_evaluation_harness (seeded INSERT OVERWRITE) |
| **Downstream** | Manual evaluation runs, future automated regression |
| **Rows**: 20 |
| **Actually valuable** | YES — but insufficient quantity |

| Metric | Score |
|--------|-------|
| Business value | 5/10 — Necessary but tiny |
| Technical value | 5/10 — Good schema, insufficient data |
| Risk | LOW |

**Should remain**: YES — expand to 100+  
**Should change**: Add expected_answer text; add expected_unit_ids for precision measurement

---

### VIEW: `v_retrieval_health_daily`

**Purpose**: Daily aggregation of retrieval telemetry for monitoring dashboards.

| Dimension | Assessment |
|-----------|-----------|
| **Upstream** | tbl_retrieval_telemetry (EMPTY) |
| **Downstream** | Monitoring dashboard (not yet built) |
| **Actually valuable** | 0/10 today (9/10 when telemetry populated) |

**Should remain**: YES — ready for when telemetry flows

---

### TABLE 43: `tbl_pipeline_telemetry`

**Purpose**: Structured pipeline execution telemetry — step/check/result/severity/metric per event.

| Dimension | Assessment |
|-----------|-----------|
| **Upstream** | 00_config.py log_telemetry() function (in-memory buffer + flush) |
| **Downstream** | Pipeline monitoring |
| **Rows**: 0 (buffer never flushed in practice) |
| **Introduces debt** | YES — in-memory buffer lost on session crash |

| Metric | Score |
|--------|-------|
| Business value | 3/10 today (7/10 if reliably populated) |
| Risk | LOW — benign when empty |

**Should remain**: YES — but fix flush mechanism (flush on each step completion, not end-of-run)

---

## SUMMARY ASSESSMENTS

---

### HIGHEST-VALUE TABLES (keep and invest)

| Rank | Table | Value Score | Why |
|------|-------|-------------|-----|
| 1 | `tbl_contract_rates_all` | 10/10 | Core financial data for entire platform |
| 2 | `tbl_genie_provider_profile` | 10/10 | User-facing entry point, demo critical |
| 3 | `tbl_contract_documents_master` | 10/10 | Structural backbone for amendment ordering |
| 4 | `tbl_reimb_rate_rules` | 9/10 | Computable reimbursement, retrieval + intelligence source |
| 5 | `tbl_retrieval_legal_units` | 9/10 | THE retrieval corpus |
| 6 | `tbl_intel_benchmark_results` | 9/10 | High negotiation value, real data |
| 7 | `tbl_v2_contract_registry` | 9/10 | Core V2 entity, renewal priority source |
| 8 | `tbl_intel_renewal_priority` | 9/10 | Actionable intelligence, real data |
| 9 | `dim_provider_canonical` | 9/10 | Entity resolution, headline numbers |
| 10 | `tbl_genie_rates_current` | 9/10 | Authoritative current rates |

---

### LOWEST-VALUE TABLES (consider removing or gating)

| Rank | Table | Value Score | Why |
|------|-------|-------------|-----|
| 1 | `tbl_v2_rate_facts_bitemporal` | 0/10 | Empty, no implementation |
| 2 | `tbl_v2_clause_facts_bitemporal` | 0/10 | Empty, no implementation |
| 3 | `tbl_v2_supersession_decisions` | 0/10 | Empty, no implementation |
| 4 | `tbl_v2_document_lineage` | 0/10 | Empty, no implementation |
| 5 | `tbl_v2_state_computation_log` | 0/10 | Empty, no implementation |
| 6 | `tbl_reimb_formula_components` | 0/10 | Empty |
| 7 | `tbl_reimb_escalators` | 0/10 | Empty |
| 8 | `tbl_reimb_conditions` | 0/10 | Empty |
| 9 | `tbl_reimb_carve_outs` | 0/10 | 0 rows (broken filter) |
| 10 | `tbl_retrieval_telemetry` | 0/10 | Empty (citation verification unimplemented) |

---

### MOST EXPENSIVE TABLES (compute/storage cost)

| Table | Rows | Expense Source | Optimization |
|-------|------|---------------|-------------|
| `tbl_contract_fulltext_vs_ready` | 1.36M | Full-table LIKE scans + VS embedding | Add text search index; reduce to significant passages |
| `tbl_retrieval_legal_units` | 83K | VS embedding compute (~14M tokens) | Filter low-quality units before embedding |
| `tbl_contract_rates_all` | 39,549 | Full rebuild on each extraction run | Incremental MERGE |
| `tbl_contract_clauses_terms` | 31,056 | Full rebuild | Incremental MERGE |
| `tbl_reimb_rate_rules` | 13-21K | TRUNCATE + INSERT every run | Deterministic IDs + MERGE |

---

### MOST IMPORTANT LINEAGE CHAINS

```
Chain 1 (Financial Intelligence):
  json_extract/ → tbl_contract_rates_all → tbl_reimb_rate_rules → tbl_intel_benchmark_results → tbl_intel_renewal_priority
  IMPACT: Rate extraction quality propagates through 4 layers to negotiation recommendations

Chain 2 (Retrieval Quality):
  json_extract/ → tbl_contract_clauses_terms → tbl_contract_terms_vs_ready → tbl_retrieval_legal_units → idx_legal_units_v2 → HybridRetriever
  IMPACT: Clause extraction quality determines retrieval precision

Chain 3 (Demo Headline):
  json_extract/ → tbl_contract_rates_all → tbl_genie_rates_current → tbl_genie_provider_profile → Demo KPIs
  IMPACT: Rate dedup quality determines accuracy of "271 providers, 6,683 rates" headlines

Chain 4 (State-Aware Retrieval):
  tbl_contract_documents_master → tbl_v2_amendment_registry → scope classification → rate supersession → is_current flag → retrieval filtering
  IMPACT: Scope classification accuracy determines whether retrieval returns superseded content
```

---

### TABLES CAUSING UNNECESSARY COMPLEXITY

| Table | Complexity Issue | Recommendation |
|-------|-----------------|----------------|
| 5 empty bitemporal tables | Create schema maintenance burden; suggest capability that doesn't exist | DROP or move to `docs/future_schema/` |
| 3 empty reimbursement tables | Same — empty tables in production schema | DROP or gate behind feature flag |
| `tbl_intel_provider_spend_summary` | Fabricated data is worse than no data | TRUNCATE; gate behind CLAIMS_AVAILABLE |
| `tbl_intel_leverage_scores` | Hardcoded assumptions produce misleading results | TRUNCATE; gate behind CLAIMS_AVAILABLE |
| `tbl_intel_savings_opportunity` | Depends on fabricated spend | TRUNCATE; gate behind CLAIMS_AVAILABLE |

---

### TABLES SUITABLE FOR MATERIALIZATION (currently views or recomputed)

| Table/View | Current State | Materialization Benefit |
|-----------|---------------|----------------------|
| `vw_genie_contract_terms` | View | Materialize for faster Genie queries (45K rows) |
| `v_retrieval_health_daily` | View | Keep as view (low row count when populated) |
| `tbl_intel_benchmark_results` | Recomputed each run | Materialize with incremental refresh |

---

### TABLES SUITABLE FOR INCREMENTALIZATION (currently full-rebuild)

| Table | Current Pattern | Incremental Approach |
|-------|----------------|---------------------|
| `tbl_contract_rates_all` | Full overwrite from JSON | MERGE on (provider_id, source_filename, rate_category, service_category) |
| `tbl_contract_clauses_terms` | Full overwrite | MERGE on (provider_id, source_filename, content_type, topic, title) |
| `tbl_reimb_rate_rules` | TRUNCATE + INSERT | MERGE on deterministic rule_id (requires SHA-based IDs) |
| `tbl_v2_contract_registry` | TRUNCATE + INSERT | MERGE on contract_id (already deterministic) |
| `tbl_v2_amendment_registry` | TRUNCATE + INSERT | MERGE on amendment_id (already deterministic) |
| `tbl_retrieval_legal_units` | Full INSERT (no dedup) | MERGE on unit_id to prevent duplicate embeddings |

---

### TABLES SUITABLE FOR STREAMING (real-time updates)

| Table | Streaming Trigger | Benefit |
|-------|------------------|---------|
| `tbl_retrieval_legal_units` | New PDF processed → new legal units | VS index automatically re-syncs via CDF |
| `tbl_retrieval_telemetry` | Every retrieval query | Real-time monitoring |
| `tbl_pipeline_telemetry` | Every pipeline step | Real-time pipeline health |
| `tbl_contract_rates_all` | New extraction complete | Downstream tables auto-refresh |

---

## FINAL TABLE HEALTH SCORECARD

| Status | Count | Tables |
|--------|-------|--------|
| ✅ HEALTHY (keep as-is) | 12 | provider_profile, genie_rates, genie_terms(view), dim_provider, dim_taxonomy, dim_patterns, documents_master, benchmark_results, renewal_priority, golden_queries, v_health_daily, contract_terms_vs_ready |
| ⚠️ NEEDS IMPROVEMENT | 10 | rates_all (supersession), rate_rules (UUID), retrieval_legal_units (quality), fulltext_vs_ready (scale), financial_protections (typing), amendment_timeline (typing), contract_registry (varying counts), amendment_registry (heuristics), stop_loss (UNLINKED), capitation_card (migrated) |
| 🔴 BROKEN/EMPTY | 14 | 5 bitemporal, 3 reimb empty, carve_outs (0 rows), retrieval_telemetry, pipeline_telemetry, lesser_of (under-detected), spend_summary (fabricated), leverage (fabricated) |
| 🗑️ CANDIDATES FOR REMOVAL | 8 | 5 empty bitemporal + 3 empty reimbursement (until implementation planned) |

