# SESSION PROMPT — In-Place Pipeline Rationalization

## CONTEXT

Read this file first for full platform understanding:
```
/Workspace/Users/adixit01@blueshieldca.com/Contract_Codification_Pipeline/pipeline_enhancement/CONTEXT_FOR_CONTINUATION.md
```

Then read the implementation plan:
```
/Workspace/Users/adixit01@blueshieldca.com/Contract_Codification_Pipeline/pipeline_enhancement/IMPLEMENTATION_PROMPT.md
```

An enterprise architectural audit was completed (Prompts 1-6). The audit found:
- 55% of the platform is genuinely valuable (extraction pipeline, table building, Genie serving)
- 45% is complexity without ROI (fabricated intelligence, empty tables, triple supersession, placeholder retrieval)
- Supersession logic is computed 3 times with different (conflicting) results
- 6 tables are empty DDL theater (never populated)
- 4 platform modules deliver zero value (scenario, leverage, reranking, citation)
- Consolidation (07) outputs are overwritten downstream — entire notebook is eliminable
- Rate status in `tbl_contract_rates_all` is incorrect for scope-limited amendments

---

## REQUIREMENTS

1. **ALL fixes go directly into the existing notebooks** — no new fix notebooks, no parallel cells, no temporary patches
2. **Keep the pipeline linear and clean** — after fixes, running 01 through 12 in sequence produces correct results from scratch
3. **Pipeline must work with NEW files at any time** — checkpoint-aware, idempotent, handles fresh PDFs added to the Volume
4. **No new folders or structural changes** — edits happen inside existing `extraction/` and `platform/` notebooks
5. **Remove dead code, don't comment it out** — if something is deleted, it's gone
6. **Preserve all working functionality** — extraction, OCR, LLM calls, table builds must continue to work identically

---

## REPOSITORY LOCATION

```
/Workspace/Users/adixit01@blueshieldca.com/Contract_Codification_Pipeline/
├── extraction/          ← Notebooks to modify (01-15)
│   ├── 01_file_discovery      (ID: 338955191380347) — NO CHANGES
│   ├── 02_ocr_extraction      (ID: 338955191380348) — NO CHANGES
│   ├── 03_metadata_parsing    (ID: 338955191380349) — NO CHANGES
│   ├── 04_llm_prompts         (ID: 338955191380350) — NO CHANGES
│   ├── 05_llm_extraction      (ID: 338955191380351) — NO CHANGES
│   ├── 06_validation          (ID: 338955191380352) — MODIFY (add gates)
│   ├── 07_consolidation       (ID: 338955191380353) — DELETE ENTIRELY
│   ├── 08_build_rates         (ID: 338955191380354) — MODIFY (inline dedup, fix supersession)
│   ├── 09_build_terms         (ID: 338955191380355) — NO CHANGES
│   ├── 10_build_documents     (ID: 338955191380356) — NO CHANGES
│   ├── 11_enrich_tables       (ID: 338955191380357) — MINOR FIX (remove consolidated dep)
│   ├── 12_build_genie         (ID: 338955191380358) — MODIFY (views instead of tables)
│   ├── 13_build_serving       (ID: 338955191380359) — NO CHANGES
│   ├── 14_quality_audit       (ID: 338955191380360) — NO CHANGES
│   └── 15_gap_filler          (ID: 338955191380361) — NO CHANGES
├── platform/            ← Modules to modify/delete
│   ├── 00_config.py           — MODIFY (add telemetry helper)
│   ├── 01_execute_ddl.py      — MODIFY (remove empty table DDLs)
│   ├── 02_state_engine.py     — MODIFY (read from documents_master, not amendment_timeline)
│   ├── 03_reimbursement_migration.py — NO CHANGES
│   ├── 04_legal_chunking.py   — NO CHANGES
│   ├── 05_retrieval_engine.py — NO CHANGES (keep skeleton for future)
│   ├── 06_reranking_service.py    — DELETE
│   ├── 07_citation_verification.py — DELETE
│   ├── 08_intelligence.py     — MODIFY (remove fabricated spend/leverage, keep benchmarks)
│   ├── 09_scenario_engine.py  — DELETE
│   ├── 10_leverage_scoring.py — DELETE
│   └── 11_evaluation_harness.py — NO CHANGES
└── sql/
    ├── state_engine_ddl.sql   — MODIFY (remove bitemporal DDL)
    ├── reimbursement_ddl.sql  — MODIFY (remove empty table DDLs)
    └── taxonomy_seed.sql      — NO CHANGES
```

---

## TASK 1: DELETE DEAD PLATFORM MODULES

Delete these files entirely (they deliver zero value and confuse the codebase):

```
platform/06_reranking_service.py     — RERANKER_DEPLOYED=False; adds score+0.1 (noop)
platform/07_citation_verification.py — NLI = keyword overlap; no real verification
platform/09_scenario_engine.py       — volume_per_line=50 hardcoded; fabricated
platform/10_leverage_scoring.py      — plan_market_share=0.25 hardcoded; meaningless
```

**Before deleting:** Read `platform/05_retrieval_engine.py` and `platform/08_intelligence.py` to confirm they do NOT import from any of the 4 files above. If they do, remove those import lines.

---

## TASK 2: DELETE CONSOLIDATION NOTEBOOK

Delete `extraction/07_consolidation` (notebook ID: 338955191380353).

**Rationale:** Its outputs (`json_consolidated/*.json`) are consumed by `08_build_rates` but the supersession status it computes is OVERWRITTEN by the 11a-fix in that same notebook. The 20 lines of version-dedup logic will be inlined into `08_build_rates` (Task 4).

**Pre-check:** Confirm that `08_build_rates`, `10_build_documents`, `11_enrich_tables`, and `12_build_genie` can all function reading from `json_extract/` alone (they already read from both sources — we just make `json_extract` the sole source).

---

## TASK 3: MODIFY `06_validation` — Add Enforcement Gates

Notebook ID: `338955191380352`

The validation notebook currently FLAGS issues but never BLOCKS bad files. Add three enforcement mechanisms:

### 3A: Add Rate Reasonability Bounds

After the `postprocess_rate_numeric()` function definition cell, add a rate bounds check:

```python
RATE_BOUNDS = {
    'inpatient_per_diem': (50, 100_000),
    'inpatient_case_rate': (500, 500_000),
    'outpatient_surgical': (100, 200_000),
    'capitation': (0.50, 5000),
}

def check_rate_reasonability(ec):
    """Flag rates outside plausible bounds."""
    flags = []
    ip = ec.get('inpatient_rates', {}) or {}
    for pdr in (ip.get('per_diem_rates') or []):
        val = pdr.get('rate_numeric')
        if val is not None:
            lo, hi = RATE_BOUNDS.get('inpatient_per_diem', (0, 1e9))
            if val < lo or val > hi:
                flags.append({'field': 'inpatient_per_diem', 'value': val, 'bounds': (lo, hi)})
    for cr in (ip.get('case_rates') or []):
        val = cr.get('rate_numeric')
        if val is not None:
            lo, hi = RATE_BOUNDS.get('inpatient_case_rate', (0, 1e9))
            if val < lo or val > hi:
                flags.append({'field': 'inpatient_case_rate', 'value': val, 'bounds': (lo, hi)})
    cap = ec.get('capitation_table', {}) or {}
    for cat_rate in (cap.get('rates_by_category') or []):
        val = cat_rate.get('rate_numeric')
        if val is not None:
            lo, hi = RATE_BOUNDS.get('capitation', (0, 1e9))
            if val < lo or val > hi:
                flags.append({'field': 'capitation', 'value': val, 'bounds': (lo, hi)})
    return flags
```

### 3B: Add Temporal Consistency Check

```python
def check_temporal_consistency(ec):
    """Verify effective < expiration, no future execution, plausible years."""
    issues = []
    co = ec.get('contract_overview', {}) or {}
    eff = parse_date_flexible(co.get('effective_date'))
    exp = parse_date_flexible(co.get('expiration_date'))
    exe = parse_date_flexible(co.get('execution_date'))
    if eff and exp and eff >= exp:
        issues.append({'check': 'effective_before_expiration', 'issue': f'{eff} >= {exp}'})
    if exe and exe > datetime.now():
        issues.append({'check': 'execution_not_future', 'issue': f'{exe} is future'})
    if eff and eff.year < 1990:
        issues.append({'check': 'effective_plausible', 'issue': f'{eff.year} < 1990'})
    if exp and exp.year > 2040:
        issues.append({'check': 'expiration_plausible', 'issue': f'{exp.year} > 2040'})
    return issues
```

### 3C: Add Quarantine Gate (AFTER main processing loop)

Add a NEW section at the END of the main processing cell (Cell index 7, after all files are enriched):

```python
# ═══ QUARANTINE GATE ═══
# Block files with severe quality issues from downstream table builds
import shutil

QUARANTINE_DIR = f"{BASE_DIR}/json_extract/_quarantine"
os.makedirs(QUARANTINE_DIR, exist_ok=True)

quarantined = 0
for jf in json_files:
    jp = os.path.join(OUTPUT_DIR, jf)
    try:
        with open(jp) as f:
            doc = json.load(f)
    except:
        continue
    
    v = doc.get('validation', {})
    if v.get('quarantined'):
        continue  # already quarantined
    
    rates_v = v.get('rates_verified', 0)
    rates_u = v.get('rates_unverified', 0)
    total_rates = rates_v + rates_u
    bucket = v.get('content_bucket', '')
    coverage = v.get('v6_coverage_pct', 100)
    
    should_quarantine = False
    reasons = []
    
    if total_rates > 5 and rates_u / max(total_rates, 1) > 0.50:
        should_quarantine = True
        reasons.append(f"rates_unverified={rates_u}/{total_rates}")
    
    if bucket == 'B1_Base_Agreement' and coverage < 15:
        should_quarantine = True
        reasons.append(f"base_agreement_coverage={coverage}%")
    
    if should_quarantine:
        shutil.copy2(jp, os.path.join(QUARANTINE_DIR, jf))
        doc['validation']['quarantined'] = True
        doc['validation']['quarantine_reasons'] = reasons
        with open(jp, 'w') as f:
            json.dump(doc, f, indent=2, ensure_ascii=False)
        quarantined += 1

print(f"  🔒 Quarantine: {quarantined} files blocked from table build")
```

### 3D: Integrate Bounds + Temporal into Main Loop

In the main processing loop (the cell that iterates json_files and writes validation keys), add these checks to the validation dict that gets written:

```python
    # ── 8. Rate reasonability bounds ──
    rate_flags = check_rate_reasonability(ec)
    
    # ── 9. Temporal consistency ──
    temporal_issues = check_temporal_consistency(ec)
    
    # Add to validation dict:
    doc['validation']['rate_reasonability_flags'] = rate_flags
    doc['validation']['temporal_issues'] = temporal_issues
```

---

## TASK 4: MODIFY `08_build_rates` — Inline Dedup + Fix Supersession

Notebook ID: `338955191380354`

### 4A: Inline Version De-duplication

At the TOP of the JSON-loading cell (the cell that loads `individual_docs` and `providers_data`), REPLACE the `providers_data` loading block with version dedup logic:

```python
# ═══ VERSION DE-DUPLICATION (replaces removed 07_consolidation) ═══
# When multiple extraction versions exist for same file, keep highest version.
from collections import defaultdict

def dedup_extraction_versions(docs_dict):
    """Keep highest version per (provider_id, contract_id, doc_type, effective_date)."""
    groups = defaultdict(list)
    for fname, doc in docs_dict.items():
        fm = doc.get('file_metadata', {})
        co = (doc.get('extracted_content') or {}).get('contract_overview', {}) or {}
        key = (fm.get('provider_id', ''), fm.get('contract_id', ''),
               fm.get('document_type', ''), co.get('effective_date', ''))
        groups[key].append(fname)
    
    keep = set()
    for key, fnames in groups.items():
        if len(fnames) == 1:
            keep.add(fnames[0])
        else:
            best = max(fnames, key=lambda fn: int(re.search(r'_v(\d+)', fn).group(1)) if re.search(r'_v(\d+)', fn) else 0)
            keep.add(best)
    
    removed = len(docs_dict) - len(keep)
    if removed > 0:
        print(f"  Version dedup: removed {removed} duplicate extractions")
    return {k: v for k, v in docs_dict.items() if k in keep}
```

Then after loading `individual_docs`, call it:
```python
individual_docs = dedup_extraction_versions(individual_docs)
```

### 4B: Remove Dependency on `json_consolidated/`

In the same cell, REMOVE the block that loads `providers_data` from `CONSOLIDATED_DIR`. Replace Source 1 (which reads `rate_timeline` from consolidated JSON) with rate extraction directly from `individual_docs` using the existing `make_rate_row()` function. The `json_extract` individual docs contain the same rate data.

Specifically:
- Remove: the `providers_data = []` loading loop from `CONSOLIDATED_DIR`
- Remove: the "Source 1: Core rates from consolidated rate_timeline" loop
- The rates will ALL come from Source 2 (individual docs) and Source 3 (capitation)
- The 11a-fix already computes status from `amendment_order` — it doesn't need pre-computed status

### 4C: Skip Quarantined Files

In the JSON-loading loop, add a quarantine filter:
```python
for jf in sorted(f for f in os.listdir(OUTPUT_DIR) if f.endswith('.json') and not f.startswith('_')):
    with open(os.path.join(OUTPUT_DIR, jf)) as f:
        doc = json.load(f)
    # Skip quarantined files
    if doc.get('validation', {}).get('quarantined'):
        continue
    individual_docs[jf] = doc
```

### 4D: Fix Supersession — Wire Scope Classification

In the 11a-fix cell, modify the supersession logic to be scope-aware:

Currently it does:
```python
# If from latest doc → 'current', else → 'superseded'
```

Replace with scope-aware logic that reads `tbl_v2_amendment_registry.scope_type`:

```python
# ─── 1. SCOPE-AWARE SUPERSESSION ───
# Read amendment scope classification
try:
    scope_df = spark.table(f"{SCHEMA}.tbl_v2_amendment_registry").select(
        "source_filename", "scope_type"
    )
    rates_with_scope = rates_df.join(scope_df, on="source_filename", how="left")
    has_scope = True
except:
    # State engine hasn't run yet — fall back to amendment_order logic
    rates_with_scope = rates_df.withColumn("scope_type", F.lit(None))
    has_scope = False

if has_scope:
    # TERM_EXTENSION amendments don't supersede rates
    # FULL_REPLACEMENT supersedes everything from prior docs
    # RATE_SPECIFIC / EXHIBIT_SPECIFIC supersede within category only
    
    # For FULL_REPLACEMENT: find max order per provider that is full replacement
    full_replace = rates_with_scope.filter(
        F.col("scope_type") == "FULL_REPLACEMENT"
    ).groupBy("provider_id").agg(F.max("doc_order").alias("full_replace_order"))
    
    rates_with_scope = rates_with_scope.join(full_replace, on="provider_id", how="left")
    
    rates_fixed = rates_with_scope.withColumn(
        "status",
        F.when(F.col("status").isNotNull(), F.col("status"))  # keep explicit status
         .when(
            # Superseded by a full replacement
            (F.col("full_replace_order").isNotNull()) &
            (F.col("doc_order") < F.col("full_replace_order")) &
            (F.col("scope_type") != "FULL_REPLACEMENT"),
            F.lit("superseded")
         ).when(
            # TERM_EXTENSION never supersedes — keep rates as current
            F.col("scope_type") == "TERM_EXTENSION",
            F.lit("current")
         ).when(
            # Default: latest per provider
            F.col("doc_order") == F.col("max_order"), F.lit("current")
         ).otherwise(F.lit("superseded"))
    ).drop("scope_type", "full_replace_order")
else:
    # Fallback: original amendment_order logic (first run before state engine)
    rates_fixed = rates_with_order.withColumn(
        "status",
        F.when(F.col("status").isNotNull(), F.col("status"))
         .when(F.col("doc_order") == F.col("max_order"), F.lit("current"))
         .otherwise(F.lit("superseded"))
    )
```

This makes supersession CORRECT on second run (after state engine) while still working on first run.

---

## TASK 5: MODIFY `platform/02_state_engine.py` — Fix Circular Dependency

Currently reads from `tbl_genie_amendment_timeline` (built by step 12).
Change to read from `tbl_contract_documents_master` (built by step 10).

Replace:
```sql
FROM {FQ}.tbl_genie_amendment_timeline a
WHERE a.amendment_order = 0
```

With:
```sql
FROM {FQ}.tbl_contract_documents_master a
WHERE a.amendment_order = 0
   OR a.doc_role = 'base_agreement'
```

And in the amendment registry INSERT, replace:
```sql
FROM {FQ}.tbl_genie_amendment_timeline a
WHERE a.amendment_order > 0
```

With:
```sql
FROM {FQ}.tbl_contract_documents_master a
WHERE a.amendment_order > 0
  AND a.doc_role != 'base_agreement'
```

Adjust column references as needed (documents_master may have slightly different column names than amendment_timeline — check both schemas).

---

## TASK 6: MODIFY `12_build_genie` — Replace Redundant Table with View

Notebook ID: `338955191380358`

Replace the `tbl_genie_contract_terms` CTAS with a view:
```sql
CREATE OR REPLACE VIEW dev_adb.raw.vw_genie_contract_terms AS
SELECT ... FROM dev_adb.raw.tbl_contract_clauses_terms WHERE ...;
```

Keep `tbl_genie_rates_current`, `tbl_genie_provider_profile`, and `tbl_genie_amendment_timeline` as materialized tables for now (Genie Space performance). Mark with a comment that they are derived and could become views.

---

## TASK 7: DROP EMPTY/FABRICATED TABLES

Add a cleanup cell to `platform/01_execute_ddl.py` OR run directly in SQL:

```sql
-- Empty DDL theater (never populated, no code writes to them)
DROP TABLE IF EXISTS dev_adb.raw.tbl_v2_rate_facts_bitemporal;
DROP TABLE IF EXISTS dev_adb.raw.tbl_reimb_formula_components;
DROP TABLE IF EXISTS dev_adb.raw.tbl_reimb_escalators;
DROP TABLE IF EXISTS dev_adb.raw.tbl_reimb_conditions;
DROP TABLE IF EXISTS dev_adb.raw.tbl_retrieval_telemetry;

-- Fabricated intelligence (hardcoded formulas, misleading outputs)
DROP TABLE IF EXISTS dev_adb.raw.tbl_intel_provider_spend_summary;
DROP TABLE IF EXISTS dev_adb.raw.tbl_intel_savings_opportunity;
DROP TABLE IF EXISTS dev_adb.raw.tbl_intel_leverage_scores;
DROP TABLE IF EXISTS dev_adb.raw.tbl_intel_scenario_results;

-- Redundant Genie table (replaced by view in Task 6)
DROP TABLE IF EXISTS dev_adb.raw.tbl_genie_contract_terms;
```

Also remove the DDL for these tables from `sql/state_engine_ddl.sql` and `sql/reimbursement_ddl.sql`.

---

## TASK 8: MODIFY `platform/08_intelligence.py` — Keep Only Real Metrics

Remove the functions and code blocks that compute:
- `estimated_annual_spend` (formula: `avg_rate × total_rate_rules × 50` — meaningless)
- `savings_opportunity` (depends on fabricated spend)
- `leverage_scores` (hardcoded `plan_market_share=0.25`)
- `scenario_results` (hardcoded `volume_per_line=50`)

KEEP:
- `tbl_intel_benchmark_results` — rate percentiles from actual data (real)
- `tbl_intel_renewal_priority` — contract expiry dates are real data (useful)

---

## TASK 9: ADD TELEMETRY TABLE

In `platform/00_config.py`, add a telemetry helper that all notebooks can use:

```python
import uuid
from datetime import datetime, timezone

_RUN_ID = str(uuid.uuid4())
_TELEMETRY_BUFFER = []
_TELEMETRY_TABLE = "dev_adb.raw.tbl_pipeline_telemetry"

def log_telemetry(step, check, result, filename=None, provider_id=None,
                  severity='INFO', detail=None, metric=None, value=None):
    _TELEMETRY_BUFFER.append({
        'run_id': _RUN_ID, 'ts': datetime.now(timezone.utc).isoformat(),
        'step': step, 'check': check, 'result': result,
        'filename': filename, 'provider_id': provider_id,
        'severity': severity, 'detail': json.dumps(detail) if detail else None,
        'metric': metric, 'value': value
    })

def flush_telemetry():
    if not _TELEMETRY_BUFFER:
        return 0
    df = spark.createDataFrame(_TELEMETRY_BUFFER)
    df.write.mode("append").saveAsTable(_TELEMETRY_TABLE)
    n = len(_TELEMETRY_BUFFER)
    _TELEMETRY_BUFFER.clear()
    return n
```

Add the DDL for this table to `sql/state_engine_ddl.sql`:
```sql
CREATE TABLE IF NOT EXISTS dev_adb.raw.tbl_pipeline_telemetry (
  run_id STRING, ts TIMESTAMP, step STRING, check STRING, result STRING,
  filename STRING, provider_id STRING, severity STRING,
  detail STRING, metric STRING, value DOUBLE
) USING DELTA;
```

---

## TASK 10: VERIFY END-TO-END

After all modifications, confirm the pipeline still runs cleanly:

1. **Dry run with 5 new test PDFs** — place 5 PDFs in Volume, run 01 through 12
2. **Check `tbl_contract_rates_all`** — status column should have both 'current' and 'superseded'
3. **Check quarantine** — `json_extract/_quarantine/` should exist (may be empty if files are clean)
4. **Check Genie Space** — NL queries still return correct answers
5. **Check state engine** — `tbl_v2_contract_registry` populates from `documents_master` not `amendment_timeline`
6. **Confirm deleted modules** — `platform/06`, `07`, `09`, `10` no longer exist
7. **Confirm deleted tables** — the 10 dropped tables return errors on SELECT

---

## EXECUTION ORDER

Perform tasks in this order to avoid breaking intermediate state:

1. **Task 7** — Drop empty/fabricated tables (safe, no dependencies)
2. **Task 1** — Delete dead platform modules (safe, nothing imports them)
3. **Task 8** — Trim intelligence module (keep benchmarks, remove fabricated)
4. **Task 3** — Modify 06_validation (additive — new gates)
5. **Task 4** — Modify 08_build_rates (inline dedup, remove consolidated dep, fix supersession)
6. **Task 2** — Delete 07_consolidation (safe now that 08 doesn't need it)
7. **Task 5** — Fix state engine dependency (reads documents_master)
8. **Task 6** — Convert Genie table to view
9. **Task 9** — Add telemetry infrastructure
10. **Task 10** — End-to-end verification

---

## WHAT NOT TO DO

- Do NOT create new notebooks for fixes — edit in place
- Do NOT create a `fixes/` or `patches/` folder
- Do NOT leave commented-out code — delete dead code cleanly
- Do NOT modify `04_llm_prompts` or `05_llm_extraction` — they work correctly
- Do NOT modify Genie Space instructions yet (do that after views are confirmed working)
- Do NOT attempt to process remaining 10K PDFs in this session — that's Month 2
- Do NOT rebuild the VS index — that's Month 3
- Do NOT try to connect claims data — that's Month 4

---

## EXPECTED RESULT

After this session, the pipeline:
- Runs 01 → 06 → 08 → 09 → 10 → 11 → 12 → state_engine (no 07)
- Produces correct scope-aware supersession on second run
- Quarantines bad files before they corrupt tables
- Has zero empty tables, zero fabricated intelligence, zero dead modules
- Works identically whether run on 199 files or 10,372 files
- Is 3,500 lines lighter and architecturally honest
