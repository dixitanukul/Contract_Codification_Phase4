# CONTRACT INTELLIGENCE DEMO NOTEBOOK — CRITICAL REVIEW
## The Most Important Asset in the Platform

**Subject:** `Contract_Intelligence_Demo` (ID: 519828381334841)  
**Path:** `/Users/adixit01@blueshieldca.com/Contract_Codification_Pipeline/Contract_Intelligence_Demo`  
**Date:** 2026-05-28  
**Verdict:** An **impressive corpus-wide analytical engine** that genuinely delivers enterprise intelligence — but packaged in a prototype shell with live-demo vulnerabilities that undermine the engineering achievement.

---

## EXECUTIVE ASSESSMENT

This notebook is simultaneously the **best demonstration of platform capability** and the **highest-risk asset** for a leadership demo. The "Ask Anything" engine genuinely performs a 7-step analytical pipeline that processes 1.36M text chunks, classifies hundreds of passages in parallel, and produces a multi-section HTML report with provider rollups, category distributions, and evidence tables — all in 2-4 minutes.

**The engineering is real. The intelligence is real. The packaging is not enterprise-grade.**

| Dimension | Rating | Notes |
| --- | --- | --- |
| Analytical depth | 5/5 | 7-step pipeline with corpus-wide coverage — exceptional |
| Retrieval completeness | 4/5 | Dual-channel (semantic + full SQL scan) covers the corpus |
| Classification quality | 4/5 | LLM classification with disambiguation rules is production-worthy |
| Provider rollup logic | 5/5 | HAS/NO_MENTION/DENIED/MIXED with temporal caveats — exactly right |
| UI/UX polish | 2/5 | HTML cards are clean but notebook-bound; widget UX is awkward |
| Demo resilience | 2/5 | UTF-8 encoding errors in KPI cells RIGHT NOW |
| Leadership confidence | 3/5 | Impressive output IF it runs; visible errors destroy confidence |
| Enterprise appearance | 2/5 | Still looks like a notebook, not a platform |
| Latency for live demo | 2/5 | 2-4 minutes is too long for live executive attention |
| Error handling | 3/5 | Good try/except but error messages are developer-facing |

---

## PART 1: SECTION-BY-SECTION ANALYSIS

### 1. Title/KPI Markdown (Cell 1)
**Assessment:** GOOD foundation.
- Clean metrics table (271 providers, 10,372 PDFs, 83K passages)
- Clear value proposition statement
- Technology stack listed tastefully

**Weakness:** Static numbers. If data changes, markdown is stale. Should pull live counts.

### 2. Install Dependencies (Cell 2)
**Assessment:** FUNCTIONAL but ugly for demo.
- `%pip install` output visible to audience
- `restartPython()` is jarring during live run
- Should be hidden or pre-run before demo

**Demo Risk:** If run live, yellow warning message appears. Audience sees "Note: you may need to restart the kernel..."

### 3. Setup and Helper Functions (Cell 3)
**Assessment:** SOLID engineering.
- Direct REST API to Claude (correct — avoids ai_query overhead)
- 60s timeout on LLM calls
- VectorSearchClient properly initialized
- Provider list pre-cached (271 providers)
- Clean HTML helper functions (styled_card, styled_table, section_header)
- Error handling on client init

**Strengths:**
- REST API approach is production-correct
- HTML helpers produce polished output
- Provider caching eliminates redundant queries

**Weaknesses:**
- `_api_token` via `dbutils.notebook.entry_point` — works but session-scoped
- No retry logic on LLM calls
- No circuit breaker for VS endpoint unavailability
- Temperature 0.1 is good for classification but should be 0.0 for deterministic extraction

### 4. Portfolio KPI Dashboard (Cell 4)
**Assessment:** CURRENTLY BROKEN.
- **Error:** `'utf-8' codec can't encode characters in position 167-168: surrogates not allowed`
- This is caused by emoji characters (`\ud83c\udfe5`, `\ud83d\udcb0`) in `styled_card()` when passed through `displayHTML()`
- The surrogate pair encoding fails on this cluster/runtime combination

**Demo Risk:** CRITICAL. Cell 4 shows a red error box in the demo right now. Leadership sees a red error box instead of portfolio metrics.

**Fix:** Replace emoji strings with HTML entity equivalents (`&#x1F3E5;` instead of Python emoji).

### 5. Portfolio Charts (Cell 5)
**Assessment:** ALSO CURRENTLY BROKEN — same UTF-8 surrogate error.
- Plotly charts (agreement type bar + contract status pie) are well-designed
- Color palette is professional (#1B3A5C, #2E86AB, #D64045)
- Layout is clean, properly sized

**Fix:** Same as Cell 4 — the `section_header()` call uses emoji that trigger the encoding bug.

### 6. Ask Anything Engine (Cell 6) — THE CORE DEMO
**Assessment:** IMPRESSIVE ENGINEERING. This is the heart of the platform demo.

**Architecture (7-step pipeline):**

| Step | What It Does | Quality |
| --- | --- | --- |
| 1. Question Understanding | LLM extracts keywords, intent, target concept | 4/5 |
| 1.5. Execution Plan | LLM triages keywords: core/extended/excluded + disambiguation | 5/5 |
| 2. Taxonomy Generation | LLM creates domain-specific classification categories | 4/5 |
| 3. Hybrid Retrieval | VS semantic (100) + full SQL keyword scan (corpus-wide) | 4/5 |
| 4. Merge and Dedup | Score semantic results, merge with Spark-scored SQL, dedup by filename | 4/5 |
| 5. LLM Classification | ALL candidates classified in batches of 10, 14 parallel workers | 5/5 |
| 6. Provider Rollup | HAS/NO_MENTION/DENIED/MIXED with temporal awareness | 5/5 |
| 7. HTML Report | Multi-section: exec summary, categories, provider lists, findings, methodology | 4/5 |

### 7. Example Questions (Cell 7)
**Assessment:** GOOD curation.
- 5 diverse examples covering existence, comparison, explanation, and data queries
- Clear description of what the engine does for each
- Methodology summary is accurate

**Weakness:** Examples are all "existence" type. Should show rate lookups, timeline queries, and single-provider deep dives too.

### 8. Leadership Talking Points (Cell 8)
**Assessment:** SOLID executive communication.
- Scale metrics are impressive and accurate
- 6 capabilities well-articulated
- ROI section is compelling ("90% reduction in manual review")
- Technology stack positioned correctly
- Next steps are realistic

**Weakness:** Still reads as internal notes, not polished executive material.

---

## PART 2: DEEP REVIEW — "ASK ANYTHING" ENGINE

### Query Understanding Quality
**Rating:** 4/5

The two-LLM-call approach (understanding + execution plan) is excellent:
- Step 1 extracts: search_keywords, semantic_query, analysis_type, is_negative, target_concept, provider_filter
- Step 1.5 triages keywords into core/extended/excluded with disambiguation rules
- The disambiguation concept is production-grade — "offset" IS the provision; "deduction" is NOT

**Weaknesses:**
- No validation that LLM returns valid JSON (bare try/except with fallback)
- Fallback logic loses the disambiguation sophistication
- No keyword expansion beyond what the LLM generates in one shot
- `provider_filter` extraction not used in retrieval (only semantic, not SQL)

### Prompt Quality
**Rating:** 4/5

**Strengths:**
- Classification prompt has explicit disambiguation section
- "CRITICAL for denial category" instruction prevents false-denial classification
- "When in doubt, prefer positive category" reduces false negatives
- Key_phrase extraction forces grounding in source text
- Batch format (10 passages per call) is efficient

**Weaknesses:**
- No system message — relies entirely on user message
- No few-shot examples for edge cases
- Classification prompt doesn't mention temporal priority (amendments > base)
- No instruction to handle cross-references ("Subject to Section X")
- `max_tokens=2048` for 10-passage classification may truncate (10 passages x ~200 tokens each = 2000+)

### Taxonomy Generation Quality
**Rating:** 4/5

Dynamic taxonomy generation per question is brilliant — avoids hardcoded categories. The "offset clause" example produces 6 sub-types (OVERPAYMENT_OFFSET, GENERAL_OFFSET, etc.) which is exactly the right granularity.

**Weaknesses:**
- No validation that generated categories are mutually exclusive
- No cross-query consistency (same concept may get different taxonomies on re-run)
- Fallback taxonomy is too generic (just "Present" / "Denied" / "Referenced")

### Retrieval Orchestration
**Rating:** 4/5

**Excellent design decisions:**
- Uses `tbl_contract_fulltext_vs_ready` (1.36M chunks) — the largest corpus
- Falls back from fulltext VS index to `idx_legal_units_v2` if first fails
- SQL scoring happens IN SPARK (not Python) — handles 10-30K rows efficiently
- Core/extended keyword differentiation prevents false matches
- ROW_NUMBER dedup keeps best-scoring chunk per source_filename
- Minimum 50-char filter removes noise (headers, page numbers)

**Weaknesses:**
- SQL injection via f-string on keywords (same vulnerability as retrieval engine)
- No score_threshold on VS results (any similarity score accepted)
- Semantic channel returns 100 results but only scores by keyword presence (ignores VS score)
- Keyword scoring doesn't differentiate "offset appears in section title" vs "offset in footnote"
- Falls back to `vw_genie_contract_terms` (69K rows) if fulltext fails — much smaller corpus

### Classification Reliability
**Rating:** 4/5

14 parallel workers x 10 passages per batch x Claude classification is genuinely reliable:
- JSON parse failure handled with heuristic fallback
- Truncated JSON repaired (finds last `}`, closes array)
- Category validation against taxonomy (rejects unknown categories -> NOT_RELEVANT)
- Disambiguation rules injected into prompt reduce misclassification

**Vulnerabilities:**
- If LLM returns fewer classifications than passages in batch, some get dropped silently
- No retry on failed batches (just swallowed by `except Exception: pass`)
- Heuristic fallback classifies ALL as first positive category — could inflate counts
- No confidence score on classification (binary: is or isn't)
- 600-char truncation of passage text may lose critical qualifying language

### Parallelization Strategy
**Rating:** 5/5

Excellent. Three levels of parallelism:
1. Plan + Taxonomy generated concurrently (ThreadPoolExecutor, 2 workers)
2. Classification runs 14 parallel workers
3. Spark SQL scoring runs distributed

This brings a 300-passage classification from ~60 sequential LLM calls to ~22 parallel rounds.

### Failure Handling
**Rating:** 3/5

| Scenario | Handling | Quality |
| --- | --- | --- |
| LLM timeout | Returns error string | MEDIUM — error becomes a "passage" |
| LLM JSON parse failure | Heuristic fallback (all = first category) | WEAK — inflates counts |
| VS endpoint down | Falls back to second index | GOOD |
| SQL query failure | Falls back to vw_genie_contract_terms | GOOD |
| Empty candidates | Shows "No relevant passages found" | GOOD |
| Overall exception | Shows error with traceback (last 800 chars) | DEVELOPER-FACING, not exec-ready |

### False-Positive Handling
**Rating:** 4/5

The execution plan's keyword triage (core/extended/excluded) is specifically designed to reduce false positives. The disambiguation rules ("IS NOT offset: deductions for patient copays") are injected into the classification prompt.

**Gap:** No post-classification validation. If LLM classifies a passage as OVERPAYMENT_OFFSET but the passage is about patient refunds, there's no second-pass check.

### False-Negative Handling
**Rating:** 3/5

The "broad" precision strategy can include all keywords, and the "when in doubt, prefer positive" instruction reduces false negatives. However:
- The full SQL scan is OR-based (any keyword matches) — good for recall
- Minimum score threshold of 2 means single-keyword matches are included
- But: dedup keeps only BEST chunk per file — a relevant passage in a low-scoring chunk position is lost

### Dedup Logic
**Rating:** 4/5

Two-level dedup:
1. **Spark SQL:** ROW_NUMBER OVER (PARTITION BY source_filename ORDER BY score DESC) = 1
2. **Python:** If same filename appears in both semantic and keyword channels, keep highest score

This is correct for the "one finding per contract" analytical model. However:
- A contract with offset clauses in BOTH the base agreement AND an amendment -> only one is kept
- Multi-section provisions (stop-loss with 3 sub-clauses in different chunks) -> only best chunk kept

### Explainability
**Rating:** 4/5

The methodology section (Section 6 of report) is comprehensive:
- Lists all 7 steps with counts
- Shows core/extended/excluded keyword counts
- Reports data source, runtime, model
- Caveats section explicitly addresses "No Mention does not equal Prohibition"

**Gap:** No per-passage explanation of WHY it was retrieved (which keywords matched, which channel).

### Citation Quality
**Rating:** 3/5

Each classified passage includes:
- Provider name
- Source filename
- Page number
- Key phrase (verbatim quote, max 100 chars)
- Reasoning (one sentence)

**Gaps:**
- No page-level PDF link
- Filename is truncated in display (last 40 chars)
- Key phrase is LLM-extracted, not verified against source
- No section/article reference

### Provider Rollup Correctness
**Rating:** 5/5

The rollup logic is genuinely excellent:
- HAS_PROVISION: Any positive classification
- EXPLICITLY_DENIED: Only denial categories (no positive)
- MIXED: Both positive AND denial in same provider (requires temporal review)
- NO_MENTION: In provider universe but zero relevant classifications
- AMBIGUOUS: Edge case (relevant but unclassifiable)

The MIXED detection with "ACTION NEEDED" callout is exactly what contract analysts need.

### Mixed-State Detection
**Rating:** 5/5

Correctly identifies when a provider has both grant and denial language across different documents. The report explains "Later amendments may supersede earlier provisions. Temporal review required." This is legally correct and actionable.

### Temporal Awareness
**Rating:** 2/5

**Current state:** Minimal. Uses `is_from_latest_doc = true` in fallback query, but the primary fulltext search has no temporal filter. The MIXED detection acknowledges temporal complexity but doesn't resolve it.

**Missing:**
- No amendment ordering (which came first?)
- No "latest wins" logic
- No effective_date comparison
- No supersession chain resolution

### Performance
**Rating:** 3/5

Expected runtime: 2-4 minutes for corpus-wide analysis.

| Phase | Estimated Latency |
| --- | --- |
| Question understanding | ~2s |
| Plan + Taxonomy (parallel) | ~3s |
| Hybrid retrieval (VS + SQL) | ~15-30s |
| Merge and dedup | ~1s |
| Classification (14 workers x N batches) | 60-180s |
| Provider rollup + report | ~2s |
| **Total** | **~120-240s** |

The classification phase dominates. For 300 candidates: 30 batches / 14 workers x ~3s per call = ~7 rounds x 3s = ~21s theoretical minimum, but with network variance and queuing, realistically 60-90s.

### UI Polish
**Rating:** 2/5

**What's good:**
- Gradient KPI cards are visually appealing
- Color coding (blue=HAS, red=DENIED, purple=MIXED, orange=NO_MENTION) is intuitive
- Collapsible details sections keep the report scannable
- Category distribution table is clean

**What's not enterprise:**
- It's a notebook cell output, not a standalone interface
- Widget text input for questions is clunky
- No loading indicator during 2-4 minute execution
- Progress messages print to stdout (developer console, not UI)
- Emoji rendering issues (the UTF-8 bug in other cells)
- No pagination on findings table (shows 200, truncates rest)

### Executive Readiness
**Rating:** 3/5

An executive seeing this notebook would think:
- "The analysis output is impressive and detailed" (POSITIVE)
- "Why does it take 3 minutes?" (NEGATIVE)
- "Why does the top of the notebook show red errors?" (VERY NEGATIVE)
- "This looks like a developer tool, not a product" (NEGATIVE)
- "Can our team use this?" (UNCLEAR — it's a notebook)

---

## PART 3: WHAT'S WRONG

### Critical Issues (Demo-Breaking)
1. **Cells 4 and 5 show red error messages** — UTF-8 surrogate encoding failure on emoji
2. **2-4 minute execution time** — loses executive attention
3. **SQL injection vulnerability** — f-string keyword interpolation in retrieval SQL
4. **No loading/progress UI** — stdout prints during analysis feel unfinished
5. **Widget re-run UX** — must re-run cell after changing question (not interactive)

### Significant Issues (Trust-Reducing)
6. **Semantic results scored only by keyword presence** — VS similarity score is IGNORED
7. **Classification fallback inflates counts** — parse failure -> all passages get first positive category
8. **No temporal resolution** — MIXED providers don't know which version is current
9. **600-char passage truncation** — may lose qualifying conditions ("provided that...")
10. **No confidence scoring** — binary classification with no uncertainty signal
11. **Key phrases are LLM-generated** — not verified against source (potential hallucination)
12. **Error messages are developer-facing** — traceback shown to executives on failure

### Moderate Issues (Quality-Reducing)
13. **Single-channel VS fallback** — if fulltext index unavailable, falls to 83K-unit index
14. **Dedup loses multi-section provisions** — only best chunk per file kept
15. **No re-run consistency** — taxonomy may differ between runs for same question
16. **provider_filter from understanding is never used** — single-provider queries don't filter
17. **Static markdown metrics** — header says 271 providers but DB may have changed
18. **No evaluation** — classification accuracy is unmeasured

---

## PART 4: WHAT'S IMPRESSIVE

### Genuinely Exceptional Engineering

1. **Corpus-wide analytical coverage** — scans ALL 1.36M chunks, not just top-K. This is rare in RAG systems.
2. **7-step methodology** — mirrors how a human analyst would work (understand -> plan -> retrieve -> classify -> rollup)
3. **Execution plan with disambiguation** — the keyword triage (core/extended/excluded) is a novel and effective approach to precision control
4. **Dynamic taxonomy generation** — avoids brittle hardcoded categories; adapts to any concept
5. **Provider rollup with MIXED detection** — correctly identifies conflicting provisions across documents
6. **Spark-side scoring** — scoring and dedup in SQL prevents Python memory blowup on 10-30K rows
7. **14-worker parallel classification** — aggressive but correct parallelism
8. **Proper caveats** — "No Mention does not equal Prohibition" and "amendment supersession" warnings show domain sophistication
9. **REST API for LLM** — correct production pattern (bypasses ai_query limitations)
10. **HTML report structure** — executive summary -> category table -> provider lists -> detailed findings -> methodology is the right information architecture

### What Leadership Will Love
- "One question leads to a full analytical report across 271 providers"
- The KPI cards and provider status breakdown (HAS/DENIED/MIXED)
- The scale numbers (10,372 PDFs, 1.36M chunks, 83K passages)
- The evidence table with key phrases (feels grounded, not hallucinated)
- The methodology transparency ("here's exactly how we got this answer")
- The MIXED provider "ACTION NEEDED" callout (actionable intelligence)
- The speed relative to manual analysis (days reduced to minutes)

---

## PART 5: RISK ANALYSIS

### Biggest Demo Risks
1. **Cells 4+5 broken RIGHT NOW** — first thing leadership sees is red error boxes
2. **LLM timeout during live demo** — 60s timeout x 30 batches = if API is slow, demo stalls
3. **VS endpoint not ready** — if index is syncing, semantic channel returns nothing
4. **Unexpected classification** — LLM may produce surprising categories for novel questions
5. **Long execution time** — 3 minutes of silence while stdout prints

### What Could Fail Live
- Question that returns 0 candidates -> "No relevant passages found" (anticlimactic)
- Question that triggers 500+ candidates -> 8+ minute execution time
- Question with ambiguous concept -> taxonomy generation produces poor categories
- Network timeout on batch 15 of 30 -> partial results, silent failures
- Emoji rendering -> red errors on cells that should be visual showcases

### What Most Impacts Trust
1. **Red error messages anywhere in the notebook** — instant credibility loss
2. **Incorrect classification visible in findings** — if leadership reads details and spots a misclassification
3. **Stale numbers** — if markdown says 271 but query returns 280
4. **No explanation of confidence** — "are you sure about this?"
5. **MIXED status without resolution** — "so which is it?"

### What Most Impacts Wow-Factor
1. The HAS/DENIED/MIXED rollup with exact counts and percentages
2. Category distribution showing sub-types (not just "yes/no")
3. The evidence table with verbatim key phrases
4. Speed: "3 minutes for what would take an analyst 3 weeks"
5. The question flexibility: any concept, any provision, any question

### What Most Impacts Perceived Intelligence
1. Dynamic taxonomy generation (system "understands" the legal concept)
2. Disambiguation rules (system knows what IS vs IS NOT the concept)
3. MIXED detection (system recognizes contradictions)
4. Proper caveats (system knows its own limitations)
5. The execution plan printout showing keyword triage reasoning

---

## PART 6: ARCHITECTURAL WEAKNESSES

### 1. Single Monolithic Cell
The entire Ask Anything engine (46,716 characters) is one massive cell. This means:
- Cannot demo individual steps
- Cannot re-run just classification if taxonomy was wrong
- Cannot iterate on one step without re-running all
- Debugging is painful (which step failed?)

### 2. No Caching Between Runs
Every re-run with a different question repeats:
- Provider universe query (cached after first run — good)
- All LLM calls from scratch (no similarity-based cache)
- Full SQL corpus scan (no incremental)

### 3. Uses V1 Fulltext Corpus, Not V2 Legal Units
The retrieval hits `tbl_contract_fulltext_vs_ready` (1.36M raw chunks) and `tbl_contract_fulltext_vs_index`, NOT the carefully curated `tbl_retrieval_legal_units` (83K legal semantic units) or `idx_legal_units_v2`.

This means:
- Chunks are fixed-size (512 tokens), not clause-aware
- No section hierarchy, no clause boundaries
- No `is_current` state-aware filtering
- No rate_domain or unit_type metadata for precision filtering
- Higher noise (raw OCR chunks vs cleaned legal units)

### 4. No Reranking Layer
RRF fusion from `platform/05_retrieval_engine.py` is not used. The demo has its own retrieval logic that:
- Scores by keyword hit count only (no semantic relevance scoring)
- Has no cross-encoder or legal signal reranking
- Has no authority/recency/specificity signals

### 5. No Citation Verification
The classification prompt asks for key_phrase, but there's no verification that:
- The phrase actually exists in the source text
- The phrase hasn't been taken out of context
- Numerical values in the phrase are accurate

### 6. Classification Without Confidence
Every passage is classified into exactly one category with no uncertainty signal. There's no:
- Confidence score (0-1)
- "Low confidence" flag for borderline classifications
- Human review trigger for uncertain results

---

## PART 7: HIDDEN TECHNICAL DEBT

1. **f-string SQL injection** — 3+ injection points in retrieval SQL
2. **Emoji encoding** — surrogate pairs fail on this runtime (cells 4, 5 broken)
3. **Hardcoded fallback indexes** — if table names change, multiple fallback paths break
4. **No retry on LLM failures** — single attempt, then permanent failure for that batch
5. **Silent batch failures** — `except Exception: pass` in ThreadPoolExecutor swallows errors
6. **Provider universe from wrong table** — uses `tbl_contract_fulltext_vs_ready` instead of `tbl_genie_provider_profile`
7. **max_tokens=2048 may truncate** — 10 passages x 200-token classification = exactly at limit
8. **No rate limiting** — 14 parallel workers could hit serving endpoint throttling
9. **Keyword sanitization incomplete** — `replace("'", "")` doesn't handle all SQL-breaking characters
10. **Static provider count in markdown** — header says 271, but query returns from different tables

---

## PART 8: REDESIGN — WORLD-CLASS EXECUTIVE AI EXPERIENCE

### Vision: From Notebook Demo to Enterprise Intelligence Platform

The demo should feel like presenting a Bloomberg terminal for contracts, not running a Jupyter notebook.

### Redesigned Flow (8 cells, not 1 monolithic):

```
Cell 1: Platform Header (live metrics from DB, no static markdown)
Cell 2: Setup (hidden, pre-run, no visible output)
Cell 3: Portfolio Dashboard (KPIs + charts — MUST work flawlessly)
Cell 4: Analysis Engine Initialization (pre-warm VS, cache providers)
Cell 5: Deep Analysis — Question Input + Execution (the 7-step pipeline)
Cell 6: Analysis Results — Report Output (separate from execution)
Cell 7: Rate Intelligence Demo (benchmark charts, savings table)
Cell 8: Demo Wrap-up (talking points, Q&A section)
```

### Key Design Principles:
1. **Zero red errors** — every cell must succeed or show graceful degradation
2. **Progress visualization** — animated progress bar during analysis
3. **Pre-computed showcase** — have 3 cached results ready for instant display
4. **Interactive without re-run** — dropdown for pre-built questions
5. **Confidence indicators** — green/yellow/red trust signals on results
6. **Executive-first layout** — KPIs and charts ABOVE the fold, details BELOW

---

## PART 9: EXACT ENGINEERING IMPROVEMENTS

### 9.1 Retrieval Improvements
1. Replace f-string SQL with parameterized queries: `spark.sql(query, params={"kw": keyword})`
2. Use `idx_legal_units_v2` as primary semantic index (83K curated units, not 1.36M raw chunks)
3. Add `score_threshold=0.3` to VS similarity_search calls
4. USE the VS similarity score in scoring (not just keyword presence)
5. Add `is_current = TRUE` filter to SQL keyword search
6. Implement OR-based keyword matching with TF weighting: `SUM(CASE WHEN LIKE kw THEN 1/total_kws ELSE 0 END)`
7. Add provider_filter to SQL channel (not just semantic)
8. Keep top-2 chunks per file (not just best) — catches multi-section provisions

### 9.2 Prompting Improvements
1. Add system message: "You are a healthcare contract legal analyst. You classify contract passages with legal precision."
2. Set temperature=0.0 (not 0.1) for classification — maximum determinism
3. Add 2 few-shot examples in classification prompt (one clear positive, one false-positive)
4. Increase max_tokens to 3072 for classification (prevents truncation on 10 passages)
5. Add instruction: "If passage mentions provision but is actually ABOUT a different topic, mark NOT_RELEVANT"
6. Add instruction: "Rate amendments override base agreements — note if this appears to be amended text"
7. Validate key_phrase exists in passage text (deterministic string check)

### 9.3 UI Improvements
1. Replace Python emoji strings with HTML entities (fixes UTF-8 bug immediately)
2. Add animated progress bar during execution: `displayHTML(f'<div class="progress" style="width:{pct}%">')`
3. Replace dbutils.widgets.text with dropdown of pre-curated questions + free-text option
4. Add estimated time remaining display
5. Render results in separate cell (not same cell as execution)
6. Add "Copy to clipboard" button on key findings
7. Add green checkmark next to each completed step (visual progress)
8. Truncate traceback from error displays — show user-friendly message only

### 9.4 Demo-Flow Improvements
1. Pre-run cells 1-4 before leadership enters the room
2. Have 3 pre-computed results cached (offset clause, termination, auto-renewal)
3. Show pre-computed result FIRST (instant), then run live analysis as "bonus"
4. Add transition narration between cells: markdown explaining what's about to happen
5. Create "Speed Demo" mode: show cached results, skip live LLM calls
6. Add audio/visual cue when analysis completes (not just stdout)

### 9.5 Performance Improvements
1. Cache taxonomy for repeated concepts (same target -> same taxonomy)
2. Implement result caching: if same question asked within 1 hour, show cached results
3. Reduce VS semantic results from 100 to 50 (most are low-relevance)
4. Increase batch size from 10 to 15 (fewer LLM calls, same quality)
5. Short-circuit: if SQL returns <20 candidates, skip semantic entirely
6. Pre-warm VS index connection during cell 3 setup

### 9.6 Caching Improvements
1. LRU cache on taxonomy generation (key: target_concept)
2. LRU cache on execution plans (key: target_concept)
3. Provider universe cached globally (already done — good)
4. Full result cache: question hash -> report HTML (1-hour TTL)
5. VS connection object cached (avoid re-init per query)

### 9.7 Concurrency Improvements
1. Current: 14 parallel LLM workers — good but risky for rate limits
2. Add adaptive concurrency: start with 14, back off to 8 if getting 429s
3. Add per-batch timeout: 30s per batch, retry once, then skip
4. Make retrieval channels parallel (VS + SQL concurrently, not sequentially)
5. Pipeline overlap: start classifying first batches while later batches still retrieving

### 9.8 Reliability Improvements
1. Add retry with exponential backoff on LLM calls (max 2 retries)
2. Add circuit breaker: if 3 consecutive LLM failures, abort gracefully with partial results
3. Track and report batch failures: "268/300 passages classified successfully (32 skipped due to timeout)"
4. Validate classification JSON schema before accepting (not just JSON parse)
5. Add idempotency: same question + same data -> same results (set random seed)
6. Add watchdog: if total execution exceeds 8 minutes, abort and show partial

### 9.9 Hallucination Protections
1. **Key phrase verification:** After LLM returns key_phrase, verify it exists in passage text (fuzzy match, 80% threshold)
2. **Category validation:** Reject classifications not in taxonomy (already done — good)
3. **Consistency check:** If LLM says "EXPLICITLY_DENIED" but passage contains granting language, flag for review
4. **Numerical grounding:** If classification mentions a dollar amount, verify it appears in passage
5. **Temperature 0.0:** Eliminate randomness in classification
6. **No-evidence escape:** If key_phrase is empty or generic, downgrade confidence

### 9.10 Trust Improvements
1. Add confidence indicator per provider: "HIGH" (3+ supporting passages), "MEDIUM" (1-2), "LOW" (inference only)
2. Add data freshness badge: "Based on data as of [last ETL run date]"
3. Add corpus coverage badge: "Searched 1,361,179 passages across 10,348 documents"
4. Add "Verify" button linking to source document for top findings
5. Add "Known limitations" visible in report (not just in collapsible methodology)
6. Show classification reasoning inline (not just in detail view)

### 9.11 Evaluation Metrics
1. Track per-question: candidates_retrieved, classified_relevant, classification_time
2. Add golden-question validation: run 5 pre-annotated questions, verify results match
3. Measure classification consistency: same question twice -> same provider rollup?
4. Measure precision: for "offset clause" golden answer, verify HAS/DENIED/NO_MENTION counts
5. Log all analyses to `tbl_demo_analysis_log` for quality trending

### 9.12 Production-Hardening
1. Extract Ask Anything engine into a Python module (importable, testable)
2. Add unit tests for: scoring logic, dedup logic, rollup logic
3. Add integration test: known question -> expected provider counts +/-10%
4. Separate HTML rendering from logic (MVC pattern)
5. Add versioning: "Analysis Engine V3.1" visible in output
6. Replace global state (`_provider_universe_cache`) with proper class encapsulation
7. Add structured logging (not print statements)
8. Add monitoring: log every analysis to Delta table with timing, counts, errors

### 9.13 Immediate Fixes (Do Today)
1. **Fix UTF-8 emoji bug** — replace `\ud83c\udfe5` with `&#x1F3E5;` in all `styled_card()` and `section_header()` calls
2. **Fix SQL injection** — replace f-strings with parameterized queries
3. **Pre-run cells 2-3** before demo (hide pip install output)
4. **Test cells 4-5** work after emoji fix (KPIs and charts should render)
5. **Add 3 pre-computed results** as a demo-safety-net cell

---

## FINAL VERDICT

**The Contract_Intelligence_Demo notebook contains genuinely impressive engineering that delivers real enterprise intelligence.** The 7-step analytical pipeline, corpus-wide coverage, dynamic taxonomy, disambiguation rules, and MIXED-state detection represent months of sophisticated work.

**However, the packaging undermines the achievement.** Red errors in the dashboard cells, 3-minute execution times, developer-facing error messages, and notebook-bound UX make it look like a prototype when it should look like a product.

**The single highest-impact change:** Fix the emoji encoding bug in cells 4 and 5 so the portfolio dashboard renders cleanly. This takes 15 minutes and eliminates the most damaging first impression.

**The single highest-value change:** Add a pre-computed results cache so the demo can show instant results for 3 showcase questions, then optionally run live analysis as proof of capability.

**Overall platform readiness:**
- Engineering: 8/10 — genuinely sophisticated
- Packaging: 3/10 — still looks like a developer notebook
- Demo safety: 4/10 — too many ways to fail live
- Intelligence quality: 8/10 — answers are substantive and grounded
- Enterprise credibility: 5/10 — impressive output, unprofessional wrapper

*The engine deserves a better stage.*
