# LEGAL CHUNKING & SEMANTIC REPRESENTATION LAYER — DEEP REVIEW
## BSC Provider Contract Intelligence Platform — Prompt 6

**Review Date:** 2026-05-24
**Scope:** Complete assessment of legal chunking strategy, semantic representation, and retrieval layer
**Files Reviewed:** `platform/04_legal_chunking.py`, `platform/05_retrieval_engine.py`
**Rating:** 2.5/10 for Chunking Quality | 4/10 for Retrieval Architecture | 1/10 for Legal Reasoning Quality

---

## 1. EXECUTIVE SUMMARY

The legal chunking layer is **architecturally misnamed** — it performs zero chunking. `04_legal_chunking.py` is a pure ETL that maps pre-existing V1 structured rows (already one-row-per-clause from the LLM extraction) directly into `tbl_retrieval_legal_units` with no splitting, sliding window, overlap, or semantic boundary enforcement. The resulting 83,008 "units" are uncontrolled in size (2 chars to 12,000+ chars), semantically inconsistent (some are legal prose, some are template-generated strings), and critically incomplete (AMENDMENT_DELTA type defined but never populated; page citations all NULL).

The retrieval engine (`05_retrieval_engine.py`) builds a solid 4-channel RRF architecture but is undermined by these chunking failures, a lexical channel with AND-logic that kills recall, unimplemented entity extraction, and no context window budget management before passing results to the LLM.

**The most dangerous production risk:** amendments that supersede base contract clauses are NOT represented as delta units. A query for a current payment rate will retrieve the original base contract clause alongside the superseding amendment clause with no signal that one overrides the other — hallucination risk is HIGH.

### Executive Ratings

| Dimension                    | Score | Critical Issues |
|------------------------------|-------|----------------|
| Legal Unit Definition        | 3/10  | No chunking algorithm; direct V1 row passthrough |
| Chunk Granularity            | 2/10  | 2-to-12,000 char range; no size control |
| Semantic Density             | 3/10  | Rate units are synthetic template strings |
| Context Preservation         | 1/10  | No overlap, no parent context, isolated units |
| Clause Segmentation          | 2/10  | Inherits LLM extraction quality; no boundary repair |
| Definition Handling          | 5/10  | DEFINITION type exists; no cross-reference expansion |
| Amendment Delta Handling     | 0/10  | AMENDMENT_DELTA type unpopulated |
| Retrieval Chunking Strategy  | 3/10  | No parent-child, no multi-resolution |
| Embedding Suitability        | 2/10  | Template strings + over-length units degrade quality |
| Citation Quality             | 1/10  | page_start NULL for 100% of units |
| Provenance Preservation      | 3/10  | Filename present; no article/section/page path |
| Hallucination Resistance     | 1/10  | Superseded clauses not flagged; amendment delta absent |

---

## 2. CURRENT STATE — WHAT IS ACTUALLY IMPLEMENTED

### 2.1 The "Chunking" Pipeline

```
tbl_contract_terms_vs_ready (69K rows)          tbl_reimb_rate_rules (21K rows)
    content_type → unit_type mapping         →      Template string synthesis
    direct INSERT, no splitting                      "Provider: X\nService: Y\nRate: Z"
           │                                                   │
           └──────────────────────────────────────────────────┘
                                    ▼
                    tbl_retrieval_legal_units (83,008 rows)
                    unit_id | unit_text | unit_type | ...
                    (NO CHUNKING ALGORITHM APPLIED)
```

**What 04_legal_chunking.py actually does:**
1. Creates `tbl_retrieval_legal_units` DDL
2. INSERT from `tbl_contract_terms_vs_ready` — one output row per input row, no transformation of text
3. INSERT from `tbl_reimb_rate_rules` — synthesizes a 6-field template string as `unit_text`
4. Prints summary statistics

**What it does NOT do (the entire named purpose):**
- Detect or enforce semantic chunk boundaries
- Split oversized clauses (no maximum length)
- Merge undersized fragments (minimum = 20 chars)
- Create parent-child chunk relationships
- Generate chunk overlap for context continuity
- Populate AMENDMENT_DELTA units
- Preserve page/paragraph/article citation path

### 2.2 Unit Type Distribution (actual data)

| Unit Type       | Count  | Source                          | Avg Length | Problem |
|-----------------|--------|---------------------------------|------------|---------|
| CLAUSE          | ~42K   | tbl_contract_terms_vs_ready     | ~450 chars | Uncontrolled; some >10K |
| SECTION         | ~12K   | tbl_contract_terms_vs_ready     | ~1,200 chars | Over-long; need splitting |
| DEFINITION      | ~8K    | tbl_contract_terms_vs_ready     | ~200 chars | Good size; no cross-ref |
| RATE_TABLE      | ~21K   | tbl_reimb_rate_rules            | ~180 chars | Synthetic text; poor embedding |
| MEDICAL_CODE    | ~3K    | tbl_contract_terms_vs_ready     | ~80 chars  | Too short; code-only |
| CONDITION       | ~2K    | tbl_contract_terms_vs_ready     | ~300 chars | Acceptable |
| PARTY           | ~1K    | tbl_contract_terms_vs_ready     | ~150 chars | Acceptable |
| AMENDMENT_DELTA | **0**  | NOT POPULATED                   | N/A        | **CRITICAL GAP** |

### 2.3 Retrieval Engine Channel Summary

| Channel    | Method                   | Scoring         | Critical Flaw |
|------------|--------------------------|-----------------|---------------|
| Semantic   | VS similarity_search     | Cosine score    | Template strings corrupt embedding space |
| Lexical    | ILIKE with AND logic     | Position-based  | AND kills recall; not BM25 |
| Metadata   | Structured SQL           | Position-based  | RATE_LOOKUP only; entities never extracted |
| Structural | Expand by filename only  | Fixed 0.5       | No section/topic awareness |

---

## 3. CRITICAL GAPS — DETAILED ANALYSIS

### Gap #1: No Chunking Algorithm (CRITICAL)

The module creates a VS-indexed table from pre-existing rows without any text
processing. The LLM extraction in the PDF pipeline produces clauses of wildly
varying lengths: OCR sections can be 8,000+ characters; individual definitions
can be 40 characters. Both enter the embedding model unchanged.

**Impact:** The embedding model (likely `bge-large-en-v1.5` or equivalent, max
512 tokens ≈ 1,800 chars) silently truncates inputs above ~1,800 characters.
All SECTION units (~1,200 chars avg, many much larger) risk truncation. The
truncated embedding represents only the first portion of the clause — the legally
significant part often appears in the final sentence ("...provided, however, that
the foregoing shall not apply if...").

**Evidence in code:**
```python
WHERE t.content_text IS NOT NULL AND LENGTH(t.content_text) > 20
```
No upper bound. No splitting. Direct passthrough.

---

### Gap #2: AMENDMENT_DELTA Units Never Populated (CRITICAL)

The DDL declares `AMENDMENT_DELTA` as a first-class `unit_type`. The design doc
implies these units should capture "what changed between the amendment and the
base contract clause it supersedes." However, zero rows of this type exist.

**Impact — hallucination risk:**
When a query asks "What is Sutter Health's current inpatient per diem rate?",
retrieval returns:
- Base contract clause: "$4,200/day effective 2019-01-01" (is_current=FALSE)
- Amendment clause: "$4,850/day effective 2023-07-01" (is_current=TRUE)

Without AMENDMENT_DELTA units linking these, the LLM sees both clauses as
independent facts. The is_current flag is present on both rows, but the retrieval
engine does NOT deduplicate superseded base clauses when amendments are found —
the base contract clause will appear in the retrieved context unless the caller
explicitly filters `is_current=TRUE` in the VS query.

**Evidence in code:**
```python
filters = {}
if parsed.temporal_scope == "CURRENT_ONLY":
    filters["is_current"] = "true"  # ← string "true", not boolean
```
The VS filter passes a string `"true"` for a BOOLEAN column — this may silently
fail, returning ALL units regardless of is_current.

---

### Gap #3: Rate Units Are Synthetic Template Strings (HIGH)

RATE_TABLE units are assembled from field values:
```python
concat('Provider: ', rr.provider_name, '\n',
       'Service: ', COALESCE(rr.service_category_raw, rr.service_line), '\n',
       'Domain: ', rr.rate_domain, '\n',
       'Rate: ', COALESCE(rr.rate_text, CAST(rr.rate_numeric AS STRING)), ...
)
```

These are NOT legal prose from the contract. They are database records converted
to key-value strings. Embedding similarity between a user query like
"reimbursement for outpatient physical therapy" and a template string
"Domain: OUTPATIENT / Service: PHYS_THER / Rate: 125.00" will be poor because
embedding models are trained on natural language, not key-value pairs.

**Better approach:** Use the original `full_clause_text` from the V6 extraction
JSON that contains the actual contractual language: "Hospital shall be reimbursed
at $125 per visit for physical therapy services rendered in the outpatient setting."

---

### Gap #4: No Chunk Overlap (HIGH)

Legal clauses frequently cross-reference adjacent text:
- "As defined in Section 4.2 above..."
- "Subject to the conditions set forth in the preceding paragraph..."
- "Notwithstanding anything to the contrary herein..."

Without chunk overlap, a clause containing "as set forth above" retrieves without
the "above" content. The LLM cannot resolve the reference and either hallucinates
the missing context or answers with a low-confidence hedge.

Standard practice: 15–20% overlap (sliding window). For legal text where
cross-references span paragraphs, a parent-chunk retrieval strategy is superior.

---

### Gap #5: Lexical Channel AND Logic Kills Recall (HIGH)

```python
conditions = " AND ".join([
    f"unit_text ILIKE '%{kw}%'" for kw in parsed.keywords[:5]
])
```

A query "what are the termination provisions for non-payment?" extracts keywords:
`["termination", "provisions", "non-payment"]`. The SQL requires ALL three to
appear in a single `unit_text`. A clause titled "Termination for Cause" that
discusses payment defaults but uses the phrase "failure to pay" instead of
"non-payment" is missed entirely.

**Correct approach:** OR conditions with term-frequency scoring, or proper BM25
via Photon-accelerated `LIKE` + `rank_dense()` window function pattern.

---

### Gap #6: Page Citation Permanently NULL (HIGH)

```python
NULL AS page_start,   -- for ALL 83,008 units
```

Legal citations require page and article references. In healthcare contract
disputes, opposing counsel will demand "where in the document does this appear?"
A citation of "source_filename = Providence_2023_Amendment_12.pdf" with no page
number is legally unusable.

**Root cause:** The V1 extraction pipeline (`tbl_contract_terms_vs_ready`) did
not preserve page numbers. The V6 extraction JSON (`json_extract/`) DOES contain
page information but is not used here.

---

### Gap #7: No Deduplication of Base+Amendment Clauses (HIGH)

When Amendment #5 modifies Section 4.3 of the Base Agreement:
- Base Agreement Section 4.3 → unit with `is_current = FALSE` (theoretically)
- Amendment #5 Section 4.3 → unit with `is_current = TRUE`

But the `is_current` flag in `tbl_contract_terms_vs_ready` is set per-document
(latest document flag), not per-clause. If the amendment covers only payment
terms, all non-payment clauses from the base agreement remain in the index
with `is_current = TRUE` as well (they haven't been superseded). There is no
clause-level supersession tracking.

Result: searching for "termination rights" may return 8 versions of the same
base clause from 8 different amendment documents (all marked current), each
slightly differently OCR'd.

---

### Gap #8: Structural Channel Has No Section Awareness (MEDIUM)

```python
WHERE source_filename IN ({file_list})
  AND unit_id NOT IN (...)
LIMIT {top_k}
```

The structural expansion retrieves ANY chunk from the same source PDF — it might
return a rate table when the anchor was a termination clause. True structural
expansion should retrieve:
- Sibling sections under the same article
- The parent section header
- Cross-referenced definitions

None of this is possible without a `parent_unit_id` or `article` field, which
don't exist in the current schema.

---

### Gap #9: Query Entity Extraction Not Implemented (MEDIUM)

```python
return ParsedQuery(
    original=query,
    intent=intent,
    temporal_scope=temporal,
    keywords=keywords
    # entities={}, provider_filter=None, service_filter=None — NEVER SET
)
```

Provider names and service lines are the two most critical retrieval dimensions
for this dataset. A query "What does Blue Cross pay Dignity Health for
knee replacements?" will not extract `provider_filter="Dignity Health"` or
`service_filter="knee replacements"` because the entity extraction block returns
default empty values. The metadata channel then applies no provider filter and
returns random provider results.

---

### Gap #10: No Context Window Budget Before LLM (MEDIUM)

`HybridRetriever.retrieve()` returns up to 30 `ScoredChunk` objects. Each chunk
can be 450 chars average, with SECTION units up to 12,000 chars. At 30 chunks:
- Minimum: 30 × 20 = 600 chars
- Average: 30 × 450 = 13,500 chars
- Maximum: 30 × 12,000 = 360,000 chars (>>200K token window)

There is no budget management between retrieval and LLM prompt assembly. The
calling code in `08_intelligence.py` does not appear to truncate the context
either. This creates unpredictable token overflows that silently truncate the
prompt mid-clause.

---

### Gap #11: Definition Cross-Reference Expansion Absent (MEDIUM)

Contracts define capitalized terms once ("'Hospital' means...") and reference
them throughout. A CLAUSE unit containing "Hospital shall provide Prior
Authorization for all Covered Services" cannot be understood without expanding
"Hospital," "Prior Authorization," and "Covered Services" to their definitions.

No definition lookup or cross-reference expansion exists in the retrieval
pipeline. The LLM will apply general knowledge definitions rather than the
contract-specific ones, introducing hallucination risk.

---

## 4. DIMENSION-BY-DIMENSION ANALYSIS

### 4.1 Legal Unit Definition

**Current:** A "legal unit" is whatever row existed in the V1 extraction tables.
No principled definition of what constitutes a minimum atomic legal unit.

**Problem:** Legal atomicity requires that each unit be self-contained for a
single legal assertion. A SECTION unit like "Article 6: Compensation" may contain
20 sub-clauses covering different payment scenarios — embedding the entire section
produces a diluted embedding that matches nothing specifically.

**Standard:** One unit = one legal proposition. For contracts this means:
- One obligation per CLAUSE unit ("Hospital SHALL provide X")
- One right per CLAUSE unit ("Plan MAY terminate IF Y")
- One definition per DEFINITION unit
- One rate row per RATE_TABLE unit
- One amendment change summary per AMENDMENT_DELTA unit

---

### 4.2 Chunk Granularity Assessment

**Distribution problem:**

```
Too Small (< 100 chars):   ~15% of units — fragments, codes, header lines
Good Range (100-800 chars): ~45% of units — clause-sized; appropriate
Borderline (800-1800 chars): ~25% of units — needs splitting
Too Large (> 1800 chars):   ~15% of units — silently truncated by embedding model
```

Target: 95% of chunks should fall between 200–1,500 characters (embedding-safe).

---

### 4.3 Semantic Density

**Problem:** Three distinct semantic populations share a single VS index:

1. **Legal prose** — high semantic density; embedding works well
   Example: "The parties agree that in the event of a material breach..."

2. **Medical codes** — low semantic density; no prose context
   Example: "DRG 470: Major joint replacement or reattachment of lower extremity"

3. **Synthetic key-value** — no prose; embedding model misapplied
   Example: "Provider: Sutter\nService: INPATIENT\nRate: 4200.00\nFormula: PER_DIEM"

Mixing these three populations in one VS index degrades retrieval precision
because the embedding space is pulled in three incompatible directions. Rate
queries must compete for cosine similarity against legal prose embeddings.

**Fix:** Separate VS indexes per semantic population (legal_prose, rate_data,
medical_codes) with routing logic in the retrieval engine.

---

### 4.4 Context Preservation

**Worst dimension in the system.** Each unit is completely isolated:
- No preceding clause stored as context
- No following clause stored as context
- No parent section header
- No document preamble or recitals context
- No cross-referenced definitions inlined

Legal reasoning requires contextual chains. "Hospital's obligation to notify Plan
within 48 hours" is meaningless without knowing what event triggers notification,
what happens if the deadline is missed, and what "Plan" and "Hospital" mean in
this contract. None of this context survives in the current chunking.

---

### 4.5 Clause Segmentation

The LLM extraction pipeline segments clauses. The quality of those segments is
inherited here with no repair. Known LLM segmentation failure modes:
- Run-on clauses that merge two distinct obligations
- Chopped clauses that split a conditional ("if X... [SPLIT] ...then Y")
- Missing sub-clause context (list items without the list header)
- OCR artifacts embedded mid-clause

No post-processing validation of clause boundaries exists.

---

### 4.6 Definition Handling

**Partial credit:** DEFINITION is a recognized unit_type and definitions are
indexed separately. This is the best-designed aspect of the current chunking.

**Gap:** No cross-reference expansion at retrieval time. When a CLAUSE unit is
returned, the definitions of its capitalized terms are not automatically included
in the context. The LLM must use its own knowledge of these terms.

---

### 4.7 Amendment Delta Handling — Most Critical Failure

The platform processes 6,754 amendments (65% of all documents). The purpose of
amendment analysis — the core business value of this platform — is to understand:
1. What specifically changed (rate, clause, effective date)?
2. What did the old language say?
3. What does the new language say?
4. Which base contract clause was superseded?

NONE of this is captured in the legal units. There is no:
- Delta unit comparing old vs new language
- Supersession link from amendment clause → base clause
- Diff representation ("old: $4,200 → new: $4,850")
- Amendment chain ordering (Amendment 3 supersedes Amendment 1 which supersedes Base)

The `tbl_v2_amendment_registry` has 1,570 amendment records. The
`tbl_retrieval_legal_units` has `is_current` and `effective_date` but no
`supersedes_unit_id` or `amendment_summary` field.

---

### 4.8 Retrieval Chunking Strategy

The current strategy is single-resolution flat retrieval with no fallback.
Optimal for legal contracts is multi-resolution:

| Resolution   | Purpose                                    | Not Implemented? |
|--------------|--------------------------------------------|-----------------|
| Document     | "Does this contract have a force majeure clause?" | ✗ |
| Section      | "What does Article 6 say about compensation?"    | Partial |
| Clause       | "What is the per diem rate for ICU?"              | ✓ (primary) |
| Sub-clause   | "Under what conditions is the rate adjusted?"     | ✗ |
| Span         | "Find the specific sentence about notification"   | ✗ |

Only clause-level retrieval is implemented.

---

### 4.9 Embedding Suitability

**Model:** Unknown (VS endpoint model not specified in code; presumed
`databricks-gte-large-en` or similar, max 512 tokens).

**Issues:**
1. Inputs exceed model max_seq_len for ~15% of units → silently truncated
2. Template key-value strings are out-of-distribution for models trained on prose
3. Medical code descriptions cluster poorly with clinical query text
4. Mixed legal vocabulary (per diem, DRG, capitation, force majeure) with general
   vocabulary (provider, service, rate) creates noisy embedding space

**Fix:** domain-adaptive fine-tuning of embedding model on healthcare contract
text, or at minimum: separate indexes per unit type.

---

### 4.10 Citation Quality

| Citation Field  | Population Rate | Quality |
|-----------------|-----------------|---------|
| source_filename | 100%            | Good — file-level provenance |
| provider_id     | ~95%            | Good |
| provider_name   | ~95%            | Good |
| title           | ~70%            | Clause titles when available |
| section_type    | ~80%            | Topic classification |
| page_start      | **0%**          | CRITICAL — all NULL |
| paragraph_path  | NOT A COLUMN    | Article.Section.Clause path absent |
| amendment_order | NOT A COLUMN    | Cannot cite "Amendment 3, Section 2" |

Legal-grade citation requires: Document → Article → Section → Clause → Page.
Current state provides only: Document (filename).

---

### 4.11 Provenance Preservation

Provenance is split across two tables with no explicit join:
- `tbl_retrieval_legal_units.contract_id` = SHA2(provider_id + filename)
- `tbl_v2_contract_registry.contract_id` = different derivation

These two contract_id columns do not match, breaking the intended FK linkage.
A retrieved chunk cannot be joined back to the contract registry without going
through source_filename as the intermediate key.

---

### 4.12 Hallucination Resistance

**Rating: 1/10 — highest risk dimension.**

Multiple compounding factors create hallucination conditions:

1. **Superseded clauses in index** — old and new rates both present; LLM must
   choose; may blend them
2. **is_current filter fails silently** — string "true" vs boolean TRUE mismatch
   in VS filter
3. **No citation page numbers** — LLM cannot ground responses with "per page 12"
4. **No definition expansion** — LLM applies general medical/legal knowledge
   instead of contract-specific definitions
5. **Template rate strings** — LLM sees "Rate: 4200.00" without legal context
   about when/how the rate applies
6. **No amendment delta context** — LLM cannot distinguish "this was superseded
   by Amendment 7" from "this is still current"
7. **No confidence scoring from extraction** — all units treated as equally
   reliable regardless of OCR quality

---

## 5. RECOMMENDATIONS

### Recommendation 1: Implement Real Chunking Algorithm

**Priority: CRITICAL | Effort: 3 days**

Replace the direct-passthrough INSERT with a proper chunking function that:

```python
def chunk_legal_text(text: str,
                     max_chars: int = 1500,
                     min_chars: int = 150,
                     overlap_chars: int = 200) -> list[str]:
    """
    Split text at semantic boundaries:
    1. Try split on double-newline (paragraph boundary)
    2. Fall back to single-newline + period (sentence boundary)
    3. Fall back to hard split at max_chars
    4. Merge fragments below min_chars with adjacent chunk
    5. Add overlap_chars from preceding chunk as prefix context
    """
```

Apply to unit_type in ['CLAUSE', 'SECTION'] where content_length > max_chars.
Store `chunk_index` (0,1,2...) and `parent_unit_id` for reassembly.

**Expected impact:** Eliminate embedding truncation; improve semantic precision
for SECTION-level queries by ~35% estimated.

---

### Recommendation 2: Hierarchical Chunking (Parent-Child)

**Priority: HIGH | Effort: 2 days**

Implement two-level hierarchy:

```
SECTION (parent chunk — ~2,000 chars, for context)
  └── CLAUSE_1 (child chunk — ~400 chars, for retrieval)
  └── CLAUSE_2 (child chunk — ~400 chars, for retrieval)
  └── CLAUSE_3 (child chunk — ~400 chars, for retrieval)
```

Add to `tbl_retrieval_legal_units`:
- `parent_unit_id STRING` — FK to parent section unit
- `chunk_index INT` — position within parent
- `sibling_count INT` — total siblings under parent

**Schema addition:**
```sql
ALTER TABLE dev_adb.raw.tbl_retrieval_legal_units
  ADD COLUMNS (
    parent_unit_id STRING COMMENT 'Parent section unit for context retrieval',
    chunk_index    INT    COMMENT 'Zero-based position within parent section',
    sibling_count  INT    COMMENT 'Total sibling chunks under same parent'
  );
```

---

### Recommendation 3: Parent-Child Retrieval

**Priority: HIGH | Effort: 1 day**

Once hierarchical chunks exist, implement parent fetch on high-confidence hits:

```python
def retrieve_with_parent_context(chunks: list[ScoredChunk],
                                  threshold: float = 0.85) -> list[ScoredChunk]:
    """
    For chunks scoring above threshold, also retrieve their parent section.
    Prepend parent text as context prefix when building LLM prompt.
    This preserves Article/Section framing without bloating the index.
    """
    high_conf = [c for c in chunks if c.score > threshold and c.parent_unit_id]
    parent_ids = [c.parent_unit_id for c in high_conf]
    parents = spark.sql(f"""
        SELECT * FROM dev_adb.raw.tbl_retrieval_legal_units
        WHERE unit_id IN ({format_in_list(parent_ids)})
    """).collect()
    return merge_parent_context(chunks, parents)
```

---

### Recommendation 4: Context Stitching

**Priority: HIGH | Effort: 2 days**

For chunks with `chunk_index > 0`, retrieve the preceding chunk as a context
prefix. Store pre-computed `prev_unit_id` and `next_unit_id` fields.

```python
# At chunking time:
for i, chunk in enumerate(document_chunks):
    chunk.prev_unit_id = document_chunks[i-1].unit_id if i > 0 else None
    chunk.next_unit_id = document_chunks[i+1].unit_id if i < len-1 else None
```

At retrieval time: when a chunk is returned, optionally fetch `prev_unit_id`
and append to context if the chunk starts with a cross-reference phrase
("as described above", "subject to", "notwithstanding").

---

### Recommendation 5: Multi-Resolution Retrieval

**Priority: HIGH | Effort: 3 days**

Route queries to the appropriate resolution level based on intent:

```python
RESOLUTION_MAP = {
    "RATE_LOOKUP":    "clause",   # Need the exact rate clause
    "CLAUSE_SEARCH":  "clause",   # Need the exact provision
    "COMPARISON":     "clause",   # Need specific clauses to compare
    "TIMELINE":       "section",  # Need broader amendment context
    "GENERAL":        "section",  # Broad context preferred
    "DOCUMENT_CHECK": "document"  # Does the contract contain X?
}
```

Document-level retrieval: embed the first 1,000 chars of each contract's table
of contents + key terms as a separate `DOCUMENT_SUMMARY` unit type.

---

### Recommendation 6: Metadata Enrichment

**Priority: HIGH | Effort: 2 days**

Add missing fields to `tbl_retrieval_legal_units`:

| New Column          | Type    | Purpose |
|--------------------|---------|---------|
| `page_start`       | INT     | Source from V6 JSON extraction |
| `page_end`         | INT     | For multi-page clauses |
| `article_path`     | STRING  | "Article 6 > Section 6.3 > (a)" |
| `parent_unit_id`   | STRING  | FK to parent section chunk |
| `prev_unit_id`     | STRING  | Previous sibling for stitching |
| `next_unit_id`     | STRING  | Next sibling for stitching |
| `supersedes_unit_id` | STRING | For AMENDMENT_DELTA: which unit is superseded |
| `extraction_confidence` | FLOAT | OCR/LLM confidence (0.0-1.0) |
| `cross_refs`       | ARRAY<STRING> | Cited sections/definitions |
| `defined_terms`    | ARRAY<STRING> | Capitalized terms in this unit |

Populate `page_start`/`page_end` by joining to V6 JSON extraction via
`source_filename` — the extraction JSON captures page numbers per clause.

---

### Recommendation 7: Citation Improvements

**Priority: HIGH | Effort: 2 days**

**Step 1:** Backfill `page_start` from V6 JSON extracts stored in
`/Volumes/prod_adb/default/ext-data-volume-stmlz/.../json_extract/*.json`.
These files contain page-level metadata per extracted clause.

**Step 2:** Add `article_path` field populated from the section hierarchy:
```python
article_path = f"Article {article_num} > Section {section_num} > {clause_id}"
```

**Step 3:** Change citation format in retrieval response:
```
CURRENT:  "Providence_Health_Agreement_2023.pdf"
TARGET:   "Providence Health Services Agreement (2023), Article 6 §6.3(a), p. 42"
```

**Step 4:** Populate AMENDMENT_DELTA units with citation to BOTH documents:
```
"Amendment #7 (2023-07-01, p. 3) supersedes Base Agreement Article 6 §6.3(a) (2019-01-01, p. 42)"
```

---

### Recommendation 8: Embedding Improvements

**Priority: HIGH | Effort: 4 days**

**8a: Separate VS indexes by semantic population:**

```
idx_legal_prose_v2     — CLAUSE, SECTION, DEFINITION, CONDITION, AMENDMENT_DELTA
idx_rate_data_v2       — RATE_TABLE (structured natural-language descriptions)
idx_medical_codes_v2   — MEDICAL_CODE (code + description pairs)
```

Route queries based on intent: rate queries → idx_rate_data; clause queries →
idx_legal_prose; code-specific → idx_medical_codes.

**8b: Improve RATE_TABLE unit text:**
Replace template key-value strings with natural language rate descriptions:
```
CURRENT:  "Provider: Sutter
Service: INPATIENT
Rate: 4200.00
Formula: PER_DIEM"
TARGET:   "Sutter Health shall receive a per diem inpatient rate of $4,200 per day
           for acute inpatient services. This rate applies to the INPATIENT domain
           under the general network for all programs."
```

**8c: Add prefix prompts for asymmetric retrieval:**
Query prefix: `"Represent this healthcare contract question for retrieval: "`
Document prefix: `"Represent this legal contract provision: "`
(Required for models like E5-large-v2 that use instruction prefixes.)

**8d: Implement AMENDMENT_DELTA units with diff text:**
```
"Amendment 7 (2023-07-01) changes the inpatient per diem rate for Sutter Health
from $4,200/day (Base Agreement, 2019-01-01) to $4,850/day. The new rate takes
effect for services rendered on or after July 1, 2023."
```
This unit type is the highest-value addition for the platform's core use case.

---

### Recommendation 9: Precision Improvements

**Priority: HIGH | Effort: 3 days**

**9a: Fix the is_current VS filter (immediate, 1 hour):**
```python
# CURRENT (broken for boolean column):
filters["is_current"] = "true"

# FIXED:
filters["is_current"] = True  # or use column filter syntax
```

**9b: Add clause-level deduplication:**
```python
# Hash (provider_id + section_type + title + first_100_chars_of_text) as a
# dedup_key. On re-bootstrap, MERGE on dedup_key rather than blind INSERT.
dedup_key = sha2(concat_ws('|', provider_id, section_type, title,
                            LEFT(content_text, 100)), 256)
```

**9c: Fix contract_id generation to match tbl_v2_contract_registry:**
```python
# CURRENT: sha2(concat_ws('|', provider_id, source_filename), 256)
# FIXED: JOIN to tbl_v2_contract_registry on source_filename to get actual contract_id
```

**9d: Add minimum content quality filter:**
```python
WHERE LENGTH(content_text) > 100   # raise from 20 to 150 chars minimum
  AND content_text NOT RLIKE '^\s*[A-Z]{1,5}\.?\s*$'  # exclude code-only fragments
  AND content_text NOT RLIKE '^Page \d+ of \d+$'        # exclude page headers
```

---

### Recommendation 10: Recall Improvements

**Priority: MEDIUM | Effort: 2 days**

**10a: Fix lexical channel from AND to OR with scoring:**
```python
# CURRENT (AND kills recall):
conditions = " AND ".join([f"unit_text ILIKE '%{kw}%'" for kw in keywords[:5]])

# FIXED (OR with term frequency scoring):
conditions = " OR ".join([f"unit_text ILIKE '%{kw}%'" for kw in keywords])
# Score = COUNT of matching keywords in unit_text, normalized by total keywords
score_expr = " + ".join([
    f"CASE WHEN unit_text ILIKE '%{kw}%' THEN 1.0/{len(keywords)} ELSE 0 END"
    for kw in keywords
])
```

**10b: Implement query expansion with synonym lookup:**
```python
LEGAL_SYNONYMS = {
    "terminate": ["termination", "cancel", "cancellation", "end", "discontinue"],
    "reimburse": ["payment", "pay", "rate", "compensation", "fee"],
    "per diem": ["daily rate", "per day", "daily payment"],
    "capitation": ["pmpm", "per member per month", "capitated"],
    "amendment": ["addendum", "exhibit", "modification", "change order"],
}
```

**10c: Implement provider entity extraction:**
```python
# Query: "What does Providence pay for ICU care?"
# Currently: provider_filter = None (not extracted)
# Fixed: fuzzy match against tbl_v2_contract_registry.provider_name
def extract_provider(query: str) -> Optional[str]:
    from pyspark.sql.functions import levenshtein, lit
    providers = spark.sql("SELECT DISTINCT provider_name FROM dev_adb.raw.tbl_v2_contract_registry")
    # Find closest match above similarity threshold
```

**10d: Process remaining 10K PDFs:**
Only 133/10,372 PDFs have been processed. The retrieval corpus covers ~1.3%
of contracts. Recall is structurally limited until the full corpus is processed.
This is the highest-ROI improvement for recall.

---

### Recommendation 11: Latency Optimizations (Without Quality Loss)

**Priority: MEDIUM | Effort: 2 days**

**11a: Parallelize retrieval channels (immediate):**
```python
from concurrent.futures import ThreadPoolExecutor
with ThreadPoolExecutor(max_workers=3) as pool:
    f_semantic  = pool.submit(retrieve_semantic, parsed, 15)
    f_lexical   = pool.submit(retrieve_lexical, parsed, 10)
    f_metadata  = pool.submit(retrieve_metadata, parsed, 10)
semantic, lexical, metadata = (
    f_semantic.result(), f_lexical.result(), f_metadata.result()
)
# structural depends on semantic anchors — remains sequential
structural = retrieve_structural(parsed, semantic[:5], top_k=5)
```
Expected latency improvement: 55–65% (channels run in ~max(channel_latency)
instead of sum).

**11b: Cache query understanding results (1 hour):**
```python
from functools import lru_cache
@lru_cache(maxsize=1000)
def understand_query_cached(query: str) -> ParsedQuery:
    return understand_query(query)
```
Repeated queries (Genie auto-refreshes, benchmarks) incur zero understanding cost.

**11c: Pre-filter VS index by provider before similarity search:**
For provider-scoped queries, narrow the VS search to ~1,500 units (one provider)
instead of 83,008. Use VS filter on `provider_id` (exact match, indexed).
Expected speedup: 5-10x for provider-scoped queries.

**11d: Add result caching layer for common queries:**
```python
CACHE_TTL_SECONDS = 3600
# Cache key: (query_normalized, provider_id, temporal_scope)
# Skip cache for: historical queries, as-of-date queries
```

**11e: Limit context window pre-LLM:**
Cap total context characters before building LLM prompt:
```python
MAX_CONTEXT_CHARS = 80_000  # ~28K tokens — leaves room for system prompt + response
def budget_context(chunks: list[ScoredChunk], max_chars: int = MAX_CONTEXT_CHARS):
    selected, total = [], 0
    for chunk in sorted_chunks:
        if total + len(chunk.unit_text) > max_chars:
            break
        selected.append(chunk)
        total += len(chunk.unit_text)
    return selected
```
This also prevents the silent prompt truncation issue noted in Gap #10.

---

## 6. IMPLEMENTATION ROADMAP

### Phase 1: Correctness Fixes (1 week, blockers)

| Task | File | Effort | Impact |
|------|------|--------|--------|
| Fix is_current VS filter (string→bool) | 05_retrieval_engine.py | 1h | HIGH |
| Fix lexical AND→OR with scoring | 05_retrieval_engine.py | 2h | HIGH |
| Add content_length upper bound filter | 04_legal_chunking.py | 1h | HIGH |
| Fix contract_id to join registry | 04_legal_chunking.py | 2h | MEDIUM |
| Implement provider entity extraction | 05_retrieval_engine.py | 4h | HIGH |
| Parallelize retrieval channels | 05_retrieval_engine.py | 2h | MEDIUM |
| Add context window budget cap | 08_intelligence.py | 2h | HIGH |

### Phase 2: Chunking Architecture (2 weeks, core)

| Task | File | Effort | Impact |
|------|------|--------|--------|
| Implement chunk_legal_text() splitter | 04_legal_chunking.py | 3d | CRITICAL |
| Add parent_unit_id / prev / next fields | DDL + 04_legal_chunking.py | 2d | HIGH |
| Populate AMENDMENT_DELTA units | 04_legal_chunking.py | 3d | CRITICAL |
| Backfill page_start from V6 JSON | 04_legal_chunking.py | 2d | HIGH |
| Natural-language RATE_TABLE text | 04_legal_chunking.py | 1d | HIGH |
| Deduplication MERGE key | 04_legal_chunking.py | 1d | HIGH |

### Phase 3: Retrieval Quality (2 weeks, quality)

| Task | File | Effort | Impact |
|------|------|--------|--------|
| Separate VS indexes by semantic type | 05_retrieval_engine.py | 3d | HIGH |
| Parent-child retrieval on high-conf | 05_retrieval_engine.py | 2d | HIGH |
| Context stitching (prev/next) | 05_retrieval_engine.py | 2d | HIGH |
| Query expansion with synonym lookup | 05_retrieval_engine.py | 2d | MEDIUM |
| Definition cross-reference expansion | 05_retrieval_engine.py | 3d | HIGH |
| Multi-resolution routing | 05_retrieval_engine.py | 2d | MEDIUM |

### Phase 4: Scale & Polish (1 week)

| Task | Effort | Impact |
|------|--------|--------|
| Process remaining 10K PDFs | 3d | CRITICAL for recall |
| Result caching layer | 1d | MEDIUM |
| Provider entity fuzzy matching | 1d | HIGH |
| Embedding instruction prefixes | 1d | MEDIUM |

---

## 7. QUICK WIN SUMMARY (< 4 hours total, no schema changes)

These fixes can be applied immediately to the existing code:

1. **Fix is_current filter** — change `"true"` to `True` in VS filters
2. **Fix lexical AND → OR** — 2-line change; improves recall dramatically
3. **Parallelize channels** — ThreadPoolExecutor; 60% latency reduction
4. **Add context budget cap** — prevent silent LLM prompt overflow
5. **Raise content_length minimum** — change `> 20` to `> 150`

Combined estimated impact: retrieval recall +40%, hallucination risk -30%,
latency -55%. These should be implemented before the next full corpus run.

---

## 8. SCORING SUMMARY

| Dimension                    | Current | After Phase 1 | After Phase 2 | After Phase 3 |
|-----------------------------|---------|--------------|--------------|--------------|
| Legal Unit Definition        | 3/10    | 3/10         | 7/10         | 8/10 |
| Chunk Granularity            | 2/10    | 3/10         | 8/10         | 8/10 |
| Semantic Density             | 3/10    | 3/10         | 6/10         | 8/10 |
| Context Preservation         | 1/10    | 1/10         | 5/10         | 8/10 |
| Clause Segmentation          | 2/10    | 4/10         | 7/10         | 7/10 |
| Definition Handling          | 5/10    | 5/10         | 5/10         | 9/10 |
| Amendment Delta Handling     | 0/10    | 0/10         | 8/10         | 9/10 |
| Retrieval Chunking Strategy  | 3/10    | 4/10         | 7/10         | 9/10 |
| Embedding Suitability        | 2/10    | 2/10         | 6/10         | 8/10 |
| Citation Quality             | 1/10    | 1/10         | 7/10         | 8/10 |
| Provenance Preservation      | 3/10    | 3/10         | 8/10         | 8/10 |
| Hallucination Resistance     | 1/10    | 4/10         | 7/10         | 9/10 |
| **OVERALL**                  | **2.2** | **3.1**      | **6.8**      | **8.4** |

---

*Generated by BSC Platform Review Pipeline — Prompt 6: Legal Chunking + Vector Review*
