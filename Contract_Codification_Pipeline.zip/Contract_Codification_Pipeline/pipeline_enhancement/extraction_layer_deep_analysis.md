# Deep Extraction Layer Analysis — Enterprise Architecture Critique

**Author**: Principal Architecture Review  
**Date**: May 2026  
**Scope**: `04_llm_prompts` → `05_llm_extraction` → `06_validation` → `07_consolidation` → `08_build_rates` → `09_build_terms` → `10_build_documents`

---

## FUNDAMENTAL ARCHITECTURE CLASSIFICATION

This pipeline implements **Architecture A: Structured Extraction-First**:

```
PDF → OCR → LLM (structured JSON) → Normalized Tables → Intelligence
```

NOT Architecture B (Retrieval-First: PDF → Chunks → Embeddings → Runtime Reasoning)

---

## MODULE-BY-MODULE CRITIQUE

### 04_llm_prompts

| Dimension | Assessment |
|-----------|------------|
| **Responsibility** | Define 4 document-type-specific extraction prompts + JSON schema + routing logic |
| **Architectural role** | Contract between raw text and structured output; defines the extraction ontology |
| **Inputs** | None (pure definitions); receives `JSON_SCHEMA` from `_config` |
| **Outputs** | `EXTRACTION_PROMPT`, `AMENDMENT_PROMPT`, `COVER_MEMO_PROMPT`, `SETTLEMENT_PROMPT`, `_get_prompt_category()` |
| **Downstream** | `05_llm_extraction` (direct), everything downstream (transitive via schema) |
| **Truly depended on?** | YES — the JSON schema here is the single most important design decision in the pipeline |
| **Business value** | CRITICAL — prompt quality directly determines extraction quality |
| **Duplicates later?** | No — but schema IS duplicated in `tbl_reimb_rate_rules.formula_json` construction |
| **Belongs here?** | YES |
| **Should exist?** | YES — this is the extraction contract |

**Verdict: Mission Critical. The schema IS the product.**

**Key design insight**: The schema includes `rate_numeric`, `effective_date`, `program`, `network`, `exhibit_reference` on EVERY rate row — this is the "Delta-Ready" innovation that eliminates post-processing ambiguity. The `full_clause_text` requirement (verbatim legal copy) eliminates the need for re-reading PDFs at retrieval time.

**Prompt Architecture Details**:
- Base Agreement prompt: ~3,500 tokens of instructions + full JSON_SCHEMA. Covers 10 extraction categories (inpatient rates, outpatient rates, regional factors, exception provisions, capitation, HAC/never events, chargemaster, stop-loss, amendments_impact, settlement_terms).
- Amendment prompt: Adds `amendments_impact` emphasis (exhibits_replaced, prior_rates_superseded, rate_categories_modified).
- Cover Memo prompt: Focuses on rate escalation tables, model contract versions, exhibit version numbers.
- Settlement prompt: Emphasizes settlement_amount, arbitration references, release scope.
- Routing logic (`_get_prompt_category`): Simple string matching on document_type field — settlements > cover memos > amendments > base.

**Weakness**: The schema is ~3,500 tokens, repeated 4 times across prompts. A single parameterized template with document-type-specific instructions appended would be cleaner and reduce maintenance surface.

---

### 05_llm_extraction

| Dimension | Assessment |
|-----------|------------|
| **Responsibility** | REST API engine: adaptive concurrency, chunking, retry, JSON repair |
| **Architectural role** | The production workhorse — converts OCR text into structured JSON |
| **Inputs** | `step2_with_metadata.parquet` (text + provider metadata), prompts from 04 |
| **Outputs** | `json_extract/*.json` — one structured JSON per PDF |
| **Downstream** | EVERYTHING. Every table, every intelligence layer, every serving endpoint |
| **Truly depended on?** | YES — this is the single irreplaceable module |
| **Business value** | CRITICAL — without this, no structured data exists |
| **Duplicates later?** | No |
| **Belongs here?** | YES |
| **Should exist?** | YES — this is the core IP of the platform |

**Verdict: Mission Critical. The canonical source of truth.**

**Engineering Details**:
- 3-worker ThreadPoolExecutor (matches serving endpoint concurrency limits)
- 80K-char chunking with 2K overlap for files >150K chars
- `_repair_truncated_json()` for max_tokens (65,536) cutoff — closes open brackets/braces
- 30s retry backoff with 1 retry per file
- Per-file HTTP timeout: 1800s (30 min) — prevents cascade failures
- Progress tracking via `_progress.json` file
- Checkpoint-resumable: skips files already in `json_extract/`
- Adaptive concurrency class (ramps down on rate limits)
- Score cache for re-extraction decisions

**Performance**: 133 files in 93 minutes (42s avg/file). This includes:
- Input: ~46K tokens average (PDF text + prompt)
- Output: ~48K tokens average (full JSON extraction)
- Total per file: ~90K tokens (45% of 200K context window)

**Weakness**: Sequential dependency on OCR quality. If pypdf fails and ai_parse_document is unavailable, the file is lost. No fallback extraction strategy (e.g., simpler schema for degraded text). Also: no streaming — entire response buffered before parsing.

---

### 06_validation

| Dimension | Assessment |
|-----------|------------|
| **Responsibility** | Post-extraction enrichment: medical code regex, date/rate verification, rate_numeric gap-fill, coverage scoring, content classification |
| **Architectural role** | Quality gate + in-place enrichment of JSON files |
| **Inputs** | `json_extract/*.json` |
| **Outputs** | Same JSON files, enriched with `validation{}` key containing: medical_codes[], unverified_dates[], rate_numeric fixes, v6_coverage_pct, content_bucket, document_subtype |
| **Downstream** | `09_build_terms` (medical_codes → tbl_contract_codes_events), `10_build_documents` (v6_coverage_pct), quality reports |
| **Truly depended on?** | PARTIALLY — medical codes are consumed by `09_build_terms`. Coverage scores go into documents_master. But rate verification is purely informational. |
| **Business value** | MEDIUM — the rate_numeric gap-fill (63%→95%) is genuinely valuable. Medical code regex adds ~2,500 codes the LLM missed. Date/rate verification flags hallucinations. |
| **Duplicates later?** | The `rate_numeric` parsing duplicates what the LLM should have done. Medical code regex duplicates what the LLM should extract. This is compensatory engineering. |
| **Belongs here?** | YES as a quality gate; the rate_numeric post-fill is a necessary band-aid |
| **Should exist?** | YES — but should be SMALLER. Verification flags are nice-to-have; rate_numeric fill and medical codes are essential. |

**Verdict: Valuable, but 60% of it is compensating for LLM extraction gaps.**

**Key Functions**:
- `_parse_rate_to_numeric()`: Handles "$5,748" → 5748.00, "88.9%" → 88.9, "varies" → None
- `verify_rate_in_text()`: OCR-aware fuzzy matching (comma/period confusion, whitespace in numbers, decimal precision)
- Medical code regex: CPT (`\d{5}`), HCPCS (`[A-Z]\d{4}`), ICD (`[A-Z]\d{2}\.?\d*`), Revenue (`0\d{3}`)
- Delta-readiness checks: rate_numeric presence, full_clause_text presence, amendments_impact presence
- Content bucket classification: base_agreement / amendment / cover_memo / settlement / stub
- V6 coverage scoring: doc-type-specific weighting of schema completeness

**Production gate**: Skips rebuild if `NEW_FILES_FOUND=False` — saves ~45 min on no-op scheduled runs.

**Checkpoint-aware**: Skips files already enriched with schema version 'v6.2b'.

The OCR-aware rate verification (`verify_rate_in_text`) with fuzzy matching across comma/period confusion, whitespace variants, and decimal precision — this is genuinely clever engineering. But it's engineering that exists because the LLM sometimes hallucinates rates. In a retrieval-first architecture, you'd verify at query time against the source chunk.

---

### 07_consolidation

| Dimension | Assessment |
|-----------|------------|
| **Responsibility** | Merge per-file JSONs into per-provider consolidated records; version dedup, amendment chain ordering, rate supersession tracking, doc role classification |
| **Architectural role** | Provider-level entity assembly — the step that turns documents into contracts |
| **Inputs** | `json_extract/*.json` (133+ files) |
| **Outputs** | `json_consolidated/*.json` (one per provider: document_timeline, rate_timeline, contract_summary) |
| **Downstream** | `08_build_rates` (for rate_timeline/supersession status), `10_build_documents` (for amendment_order lookup) |
| **Truly depended on?** | PARTIALLY — amendment_order is critical for supersession. But rate_timeline is only used to set `status='current'` vs `status='superseded'`. |
| **Business value** | MEDIUM-HIGH — the amendment ordering logic (ordinal word parsing, doc role classification) solves a genuine business problem: which rates are current? |
| **Duplicates later?** | YES — duplicates `platform/02_state_engine.py` which builds `tbl_v2_contract_registry` and `tbl_v2_amendment_registry` from the SAME source data. Two independent implementations of "which document supersedes which." |
| **Belongs here?** | ARCHITECTURALLY QUESTIONABLE — this is state-engine logic embedded in the extraction pipeline |
| **Should exist?** | YES for amendment_order derivation. NO as a separate consolidated JSON layer — the same logic should live in the state engine or be computed at table-build time. |

**Verdict: Valuable logic, wrong location. This IS the state engine — just implemented 5 steps earlier.**

**Key Logic**:
- Version dedup: Group by (provider_id, contract_id, doc_type, effective_date), keep highest version number
- Amendment ordering: Ordinal word parsing ("first" → 1, "second" → 2, ... "twentieth" → 20). Settlements = 900, Letters = 800.
- Doc role classification: base_agreement / amendment / cover_memo / settlement / letter_of_agreement / mutual_agreement / other
- Rate supersession: Within each provider, rates from highest-order amendment = current; earlier = superseded
- Per-provider consolidated JSON includes: document_timeline (ordered docs), rate_timeline (all rates with status), contract_summary (metadata)

**The core problem**: `json_consolidated/*.json` is an intermediate artifact that creates semantic debt. It establishes a provider-level entity model that is LATER re-derived by `platform/02_state_engine`. The consolidation should either BE the state engine, or the state engine should replace it entirely.

---

### 08_build_rates

| Dimension | Assessment |
|-----------|------------|
| **Responsibility** | JSON → 3 Delta tables: `tbl_contract_rates_all` (all rates), `tbl_contract_regional_factors` (county multipliers), `tbl_contract_financial_protections` (stop-loss/outlier) |
| **Architectural role** | Primary materialization of rate data from JSON into queryable schema |
| **Inputs** | `json_extract/*.json`, `json_consolidated/*.json` (for supersession) |
| **Outputs** | 3 tables, ~68K rate rows + 2K regional factors + 1.5K financial protections |
| **Downstream** | `12_build_genie` (serves Genie Space), `platform/03_reimbursement_migration` (creates V2 rate_rules), `11_enrich_tables` (adds program_normalized) |
| **Truly depended on?** | YES — `tbl_contract_rates_all` is the most-consumed table in the platform |
| **Business value** | CRITICAL — rates ARE the business. This table directly answers "what do we pay?" |
| **Duplicates later?** | YES — `platform/03_reimbursement_migration` creates `tbl_reimb_rate_rules` which is the same data re-schematized with formula_json. Then `platform/04_legal_chunking` re-textualizes it into `tbl_retrieval_legal_units`. The same rate lives in 4 representations. |
| **Belongs here?** | YES — this is the correct architectural location |
| **Should exist?** | YES — but should be the ONLY rate table, not one of four |

**Verdict: Mission Critical. But downstream creates 3 redundant copies of the same data.**

**Table Schemas**:

`tbl_contract_rates_all` (~68K rows):
- provider_id, provider_name, source_filename, document_type
- rate_category (inpatient_per_diem, outpatient_surgical, capitation, etc.)
- service_category (Med/Surg, ICU/CCU, NICU Level I-IV, etc.)
- rate_text, rate_numeric, rate_type_detail
- formula, revenue_codes, notes
- effective_date_parsed, program, network, program_normalized
- status (current/superseded), is_latest_version, amendment_order
- is_valid_rate (flag for negative/zero rates)

`tbl_contract_financial_protections` (~1.5K rows):
- protection_type (stop_loss, outlier, corridor)
- threshold_numeric, reimbursement_pct_numeric
- aggregate_cap, corridor
- has_stop_loss_bool, revenue_codes, exhibit_reference

`tbl_contract_regional_factors` (~2K rows):
- county, factor, effective_date_parsed

**Post-processing (11a-fix)**:
- Rate status supersession via amendment_order (PARTITION BY provider ORDER BY amendment_order DESC)
- Program/network NULL defaults (Commercial / All Networks)
- Program normalization (148 raw variants → 8 canonical buckets)
- Rate category normalization (merge plural variants)
- Empty placeholder removal
- Zero-current safety net (every provider gets ≥1 current rate)
- is_valid_rate flag (FALSE for negative/zero)

**V8 fix** (expanded outpatient extraction: cap_amount, conversion_factor, formula) recovered +170 formula/cap rates across 39 providers.

---

### 09_build_terms

| Dimension | Assessment |
|-----------|------------|
| **Responsibility** | JSON → 4 Delta tables: `tbl_contract_clauses_terms` (clauses + sections + definitions), `tbl_contract_codes_events` (CPT/HCPCS/ICD/Revenue + HAC/Never Events), `tbl_contract_parties` (payer/provider/signatories), `tbl_contract_services_quality` (DOFR/quality/credentialing) |
| **Architectural role** | Non-rate structured data materialization |
| **Inputs** | `json_extract/*.json` (reads directly — no table dependency) |
| **Outputs** | 4 tables |
| **Downstream** | `tbl_contract_clauses_terms` → `tbl_contract_terms_vs_ready` → `platform/04_legal_chunking` (becomes 69K legal units for RAG). `tbl_contract_parties` → `tbl_genie_provider_profile`. Others → Genie queries. |
| **Truly depended on?** | YES for clauses (feeds retrieval). PARTIALLY for codes (consumed by `tbl_contract_codes_events` but never joined against claims). NO for parties (informational only — provider identity lives in `dim_provider_canonical`). |
| **Business value** | MEDIUM — clauses are the most valuable output (enables contract Q&A). Codes are forensic. Parties are decorative. Services/quality are rarely queried. |
| **Duplicates later?** | Clauses duplicate into `tbl_retrieval_legal_units` (re-chunked). Parties duplicate `dim_provider_canonical` semantics. |
| **Belongs here?** | YES for clauses and codes. QUESTIONABLE for parties (should be part of entity resolution). |
| **Should exist?** | YES — but `tbl_contract_services_quality` and `tbl_contract_parties` could merge into documents_master as JSON columns. |

**Verdict: Valuable for clauses. Decorative for parties/services.**

**Table Details**:

`tbl_contract_clauses_terms` (~15K rows):
- content_type: clause | section | definition
- topic: termination, dispute_resolution, confidentiality, etc.
- content_text: verbatim clause text (up to 5,000 chars)
- effective_date, source_filename
- Sources: clause_sections (6 legal sections with full_clause_text), sections[] (table of contents), key_definitions{} (term→definition dict)

`tbl_contract_codes_events` (~3K rows):
- content_type: medical_code | hac | never_event
- code_value: CPT/HCPCS/ICD/Revenue code string
- condition_name, adjustment_rule (for HAC/Never Events)
- Sources: validation.medical_codes[] (regex-extracted), hac_never_events.hac_list[], .never_events[]

`tbl_contract_parties` (~1K rows):
- party_role: health_plan | provider | signatory
- party_name, party_dba, party_type, npi, tax_id
- Sources: extracted_content.parties{}, .signatories[]

`tbl_contract_services_quality` (~2K rows):
- category: covered_service | quality_metric | credentialing | delegated_activity
- service_name, description, metric_target, metric_threshold
- Sources: covered_services[], quality_and_performance{}, delegated_activities[]

---

### 10_build_documents

| Dimension | Assessment |
|-----------|------------|
| **Responsibility** | JSON → 2 tables: `tbl_contract_documents_master` (74-column document spine), `dim_provider_canonical` (identity resolution: 456 IDs → 278 facilities) |
| **Architectural role** | Document registry + provider entity resolution |
| **Inputs** | `json_extract/*.json`, `json_consolidated/*.json` (for amendment_order) |
| **Outputs** | 2 tables |
| **Downstream** | `dim_provider_canonical` is consumed by EVERYTHING (12_build_genie, platform/02, platform/08-10). `tbl_contract_documents_master` is consumed by `08_build_rates` (for supersession), `12_build_genie` (for timeline). |
| **Truly depended on?** | YES — `dim_provider_canonical` is the most critical dimension table. `tbl_contract_documents_master` is the document spine. |
| **Business value** | HIGH — identity resolution (many-to-one provider mapping) directly fixes data quality. The 74-column spine enables any downstream aggregation. |
| **Duplicates later?** | `dim_provider_canonical` is partially duplicated by `tbl_genie_provider_profile` (pre-aggregated). Document spine overlaps with `tbl_v2_contract_registry` (different schema, similar entity). |
| **Belongs here?** | YES — correct location |
| **Should exist?** | YES |

**Verdict: Valuable. Identity resolution is genuine IP.**

**Identity Resolution Logic** (dim_provider_canonical):
1. For each provider_id, pick the most recent name (latest amendment_order) = `canonical_name`
2. Group all IDs sharing the same canonical_name into one "facility"
3. Rank IDs within facility by doc_count (most active = `primary_provider_id`)
4. Result: 456 provider_ids → 278 canonical facilities
- Handles: 89 cases of same name → multiple IDs, 50 cases of same ID → multiple names
- Output columns: provider_id, canonical_name, primary_provider_id, is_primary_id, rank_in_facility, ids_in_facility, facility_total_docs, facility_total_rates, all_names_used (array)

**Documents Master** (74 columns):
- file_metadata block: provider_id, source_filename, document_type, amendment_order, content_bucket, v6_coverage_pct, rate_count
- contract_overview block: agreement_type, payment_type, auto_renewal, term_years, service_area, hospital_type, network_participation
- financial_terms block: withhold_percentage, withhold_amount, risk_sharing, interest_on_late
- operational block: delegated_activities, service_area, credentialing_requirements
- amendments_impact block: exhibits_replaced_count, sections_modified_count, rate_count, prior_rates_superseded, summary_of_changes
- parsed dates: effective_date_parsed, expiration_date_parsed (with flexible format parsing)
- computed: amendment_depth (max order within provider), doc_category

---

## OUTPUT CLASSIFICATION

### Foundational (everything downstream breaks without these):
- `json_extract/*.json` — canonical source of truth
- `tbl_contract_rates_all` — rates serving + intelligence
- `tbl_contract_clauses_terms` → feeds retrieval legal units
- `tbl_contract_documents_master` — document spine
- `dim_provider_canonical` — identity resolution
- `validation.medical_codes[]` — feeds codes table
- `amendment_order` derivation — feeds supersession

### Decorative (exist for completeness, rarely queried):
- `tbl_contract_parties` — payer is always BSC, provider is in dim_canonical
- `tbl_contract_services_quality` — DOFR is interesting but never consumed by intelligence
- `tbl_contract_regional_factors` — 2K rows, never joined against claims
- `json_consolidated/*.json` — intermediate artifact that should be ephemeral

### Never meaningfully consumed:
- `validation.unverified_dates[]` — logged but never acted upon
- `validation.unverified_rates[]` — logged but never triggers re-extraction
- `v6_coverage_pct` — quality metric stored but never gated on
- `content_bucket` / `document_subtype` — classification stored, never filtered by downstream

### Should be retrieval-time inference (not pre-extracted):
- `full_clause_text` verbatim copy — could be served from VS index at query time
- `sections[].content_summary` — LLM can summarize at query time with better context
- `key_definitions{}` — retrieval-time extraction would be more accurate and always current
- `covered_services` — better as searchable text than rigid array
- Quality/credentialing details — rarely queried, expensive to extract

### Should live in the state engine instead:
- `amendment_order` derivation (07_consolidation) — IS state logic
- `rate.status` = 'current'/'superseded' — IS temporal state
- `is_latest_version` flag — IS state computation
- `prior_rates_superseded` tracking — IS amendment graph logic

---

## WHERE BUSINESS SEMANTICS ARE DUPLICATED

| Semantic Concept | First Implementation | Second Implementation | Third |
|-----------------|---------------------|----------------------|-------|
| "Which rates are current?" | 07_consolidation (amendment_order ranking) | 08_build_rates 11a-fix (PARTITION BY provider ORDER BY amendment_order DESC) | platform/02_state_engine (tbl_v2_contract_registry.status) |
| "Which provider is this?" | file_metadata.provider_id | dim_provider_canonical.primary_provider_id | tbl_genie_provider_profile.provider_id |
| "What is this rate worth?" | rate_text (string) + rate_numeric (float) | tbl_reimb_rate_rules.formula_json (expression tree) | tbl_retrieval_legal_units.unit_text (re-textualized) |
| "What document type is this?" | file_metadata.document_type | 07_consolidation.classify_doc_role() | tbl_v2_amendment_registry.document_type |
| "What service line?" | rate_category (raw) + service_category (raw) | dim_service_line_taxonomy (normalized) | tbl_reimb_rate_rules.service_line (mapped) |

### Where Legal Semantics Are Modeled Twice:

1. **Termination provisions**: Extracted as `full_clause_text` in `tbl_contract_clauses_terms` (structured) AND embedded in `tbl_retrieval_legal_units` (vector). Same text, two storage mechanisms, two access patterns.

2. **Stop-loss thresholds**: Exist in `tbl_contract_financial_protections` (V1 flat) AND `tbl_reimb_stop_loss` (V2 typed with attachment_level, reimburse_formula_type). Same business fact, two schemas.

3. **Amendment impact**: Captured in `json_consolidated` (rate_timeline with superseded flag) AND `tbl_v2_amendment_registry` (scope_type classification). Same document relationship, two representations.

4. **Rate applicability**: Stored as (program, network, revenue_codes) in `tbl_contract_rates_all` AND as (program, network, revenue_codes, procedure_codes, drg_codes) in `tbl_reimb_rate_rules`. Same applicability semantics, different column granularity.

---

## ARCHITECTURE A vs B: WHICH IS CORRECT HERE?

### The Case for Structured Extraction-First (Current Architecture):

**Healthcare contracts are TABULAR, not narrative.** Rate schedules are tables with 10-100 rows of `(service, rate, codes, program, network)`. These are not "unstructured text" — they are structured data trapped in PDF formatting. Extraction-first is correct because:

1. **Rates require computation**: You can't compute percentile benchmarks, savings opportunities, or scenario projections from embeddings. You need `rate_numeric` in a column.
2. **Temporal state is relational**: "Which rate is current?" requires amendment ordering and supersession logic — a graph/state problem, not a similarity problem.
3. **Regulatory compliance demands precision**: A health plan cannot cite "the embedding said the rate is approximately $5,748." They need the exact number with provenance.
4. **Portfolio analytics require aggregation**: "What's our average inpatient per diem across 348 providers?" requires SQL, not retrieval.

### The Case for Retrieval-First (What's Missing):

**Legal clauses are narrative, not tabular.** Termination provisions, dispute resolution, confidentiality language — these are best served by chunking + semantic search because:

1. **Questions are open-ended**: "What are the termination rights?" doesn't map to a column.
2. **Context matters**: A clause's meaning depends on surrounding clauses, defined terms, and exhibit cross-references.
3. **Verbatim citation is required**: The `full_clause_text` extraction approach (copy entire clause) is the platform's acknowledgment that retrieval-time access to source text is needed.

### The Correct Architecture: HYBRID

```
    STRUCTURED (rates, dates, parties, codes)
        ├── Extraction-First: PDF → JSON → Tables → SQL Analytics
        └── This is CORRECT and should remain

    NARRATIVE (clauses, provisions, legal language)
        ├── Retrieval-First: PDF → Chunks → Embeddings → Runtime Reasoning
        └── This should REPLACE full_clause_text extraction

    TEMPORAL (amendments, supersession, state)
        ├── Graph/State-First: Documents → Amendment Graph → Point-in-Time Query
        └── This should REPLACE the 3 independent implementations
```

### What Enterprise Systems Actually Do:

| System Category | Architecture | Examples |
|----------------|-------------|----------|
| Claims adjudication | Structured extraction + rules engine | Cotiviti, Optum, Change Healthcare |
| Contract management | Document DB + metadata + search | Icertis, Agiloft, ContractPodAi |
| Legal research | Retrieval-first + citation | Westlaw, LexisNexis, Harvey AI |
| Provider network analytics | Relational + OLAP | Clarify Health, Milliman |

The correct model for THIS platform is **Icertis + Clarify Health**: structured extraction for rates/financials (table-driven analytics) + document retrieval for legal language (search-driven Q&A) + temporal state for amendment lineage.

---

## WHAT SHOULD REMAIN STRUCTURED
- ALL rate data (per diem, case rate, percentage, capitation PMPM)
- ALL financial protections (stop-loss thresholds, carve-out rules)
- ALL dates (effective, expiration, execution)
- Provider identity (canonical resolution)
- Amendment ordering and supersession
- Medical/revenue codes

## WHAT SHOULD BECOME RETRIEVAL-DRIVEN
- `full_clause_text` — serve from VS index at query time
- `sections[].content_summary` — generate at query time
- `key_definitions{}` — extract on demand from relevant chunks
- `covered_services` — better as searchable text than rigid array
- Quality/credentialing details — rarely queried, expensive to extract

## WHAT SHOULD BECOME GRAPH/STATE-DRIVEN
- Amendment supersession (currently computed 3 times independently)
- Rate currency (current vs historical)
- Contract lifecycle (active/expired/terminated)
- Document lineage (which doc modifies which)

---

## COST ANALYSIS

| Component | Per-File Cost | Full Corpus (10,372) | Value Generated |
|-----------|--------------|---------------------|----------------|
| OCR (pypdf) | $0.00 | $0 | Text extraction |
| OCR (ai_parse_document) | ~$0.05 | ~$519 | Scanned PDF fallback |
| LLM Extraction (full schema) | ~$0.36 | ~$3,734 | Structured data |
| LLM Extraction (rates only) | ~$0.12 | ~$1,245 | Just the valuable parts |
| Clause extraction overhead | ~$0.10 | ~$1,037 | full_clause_text (could be retrieval) |
| Sections/definitions overhead | ~$0.08 | ~$830 | content_summary (could be runtime) |
| Quality audit (optional) | ~$0.36 | ~$3,734 | Gap detection |

**Observation**: ~30% of extraction cost ($0.10-0.18/file) goes to extracting narrative content (clauses, sections, definitions) that could be served via retrieval at query time. For the full 10K corpus, this is ~$1,200-$1,800 that could be eliminated by adopting hybrid architecture.

---

## FINAL ASSESSMENT: THE EXTRACTION LAYER

**The extraction layer (04-10) is the BEST part of this platform.** It is:
- Pragmatic (reads JSON directly, no circular dependencies)
- Battle-tested (V8 fixes, OCR-aware matching, JSON repair)
- Production-hardened (checkpoints, retry, concurrency control)
- Well-separated (each module has clear responsibility)

**Its primary failure is architectural**: it implements state-engine logic (supersession, amendment ordering) that is later reimplemented in `platform/02`. This creates two independent truth sources for "which rates are current" that can diverge.

**Its secondary failure is over-extraction**: it extracts things like `full_clause_text`, `key_definitions`, `covered_services`, and `parties` into structured fields when these should be retrieval-time operations. This extraction costs ~$0.36/file × 10,372 files = ~$3,700 — and the clause text is then ALSO chunked into embeddings for retrieval. Double payment for the same content.

---

## RECOMMENDATIONS

1. **Keep exactly as-is**: 04_llm_prompts, 05_llm_extraction, 08_build_rates
2. **Slim down**: 06_validation → just rate_numeric gap-fill + medical code regex (remove verification flags nobody consumes)
3. **Merge into state engine**: 07_consolidation's amendment ordering logic → should be the authoritative implementation in platform/02, not a separate upstream step
4. **Convert to retrieval-only**: 09_build_terms clause extraction → skip full_clause_text extraction, let legal units come directly from OCR text chunks at indexing time
5. **Keep**: 10_build_documents identity resolution (dim_provider_canonical is genuine IP)
6. **Eliminate downstream duplication**: `tbl_reimb_rate_rules` should be a VIEW over `tbl_contract_rates_all` with formula_type classification, not a separate table
7. **Single supersession authority**: Pick ONE place where `status='current'` is determined. Either 07_consolidation OR platform/02_state_engine. Not both.