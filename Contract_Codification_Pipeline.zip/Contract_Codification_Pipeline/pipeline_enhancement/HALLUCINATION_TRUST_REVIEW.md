# HALLUCINATION & TRUST REVIEW — COMPLETE ANALYSIS
## BSC Provider Contract Intelligence Platform

**Date:** 2026-05-28  
**Scope:** End-to-end hallucination risk assessment across extraction, retrieval, generation, and serving  
**Legal context:** Healthcare provider contracts are legally binding. A hallucinated rate, date, or provision creates direct financial liability.

---

## EXECUTIVE SUMMARY

The platform has **no operational hallucination detection or prevention system**. The citation verification framework exists only as a design document. The extraction pipeline has 3 anti-hallucination rules in its prompts but no post-extraction verification. The retrieval engine has no grounding checks, no confidence scoring, and no "I don't know" pathway.

**Hallucination risk by pipeline stage:**

| Stage | Risk Level | Hallucination Type | Detection Mechanism |
| --- | --- | --- | --- |
| PDF OCR (Step 1) | MEDIUM | Character substitution ($l,500 for $1,500) | NONE |
| LLM Extraction (Step 3) | HIGH | Fabricated rates, inferred dates, scope confusion | 3 prompt rules only |
| Legal Unit Bootstrap (Step 4) | MEDIUM | Hardcoded `is_current=TRUE` on all rate rules | NONE |
| Retrieval (Step 5) | HIGH | Scope leakage, stale results, wrong provider | NONE |
| Answer Generation (Genie) | CRITICAL | Uncited claims, numerical distortion, conditional drop | NONE |
| Intelligence Layer (Step 8) | LOW | Benchmarks from real data; no LLM involved | N/A (deterministic SQL) |

**Overall trust rating: 2/10.** The system can produce correct answers but has no mechanism to verify, signal confidence, or prevent hallucination from reaching the user.

---

## PART 1: HALLUCINATION RISK TAXONOMY

### 1.1 Extraction-Stage Hallucination

These hallucinations enter the system at data creation time and propagate to all downstream consumers.

#### A. Numerical Hallucination

**Risk:** LLM fabricates or distorts dollar amounts during extraction.

**Evidence of existing risk:**
- Validation report shows 63% rate_numeric population — the other 37% may contain rates that the LLM failed to parse or silently "corrected"
- 36 unverified dates flagged in validation (possible hallucinations from extraction)
- OCR artifacts (e.g., `$l,500` where L looks like 1) can be "corrected" by the LLM into plausible but wrong values

**Specific failure modes:**

| Scenario | Probability | Severity | Example |
| --- | --- | --- | --- |
| OCR garble → LLM "fixes" to wrong number | MEDIUM | CRITICAL | `$l,S00` → model writes `$1,500` when actual is `$1,800` |
| Rate range → single value | HIGH | HIGH | "$1,500-$2,000" → model picks $1,500 for rate_numeric |
| Annual vs monthly confusion | MEDIUM | CRITICAL | "$18,000/year" → model writes rate_numeric=18000 (correct) or rate_numeric=1500 (monthly) |
| Percentage vs decimal | LOW | HIGH | "88.9%" → model writes 88.9 or 0.889 inconsistently |
| Multi-year rates → wrong year assignment | MEDIUM | HIGH | Year 2 rate assigned to Year 1 effective_date |
| Capitation PMPM rates misattributed to wrong aid category | MEDIUM | HIGH | Aged rate assigned to Disabled category |

**Current mitigation:** 3 CRITICAL rules in extraction prompts ("Extract ONLY dates explicitly written", etc.)

**Gap:** No post-extraction numerical verification. No check that extracted rate_numeric matches rate_text. No check that amounts are within reasonable ranges for healthcare contracts.

#### B. Date Hallucination

**Risk:** LLM infers dates from contextual clues rather than extracting explicitly stated dates.

**Evidence:** 36 unverified dates in 133-file validation. Prompt says "extract ONLY dates explicitly written" but model may still infer.

**Specific failure modes:**

| Scenario | Probability | Severity |
| --- | --- | --- |
| Effective date inferred from "beginning of contract year" | HIGH | HIGH |
| Expiration date calculated from "3-year term" | MEDIUM | CRITICAL |
| Amendment effective date confused with execution date | HIGH | HIGH |
| "Effective upon regulatory approval" → model invents date | LOW | CRITICAL |
| Date in wrong format (OCR: "01/02/2024" → Jan 2 vs Feb 1) | MEDIUM | HIGH |

#### C. Provider Name Hallucination

**Risk:** LLM substitutes parent company name, abbreviates incorrectly, or conflates entities.

**Evidence:** Extraction prompt has explicit rule ("Extract ONLY the entity name as written") but no verification.

**Specific failure modes:**
- "CommonSpirit Health" used when contract says "Dignity Health" (parent co substitution)
- "St. Joseph" vs "Saint Joseph" vs "St Joseph Medical Center" (normalization inconsistency)
- Multi-entity contracts: model picks wrong party as "the provider"

#### D. Classification Hallucination

**Risk:** LLM assigns wrong document type, payment type, or agreement type during extraction.

**Evidence:** `_get_prompt_category()` routes based on filename patterns, but document content may not match filename conventions.

**Specific failure modes:**
- Amendment misclassified as base agreement → rates treated as canonical instead of superseding
- Settlement classified as amendment → settlement amounts enter rate tables
- Cover memo classified as amendment → internal routing metadata treated as contractual terms

---

### 1.2 Retrieval-Stage Hallucination

These don't create false data but cause the wrong data to be presented as the answer.

#### A. Scope Leakage (Provider Confusion)

**Risk level:** HIGH — The #1 retrieval failure mode.

**Mechanism:** No entity extraction from queries means retrieval returns results from ANY provider that matches keywords.

**Example:**
- Query: "What is Providence's inpatient per diem?"
- System: Returns rates from 5 providers because "inpatient" and "per diem" match many units
- User sees: Rate from Kaiser presented alongside Providence rates without clear attribution
- Consequence: User may cite wrong provider's rate in negotiations

**Current mitigation:** NONE. The `provider_filter` field on ParsedQuery is never populated by `understand_query()`.

#### B. Temporal Confusion (State Hallucination)

**Risk level:** HIGH

**Mechanism:** The `is_current` flag is hardcoded to TRUE for all 21K rate_rules units (line 168 of 04_legal_chunking.py). This means:
- Superseded rates appear as "current"
- No mechanism to distinguish base agreement rate from amended rate
- Historical rates returned without "superseded" warning

**Example:**
- Base agreement (2020): Per diem = $1,200
- Amendment 3 (2023): Per diem = $1,500
- Both units have `is_current = TRUE`
- Retrieval may return the $1,200 rate to a "current rate" query

#### C. Amendment Confusion

**Risk level:** HIGH

**Mechanism:** No amendment-chain traversal in retrieval. The structural channel fetches siblings from the same file but doesn't follow supersession chains.

**Example:**
- Query: "What did the 5th amendment change?"
- System: Searches for "5th amendment" keywords
- Result: May return the US Constitution's 5th Amendment (from a regulatory clause) instead of the contract's 5th amendment
- Or: Returns the 5th amendment's NEW rates but not what they REPLACED

#### D. Retrieval Contamination

**Risk level:** MEDIUM

**Mechanism:** Lexical channel uses ILIKE substring matching with AND conjunction. Common legal terms ("shall", "provider", "agreement") appear in nearly every unit, causing irrelevant results to enter the fusion pool.

**Impact:** Noise from irrelevant units dilutes the context provided to the generation LLM, increasing hallucination probability in downstream answers.

#### E. Semantic Drift

**Risk level:** MEDIUM

**Mechanism:** Vector similarity conflates semantically similar but legally distinct concepts.

**Examples:**
- "Stop-loss threshold" ≈ "risk corridor" (similar embedding, different legal meaning)
- "Termination for cause" ≈ "termination without cause" (nearly identical embedding, opposite meaning)
- "Lesser-of provision" ≈ "greater-of calculation" (high similarity, inverse logic)

---

### 1.3 Generation-Stage Hallucination

These occur when the answer LLM (Genie or future chat) synthesizes retrieved evidence into a response.

#### A. Fabrication (No Evidence Basis)

**Risk:** LLM generates claims not supported by any retrieved unit.

**Probability:** HIGH when retrieved evidence is insufficient but model doesn't abstain.

**Current mitigation:** NONE. No citation enforcement. No "I don't know" pathway.

#### B. Numerical Distortion

**Risk:** LLM quotes a dollar amount or date that differs from the source.

**Probability:** MEDIUM. Models generally preserve numbers, but can round, truncate, or transpose.

**Example:** Source says "$1,547.23" → model writes "$1,547" (rounds) or "$1,574" (transposes digits).

#### C. Conditional Drop

**Risk:** LLM states a rate or obligation without its qualifying conditions.

**Probability:** HIGH. This is the most common faithfulness failure in contract RAG.

**Example:**
- Source: "Per diem rate of $1,500, subject to stop-loss threshold of $75,000 and lesser-of provision"
- Model: "The per diem rate is $1,500"
- Missing: Stop-loss and lesser-of conditions that materially affect actual payment

#### D. Aggregation Error

**Risk:** LLM generalizes from one provider to "all" or makes universal claims.

**Probability:** MEDIUM.

**Example:**
- Evidence: Providence has a 90-day termination notice
- Model: "Providers in this network have 90-day termination notice requirements"
- Reality: Other providers have 60-day, 120-day, or no notice requirements

#### E. Inference Overreach

**Risk:** LLM draws conclusions not explicitly stated in source text.

**Probability:** MEDIUM-HIGH. Healthcare contracts require conservative interpretation.

**Example:**
- Evidence: "Rate increases 3% annually"
- Model: "The 2026 rate will be $1,591" (calculates 1500 × 1.03^2)
- Problem: Model performed arithmetic not stated in the contract; actual 2026 rate may be different due to amendments

---

### 1.4 Bootstrap-Stage Hallucination (Systematic)

These are structural issues in how the data pipeline creates "ground truth."

#### A. Hardcoded `is_current = TRUE`

**Location:** `04_legal_chunking.py`, line 168

```sql
TRUE AS is_current,  -- ALL rate_rules get is_current=TRUE
```

**Impact:** 21,074 rate rules from ALL documents (including superseded amendments) are marked as current. This is a **systematic false assertion** that propagates to every retrieval query using temporal filtering.

**Root cause:** The bootstrap doesn't have supersession resolution. It loads from `tbl_reimb_rate_rules` which already filtered `WHERE status = 'current'`, but that filter was applied at the V1→V2 migration level based on coarse document-level dedup, not provision-level supersession.

#### B. Source Table Conflation

The 83K legal units come from two sources:
- 69K from `tbl_contract_terms_vs_ready` (clauses, definitions, sections)
- 14K from `tbl_reimb_rate_rules` (generated rate summaries)

The rate summaries are **LLM-generated text** (the `concat(...)` formula in step 3 of 04_legal_chunking.py creates synthetic text from structured fields). This means:
- Semantic search on these units is searching over **generated text, not source contract text**
- The `unit_text` for rates is a template ("Provider: X\nService: Y\nRate: Z") — not verbatim contract language
- Citation to these units cites a synthetic summary, not the actual contract page

#### C. Missing Amendment Linkage

The `tbl_retrieval_legal_units` table has no `superseded_by` column, no `amendment_chain` field, and no mechanism to link a clause to the amendments that modify it. The `effective_date` field is populated but not used for supersession logic.

---

## PART 2: RISK QUANTIFICATION

### 2.1 Hallucination Probability by Query Type

| Query Type | Estimated Hallucination Rate | Primary Risk | Severity if Wrong |
| --- | --- | --- | --- |
| Single-provider rate lookup | 15-25% | Temporal confusion (stale rate) | CRITICAL — payment disputes |
| Cross-provider comparison | 35-50% | Scope leakage (wrong provider's rate) | HIGH — incorrect negotiation basis |
| Amendment history | 40-60% | Incomplete retrieval, missing chain links | HIGH — wrong supersession understanding |
| Clause existence check | 20-30% | False negative (clause exists but not retrieved) | MEDIUM — compliance gaps |
| Financial exposure calculation | 50-70% | Inference overreach + stale data | CRITICAL — financial planning |
| "What changed?" queries | 60-80% | No diff capability, no before/after | HIGH — negotiation prep |
| Aggregation ("average rate") | 30-40% | Incomplete retrieval, not all providers scanned | MEDIUM — market positioning |

### 2.2 Hallucination Severity Matrix

| If Hallucinated... | Financial Impact | Legal Impact | Operational Impact |
| --- | --- | --- | --- |
| Per diem rate (wrong by $200) | $200 × ~365 days × patients = $73K+/year per provider | Payment dispute, audit finding | Claims paid incorrectly |
| Stop-loss threshold (wrong by $10K) | Exposure miscalculation for high-cost cases | Contract non-compliance | Risk management failure |
| Effective date (wrong by 3 months) | Retroactive payment adjustments | Amendment applicability disputes | Timing of rate changes |
| Provider name (wrong entity) | Rate applied to wrong hospital | Contract misattribution | Network adequacy reporting |
| Expiration date (wrong) | Missed renewal window | Auto-renewal vs termination confusion | Strategic planning error |
| "No stop-loss" (false negative) | Uncapped financial exposure assumed | None (conservative error) | Over-reserves, increased premiums |
| "Has stop-loss" (false positive) | Under-reserved financial exposure | Payment below contractual obligation | Potential underpayment litigation |

### 2.3 Cumulative Trust Erosion

Even when individual hallucination probability is low, cumulative impact across many queries destroys trust:
- 10 queries/day × 20% hallucination rate = 2 wrong answers daily
- 1 wrong rate cited in negotiations = months of repair + legal costs
- 1 false "contract expires next month" = emergency renewal scramble for non-expiring contract

**The cost of ONE high-severity hallucination exceeds the entire platform development cost.**

---

## PART 3: MISSING-CONTEXT RISK ANALYSIS

### 3.1 Evidence Insufficiency Scenarios

| Scenario | What Happens Now | What Should Happen |
| --- | --- | --- |
| Query about unprocessed provider (9K of 10K PDFs) | Returns results from similar-sounding providers | Return "No data available for this provider" |
| Query about a clause that doesn't exist in contract | Returns vaguely similar clauses from other sections | Return "This provision was not found in Provider X's contract" |
| Query about future rates (not yet amended) | Returns most recent rate without caveat | Return rate + "Note: This is the most recent rate on file as of [date]" |
| Multi-provider query where data exists for only some | Returns partial results without indicating gaps | Return results + "Data unavailable for: [list of missing providers]" |
| Rate from superseded amendment retrieved | Presented as current without warning | Flag: "⚠️ This rate may have been superseded by Amendment [N]" |

### 3.2 Context Completeness Scoring

**Every answer should report evidence completeness:**

```
Evidence Assessment:
- Provider coverage: 1/1 (Providence found)
- Temporal coverage: CURRENT (most recent rate, effective 2024-01-01)
- Conditional completeness: PARTIAL (rate found, but associated stop-loss provisions not retrieved)
- Confidence: 0.75 (rate directly stated; conditions may be incomplete)
```

**Currently implemented:** NONE of this.

---

## PART 4: TRUST ARCHITECTURE (Proposed)

### 4.1 Defense-in-Depth Model

```
Layer 1: EXTRACTION VERIFICATION (data creation time)
─────────────────────────────────────────────────────
• Numerical consistency check (rate_numeric matches rate_text)
• Date format validation (actual YYYY-MM-DD, not inferred)
• Cross-field consistency (effective_date < expiration_date)
• OCR confidence scoring (flag low-confidence characters)
• Schema completeness scoring

Layer 2: RETRIEVAL GROUNDING (query time)
─────────────────────────────────────────
• Entity verification (provider in query matches provider in result)
• Temporal verification (result is_current matches query temporal intent)
• Minimum confidence threshold (reject fused scores below 0.15)
• Evidence sufficiency check (at least 1 high-confidence result required)
• "I don't know" escape when evidence insufficient

Layer 3: GENERATION VERIFICATION (answer time)
──────────────────────────────────────────────
• Inline citation enforcement (every factual claim must cite evidence)
• Numerical exact-match verification (amounts in answer vs source)
• Scope verification (provider in answer matches provider in evidence)
• Conditional completeness check (conditions not dropped)
• Confidence score on final answer

Layer 4: POST-HOC AUDIT (continuous)
────────────────────────────────────
• Random sampling of answers for human review
• Automated regression on golden query set
• Drift detection on extraction quality metrics
• User feedback integration (thumbs up/down)
```

### 4.2 Trust Signals for Every Answer

Every response from the system should carry:

```python
@dataclass
class TrustEnvelope:
    """Wraps every answer with trust metadata."""
    answer_text: str
    confidence: float              # 0-1, calibrated probability of correctness
    
    # Evidence grounding
    citations: List[Citation]      # Source unit IDs with page references
    evidence_coverage: float       # % of claims that are cited
    uncited_claims: List[str]      # Any claims without supporting evidence
    
    # Temporal trust
    data_freshness: str            # "Current as of [date]" or "May be superseded"
    supersession_risk: float       # Probability that cited data is stale
    
    # Scope trust
    provider_match: bool           # All evidence from queried provider(s)
    cross_provider_contamination: bool  # Whether non-queried providers appear
    
    # Completeness
    missing_providers: List[str]   # Providers asked about but not found
    missing_dimensions: List[str]  # E.g., "stop-loss not retrieved", "conditions incomplete"
    
    # Human review triggers
    needs_review: bool             # True if confidence < 0.6 or violations detected
    review_reason: str             # Why human review is needed
```

---

## PART 5: EVIDENCE GROUNDING IMPROVEMENTS

### 5.1 Ground Truth Provenance Chain

Every answer should trace back through:

```
Answer claim: "Providence's per diem is $1,500"
    ↓ citation [1]
Legal Semantic Unit: unit_id = "abc123"
    ↓ source mapping
Source: tbl_contract_terms_vs_ready.row_id = "xyz789"
    ↓ extraction provenance
PDF: "0001_Providence_12345_BaseAgmt_v1.pdf", page 47
    ↓ file reference
Volume: /Volumes/.../Provider_Contracts/0001_Providence/...
```

### 5.2 Source Text Anchoring

**Problem:** RATE_TABLE legal units contain synthetic text (generated by concat template), not verbatim contract language.

**Fix:** Add `source_verbatim` field to legal units that stores the original extracted rate_text from the LLM extraction:

```sql
ALTER TABLE dev_adb.raw.tbl_retrieval_legal_units
ADD COLUMN source_verbatim STRING
COMMENT 'Original verbatim text from source document (for citation verification)';
```

For clause units (from `tbl_contract_terms_vs_ready`), the `unit_text` IS the source text. For rate units, the `unit_text` is a template — `source_verbatim` should store the original `rate_text` field.

### 5.3 Evidence Sufficiency Threshold

```python
def check_evidence_sufficiency(results: List[ScoredChunk], parsed: ParsedQuery) -> EvidenceAssessment:
    """Determine if retrieved evidence is sufficient to answer the query."""
    
    if not results:
        return EvidenceAssessment(sufficient=False, reason="No results retrieved")
    
    # Check 1: At least one high-confidence result
    max_score = max(r.score for r in results)
    if max_score < 0.15:
        return EvidenceAssessment(sufficient=False, 
            reason="All results below confidence threshold")
    
    # Check 2: Provider match (if provider specified in query)
    if parsed.provider_filter:
        provider_matches = [r for r in results 
                          if parsed.provider_filter.lower() in r.provider_name.lower()]
        if not provider_matches:
            return EvidenceAssessment(sufficient=False,
                reason=f"No results found for provider: {parsed.provider_filter}")
    
    # Check 3: Domain match for rate queries
    if parsed.intent == "RATE_LOOKUP":
        rate_results = [r for r in results if r.unit_type == "RATE_TABLE"]
        if not rate_results:
            return EvidenceAssessment(sufficient=False,
                reason="Rate query but no RATE_TABLE units retrieved")
    
    return EvidenceAssessment(sufficient=True, confidence=max_score)
```

---

## PART 6: CITATION IMPROVEMENTS

### 6.1 Mandatory Citation Protocol

Every factual claim in a generated answer MUST cite a source unit:

```
The inpatient per diem rate for Providence is $1,500 [1], effective January 1, 2024 [1],
subject to a stop-loss threshold of $75,000 [2].

───────────────────────
CITATIONS:
[1] Source: 0001_Providence_12345_BaseAgmt_v1.pdf
    Unit: RATE_TABLE | Inpatient Per Diem
    Effective: 2024-01-01 | Status: CURRENT
    
[2] Source: 0001_Providence_12345_BaseAgmt_v1.pdf
    Unit: CLAUSE | Stop-Loss Provisions (Section 4.2)
    Effective: 2024-01-01 | Status: CURRENT
```

### 6.2 Citation Verification Checks

| Check | What It Verifies | Detection Method | Automated? |
| --- | --- | --- | --- |
| Every number in answer appears in cited unit | Numerical faithfulness | Regex extraction + exact match | YES |
| Every date in answer appears in cited unit | Temporal faithfulness | Date extraction + exact match | YES |
| Provider name in answer matches cited unit | Scope correctness | String match on provider_name | YES |
| Answer doesn't claim "all" when evidence covers subset | Quantifier accuracy | Count providers in evidence vs claim | PARTIAL |
| Conditions in source are preserved in answer | Conditional completeness | NLI check (requires LLM judge) | NO (expensive) |
| Cited unit is marked is_current=TRUE | Temporal currency | Direct field check | YES |

### 6.3 Uncited Claim Detection

```python
def detect_uncited_claims(answer_text: str, citations: List[Citation]) -> List[str]:
    """Find factual claims in the answer that lack citation markers."""
    # Extract sentences containing factual signals
    factual_patterns = [
        r'\$[\d,]+',                    # Dollar amounts
        r'\d+%',                         # Percentages
        r'\d{4}-\d{2}-\d{2}',          # Dates
        r'\d+ days?',                    # Day counts
        r'(shall|must|will|requires)',   # Obligations
        r'(expires?|terminates?|effective)',  # Temporal claims
    ]
    
    sentences = split_into_sentences(answer_text)
    uncited = []
    for sent in sentences:
        has_factual = any(re.search(p, sent) for p in factual_patterns)
        has_citation = bool(re.search(r'\[\d+\]', sent))
        if has_factual and not has_citation:
            uncited.append(sent)
    
    return uncited
```

---

## PART 7: VERIFICATION LAYERS

### 7.1 Layer 1: Extraction Verification (Batch, at ETL Time)

**Runs on every extracted JSON before it enters Delta tables.**

```python
def verify_extraction(extracted: dict, full_text: str) -> List[Violation]:
    violations = []
    
    # V1: Rate consistency — rate_numeric should parse from rate_text
    for rate_section in ['inpatient_rates', 'outpatient_rates']:
        for rate_array in extract_rate_arrays(extracted, rate_section):
            for rate in rate_array:
                if rate.get('rate_numeric') and rate.get('rate'):
                    text_amount = extract_dollar_amount(rate['rate'])
                    if text_amount and abs(text_amount - rate['rate_numeric']) > 0.01:
                        violations.append(Violation(
                            type='NUMERICAL_INCONSISTENCY',
                            field=f"{rate_section}.rate_numeric",
                            expected=text_amount,
                            actual=rate['rate_numeric'],
                            severity='HIGH'
                        ))
    
    # V2: Date presence — effective_date must appear in source text
    eff_date = extracted.get('contract_overview', {}).get('effective_date')
    if eff_date and eff_date not in full_text:
        # Check reformatted versions
        if not any(fmt in full_text for fmt in reformat_date(eff_date)):
            violations.append(Violation(
                type='DATE_NOT_IN_SOURCE',
                field='contract_overview.effective_date',
                value=eff_date,
                severity='HIGH'
            ))
    
    # V3: Provider name must appear in source
    provider = extracted.get('parties', {}).get('provider', {}).get('name')
    if provider and provider not in full_text:
        violations.append(Violation(
            type='PROVIDER_NOT_IN_SOURCE',
            field='parties.provider.name',
            value=provider,
            severity='MEDIUM'
        ))
    
    return violations
```

### 7.2 Layer 2: Retrieval Verification (Real-time, per Query)

```python
def verify_retrieval_results(results: List[ScoredChunk], parsed: ParsedQuery) -> RetrievalDiagnostics:
    """Post-retrieval verification before passing to generation."""
    
    diagnostics = RetrievalDiagnostics()
    
    # Check: Provider scope purity
    if parsed.provider_filter:
        off_scope = [r for r in results 
                    if r.provider_name and 
                    parsed.provider_filter.lower() not in r.provider_name.lower()]
        if off_scope:
            diagnostics.add_warning(
                f"SCOPE_CONTAMINATION: {len(off_scope)} results from other providers filtered out"
            )
            results = [r for r in results if r not in off_scope]  # Remove contamination
    
    # Check: Temporal consistency
    superseded_results = [r for r in results if not r.is_current]
    if superseded_results and parsed.temporal_scope == "CURRENT_ONLY":
        diagnostics.add_warning(
            f"TEMPORAL_CONTAMINATION: {len(superseded_results)} superseded results removed"
        )
        results = [r for r in results if r.is_current]
    
    # Check: Diversity (not all results from same document)
    source_files = set(r.source_filename for r in results[:10])
    if len(source_files) == 1 and len(results) > 3:
        diagnostics.add_info("SINGLE_SOURCE: All top results from one document")
    
    diagnostics.filtered_results = results
    return diagnostics
```

### 7.3 Layer 3: Generation Verification (Real-time, per Answer)

```python
def verify_answer(answer: str, evidence: List[ScoredChunk]) -> AnswerVerification:
    """Verify generated answer against source evidence."""
    
    violations = []
    
    # V1: Extract all numbers from answer
    answer_numbers = extract_all_numbers(answer)  # {1500.0, 75000.0, 90, ...}
    evidence_numbers = set()
    for chunk in evidence:
        evidence_numbers.update(extract_all_numbers(chunk.unit_text))
    
    # Any number in answer not in evidence is suspicious
    unsupported_numbers = answer_numbers - evidence_numbers
    for num in unsupported_numbers:
        violations.append(AnswerViolation(
            type='UNSUPPORTED_NUMBER',
            value=str(num),
            severity='HIGH',
            explanation=f"${num:,.2f} appears in answer but not in any cited evidence"
        ))
    
    # V2: Extract all dates from answer
    answer_dates = extract_all_dates(answer)
    evidence_dates = set()
    for chunk in evidence:
        evidence_dates.update(extract_all_dates(chunk.unit_text))
    
    unsupported_dates = answer_dates - evidence_dates
    for d in unsupported_dates:
        violations.append(AnswerViolation(
            type='UNSUPPORTED_DATE',
            value=d,
            severity='HIGH',
            explanation=f"Date {d} appears in answer but not in cited evidence"
        ))
    
    # V3: Provider names mentioned in answer
    answer_providers = extract_provider_names(answer)
    evidence_providers = set(c.provider_name for c in evidence)
    unsupported_providers = answer_providers - evidence_providers
    for p in unsupported_providers:
        violations.append(AnswerViolation(
            type='UNSUPPORTED_PROVIDER',
            value=p,
            severity='MEDIUM',
            explanation=f"Provider '{p}' mentioned in answer but not in evidence"
        ))
    
    return AnswerVerification(
        is_faithful=len([v for v in violations if v.severity == 'HIGH']) == 0,
        violations=violations,
        confidence=compute_answer_confidence(violations, evidence)
    )
```

---

## PART 8: CONFIDENCE SCORING

### 8.1 Multi-Signal Confidence Model

```python
def compute_confidence(
    retrieval_scores: List[float],
    citation_coverage: float,
    numerical_verification: float,
    scope_purity: float,
    temporal_certainty: float
) -> ConfidenceScore:
    """
    Compute calibrated confidence from multiple signals.
    
    Target: confidence=0.8 means correct 80% of the time (calibrated).
    """
    # Component scores (all 0-1)
    retrieval_conf = np.mean(sorted(retrieval_scores, reverse=True)[:5]) if retrieval_scores else 0.0
    
    # Weighted combination
    overall = (
        0.25 * retrieval_conf +       # How relevant was retrieved evidence?
        0.25 * citation_coverage +     # What % of claims are cited?
        0.20 * numerical_verification + # Did all numbers verify?
        0.15 * scope_purity +          # All evidence from correct provider?
        0.15 * temporal_certainty      # Evidence confirmed current?
    )
    
    return ConfidenceScore(
        overall=overall,
        label=confidence_label(overall),
        components={
            "retrieval": retrieval_conf,
            "citations": citation_coverage,
            "numerical": numerical_verification,
            "scope": scope_purity,
            "temporal": temporal_certainty,
        }
    )

def confidence_label(score: float) -> str:
    if score >= 0.85:
        return "HIGH CONFIDENCE — verified against source"
    elif score >= 0.65:
        return "MODERATE CONFIDENCE — likely correct, verify key numbers"
    elif score >= 0.45:
        return "LOW CONFIDENCE — treat as directional only"
    else:
        return "INSUFFICIENT EVIDENCE — do not use for decisions"
```

### 8.2 Confidence Display Rules

| Confidence | User-Facing Behavior |
| --- | --- |
| ≥ 0.85 | Show answer normally with green confidence indicator |
| 0.65 - 0.84 | Show answer with amber "Verify" indicator + source link |
| 0.45 - 0.64 | Show answer with red "Low Confidence" warning + mandatory source check |
| < 0.45 | Do NOT show answer. Display: "I don't have sufficient evidence to answer this reliably. Here's what I found: [raw evidence]" |

---

## PART 9: HUMAN-REVIEW PATHWAYS

### 9.1 Automatic Escalation Triggers

| Trigger | Condition | Action |
| --- | --- | --- |
| Numerical violation | Dollar amount in answer not in evidence | Block answer → human review queue |
| Scope contamination | Multiple providers in single-provider query | Flag answer + add warning |
| Temporal uncertainty | Evidence includes possibly-superseded units | Add "may be outdated" caveat |
| High-stakes query | Query mentions "payment", "terminate", "liability" | Add "Verify with contract" disclaimer |
| Zero evidence | No results above confidence threshold | Return "cannot answer" + suggest alternatives |
| Conflicting evidence | Two units disagree on same fact | Present both with "Conflicting terms found" |

### 9.2 Review Queue Design

```python
@dataclass
class ReviewItem:
    query: str
    generated_answer: str
    evidence_units: List[str]      # Unit IDs
    violations: List[str]          # What triggered review
    confidence: float
    timestamp: datetime
    user_id: str                   # Who asked
    priority: str                  # CRITICAL / HIGH / MEDIUM
    status: str                    # PENDING / REVIEWED / CONFIRMED / REJECTED
    reviewer_notes: str            # Human reviewer's assessment
```

### 9.3 Feedback Loop

```
User asks question
    → System generates answer with confidence
    → If confidence < 0.65: flag for review
    → Human reviewer confirms or corrects
    → Correction feeds back to:
        1. Golden query set (evaluation improvement)
        2. Extraction error log (if source data was wrong)
        3. Retrieval weight tuning (if wrong results were retrieved)
```

---

## PART 10: GUARDRAILS

### 10.1 Hard Guardrails (Cannot Be Overridden)

| Guardrail | Implementation | Rationale |
| --- | --- | --- |
| Never present dollar amount not in evidence | Post-generation number check | Financial liability |
| Never attribute rate to unmentioned provider | Scope verification | Contractual accuracy |
| Never state "all providers" without evidence for all | Quantifier check | Aggregation errors |
| Always include effective date with any rate | Citation completeness | Temporal context |
| Never present superseded rate as current without warning | State annotation | Stale data risk |
| Maximum 1 answer per query (no retries with different content) | Determinism | Consistency |

### 10.2 Soft Guardrails (Configurable)

| Guardrail | Default | Purpose |
| --- | --- | --- |
| Minimum retrieval confidence to answer | 0.15 | Prevents answers from garbage evidence |
| Maximum answer length | 500 words | Prevents over-generation (more words = more hallucination surface) |
| Citation density minimum | 1 citation per 2 factual sentences | Ensures grounding |
| Cross-provider result cap | 5 providers max per answer | Prevents scope sprawl |
| Amendment chain depth | 3 amendments deep | Prevents stale-data cascades |

### 10.3 Disclaimer Framework

| Context | Required Disclaimer |
| --- | --- |
| Any answer with confidence < 0.8 | "This information should be verified against the source contract." |
| Any rate or dollar amount | "Verify rate against [source document] before use in payment calculations." |
| Any answer involving amendments | "Contract amendment history may affect these terms. Check amendment timeline." |
| Any answer about unprocessed provider (>133 processed) | "Note: Only [N]% of PDFs have been processed. Additional terms may exist." |
| Any temporal claim | "Information current as of [extraction date]. Check for recent amendments." |

---

## PART 11: NUMERICAL VERIFICATION

### 11.1 Extraction-Time Numerical Verification

```python
def verify_extracted_numbers(extracted: dict) -> List[NumericalIssue]:
    """Cross-check all numeric fields against text fields and reasonable ranges."""
    issues = []
    
    # Rule 1: rate_numeric must parse from rate text field
    for path, rate in enumerate_all_rates(extracted):
        if rate.get('rate_numeric') and rate.get('rate'):
            parsed = parse_dollar_amount(rate['rate'])
            if parsed and abs(parsed - rate['rate_numeric']) > 0.01:
                issues.append(NumericalIssue(
                    field=path, type='TEXT_NUMERIC_MISMATCH',
                    text_value=rate['rate'], numeric_value=rate['rate_numeric']
                ))
    
    # Rule 2: Range validation (healthcare contract reasonable ranges)
    REASONABLE_RANGES = {
        'per_diem': (200, 25000),         # $200-$25K per day
        'case_rate': (1000, 500000),       # $1K-$500K per case
        'pmpm': (1, 5000),                 # $1-$5K per member per month
        'stop_loss': (10000, 2000000),     # $10K-$2M stop-loss threshold
        'percentage': (0.01, 500),         # 0.01%-500% (of charges)
    }
    for path, rate in enumerate_all_rates(extracted):
        if rate.get('rate_numeric'):
            rate_type = infer_rate_type(path, rate)
            if rate_type in REASONABLE_RANGES:
                lo, hi = REASONABLE_RANGES[rate_type]
                if rate['rate_numeric'] < lo or rate['rate_numeric'] > hi:
                    issues.append(NumericalIssue(
                        field=path, type='OUT_OF_RANGE',
                        value=rate['rate_numeric'], expected_range=(lo, hi)
                    ))
    
    # Rule 3: Effective date before expiration date
    co = extracted.get('contract_overview', {})
    eff = co.get('effective_date')
    exp = co.get('expiration_date')
    if eff and exp and eff > exp:
        issues.append(NumericalIssue(
            field='contract_overview', type='DATE_ORDER_VIOLATION',
            text_value=f"effective={eff}, expiration={exp}"
        ))
    
    return issues
```

### 11.2 Answer-Time Numerical Verification

For every dollar amount in a generated answer:
1. Extract all `$X,XXX.XX` patterns
2. For each, find the cited evidence unit
3. Verify exact match (or within $0.01 for rounding)
4. If no match: **BLOCK the answer** and return evidence directly

---

## PART 12: AMENDMENT VERIFICATION

### 12.1 Amendment State Resolution

```python
def verify_amendment_state(unit: ScoredChunk) -> AmendmentStatus:
    """Determine if a retrieved unit has been superseded by a later amendment."""
    
    # Query amendment registry for modifications after this unit's effective date
    amendments = spark.sql(f"""
        SELECT a.amendment_id, a.effective_date, a.scope_type,
               a.exhibits_modified, a.summary_of_changes
        FROM dev_adb.raw.tbl_v2_amendment_registry a
        WHERE a.contract_id = '{unit.contract_id}'
          AND a.effective_date > '{unit.effective_date}'
        ORDER BY a.effective_date ASC
    """).collect()
    
    if not amendments:
        return AmendmentStatus(is_current=True, confidence=0.95)
    
    # Check if any amendment modifies this unit's section
    for amend in amendments:
        if amend['scope_type'] == 'FULL_REPLACEMENT':
            return AmendmentStatus(
                is_current=False, confidence=0.90,
                superseded_by=amend['amendment_id'],
                warning=f"Superseded by full replacement effective {amend['effective_date']}"
            )
        if unit.section_type and unit.section_type in (amend['exhibits_modified'] or ''):
            return AmendmentStatus(
                is_current=False, confidence=0.75,
                superseded_by=amend['amendment_id'],
                warning=f"Section may be modified by amendment effective {amend['effective_date']}"
            )
    
    # Amendments exist but don't clearly modify this section
    return AmendmentStatus(
        is_current=True, confidence=0.70,
        warning=f"{len(amendments)} later amendments exist — verify currency"
    )
```

### 12.2 Amendment Chain Display

When answering questions involving amended terms:

```
Rate: $1,500/day (Inpatient Med/Surg Per Diem)

Amendment History:
├── Base Agreement (2020-01-01): $1,200/day
├── Amendment 2 (2022-06-01): $1,350/day [SUPERSEDED]
└── Amendment 5 (2024-01-01): $1,500/day [CURRENT] ← cited
```

---

## PART 13: STATE VERIFICATION

### 13.1 is_current Verification

**The hardcoded `is_current = TRUE` problem:**

All 21,074 rate_rules were loaded with `is_current = TRUE` regardless of supersession status. This is because the bootstrap (04_legal_chunking.py) doesn't perform supersession resolution.

**Fix — Runtime state verification:**

```python
def verify_current_state(unit: ScoredChunk) -> StateVerification:
    """Runtime check: is this unit actually current?"""
    
    # Check 1: Does a newer unit exist with same provider + service_line?
    newer_exists = spark.sql(f"""
        SELECT COUNT(*) AS cnt
        FROM dev_adb.raw.tbl_retrieval_legal_units
        WHERE provider_id = '{unit.provider_id}'
          AND rate_domain = '{unit.rate_domain}'
          AND section_type = '{unit.section_type}'
          AND effective_date > '{unit.effective_date}'
          AND unit_id != '{unit.unit_id}'
    """).collect()[0]['cnt']
    
    if newer_exists > 0:
        return StateVerification(
            verified_current=False,
            confidence=0.70,
            warning="A newer rate exists for this provider/service — this may be superseded"
        )
    
    # Check 2: Does amendment registry show supersession?
    amend_status = verify_amendment_state(unit)
    
    return StateVerification(
        verified_current=amend_status.is_current,
        confidence=amend_status.confidence,
        warning=amend_status.warning
    )
```

### 13.2 Point-in-Time State Query

```python
def get_state_as_of(provider_id: str, service_line: str, as_of_date: str) -> StateAsOf:
    """What was the governing rate on a specific date?"""
    
    result = spark.sql(f"""
        SELECT * FROM dev_adb.raw.tbl_retrieval_legal_units
        WHERE provider_id = :provider_id
          AND section_type LIKE :service_pattern
          AND effective_date <= :as_of_date
          AND unit_type = 'RATE_TABLE'
        ORDER BY effective_date DESC
        LIMIT 1
    """, params={
        "provider_id": provider_id,
        "service_pattern": f"%{service_line}%",
        "as_of_date": as_of_date
    }).collect()
    
    if result:
        return StateAsOf(found=True, unit=result[0], 
                        note=f"Rate effective {result[0]['effective_date']}, governing as of {as_of_date}")
    else:
        return StateAsOf(found=False, 
                        note=f"No rate found for {provider_id}/{service_line} as of {as_of_date}")
```

---

## PART 14: RETRIEVAL DIAGNOSTICS

### 14.1 Per-Query Diagnostic Output

```python
@dataclass
class RetrievalDiagnostics:
    """Full diagnostic trace for every retrieval query."""
    query: str
    parsed_intent: str
    parsed_entities: dict
    
    # Channel results
    semantic_count: int
    semantic_top_score: float
    lexical_count: int
    metadata_count: int
    structural_count: int
    
    # Fusion results
    fused_count: int
    fused_top_score: float
    
    # Quality indicators
    provider_diversity: int        # How many distinct providers in top-10
    temporal_diversity: int        # How many distinct effective_dates
    type_diversity: int            # How many distinct unit_types
    single_source_dominance: bool  # >80% results from one file
    
    # Warnings
    scope_contamination: bool      # Results from unqueried providers
    possible_supersession: bool    # Results that may be superseded
    low_confidence: bool           # Top score below threshold
    
    # Timing
    latency_ms: float
    channel_latencies: dict        # Per-channel timing
```

### 14.2 Telemetry Table

```sql
CREATE TABLE IF NOT EXISTS dev_adb.raw.tbl_retrieval_telemetry (
    query_id            STRING NOT NULL,
    timestamp           TIMESTAMP NOT NULL,
    query_text          STRING,
    parsed_intent       STRING,
    
    -- Results
    total_retrieved     INT,
    top_score           FLOAT,
    provider_in_results STRING,
    
    -- Verification
    confidence_score    FLOAT,
    has_numerical_error BOOLEAN,
    has_state_error     BOOLEAN,
    has_scope_error     BOOLEAN,
    needs_review        BOOLEAN,
    
    -- Quality metrics
    checks_passed       INT,
    checks_total        INT,
    citations_count     INT,
    
    -- Performance
    latency_ms          FLOAT,
    channel_semantic_ms FLOAT,
    channel_lexical_ms  FLOAT,
    channel_metadata_ms FLOAT,
    
    -- User feedback
    user_rating         STRING    COMMENT 'CORRECT | INCORRECT | PARTIAL | NULL'
) USING DELTA
COMMENT 'Per-query retrieval telemetry for trust monitoring'
TBLPROPERTIES ('delta.enableChangeDataFeed'='true')
```

---

## PART 15: HALLUCINATION DETECTION (Runtime)

### 15.1 Detection Signals

| Signal | What It Detects | Implementation | Latency |
| --- | --- | --- | --- |
| **Number-not-in-evidence** | Fabricated dollar amounts | Regex + set intersection | <5ms |
| **Date-not-in-evidence** | Fabricated dates | Date extraction + match | <5ms |
| **Provider-not-in-evidence** | Scope leakage | String match | <5ms |
| **Quantifier overreach** | "All providers" without evidence | Keyword + count check | <5ms |
| **Confidence-below-threshold** | Weak grounding overall | Score computation | <1ms |
| **Citation-density-low** | Uncited factual claims | Sentence parsing | <10ms |
| **Supersession-unverified** | Stale data risk | Amendment registry lookup | ~50ms |
| **NLI-entailment-check** | Inference overreach | LLM judge call | ~500ms |

### 15.2 Detection Pipeline

```python
def detect_hallucinations(answer: str, evidence: List[ScoredChunk], 
                          parsed: ParsedQuery) -> HallucinationReport:
    """Run all detection checks. Fast checks first, expensive checks gated."""
    
    report = HallucinationReport()
    
    # FAST CHECKS (always run, <20ms total)
    report.numerical = check_numbers_in_evidence(answer, evidence)
    report.dates = check_dates_in_evidence(answer, evidence)
    report.providers = check_providers_in_evidence(answer, evidence)
    report.quantifiers = check_quantifier_accuracy(answer, evidence)
    report.citation_density = check_citation_density(answer)
    
    # MEDIUM CHECKS (run if fast checks pass, <100ms)
    if not report.has_critical_violations():
        report.supersession = check_supersession_risk(evidence)
        report.scope_purity = check_scope_purity(evidence, parsed)
    
    # EXPENSIVE CHECKS (run only for high-stakes queries, ~500ms)
    if is_high_stakes_query(parsed):
        report.entailment = check_entailment_llm(answer, evidence)
    
    # Compute overall hallucination risk
    report.risk_level = compute_risk_level(report)
    report.should_block = report.risk_level == 'CRITICAL'
    report.needs_review = report.risk_level in ('CRITICAL', 'HIGH')
    
    return report
```

### 15.3 Hallucination Response Actions

| Risk Level | Action |
| --- | --- |
| CRITICAL (fabricated number/provider) | **BLOCK answer**. Show: "I found relevant information but cannot verify the accuracy. Here is the raw evidence: [source units]" |
| HIGH (possible supersession, low confidence) | Show answer with prominent warning: "⚠️ Low confidence — verify against source document before use" |
| MEDIUM (minor scope issues, partial evidence) | Show answer with subtle indicator: "ℹ️ Based on available evidence. Additional context may exist." |
| LOW (clean pass) | Show answer normally with green confidence badge |

---

## PART 16: PRODUCTION TRUST FRAMEWORK

### 16.1 Trust Metrics Dashboard

| Metric | Target | Measurement | Frequency |
| --- | --- | --- | --- |
| Hallucination rate (numerical) | <5% | Numbers not in evidence / total numbers | Per query |
| Hallucination rate (scope) | <10% | Wrong-provider results / total results | Per query |
| Citation coverage | >90% | Cited claims / total factual claims | Per query |
| Confidence calibration (ECE) | <0.10 | Expected Calibration Error | Weekly (batch) |
| User-reported errors | <2/week | Feedback submissions | Continuous |
| Supersession accuracy | >85% | Correct is_current labels / total | Monthly (sample audit) |
| Answer accuracy (human-judged) | >80% | Correct answers / sampled answers | Weekly (20-query sample) |

### 16.2 Trust SLA

| Tier | Confidence Threshold | Response Guarantee | Verification Level |
| --- | --- | --- | --- |
| Tier 1 (Decisions) | ≥0.85 | Verified answer with citations | Full verification pipeline |
| Tier 2 (Research) | ≥0.65 | Answer with confidence indicator | Fast checks only |
| Tier 3 (Exploration) | ≥0.45 | Answer with disclaimer | Minimal verification |
| Tier 4 (Insufficient) | <0.45 | Refuse to answer; show raw evidence | Evidence sufficiency check |

### 16.3 Implementation Roadmap

**Week 1: Foundation (Zero Quality Loss)**
1. Implement numerical verification (answer numbers vs evidence numbers)
2. Implement scope verification (provider match check)
3. Add confidence scoring (retrieval score + verification signals)
4. Add "insufficient evidence" escape (refuse when confidence < 0.45)
5. Create `tbl_retrieval_telemetry` and log all queries

**Week 2: Citation Layer**
6. Implement citation enforcement in generation prompt
7. Add citation extraction and mapping
8. Implement uncited-claim detection
9. Add supersession risk check (amendment registry lookup)
10. Deploy confidence display in Genie responses

**Week 3: Verification Pipeline**
11. Implement extraction-time numerical verification
12. Implement rate_numeric vs rate_text consistency check
13. Add reasonable-range validation for extracted amounts
14. Build human review queue for flagged answers
15. Run first evaluation against 20 golden queries

**Week 4: Continuous Trust Monitoring**
16. Deploy daily trust metrics computation
17. Implement user feedback loop (thumbs up/down)
18. Build trust dashboard (confidence distribution, violation rates)
19. Calibrate confidence against human judgments (ECE < 0.10)
20. Expand golden query set to 100+ with difficulty grading

---

## FINAL ASSESSMENT

### Critical Findings

1. **ZERO operational hallucination detection exists today.** The system can (and does) present fabricated numbers, wrong providers, and stale rates without any warning.

2. **The `is_current = TRUE` hardcoding is a systematic trust violation.** 21K rate units are asserted as current regardless of amendment history. This is not a bug — it's a design shortcut that creates unreliable retrieval foundations.

3. **No "I don't know" pathway exists.** When evidence is insufficient, the system returns low-quality results rather than abstaining. This is the #1 cause of hallucination in RAG systems.

4. **Citation verification exists only on paper.** The design document is comprehensive (6-check pipeline, NLI verification, calibrated confidence), but zero implementation exists.

5. **The generation layer (Genie) has no faithfulness constraints.** It receives retrieved chunks and generates free-form text with no citation enforcement, no grounding verification, and no confidence signaling.

### Highest-Impact Single Fix

**Implement the evidence sufficiency gate + "I don't know" response.** When max retrieval confidence is below 0.15, or when zero results match the queried provider, return "I don't have sufficient evidence to answer this reliably" instead of fabricating an answer from tangentially related chunks.

**Estimated effort:** 30 minutes.  
**Estimated hallucination reduction:** 40-50% (eliminates the "answer from nothing" failure mode).

### Risk If Unfixed

If the platform is used for payment calculations, contract negotiations, or compliance decisions without hallucination controls:
- **Financial exposure:** Incorrect rate cited → payment disputes ($50K-$500K per incident)
- **Legal exposure:** Hallucinated contract terms cited in negotiations → breach of good faith
- **Reputational exposure:** User loses trust after 2-3 wrong answers → platform abandoned

---

*End of review. The platform needs hallucination controls before any production decision-making use. Start with the evidence sufficiency gate and numerical verification — both are implementable in under 2 hours and eliminate the most dangerous failure modes.*
