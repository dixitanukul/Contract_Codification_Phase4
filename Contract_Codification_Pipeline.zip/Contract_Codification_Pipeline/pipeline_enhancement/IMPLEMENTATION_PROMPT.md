# IMPLEMENTATION PROMPT — Contract Codification Pipeline Rationalization
## 30-Day Sprint: Delete, Fix, Unify, Orchestrate

**Created**: May 2026  
**Context**: Architectural audit (Prompts 1-6) complete. Platform assessed at 3.4/10 enterprise readiness. 55% valuable / 45% complexity without ROI. This prompt provides the COMPLETE implementation plan to rationalize the platform.

**Repository**: `/Workspace/Users/adixit01@blueshieldca.com/Contract_Codification_Pipeline`  
**Schema**: `dev_adb.raw`  
**Runtime**: DBR 18.0, Azure, Standard_L16s_v2  

**Prerequisite Reading** (in this folder):
- `CONTEXT_FOR_CONTINUATION.md` — full platform understanding
- `validation_layer_audit.md` — 06_validation deep analysis
- `consolidation_layer_audit.md` — 07_consolidation deep analysis  
- `table_value_audit.md` — all 16 tables scored and classified
- `final_architecture_verdict.md` — enterprise scorecard and verdict

---

# PHASE 1: DELETE (Days 1-3)
## Objective: Remove 3,500 lines of dead code and 6 empty tables

### 1.1 Delete Platform Modules (zero downstream impact)

Delete these files entirely from `platform/`:

```
platform/09_scenario_engine.py      — volume_per_line=50 hardcoded; fabricated outputs
platform/10_leverage_scoring.py     — plan_market_share=0.25 hardcoded; meaningless scores
platform/06_reranking_service.py    — RERANKER_DEPLOYED=False; adds score+0.1 (noop)
platform/07_citation_verification.py — NLI = keyword overlap; no real verification
```

**Validation before delete**: Confirm no other module imports from these:
```python
import os, re
platform_dir = "/Workspace/Users/adixit01@blueshieldca.com/Contract_Codification_Pipeline/platform"
kill_list = ['09_scenario_engine', '10_leverage_scoring', '06_reranking_service', '07_citation_verification']

for fname in sorted(os.listdir(platform_dir)):
    if fname.endswith('.py') and not any(k in fname for k in kill_list):
        with open(os.path.join(platform_dir, fname)) as f:
            content = f.read()
        for target in kill_list:
            module_name = target.split('_', 1)[1]  # e.g., 'scenario_engine'
            if module_name in content:
                print(f"WARNING: {fname} references {target}")
```

### 1.2 Drop Empty Tables

Execute in SQL:
```sql
-- Tables that were designed but never populated (DDL theater)
DROP TABLE IF EXISTS dev_adb.raw.tbl_v2_rate_facts_bitemporal;
DROP TABLE IF EXISTS dev_adb.raw.tbl_reimb_formula_components;
DROP TABLE IF EXISTS dev_adb.raw.tbl_reimb_escalators;
DROP TABLE IF EXISTS dev_adb.raw.tbl_reimb_conditions;
DROP TABLE IF EXISTS dev_adb.raw.tbl_retrieval_telemetry;

-- Verify: all should return 0 before dropping
-- SELECT COUNT(*) FROM dev_adb.raw.tbl_v2_rate_facts_bitemporal; -- 0
-- etc.
```

### 1.3 Delete Consolidation Notebook

Delete `extraction/07_consolidation` — but FIRST:

1. Verify `08_build_rates` 11a-fix independently computes status (it does — confirmed in audit)
2. Inline version-dedup logic into `08_build_rates` (see Phase 2.3)
3. THEN delete the notebook

### 1.4 Drop Redundant Genie Table

```sql
-- tbl_genie_contract_terms is a redundant copy of tbl_contract_clauses_terms
-- Genie Space instruction should point to clauses_terms directly
DROP TABLE IF EXISTS dev_adb.raw.tbl_genie_contract_terms;
```

Update Genie Space instructions to reference `tbl_contract_clauses_terms` instead.

### 1.5 Remove Intelligence Tables (fabricated data)

```sql
-- These contain fabricated metrics (rate×50×12 spend, hardcoded leverage)
-- They will mislead users. Remove until real claims data is available.
DROP TABLE IF EXISTS dev_adb.raw.tbl_intel_provider_spend_summary;
DROP TABLE IF EXISTS dev_adb.raw.tbl_intel_savings_opportunity;
DROP TABLE IF EXISTS dev_adb.raw.tbl_intel_leverage_scores;
DROP TABLE IF EXISTS dev_adb.raw.tbl_intel_scenario_results;

-- KEEP these (computed from real extracted data):
-- tbl_intel_benchmark_results — rate percentiles from actual contracts
-- tbl_intel_renewal_priority — contract dates are real (spend estimates are not)
```

---

# PHASE 2: FIX CANONICAL TABLES (Days 4-10)
## Objective: Correct data types, remove denormalization, add validation gates

### 2.1 Fix `tbl_contract_rates_all` Schema

```sql
-- Fix STRING dates → DATE
-- Fix DOUBLE amendment_order → INT
-- The table already has effective_date_parsed (DATE) and canonical_provider_id
-- Verify those are populated:
SELECT 
  COUNT(*) AS total,
  COUNT(effective_date_parsed) AS has_parsed_date,
  COUNT(canonical_provider_id) AS has_canonical_id,
  COUNT(CASE WHEN amendment_order = CAST(amendment_order AS INT) THEN 1 END) AS order_is_int
FROM dev_adb.raw.tbl_contract_rates_all;

-- If effective_date_parsed is well-populated, drop the STRING version
-- and rename (or just document that effective_date_parsed is the canonical date column)
```

### 2.2 Add Quarantine Gate to Validation (06_validation)

Add a new function to `extraction/06_validation` AFTER the main processing loop:

```python
# ═══ QUARANTINE GATE ═══
# Block files with >30% unverified rates from proceeding to table build
# Quarantined files go to json_extract/_quarantine/ for human review

QUARANTINE_DIR = f"{BASE_DIR}/json_extract/_quarantine"
os.makedirs(QUARANTINE_DIR, exist_ok=True)

quarantined = 0
for ji, jf in enumerate(json_files):
    jp = os.path.join(OUTPUT_DIR, jf)
    try:
        with open(jp) as f:
            doc = json.load(f)
    except:
        continue
    
    v = doc.get('validation', {})
    rates_v = v.get('rates_verified', 0)
    rates_u = v.get('rates_unverified', 0)
    total_rates = rates_v + rates_u
    
    # Quarantine conditions:
    # 1. >30% rates unverified AND has more than 5 rates
    # 2. >50% dates unverified
    # 3. Coverage score < 20% on a Base Agreement
    should_quarantine = False
    reason = []
    
    if total_rates > 5 and rates_u / total_rates > 0.30:
        should_quarantine = True
        reason.append(f"rates_unverified={rates_u}/{total_rates} ({rates_u/total_rates*100:.0f}%)")
    
    dates_v = v.get('dates_verified', 0)
    dates_u = v.get('dates_unverified', 0)
    if (dates_v + dates_u) > 0 and dates_u / (dates_v + dates_u) > 0.50:
        should_quarantine = True
        reason.append(f"dates_unverified={dates_u}/{dates_v+dates_u}")
    
    coverage = v.get('v6_coverage_pct', 100)
    bucket = v.get('content_bucket', '')
    if bucket == 'B1_Base_Agreement' and coverage < 20:
        should_quarantine = True
        reason.append(f"base_agreement_coverage={coverage}%")
    
    if should_quarantine:
        # Move to quarantine (copy, don't delete — preserve for re-extraction)
        import shutil
        shutil.copy2(jp, os.path.join(QUARANTINE_DIR, jf))
        quarantined += 1
        # Tag the file
        doc['validation']['quarantined'] = True
        doc['validation']['quarantine_reason'] = reason
        with open(jp, 'w') as f:
            json.dump(doc, f, indent=2, ensure_ascii=False)

print(f"  🔒 Quarantine gate: {quarantined} files quarantined for human review")
print(f"     Quarantine dir: {QUARANTINE_DIR}")
```

### 2.3 Add Rate Reasonability Bounds to Validation

Add to `06_validation` after `postprocess_rate_numeric()`:

```python
# ═══ RATE REASONABILITY BOUNDS ═══
# Flag rates that are numerically implausible
RATE_BOUNDS = {
    'inpatient_per_diem': (50, 100_000),      # $50 - $100K per day
    'inpatient_case_rate': (500, 500_000),     # $500 - $500K per case
    'outpatient_surgical': (100, 200_000),     # $100 - $200K per procedure
    'capitation': (0.50, 5000),                # $0.50 - $5000 PMPM
    'outpatient_emergency': (50, 50_000),      # $50 - $50K ER visit
    'outpatient_therapy': (10, 2000),          # $10 - $2K per visit
}

def check_rate_reasonability(ec):
    """Flag rates outside plausible bounds. Returns list of flagged rates."""
    flags = []
    
    ip = ec.get('inpatient_rates', {}) or {}
    for pdr in (ip.get('per_diem_rates') or []):
        val = pdr.get('rate_numeric')
        if val is not None:
            lo, hi = RATE_BOUNDS.get('inpatient_per_diem', (0, 1e9))
            if val < lo or val > hi:
                flags.append({
                    'field': 'inpatient_rates.per_diem_rates',
                    'value': val,
                    'bounds': (lo, hi),
                    'issue': 'below_minimum' if val < lo else 'above_maximum'
                })
    
    for cr in (ip.get('case_rates') or []):
        val = cr.get('rate_numeric')
        if val is not None:
            lo, hi = RATE_BOUNDS.get('inpatient_case_rate', (0, 1e9))
            if val < lo or val > hi:
                flags.append({
                    'field': 'inpatient_rates.case_rates',
                    'value': val,
                    'bounds': (lo, hi),
                    'issue': 'below_minimum' if val < lo else 'above_maximum'
                })
    
    cap = ec.get('capitation_table', {}) or {}
    for cat_rate in (cap.get('rates_by_category') or []):
        val = cat_rate.get('rate_numeric')
        if val is not None:
            lo, hi = RATE_BOUNDS.get('capitation', (0, 1e9))
            if val < lo or val > hi:
                flags.append({
                    'field': 'capitation_table.rates_by_category',
                    'value': val,
                    'bounds': (lo, hi),
                    'issue': 'below_minimum' if val < lo else 'above_maximum'
                })
    
    return flags
```

### 2.4 Add Temporal Consistency Check

```python
# ═══ TEMPORAL CONSISTENCY ═══
def check_temporal_consistency(ec):
    """Verify date logic: effective < expiration, no future execution."""
    issues = []
    co = ec.get('contract_overview', {}) or {}
    
    eff = parse_date_flexible(co.get('effective_date'))
    exp = parse_date_flexible(co.get('expiration_date'))
    exe = parse_date_flexible(co.get('execution_date'))
    
    if eff and exp and eff >= exp:
        issues.append({
            'check': 'effective_before_expiration',
            'effective': str(eff),
            'expiration': str(exp),
            'issue': 'effective_date >= expiration_date'
        })
    
    if exe and exe > datetime.now():
        issues.append({
            'check': 'execution_not_future',
            'execution_date': str(exe),
            'issue': 'execution_date is in the future'
        })
    
    if eff and eff.year < 1990:
        issues.append({
            'check': 'effective_plausible',
            'effective': str(eff),
            'issue': 'effective_date before 1990 — likely extraction error'
        })
    
    if exp and exp.year > 2040:
        issues.append({
            'check': 'expiration_plausible',
            'expiration': str(exp),
            'issue': 'expiration_date after 2040 — likely extraction error'
        })
    
    return issues
```

### 2.5 Inline Version Dedup from Consolidation

Add to the TOP of `08_build_rates` (before loading JSON files):

```python
# ═══ VERSION DE-DUPLICATION (inlined from removed 07_consolidation) ═══
# When multiple extraction versions exist for same (provider, contract, doctype, date),
# keep only the highest version number.

def dedup_extraction_versions(json_files_dict):
    """Remove duplicate extraction versions. Keep highest version per key.
    
    Args:
        json_files_dict: dict of {filename: loaded_json_doc}
    Returns:
        filtered dict with duplicates removed
    """
    from collections import defaultdict
    
    dedup_groups = defaultdict(list)
    for fname, doc in json_files_dict.items():
        fm = doc.get('file_metadata', {})
        co = (doc.get('extracted_content') or {}).get('contract_overview', {}) or {}
        key = (
            fm.get('provider_id', ''),
            fm.get('contract_id', ''),
            fm.get('document_type', ''),
            co.get('effective_date', '')
        )
        dedup_groups[key].append(fname)
    
    keep = set()
    removed = 0
    for key, fnames in dedup_groups.items():
        if len(fnames) == 1:
            keep.add(fnames[0])
        else:
            # Sort by version number descending, keep highest
            def get_version(fn):
                m = re.search(r'_v(\d+)', fn)
                return int(m.group(1)) if m else 0
            sorted_fnames = sorted(fnames, key=get_version, reverse=True)
            keep.add(sorted_fnames[0])
            removed += len(sorted_fnames) - 1
    
    if removed > 0:
        print(f"  Version dedup: removed {removed} duplicate extractions")
    
    return {k: v for k, v in json_files_dict.items() if k in keep}
```

---

# PHASE 3: UNIFY SUPERSESSION (Days 11-17)
## Objective: ONE authoritative supersession implementation using scope classification

### 3.1 Design: Unified Supersession Function

The state engine (`platform/02_state_engine.py`) already has scope classification:
- `FULL_REPLACEMENT` — supersedes all rates from prior documents
- `EXHIBIT_SPECIFIC` — supersedes only rates in specific exhibits
- `RATE_SPECIFIC` — supersedes only rates matching specific categories
- `TERM_EXTENSION` — supersedes nothing (extends dates only)
- `SECTION_SPECIFIC` — supersedes specific clauses, not rates

The problem: this classification exists in `tbl_v2_amendment_registry` but is NEVER READ by the rate status computation.

### 3.2 Implementation: Wire Scope into Rate Status

Replace the `08_build_rates` 11a-fix supersession logic with scope-aware logic:

```python
# ═══ SCOPE-AWARE SUPERSESSION ═══
# Instead of: "latest amendment_order = current, everything else = superseded"
# Use: amendment_registry.scope_type to determine WHAT each amendment supersedes

from pyspark.sql import functions as F
from pyspark.sql.window import Window

SCHEMA = "dev_adb.raw"

# Load amendment registry (has scope classification)
amendment_reg = spark.table(f"{SCHEMA}.tbl_v2_amendment_registry").select(
    "source_filename", "scope_type", "scope_confidence"
)

# Load rates
rates_df = spark.table(f"{SCHEMA}.tbl_contract_rates_all")

# Join rates to their document's scope classification
rates_with_scope = rates_df.join(
    amendment_reg,
    on="source_filename",
    how="left"
).fillna({'scope_type': 'BASE_AGREEMENT', 'scope_confidence': 1.0})

# Supersession logic per scope type:
# FULL_REPLACEMENT: supersedes ALL rates from same provider with lower amendment_order
# EXHIBIT_SPECIFIC: supersedes rates from same provider + same rate_category
# RATE_SPECIFIC: supersedes rates matching same provider + same rate_category + service_category
# TERM_EXTENSION / SECTION_SPECIFIC: supersedes NOTHING (rates carry forward)

# Step 1: For FULL_REPLACEMENT amendments, mark all prior rates as superseded
w_provider = Window.partitionBy("provider_id").orderBy(F.col("amendment_order").desc())

# Get the max amendment_order per provider that is FULL_REPLACEMENT
full_replacements = rates_with_scope.filter(
    F.col("scope_type") == "FULL_REPLACEMENT"
).groupBy("provider_id").agg(
    F.max("amendment_order").alias("full_replace_order")
)

# Step 2: For RATE_SPECIFIC / EXHIBIT_SPECIFIC, supersede within category
w_category = Window.partitionBy(
    "provider_id", "rate_category"
).orderBy(F.col("amendment_order").desc())

rates_scored = rates_with_scope.join(
    full_replacements, on="provider_id", how="left"
).withColumn(
    "status_new",
    F.when(
        # If there's a full replacement after this rate, it's superseded
        (F.col("full_replace_order").isNotNull()) & 
        (F.col("amendment_order") < F.col("full_replace_order")) &
        (F.col("scope_type") != "FULL_REPLACEMENT"),
        F.lit("superseded")
    ).when(
        # For RATE_SPECIFIC/EXHIBIT_SPECIFIC: latest per category is current
        F.col("scope_type").isin("RATE_SPECIFIC", "EXHIBIT_SPECIFIC"),
        F.when(
            F.row_number().over(w_category) == 1,
            F.lit("current")
        ).otherwise(F.lit("superseded"))
    ).when(
        # TERM_EXTENSION: rates carry forward (never superseded by this doc)
        F.col("scope_type") == "TERM_EXTENSION",
        F.lit("current")  # keep existing status
    ).otherwise(
        # Default: latest amendment_order per provider = current
        F.when(
            F.row_number().over(w_provider) == 1,
            F.lit("current")
        ).otherwise(F.lit("superseded"))
    )
)

# Apply new status
rates_final = rates_scored.withColumn(
    "status", F.col("status_new")
).drop("status_new", "scope_type", "scope_confidence", "full_replace_order")

# Write back
rates_final.write.mode("overwrite").option("overwriteSchema", "true").saveAsTable(
    f"{SCHEMA}.tbl_contract_rates_all"
)
```

### 3.3 Fix State Engine Data Flow (Invert Dependency)

Currently:
```
json_extract → 08_build_rates → documents_master → 12_build_genie → amendment_timeline → state_engine
```

Target:
```
json_extract → 08_build_rates → documents_master → state_engine → (reads directly from documents_master)
```

Modify `platform/02_state_engine.py` to read from `tbl_contract_documents_master` directly instead of `tbl_genie_amendment_timeline`:

```python
# BEFORE (circular — reads from Genie table built from consolidated):
# FROM {FQ}.tbl_genie_amendment_timeline a

# AFTER (direct — reads from canonical document table):
spark.sql(f"""
INSERT INTO {FQ}.tbl_v2_contract_registry (...)
SELECT
    sha2(concat_ws('|', dm.provider_id, dm.source_filename), 256) AS contract_id,
    dm.provider_id,
    dm.provider_name,
    -- ... same classification logic ...
FROM {FQ}.tbl_contract_documents_master dm
WHERE dm.doc_role = 'base_agreement'
   OR dm.amendment_order = 0
QUALIFY ROW_NUMBER() OVER (PARTITION BY dm.provider_id, dm.source_filename ORDER BY dm.amendment_order) = 1
""")
```

---

# PHASE 4: OBSERVABILITY (Days 18-21)
## Objective: Structured telemetry replacing print statements

### 4.1 Create Validation Telemetry Table

```sql
CREATE TABLE IF NOT EXISTS dev_adb.raw.tbl_pipeline_telemetry (
  run_id STRING NOT NULL,
  run_timestamp TIMESTAMP NOT NULL,
  step_name STRING NOT NULL,
  filename STRING,
  provider_id STRING,
  check_name STRING,
  check_result STRING,           -- 'PASS' | 'FAIL' | 'WARN' | 'SKIP'
  severity STRING,               -- 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW' | 'INFO'
  detail_json STRING,
  metric_name STRING,
  metric_value DOUBLE,
  action_taken STRING,           -- 'enriched' | 'quarantined' | 'flagged' | 'passed'
  elapsed_seconds DOUBLE
)
USING DELTA
COMMENT 'Pipeline telemetry for extraction, validation, and build steps. One row per check per file per run.';
```

### 4.2 Telemetry Helper Function

Add to `extraction/_config` (shared config notebook):

```python
import uuid
from datetime import datetime, timezone

_CURRENT_RUN_ID = str(uuid.uuid4())
_TELEMETRY_BUFFER = []
_TELEMETRY_TABLE = "dev_adb.raw.tbl_pipeline_telemetry"

def log_telemetry(step_name, check_name, check_result, 
                  filename=None, provider_id=None, severity='INFO',
                  detail=None, metric_name=None, metric_value=None,
                  action_taken=None, elapsed=None):
    """Buffer a telemetry event for batch write."""
    _TELEMETRY_BUFFER.append({
        'run_id': _CURRENT_RUN_ID,
        'run_timestamp': datetime.now(timezone.utc).isoformat(),
        'step_name': step_name,
        'filename': filename,
        'provider_id': provider_id,
        'check_name': check_name,
        'check_result': check_result,
        'severity': severity,
        'detail_json': json.dumps(detail) if detail else None,
        'metric_name': metric_name,
        'metric_value': metric_value,
        'action_taken': action_taken,
        'elapsed_seconds': elapsed,
    })

def flush_telemetry():
    """Write buffered telemetry to Delta table."""
    if not _TELEMETRY_BUFFER:
        return
    df = spark.createDataFrame(_TELEMETRY_BUFFER)
    df.write.mode("append").saveAsTable(_TELEMETRY_TABLE)
    n = len(_TELEMETRY_BUFFER)
    _TELEMETRY_BUFFER.clear()
    print(f"  📊 Flushed {n} telemetry events to {_TELEMETRY_TABLE}")
```

---

# PHASE 5: ORCHESTRATION (Days 22-28)
## Objective: Databricks Workflow DAG replacing manual notebook execution

### 5.1 Job Design

```
Job: Contract_Codification_Pipeline_Daily
Schedule: Mon-Fri 2:00 AM PT (or on-demand trigger)
Cluster: Shared Compute Cluster - Analysts

DAG:
  Task 1: 01_file_discovery
    → Task 2: 02_ocr_extraction
      → Task 3: 03_metadata_parsing
        → Task 4: 04_llm_prompts + 05_llm_extraction (parallel would be ideal but sequential fine)
          → Task 5: 06_validation (with quarantine gate)
            → Task 6: 08_build_rates (includes inlined dedup from removed 07)
              → Task 7: 09_build_terms
                → Task 8: 10_build_documents
                  → Task 9: 11_enrich_tables
                    → Task 10: 12_build_genie
                      → Task 11: platform/02_state_engine.py
                        → Task 12: 14_quality_audit (sample mode, 10 files)

Parameters:
  force_rebuild: false (default)
  sample_size: 10 (for quality audit)
  audit_mode: sample
```

### 5.2 Create Job via Databricks CLI or UI

```python
# Use Databricks SDK to create the job programmatically
from databricks.sdk import WorkspaceClient

w = WorkspaceClient()

notebook_base = "/Users/adixit01@blueshieldca.com/Contract_Codification_Pipeline/extraction"

tasks = [
    {"task_key": "file_discovery", "notebook": f"{notebook_base}/01_file_discovery"},
    {"task_key": "ocr_extraction", "notebook": f"{notebook_base}/02_ocr_extraction", "depends_on": ["file_discovery"]},
    {"task_key": "metadata_parsing", "notebook": f"{notebook_base}/03_metadata_parsing", "depends_on": ["ocr_extraction"]},
    {"task_key": "llm_extraction", "notebook": f"{notebook_base}/05_llm_extraction", "depends_on": ["metadata_parsing"]},
    {"task_key": "validation", "notebook": f"{notebook_base}/06_validation", "depends_on": ["llm_extraction"]},
    {"task_key": "build_rates", "notebook": f"{notebook_base}/08_build_rates", "depends_on": ["validation"]},
    {"task_key": "build_terms", "notebook": f"{notebook_base}/09_build_terms", "depends_on": ["build_rates"]},
    {"task_key": "build_documents", "notebook": f"{notebook_base}/10_build_documents", "depends_on": ["build_terms"]},
    {"task_key": "enrich_tables", "notebook": f"{notebook_base}/11_enrich_tables", "depends_on": ["build_documents"]},
    {"task_key": "build_genie", "notebook": f"{notebook_base}/12_build_genie", "depends_on": ["enrich_tables"]},
    {"task_key": "state_engine", "notebook": "/Users/adixit01@blueshieldca.com/Contract_Codification_Pipeline/platform/02_state_engine", "depends_on": ["build_genie"]},
]
```

### 5.3 Add Job Alerting

Configure email/Slack notification on:
- Task failure (any task)
- Quarantine gate triggers (>5 files quarantined)
- Quality audit score drops below 60 average

---

# PHASE 6: GENIE VIEW CONVERSION (Days 29-30)
## Objective: Replace Genie materialized tables with views on canonical tables

### 6.1 Convert `tbl_genie_amendment_timeline` to View

```sql
CREATE OR REPLACE VIEW dev_adb.raw.vw_genie_amendment_timeline AS
SELECT
  provider_id,
  provider_name,
  source_filename,
  document_type,
  doc_role,
  amendment_order,
  effective_date,
  effective_date_parsed,
  expiration_date,
  agreement_title,
  v6_coverage_pct,
  doc_category,
  summary_of_changes
FROM dev_adb.raw.tbl_contract_documents_master
ORDER BY provider_id, amendment_order;

-- Update Genie Space to reference vw_genie_amendment_timeline
-- Then drop the table:
-- DROP TABLE dev_adb.raw.tbl_genie_amendment_timeline;
```

### 6.2 Convert `tbl_genie_rates_current` to View

```sql
CREATE OR REPLACE VIEW dev_adb.raw.vw_genie_rates_current AS
SELECT
  c.canonical_name AS provider_name,
  c.primary_provider_id AS provider_id,
  r.rate_category,
  r.service_category,
  r.rate_type_detail,
  r.rate_text,
  r.rate_numeric,
  r.revenue_codes,
  r.effective_date,
  r.effective_date_parsed,
  r.program,
  r.network,
  r.formula,
  r.notes,
  r.program_normalized,
  r.source_table
FROM dev_adb.raw.tbl_contract_rates_all r
JOIN dev_adb.raw.dim_provider_canonical c
  ON r.provider_id = c.provider_id
WHERE r.status = 'current'
  AND r.is_latest_version = true
  AND r.rate_text IS NOT NULL
  AND r.rate_text != '';

-- Validate row count matches current table before switching:
-- SELECT COUNT(*) FROM dev_adb.raw.tbl_genie_rates_current;      -- ~5000
-- SELECT COUNT(*) FROM dev_adb.raw.vw_genie_rates_current;        -- should be similar
```

---

# VALIDATION CHECKLIST

After completing all phases, verify:

```sql
-- 1. Rates table has correct status distribution
SELECT status, COUNT(*) FROM dev_adb.raw.tbl_contract_rates_all GROUP BY status;
-- Expected: ~60% superseded, ~40% current

-- 2. No empty dropped tables remain
SHOW TABLES IN dev_adb.raw LIKE '*bitemporal*';  -- should return nothing
SHOW TABLES IN dev_adb.raw LIKE '*formula_components*';  -- should return nothing

-- 3. Telemetry table receiving data
SELECT COUNT(*) FROM dev_adb.raw.tbl_pipeline_telemetry WHERE run_timestamp > current_date() - 1;

-- 4. Genie Space still answers queries correctly
-- Test: "What is the ICU per diem rate for St Joseph's?"
-- Test: "Show me the amendment timeline for Kaweah Delta"
-- Test: "What providers have the highest stop-loss thresholds?"

-- 5. State engine reads from documents_master (not amendment_timeline)
-- Check: platform/02_state_engine.py source query references tbl_contract_documents_master

-- 6. Quarantine directory exists and captures bad files
-- ls /Workspace/Users/adixit01@blueshieldca.com/Contract_Codification_Pipeline/data/json_extract/_quarantine/
```

---

# SUCCESS CRITERIA (Day 30)

| Metric | Before | After |
| --- | --- | --- |
| Lines of platform code | ~6,500 | ~3,000 |
| Empty tables | 6 | 0 |
| Supersession implementations | 3 | 1 |
| Rate table representations | 5 | 3 (rates_all + reimb_rate_rules + view) |
| Orchestration | Manual | Scheduled DAG |
| Observability | Print to stdout | Delta telemetry + alerting |
| Validation enforcement | Flags only | Quarantine gate blocks bad files |
| Circular dependencies | 2 | 0 |
| Fabricated intelligence tables | 4 | 0 |
| Genie tables (should be views) | 4 | 2 tables + 2 views |

---

# FUTURE PHASES (Month 2-6)

## Month 2: Scale Extraction
- Process PDFs 200-1,200 (10× current)
- Monitor quality via telemetry
- Tune quarantine thresholds based on observed patterns
- Benchmark run cost and time

## Month 3: Retrieval Layer
- Deploy VS index for legal clause search
- Build query router (structured→SQL, narrative→VS+LLM)
- Replace Genie-only serving with hybrid system

## Month 4: Claims Integration
- Connect claims data feed (when CLAIMS_AVAILABLE flips to True)
- Build real spend calculation: rate × actual utilization
- Validate extracted rates against paid claims

## Month 5: Real Intelligence
- Rebuild benchmarks from full corpus
- Compute real savings (rate vs. benchmark × volume)
- Build renewal priority from contract expiry + spend significance
- Ship to contracting team

## Month 6: Enterprise Hardening
- RBAC for provider data segmentation
- Audit trail for all rate queries
- SLA monitoring (query latency, freshness)
- Compliance documentation
- Prepare for broader organizational rollout

---

# ANTI-PATTERNS TO AVOID

1. **Do NOT build new intelligence modules** until 100% corpus is processed and claims are connected
2. **Do NOT create new tables** when a view would suffice — ask "will this drift from its source?"
3. **Do NOT add supersession logic anywhere** except the unified state engine
4. **Do NOT store computed status in JSON files** — status belongs in Delta tables only
5. **Do NOT use STRING for dates** in any new table or column
6. **Do NOT denormalize provider_name** onto fact tables — always join to dim_provider_canonical
7. **Do NOT add design documents** for features that won't be implemented this quarter
8. **Do NOT build serving tables** that are just filtered copies of base tables — use views
9. **Do NOT process all 10K PDFs at once** — batch in groups of 500, validate quality between batches
10. **Do NOT deploy retrieval/RAG** until VS index is validated against golden queries
