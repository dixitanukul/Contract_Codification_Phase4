# STATE ENGINE DEEP REVIEW
## V2 Contract State Engine — Correctness, Reliability, and Integration Assessment
**Generated**: 2026-05-24  
**Scope**: Deep evaluation of state reconstruction, supersession, temporal logic  
**Source Files Reviewed**: 02_state_engine.py, state_engine_ddl.sql, 08_build_rates(fix), 6 design docs

---

## 1. DESIGN INTENT VS. IMPLEMENTATION REALITY

### What Was Designed (6 Design Docs)

The design documents describe a **6-stage computation pipeline**:

```
Stage 1: CONTRACT DISCOVERY      → Identify distinct contracts per provider
Stage 2: AMENDMENT CLASSIFICATION → Classify amendment scope (6 types)
Stage 3: FACT INGESTION          → Load rates/clauses into bitemporal model
Stage 4: SUPERSESSION RESOLUTION → Execute 4-pass algorithms per contract
Stage 5: STATE MATERIALIZATION   → Set valid_to, compute is_current
Stage 6: VALIDATION & AUDIT      → Invariant checks, comparison to V1
```

Supporting architectures designed:
- **Bitemporal model**: valid_time (when true) + transaction_time (when learned)
- **DAG graph model**: Amendments as directed edges with scope edges
- **4-pass supersession**: Document → Exhibit → Rate-line → Clause level
- **Point-in-time queries**: SQL functions for temporal reconstruction

### What Is Actually Implemented

```
Stage 1: CONTRACT DISCOVERY      → ✓ Implemented (02_state_engine.py)
Stage 2: AMENDMENT CLASSIFICATION → ✓ Implemented (02_state_engine.py)
Stage 3: FACT INGESTION          → ✗ NOT IMPLEMENTED (table exists, never populated)
Stage 4: SUPERSESSION RESOLUTION → ✗ NOT IMPLEMENTED (table exists, never populated)
Stage 5: STATE MATERIALIZATION   → PARTIAL (is_current set in 08_build_rates fix, not in bitemporal)
Stage 6: VALIDATION & AUDIT      → ✗ NOT IMPLEMENTED
```

**Implementation gap**: Only 2 of 6 stages exist. The entire bitemporal model, supersession algorithm, and audit trail are schema-only.

---

## 2. CONTRACT REGISTRY MODELING

### Implementation (02_state_engine.py, lines 47-99)

```sql
INSERT INTO tbl_v2_contract_registry (...)
SELECT
    sha2(concat_ws('|', a.provider_id, a.source_filename), 256) AS contract_id,
    ...
FROM tbl_contract_documents_master a
WHERE a.amendment_order = 0
   OR a.doc_role = 'base_agreement'
QUALIFY ROW_NUMBER() OVER (PARTITION BY a.provider_id, a.source_filename ORDER BY a.amendment_order) = 1
```

### Assessment

**Strengths**:
- Deterministic contract_id (SHA-256 of provider_id|source_filename) — idempotent
- Status derivation is simple and correct (expiration_date < current_date → EXPIRED, else ACTIVE)
- Agreement type normalization (capitation, fee_for_service, settlement, mixed)
- Payment model classification (per_diem, case_rate, percentage, pmpm)
- Correlated subqueries compute total_amendments and latest_amendment info

**Weaknesses**:

1. **Contract identity is wrong**: `sha2(provider_id|source_filename)` means one contract per base agreement FILE. But a single provider may have ONE legal agreement with ONE base agreement PDF. Two base agreement files for the same provider create two "contracts" even if the second was just a re-scan or format update.

2. **No multi-contract detection**: The design doc states "Most providers (85%+) have exactly 1 contract. Some have 2-3." But the implementation doesn't detect whether a provider with 2 base agreement PDFs truly has 2 contracts or just 1 contract with a re-stated version.

3. **Status is binary**: Only ACTIVE or EXPIRED. Design doc calls for ACTIVE, TERMINATED, EXPIRED, SUPERSEDED. No distinction between:
   - Contract reached end of term (EXPIRED)
   - Contract was terminated early (TERMINATED)
   - Contract was replaced by a new agreement (SUPERSEDED)

4. **No multi-provider contracts**: A single contract can involve multiple providers (e.g., IPA umbrella agreements). This model is strictly 1 contract per provider_id × source_filename.

5. **Row count instability**: 685 contracts in one run vs 1,948 in another. The `WHERE amendment_order = 0 OR doc_role = 'base_agreement'` filter is fragile — depends on extraction consistency of amendment_order and doc_role values.

6. **No contract grouping logic**: The design calls for grouping documents into contracts by:
   - Explicit base_agreement_reference in amendments_impact
   - Filename prefix matching (same contract_id in filename)
   - Temporal proximity + agreement_type matching
   
   None of this is implemented. The current approach is: "each base agreement file = one contract."

### Correctness Rating: 5/10
- Correctly identifies most base agreements
- Incorrect when providers have multiple base agreement files for the same logical contract
- Incorrect status classification (missing TERMINATED/SUPERSEDED)
- Unstable row counts between runs

---

## 3. AMENDMENT REGISTRY MODELING

### Implementation (02_state_engine.py, lines 112-162)

```sql
INSERT INTO tbl_v2_amendment_registry (...)
SELECT
    sha2(concat_ws('|', a.provider_id, a.source_filename), 256) AS amendment_id,
    sha2(concat_ws('|', a.provider_id,
        COALESCE((SELECT x.source_filename FROM tbl_contract_documents_master x
         WHERE x.provider_id = a.provider_id
           AND (x.amendment_order = 0 OR x.doc_category = 'Base Agreement')
         ORDER BY x.amendment_order LIMIT 1), a.source_filename)), 256) AS contract_id,
    ...
    CASE
        WHEN LENGTH(a.exhibits_replaced_count) > 30 AND a.prior_rates_superseded = 'True' THEN 'FULL_REPLACEMENT'
        WHEN LENGTH(a.exhibits_replaced_count) > 4 THEN 'EXHIBIT_SPECIFIC'
        WHEN a.prior_rates_superseded = 'True' THEN 'RATE_SPECIFIC'
        WHEN LENGTH(a.sections_modified_count) > 4 THEN 'SECTION_SPECIFIC'
        WHEN a.document_type ILIKE '%extension%' OR a.document_type ILIKE '%renewal%' THEN 'TERM_EXTENSION'
        WHEN a.document_type ILIKE '%addendum%' THEN 'ADDENDUM'
        WHEN a.rate_count > 10 THEN 'FULL_REPLACEMENT'
        WHEN a.rate_count > 0 THEN 'RATE_SPECIFIC'
        ELSE 'SECTION_SPECIFIC'
    END AS scope_type,
```

### Scope Classification — Detailed Critique

**The STRING LENGTH heuristic is the most problematic design decision:**

```sql
LENGTH(a.exhibits_replaced_count) > 30  -- Intended: "many exhibits replaced"
LENGTH(a.exhibits_replaced_count) > 4   -- Intended: "at least one exhibit replaced"
```

`exhibits_replaced_count` is a STRING containing a JSON array like `["Exhibit A", "Exhibit B"]`.

| JSON Value | LENGTH | Classified As |
|-----------|--------|---------------|
| `null` or empty | 0 | Falls through |
| `[]` | 2 | Falls through (< 4) |
| `["A"]` | 5 | EXHIBIT_SPECIFIC (> 4, correct) |
| `["Exhibit B"]` | 14 | EXHIBIT_SPECIFIC (> 4, correct) |
| `["Exhibit A", "Exhibit B"]` | 28 | EXHIBIT_SPECIFIC (NOT > 30, correct) |
| `["Exhibit A", "Exhibit B", "Exhibit C"]` | 42 | FULL_REPLACEMENT (> 30) |

**Problem**: A length > 30 threshold for FULL_REPLACEMENT means:
- 3 short exhibit names → FULL_REPLACEMENT (possibly incorrect — could be 3 of 10 exhibits)
- 1 long exhibit name (e.g., `["Exhibit A - Inpatient Hospital Services Rate Schedule"]`) → length 62 → FULL_REPLACEMENT (definitely incorrect — one exhibit ≠ full replacement)

**The correct approach**: Parse the JSON array and COUNT elements:
```sql
CASE
    WHEN size(from_json(exhibits_replaced_count, 'ARRAY<STRING>')) >= 5 THEN 'FULL_REPLACEMENT'
    WHEN size(from_json(exhibits_replaced_count, 'ARRAY<STRING>')) >= 1 THEN 'EXHIBIT_SPECIFIC'
```

### Contract Linkage — Critique

The contract_id FK uses a correlated subquery:
```sql
sha2(concat_ws('|', a.provider_id,
    COALESCE((SELECT x.source_filename FROM tbl_contract_documents_master x
     WHERE x.provider_id = a.provider_id
       AND (x.amendment_order = 0 OR x.doc_category = 'Base Agreement')
     ORDER BY x.amendment_order LIMIT 1), a.source_filename)), 256) AS contract_id
```

**Problem**: This finds the FIRST base agreement for the provider. If a provider has 2 base agreements (e.g., separate capitation and FFS contracts), ALL amendments link to the first one. There's no logic to determine which contract an amendment belongs to.

### Confidence Scoring — Critique

```sql
CASE
    WHEN LENGTH(exhibits_replaced_count) > 4 OR prior_rates_superseded = 'True' THEN 0.85
    WHEN LENGTH(sections_modified_count) > 4 THEN 0.75
    WHEN document_type ILIKE '%extension%' THEN 0.90
    ELSE 0.60
END
```

**Problems**:
- Confidence is hardcoded, not calibrated against human judgment
- 0.60 for "else" means every amendment that falls through has moderate confidence even though classification is essentially random
- No mechanism to improve confidence over time (no human feedback loop)
- Confidence doesn't vary by the QUALITY of the input signal (e.g., prior_rates_superseded could be a hallucinated string vs a verified extraction)

### Correctness Rating: 6/10
- Scope taxonomy is correct (6 types are comprehensive)
- Classification heuristics are directionally useful but technically flawed
- Contract linkage fails for multi-contract providers
- Confidence scoring is informational only (never used in downstream logic)

---

## 4. TEMPORAL LOGIC ASSESSMENT

### Current Implementation

The state engine has **no temporal logic** beyond:
1. `effective_from` / `effective_to` on contract_registry (populated from extraction)
2. `effective_date` on amendment_registry (populated from extraction)
3. `state_computed_at` timestamp (audit only)

### What's Missing

| Temporal Capability | Designed | Implemented | Impact |
|---------------------|----------|-------------|--------|
| valid_from / valid_to on rate facts | YES | NO | Cannot determine when a rate was valid |
| tx_from / tx_to on rate facts | YES | NO | Cannot audit system belief history |
| Point-in-time rate queries | YES | NO | Cannot answer "what rates were in effect on date X?" |
| Rate history reconstruction | YES | NO | Cannot show rate change timeline |
| Retroactive amendment handling | YES | NO | Cannot model amendments effective before execution date |
| Delta reports (period A vs period B) | YES | NO | Cannot show what changed between dates |

### Temporal Modeling in V1 (What Currently Exists)

The V1 system uses a **document-level temporal heuristic**:
```python
# From 08_build_rates fix:
# All rates from the latest document = "current"
# All rates from prior documents = "superseded"
# EXCEPT: scope-aware amendment handling (if state engine has run)
```

The scope-aware fix (lines 45-75 in the rates fix cell) is the ONLY place where V2 state engine outputs influence temporal state:
```python
# If the latest FULL_REPLACEMENT amendment is at order=5:
#   All rates from documents with order < 5 are superseded
#   Rates from TERM_EXTENSION amendments remain current
```

This is a significant improvement over pure "latest wins" but still coarse — it operates at document level, not rate-line level.

### Assessment

**The platform cannot reliably answer temporal questions because:**
1. No bitemporal fact storage exists (tables created but empty)
2. Rate validity is binary (current/superseded) not temporal (valid_from/valid_to)
3. No mechanism to determine WHEN a specific rate was superseded
4. No mechanism to reconstruct state at a historical date
5. Effective dates are STRING with inconsistent formats (not queryable as DATE)

### Temporal Correctness Rating: 2/10
- Can distinguish current vs superseded (binary)
- Cannot determine WHEN supersession occurred
- Cannot reconstruct historical state
- Cannot handle retroactive amendments

---

## 5. SUPERSESSION LOGIC — DEEP ANALYSIS

### Designed: 4-Pass Resolution Algorithm

```
Pass 1: DOCUMENT-LEVEL → "replaces and supersedes" language detection
Pass 2: EXHIBIT-LEVEL → Specific exhibit replacement/modification
Pass 3: RATE-LINE PAIRING → Individual rate supersession matching
Pass 4: CLAUSE-LEVEL → Semantic clause matching across amendments
```

### Implemented: Coarse Scope-Aware Heuristic

```python
# In 08_build_rates fix (lines 45-75):
if has_scope:  # If state engine has populated amendment_registry
    # Find the latest FULL_REPLACEMENT amendment order
    full_replace_order = max(order WHERE scope_type = 'FULL_REPLACEMENT')
    
    # All rates from documents BEFORE full_replace_order → superseded
    # TERM_EXTENSION documents → current (they extend, not replace)
    # Otherwise: latest document wins
```

### Gap Analysis

| Algorithm | Designed | Implemented | Error Mode |
|-----------|----------|-------------|-----------|
| Pass 1: Document-level full replacement | YES | PARTIAL — detects via scope_type but doesn't preserve individual rates from partial amendments | Over-supersession: kills rates from partial amendments that happened before the full replacement |
| Pass 2: Exhibit-level replacement | YES | NO — exhibits_modified stored but never used in supersession | Under-supersession: rates from replaced exhibits remain "current" |
| Pass 3: Rate-line pairing | YES | NO | Under-supersession: duplicate rate lines (same service, different amounts) both marked "current" |
| Pass 4: Clause-level matching | YES | NO | Under-supersession: same clause from base + amendment both in corpus |

### Concrete Error Examples

**Error 1: Over-supersession (current system)**
```
Provider: Hospital X
- Base Agreement (2019): 50 rates across Exhibits A, B, C, D
- Amendment 1 (2020): Modifies Exhibit B only (5 rates)
- Amendment 2 (2021): Modifies Exhibit D only (3 rates)

V1 RESULT (document-level "latest wins"):
  Amendment 2 is latest → ONLY 3 rates marked current
  47 other rates marked superseded (WRONG — Exhibits A, B, C rates are still valid)

V2 RESULT (scope-aware, if no FULL_REPLACEMENT):
  If Amendment 2 is EXHIBIT_SPECIFIC for Exhibit D:
    Amendment 2's 3 rates = current
    Amendment 1's 5 Exhibit B rates = ??? (depends on amendment_order logic)
    Base's 42 rates from A, C = ??? (may or may not be current)
```

The scope-aware fix still falls back to `doc_order == max_order → current` for non-FULL_REPLACEMENT cases, which means only the LATEST document's rates survive.

**Error 2: Under-supersession (missing exhibit-level logic)**
```
Provider: Hospital Y
- Base Agreement: Exhibit B has rate=$1,200/day for Med/Surg
- Amendment 3: "Exhibit B is replaced in its entirety" with rate=$1,350/day for Med/Surg

CURRENT BEHAVIOR:
  Both $1,200 and $1,350 may appear as "current" if:
  - Amendment 3 is scope_type=EXHIBIT_SPECIFIC (correct)
  - But no rate-line pairing logic exists to mark the $1,200 as superseded by $1,350
  
  The V8 dedup in 12_build_genie may catch this (partitions by rate_numeric + category)
  but only if rate_category is identical between base and amendment
```

**Error 3: Phantom rates (rates that never existed)**
```
Provider: Hospital Z
- Amendment 5: FULL_REPLACEMENT (restates entire agreement)
- Amendment 6: TERM_EXTENSION (extends term 2 years)

CURRENT BEHAVIOR:
  scope-aware logic: TERM_EXTENSION rates stay current
  But TERM_EXTENSION documents typically have NO rates (they just extend dates)
  If they DO have rates (e.g., a cover letter mentions one rate), that rate
  appears "current" even though it's just a reference, not a new contractual provision
```

### Supersession Correctness Rating: 4/10
- FULL_REPLACEMENT detection works for the simple case
- EXHIBIT_SPECIFIC scope identified but never used in rate supersession
- No rate-line level pairing (the design's Pass 3)
- No clause-level matching (the design's Pass 4)
- Systematic over-supersession for multi-amendment providers

---

## 6. CAN THE STATE ENGINE RELIABLY ANSWER THESE QUESTIONS?

| Question | Can Answer? | Confidence | Why |
|----------|------------|-----------|-----|
| **Current contract state** (active/expired) | YES | HIGH | Simple date comparison, works correctly |
| **Historical contract state** (state at date X) | NO | N/A | No temporal storage; only current snapshot |
| **Amendment history** (ordered list) | YES | HIGH | amendment_order + documents_master provides this |
| **Which clauses are active** | PARTIALLY | LOW | is_from_latest_doc flag exists but uses document-level heuristic |
| **Which rates are superseded** | PARTIALLY | MEDIUM | Scope-aware for FULL_REPLACEMENT; falls back to document-level otherwise |
| **Which provisions are valid today** | PARTIALLY | LOW | Binary current/superseded; no temporal validity periods |
| **Which amendments override others** | SCOPE ONLY | MEDIUM | scope_type classifies WHAT was modified but doesn't resolve specific supersessions |
| **Rate at a specific historical date** | NO | N/A | No valid_from/valid_to on individual rates |
| **What changed in amendment X** | PARTIALLY | MEDIUM | summary_of_changes (LLM text), exhibits_modified (JSON) |
| **Is this clause still in force** | NO | N/A | No clause-level supersession tracking |

---

## 7. HALLUCINATION PATHWAYS

| Pathway | Mechanism | Severity | Likelihood |
|---------|-----------|----------|-----------|
| **Scope misclassification** | STRING LENGTH heuristic marks EXHIBIT_SPECIFIC as FULL_REPLACEMENT | HIGH | 15-20% of amendments with long exhibit names |
| **Ghost supersession** | FULL_REPLACEMENT detected via LENGTH>30 kills all prior rates even when only 3 exhibits actually replaced | HIGH | Occurs whenever 3+ exhibit names appear in JSON |
| **Missing supersession** | Amendment replaces Exhibit B but scope classified as SECTION_SPECIFIC → old Exhibit B rates remain "current" | HIGH | Occurs when exhibits_replaced_count is NULL but sections_modified has content |
| **Contract mis-linking** | All amendments link to first base agreement; second contract's amendments orphaned | MEDIUM | Affects 15% of providers (multi-contract) |
| **Confidence inflation** | 0.85 confidence for STRING length match suggests high reliability when actual accuracy is ~70% | MEDIUM | All scope classifications |
| **Status binary** | Contract marked ACTIVE when actually terminated (no termination detection) | MEDIUM | Affects providers with early termination notices |
| **LLM extraction propagation** | prior_rates_superseded = 'True' may be LLM hallucination (not verified) | MEDIUM | 36 unverified dates already flagged in extraction |

---

## 8. MISSING CONCEPTS

### 8.1 Concepts Missing from Implementation

| Concept | Design Status | Implementation Status | Impact of Absence |
|---------|--------------|----------------------|-------------------|
| Bitemporal fact storage | Fully designed | Schema only | Cannot answer temporal queries |
| Rate-line pairing (matching old rate to new rate) | Algorithm specified | Not coded | Duplicate rates both "current" |
| Clause identity matching | Hash-based design | Not coded | Same clause from multiple docs all in corpus |
| Supersession decision audit trail | Table + schema | Empty table | Cannot explain WHY a rate was marked superseded |
| DAG amendment graph | Full architecture doc | Not coded | Cannot represent independent amendment paths |
| Zero-current guard | Mentioned in design | Not coded | Provider could have 0 current rates (data loss) |
| Conflict resolution (contradictory amendments) | Mentioned | Not coded | No handling of conflicting provisions |
| Multi-contract detection | Designed | Not coded | All amendments go to first base agreement |
| Point-in-time functions | SQL functions designed | Not coded | No API for historical queries |
| Validation against V1 | Designed as Stage 6 | Not coded | No confidence in correctness |

### 8.2 Concepts Missing from Design

| Concept | Why It's Needed | Impact |
|---------|----------------|--------|
| **Explicit supersession language detection** | Amendments often say "Section X.Y is hereby deleted" or "Exhibit B is replaced in its entirety" — this text should be parsed, not just summarized | Would enable confident exhibit-level supersession |
| **Rate continuity assumption** | If Amendment 5 replaces Exhibit B with 10 rates, and the old Exhibit B had 10 rates in the same categories, this is a rate UPDATE not a net new | Reduces false "new rate" detection |
| **Effective date propagation** | When an amendment takes effect, its rates should inherit the amendment's effective_date as valid_from | Currently effective_date is per-rate but often NULL |
| **Termination notice processing** | Termination notices in the corpus should trigger status=TERMINATED | Currently only expiration triggers status change |
| **Evergreen contract handling** | Auto-renewal contracts with no expiration_date need different status logic | Currently NULL expiration → ACTIVE forever |
| **IPA delegation chain** | IPA contracts delegate to sub-providers; amendment to IPA affects downstream | No delegation modeling |

---

## 9. BETTER MODELING APPROACHES

### Approach 1: Event-Sourced State Machine (Recommended)

Instead of computing state from a heuristic, model each amendment as an **event** that transitions contract state:

```
State Machine:
  DRAFT → EXECUTED → ACTIVE → {AMENDED, RENEWED, TERMINATED, EXPIRED}
  AMENDED → ACTIVE (after amendment applied)

Events:
  ContractSigned(provider, effective_date, exhibits[])
  AmendmentApplied(contract, scope, effective_date, exhibits_replaced[], rates_changed[])
  TermNoticeReceived(contract, termination_date, reason)
  ContractExpired(contract, expiration_date)
  ContractRenewed(contract, new_term_end)
```

**Advantages**:
- Every state transition is explicit and auditable
- Can replay event history to reconstruct any point-in-time
- New amendment types (e.g., "partial termination") add new event types without refactoring

### Approach 2: Exhibit-Level Versioning (Pragmatic)

Instead of tracking individual rates, version at the EXHIBIT level:

```sql
CREATE TABLE exhibit_versions (
    exhibit_version_id  STRING,
    contract_id         STRING,
    exhibit_name        STRING,    -- "Exhibit B", "Exhibit D-1"
    version_number      INT,       -- 1=base, 2=first amendment, etc.
    introduced_by       STRING,    -- amendment_id that created this version
    supersedes          STRING,    -- previous exhibit_version_id (NULL for base)
    effective_date      DATE,
    is_current          BOOLEAN,
    source_filename     STRING
);
```

**Advantages**:
- Matches how contracts actually work (amendments replace exhibits, not individual rates)
- Supersession is explicit: each exhibit version points to what it replaces
- Simple to implement (no rate-line pairing algorithms needed)
- Naturally handles "Exhibit B is replaced in its entirety"

### Approach 3: Hybrid (Design-Compatible Enhancement)

Enhance the existing implementation without redesigning:

```python
# STEP 1: Fix scope classification (parse JSON, count elements)
# STEP 2: Add exhibit_version tracking (new table, simple)
# STEP 3: Implement rate-line pairing for same-exhibit rates
# STEP 4: Add supersession_decisions logging
# STEP 5: Implement zero-current guard (every provider must have ≥1 current rate)
```

This preserves the existing schema and adds correctness incrementally.

---

## 10. ENTERPRISE REDESIGN RECOMMENDATIONS

### Priority 1: Fix Scope Classification (2 hours)

Replace STRING LENGTH heuristics with proper JSON parsing:

```sql
-- BEFORE (fragile):
WHEN LENGTH(a.exhibits_replaced_count) > 30 THEN 'FULL_REPLACEMENT'

-- AFTER (correct):
WHEN try_size(from_json(a.exhibits_replaced_count, 'ARRAY<STRING>')) >= total_exhibits_count * 0.8 THEN 'FULL_REPLACEMENT'
WHEN try_size(from_json(a.exhibits_replaced_count, 'ARRAY<STRING>')) >= 1 THEN 'EXHIBIT_SPECIFIC'
```

### Priority 2: Implement Exhibit-Level Versioning (8 hours)

```sql
CREATE TABLE dev_adb.raw.tbl_v2_exhibit_versions (
    exhibit_version_id  STRING NOT NULL,
    contract_id         STRING NOT NULL,
    exhibit_name        STRING NOT NULL,
    version_number      INT NOT NULL,
    introduced_by_amendment STRING,
    supersedes_version  STRING,
    effective_date      DATE,
    is_current          BOOLEAN NOT NULL,
    rate_count          INT,
    source_filename     STRING NOT NULL,
    created_at          TIMESTAMP
) USING DELTA;
```

Population logic:
1. Each base agreement's rates grouped by exhibit_reference → version 1
2. Each EXHIBIT_SPECIFIC amendment creates version N+1 for its exhibits
3. Each FULL_REPLACEMENT creates new versions for ALL exhibits
4. Previous versions get is_current = FALSE

### Priority 3: Add Zero-Current Guard (1 hour)

```python
def zero_current_guard():
    """Ensure every provider has at least 1 current rate."""
    providers_without_current = spark.sql("""
        SELECT provider_id, COUNT(*) as total_rates
        FROM tbl_contract_rates_all
        WHERE provider_id NOT IN (
            SELECT DISTINCT provider_id FROM tbl_contract_rates_all WHERE status = 'current'
        )
        GROUP BY provider_id
    """).collect()
    
    for row in providers_without_current:
        # Promote the latest document's rates to current
        spark.sql(f"""
            UPDATE tbl_contract_rates_all
            SET status = 'current'
            WHERE provider_id = '{row.provider_id}'
              AND source_filename = (
                SELECT source_filename FROM tbl_contract_documents_master
                WHERE provider_id = '{row.provider_id}'
                ORDER BY amendment_order DESC LIMIT 1
              )
        """)
```

### Priority 4: Implement Contract Grouping (4 hours)

```python
def group_amendments_to_contracts(provider_id):
    """Link amendments to their parent contract using multiple signals."""
    base_agreements = get_base_agreements(provider_id)
    amendments = get_amendments(provider_id)
    
    for amendment in amendments:
        # Signal 1: Explicit reference (highest confidence)
        explicit_ref = amendment.amendments_impact.get('base_agreement_reference')
        if explicit_ref and matches_any(explicit_ref, base_agreements):
            link(amendment, find_match(explicit_ref, base_agreements), confidence=0.95)
            continue
        
        # Signal 2: Contract ID prefix in filename
        contract_prefix = extract_contract_id(amendment.source_filename)
        matching_bases = [b for b in base_agreements if contract_prefix in b.source_filename]
        if len(matching_bases) == 1:
            link(amendment, matching_bases[0], confidence=0.90)
            continue
        
        # Signal 3: Agreement type matching
        if len(base_agreements) > 1:
            type_match = [b for b in base_agreements if b.agreement_type == amendment.agreement_type]
            if len(type_match) == 1:
                link(amendment, type_match[0], confidence=0.75)
                continue
        
        # Fallback: link to first base agreement (lowest confidence)
        link(amendment, base_agreements[0], confidence=0.50)
```

### Priority 5: Deterministic Multi-Contract Detection (4 hours)

Detect providers with genuinely separate contracts:
```sql
-- Indicators of separate contracts:
-- 1. Different agreement_type (capitation vs FFS)
-- 2. Non-overlapping effective dates
-- 3. Different contract_id prefixes in filenames
-- 4. Different network scope

SELECT provider_id,
       COUNT(DISTINCT agreement_type) as type_count,
       COUNT(DISTINCT contract_id_prefix) as prefix_count,
       CASE WHEN type_count > 1 OR prefix_count > 1 THEN 'MULTI_CONTRACT'
            ELSE 'SINGLE_CONTRACT'
       END as contract_topology
FROM tbl_contract_documents_master
WHERE doc_role = 'base_agreement'
GROUP BY provider_id
```

---

## 11. PRODUCTION-HARDENING RECOMMENDATIONS

### Correctness Guards

1. **Invariant: Every provider has ≥1 current rate**
   - After state computation, validate and remediate
   - Alert if zero-current detected

2. **Invariant: No duplicate current rates for same (provider, category, service)**
   - After supersession, check for conflicts
   - If duplicates exist, pick highest amendment_order

3. **Invariant: Amendment count matches documents_master**
   - After registry population, validate: amendment_registry count per contract = documents_master count
   - Alert on mismatches

4. **Invariant: Every amendment has a valid contract_id FK**
   - After population, validate JOIN to contract_registry
   - Orphaned amendments indicate contract grouping failure

### Reliability Improvements

1. **Replace TRUNCATE + INSERT with MERGE**
   - contract_id and amendment_id are deterministic → MERGE on key
   - Enables incremental updates without full rebuild
   - Preserves Delta history for audit

2. **Add computation version tracking**
   - state_version column already exists
   - Increment on each run; log what changed

3. **Add transaction wrapping**
   - Both registries should update atomically
   - If amendment population fails, contract registry should rollback

4. **Add input data quality checks**
   - Validate documents_master has amendment_order continuity (no gaps)
   - Validate effective_date_parsed is parseable as DATE
   - Alert on NULL provider_id or source_filename

### Observability

1. **Log scope classification distribution per run**
   - Already partially done (prints at end)
   - Should persist to telemetry table for trend analysis

2. **Log confidence distribution**
   - Track: what % of amendments have confidence < 0.70?
   - Alert if degrading over time

3. **Log contract topology**
   - Track: single vs multi-contract providers
   - Validate against known multi-contract providers

---

## 12. PERFORMANCE OPTIMIZATIONS WITHOUT QUALITY LOSS

| Optimization | Current | Proposed | Savings | Quality Impact |
|-------------|---------|----------|---------|---------------|
| Replace correlated subqueries with JOINs | Subquery per row | Pre-computed JOIN | 3-5x faster | NONE |
| Replace TRUNCATE+INSERT with MERGE | Full rebuild | Incremental | 10x faster at scale | NONE |
| Add Z-ORDER on contract_registry | No optimization | Z-ORDER by (provider_id, status) | 2-3x for filtered queries | NONE |
| Parallelize contract + amendment population | Sequential | Concurrent (independent inserts) | 2x | NONE |
| Cache documents_master in temp view | Re-queried in each subquery | Cached once | 2x | NONE |
| Pre-parse exhibits_replaced as array | Runtime STRING length check | Pre-computed column | Minor | IMPROVES quality |

### Rewritten Contract Registry (Performance + Quality)

```sql
-- Pre-compute base agreements and amendment stats
WITH base_agreements AS (
    SELECT provider_id, provider_name, source_filename,
           agreement_type, payment_type, auto_renewal, contract_term_years,
           effective_date_parsed, expiration_date_parsed,
           sha2(concat_ws('|', provider_id, source_filename), 256) AS contract_id
    FROM tbl_contract_documents_master
    WHERE amendment_order = 0 OR doc_role = 'base_agreement'
    QUALIFY ROW_NUMBER() OVER (PARTITION BY provider_id, source_filename ORDER BY amendment_order) = 1
),
amendment_stats AS (
    SELECT 
        -- Link to FIRST base agreement for this provider (current behavior)
        b.contract_id,
        COUNT(*) AS total_amendments,
        MAX(a.effective_date_parsed) AS latest_amendment_date,
        FIRST_VALUE(a.source_filename) OVER (PARTITION BY a.provider_id ORDER BY a.amendment_order DESC) AS latest_amendment_doc
    FROM tbl_contract_documents_master a
    JOIN base_agreements b ON a.provider_id = b.provider_id
    WHERE a.amendment_order > 0
    GROUP BY b.contract_id, a.provider_id
)
-- Single INSERT with pre-computed stats (no correlated subqueries)
INSERT INTO tbl_v2_contract_registry (...)
SELECT
    b.contract_id, b.provider_id, b.provider_name,
    normalize_agreement_type(b.agreement_type),
    normalize_payment_model(b.payment_type),
    'commercial' AS network_scope,
    CASE WHEN b.expiration_date_parsed < current_date() THEN 'EXPIRED' ELSE 'ACTIVE' END,
    b.effective_date_parsed, b.expiration_date_parsed,
    b.auto_renewal, b.contract_term_years,
    b.source_filename,
    COALESCE(s.total_amendments, 0),
    s.latest_amendment_date,
    s.latest_amendment_doc,
    current_timestamp(), 1, 'v2_optimized_join'
FROM base_agreements b
LEFT JOIN amendment_stats s ON b.contract_id = s.contract_id;
```

---

## 13. INTEGRATION ASSESSMENT

### Retrieval Integration

| Integration Point | Status | Quality Impact |
|------------------|--------|---------------|
| contract_id in legal_units → scope filtering | AVAILABLE | Enables per-contract retrieval scope |
| is_current flag in legal_units | SET but uses V1 heuristic | Retrieval may return superseded content |
| scope_type in amendment_registry | STORED but unused by retriever | Could enable "show only what changed" queries |
| effective_date on legal_units | POPULATED from source | Could enable temporal filtering (not used) |

**Recommendation**: Retrieval engine should use scope_type + effective_date for temporal filtering, not just is_current boolean.

### Intelligence Integration

| Integration Point | Status | Quality Impact |
|------------------|--------|---------------|
| contract_registry → renewal priority | USED (effective_to for urgency) | Correct — real dates used |
| rate_rules → benchmarks | USED (rate_numeric for percentiles) | Correct — V2 data used |
| amendment_registry → complexity scoring | NOT USED | Could improve renewal impact scoring |
| scope_type → negotiation difficulty | NOT USED | FULL_REPLACEMENT contracts may be easier to negotiate |

### Demo Integration

| Integration Point | Status | Quality Impact |
|------------------|--------|---------------|
| contract_registry → status chart | USED | Correct |
| amendment_registry → not used by demo | N/A | Could enable "amendment scope" visualization |
| State engine → Ask Anything | NOT CONNECTED | Demo runs independent pipeline |

---

## 14. FINAL ASSESSMENT SUMMARY

### Overall State Engine Rating: 4.5/10

| Dimension | Rating | Notes |
|-----------|--------|-------|
| Correctness | 5/10 | Works for simple cases; fails for multi-contract, exhibit-level |
| Reliability | 6/10 | Deterministic IDs; idempotent; but varying row counts |
| Scalability | 7/10 | Fine at current scale; correlated subqueries problematic at 10x |
| Maintainability | 5/10 | Single file, clear structure; but duplicated utilities, no tests |
| Retrieval integration | 3/10 | Data available but not consumed by retriever |
| Intelligence integration | 7/10 | Renewal priority correctly uses contract dates |
| Demo readiness | 6/10 | Status chart works; no other direct demo usage |
| Legal defensibility | 3/10 | Cannot explain supersession decisions; no audit trail |
| Explainability | 4/10 | scope_type is informative but confidence is meaningless |
| Temporal completeness | 2/10 | Binary current/superseded; no historical reconstruction |

### Top 3 Immediate Actions

1. **Fix scope classification** — replace STRING LENGTH with JSON array parsing (2 hours, high impact)
2. **Implement zero-current guard** — ensure no provider loses all rates (1 hour, safety critical)
3. **Rewrite correlated subqueries as JOINs** — fix runtime errors and improve performance (2 hours)

### Top 3 Medium-Term Actions

1. **Implement exhibit-level versioning** — the pragmatic middle ground between current and bitemporal (8 hours)
2. **Add contract grouping logic** — fix multi-contract provider handling (4 hours)
3. **Connect scope_type to rate supersession** — use EXHIBIT_SPECIFIC to supersede only the relevant rates (4 hours)
