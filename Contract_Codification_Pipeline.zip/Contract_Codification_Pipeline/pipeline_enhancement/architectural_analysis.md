# COMPLETE PLATFORM ARCHITECTURAL ANALYSIS
## Provider Contract Intelligence Platform — Dependency Map & Judgment

**Author**: Principal Architecture Review  
**Date**: May 2026  
**Scope**: `/Workspace/Users/adixit01@blueshieldca.com/Contract_Codification_Pipeline`

---

## 1. WHAT THE PLATFORM IS ACTUALLY TRYING TO BECOME

A **vertically-integrated contract intelligence system** that:
1. Ingests 10,372 provider contract PDFs (27 GB)
2. Extracts structured data via LLM (Claude Sonnet 4.5)
3. Models contract lifecycle (state engine + bitemporal rates)
4. Computes reimbursement logic as evaluable expression trees
5. Serves natural-language Q&A via retrieval-augmented generation (RAG)
6. Delivers negotiation intelligence (benchmarks, leverage, scenarios)

The **aspiration** is a Bloomberg Terminal for provider contracting — combining document intelligence, computational finance, and strategic decision support.

---

## 2. COMPLETE ARCHITECTURE DIAGRAM

```
╔══════════════════════════════════════════════════════════════════════════════╗
║                        SOURCE LAYER (External)                              ║
║  /Volumes/prod_adb/.../Provider_Contracts — 597 folders, 10,372 PDFs       ║
╚════════════════════════════════════╦═════════════════════════════════════════╝
                                     ▼
╔══════════════════════════════════════════════════════════════════════════════╗
║ LAYER 1: EXTRACTION PIPELINE (extraction/ — 15 notebooks)                   ║
║                                                                              ║
║  01_file_discovery → 02_ocr → 03_metadata → 04_prompts → 05_llm_extract   ║
║         │                                                       │            ║
║         └── file_registry.parquet               json_extract/*.json ──┐      ║
║                                                                       │      ║
║  06_validation → 07_consolidation → json_consolidated/*.json          │      ║
║         │                                    │                        │      ║
║  08_build_rates → 09_build_terms → 10_build_documents                 │      ║
║         │                │                   │                        │      ║
║  11_enrich → 12_build_genie → 13_build_serving → 14_quality_audit     │      ║
║                    │                │               15_gap_filler      │      ║
║                    ▼                ▼                                  │      ║
║           V1 TABLES (16+)    Serving Tables                          │      ║
╚═══════╦════════════════════════════╦═══════════════════════════════════╩══════╝
        ▼                            ▼
╔══════════════════════════════════════════════════════════════════════════════╗
║ LAYER 2: FOUNDATION (platform/00-03)                                        ║
║                                                                              ║
║  00_config ─┬─► 01_execute_ddl (state_engine_ddl + reimb_ddl + taxonomy)    ║
║             ├─► 02_state_engine  → tbl_v2_contract_registry (1,948)         ║
║             │                    → tbl_v2_amendment_registry (1,570)         ║
║             └─► 03_reimbursement_migration → tbl_reimb_rate_rules (21,074)  ║
║                                            → tbl_reimb_stop_loss (741)       ║
║                                            → tbl_reimb_carve_outs            ║
║                                            → dim_service_line_taxonomy (50)  ║
╚═══════╦════════════════════════════╦════════════════════════════════════════╝
        ▼                            ▼
╔══════════════════════════════════════════════════════════════════════════════╗
║ LAYER 3: RETRIEVAL (platform/04-07)                                         ║
║                                                                              ║
║  04_legal_chunking → tbl_retrieval_legal_units (83,008)                     ║
║           │              ↓                                                   ║
║           │         idx_legal_units_v2 (VS delta sync index)                ║
║           ▼                                                                  ║
║  05_retrieval_engine (4-channel: semantic + lexical + metadata + structural)║
║           ▼                                                                  ║
║  06_reranking_service (3-stage: cross-encoder + 6 legal signals + diversity)║
║           ▼                                                                  ║
║  07_citation_verification (6-check: uncited, numerical, scope, state, NLI) ║
║           │                                                                  ║
║           └─► tbl_retrieval_telemetry (monitoring)                          ║
╚═══════╦══════════════════════════════════════════════════════════════════════╝
        ▼
╔══════════════════════════════════════════════════════════════════════════════╗
║ LAYER 4: INTELLIGENCE (platform/08-11)                                      ║
║                                                                              ║
║  08_intelligence → tbl_intel_benchmark_results (1,399)                      ║
║                  → tbl_intel_provider_spend_summary (348)                    ║
║                  → tbl_intel_savings_opportunity (500)                       ║
║                  → tbl_intel_renewal_priority (1,478)                        ║
║  09_scenario_engine → tbl_intel_scenario_results (5 samples)                ║
║  10_leverage_scoring → tbl_intel_leverage_scores (348)                      ║
║  11_evaluation_harness → tbl_eval_golden_queries (20)                       ║
║                        → v_retrieval_health_daily (monitoring view)          ║
╚═══════╦══════════════════════════════════════════════════════════════════════╝
        ▼
╔══════════════════════════════════════════════════════════════════════════════╗
║ LAYER 5: SERVING (External Assets)                                          ║
║                                                                              ║
║  Genie Space (01f14d360bd51f8d801452065b2df600) — NL contract queries       ║
║  Dashboard (01f153b41dc51de8bb4e0a3cf16bb7e1) — portfolio analytics          ║
║  VS Endpoint (contract_intelligence_vs_endpoint) — semantic search           ║
╚══════════════════════════════════════════════════════════════════════════════╝
```

---

## 3. DEPENDENCY GRAPH (Critical Path)

```
PDF Volume
    │
    ▼
[01-05] File Discovery → OCR → Metadata → LLM Extraction
    │                                         │
    │                              json_extract/*.json (canonical source of truth)
    │                                         │
    ├──────────────[06]───── Validation ──────┤
    │                                         │
    ├──────────────[07]── Consolidation ──────┤
    │                          │              │
    │                json_consolidated/       │
    │                          │              │
    ├──[08] Build Rates ◄──────┘              │
    │         │                               │
    │   tbl_contract_rates_all ──────► [platform/03] reimb_migration
    │   tbl_contract_financial_protections      │
    │         │                               │
    ├──[09] Build Terms                  tbl_reimb_rate_rules
    │         │                               │
    │   tbl_contract_terms_all          [platform/08] Intelligence
    │   tbl_contract_clauses_all              │
    │         │                         tbl_intel_*
    ├──[10] Build Documents                   │
    │         │                         [platform/10] Leverage
    │   tbl_contract_documents_master         │
    │         │                         tbl_intel_leverage_scores
    ├──[11] Enrich → dim_provider_canonical   │
    │         │                         [platform/09] Scenarios
    ├──[12] Build Genie (V1 serving)          │
    │         │                         tbl_intel_scenario_results
    │   tbl_genie_* (4 tables) ─────────────────┐
    │         │                                   │
    │   [platform/02] State Engine ◄──────────────┘
    │         │                         (reads tbl_genie_amendment_timeline)
    │   tbl_v2_contract_registry
    │   tbl_v2_amendment_registry
    │         │
    │   [platform/04] Legal Chunking ◄─── tbl_contract_terms_vs_ready
    │         │                           tbl_reimb_rate_rules
    │   tbl_retrieval_legal_units (83K)
    │         │
    │   [platform/05-07] Retrieval → Reranking → Citation
    │         │
    │   [platform/11] Evaluation Harness
    │
    └──[13-15] Build Serving / Quality Audit / Gap Filler
```

---

## 4. CANONICAL ENTITY MAP

| Entity | Canonical Source | Primary Key | Consumers |
| --- | --- | --- | --- |
| Provider (facility) | `dim_provider_canonical` | `primary_provider_id` | All Genie, Intelligence, Retrieval |
| Contract | `tbl_v2_contract_registry` | `contract_id` (sha256) | Amendment registry, Rate rules, Scenarios |
| Amendment | `tbl_v2_amendment_registry` | `amendment_id` (sha256) | State engine, Supersession |
| Rate (V1) | `tbl_contract_rates_all` | `(provider_id, source_filename, rate_category, service_category)` | Genie, Migration |
| Rate Rule (V2) | `tbl_reimb_rate_rules` | `rule_id` (UUID) | Benchmarks, Intelligence, Legal Units |
| Rate Fact (Bitemporal) | `tbl_v2_rate_facts_bitemporal` | `rate_fact_id` | **EMPTY — never populated** |
| Legal Unit | `tbl_retrieval_legal_units` | `unit_id` | VS index, Retrieval channels |
| Document | `tbl_contract_documents_master` | `(provider_id, source_filename)` | Rates, Terms, Genie |

---

## 5. MODULE-BY-MODULE ANALYSIS

### LAYER 1: Extraction Pipeline (extraction/01-15)

| Module | Responsibility | Inputs | Outputs | Business Value | Classification |
| --- | --- | --- | --- | --- | --- |
| 01_file_discovery | Scan Volume, prefetch to SSD, checkpoint | PDF Volume | file_registry | Foundation | **Mission Critical** |
| 02_ocr_extraction | 2-tier: pypdf + ai_parse_document | PDFs | step1_parsed.parquet | Foundation | **Mission Critical** |
| 03_metadata_parsing | Extract provider_id, doc_type from filenames | Parsed text | step2_with_metadata.parquet | Foundation | **Mission Critical** |
| 04_llm_prompts | 4 document-type-specific prompt templates | — | Prompt strings | Enabler | **Mission Critical** |
| 05_llm_extraction | REST API → Claude, chunking, retry | Text + Prompts | json_extract/*.json | Core IP | **Mission Critical** |
| 06_validation | Section completeness, schema checks | JSONs | Validation metadata | Quality gate | **Valuable** |
| 07_consolidation | Provider-level merge, amendment ordering | Per-file JSONs | json_consolidated/ | Architecture | **Valuable** |
| 08_build_rates | JSON → Delta tables (rates, financial protections) | JSONs | 3 rate tables | Foundation | **Mission Critical** |
| 09_build_terms | JSON → terms, clauses, parties tables | JSONs | 4 term tables | Foundation | **Mission Critical** |
| 10_build_documents | JSON → documents_master | JSONs | 1 doc table | Foundation | **Valuable** |
| 11_enrich_tables | dim_provider_canonical, program normalization | All tables | Enriched tables | Data quality | **Valuable** |
| 12_build_genie | 4 AI-optimized serving tables | Base tables | 4 Genie tables | Direct serving | **Mission Critical** |
| 13_build_serving | Capitation card, VS-ready views | Genie + base | Serving tables | Delivery | **Valuable** |
| 14_quality_audit | LLM-based extraction quality audit | JSONs | Audit table | Governance | **Nice to Have** |
| 15_gap_filler | Re-extract missing fields | Audit gaps | Updated JSONs | Completeness | **Nice to Have** |

### LAYER 2: Foundation (platform/00-03)

| Module | Responsibility | Inputs | Outputs | Business Value | Classification |
| --- | --- | --- | --- | --- | --- |
| 00_config | Constants, utilities, feature flags | — | Session context | Enabler | **Mission Critical** |
| 01_execute_ddl | Create 18+ tables + seed taxonomy | SQL files | Empty tables | Schema foundation | **Valuable** |
| 02_state_engine | Contract/amendment registry population | `tbl_genie_amendment_timeline` | Registry tables (3,518 rows) | Temporal awareness | **Valuable** |
| 03_reimbursement_migration | V1→V2 rate schema migration | `tbl_contract_rates_all`, `tbl_contract_financial_protections` | Rate rules (21K), stop-loss (741) | Structured reimbursement | **Valuable** |

### LAYER 3: Retrieval (platform/04-07)

| Module | Responsibility | Inputs | Outputs | Business Value | Classification |
| --- | --- | --- | --- | --- | --- |
| 04_legal_chunking | Chunk 83K legal units + VS index | Terms + Rate rules | `tbl_retrieval_legal_units` | RAG enabler | **Valuable** |
| 05_retrieval_engine | 4-channel hybrid retrieval + RRF | User query + VS index | Top-30 candidates | Core RAG | **Valuable** |
| 06_reranking_service | 3-stage reranking (legal signals) | Candidates | Top-5 results | Quality filter | **Nice to Have** |
| 07_citation_verification | 6-check answer verification | Answer + Citations | Verified answer | Trust/compliance | **Nice to Have** |

### LAYER 4: Intelligence (platform/08-11)

| Module | Responsibility | Inputs | Outputs | Business Value | Classification |
| --- | --- | --- | --- | --- | --- |
| 08_intelligence | Benchmarks, spend, savings, renewal | Rate rules + registry | 4 intel tables | Core analytics | **Valuable** |
| 09_scenario_engine | What-if simulation | Rate rules | Scenario results | Negotiation prep | **Nice to Have** |
| 10_leverage_scoring | Bilateral leverage computation | Spend summary + heuristics | Leverage scores | Strategic insight | **Nice to Have** |
| 11_evaluation_harness | Golden queries + monitoring view | Telemetry | Eval tables + view | Ops monitoring | **Nice to Have** |

---

## 6. TEMPORAL MODELING FLOW

```
tbl_genie_amendment_timeline (V1 — extraction-derived)
    ├── amendment_order (0=base, 1..N=amendments)
    ├── effective_date_parsed
    ├── exhibits_replaced_count (STRING/JSON array)
    └── prior_rates_superseded (STRING 'True'/'False')
            │
            ▼
tbl_v2_contract_registry (V2 — derived from V1)
    ├── status: ACTIVE/EXPIRED (from expiration_date vs now())
    ├── effective_from / effective_to
    └── latest_amendment_date/doc
            │
            ▼
tbl_v2_amendment_registry (V2 — scope classification)
    ├── scope_type: FULL_REPLACEMENT/EXHIBIT_SPECIFIC/RATE_SPECIFIC/...
    ├── scope_confidence (0.60-0.90)
    └── classification_rule: 'v2_structural_heuristic_v1'
            │
            ▼
tbl_v2_rate_facts_bitemporal (DESIGNED but NEVER POPULATED)
    ├── valid_from / valid_to (business time)
    ├── tx_from / tx_to (system time)
    ├── is_current (computed)
    └── supersession_type + confidence

ACTUAL supersession resolution: tbl_contract_rates_all.status = 'current'/'superseded'
    ├── Determined by amendment_order from tbl_contract_documents_master
    └── Simple: highest amendment_order per provider = current
```

**Critical Finding**: The elaborate bitemporal model (`tbl_v2_rate_facts_bitemporal` with 24 columns, dual timelines, supersession types and confidence) was designed but **never populated**. Real temporal logic is a simple Python comparison in `08_build_rates`: "highest amendment_order per provider = current."

---

## 7. REIMBURSEMENT INTELLIGENCE COMPUTATION

```
tbl_contract_rates_all (V1 — flat rows, rate_numeric)
    │
    ▼  [platform/03_reimbursement_migration]
tbl_reimb_rate_rules (V2 — formula_json expression trees)
    ├── formula_type: FIXED | PER_DIEM | PERCENTAGE | DRG_WEIGHTED | LESSER_OF
    ├── formula_json: {"formula_type":"PER_DIEM","base_rate":10912,"unit":"day"}
    ├── rate_numeric (still the main query field)
    └── has_stop_loss/carve_out/escalator flags
            │
            ▼  [platform/08_intelligence]
tbl_intel_benchmark_results
    ├── percentile_approx(rate_numeric, 0.10..0.90) GROUP BY domain/service_line/formula
    └── provider_count, rate_count, std_dev per group
            │
            ▼
tbl_intel_provider_spend_summary
    ├── estimated_annual_spend = avg_rate × total_rate_rules × 50 (HEURISTIC)
    ├── pct_above_median, avg_percentile (vs benchmarks)
    └── total_savings_opportunity = SUM(rate - median) × 12
            │
            ▼
tbl_intel_leverage_scores
    ├── plan_leverage (5 components, mostly fixed constants)
    ├── prov_leverage (7 components, mostly proxies from rate data)
    └── net_leverage = plan - provider, mapped to posture
```

**Critical Finding**: The intelligence layer computes estimated_annual_spend as `avg_rate × total_rate_rules × 50` — a meaningless heuristic. Without claims data (CLAIMS_AVAILABLE=False), all "spend," "savings," and "leverage" numbers are fabricated proxies. The `formula_json` expression trees in rate_rules are **never evaluated** — `rate_numeric` is used everywhere downstream.

---

## 8. RETRIEVAL FLOW

```
User Query
    │
    ▼  [05_retrieval_engine.understand_query]
ParsedQuery (intent, entities, temporal_scope, keywords)
    │
    ├──► Channel 1: Semantic (VS similarity_search against 83K units)
    ├──► Channel 2: Lexical (ILIKE on unit_text with keyword AND)
    ├──► Channel 3: Metadata (SQL on tbl_reimb_rate_rules for RATE_LOOKUP only)
    └──► Channel 4: Structural (not implemented — placeholder)
            │
            ▼  [Reciprocal Rank Fusion — not actually implemented in code]
    Top-30 candidates
            │
            ▼  [06_reranking_service]
    Stage 1: Cross-encoder (NOT DEPLOYED — just uses retrieval score + 0.1 boost)
    Stage 2: 6 legal signals (state, recency, specificity, scope, authority, completeness)
    Stage 3: Diversity enforcement (max 2 per source doc)
            │
            ▼
    Top-5 results
            │
            ▼  [07_citation_verification]
    6 checks (regex-based, simplified NLI — no actual LLM judge call)
            │
            ▼
    VerifiedAnswer (confidence score, citations, disclaimers)
```

**Critical Finding**: The retrieval pipeline has impressive architecture on paper but multiple unfinished components:
- Channel 4 (structural) — not implemented
- RRF fusion — not actually coded; channels return independently
- Cross-encoder Stage 1 — RERANKER_DEPLOYED=False, just adds 0.1 to type-matched chunks
- NLI check — simplified keyword overlap, no LLM call
- VS index — may not exist yet (created programmatically, never confirmed synced)

---

## 9. DUPLICATED BUSINESS LOGIC & SEMANTIC REDUNDANCY

### A. Rate data exists in 5+ representations:

| Layer | Table/Artifact | Same Data? |
| --- | --- | --- |
| Raw Extraction | json_extract/*.json (inpatient_rates, outpatient_rates) | Source |
| Consolidated | json_consolidated/*.json (rate_timeline) | Deduplicated |
| V1 Delta | tbl_contract_rates_all (68K rows) | Flattened |
| V1 Genie | tbl_genie_rates_current (deduped current only) | Served |
| V2 Reimbursement | tbl_reimb_rate_rules (21K, formula_json) | Re-schematized |
| V2 Legal Units | tbl_retrieval_legal_units (RATE_TABLE type, 21K) | Re-textualized |
| V2 Bitemporal | tbl_v2_rate_facts_bitemporal | **EMPTY** |

The **same rate** ($10,912/day Med/Surg per diem) exists in JSON files, json_consolidated, tbl_contract_rates_all, tbl_genie_rates_current, tbl_reimb_rate_rules, AND tbl_retrieval_legal_units — each with different schemas, different deduplication logic, and different temporal semantics.

### B. Provider identity exists in 3+ places:

- `dim_provider_canonical` (canonical resolution — 278 facilities)
- `tbl_genie_provider_profile` (pre-joined aggregate)
- `tbl_intel_provider_spend_summary` (intelligence layer)
- `tbl_intel_leverage_scores` (leverage layer)

### C. Amendment/temporal logic duplicated:

- `tbl_genie_amendment_timeline` — V1 extraction-level
- `tbl_v2_contract_registry` — V2 state engine (reads FROM V1)
- `tbl_v2_amendment_registry` — V2 scope classification (reads FROM V1)
- `tbl_contract_documents_master` — extraction metadata

All four contain overlapping amendment chain data with different enrichments.

### D. Service line classification duplicated:

- `dim_service_line_taxonomy` (50 rows, 4-level hierarchy, regex patterns)
- `dim_service_line_patterns` (45 rows, normalization patterns)
- CASE WHEN logic in `13_build_serving` (hardcoded 25-entry mapping)
- `service_category_raw` → `service_line` mapping in `03_reimbursement_migration` (ILIKE patterns)

Four independent codifications of the same domain knowledge.

---

## 10. ARCHITECTURAL STRENGTHS

1. **Extraction pipeline is genuinely well-engineered**: 2-tier OCR, adaptive concurrency, chunking for large files, checkpoint resumability, JSON repair for truncated outputs. This shows real production lessons learned.

2. **V6 schema design is thoughtful**: `rate_numeric` on every row, `full_clause_text`, `amendments_impact` for supersession — the LLM prompts are well-structured with document-type variants.

3. **Consolidation logic handles real complexity**: Version deduplication, amendment ordering via ordinal word parsing, doc role classification, rate supersession — these are genuine domain problems solved pragmatically.

4. **Genie serving layer (12_build_genie) is the highest-value downstream asset**: Pre-joined, deduplicated, sentinel-safe, 67 column comments. This directly serves end users via natural language.

5. **Quality audit approach** is sophisticated: LLM-as-auditor comparing PDF text against extraction output is a valid technique for measuring extraction fidelity.

6. **Clear documentation**: 26 design docs, implementation prompt, README with execution order — shows architectural intentionality.

---

## 11. ARCHITECTURAL WEAKNESSES

### Critical Issues:

1. **Bitemporal model is architecture theater**: `tbl_v2_rate_facts_bitemporal` (the most complex DDL in the system — 24 columns, dual timelines, supersession confidence) is **completely empty**. The actual temporal logic is `amendment_order DESC LIMIT 1`.

2. **Intelligence layer is fabricated without claims data**: All spend, savings, leverage, and renewal numbers are computed from `avg_rate × rule_count × 50` — a meaningless heuristic. The `formula_json` expression trees in rate_rules are **never evaluated** — `rate_numeric` is used everywhere downstream.

3. **Retrieval pipeline is 60% placeholder**: Cross-encoder=disabled, structural channel=unimplemented, RRF=not coded, NLI=regex proxy, VS index=may not exist.

4. **V1→V2 migration creates semantic debt**: The platform maintains TWO complete representations (V1 tables from extraction + V2 tables from migration). Neither representation is authoritative.

5. **formula_json is never evaluated**: The `tbl_reimb_formula_components` table (recursive expression tree) is **empty**. The `formula_json` field is populated but never consumed by any downstream process.

6. **No orchestration**: 15 extraction notebooks + 12 platform modules have NO job DAG, NO dependency management, NO idempotency guarantees.

### Design Issues:

7. **Over-normalization in reimbursement model**: 9 tables where 2-3 would suffice. `formula_components`, `conditions`, and `escalators` are empty.

8. **Evaluation harness tests names that don't exist**: Golden queries reference providers not yet in the processed sample.

9. **Scenario engine with hardcoded volume**: `volume_per_line = 50` monthly — applied uniformly, making results meaningless.

10. **Taxonomy seed covers cases that may not exist in data**: 50-row hierarchy populated but orphaned from extraction pipeline.

---

## 12. LAYER CLASSIFICATION

| Layer | Classification | Rationale |
| --- | --- | --- |
| Extraction Pipeline (01-07) | **Mission Critical** | Produces the data. Without this, nothing exists. |
| Table Building (08-10) | **Mission Critical** | Transforms JSON into queryable Delta tables. |
| Enrichment + Genie (11-12) | **Mission Critical** | Directly serves end users via Genie Space. |
| Serving/Quality (13-15) | **Valuable** | Capitation card, audit, gap fill — operational quality. |
| State Engine (platform/02) | **Valuable** | Registry gives portfolio-level visibility. |
| Reimbursement Migration (03) | **Nice to Have** | Rate_rules adds formula_type; formula_json unused. |
| Legal Chunking (04) | **Valuable** | Enables RAG retrieval if/when VS index is operational. |
| Retrieval Engine (05) | **Nice to Have** | Mostly placeholder; Genie Space does its own retrieval. |
| Reranking Service (06) | **Redundant** | Cross-encoder disabled, legal signals are simple heuristics. |
| Citation Verification (07) | **Redundant** | Regex-only checks; no actual LLM verification running. |
| Intelligence (08) | **Nice to Have** | Benchmarks useful; spend/savings fabricated without claims. |
| Scenario Engine (09) | **Dead Weight** | `rate × 50 × 12` is not a scenario — it's multiplication. |
| Leverage Scoring (10) | **Dead Weight** | Hardcoded constants pretending to be bilateral analysis. |
| Evaluation Harness (11) | **Nice to Have** | Good idea, but tests entities that don't exist in data. |
| Bitemporal Rate Facts DDL | **Dead Weight** | 24-column table that will never be populated at this stage. |
| Formula Components DDL | **Dead Weight** | Expression tree decomposition with zero rows. |
| 26 Design Docs | **Nice to Have** | Document aspirations; several describe systems that don't exist. |

---

## 13. FINAL PLATFORM JUDGMENT

### Is this platform architecturally coherent?

**Partially.** The extraction pipeline (Layer 1) is coherent, battle-tested, and genuinely solves the PDF→structured data problem. The Genie serving layer delivers real end-user value. Everything above that — the "V2" platform — is an architectural blueprint that has been coded but not validated.

The architecture has **two minds**: a pragmatic extraction engineer who ships working code (extraction/), and an aspirational platform architect who designs enterprise systems (platform/). They coexist in the same repo without reconciliation.

### Is this actually enterprise-grade?

**No.** Enterprise-grade requires:
- Orchestration (no job DAG exists)
- Idempotency (notebooks have manual execution dependencies)
- Data contracts (V1 and V2 schemas coexist without clear ownership)
- Testing (20 golden queries that reference non-existent providers)
- Monitoring (telemetry table exists but nothing writes to it)
- Access control (everything in `dev_adb.raw` — no environments)

### Is this a prototype pretending to be enterprise?

**Yes.** The 26 design documents, the bitemporal DDL, the 9-table reimbursement model, the 6-check citation verification, the 5-component leverage model — these are architecture artifacts designed to look enterprise while running on 199/10,372 PDFs with hardcoded volume estimates and disabled model endpoints.

### What percentage is genuinely valuable?

**~55-60%** — the extraction pipeline, table building, Genie serving, and state engine registries. These solve real problems and serve real users.

### What percentage is complexity without ROI?

**~40-45%** — the V2 reimbursement schema (formula_json unused), retrieval stack (mostly placeholder), intelligence layer (fabricated numbers), leverage scoring (fixed constants), bitemporal model (empty), expression tree decomposition (empty).

### What would a FAANG/principal engineer think?

"The extraction pipeline is solid engineering — checkpoint resumability, adaptive concurrency, JSON repair, document-type prompts. I'd hire that person. But then someone got excited about 'platform architecture' and built 5 layers of abstraction on top of 2% of the data with no integration tests, no CI/CD, no data contracts, and intelligence outputs that are literally `rate × 50 × 12`. This needs to be cut in half before it can be scaled. Kill the fantasy layers, ship the extraction at 100%, THEN build intelligence once you have claims data."

### What would an enterprise buyer think?

"The demo looks impressive — Genie Space, 83K legal units, leverage scoring, scenario modeling. But when I ask 'how is spend calculated?' and the answer is 'average rate times 50,' I'm concerned. When I learn the bitemporal model is empty and the reranker is disabled, I wonder what else is scaffolding. I'd need to see this run on the full 10K corpus with real claims data before I'd approve budget."

### What should be rebuilt entirely?

1. **Kill**: Scenario engine (09), leverage scoring (10), formula_components DDL, tbl_v2_rate_facts_bitemporal DDL, reranking service (06), citation verification (07)
2. **Defer until claims connected**: Intelligence pipeline (08), spend summaries, savings opportunities, renewal priority
3. **Consolidate**: Merge V1 and V2 rate representations into ONE canonical rate table with formula_type as metadata
4. **Ship**: Run extraction on remaining 10K PDFs — this is the actual bottleneck
5. **Build for real**: Once you have 100% extraction + claims data, THEN build intelligence from actual utilization, not `× 50`

---

**Bottom line**: This is a 55% valuable extraction platform wearing a 45% enterprise-architecture costume. The costume needs to come off before the platform can scale. Ship the extraction. Connect claims. Then rebuild intelligence on real data.