# REIMBURSEMENT ENGINE DEEP REVIEW
## BSC Provider Contract Intelligence Platform — Prompt 5

**Review Date:** 2026-05-24
**Scope:** Complete assessment of reimbursement architecture, data quality, computability, and roadmap
**Rating:** 3.5/10 for Production Readiness | 7/10 for Architectural Vision

---

## 1. EXECUTIVE SUMMARY

The reimbursement engine has **exceptional schema design** but **critically flawed data population**. The DDL creates a computable framework (rate_rules, stop_loss, carve_outs, lesser_of) that could support real pricing engines. However, the V1→V2 migration injects data through heuristic ILIKE classification that produces systematic errors: dollar values stored as percentages, day counts stored in dollar columns, and zero linkage to the service-line taxonomy that was designed to normalize them.

### Key Metrics
| Dimension | Score | Evidence |
|-----------|-------|----------|
| Schema Design | 8/10 | Expression tree JSON, modifier chain, taxonomy hierarchy |
| Data Quality | 3/10 | 22% formula_type misclassification, $5,571 as "percentage" |
| Computability | 2/10 | Engine designed but 0% implemented; formula_json too flat |
| Taxonomy Linkage | 0/10 | 0 of 11,486 rules linked to dim_service_line_taxonomy |
| Benchmark Reliability | 2/10 | All "estimated", 60% groups have <3 providers |
| Claims Readiness | 1/10 | No claim adjudication path exists; no code matching |
| Carve-Out Coverage | 0/10 | 0 rows populated despite 4,174 source exceptions |

---

## 2. ARCHITECTURE ASSESSMENT

### 2.1 Designed Architecture (from design docs)

```
┌─────────────────────────────────────────────────────────────────┐
│                    DESIGNED RATE RULE ENGINE                      │
├─────────────────────────────────────────────────────────────────┤
│  ClaimScenario → RuleMatcher → FormulaEvaluator → ModifierChain │
│                                                                   │
│  Components:                                                      │
│  ├── Rule Matching (domain + service_line + program + date)      │
│  ├── Formula Evaluation (recursive expression tree)               │
│  ├── Condition Evaluation (AND/OR grouped, operator-based)        │
│  ├── Stop-Loss Application (PER_DIEM, AGGREGATE, CORRIDOR)       │
│  ├── Carve-Out Addition (threshold-triggered extra payments)      │
│  ├── Lesser-Of Comparison (MIN of N comparators)                 │
│  ├── Escalator Projection (compound annual growth)                │
│  └── Result Builder (total + breakdown + audit trail)            │
└─────────────────────────────────────────────────────────────────┘
```

### 2.2 Implemented Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    ACTUAL IMPLEMENTATION                          │
├─────────────────────────────────────────────────────────────────┤
│  tbl_contract_rates_all (WHERE status='current')                 │
│       │                                                           │
│       ▼                                                           │
│  ILIKE-based CASE WHEN classification                            │
│       │                                                           │
│       ▼                                                           │
│  INSERT INTO tbl_reimb_rate_rules (flat formula_json)            │
│       │                                                           │
│       ├── Correlated subquery → stop_loss linkage (35% UNLINKED) │
│       └── ILIKE text search → lesser_of (21 rows)               │
│                                                                   │
│  NO: Formula evaluation, condition checking, carve-out capture,  │
│      escalator computation, scenario modeling, claims integration │
└─────────────────────────────────────────────────────────────────┘
```

### 2.3 Implementation Gap
| Designed Component | Implementation Status | Gap Severity |
|---|---|---|
| ClaimScenario dataclass | NOT IMPLEMENTED | CRITICAL — no input contract |
| RuleMatcher (7-criteria) | NOT IMPLEMENTED | CRITICAL — no runtime matching |
| FormulaEvaluator (recursive) | NOT IMPLEMENTED | CRITICAL — JSON exists but no evaluator |
| ConditionEvaluator | NOT IMPLEMENTED | HIGH — no tbl_reimb_conditions table |
| Stop-Loss Application | SCHEMA ONLY | HIGH — data migrated but no computation |
| Carve-Out Evaluation | EMPTY TABLE | CRITICAL — 0 rows populated |
| Escalator Projection | NO TABLE | HIGH — tbl_reimb_escalators doesn't exist |
| Geographic Adjustments | NOT DESIGNED | MEDIUM — county-level factors missing |
| Result Builder | NOT IMPLEMENTED | HIGH — no output structure |

---

## 3. RATE RULE MODELING

### 3.1 Table: tbl_reimb_rate_rules (11,486 rows)

**Sources:**
- `tbl_contract_rates_all` WHERE status='current' → 9,229 FFS rules
- `tbl_serving_capitation_card` → 2,257 capitation rules

**Domain Distribution:**
| Domain | Count | % | Assessment |
|--------|-------|---|-----------|
| CAPITATION | 5,302 | 46% | From capitation_card; age_gender_band as service_line |
| OUTPATIENT | 3,820 | 33% | Most diverse service categories |
| INPATIENT | 2,364 | 21% | Per-diem + case rates |
| PROFESSIONAL | 0 | 0% | **MISSING** — no source pattern matches |

### 3.2 Critical Data Quality Issues

#### Issue #1: PERCENTAGE Formula Misclassification (CRITICAL)
```
84 rules have formula_type=PERCENTAGE with rate_numeric > 100
Example: rate_text="$5,571", rate_numeric=5571.0
Stored as: {"formula_type":"PERCENTAGE","percentage":5571.0,"of":"BILLED_CHARGES"}
Meaning: This would compute 5,571% of billed charges — obviously wrong
```
**Root Cause:** The classification logic matches `formula ILIKE '%percent%'` but the source `formula` column contains text like "percent of case rate" even when the actual value is a dollar amount.

**Impact:** Any computation using these rules would produce absurd results. Affects 22% of PERCENTAGE-classified rules.

#### Issue #2: Empty Service Lines (HIGH)
```
1,676 rules (15%) have blank service_line
These are unclassifiable for benchmarking or matching
```

#### Issue #3: Zero Taxonomy Linkage (HIGH)
```
0 of 11,486 rules link to dim_service_line_taxonomy
The service_line column contains free-text (e.g., "Knee Arthroscopy")
The taxonomy expects codes (e.g., "OP_SURG_TIER3")
```
The taxonomy (50 rows) and pattern-matching table (45 ILIKE patterns) exist but are never applied during migration.

#### Issue #4: CONVERSION_FACTOR JSON Mismatch (MEDIUM)
```
5 rules: formula_type = 'CONVERSION_FACTOR'
         JSON internal type = 'FIXED' (stores as amount, not conversion_factor)
Evaluator would produce wrong results for these
```

#### Issue #5: Confidence Score is Hardcoded (LOW)
```
9,229 rules: confidence_score = 0.7 (FFS)
2,257 rules: confidence_score = 0.9 (capitation)
No actual LLM extraction confidence propagated
```

#### Issue #6: Non-Idempotent UUIDs (MEDIUM)
```
rule_id = uuid() — regenerated on every migration run
FK references (stop_loss.rule_id → rate_rules.rule_id) break on rerun
Correlated subqueries use LIMIT 1 for linkage — non-deterministic
```

---

## 4. FORMULA MODELING

### 4.1 Formula JSON Design Assessment

**Designed expressiveness (from docs):**
```json
{
  "formula_type": "COMPOUND",
  "operands": [
    {"formula_type": "DRG_WEIGHTED", "base_rate": 8500, "weight_source": "CMS_DRG_WEIGHTS"},
    {"formula_type": "ESCALATED", "base_formula": {...}, "annual_increase_pct": 3.5}
  ]
}
```

**Actual data (what's stored):**
```json
{"formula_type":"FIXED","amount":37591.0}
{"formula_type":"PER_DIEM","base_rate":2383.0,"unit":"day"}
{"formula_type":"PERCENTAGE","percentage":86.5,"of":"BILLED_CHARGES"}
{"formula_type":"LESSER_OF","operands":[{"formula_type":"FIXED","amount":100.0},{"formula_type":"REFERENCE","reference":"BILLED_CHARGES"}]}
```

### 4.2 Formula Expressiveness Rating

| Formula Type | Designed | Actual Data | Computable? | Notes |
|---|---|---|---|---|
| FIXED | ✓ amount | ✓ amount | YES | Trivial |
| PER_DIEM | ✓ base_rate × days | ✓ base_rate, unit | PARTIALLY | No stop_loss embedding |
| PERCENTAGE | ✓ pct × reference | ✗ STORES DOLLARS AS % | BROKEN | 22% misclassified |
| DRG_WEIGHTED | ✓ base × weight | ✗ 0 valid DRG rows | NO | Schema only |
| CONVERSION_FACTOR | ✓ CF × RVU × geo | ✗ Stored as FIXED | NO | JSON type mismatch |
| TIERED | ✓ tier brackets | ✗ 0 rows | NO | Not extracted |
| LESSER_OF | ✓ MIN(operands) | ✓ 2-operand | PARTIALLY | Only contracted vs billed |
| GREATER_OF | ✓ MAX(operands) | ✗ 0 rows | NO | Not extracted |
| COMPOUND | ✓ SUM(operands) | ✗ 0 rows | NO | Not extracted |
| ESCALATED | ✓ base × (1+r)^n | ✗ 0 rows | NO | No escalator table |

### 4.3 Is Reimbursement Logic Actually Computable?

**Answer: NO — not from current data.**

Reasons:
1. **Formula JSON is flat, not recursive** — Only LESSER_OF uses operands array; all others are single-level
2. **No modifier chain** — Stop-loss stored separately but never composed into formula
3. **No claim input contract** — ClaimScenario class exists in design doc but not in code
4. **Critical misclassification** — 84 "PERCENTAGE" rules would compute absurd values
5. **No code matching** — Revenue codes, procedure codes, DRG codes all NULL or comma-separated text
6. **Effective dates** — Present (99.4% coverage) but no temporal selection logic exists

**What IS computable today:**
- FIXED rates: "Provider X pays $37,591 per knee arthroscopy case" ✓
- PER_DIEM rates: "Provider X pays $2,383/day for medical/surgical" ✓ (if you know LOS)
- Simple benchmarking: "Provider X is at the 75th percentile for inpatient case rates" ✓

---

## 5. STOP-LOSS MODELING

### 5.1 Table: tbl_reimb_stop_loss (1,104 rows)

**Critical Findings:**
| Metric | Value | Issue |
|--------|-------|-------|
| Total rows | 1,104 | Reasonable volume |
| All typed as CASE_RATE | 100% | No variety despite schema supporting 4 types |
| UNLINKED to rules | 385 (35%) | Correlated subquery only finds INPATIENT rules |
| reimburse_percentage > 100 | 102 (9.2%) | Dollar amounts in percentage field |
| attachment_level < $100 | 77 (7%) | Day counts stored as dollar amounts |

#### Critical Bug: Column Confusion
```
attachment_level = 3.0, reimburse_percentage = 5000.0

Reality: "After 3 days, reimburse at $5,000/day"
Stored as: "After $3.00 total charges, reimburse 5000% of something"
```
The source `tbl_contract_financial_protections` stores "3 days" as `threshold_numeric=3` and "$5,000" as `reimbursement_pct_numeric=5000`. The migration doesn't distinguish between days/dollars/percentages.

### 5.2 Stop-Loss Assessment
| Criterion | Score | Rationale |
|-----------|-------|-----------|
| Type diversity | 1/5 | Only CASE_RATE — PER_DIEM/AGGREGATE/CORRIDOR never classified |
| Linkage quality | 2/5 | 35% UNLINKED; non-deterministic LIMIT 1 |
| Financial correctness | 1/5 | Column confusion makes computation impossible |
| Applicability scope | 2/5 | applies_to_services populated from sub_type (reasonable) |
| Computation readiness | 0/5 | No application logic; data semantics corrupted |

---

## 6. CARVE-OUT MODELING

### 6.1 Table: tbl_reimb_carve_outs (0 rows)

**Root Cause:** The migration filter requires:
```sql
WHERE fp.protection_type ILIKE '%carve%'
   OR fp.protection_type ILIKE '%implant%'
   OR fp.protection_type ILIKE '%drug%'
   OR fp.protection_type ILIKE '%device%'
```

But the actual data has only two protection_types: `exception` (4,174) and `stop_loss` (1,104). The 4,174 "exception" rows likely contain carve-outs (implants, drugs, devices billed separately) but are labeled generically.

### 6.2 What's Lost
The `tbl_contract_financial_protections` stores 4,174 "exception" provisions that likely include:
- High-cost implant carve-outs (common in hospital contracts)
- Pharmacy carve-outs (drug costs excluded from case rates)
- Device carve-outs (pacemakers, stents, etc.)
- Supply carve-outs

Without carve-out capture, any reimbursement computation would **understate** payments by potentially 10-30% for inpatient cases with expensive devices.

---

## 7. ESCALATOR MODELING

### 7.1 Status: NOT IMPLEMENTED

- `tbl_reimb_escalators` table does NOT exist (DDL doesn't create it)
- Migration references it but gracefully skips: "Skipping escalator flags: not found"
- Design docs describe annual escalator formulas (compound growth: `base × (1+r)^n`)

### 7.2 Impact
Without escalators:
- Cannot project future rates
- Cannot tell if a provider's 2024 rate represents 2019 base + 5 years of 3% escalation
- Cannot model renewal scenarios with rate increases

---

## 8. LESSER-OF MODELING

### 8.1 Table: tbl_reimb_lesser_of (21 rows)

**Best-populated modifier table.** 95% linked to rules (20/21).

**Structure:**
| Comparator | All 21 Rows |
|---|---|
| comparator_1_type | CONTRACTED_RATE (value: 100.0) |
| comparator_2_type | BILLED_CHARGES (value: NULL = dynamic) |
| comparator_3_type | MEDICARE_RATE (value: NULL = dynamic) |

**Assessment:** Correctly models the "lesser of contracted rate, billed charges, or Medicare" provision common in BSC contracts. However:
- Only 21 rows from 11,486 rules (0.18%) — likely more exist
- All from one provider with same pattern (100% billed charges → not actually a rate reduction)
- `comparator_1_value = 100.0` is meaningless for "contracted rate" comparison (it's the percentage, not the rate)

---

## 9. CAPITATION MODELING

### 9.1 Assessment: GOOD (Best Component)

The capitation migration is the cleanest:
- Clear source: `tbl_serving_capitation_card` (2,257 rows with explicit PMPM rates)
- Correct formula: `{"formula_type":"FIXED","amount":X,"unit":"member_month"}`
- Proper demographics: `age_gender_band` preserved as service_line
- Good confidence: 0.9 (higher than FFS because values are explicit numbers)

### 9.2 Limitations
- No member count data → cannot compute total capitation spend
- No risk adjustment factors
- No multi-year escalation tracking
- Age/gender bands are free-text ("Male 45-49") not structured demographic ranges

---

## 10. DOMAIN CLASSIFICATION

### 10.1 Classification Logic Quality

```sql
CASE
  WHEN r.rate_category ILIKE '%inpatient%' OR '%per_diem%' → 'INPATIENT'
  WHEN r.rate_category ILIKE '%outpatient%' OR '%ambulatory%' → 'OUTPATIENT'
  WHEN r.rate_category ILIKE '%capitation%' OR '%pmpm%' → 'CAPITATION'
  WHEN r.rate_category ILIKE '%professional%' OR '%physician%' → 'PROFESSIONAL'
  ELSE 'INPATIENT'  -- DEFAULT FALLBACK
END
```

**Problems:**
1. **PROFESSIONAL = 0 rows** — Source `rate_category` values never contain "professional" or "physician"
2. **Default to INPATIENT** — Anything unrecognized becomes inpatient (overstates inpatient volume)
3. **No validation** — Emergency services, radiology, pathology, infusion are all classified as OUTPATIENT regardless of whether they're professional or facility charges

### 10.2 Source rate_category Distribution
| rate_category | Count | Correct Domain? |
|---|---|---|
| capitation | 27,743 | ✓ CAPITATION |
| inpatient_per_diem | 16,944 | ✓ INPATIENT |
| outpatient_other_outpatient_rates | 16,820 | ✓ OUTPATIENT |
| inpatient_case_rate | 6,636 | ✓ INPATIENT |
| outpatient_surgical_tiers | 5,418 | ✓ OUTPATIENT |
| outpatient_therapy_services | 3,604 | MIXED — could be professional |
| inpatient_other_inpatient_rates | 3,360 | ✓ INPATIENT |
| outpatient_emergency_services | 514 | ✓ OUTPATIENT (facility) |
| outpatient_radiology_pathology | 380 | MIXED — often professional |
| outpatient_infusion_therapy | 303 | ✓ OUTPATIENT |

---

## 11. SERVICE-LINE NORMALIZATION

### 11.1 Designed System
A 4-level hierarchical taxonomy with 50 nodes and 45 pattern-matching rules:
```
Domain (Level 0) → Service Group (Level 1) → Service Line (Level 2) → Subtype (Level 3)
INPATIENT → Acute Care → Medical/Surgical → Standard
                        → ICU/CCU → Neonatal
OUTPATIENT → Surgical → Tier 1 - Minor
                       → Tier 2 - Intermediate Low
```

### 11.2 Actual State
**COMPLETELY DISCONNECTED.**

- Taxonomy exists (50 rows, well-structured)
- Patterns exist (45 ILIKE rules with priority and exclusions)
- Rate rules store free-text service_line (e.g., "Knee Arthroscopy", "Male 45-49")
- **Zero linkage between rate_rules.service_line and dim_service_line_taxonomy.service_line_code**
- No migration step applies patterns to classify free-text → codes

### 11.3 Consequences
1. **Benchmarking unreliable** — Groups by free-text variations ("Med/Surg" ≠ "Medical/Surgical")
2. **Rule matching impossible** — Designed engine requires service_line codes for hierarchical matching
3. **Reporting inconsistent** — Dashboard shows 711 benchmark "groups" that are really text variations

---

## 12. FINANCIAL CORRECTNESS ASSESSMENT

### 12.1 Can You Trust These Numbers?

| Question | Answer | Confidence |
|----------|--------|-----------|
| "What's the per-diem rate for Provider X?" | YES | HIGH for explicit $ amounts |
| "What's the case rate for knee surgery?" | MOSTLY | MEDIUM — rate_numeric reliable, service_line fuzzy |
| "What would Provider X pay for a 5-day stay?" | NO | LOW — no computation engine |
| "How does this compare to market?" | QUESTIONABLE | LOW — benchmarks from same dirty data |
| "What's the total annual cost at these rates?" | NO | N/A — no volume/utilization data |
| "Is this claim paid correctly?" | NO | N/A — no claims adjudication |

### 12.2 Data Reliability by Column
| Column | Reliable? | Error Rate | Notes |
|--------|-----------|-----------|-------|
| rate_numeric | 97.5% | 2.3% NULL + suspicious | Core financial value, trustworthy |
| formula_type | ~78% | 22% misclassified | PERCENTAGE most affected |
| formula_json | ~78% | Matches formula_type errors | Garbage in = garbage out |
| rate_domain | ~90% | 10% should be PROFESSIONAL | Default-to-INPATIENT inflates |
| service_line | ~72% | 15% empty + untranslated | Free-text, no codes |
| effective_date | 99.4% | 0.6% NULL | Best quality column |
| confidence_score | 0% useful | Hardcoded | Provides zero signal |

---

## 13. BENCHMARKING RELIABILITY

### 13.1 tbl_intel_benchmark_results (711 groups)

**ALL rows have source = 'estimated'** — None verified against external benchmarks.

**Sample Size Distribution:**
| Provider Count | Benchmark Groups | % | Statistical Validity |
|---|---|---|---|
| ≥ 5 providers | 136 | 19% | Marginally acceptable |
| 3-4 providers | 149 | 21% | Very weak statistical basis |
| 1-2 providers | 426 | 60% | **STATISTICALLY INVALID** |

### 13.2 Benchmark Computation Method
Benchmarks are computed from `tbl_reimb_rate_rules` grouped by `(rate_domain, service_line, formula_type)`. Since service_line is free-text, this creates hundreds of groups with identical clinical meaning but different text:
- "Medical/Surgical" ≠ "Med/Surg" ≠ "Med-Surg" = 3 separate benchmark groups
- Each may have only 1-2 providers → invalid percentile calculations

### 13.3 Are Intelligence Outputs Trustworthy?

**tbl_intel_renewal_priority (1,363 rows):**
- `pct_above_median` — Based on unreliable benchmarks
- `savings_opportunity` — Computed from difference vs median of small groups
- `estimated_spend` — Fabricated (no claims/volume data)
- `priority_score` — Composite of unreliable inputs

**Verdict:** Directionally useful for identifying obviously expensive providers, but NOT defensible for negotiation or regulatory purposes.

---

## 14. EXTENSIBILITY ASSESSMENT

### 14.1 Schema Extensibility: EXCELLENT (8/10)
The DDL design supports:
- ✓ New formula types (add to CASE WHEN + extend evaluator)
- ✓ New modifier types (add new tables with FK to rule_id)
- ✓ New domains (just string values)
- ✓ Geographic factors (column exists, unpopulated)
- ✓ Multi-tier stop-loss (schema supports multiple per rule)
- ✓ CDF (Change Data Feed) enabled on all tables

### 14.2 Implementation Extensibility: POOR (2/10)
- ✗ Formula evaluation engine: completely unimplemented
- ✗ Claims integration: no input contract, no matching logic
- ✗ Temporal handling: no valid_from/valid_to support
- ✗ Multi-rate resolution: no priority/specificity when multiple rules match
- ✗ Provider hierarchy: flat provider_id with no group/system rollup

---

## 15. TOP 15 DEFECTS (Ranked by Impact)

| # | Defect | Category | Impact | Fix Effort |
|---|--------|----------|--------|-----------|
| 1 | 84 PERCENTAGE rules contain dollar amounts | DATA CORRUPTION | Breaks any computation | 2 hours |
| 2 | 0 carve-out rows (4,174 exceptions unmigrated) | MISSING DATA | 10-30% payment underestimate | 4 hours |
| 3 | 0 taxonomy linkage (11,486 rules unclassified) | BROKEN PIPELINE | Benchmarks statistically invalid | 1 day |
| 4 | Stop-loss column confusion (days as dollars) | DATA CORRUPTION | 77 rows compute nonsense | 4 hours |
| 5 | Reimburse_percentage stores dollar amounts | DATA CORRUPTION | 102 stop-loss rows corrupted | 2 hours |
| 6 | No formula evaluation engine exists | MISSING FEATURE | Cannot compute reimbursement | 2-3 weeks |
| 7 | PROFESSIONAL domain has 0 rules | MISSING DATA | ~20% of healthcare payments invisible | 1 day |
| 8 | Benchmarks from <3 providers (60%) | STATISTICAL ERROR | Percentiles meaningless | Redesign |
| 9 | No escalator table | MISSING FEATURE | Cannot project future rates | 1 week |
| 10 | uuid() non-idempotent (FKs break on rerun) | DATA INTEGRITY | Linkages corrupt on rerun | 4 hours |
| 11 | CONVERSION_FACTOR stored as FIXED in JSON | DATA CORRUPTION | 5 rules won't evaluate correctly | 1 hour |
| 12 | Network normalization absent | DIRTY DATA | 67% "All Networks" hides specificity | 1 day |
| 13 | Confidence score hardcoded | MISLEADING | Provides false assurance | 2 hours |
| 14 | No procedure/revenue code validation | MISSING VALIDATION | Cannot match claims to rules | 2 weeks |
| 15 | All benchmarks source="estimated" | HONESTY GAP | Users may trust as "actual" | Documentation |

---

## 16. ENTERPRISE-GRADE REIMBURSEMENT ARCHITECTURE

### 16.1 Target Architecture

```
┌─────────────────────────────────────────────────────────────────────────┐
│                    ENTERPRISE REIMBURSEMENT ENGINE                        │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                           │
│  LAYER 1: DATA FOUNDATION                                                │
│  ┌───────────────────┐  ┌──────────────────┐  ┌─────────────────────┐  │
│  │ Rate Rules        │  │ Modifiers        │  │ Reference Data      │  │
│  │ (normalized,      │  │ (stop-loss,      │  │ (CMS DRG weights,   │  │
│  │  validated,       │  │  carve-outs,     │  │  fee schedules,     │  │
│  │  typed,           │  │  escalators,     │  │  geographic factors,│  │
│  │  temporally       │  │  lesser-of,      │  │  RVU tables,        │  │
│  │  correct)         │  │  conditions)     │  │  Medicare rates)    │  │
│  └───────────────────┘  └──────────────────┘  └─────────────────────┘  │
│                                                                           │
│  LAYER 2: MATCHING ENGINE                                                │
│  ┌─────────────────────────────────────────────────────────────────┐    │
│  │  Claim Input → Code Resolution → Rule Candidate Selection       │    │
│  │            → Condition Filter → Specificity Ranking             │    │
│  │            → Temporal Validity → Single Rule Selection          │    │
│  └─────────────────────────────────────────────────────────────────┘    │
│                                                                           │
│  LAYER 3: COMPUTATION ENGINE                                             │
│  ┌─────────────────────────────────────────────────────────────────┐    │
│  │  Formula Evaluation (recursive expression tree)                  │    │
│  │  → Stop-Loss Application (tiered, with corridor)                │    │
│  │  → Carve-Out Addition (threshold-triggered)                     │    │
│  │  → Lesser-Of Comparison (N-way MIN)                             │    │
│  │  → Escalator Projection (temporal growth)                       │    │
│  │  → Geographic Adjustment (county GPCI factors)                  │    │
│  └─────────────────────────────────────────────────────────────────┘    │
│                                                                           │
│  LAYER 4: ANALYTICS & INTELLIGENCE                                       │
│  ┌─────────────────────────────────────────────────────────────────┐    │
│  │  Benchmarking (statistically valid groups, N≥10)                 │    │
│  │  Scenario Modeling (what-if rate changes)                        │    │
│  │  Claims Validation (expected vs actual payment)                  │    │
│  │  Savings Projection (volume × rate delta)                        │    │
│  │  Renewal Prioritization (composite: urgency + savings + risk)    │    │
│  └─────────────────────────────────────────────────────────────────┘    │
│                                                                           │
│  LAYER 5: GOVERNANCE                                                     │
│  ┌─────────────────────────────────────────────────────────────────┐    │
│  │  Audit Trail │ Confidence Scoring │ Version Control │ Lineage    │    │
│  └─────────────────────────────────────────────────────────────────┘    │
│                                                                           │
└─────────────────────────────────────────────────────────────────────────┘
```

### 16.2 Key Design Principles

1. **Deterministic IDs** — Replace `uuid()` with `sha2(concat_ws('|', provider_id, source_filename, rate_domain, service_line, rate_text), 256)`
2. **Validated formulas** — JSON schema validation on write; reject unparseable
3. **Type safety** — formula_json must agree with formula_type column
4. **Temporal correctness** — effective_date + superseded_date range (not just effective)
5. **Code-based matching** — Revenue codes as ARRAY<STRING>, validated against CMS codebook
6. **Statistical minimums** — Benchmarks require N≥10 providers per group
7. **Reference data integration** — CMS DRG weights, RBRVS RVU, Medicare fee schedules
8. **Audit provenance** — Every computed value traces to source PDF + extraction confidence

---

## 17. CLAIMS INTEGRATION ROADMAP

### Phase 1: Claims Ingest (Weeks 1-4)
```
Claims Feed → Standardize → Match to Providers → Store in tbl_claims_adjudicated

Required columns:
- claim_id, provider_id, admit_date, discharge_date
- drg_code, procedure_codes[], revenue_codes[], diagnosis_codes[]
- billed_charges, paid_amount, allowed_amount
- service_line, place_of_service
- member_id, plan_code, network
```

### Phase 2: Claim-to-Rule Matching (Weeks 5-8)
```
For each claim:
1. Identify provider → get applicable contracts
2. Match service (DRG/CPT/revenue codes) → candidate rules
3. Apply temporal filter (admit_date within rule effective period)
4. Apply condition filter (LOS, charges thresholds)
5. Rank by specificity → select best rule
6. Compute expected reimbursement via formula_json
7. Compare expected vs actual paid → identify variances
```

### Phase 3: Variance Analysis (Weeks 9-12)
```
For each claim with |expected - actual| > threshold:
- Flag as UNDERPAID, OVERPAID, or UNMATCHED
- Link to specific formula component causing variance
- Generate audit trail for contract compliance review
```

### Phase 4: Continuous Intelligence (Weeks 13-16)
```
- Real-time benchmarking from actual paid amounts
- Savings estimation from volume × rate differential
- Outlier detection (claims paid outside contracted terms)
- Provider performance scoring (compliance rate)
```

---

## 18. PRICING ENGINE ROADMAP

### Phase 1: Formula Interpreter (Week 1-2)
```python
class ReimbursementEngine:
    def evaluate(self, claim: ClaimScenario, provider_id: str) -> ReimbursementResult:
        rules = self.match_rules(claim, provider_id)
        best_rule = self.select_rule(rules, claim)
        base = self.evaluate_formula(best_rule.formula_json, claim)
        adjusted = self.apply_modifiers(base, best_rule, claim)
        return self.build_result(adjusted, best_rule, claim)
```

### Phase 2: Reference Data Integration (Week 3-4)
- Import CMS DRG relative weights (MS-DRG v42)
- Import RBRVS RVU tables (for conversion factor rates)
- Import Medicare fee schedule (OPPS/IPPS rates)
- Import geographic practice cost indices (GPCI)

### Phase 3: Multi-Rate Resolution (Week 5-6)
```
When multiple rules match:
1. Most specific service_line wins
2. Exact program match > "All"
3. Exact network match > "All Networks"
4. Most recent effective_date wins (within validity)
5. Highest specificity score (code-level > domain-level)
```

### Phase 4: Validation & Testing (Week 7-8)
- 100 hand-verified claim scenarios
- Compare engine output vs known paid amounts
- Accuracy target: ±5% for 90% of test cases

---

## 19. SCENARIO MODELING ROADMAP

### Phase 1: Single-Variable Scenarios (Week 1-2)
```
"What if we increase all inpatient per-diem rates by 3%?"
→ Apply multiplier to formula_json.base_rate for matching rules
→ Recompute benchmarks and savings
```

### Phase 2: Renewal Negotiation Scenarios (Week 3-4)
```
"What would it cost to bring Provider X to the 50th percentile?"
→ For each service_line where provider > median:
  → Compute target rate (= median)
  → Apply volume estimate
  → Sum savings
→ Display as negotiation brief
```

### Phase 3: Portfolio-Level Scenarios (Week 5-6)
```
"What's the 3-year cost trajectory if all escalators are 3.5%?"
→ For each rule with escalator:
  → Project rates forward
  → Apply volume growth assumptions
  → Aggregate by service line, domain, region
```

---

## 20. SIMULATION ARCHITECTURE

```
┌─────────────────────────────────────────────────────────────────┐
│                    SIMULATION ENGINE                              │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  INPUT: ScenarioDefinition                                       │
│  ├── rate_adjustments: [{rule_filter, adjustment_type, value}]   │
│  ├── volume_assumptions: [{service_line, annual_volume}]         │
│  ├── escalator_overrides: [{provider, annual_pct}]               │
│  ├── temporal_horizon: {start_date, end_date, granularity}       │
│  └── comparison_baseline: {current_rates | custom}               │
│                                                                   │
│  PROCESS:                                                         │
│  1. Clone current rate_rules as scenario workspace               │
│  2. Apply rate_adjustments to matching rules                     │
│  3. Project temporal trajectory via escalators                    │
│  4. Compute reimbursement for each volume unit × adjusted rate    │
│  5. Aggregate by grouping dimensions                             │
│  6. Compare to baseline                                           │
│                                                                   │
│  OUTPUT: SimulationResult                                         │
│  ├── total_cost_scenario vs total_cost_baseline                  │
│  ├── delta_by_provider, delta_by_service_line, delta_by_domain   │
│  ├── confidence_intervals (if volume estimates have uncertainty) │
│  └── sensitivity_analysis (which inputs drive most variation)     │
│                                                                   │
└─────────────────────────────────────────────────────────────────┘
```

---

## 21. PERFORMANCE IMPROVEMENTS WITHOUT QUALITY LOSS

### 21.1 Immediate (Zero Risk)
| Improvement | Current | Proposed | Benefit |
|---|---|---|---|
| Z-ORDER rate_rules | Unoptimized | `ZORDER BY (provider_id, rate_domain, service_line)` | 5-10× faster lookups |
| Partition benchmark_results | Single partition | Partition by rate_domain | 3× faster domain queries |
| Cache taxonomy dim | Re-read each query | Broadcast join variable | Eliminates redundant I/O |
| Add computed columns | formula_json as STRING | Add materialized `is_computable BOOLEAN` | Fast filtering |

### 21.2 Moderate Risk
| Improvement | Benefit | Risk |
|---|---|---|
| Replace uuid() with deterministic hash | Idempotent reruns | Must update all FK references |
| Apply taxonomy patterns during migration | Enable grouping | May misclassify edge cases |
| Pre-validate formula_json on write | Catch corruption early | Reject valid but unusual structures |
| Materialize benchmark percentiles | Faster queries | Stale until recomputed |

### 21.3 Architecture-Level
| Improvement | Benefit | Effort |
|---|---|---|
| Move formula_json to VARIANT type | Native JSON operations, schema evolution | 1 day migration |
| Add compound index on (provider_id, rate_domain, effective_date) | Claims matching performance | 1 hour |
| Implement incremental benchmark updates (CDF-driven) | Real-time accuracy | 1 week |
| Add materialized view for "current active rules per provider" | Simplify queries | 2 hours |

---

## 22. FINAL ASSESSMENT

### What Works
1. **Schema design is excellent** — The tables, relationships, and expression tree concept are healthcare-industry-appropriate
2. **Capitation data is clean** — 2,257 rows with correct structure and values
3. **Rate_numeric is mostly reliable** — 97.5% populated with real dollar amounts
4. **Temporal coverage** — 99.4% have effective dates
5. **CDF enabled** — Change tracking available for all reimbursement tables

### What's Broken
1. **Formula misclassification corrupts computation** — 22% of PERCENTAGE rules
2. **Carve-outs completely missing** — 0 rows from 4,174 source exceptions
3. **Taxonomy disconnected** — Beautiful hierarchy, zero usage
4. **Stop-loss semantics corrupted** — Days stored as dollars
5. **No computation engine** — Design docs describe what code doesn't exist
6. **Benchmarks statistically invalid** — 60% from <3 providers, all "estimated"

### Overall Grades
| Dimension | Grade |
|-----------|-------|
| Schema Design & Extensibility | A |
| Data Quality & Correctness | D |
| Computational Readiness | F |
| Benchmark Trustworthiness | D- |
| Claims Integration Readiness | F |
| Operational Usability | C+ (lookup works, computation doesn't) |
| Design Documentation | A+ |
| Implementation vs Design Gap | D (30% implemented) |

### The Core Paradox
This is the most **well-designed but poorly-populated** reimbursement system I've reviewed. The schema could support a production pricing engine. The data makes it barely suitable for rate lookups. The fix path is clear: validate and re-migrate data using the rules the taxonomy already provides, then build the evaluation engine the design docs already specify.

---

## 23. IMMEDIATE ACTION ITEMS

### P0: Data Corruption Fixes (8 hours)
1. **Fix PERCENTAGE misclassification** — Rules where rate_numeric > 100 and formula contains dollar text should be FIXED, not PERCENTAGE
2. **Fix stop-loss column confusion** — Distinguish days vs. dollars in attachment_level; separate reimburse_rate from reimburse_percentage
3. **Apply taxonomy normalization** — Run dim_service_line_patterns against service_category_raw to populate a normalized service_line_code column
4. **Populate carve-outs** — Re-examine the 4,174 "exception" records with expanded ILIKE patterns

### P1: Foundation Work (2 weeks)
1. **Implement deterministic rule_id** — sha2 hash of natural key
2. **Build formula evaluator** — Python class that parses formula_json and computes results
3. **Create validation view** — Surface all rules where formula_json internal type ≠ formula_type
4. **Rebuild benchmarks** — Only groups with ≥5 providers; mark others as "insufficient data"
5. **Add PROFESSIONAL domain** — Identify physician/professional rates in source data

### P2: Engine Build (1 month)
1. **ClaimScenario interface** — Input dataclass matching design doc
2. **RuleMatcher** — Code-aware, temporal, hierarchical
3. **Full modifier chain** — Stop-loss → carve-out → lesser-of → escalator
4. **Test harness** — 100 verified claim scenarios
5. **Benchmark refresh automation** — Triggered on rate_rules changes via CDF
