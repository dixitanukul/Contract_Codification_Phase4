# PROMPT 5 — Table-by-Table Value Audit
## Enterprise Architecture Review of All Extraction Artifacts

**Created**: May 2026  
**Scope**: All Delta tables produced by steps 06-12 (validation through Genie serving)  
**Schema**: `dev_adb.raw`  
**Related**: `validation_layer_audit.md`, `consolidation_layer_audit.md`

---

# EXECUTIVE SUMMARY

**Of 16 tables audited:**
- **4 Mission Critical** — removing any breaks the platform
- **4 Valuable** — actively queried, serve real business needs
- **3 Nice to Have** — useful but could be views
- **3 Redundant** — duplicate data already available elsewhere
- **2 Dead Weight** — empty or architecturally misplaced

**The core problem:** 5 rate representations exist for the same underlying data. The platform needs ONE canonical rate table with views for different access patterns, not 5 independent materializations.

---

# PART 1: TABLE-BY-TABLE DEEP ANALYSIS

---

## TABLE 1: `tbl_contract_rates_all`
**Source:** `08_build_rates` | **Rows:** ~78,802 | **Columns:** 25

| # | Question | Answer |
| --- | --- | --- |
| 1 | Business purpose | Complete rate history — all extracted rates with supersession tracking |
| 2 | Who consumes | Genie Space queries, Dashboard, Intelligence benchmarks, state engine (indirectly) |
| 3 | Actively used downstream | **YES** — `tbl_genie_rates_current` is derived from this; joined in 7+ Genie queries |
| 4 | What breaks if removed | Everything. Genie Space, Dashboard, benchmarks, spend analysis ALL fail |
| 5 | Canonical or derived | **CANONICAL** — the primary rate store |
| 6 | Duplicative | YES — overlaps with `tbl_reimb_rate_rules` (21K rows, same data different structure) |
| 7 | Query-efficient | MODERATE — 78K rows is fine, but querying current rates requires `WHERE status='current'` filter every time |
| 8 | Future-proof | NO — `effective_date` is STRING (not DATE), `amendment_order` is DOUBLE (not INT) |
| 9 | Temporal modeling | PARTIAL — has `status`, `superseded_by`, `superseded_date` but no valid_from/valid_to |
| 10 | Reimbursement intelligence | YES — core input for benchmarking and rate comparison |
| 11 | Retrieval support | NO — rates aren't embedded or VS-indexed |
| 12 | Analytics support | YES — `rate_numeric` enables aggregation; `program_normalized` enables grouping |
| 13 | Schema correct | NO — STRING dates, DOUBLE for integer fields, no NOT NULL constraints |
| 14 | Normalization correct | NO — `provider_name` denormalized on every row (join to dim instead) |
| 15 | Should exist | **YES — Mission Critical** |

**Classification: MISSION CRITICAL** ⭐

**Schema issues to fix:**
- `effective_date` → DATE (already have `effective_date_parsed` column)
- `amendment_order` → INT
- Remove `provider_name` (join to `dim_provider_canonical`)
- Add `canonical_provider_id` FK
- Consider partitioning by `provider_id` at 10K+ provider scale

---

## TABLE 2: `tbl_contract_financial_protections`
**Source:** `08_build_rates` | **Rows:** ~2,921 | **Columns:** 24

| # | Question | Answer |
| --- | --- | --- |
| 1 | Business purpose | Stop-loss thresholds, outlier provisions, exception carve-outs |
| 2 | Who consumes | Genie Space (risk queries), Dashboard (exposure analysis), Reimbursement V2 |
| 3 | Actively used downstream | YES — `tbl_reimb_stop_loss` (741 rows) is derived from this |
| 4 | What breaks if removed | Risk classification queries fail; stop-loss intelligence lost |
| 5 | Canonical or derived | **CANONICAL** — primary stop-loss store |
| 6 | Duplicative | PARTIALLY — `tbl_reimb_stop_loss` duplicates the stop_loss subset |
| 7 | Query-efficient | YES — 2.9K rows, well-typed (threshold_numeric, reimbursement_pct_numeric) |
| 8 | Future-proof | MOSTLY — has `effective_date_parsed`, typed numerics |
| 9 | Temporal modeling | NO — no supersession tracking for protection terms |
| 10 | Reimbursement intelligence | **CRITICAL** — stop-loss is essential for reimbursement accuracy |
| 11 | Retrieval support | NO |
| 12 | Analytics support | YES — numeric columns enable comparison |
| 13 | Schema correct | MOSTLY — `aggregate_cap` and `corridor` still STRING (need DOUBLE) |
| 14 | Normalization correct | Same denormalization issue (provider_name repeated) |
| 15 | Should exist | **YES — Mission Critical** |

**Classification: MISSION CRITICAL** ⭐

---

## TABLE 3: `tbl_contract_regional_factors`
**Source:** `08_build_rates` | **Rows:** ~7,864 | **Columns:** 17

| # | Question | Answer |
| --- | --- | --- |
| 1 | Business purpose | County-level geographic rate multipliers (surgical, practice expense, malpractice) |
| 2 | Who consumes | Rate calculation (applies multiplier to base rate for specific county) |
| 3 | Actively used downstream | WEAKLY — no Genie query references it; only used in one serving table build |
| 4 | What breaks if removed | Geographic rate adjustments disappear; serving_regional_factors breaks |
| 5 | Canonical or derived | CANONICAL (only source of county-level factors) |
| 6 | Duplicative | NO — unique data not available elsewhere |
| 7 | Query-efficient | YES — 7.8K rows, typed numeric columns |
| 8 | Future-proof | YES — has `effective_date_parsed`, boolean version flags |
| 9 | Temporal modeling | NO — no supersession tracking |
| 10 | Reimbursement intelligence | YES — necessary for accurate rate calculation by geography |
| 11 | Retrieval support | NO |
| 12 | Analytics support | YES — geographic analysis requires this |
| 13 | Schema correct | YES — numeric factors typed, dates parsed |
| 14 | Normalization correct | Good (county as dimension, provider as FK) |
| 15 | Should exist | **YES — Valuable** |

**Classification: VALUABLE** ⭐

---

## TABLE 4: `tbl_contract_clauses_terms`
**Source:** `09_build_terms` | **Rows:** ~15,000 | **Columns:** 14

| # | Question | Answer |
| --- | --- | --- |
| 1 | Business purpose | Verbatim legal clause text, section summaries, defined terms |
| 2 | Who consumes | Genie Space (termination queries), legal team review, VS embedding source |
| 3 | Actively used downstream | YES — `tbl_retrieval_legal_units` (83K chunks) derived from this |
| 4 | What breaks if removed | Legal clause queries fail; VS index loses source material |
| 5 | Canonical or derived | **CANONICAL** — primary textual content store |
| 6 | Duplicative | SIGNIFICANTLY — overlaps with `tbl_retrieval_legal_units` (83K rows, same text chunked) |
| 7 | Query-efficient | MODERATE — 15K rows is fine; `content_text` is large (full clause verbatim) |
| 8 | Future-proof | MOSTLY — good content_type discriminator |
| 9 | Temporal modeling | NO — no versioning of clause text across amendments |
| 10 | Reimbursement intelligence | NO (terms, not rates) |
| 11 | Retrieval support | **YES** — source for legal unit chunking and embeddings |
| 12 | Analytics support | PARTIAL — clause counts useful; text analytics require NLP |
| 13 | Schema correct | YES — well-structured with `content_type`, `topic`, `section_number` |
| 14 | Normalization correct | Good (content_type discriminator pattern) |
| 15 | Should exist | **YES — Mission Critical** |

**Classification: MISSION CRITICAL** ⭐

**Note:** This table should be the SOLE text store. `tbl_retrieval_legal_units` should be a DERIVED chunked view, not a separate materialization that drifts.

---

## TABLE 5: `tbl_contract_codes_events`
**Source:** `09_build_terms` | **Rows:** ~3,000 | **Columns:** 13

| # | Question | Answer |
| --- | --- | --- |
| 1 | Business purpose | Medical codes (CPT/HCPCS/ICD/Revenue) + HAC/Never Event policies |
| 2 | Who consumes | Genie Space (code queries), claims adjudication (future), compliance |
| 3 | Actively used downstream | WEAKLY — queried in Genie but not consumed by platform layer |
| 4 | What breaks if removed | Code lookup queries fail; no downstream table depends on it |
| 5 | Canonical or derived | CANONICAL — unique code-to-contract mapping |
| 6 | Duplicative | NO — unique data |
| 7 | Query-efficient | YES — 3K rows, good indexing potential |
| 8 | Future-proof | MOSTLY — when claims connect, code ↔ rate joining becomes critical |
| 9 | Temporal modeling | NO |
| 10 | Reimbursement intelligence | **FUTURE** — code-to-rate mapping enables claims-based validation |
| 11 | Retrieval support | NO |
| 12 | Analytics support | YES — code frequency analysis, HAC policy comparison |
| 13 | Schema correct | YES — clean discriminator pattern |
| 14 | Normalization correct | Good |
| 15 | Should exist | **YES — Valuable** |

**Classification: VALUABLE** ⭐

---

## TABLE 6: `tbl_contract_parties`
**Source:** `09_build_terms` | **Rows:** ~1,000 | **Columns:** 16

| # | Question | Answer |
| --- | --- | --- |
| 1 | Business purpose | Contracting entities: legal names, DBA, Tax IDs, NPIs, signatories |
| 2 | Who consumes | Genie Space (party queries), entity resolution, compliance verification |
| 3 | Actively used downstream | WEAKLY — `dim_provider_canonical` should reference this but doesn't directly |
| 4 | What breaks if removed | Party/signatory queries fail; NPI/TIN lookups lost |
| 5 | Canonical or derived | CANONICAL — only source of NPI/TIN/signatory data |
| 6 | Duplicative | NO — unique data |
| 7 | Query-efficient | YES — 1K rows |
| 8 | Future-proof | YES — NPI/TIN essential for claims integration |
| 9 | Temporal modeling | NO — doesn't track party changes across amendments |
| 10 | Reimbursement intelligence | INDIRECT — TIN routing for claims |
| 11 | Retrieval support | NO |
| 12 | Analytics support | MINIMAL |
| 13 | Schema correct | YES — well-commented, good discriminator (party_role) |
| 14 | Normalization correct | Good |
| 15 | Should exist | **YES — Valuable** |

**Classification: VALUABLE** ⭐

---

## TABLE 7: `tbl_contract_services_quality`
**Source:** `09_build_terms` | **Rows:** ~2,000 | **Columns:** 14

| # | Question | Answer |
| --- | --- | --- |
| 1 | Business purpose | Covered services, DOFR delegations, quality programs |
| 2 | Who consumes | Genie Space (service coverage queries, delegation lookups) |
| 3 | Actively used downstream | WEAKLY — queried in Genie, not consumed by platform |
| 4 | What breaks if removed | Service coverage and delegation queries fail |
| 5 | Canonical or derived | CANONICAL — unique DOFR and service data |
| 6 | Duplicative | NO |
| 7 | Query-efficient | YES — 2K rows |
| 8 | Future-proof | YES — DOFR critical for delegation oversight |
| 9 | Temporal modeling | NO |
| 10 | Reimbursement intelligence | INDIRECT — carve-outs affect rate applicability |
| 11 | Retrieval support | NO |
| 12 | Analytics support | YES — delegation coverage comparison |
| 13 | Schema correct | YES |
| 14 | Normalization correct | Good |
| 15 | Should exist | **YES — Nice to Have** (becomes Valuable with operations integration) |

**Classification: NICE TO HAVE** (upgrades to Valuable when operational) ⭐

---

## TABLE 8: `tbl_contract_documents_master`
**Source:** `10_build_documents` | **Rows:** ~3,518 | **Columns:** 45

| # | Question | Answer |
| --- | --- | --- |
| 1 | Business purpose | Document spine — one row per PDF, all metadata, amendment chain |
| 2 | Who consumes | Genie Space (timeline queries), 08_build_rates (status fix), 12_build_genie |
| 3 | Actively used downstream | **YES** — foundational for amendment_timeline, provider_profile, state_engine |
| 4 | What breaks if removed | Amendment chain reconstruction fails; provider profile breaks; state engine loses input |
| 5 | Canonical or derived | **CANONICAL** — primary document registry |
| 6 | Duplicative | PARTIALLY — overlaps with `tbl_v2_contract_registry` (1,948 rows, different grain) |
| 7 | Query-efficient | MODERATE — 45 columns is wide; many rarely queried |
| 8 | Future-proof | PARTIAL — STRING dates need migration |
| 9 | Temporal modeling | YES — `amendment_order`, `effective_date_parsed`, `doc_category` enable timeline |
| 10 | Reimbursement intelligence | INDIRECT — provides temporal context for rates |
| 11 | Retrieval support | YES — source for document-level retrieval filters |
| 12 | Analytics support | YES — document counts, amendment depth, coverage analysis |
| 13 | Schema correct | MIXED — 45 cols is too wide; some should split out |
| 14 | Normalization correct | NO — 74 cols implies multiple concerns crammed into one table |
| 15 | Should exist | **YES — Mission Critical** |

**Classification: MISSION CRITICAL** ⭐

**Schema issue:** 45 columns is too wide. Should split into:
- `tbl_documents_core` (20 cols: IDs, dates, types, lineage)
- `tbl_documents_extraction_meta` (20 cols: coverage scores, validation flags)
- `tbl_documents_content_summary` (remaining: agreement_type, payment_type, etc.)

---

## TABLE 9: `dim_provider_canonical`
**Source:** `10_build_documents` | **Rows:** 456 | **Columns:** 12

| # | Question | Answer |
| --- | --- | --- |
| 1 | Business purpose | Identity resolution: 456 provider_ids → 278 distinct facilities |
| 2 | Who consumes | EVERY query that needs facility-level grouping; Genie, Dashboard, Intelligence |
| 3 | Actively used downstream | **YES** — joined in nearly all downstream tables (top join on 4+ tables) |
| 4 | What breaks if removed | Facility-level analytics impossible; duplicate providers pollute results |
| 5 | Canonical or derived | **CANONICAL** — the authority on provider identity |
| 6 | Duplicative | NO — unique |
| 7 | Query-efficient | YES — 456 rows, fast join |
| 8 | Future-proof | YES — handles many-to-one ID resolution |
| 9 | Temporal modeling | NO — doesn't track when ID mappings change |
| 10 | Reimbursement intelligence | YES — facility grouping essential for benchmarks |
| 11 | Retrieval support | YES — canonical name for VS filters |
| 12 | Analytics support | **CRITICAL** — without this, all analytics double-count |
| 13 | Schema correct | YES — clean, well-commented |
| 14 | Normalization correct | YES — proper dimension table |
| 15 | Should exist | **YES — Mission Critical** (should be promoted to a true UC dimension) |

**Classification: MISSION CRITICAL** ⭐ (the best-designed table in the system)

---

## TABLE 10: `tbl_genie_rates_current`
**Source:** `12_build_genie` | **Rows:** ~5,000 | **Columns:** 15

| # | Question | Answer |
| --- | --- | --- |
| 1 | Business purpose | Deduplicated current rates for Genie Space natural language queries |
| 2 | Who consumes | Genie Space exclusively |
| 3 | Actively used downstream | YES — primary table for all NL rate queries |
| 4 | What breaks if removed | Genie Space rate queries fail |
| 5 | Canonical or derived | **DERIVED** — filtered/deduped view of `tbl_contract_rates_all` |
| 6 | Duplicative | **YES** — should be a VIEW not a TABLE |
| 7 | Query-efficient | YES — pre-filtered to current only, properly typed dates |
| 8 | Future-proof | MODERATE |
| 9 | Temporal modeling | NO — current snapshot only (by design) |
| 10 | Reimbursement intelligence | YES — Genie answers rate questions |
| 11 | Retrieval support | NO |
| 12 | Analytics support | YES — clean for aggregation |
| 13 | Schema correct | YES — well-typed, canonical names resolved |
| 14 | Normalization correct | ACCEPTABLE for serving table |
| 15 | Should exist | **As a VIEW, not a table** |

**Classification: NICE TO HAVE** (should be materialized view on rates_all)

**Recommendation:** Replace with:
```sql
CREATE VIEW genie_rates_current AS
SELECT ... FROM tbl_contract_rates_all
WHERE status = 'current' AND is_latest_version = true
```

---

## TABLE 11: `tbl_genie_amendment_timeline`
**Source:** `12_build_genie` | **Rows:** ~3,518 | **Columns:** 20+

| # | Question | Answer |
| --- | --- | --- |
| 1 | Business purpose | Amendment chain per provider for Genie timeline queries |
| 2 | Who consumes | Genie Space, `platform/02_state_engine` |
| 3 | Actively used downstream | YES — state engine reads this to populate contract_registry |
| 4 | What breaks if removed | State engine population fails; Genie timeline queries fail |
| 5 | Canonical or derived | **DERIVED** — subset of `tbl_contract_documents_master` |
| 6 | Duplicative | **YES** — near-complete overlap with documents_master |
| 7 | Query-efficient | YES — optimized for timeline display |
| 8 | Future-proof | NO — creates circular dependency (state engine reads from it) |
| 9 | Temporal modeling | YES — ordered amendment chain |
| 10 | Reimbursement intelligence | INDIRECT |
| 11 | Retrieval support | NO |
| 12 | Analytics support | YES — amendment depth analysis |
| 13 | Schema correct | MIXED — STRING columns that should be typed (exhibits_replaced_count) |
| 14 | Normalization correct | Poor — denormalized from documents_master |
| 15 | Should exist | **As a VIEW, not a table** |

**Classification: REDUNDANT** (should be view on documents_master)

---

## TABLE 12: `tbl_genie_provider_profile`
**Source:** `12_build_genie` | **Rows:** 278 | **Columns:** 20+

| # | Question | Answer |
| --- | --- | --- |
| 1 | Business purpose | Pre-joined facility-level summary for Genie overview queries |
| 2 | Who consumes | Genie Space exclusively |
| 3 | Actively used downstream | YES — Genie provider overview queries |
| 4 | What breaks if removed | "Tell me about Provider X" queries fail |
| 5 | Canonical or derived | **DERIVED** — aggregation of rates + docs + dim |
| 6 | Duplicative | YES — can be reconstructed from base tables |
| 7 | Query-efficient | YES — 278 rows, pre-aggregated |
| 8 | Future-proof | MODERATE |
| 9 | Temporal modeling | NO |
| 10 | Reimbursement intelligence | PARTIAL — has avg_inpatient_per_diem |
| 11 | Retrieval support | NO |
| 12 | Analytics support | YES — portfolio-level summaries |
| 13 | Schema correct | YES |
| 14 | Normalization correct | ACCEPTABLE for serving aggregate |
| 15 | Should exist | **YES as materialized aggregate — refreshed on rebuild** |

**Classification: NICE TO HAVE** (useful performance optimization for Genie)

---

## TABLE 13: `tbl_genie_contract_terms`
**Source:** `12_build_genie` | **Rows:** ~5,000 | **Columns:** 12

| # | Question | Answer |
| --- | --- | --- |
| 1 | Business purpose | Optimized terms table for Genie NL queries |
| 2 | Who consumes | Genie Space |
| 3 | Actively used downstream | YES — Genie clause/term queries |
| 4 | What breaks if removed | Genie term queries fail (but could hit clauses_terms directly) |
| 5 | Canonical or derived | **DERIVED** — subset of `tbl_contract_clauses_terms` |
| 6 | Duplicative | **YES** — same data as clauses_terms with Genie optimizations |
| 7 | Query-efficient | YES — pre-filtered for Genie |
| 8 | Future-proof | NO — will drift from source |
| 9 | Temporal modeling | NO |
| 10 | Reimbursement intelligence | NO |
| 11 | Retrieval support | PARTIAL |
| 12 | Analytics support | Covered by source table |
| 13 | Schema correct | YES |
| 14 | Normalization correct | N/A (serving copy) |
| 15 | Should exist | **NO — Genie should query clauses_terms directly** |

**Classification: REDUNDANT** (Genie Space instruction should point to clauses_terms)

---

## TABLE 14: `tbl_v2_contract_registry`
**Source:** `platform/02_state_engine` | **Rows:** 1,948 | **Columns:** 18

| # | Question | Answer |
| --- | --- | --- |
| 1 | Business purpose | Contract-level entity with status, type, payment model classification |
| 2 | Who consumes | Intelligence layer (renewal priority, leverage), evaluation harness |
| 3 | Actively used downstream | WEAKLY — intelligence tables read it; no operational system |
| 4 | What breaks if removed | Intelligence pipeline loses contract-level context |
| 5 | Canonical or derived | **DERIVED** — populated FROM `tbl_genie_amendment_timeline` (circular) |
| 6 | Duplicative | **SIGNIFICANTLY** — overlaps documents_master + amendment_timeline |
| 7 | Query-efficient | YES — 1,948 rows, well-typed |
| 8 | Future-proof | ARCHITECTURALLY CORRECT — this SHOULD be canonical (but isn't due to circular dep) |
| 9 | Temporal modeling | PARTIAL — has effective_from/to but not bitemporal |
| 10 | Reimbursement intelligence | YES — contract_id links to rate_rules |
| 11 | Retrieval support | INDIRECT |
| 12 | Analytics support | YES — contract portfolio analysis |
| 13 | Schema correct | YES — SHA256 contract_id, proper types |
| 14 | Normalization correct | YES |
| 15 | Should exist | **YES — should be CANONICAL (currently derived, invert dependency)** |

**Classification: VALUABLE** (architecturally correct, operationally inverted)

---

## TABLE 15: `tbl_v2_amendment_registry`
**Source:** `platform/02_state_engine` | **Rows:** 1,570 | **Columns:** 17

| # | Question | Answer |
| --- | --- | --- |
| 1 | Business purpose | Amendment scope classification (FULL_REPLACEMENT, EXHIBIT_SPECIFIC, etc.) |
| 2 | Who consumes | Should be consumed by rate supersession logic — but isn't |
| 3 | Actively used downstream | **NO** — nothing reads scope_type to determine what to supersede |
| 4 | What breaks if removed | Nothing currently. Intelligence layer doesn't depend on it |
| 5 | Canonical or derived | DERIVED (from amendment_timeline) |
| 6 | Duplicative | YES — duplicates classification already in amendment_timeline |
| 7 | Query-efficient | YES — 1,570 rows |
| 8 | Future-proof | YES — scope classification is the RIGHT approach |
| 9 | Temporal modeling | YES — amendment_order + effective_date |
| 10 | Reimbursement intelligence | SHOULD — if supersession used scope_type, this would be critical |
| 11 | Retrieval support | NO |
| 12 | Analytics support | PARTIAL — amendment pattern analysis |
| 13 | Schema correct | YES |
| 14 | Normalization correct | YES |
| 15 | Should exist | **YES — but must be WIRED INTO supersession logic** |

**Classification: DEAD WEIGHT** (correct design, zero consumption)

---

## TABLE 16: `tbl_v2_rate_facts_bitemporal`
**Source:** `platform/01_execute_ddl` | **Rows:** **0 (EMPTY)** | **Columns:** 24

| # | Question | Answer |
| --- | --- | --- |
| 1 | Business purpose | Bitemporal rate store with valid_from/to and tx_from/to |
| 2 | Who consumes | Nobody — never populated |
| 3 | Actively used downstream | **NO** |
| 4 | What breaks if removed | Nothing |
| 5 | Canonical or derived | INTENDED CANONICAL — never materialized |
| 6 | Duplicative | Would replace rates_all IF populated |
| 7 | Query-efficient | N/A |
| 8 | Future-proof | YES — correct design for point-in-time queries |
| 9 | Temporal modeling | **YES — the only table with proper bitemporal columns** |
| 10 | Reimbursement intelligence | WOULD BE if populated |
| 11 | Retrieval support | NO |
| 12 | Analytics support | WOULD BE |
| 13 | Schema correct | YES — best schema design in the platform |
| 14 | Normalization correct | YES |
| 15 | Should exist | **YES — but must be POPULATED** |

**Classification: DEAD WEIGHT** (aspirational architecture never realized)

---

# PART 2: CLASSIFICATION SUMMARY

| Classification | Tables | Action |
| --- | --- | --- |
| **Mission Critical** | `tbl_contract_rates_all`, `tbl_contract_financial_protections`, `tbl_contract_clauses_terms`, `tbl_contract_documents_master`, `dim_provider_canonical` | KEEP — fix schemas |
| **Valuable** | `tbl_contract_regional_factors`, `tbl_contract_codes_events`, `tbl_contract_parties`, `tbl_v2_contract_registry` | KEEP — enhance |
| **Nice to Have** | `tbl_contract_services_quality`, `tbl_genie_rates_current`, `tbl_genie_provider_profile` | CONVERT to views or materialized views |
| **Redundant** | `tbl_genie_amendment_timeline`, `tbl_genie_contract_terms`, `tbl_reimb_rate_rules` | ELIMINATE — replace with views |
| **Dead Weight** | `tbl_v2_rate_facts_bitemporal` (empty), `tbl_v2_amendment_registry` (unused) | POPULATE or DROP |

---

# PART 3: ARCHITECTURE THEATER IDENTIFICATION

## Tables Created for Architecture Theater:

| Table | Why It's Theater |
| --- | --- |
| `tbl_v2_rate_facts_bitemporal` | 24-column bitemporal design — never populated. Pure DDL aspiration. |
| `tbl_v2_amendment_registry` | Correct scope classification — nothing reads it. Designed, never wired. |
| `tbl_reimb_formula_components` | Expression tree decomposition — empty. Over-designed. |
| `tbl_reimb_escalators` | Rate escalation tracking — empty. |
| `tbl_reimb_conditions` | Conditional rate logic — empty. |
| `tbl_retrieval_telemetry` | Query telemetry — empty. |

**Pattern:** The platform layer has 6+ tables with beautiful schemas that were designed but never populated. This is architecture as documentation, not architecture as infrastructure.

## Extraction Artifacts Nobody Consumes:

| Artifact | Status |
| --- | --- |
| `json_consolidated/*.json` | Consumed by 08_build_rates but its data is overwritten by 11a-fix |
| `validation.schema_version` in JSON | Only used as checkpoint flag, not consumed for decisions |
| `validation.date_verification` in JSON | Flags hallucinations but nothing acts on them |
| `validation.content_bucket` | Used only for reporting, not for routing or gating |

## Tables Duplicating Retrieval Metadata:

| Table | Duplication With |
| --- | --- |
| `tbl_genie_contract_terms` | `tbl_contract_clauses_terms` (same text, different columns) |
| `tbl_retrieval_legal_units` | `tbl_contract_clauses_terms` (chunked version of same text) |
| `tbl_contract_terms_vs_ready` | `tbl_contract_clauses_terms` (VS-formatted version) |

**Three tables contain the same clause text in different formats.** Should be ONE canonical text store + transformation views.

## Tables Duplicating State Engine Logic:

| Table | Duplication |
| --- | --- |
| `tbl_genie_amendment_timeline` | `tbl_contract_documents_master` (subset) → `tbl_v2_contract_registry` (re-derived) |
| `tbl_contract_rates_all.status` | Computed in 07_consolidation, overwritten in 08 11a-fix, re-classified in state_engine |
| `tbl_reimb_rate_rules.contract_id` | SHA256 computed independently from same source as contract_registry |

## Tables That Should Become Graph Structures:

| Current Table | Graph Alternative |
| --- | --- |
| `tbl_genie_amendment_timeline` | `amendment_graph(parent_doc, child_doc, scope, supersedes[])` |
| `tbl_v2_amendment_registry` | `amendment_edges(from_contract, to_amendment, scope_type, affected_exhibits[])` |
| `dim_provider_canonical` | `provider_entity_graph(entity_id, alias_ids[], facility_group)` |

## Tables That Should Become Retrieval-Time Inference:

| Current Table | Retrieval Alternative |
| --- | --- |
| `tbl_genie_contract_terms` | Generate at query time from VS index |
| `tbl_contract_clauses_terms.content_text` (sections) | Summarize at query time via LLM |
| `tbl_genie_provider_profile` | Compute on-the-fly from base tables (278 rows, fast) |

---

# PART 4: IDEAL ENTERPRISE SCHEMA ARCHITECTURE

## Layer 1: Canonical Fact Tables (Source of Truth)

```
┌─────────────────────────────────────────────────────────────────┐
│  CANONICAL LAYER (5 tables — the only mutable stores)           │
│                                                                 │
│  fact_rates            — ALL rates, bitemporal (valid + tx)     │
│  fact_documents        — Document registry (one per PDF)        │
│  fact_clauses          — Legal text store (verbatim)            │
│  fact_protections      — Stop-loss, exceptions, carve-outs      │
│  dim_provider          — Identity resolution (canonical)        │
│                                                                 │
│  RULES:                                                         │
│  - Only extraction pipeline writes to these                     │
│  - All dates are DATE/TIMESTAMP (no strings)                    │
│  - All IDs are typed (no DOUBLE for INT fields)                 │
│  - provider_name NOT stored (join to dim)                       │
│  - Every row has extraction_run_id for lineage                  │
└─────────────────────────────────────────────────────────────────┘
```

## Layer 2: State Engine (Derived, Authoritative)

```
┌─────────────────────────────────────────────────────────────────┐
│  STATE LAYER (3 tables — computed from canonical)               │
│                                                                 │
│  state_contracts       — Contract lifecycle (active/expired)    │
│  state_amendments      — Amendment graph with scope             │
│  state_supersession    — Rate → effective version mapping       │
│                                                                 │
│  RULES:                                                         │
│  - Reads ONLY from canonical layer                              │
│  - Owns supersession logic (ONE implementation)                 │
│  - Point-in-time queryable                                      │
│  - All downstream reads from here for "current" state           │
└─────────────────────────────────────────────────────────────────┘
```

## Layer 3: Serving Views (Derived, Read-Only)

```
┌─────────────────────────────────────────────────────────────────┐
│  SERVING LAYER (views + materialized views)                     │
│                                                                 │
│  view_rates_current    — Current rates (WHERE from state)       │
│  view_provider_profile — Aggregated facility summary            │
│  view_amendment_timeline — Ordered doc chain per provider       │
│  view_terms_searchable — Optimized for Genie text search        │
│  mv_benchmark_rates    — Materialized for performance           │
│                                                                 │
│  RULES:                                                         │
│  - NEVER written to directly                                    │
│  - Refresh on pipeline completion                               │
│  - Genie Space points HERE                                      │
│  - If slow, materialize. If fast, keep as view.                 │
└─────────────────────────────────────────────────────────────────┘
```

## Layer 4: Intelligence (Derived, Disposable)

```
┌─────────────────────────────────────────────────────────────────┐
│  INTELLIGENCE LAYER (tables — recomputed on demand)             │
│                                                                 │
│  intel_benchmarks      — Rate percentiles by service line       │
│  intel_spend           — Provider spend estimates               │
│  intel_savings         — Opportunity identification             │
│  intel_retrieval_units — Chunked text + embeddings              │
│                                                                 │
│  RULES:                                                         │
│  - Fully disposable (can regenerate from canonical + state)     │
│  - Only meaningful when CLAIMS_AVAILABLE = True                 │
│  - Embeddings re-synced on canonical text changes               │
└─────────────────────────────────────────────────────────────────┘
```

---

# PART 5: MIGRATION PATH (Current → Ideal)

| Phase | Action | Effort | Impact |
| --- | --- | --- | --- |
| 1 | Fix types on rates_all (STRING→DATE, DOUBLE→INT) | 2 hours | Eliminates try_cast everywhere |
| 2 | Convert 3 Genie tables to VIEWS on base tables | 4 hours | Eliminates drift, reduces maintenance |
| 3 | Populate `tbl_v2_rate_facts_bitemporal` from rates_all | 8 hours | Enables point-in-time queries |
| 4 | Wire amendment_registry.scope_type into supersession | 16 hours | Fixes incorrect rate status |
| 5 | Merge 3 clause/text tables into one canonical store | 8 hours | Eliminates text duplication |
| 6 | Remove `provider_name` from fact tables (join to dim) | 4 hours | Proper normalization |
| 7 | Drop empty DDL-only tables or populate them | 2 hours | Removes architecture theater |

**Total: ~44 hours to reach enterprise-grade schema architecture.**

---

# PART 6: THE 5 RATE REPRESENTATIONS PROBLEM

The single worst architectural decision: rate data exists in 5+ places.

| # | Location | Rows | What It Adds |
| --- | --- | --- | --- |
| 1 | `json_extract/*.json` | N/A | Raw extraction (immutable source) |
| 2 | `tbl_contract_rates_all` | 78,802 | Supersession status, amendment_order |
| 3 | `tbl_genie_rates_current` | ~5,000 | Deduplication, canonical names |
| 4 | `tbl_reimb_rate_rules` | 21,074 | formula_json, rule_id, contract_id linkage |
| 5 | `tbl_v2_rate_facts_bitemporal` | 0 | Bitemporal design (empty) |

**Correct answer:** ONE rate table (`fact_rates`) with:
- Bitemporal columns (valid_from, valid_to, tx_from, tx_to)
- Supersession via state_amendments.scope_type
- formula_json included (no separate table)
- Views for current, historical, by-provider

---

# FINAL SCORECARD

| Metric | Current | Target |
| --- | --- | --- |
| Tables in schema | 25+ | 12 (5 canonical + 3 state + 4 intel) |
| Rate representations | 5 | 1 + views |
| Supersession implementations | 3 | 1 |
| Text duplications | 3 tables | 1 + chunking view |
| Empty tables (DDL theater) | 6 | 0 |
| STRING date columns | 12+ | 0 |
| Denormalized provider_name | Every table | dim_provider JOIN only |
| Circular dependencies | 2 | 0 |
| Genie tables (should be views) | 4 | 0 tables, 4 views |

**The platform has good DATA. It has mediocre ARCHITECTURE. The data is worth preserving; the schema layout needs rationalization.**
