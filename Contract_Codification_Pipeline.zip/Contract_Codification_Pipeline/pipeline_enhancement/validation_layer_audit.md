# PROMPT 3 — Validation Layer Audit: `06_validation.py`
## Enterprise-Grade Assessment of Extraction Validation

**Created**: May 2026  
**Source**: `extraction/06_validation` (notebook ID: 338955191380352)  
**Related**: `CONTEXT_FOR_CONTINUATION.md`, `architectural_analysis.md`, `extraction_layer_deep_analysis.md`

---

# EXECUTIVE SUMMARY

**Verdict: This is REAL but NARROW validation — it protects against one specific failure mode (LLM numeric extraction gaps) while leaving 12+ enterprise risk categories completely unaddressed.**

It is NOT "superficial schema checking pretending to be governance." It IS a pragmatic, battle-hardened post-processor that solves real problems encountered during extraction. But it would **fail an enterprise audit** because it lacks the breadth expected of a validation layer in a healthcare payer contract intelligence system.

---

# PART 1: 15-DIMENSION DEEP ANALYSIS

## 1. Schema Validation ✅ REAL (but incomplete)

**What exists:**
- V6 schema compliance checking (`check_delta_readiness()`)
- Tracks `rate_numeric`, `full_clause_text`, `amendments_impact` presence
- Reports coverage percentages per document type
- Checkpoint-aware versioning (`v6.2b`) prevents re-processing

**What's missing:**
- NO schema enforcement (doesn't reject malformed documents)
- NO type validation (doesn't verify rate_numeric is actually numeric)
- NO constraint checking (rate < 0? date in 2099? NPI with wrong checksum?)
- NO schema evolution handling (what if V7 adds fields?)

**Assessment: 40/100** — measures schema presence, never enforces it.

---

## 2. Legal Consistency Validation ❌ ABSENT

**What should exist:**
- Cross-clause contradiction detection (termination says 90 days, cover page says 60)
- Regulatory compliance validation (rates violate state fee schedule caps)
- Term consistency (parties named differently across sections)
- Severability analysis (if clause X is void, does rate Y still apply?)

**What actually exists:** Nothing. Zero legal logic.

**Assessment: 0/100**

---

## 3. Temporal Consistency ❌ ABSENT

**What should exist:**
- `effective_date < expiration_date` enforcement
- Amendment date must be within parent contract's validity period
- Rate escalation dates must be sequential
- No future execution dates
- Business logic: can't have 2028 rates on a contract expiring 2025

**What actually exists:**
- `verify_date_in_text()` — but this only checks whether a date string appears in the PDF, NOT whether dates are logically consistent.

**Assessment: 5/100** — detects hallucinated dates (good) but zero temporal logic.

---

## 4. Amendment Consistency ❌ ABSENT

**What should exist:**
- Amendment references a valid parent contract
- Supersession chain is acyclic (no circular amendments)
- `exhibits_replaced` actually exist in the base agreement
- Rate changes are monotonically timestamped
- `prior_rates_superseded` aligns with rate tables

**What actually exists:**
- `amendments_impact` presence check (is the field populated?)
- Quality label: 'good' if `prior_rates_superseded` is not None, else 'partial'

**Assessment: 10/100** — checks if field exists, never validates content.

---

## 5. Reimbursement Formula Validation ❌ ABSENT

**What should exist:**
- Formula syntax validation (`fee_schedule * conversion_factor + differential`)
- Rate reasonability bounds (per diem $100-$50,000 is plausible; $0.01 or $5M is not)
- Percentage validation (0-100% for discounts, 100-500% for charge-based)
- Consistency between rate_type and rate_value (% of Medicare can't be $5,000)
- Multi-year escalation arithmetic verification

**What actually exists:**
- `_parse_rate_to_numeric()` has a sanity check: `0 < val < 100_000_000`
- That's it. No formula validation. No reasonability checks.

**Assessment: 5/100** — one sanity bound, no formula logic.

---

## 6. Hallucination Prevention ✅ REAL (strongest capability)

**What exists:**
- **Date hallucination detection:** `verify_date_in_text()` checks 40+ format variants against source PDF
- **Rate hallucination detection:** `verify_rate_in_text()` with 8 OCR-aware matching strategies
- Counts verified vs. unverified; flags "suspect" percentages in report
- OCR artifact handling (comma→period, space-after-comma, whitespace variants)

**What's missing:**
- No action taken on hallucinated values (flags them, never quarantines)
- No entity hallucination detection (provider names, NPIs, Tax IDs)
- No clause hallucination detection (full_clause_text fabricated?)
- No confidence threshold — a 90% unverified rate is still written to Delta

**Assessment: 65/100** — excellent detection, zero enforcement.

---

## 7. Citation Grounding ❌ ABSENT

**What should exist:**
- Every extracted field traceable to a page/paragraph in the source PDF
- Character offsets or page numbers stored with each extraction
- Ability to render "proof" for any claim in the JSON

**What actually exists:** Nothing. Rates are verified against full text (substring match), but no provenance is stored.

**Assessment: 0/100**

---

## 8. Confidence Scoring ⚠️ PARTIAL (misnamed)

**What exists:**
- `v6_coverage_pct` — measures field population, NOT extraction confidence
- `rate_numeric_pct` — measures post-processing success rate
- Document-type-specific weighting (Settlements scored differently from Base Agreements)

**What's missing:**
- No per-field confidence scores (how sure is the LLM about this rate?)
- No model uncertainty propagation (temperature=0.1 ≠ certainty)
- No human-review routing based on confidence

**Assessment: 20/100** — coverage scores exist but mislabeled as quality.

---

## 9. Referential Integrity ❌ ABSENT

**What should exist:**
- Exhibit references in contract_overview resolved against actual exhibits
- Provider_id in rates matches provider_id in parties
- Rate categories reference valid service lines from taxonomy
- Amendment references valid base agreement filename

**What actually exists:** Nothing. Files are processed independently.

**Assessment: 0/100**

---

## 10. Canonical Entity Validation ❌ ABSENT

**What should exist:**
- Provider name normalized against `dim_provider_canonical`
- NPI checksum validation (Luhn algorithm on positions 1-9)
- Tax ID format validation (XX-XXXXXXX)
- Address standardization
- Duplicate entity detection

**What actually exists:** Nothing. Entity validation is deferred to downstream `dim_provider_canonical` build.

**Assessment: 0/100**

---

## 11. Business Rule Enforcement ❌ ABSENT

**What should exist:**
- BSC-specific rules (e.g., capitation must include stop-loss if PMPM > $X)
- Regulatory minimums (California Knox-Keene Act requirements)
- Network adequacy validation (provider has required specialties)
- Rate change limits (>25% year-over-year flagged for review)

**What actually exists:** Nothing domain-specific beyond document classification.

**Assessment: 0/100**

---

## 12. State Consistency ❌ ABSENT

**What should exist:**
- If contract status = TERMINATED, no active rates should exist
- If amendment supersedes, prior version marked inactive
- Provider active/inactive status consistent across tables
- No orphan amendments (amendment without parent contract)

**What actually exists:** Nothing. State management happens in `07_consolidation` and `platform/02_state_engine` independently.

**Assessment: 0/100**

---

## 13. Extraction Quality Assurance ✅ REAL

**What exists:**
- `extract_medical_codes()` — regex captures codes LLM consistently misses
- `postprocess_rate_numeric()` — fills 63%→95% coverage for numeric rates
- `classify_document_subtype()` — identifies stubs, routing memos, thin documents
- `classify_bucket()` — routes documents to appropriate scoring rubric
- Report tracks extraction success rates, coverage distributions, per-bucket statistics

**What's missing:**
- No automated re-extraction trigger (flags issues but doesn't act)
- No A/B comparison (two LLM calls compared for agreement)
- No extraction drift detection (quality changing over time)

**Assessment: 70/100** — genuinely useful enrichment pipeline.

---

## 14. Observability ⚠️ PARTIAL

**What exists:**
- Print-based progress reporting (every 50 files)
- Summary statistics at end of run (bucket breakdown, coverage means)
- Exit codes (0=clean, 1=partial, 2=critical)
- Pipeline Validation Report (Cell 8) with formatted quality dashboard

**What's missing:**
- No structured logging (can't query historical run metrics)
- No alerting (unverified rates spike to 50% — nobody gets paged)
- No time-series tracking (was quality better last run?)
- No integration with Databricks monitoring/MLflow

**Assessment: 35/100** — observability for a human watching stdout, not for production.

---

## 15. Error Recovery ⚠️ PARTIAL

**What exists:**
- Try/except around file loading (errors counted, not fatal)
- Checkpoint-aware: `schema_version: 'v6.2b'` check prevents re-processing
- Rebuild gate: skips entire step if no new files detected
- `force_rebuild=true` widget for manual override

**What's missing:**
- No dead-letter queue for failed files
- No retry logic (once failed, stays failed until full re-run)
- No partial recovery (if 1 of 3,519 files corrupts, must re-run all)
- No rollback capability

**Assessment: 40/100** — won't crash, but won't self-heal.

---

# PART 2: WHAT THIS LAYER ACTUALLY PROTECTS AGAINST

| Risk | Protection Level |
| --- | --- |
| LLM fails to populate rate_numeric | ✅ STRONG (post-processor fills 95%) |
| LLM hallucinates a date not in PDF | ✅ MODERATE (flags but doesn't block) |
| LLM hallucinates a rate not in PDF | ✅ MODERATE (flags but doesn't block) |
| LLM misses medical codes in text | ✅ STRONG (regex fallback captures them) |
| OCR artifacts corrupt rate matching | ✅ STRONG (8 variant strategies) |
| Wrong document type scoring | ✅ MODERATE (doc-type-specific rubrics) |
| Stub files polluting analytics | ✅ MODERATE (subtype classification) |
| Schema version mismatch | ✅ MODERATE (checkpoint versioning) |

---

# PART 3: WHAT RISKS REMAIN UNPROTECTED

| Risk | Impact | Likelihood |
| --- | --- | --- |
| LLM fabricates entire clause text | CRITICAL | Medium (known LLM behavior) |
| Rate from wrong section (misclassification) | HIGH | High (seen in St Joseph audit) |
| Amendment supersession incorrect | HIGH | High (3 independent implementations) |
| Provider entity confusion | HIGH | Medium (456→278 requires resolution) |
| Temporal impossibility | MEDIUM | Medium (future dates, negative durations) |
| Cross-contract rate inconsistency | MEDIUM | High (same provider, conflicting rates) |
| Formula type mismatch | MEDIUM | Medium (% of Medicare stored as $) |
| Regulatory non-compliance | HIGH | Unknown (never checked) |
| Downstream table corruption | HIGH | Medium (no referential integrity) |

---

# PART 4: FAKE RIGOR vs REAL RIGOR

## Real Rigor (would survive scrutiny):
- `verify_rate_in_text()` — 8-strategy OCR-aware matching is genuinely sophisticated
- `postprocess_rate_numeric()` — comprehensive field-by-field gap-filling
- `verify_date_in_text()` — 40+ format variants including ordinals, abbreviations
- Doc-type-specific scoring — LOAs aren't penalized for missing rate tables
- Checkpoint versioning — prevents expensive re-processing
- P1 fix documentation — clear audit trail of discovered issues and corrections

## Fake Rigor (cosmetic):
- "V6 Delta-Readiness" label — measuring field presence isn't readiness
- Exit codes (0/1/2) — reported but never consumed by any orchestrator
- `v6_coverage_pct` — conflates population with correctness
- "Hallucination Detection" — detects but never blocks; the name implies prevention
- `quality_flags` in report — printed to stdout, never acted upon
- Schema version `v6.2b` — suggests formal versioning but it's just a string literal

---

# PART 5: COMPARISON AGAINST ENTERPRISE SYSTEMS

## vs. Enterprise Legal AI (e.g., Kira Systems, Luminance, Eigen Technologies)

| Capability | Enterprise Legal AI | This Implementation |
| --- | --- | --- |
| Field-level confidence scores | ✅ Per-field (0.0-1.0) | ❌ None |
| Human-in-the-loop routing | ✅ Low-confidence → reviewer | ❌ None |
| Citation provenance | ✅ Page/para/char offset | ❌ None |
| Cross-doc consistency | ✅ Entity resolution + dedup | ❌ None |
| Validation rules engine | ✅ Configurable rule DSL | ❌ Hardcoded |
| Temporal logic | ✅ Date arithmetic + validation | ❌ None |
| Audit trail | ✅ Immutable extraction log | ⚠️ JSON overwrite in-place |
| Model drift detection | ✅ Statistical monitoring | ❌ None |

**Gap: SEVERE** — This implementation lacks every enterprise governance feature except basic extraction enrichment.

## vs. Healthcare Payer Platforms (e.g., Apixio, Inovalon, Cotiviti)

| Capability | Payer Platform | This Implementation |
| --- | --- | --- |
| NPI/TIN validation | ✅ NPPES lookup + Luhn check | ❌ None |
| Rate reasonability | ✅ Medicare fee schedule bounds | ❌ 0 < x < 100M only |
| Service code validation | ✅ CMS code set authority | ⚠️ Regex pattern match only |
| Regulatory compliance | ✅ State-specific rules | ❌ None |
| Provider credentialing | ✅ Status verification | ❌ None |
| Claims integration | ✅ Rate vs. paid verification | ❌ (CLAIMS_AVAILABLE=False) |
| PHI handling | ✅ De-identification pipeline | ❌ Not addressed |

**Gap: CRITICAL** — Healthcare-specific validation is entirely absent.

## vs. Production AI Extraction (e.g., Scale AI, Anthropic Enterprise, AWS Textract+)

| Capability | Production AI Extraction | This Implementation |
| --- | --- | --- |
| Multi-model agreement | ✅ Consensus voting | ❌ Single model |
| Structured output validation | ✅ JSON Schema + Pydantic | ❌ None |
| Confidence calibration | ✅ Logprob-based | ❌ None |
| Active learning loop | ✅ Errors → retraining | ❌ None |
| Canary testing | ✅ Known-answer docs | ❌ None |
| Output quarantine | ✅ Low-quality → review queue | ❌ Flags only |
| Versioned extraction | ✅ Immutable + versioned | ❌ In-place overwrite |

**Gap: SIGNIFICANT** — No production AI patterns implemented.

---

# PART 6: ARCHITECTURAL QUESTIONS ANSWERED

## 1. Is this validation layer architecturally necessary?
**YES.** The `rate_numeric` post-processor alone justifies its existence. Without it, 37% of rates would be missing from Delta tables. The medical code regex extraction is also genuinely valuable (LLMs consistently miss embedded codes). Remove this layer and your downstream tables are measurably worse.

## 2. Is it correctly placed?
**MOSTLY YES, with caveats.** Post-extraction enrichment (filling gaps) MUST happen before table building. However, hallucination detection SHOULD happen at write-time (gate to Delta), not as a passive flag. Currently it runs after extraction but before consolidation — correct sequence, wrong enforcement model.

## 3. Is it sufficient?
**NO.** It covers 2 of 15 enterprise validation dimensions adequately. The other 13 are completely unaddressed. For a healthcare payer processing $billions in contract rates, this is insufficient.

## 4. Is it weak?
**In scope: NO** — the OCR-aware matching and rate post-processing are genuinely strong engineering.
**In breadth: YES** — it validates the extraction mechanics while ignoring the business semantics entirely.

## 5. Is it overengineered?
**NO.** If anything, it's appropriately engineered for its narrow scope. The 8 OCR variant strategies in `verify_rate_in_text()` handle real-world PDF artifacts. The doc-type-specific scoring prevents false penalties. The P1 fixes address real production issues. There's no unnecessary complexity.

## 6. What should be added?

| Priority | Addition | Effort |
| --- | --- | --- |
| P0 | Rate reasonability bounds ($1-$100K per diem, $0.01-$500K case rate) | 2 hours |
| P0 | Temporal consistency (effective < expiration, no future execution) | 4 hours |
| P1 | NPI Luhn checksum validation | 1 hour |
| P1 | Per-field confidence scoring (based on verification status) | 4 hours |
| P1 | Quarantine gate (>30% unverified rates → block from Delta) | 2 hours |
| P2 | Cross-document referential integrity (amendment → parent exists) | 8 hours |
| P2 | Rate type/value consistency (% stored as % not $, $ stored as $ not %) | 4 hours |
| P3 | Citation provenance (character offsets for verified values) | 16 hours |
| P3 | Structured logging to Delta table | 8 hours |

## 7. What should be removed?
**Nothing.** Every function in this module solves a real problem. The print-based reporting is crude but not harmful. The exit codes are unused but cost nothing.

## 8. What should move to downstream verification?

| Validation | Move To | Reason |
| --- | --- | --- |
| Cross-provider rate comparison | Intelligence layer (platform/08) | Requires full corpus |
| Amendment chain validation | State Engine (platform/02) | Requires contract graph |
| Entity resolution validation | dim_provider_canonical build (10) | Requires all providers loaded |
| Service line taxonomy validation | Reimbursement migration (platform/03) | Requires taxonomy seed |
| Business rule enforcement | Serving layer (Genie/API) | Rules change; enforce at read-time |

---

# PART 7: WHEN SHOULD VALIDATION HAPPEN?

## Current: All at extraction time (06_validation)

## Correct Answer: THREE-TIER VALIDATION ARCHITECTURE

### Tier 1: Extraction-Time (keep in 06_validation)
**Purpose:** Ensure extraction output is MECHANICALLY CORRECT
- rate_numeric post-processing ✅ (already here)
- Medical code regex extraction ✅ (already here)
- Date/rate hallucination flagging ✅ (already here)
- Schema presence checks ✅ (already here)
- **ADD:** Rate reasonability bounds
- **ADD:** Temporal consistency (effective < expiration)
- **ADD:** NPI/TIN format validation
- **ADD:** Quarantine gate (block worst files from proceeding)

### Tier 2: State-Engine-Time (move to platform/02)
**Purpose:** Ensure extraction output is LOGICALLY CONSISTENT across documents
- Amendment → parent contract resolution
- Supersession chain validation (no cycles)
- Rate versioning (newer amendment's rates supersede older)
- Provider identity resolution (same entity across docs)
- Cross-document date consistency
- Orphan detection (amendments without parents)

### Tier 3: Serving-Time (new layer before Genie/API)
**Purpose:** Ensure QUERY RESULTS are BUSINESS-CORRECT
- Rate vs. claims reconciliation (when CLAIMS_AVAILABLE=True)
- Business rule enforcement (BSC-specific policies)
- Regulatory compliance checks (Knox-Keene, CMS rules)
- Freshness validation (stale rates flagged)
- Access control (user can see this provider's rates?)
- Citation grounding (every answer traceable to source)

---

# PART 8: IDEAL ENTERPRISE VALIDATION ARCHITECTURE

```
┌─────────────────────────────────────────────────────────────────────────┐
│                    EXTRACTION PIPELINE                               │
│  05_llm_extraction → raw JSON output                                │
└───────────────────────────────────┬─────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────────────┐
│  TIER 1: MECHANICAL VALIDATION (06_validation — enhanced)           │
│                                                                     │
│  ┌──────────────┐ ┌──────────────┐ ┌──────────────┐ ┌───────────┐ │
│  │ Post-Process │ │ Hallucination│ │ Schema       │ │ Quarantine│ │
│  │ rate_numeric │ │ Detection    │ │ Enforcement  │ │ Gate      │ │
│  │ medical codes│ │ date/rate    │ │ type checks  │ │ block/pass│ │
│  │ gap-fill     │ │ OCR-aware    │ │ bounds check │ │ threshold │ │
│  └──────────────┘ └──────────────┘ └──────────────┘ └───────────┘ │
│                                                                     │
│  Output: enriched JSON + validation_metadata + confidence_scores    │
│  Quarantined files → dead-letter queue for human review             │
└───────────────────────────────────┬─────────────────────────────────────┘
                                │ (only PASSED files proceed)
                                ▼
┌─────────────────────────────────────────────────────────────────────────┐
│  TIER 2: LOGICAL VALIDATION (in state_engine / consolidation)       │
│                                                                     │
│  ┌──────────────┐ ┌──────────────┐ ┌──────────────┐ ┌───────────┐ │
│  │ Referential  │ │ Temporal     │ │ Entity       │ │ Supersess │ │
│  │ Integrity    │ │ Consistency  │ │ Resolution   │ │ Chain     │ │
│  │ amend→parent │ │ date logic   │ │ canonical ID │ │ validation│ │
│  │ exhibit refs │ │ sequencing   │ │ NPI→provider │ │ no cycles │ │
│  └──────────────┘ └──────────────┘ └──────────────┘ └───────────┘ │
│                                                                     │
│  Output: validated graph + integrity_report + conflict_log          │
│  Conflicts → resolution queue (auto-resolve or escalate)            │
└───────────────────────────────────┬─────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────────────┐
│  TIER 3: SEMANTIC VALIDATION (at serving/query time)                │
│                                                                     │
│  ┌──────────────┐ ┌──────────────┐ ┌──────────────┐ ┌───────────┐ │
│  │ Business     │ │ Regulatory   │ │ Freshness    │ │ Citation  │ │
│  │ Rules Engine │ │ Compliance   │ │ Check        │ │ Grounding │ │
│  │ BSC policies │ │ Knox-Keene   │ │ stale data   │ │ provenance│ │
│  │ rate limits  │ │ CMS rules    │ │ flags        │ │ page/para │ │
│  └──────────────┘ └──────────────┘ └──────────────┘ └───────────┘ │
│                                                                     │
│  Output: validated response + confidence + citations + warnings     │
└─────────────────────────────────────────────────────────────────────────┘
```

---

# PART 9: OBSERVABILITY TARGET STATE

```sql
-- Validation telemetry table (should exist but doesn't)
CREATE TABLE dev_adb.raw.tbl_validation_telemetry (
  run_id STRING,
  run_timestamp TIMESTAMP,
  filename STRING,
  provider_id STRING,
  tier STRING,  -- 'mechanical' | 'logical' | 'semantic'
  check_name STRING,
  check_result STRING,  -- 'PASS' | 'FAIL' | 'WARN' | 'SKIP'
  severity STRING,  -- 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW'
  detail_json STRING,
  confidence_score FLOAT,
  action_taken STRING  -- 'enriched' | 'quarantined' | 'flagged' | 'blocked'
);
```

---

# FINAL VERDICT

| Dimension | Score |
| --- | --- |
| Architecturally necessary? | ✅ YES — without it, 37% of rates vanish |
| Correctly placed? | ✅ YES — post-extraction, pre-table-build |
| Sufficient? | ❌ NO — covers 2/15 dimensions |
| Weak? | ⚠️ NARROW — strong in scope, absent in breadth |
| Overengineered? | ❌ NO — appropriately complex for its scope |
| Would survive enterprise audit? | ❌ NO — missing 13 standard categories |
| Is it fake governance? | ❌ NO — it's real engineering solving real problems |
| Priority to fix? | P1 — add quarantine gate + reasonability bounds NOW |

**Bottom line:** This is a **competent enrichment pipeline** mislabeled as "validation." Rename it `06_enrichment_and_hallucination_check`, add 3 enforcement gates (quarantine, bounds, temporal), and build Tier 2/3 separately. The code quality is high; the architectural scope is too narrow for the label it carries.

---

# SCORECARD SUMMARY (15 Dimensions)

| # | Dimension | Score | Status |
| --- | --- | --- | --- |
| 1 | Schema Validation | 40/100 | ⚠️ Partial |
| 2 | Legal Consistency | 0/100 | ❌ Absent |
| 3 | Temporal Consistency | 5/100 | ❌ Absent |
| 4 | Amendment Consistency | 10/100 | ❌ Absent |
| 5 | Reimbursement Formula | 5/100 | ❌ Absent |
| 6 | Hallucination Prevention | 65/100 | ✅ Real |
| 7 | Citation Grounding | 0/100 | ❌ Absent |
| 8 | Confidence Scoring | 20/100 | ⚠️ Partial |
| 9 | Referential Integrity | 0/100 | ❌ Absent |
| 10 | Canonical Entity | 0/100 | ❌ Absent |
| 11 | Business Rules | 0/100 | ❌ Absent |
| 12 | State Consistency | 0/100 | ❌ Absent |
| 13 | Extraction QA | 70/100 | ✅ Real |
| 14 | Observability | 35/100 | ⚠️ Partial |
| 15 | Error Recovery | 40/100 | ⚠️ Partial |
| | **WEIGHTED AVERAGE** | **~19/100** | **INSUFFICIENT** |
