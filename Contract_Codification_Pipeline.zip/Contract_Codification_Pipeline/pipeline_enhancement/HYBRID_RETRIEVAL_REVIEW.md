# HYBRID RETRIEVAL ENGINE — CRITICAL REVIEW
## BSC Provider Contract Intelligence Platform

**Reviewer:** Architecture Analysis (Automated)  
**Date:** 2026-05-28  
**Scope:** Complete evaluation of `platform/05_retrieval_engine.py` + supporting design documentation  
**Assessment:** Implementation is a **solid MVP foundation** with significant gaps between design intent and operational reality

---

## EXECUTIVE SUMMARY

The hybrid retrieval system implements a 4-channel architecture (semantic, lexical, metadata, structural) with intent-weighted Reciprocal Rank Fusion. The design documents describe an enterprise-grade system with cross-encoder reranking, 6 legal signals, citation verification, and continuous evaluation. However, only the **retrieval engine itself** (05) and the **evaluation harness shell** (11) are implemented as runnable code. The reranking service (06), citation verification (07), scenario engine (09), and leverage scoring (10) exist only as design specs.

**Maturity Rating:** 3/10 for production readiness; 7/10 for architectural vision.

| Dimension | Status | Rating |
| --- | --- | --- |
| Semantic retrieval | Implemented (VS index) | ★★★☆☆ |
| Lexical retrieval | Implemented (ILIKE, no BM25) | ★★☆☆☆ |
| Metadata retrieval | Implemented (SQL on rate_rules) | ★★★★☆ |
| Structural retrieval | Implemented (sibling expansion) | ★★☆☆☆ |
| Query understanding | Implemented (rule-based keywords) | ★★☆☆☆ |
| Reciprocal Rank Fusion | Implemented (intent-weighted) | ★★★☆☆ |
| Reranking | NOT IMPLEMENTED (design only) | ☆☆☆☆☆ |
| Citation verification | NOT IMPLEMENTED (design only) | ☆☆☆☆☆ |
| Evaluation harness | Shell only (DDL + 20 seeds) | ★☆☆☆☆ |
| Telemetry | NOT IMPLEMENTED | ☆☆☆☆☆ |

---

## PART 1: COMPONENT-LEVEL ANALYSIS

### 1.1 Semantic Retrieval (Channel 1)

**Implementation:** Vector Search similarity_search against `idx_legal_units_v2` with metadata pre-filtering.

**Strengths:**
- Uses Databricks Vector Search (managed, auto-syncing delta index)
- Supports `is_current` and `provider_name` filters at query time
- Returns 15 results (reasonable over-retrieval for fusion)
- Includes all relevant metadata columns for downstream scoring

**Critical Weaknesses:**

| Issue | Severity | Impact |
| --- | --- | --- |
| VS index may not be in READY state (documented in W3: 10% synced) | CRITICAL | Semantic channel returns empty results |
| No score_threshold — accepts anything VS returns | HIGH | Low-quality results pollute fusion |
| No query reformulation — passes raw user text directly | HIGH | Semantic drift on legal jargon queries |
| top_k=15 is too low for reranking pipeline (design calls for 50) | MEDIUM | Insufficient recall for complex queries |
| Score extraction is fragile: `row[-1] if len(row) > 9 else 0.5` | MEDIUM | Wrong column indexed if schema changes |
| No embedding model specification in code (relies on VS index config) | LOW | Implicit dependency |

**Precision Estimate:** ~55% at k=5 (semantic similarity ≠ legal authority).

### 1.2 Lexical Retrieval (Channel 2)

**Implementation:** ILIKE conjunctive matching on `tbl_retrieval_legal_units.unit_text`.

**Strengths:**
- Correctly handles temporal filtering (`is_current = TRUE`)
- Limits to 5 keywords (prevents over-constrained queries)
- Simple, no external dependencies

**Critical Weaknesses:**

| Issue | Severity | Impact |
| --- | --- | --- |
| **NOT BM25** — uses ILIKE (substring match), not token scoring | CRITICAL | No relevance ranking; row order is arbitrary |
| SQL injection via f-string interpolation of keywords | CRITICAL | Security vulnerability; also breaks on apostrophes |
| Positional scoring (0.8 - i*0.05) is meaningless without ORDER BY | HIGH | Score is random (depends on physical scan order) |
| AND conjunction of all keywords = too strict | HIGH | Fails for "Providence inpatient per diem" (requires ALL words in unit) |
| No tokenization or stemming | MEDIUM | "reimburse" won't match "reimbursement" |
| No phrase matching | MEDIUM | Can't search for "per diem" as a phrase |
| No stop-word-aware field-level boosting | LOW | Title matches treated same as body matches |

**This is the weakest channel.** The design doc specifies a proper BM25 with token scoring; the implementation is a naive substring search with fake ranking.

### 1.3 Metadata Retrieval (Channel 3)

**Implementation:** Direct SQL against `tbl_reimb_rate_rules` for RATE_LOOKUP intents only.

**Strengths:**
- **Best channel for structured queries** — directly hits normalized rate data
- Joins service category, rate domain, formula type, program, network
- Returns fully formatted text with all rate context
- Correctly scoped to RATE_LOOKUP intent only (avoids noise for clause queries)

**Weaknesses:**

| Issue | Severity | Impact |
| --- | --- | --- |
| SQL injection on provider_filter and service_filter | CRITICAL | Same f-string vulnerability |
| Only fires for RATE_LOOKUP intent — misses COMPARISON | HIGH | Comparisons need rate data too |
| No join to stop_loss or lesser_of tables | MEDIUM | Incomplete financial picture |
| No pagination or relevance ordering (just LIMIT 10) | MEDIUM | Arbitrary row selection |
| Keyword filter uses OR logic for service but AND logic overall | LOW | Inconsistent |
| Does not handle "which provider has the highest rate" (requires cross-provider scan) | HIGH | Analytics queries unsupported |

### 1.4 Structural Retrieval (Channel 4)

**Implementation:** Fetches sibling legal units from the same source document as top semantic anchors.

**Strengths:**
- Provides document context around point-match results
- Correctly excludes already-retrieved unit IDs
- Uses top-5 anchors from semantic (focused expansion)

**Critical Weaknesses:**

| Issue | Severity | Impact |
| --- | --- | --- |
| No section-type awareness — retrieves ANY sibling from same file | HIGH | Irrelevant sections (e.g., definitions when looking for rates) |
| Fixed score of 0.5 for all structural results | MEDIUM | No differentiation by proximity/relevance |
| No parent-child traversal (flat file filter only) | HIGH | Doesn't use `parent_unit_id` or section hierarchy |
| No amendment-chain expansion | HIGH | Misses linked amendments modifying same section |
| Limited to 3 source files, 5 results | MEDIUM | Shallow expansion |
| Depends entirely on semantic results (empty if semantic fails) | HIGH | Cascading failure mode |

### 1.5 Query Understanding

**Implementation:** Rule-based keyword matching for intent classification + simple tokenization.

**Strengths:**
- Fast (no LLM call required)
- Covers 5 intent types with reasonable keyword triggers
- Temporal scope detection (CURRENT vs HISTORICAL)
- Extensible dataclass model

**Critical Weaknesses:**

| Issue | Severity | Impact |
| --- | --- | --- |
| No entity extraction (providers, service lines, programs) | CRITICAL | Cannot scope retrieval to queried entity |
| No sub-intent classification | HIGH | "per diem rate" vs "stop-loss threshold" treated identically |
| Keyword overlap causes misclassification | HIGH | "rate change" triggers RATE_LOOKUP, should be TIMELINE |
| No multi-intent handling | MEDIUM | "Compare rates and show how they changed" needs COMPARISON+TIMELINE |
| No AS_OF_DATE parsing | MEDIUM | "What was the rate in 2023?" doesn't extract date |
| No program/network extraction | MEDIUM | "Medi-Cal capitation rate" doesn't isolate program |
| No query expansion or reformulation | HIGH | Legal jargon not normalized |
| No disambiguation | MEDIUM | "Providence" could be multiple entities |

**The design doc specifies LLM-powered query understanding with full entity extraction. The implementation is a 40-line keyword match.**

### 1.6 Reciprocal Rank Fusion

**Implementation:** Intent-weighted RRF with k=60 constant.

**Strengths:**
- Correct RRF formula: `weight * (1 / (k + rank))`
- Intent-specific weight profiles (5 intents × 4 channels)
- Deduplication by unit_id across channels
- Weights are reasonable (metadata 0.6 for RATE_LOOKUP, semantic 0.5 for CLAUSE_SEARCH)

**Weaknesses:**

| Issue | Severity | Impact |
| --- | --- | --- |
| Channel detection by first result's channel field is fragile | HIGH | Empty channel → "unknown" → 0.1 weight |
| k=60 is standard but not tuned for this corpus | LOW | Minor score compression |
| No score normalization across channels | MEDIUM | Raw VS similarity scores (0-1) vs positional lexical scores (0.3-0.8) |
| No multi-appearance boost | MEDIUM | Unit appearing in 3 channels gets sum, but no explicit bonus |
| Weights are hardcoded, not learned from evaluation | MEDIUM | Sub-optimal for this domain |
| No minimum score threshold on fused results | HIGH | Returns low-confidence results without warning |

---

## PART 2: CRITICAL ANALYSIS

### 2.1 Retrieval Precision

**Estimated precision@5:** 45-60% (unverified — no evaluation has been run).

**Precision failure modes:**
1. **Scope leakage** — No provider entity extraction means Provider B's rates appear in Provider A queries
2. **Stale results** — `is_current` flag depends on bootstrap correctness (83K units, untested)
3. **Type mismatch** — CLAUSE_SEARCH returns RATE_TABLE units if keywords match
4. **Semantic drift** — "Stop-loss threshold" semantically similar to "risk corridor" but legally distinct

### 2.2 Retrieval Recall

**Estimated recall@30:** 60-75%.

**Recall failure modes:**
1. **Lexical AND-conjunction** — Misses relevant docs that contain only 4/5 keywords
2. **Metadata channel fires only for RATE_LOOKUP** — Misses rate data needed for COMPARISON, TIMELINE
3. **VS index sync lag** — If <100% synced, semantic channel has blind spots
4. **No fuzzy entity matching** — "St. Joseph" won't match "St Joseph" or "Saint Joseph Medical Center"

### 2.3 Ranking Quality

**NDCG@5 estimate:** 0.40-0.55 (no reranker deployed).

The RRF fusion produces a reasonable initial ranking, but without reranking:
- Semantically similar but legally irrelevant docs rank high
- Superseded docs rank alongside current without penalty
- Broad general clauses rank above specific rate tables (inverse specificity)
- Same-section duplicates consume top-K slots

### 2.4 Noise Handling

**Current approach:** None. All retrieved results are passed through fusion without quality gates.

**Missing mechanisms:**
- No minimum similarity threshold on semantic results
- No minimum keyword density on lexical results
- No "I don't know" / low-confidence escape
- No diversity enforcement (5 results can all be from same exhibit)

### 2.5 Ambiguous Query Handling

**Current approach:** Default to GENERAL intent + CURRENT_ONLY temporal scope.

**Failure scenarios:**
- "What's the rate?" — No provider specified → retrieves random providers
- "Show me the termination clause" — Multiple providers, no scoping
- "How much does this cost?" — Ambiguous between rate lookup and exposure calculation

### 2.6 Long-Tail Query Handling

**Current approach:** Falls through to GENERAL intent (semantic 0.4, lexical 0.3, metadata 0.1, structural 0.2).

**Unsupported patterns:**
- Multi-hop: "If LOS exceeds outlier threshold at Providence, what's the per-day rate after stop-loss?"
- Aggregation: "Average per diem across all HMO providers"
- Negation: "Which providers do NOT have a stop-loss provision?"
- Conditional: "What rate applies if the patient is transferred?"
- Regulatory: "Which contracts don't meet the 90-day termination notice requirement?"

### 2.7 Legal Query Understanding

**Critical gap.** The system treats legal terminology as generic keywords:
- "Lesser-of provision" → searches for "lesser" and "provision" separately
- "Force majeure" → no special handling for Latin legal terms
- "Material breach" → "material" is too common, dilutes results
- "Sole and exclusive remedy" → standard legal phrase treated as 5 independent words

### 2.8 Numerical Query Handling

**Partially addressed** via metadata channel (rate_numeric field). However:
- "Rates above $2,000" → cannot filter numerically (ILIKE on text)
- "What's the highest rate?" → requires MAX aggregation, not retrieval
- "How does $1,500 compare to market?" → requires benchmark context
- Dollar amounts in text chunks aren't indexed for range queries

### 2.9 Amendment-Aware Retrieval

**Design intent:** Full amendment-chain resolution with supersession confidence scoring.

**Implementation reality:**
- `is_current` Boolean flag (no confidence, no "possibly superseded")
- No amendment chain traversal in retrieval
- No `superseded_by` linkage used during search
- Structural expansion doesn't follow amendment chains
- Cannot answer "What did Amendment 3 change?" without iterating all units

### 2.10 Current-State Retrieval

**Implementation:** `is_current = TRUE` filter in semantic and lexical channels.

**Gaps:**
- All rate rules from `tbl_reimb_rate_rules` are hardcoded as `is_current = TRUE` in bootstrap (line 169 of 04_legal_chunking.py)
- No point-in-time ("as of date X") capability
- No "show me what changed" differential view
- Superseded content is excluded rather than downranked (loses context)

### 2.11 Retrieval Explainability

**Current state:** Zero explainability.

**Missing:**
- No explanation of why a result was retrieved (which channel, which signal)
- No confidence score communicated to user
- No "these results may be incomplete because..." warnings
- No retrieval audit trail (which channels fired, what was filtered out)
- The `ScoredChunk.channel` field exists but is never surfaced to users

---

## PART 3: USER PERSONA SUPPORT

### Executive Users
**Support level:** WEAK (2/5)
- Can answer "What's Provider X's rate?" (simple rate lookup)
- Cannot answer portfolio-level questions ("total network spend exposure")
- No summarization layer
- No confidence indicators for decision-making

### Legal Users
**Support level:** VERY WEAK (1/5)
- No citation provenance (page numbers not reliably available)
- No amendment-chain navigation
- No "is this still current?" verification
- No conditional-logic preservation
- No cross-reference resolution

### Contract Analysts
**Support level:** MODERATE (3/5)
- Rate lookups work for single-provider, single-domain queries
- Clause search works when keywords are precise
- Timeline queries partially supported via intent routing
- Missing: side-by-side comparisons, red-flag detection

### Reimbursement Analysts
**Support level:** MODERATE (3/5)
- Metadata channel directly queries rate_rules (strongest channel)
- Rate domain filtering works
- Missing: stop-loss interaction, lesser-of calculations, escalator projections
- Missing: "what-if" scenarios

### Finance Users
**Support level:** WEAK (2/5)
- Can surface individual rates
- Cannot compute aggregate exposure, renewal costs, or savings opportunities
- No financial modeling integration
- No budget-impact projections

### Strategy Users
**Support level:** VERY WEAK (1/5)
- Cannot answer "which providers are most expensive relative to market?"
- No benchmark comparison retrieval
- No competitive positioning
- No leverage analysis context

---

## PART 4: SECURITY VULNERABILITIES

### SQL Injection (CRITICAL)

Three separate injection points via f-string interpolation:

```python
# In retrieve_lexical (line 166):
f"unit_text ILIKE '%{kw}%'"  # kw comes from user input

# In retrieve_metadata (line 218):
f"rr.provider_name ILIKE '%{parsed.provider_filter}%'"

# In retrieve_metadata (line 220):
f"rr.service_category_raw ILIKE '%{parsed.service_filter}%'"
```

**Impact:** A crafted query like `rate'; DROP TABLE tbl_retrieval_legal_units; --` could destroy data.

**Fix:** Use parameterized queries (`spark.sql(query, params={...})`) throughout.

---

## PART 5: RECOMMENDATIONS

### 5.1 Retrieval Redesign Recommendations

**Priority 1 — Fix What's Broken (Week 1):**
1. Replace all f-string SQL with parameterized queries
2. Add score_threshold=0.3 to semantic search
3. Change lexical from AND to OR with per-keyword scoring
4. Add ORDER BY to metadata channel (rate_numeric DESC or effective_date DESC)
5. Fire metadata channel for COMPARISON intent too

**Priority 2 — Proper Lexical Retrieval (Week 2):**
- Implement actual BM25 scoring using Spark's `regexp_count()` or dedicated FTS
- OR: Use Databricks Vector Search with hybrid mode (embedding + keyword) when GA
- Add phrase matching for legal terms ("per diem", "stop loss", "force majeure")
- Implement stemming via SQL UDF or pre-tokenized index

**Priority 3 — Entity-Aware Query Understanding (Week 3):**
- Add LLM-powered entity extraction (provider, program, network, service line, date)
- Build provider name fuzzy matching against `tbl_v2_contract_registry.provider_name`
- Implement sub-intent classification (rate type, clause type)
- Add query reformulation for semantic search (rewrite jargon → embedding-friendly text)

### 5.2 Cross-Encoder Reranking Strategy

**Recommended approach (pragmatic):**

| Stage | Method | Latency | When to Deploy |
| --- | --- | --- | --- |
| Stage 0 (now) | Rule-based re-scoring: state + scope + recency | <10ms | Immediately |
| Stage 1 | LLM-as-reranker via `databricks-claude-sonnet-4-5` (top-15 only) | ~3s | After basic retrieval is solid |
| Stage 2 | `bge-reranker-v2-m3` on Model Serving (30 pairs) | ~150ms | When query volume justifies |

**Stage 0 implementation (no model required):**
```
final_score = (
    0.40 * rrf_score +
    0.25 * scope_match(chunk.provider, query.provider) +
    0.20 * state_score(chunk.is_current, query.temporal) +
    0.15 * recency_decay(chunk.effective_date)
)
```

This alone would improve NDCG@5 from ~0.5 to ~0.7 by eliminating scope leakage and stale results.

### 5.3 Better Fusion Techniques

**Current RRF limitations and alternatives:**

| Technique | Advantage | When to Use |
| --- | --- | --- |
| Weighted RRF (current) | Simple, robust to score scale differences | Keep as baseline |
| Normalized score fusion | Uses actual relevance scores, not just ranks | When BM25 provides calibrated scores |
| Learned fusion (LambdaMART) | Optimizes NDCG directly on golden queries | When 200+ labeled queries available |
| Cascade fusion | Only fire expensive channels if cheap ones insufficient | Production latency optimization |
| Conditional channel gating | Skip metadata for CLAUSE_SEARCH, skip semantic for exact-code queries | Reduce noise |

**Immediate improvement:** Add a **confidence gate** after fusion — if max fused score < threshold, return "insufficient evidence" rather than low-quality results.

### 5.4 Query Planning Improvements

**Implement a query planner that decomposes complex queries:**

```
"Compare Providence and Kaiser inpatient per diem rates, including any 2024 amendments"
  → Sub-query 1: RATE_LOOKUP (provider=Providence, domain=INPATIENT, temporal=CURRENT)
  → Sub-query 2: RATE_LOOKUP (provider=Kaiser, domain=INPATIENT, temporal=CURRENT)
  → Sub-query 3: TIMELINE (provider=Providence, after=2024-01-01)
  → Sub-query 4: TIMELINE (provider=Kaiser, after=2024-01-01)
  → Synthesis: Tabular comparison with amendment annotations
```

**Implementation:** Use LLM to decompose → execute sub-queries in parallel → assemble context.

### 5.5 Metadata Weighting Improvements

**Current weights are reasonable but should be dynamic:**

- If provider is explicitly named → boost scope-matching results by 2x
- If "current" or "latest" mentioned → hard-filter `is_current = TRUE`
- If dollar amount mentioned → boost metadata channel to 0.7
- If clause/section number cited → boost lexical to 0.6 (exact match scenario)
- If "all providers" or "compare" → suppress metadata (needs cross-provider scan)

**Implement as weight modifiers on top of base profile:**
```
effective_weight = base_weight * intent_modifier * entity_modifier * temporal_modifier
```

### 5.6 Context Assembly Improvements

**Current approach:** Return flat list of scored chunks.

**Needed:**
1. **Hierarchical grouping** — Group results by source document, then by section
2. **Amendment annotation** — Attach "⚠️ Modified by Amendment 3 (2024-06-01)" inline
3. **Cross-reference resolution** — If a chunk says "per Section 4.2", include Section 4.2
4. **Conditional completeness** — If a rate has conditions ("subject to..."), include the condition
5. **Deduplication** — Same rate appearing in both metadata and lexical channels → merge, don't duplicate
6. **Context windowing** — Include 1 sibling above/below the matched unit for reading context

### 5.7 Temporal Retrieval Improvements

| Capability | Current | Needed |
| --- | --- | --- |
| Current-only filtering | Boolean `is_current` | Confidence-weighted state scoring |
| Point-in-time queries | Not supported | AS_OF_DATE filter on effective_date range |
| Rate trend queries | Not supported | Time-series retrieval with ordering |
| Amendment sequencing | Not supported | Amendment chain traversal |
| Expiration awareness | Not supported | Flag contracts nearing expiration |
| Retroactive amendments | Not supported | Handle amendments with earlier effective dates |

**Implementation priority:** Add `effective_date BETWEEN :start AND :end` filtering + amendment chain resolution using `tbl_v2_amendment_registry`.

### 5.8 Amendment-Aware Retrieval Improvements

**Current state:** Binary `is_current` flag set at bootstrap time. No runtime amendment resolution.

**Required capabilities:**
1. **Supersession chain** — For any retrieved clause, find all amendments that modified it
2. **Scope resolution** — Determine if an amendment is FULL_REPLACEMENT or EXHIBIT_SPECIFIC
3. **Delta extraction** — "What changed?" queries need diff between versions
4. **Conflicting amendments** — Handle multiple amendments modifying same section
5. **Effective date ordering** — Latest effective date wins (not latest document date)

**Implementation:**
```sql
-- For each retrieved unit, annotate with amendment context
SELECT u.*, a.amendment_id, a.summary_of_changes, a.scope_type
FROM tbl_retrieval_legal_units u
LEFT JOIN tbl_v2_amendment_registry a
  ON u.contract_id = a.contract_id
  AND a.effective_date > u.effective_date
  AND (a.scope_type = 'FULL_REPLACEMENT'
       OR a.exhibits_modified LIKE CONCAT('%', u.section_type, '%'))
```

### 5.9 Enterprise-Grade Retrieval Roadmap

**Phase 1 — Foundation Hardening (Weeks 1-2):**
- Fix SQL injection vulnerabilities
- Implement proper BM25 or hybrid search
- Add entity extraction to query understanding
- Deploy Stage 0 rule-based reranking
- Run evaluation against 20 golden queries

**Phase 2 — Intelligence Layer (Weeks 3-4):**
- LLM-powered query decomposition
- Amendment-chain resolution at retrieval time
- Cross-reference expansion
- Confidence calibration against golden queries
- Deploy citation verification (Check 2: numerical accuracy first)

**Phase 3 — Scale & Performance (Weeks 5-6):**
- Deploy cross-encoder reranker on Model Serving
- Implement retrieval caching (TTL-based for repeated queries)
- Add async parallel channel execution
- Build retrieval telemetry pipeline
- Expand golden queries to 200+ with human annotations

**Phase 4 — Advanced Capabilities (Weeks 7-8):**
- Multi-hop query planning
- Financial aggregation queries (portfolio-level)
- Benchmark comparison retrieval
- Scenario modeling integration
- Continuous evaluation with drift detection

### 5.10 Optimizations WITHOUT Quality Loss

| Optimization | Latency Savings | Quality Impact | Implementation |
| --- | --- | --- | --- |
| Cache VS results for repeated queries (TTL=5min) | -200ms per cache hit | Zero | LRU cache on query hash |
| Skip structural channel when semantic returns >10 high-confidence results | -50ms | Zero (structural adds context, not precision) | Threshold gate |
| Pre-filter metadata channel by intent before SQL execution | -30ms | Zero | Already partially done |
| Use async I/O for parallel channel execution | -100ms (total latency) | Zero | asyncio.gather() |
| Limit lexical to first 3 keywords (not 5) | -20ms | Slight improvement (less over-constraining) | Trivial |
| Cache `tbl_retrieval_legal_units` metadata stats | -10ms per query | Zero | Spark table cache |
| Skip empty channels before fusion (already done) | -5ms | Zero | Already implemented |
| Pre-compute provider name → ID mapping | -15ms | Zero | One-time lookup table |

**Total potential latency reduction:** ~400ms without any quality degradation.

---

## PART 6: GAP ANALYSIS — DESIGN vs IMPLEMENTATION

| Component | Design Doc | Implementation | Gap |
| --- | --- | --- | --- |
| Query understanding | LLM-powered, full entity extraction, sub-intent | 40-line keyword match | MASSIVE |
| Semantic retrieval | 50 results, score_threshold, query reformulation | 15 results, no threshold, raw query | LARGE |
| Lexical retrieval | BM25 with token scoring, phrase matching | ILIKE substring with fake positional score | MASSIVE |
| Metadata retrieval | Joins rate_rules + stop_loss + taxonomy, parameterized | Single-table query with SQL injection | MODERATE |
| Structural retrieval | Section hierarchy traversal, amendment chain expansion | Flat same-file sibling fetch | LARGE |
| RRF fusion | Async parallel, score normalization, confidence gate | Sequential, raw score addition, no gate | MODERATE |
| Cross-encoder reranking | bge-reranker-v2-m3 on Model Serving | NOT IMPLEMENTED | TOTAL |
| Legal signal scoring | 6 signals: state, recency, specificity, scope, authority, completeness | NOT IMPLEMENTED | TOTAL |
| Citation verification | 6-check pipeline with NLI | NOT IMPLEMENTED | TOTAL |
| Evaluation | 200+ queries, NDCG, MRR, state_precision, automated | 20 seed queries, no execution logic | MASSIVE |
| Telemetry | Per-query latency, precision, coverage, drift detection | NOT IMPLEMENTED | TOTAL |

---

## PART 7: FINAL ASSESSMENT

### What Works
1. The 4-channel architecture is sound and well-motivated
2. Intent-weighted RRF is the right fusion approach
3. Metadata channel for rate lookups is the strongest path
4. Legal unit model (83K units) is a solid foundation
5. Design documentation is exceptionally thorough

### What's Broken
1. SQL injection vulnerabilities (3 injection points)
2. Lexical channel provides no meaningful ranking
3. No entity extraction = no scope enforcement
4. No reranking = semantic drift dominates results
5. No confidence scoring = users can't trust answers
6. No evaluation = quality is unknown and unmeasured

### Highest-Impact Single Change
**Implement entity extraction + scope filtering.** A single LLM call to extract `{provider, service_line, program, temporal_scope}` from the query, then hard-filter retrieval results to matching providers, would eliminate the #1 precision failure mode (scope leakage) and improve precision@5 by an estimated 15-20 percentage points.

### Risk Assessment
- **Operational risk:** LOW — system fails gracefully (returns empty or low-quality, doesn't crash)
- **Security risk:** HIGH — SQL injection is exploitable
- **Quality risk:** HIGH — no evaluation means degradation goes undetected
- **Legal risk:** MEDIUM — hallucinated contract terms without verification creates liability

---

*End of review. The architecture is well-designed on paper — the implementation needs to close the gap between vision and reality, starting with security fixes and entity extraction.*
