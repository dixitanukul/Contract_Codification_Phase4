# ARCHITECTURE CRITIQUE — PROVIDER CONTRACT INTELLIGENCE PLATFORM
## Complete End-to-End Assessment
**Generated**: 2026-05-24  
**Scope**: 12-layer evaluation, risk taxonomy, improvement roadmap  
**Basis**: Full source review of extraction/, platform/, sql/, docs/, demo notebook

---

## EXECUTIVE SUMMARY

This platform achieves a remarkable feat: transforming 27 GB of unstructured healthcare contract PDFs into queryable intelligence in a single-developer effort. The extraction pipeline is **production-grade** (checkpoint recovery, 2-tier OCR, parallel processing). The intelligence platform is **architecturally ambitious but partially implemented** — 4 of 12 platform modules exist only in design docs. The retrieval architecture is **well-designed on paper but operates in degraded mode** (no reranker, unstable fulltext index). The demo notebook is **self-contained and impressive** but runs a completely separate retrieval pipeline from the platform modules.

**Overall Grade**: B+ for a prototype/MVP, C for production readiness, A for architectural vision.

---

## LAYER-BY-LAYER EVALUATION

---

### LAYER 1: INGESTION LAYER

**Purpose**: Discover, prefetch, and prepare 10,372 PDFs from a UC Volume for processing.

**Strengths**:
- Incremental discovery with parquet-based registry cache (instant restart)
- NVMe SSD prefetch eliminates Volume I/O latency during extraction (32 parallel threads)
- Provider-folder-aware sampling enables controlled subset processing
- Stale-cache detection compares actual PDF count vs cached count
- Empty-file handling prevents downstream failures

**Weaknesses**:
- Single-machine architecture: all 27 GB must fit on local disk (or stream)
- No partitioning strategy: cannot distribute discovery across workers
- File registry is an in-memory dict, not a Delta table — invisible to other notebooks
- No file integrity validation (checksum, corruption detection)
- Provider folder structure assumed stable — no handling of folder renames/moves

**Architectural Risks**:
- Local SSD space exhaustion (27 GB + working space needed)
- Registry cache invalidation race condition if multiple sessions run concurrently
- No idempotency guarantee if prefetch is interrupted mid-copy

**Technical Debt**:
- File registry should be a Delta table for observability and lineage
- Missing: file-level processing status (PENDING/PROCESSING/COMPLETE/FAILED)
- No integration with Unity Catalog Volume metadata APIs

**Scalability Concerns**:
- Cannot scale beyond single-node (all files must be visible to one driver)
- os.walk() is O(n) on file count — 10K files is fine, 100K would stall
- shutil.copy2 does not leverage cloud-native copy semantics

**Demo Concerns**: None — ingestion runs offline before demo.

**Production Concerns**:
- No alerting on discovery failures
- No SLA monitoring for Volume availability
- No handling of corrupted/truncated PDFs at discovery time

---

### LAYER 2: EXTRACTION LAYER (OCR + LLM)

**Purpose**: Convert raw PDFs to structured JSON via 2-tier OCR + Claude Sonnet 4.5 extraction.

**Strengths**:
- 2-tier OCR strategy is excellent: pypdf (free, 14 processes, 82% coverage) → ai_parse_document (paid, handles scanned)
- ProcessPoolExecutor for pypdf bypasses GIL — true 5.1x speedup measured
- Direct REST API to Claude (not ai_query) eliminates Spark overhead cascade failures
- 3 concurrent LLM workers with per-file HTTP timeout (1800s)
- Document-type-specific prompts (4 types) improve extraction quality
- Chunking strategy for >150K char files (80K segments, merged results)
- JSON repair for truncated LLM output (closes open brackets)
- Checkpoint-resumable (step1_parsed_v2.parquet preserves state)
- Version dedup (keeps highest _vN per document key)

**Weaknesses**:
- Single-threaded checkpoint writes (parquet append, not Delta MERGE)
- No retry logic for transient LLM API failures (just logs and continues)
- Chunking merge logic is simplistic (concatenation, not semantic reconciliation)
- No cost tracking (token consumption per file not logged)
- Extraction confidence is not measured — all outputs treated equally
- No A/B comparison between extraction versions (no gold standard)

**Architectural Risks**:
- REST API approach means no automatic load balancing or rate limit handling
- 1800s timeout per file is generous — a stuck request blocks a worker for 30 minutes
- LLM model version changes could silently change extraction quality
- No circuit breaker pattern: if API is degraded, all 3 workers send failing requests

**Technical Debt**:
- Quarantine logic exists but quarantined files are silently skipped downstream
- Medical code regex extraction (2,545 codes) is not validated against reference
- 36 unverified dates flagged as possible hallucinations — never resolved
- max_tokens raised from 32,768 to 65,536 but no validation that outputs actually improved

**Scalability Concerns**:
- 3 concurrent workers is conservative — could safely run 8-10 with rate limiting
- Sequential file processing within each worker (no within-file parallelism)
- 93 minutes for 133 files → ~12 hours for full 10,372 corpus (acceptable)

**Accuracy Concerns**:
- rate_numeric populated only 63% — substantial missing data for financial analysis
- full_clause_text at 37% means most clauses lack verbatim source text
- No cross-validation between pypdf text and ai_parse_document text

**Demo Concerns**: None — extraction is offline. But sample coverage (199/10,372 = 1.9%) means demo queries may miss providers.

**Production Concerns**:
- No dead letter queue for failed extractions
- No extraction freshness monitoring (SLA for new PDFs)
- Model deprecation would break pipeline silently

---

### LAYER 3: STATE ENGINE LAYER

**Purpose**: Model contracts and amendments as first-class entities with lifecycle state and scope classification.

**Strengths**:
- Deterministic scope classification (no LLM dependency for state computation)
- Six scope types cover the amendment taxonomy well (FULL_REPLACEMENT through ADDENDUM)
- SHA-256 deterministic IDs enable idempotent re-runs (TRUNCATE + INSERT)
- Structural signals (exhibits_replaced_count length, prior_rates_superseded flag) are clever proxy measures
- Clean FK relationship: amendment → contract via contract_id
- Computation log table (tbl_v2_state_computation_log) enables audit trail

**Weaknesses**:
- Scope classification uses STRING LENGTH as proxy for array cardinality (LENGTH(exhibits_replaced_count) > 30)
- This is a heuristic — JSON arrays of length 30+ chars could be "["A"]" (one element) or "["A","B",...,"Z"]" (26 elements)
- prior_rates_superseded is STRING 'True'/'False' — comparison via string equality, not boolean logic
- Confidence scores are hardcoded (0.60-0.90), not learned or calibrated
- No temporal ordering validation — amendments assumed chronologically ordered by amendment_order
- Contract status is binary (ACTIVE/EXPIRED) based solely on expiration_date < current_date()
- No TERMINATED, SUPERSEDED, or PENDING states computed

**Architectural Risks**:
- Correlated subqueries (SELECT ... FROM x WHERE x.provider_id = a.provider_id) may fail on some runtimes
- TRUNCATE + INSERT is atomic per table but not across tables — inconsistent state if interrupted between contract and amendment population
- No referential integrity enforcement (amendment's contract_id may point to nonexistent contract if ordering is wrong)

**Technical Debt**:
- 4 DDL tables created but never populated: rate_facts_bitemporal, clause_facts_bitemporal, supersession_decisions, document_lineage
- The bitemporal model (valid_from/valid_to + tx_from/tx_to) is designed but has zero implementation
- Supersession decision audit trail exists in schema only
- Row counts vary between runs (685 vs 1,948 contracts) indicating filter condition sensitivity

**Scalability Concerns**:
- TRUNCATE + INSERT is fine for current scale (2K contracts, 1.5K amendments)
- Would need MERGE for incremental processing at 50K+ contracts
- Correlated subqueries for total_amendments/latest_amendment_date will degrade at scale

**Retrieval Concerns**:
- State engine produces contract_id used as scope filter in retrieval
- If state engine hasn't run, retrieval has no contract-level filtering
- No state-aware retrieval integration yet (is_current flag set but not enforced in queries)

**Demo Concerns**: Low risk — demo reads from Genie tables, not directly from state engine tables.

**Production Concerns**:
- No incremental refresh (must re-process all contracts on each run)
- No change detection (new PDFs don't trigger state recomputation)
- No alerting on scope classification failures

---

### LAYER 4: REIMBURSEMENT LAYER

**Purpose**: Transform extracted rate data into computable formula_json expression trees with modifier linkage.

**Strengths**:
- Formula type taxonomy is comprehensive (11 types: FIXED through ESCALATED)
- formula_json provides machine-readable reimbursement logic (JSON expression trees)
- Modifier flag system (has_stop_loss, has_carve_outs, etc.) enables efficient filtering
- Service line taxonomy (50 entries) + pattern matching (45 rules) for normalization
- Multi-tier stop-loss modeling (PER_DIEM, CASE_RATE, AGGREGATE, CORRIDOR)
- Lesser-of comparator modeling (contracted_rate vs billed_charges vs medicare_rate)
- Post-migration MERGE updates modifier flags (links stop-loss → base rate rule)

**Weaknesses**:
- Carve-outs produce 0 rows — extraction filter is too restrictive or source data lacks expected patterns
- Lesser-of produces only 23 rows from 6,683 Genie rates — likely under-detecting
- Escalators table exists in DDL but is never populated (no source data mapped)
- confidence_score hardcoded to 0.7 (FFS) and 0.9 (capitation) — not actually computed
- formula_json for DRG_WEIGHTED uses "base_rate: 0" when rate_numeric is NULL — misleading
- UNLINKED sentinel value in rule_id means many stop-loss/lesser-of provisions aren't connected to their base rate

**Architectural Risks**:
- formula_json is STRING not validated against a schema — downstream consumers must parse and handle malformed JSON
- rate_domain classification uses ILIKE patterns that may misclassify ambiguous categories
- CAPITATION rates use age_gender_band as service_line — conflating demographics with service taxonomy
- No versioning of formula_json schema — if expression tree format changes, all consumers break

**Technical Debt**:
- No formula evaluation engine (formula_json is never actually computed against claims)
- Escalator detection completely missing (has_escalator flag always FALSE)
- No conditions table population (tbl_reimb_conditions exists empty)
- Source confidence from LLM extraction not propagated (overwritten with hardcoded values)

**Scalability Concerns**:
- 21K rules is manageable; formula_json evaluation at claims volume (millions) would require pre-compilation
- UUID() for rule_id means every re-run generates new IDs — breaks FK integrity with stop_loss/lesser_of

**Accuracy Concerns**:
- 37% of rates lack formula derivation (just FIXED with amount)
- DRG weight source is always "CMS_DRG_WEIGHTS" regardless of actual contract specification
- PERCENTAGE formula always references "BILLED_CHARGES" — may be % of Medicare, % of fee schedule, etc.

**Demo Concerns**: Medium — benchmark calculations use rate_numeric which is populated; formula_json inaccuracies don't surface in demo.

**Production Concerns**:
- Cannot actually reimburse a claim with this data (formula_json is informational, not executable)
- No validation against actual claims processing outcomes
- No reconciliation with existing reimbursement systems

---

### LAYER 5: LEGAL CHUNKING LAYER

**Purpose**: Bootstrap 83K semantic legal units from V1 structured data for Vector Search embedding.

**Strengths**:
- Unit type taxonomy is well-designed (CLAUSE, DEFINITION, RATE_TABLE, CONDITION, SECTION, PARTY, MEDICAL_CODE, AMENDMENT_DELTA)
- CDF-enabled table allows Vector Search delta sync (only new/changed rows re-embedded)
- Dual-source approach: terms_vs_ready (69K structured) + rate_rules (21K formula-enriched)
- Provider linkage enables scope-filtered retrieval
- is_current flag distinguishes superseded from active content
- Content length tracking enables quality filtering

**Weaknesses**:
- No actual chunking intelligence — raw source rows become units 1:1
- Clause text ranges from 50 chars to 10K+ chars with no normalization
- RATE_TABLE units have synthetic text ("Provider: X\nService: Y\n...") not natural language — embedding quality questionable
- No overlap between chunks (missing adjacent context)
- No semantic deduplication (similar clauses across amendments stored independently)
- page_start is always NULL (not populated from source)

**Architectural Risks**:
- 83K units at avg ~500 chars = ~40M chars ≈ 14M tokens for embedding — manageable but cost-relevant
- Synthetic rate text will dominate VS results for financial queries (21K units with "rate" in text)
- No re-chunking capability — if chunk size is wrong, must rebuild entire table
- is_current flag comes from V1 supersession logic (which is flawed, per state engine design doc)

**Technical Debt**:
- No chunk overlap strategy (context loss at boundaries)
- No metadata embedding (provider context not in embedding text)
- No chunk quality scoring (some units are just section headers)
- Pipeline version "v2_bootstrap_1.0" suggests this is intended as temporary

**Scalability Concerns**:
- 83K units is well within VS limits (supports millions)
- Full corpus would be ~400K units — still manageable
- Delta sync via CDF is architecturally correct for incremental updates

**Retrieval Concerns**:
- Heterogeneous unit sizes hurt retrieval (long clauses dominate embedding space)
- Synthetic rate text may cluster incorrectly in embedding space
- No unit quality filter before embedding (headers, boilerplate, noise)

**Demo Concerns**: Low — demo uses the separate fulltext index (1.36M chunks), not this layer.

**Production Concerns**:
- VS index registration is one-time — no monitoring of sync health
- No alerting on embedding failures or index staleness
- Rebuild requires full recomputation (no incremental re-chunking)

---

### LAYER 6: RETRIEVAL LAYER (HybridRetriever)

**Purpose**: Orchestrate 4-channel hybrid retrieval with intent-aware Reciprocal Rank Fusion.

**Strengths**:
- 4-channel architecture is state-of-the-art for legal retrieval (semantic + lexical + metadata + structural)
- Intent-classified query understanding (5 types: RATE_LOOKUP, CLAUSE_SEARCH, COMPARISON, TIMELINE, GENERAL)
- Channel weighting is intent-specific (RATE_LOOKUP → 60% metadata, CLAUSE_SEARCH → 50% semantic)
- RRF fusion is mathematically sound and well-understood
- Structural expansion (sibling chunks from same document) provides context
- Temporal scope filtering (CURRENT_ONLY vs HISTORICAL)

**Weaknesses**:
- Query understanding is rule-based keyword matching — no LLM classification
- Entity extraction is placeholder (provider_filter, service_filter always None in practice)
- Lexical channel uses ILIKE with f-string interpolation — SQL INJECTION VULNERABILITY
- Metadata channel only fires for RATE_LOOKUP intent — misses rate-related clauses
- Structural expansion is naive (any chunk from same file, regardless of relevance)
- No query expansion or synonym handling
- No negative filtering (exclude superseded content beyond is_current flag)

**Architectural Risks**:
- SQL injection: `f"unit_text ILIKE '%{kw}%'"` — user input goes directly into SQL
- VS client instantiated per-query (should be singleton or cached)
- No timeout on VS similarity_search call — can hang indefinitely
- No fallback if VS endpoint is down (would return only lexical results)
- Lexical scoring is position-based (0.8 - i*0.05) — not actual relevance

**Technical Debt**:
- No caching of repeated queries
- No query rewriting for common misspellings
- Error handling prints to stdout (not structured logging)
- No telemetry integration (retrieval quality not measured per-query)

**Scalability Concerns**:
- Four sequential channel executions — could be parallelized (2-3x speedup)
- ILIKE on 83K rows is fast; on 1.36M rows would be slow
- No connection pooling for VS client

**Retrieval Concerns**:
- Precision: Lexical channel returns first-N matches without true relevance scoring (BM25 absent)
- Recall: Metadata channel misses anything not classified as RATE_LOOKUP
- Ranking: Position-based scoring in lexical channel doesn't reflect actual match quality
- Diversity: No diversity constraint — top results may all be from same provider/document

**Demo Concerns**: Medium — the demo notebook does NOT use this HybridRetriever; it uses its own 7-step engine. But if platform retrieval is demonstrated separately, quality issues surface.

**Production Concerns**:
- SQL injection is a security vulnerability
- No rate limiting or circuit breaking
- No observability (latency, result counts, channel contributions not logged)

---

### LAYER 7: HYBRID SEARCH LAYER (Demo "Ask Anything")

**Purpose**: 7-step deep analysis engine for corpus-wide contract intelligence questions.

**Strengths**:
- Remarkably sophisticated: LLM intent → plan → taxonomy → retrieval → classify → rollup → report
- Parallel execution (Steps 1.5 + 2 concurrent; 14 classification workers)
- Precision keyword triage (core/extended/excluded) eliminates false positives
- Dynamic taxonomy generation avoids hardcoded categories
- Spark-side scoring + ROW_NUMBER dedup (avoids 30K row toPandas overhead)
- Dual-channel: VS semantic (100 results) + SQL keyword (full corpus scan)
- LLM classification with disambiguation rules
- Provider rollup with MIXED status detection (conflicting signals)
- Multi-section HTML report matches Excel analyst depth

**Weaknesses**:
- 2-4 minute runtime for a single question (not interactive)
- 14 concurrent LLM calls × 10 passages/batch × multiple batches = high token consumption per query
- No caching — repeated questions re-run entire pipeline
- Keyword SQL channel has no true relevance scoring (LIKE match + position score)
- LLM classification can fail (JSON parse errors) — fallback marks everything as first category
- Provider universe is 326 providers from fulltext table (not dim_provider_canonical 271) — inconsistency
- No streaming/progressive results (user waits for full pipeline completion)

**Architectural Risks**:
- Single-cell implementation (~800 lines) — unmaintainable at this size
- No modularity — can't reuse components independently
- Rate limited by LLM endpoint throughput (14 workers × classification batches)
- HTML report generation in Python string concatenation — XSS risk if provider names contain HTML
- Memory pressure: all candidates held in Python lists simultaneously

**Technical Debt**:
- Hardcoded table names in SQL (not parameterized via config)
- Error handling via try/except with pass (silent failures)
- _provider_universe_cache as global variable (module-level mutation)
- Two separate fallback paths for VS index (fulltext → legal_units)
- Three separate fallback paths for keyword search (fulltext_vs_ready → vw_genie_contract_terms)

**Scalability Concerns**:
- O(providers × passages) LLM classification — cost scales linearly with corpus
- Full-corpus SQL scan (1.36M rows) is expensive per query
- Cannot handle concurrent users (single notebook session)

**Retrieval Concerns**:
- Recall: Full-corpus scan is excellent for recall
- Precision: LLM classification compensates for retrieval noise (high precision for classified results)
- Trade-off: High recall + LLM filtering = high cost but high quality

**Demo Concerns**: HIGH — this IS the demo centerpiece. If LLM endpoint is slow/down, demo fails. If keyword search returns 0 results, report is empty.

**Production Concerns**:
- Not productionizable as notebook cell (needs extraction into service)
- No concurrent access
- Cost per query: ~$0.50-2.00 in LLM tokens (estimated 50K-200K tokens)
- No SLA or latency guarantee

---

### LAYER 8: RERANKING LAYER

**Purpose**: 3-stage legal signal reranking to improve precision of retrieval results.

**Strengths**:
- Design is excellent: cross-encoder → legal relevance signals → state-aware recency
- Six legal signals identified (provision_type_match, scope_alignment, temporal_relevance, jurisdiction_match, section_specificity, amendment_awareness)
- Separation of concerns: retrieval (recall-focused) → reranking (precision-focused)

**Weaknesses**:
- **MODULE DOES NOT EXIST IN PLATFORM FOLDER** — only in design docs
- RERANKER_DEPLOYED = False — cross-encoder never deployed
- Fallback is score-weighted combination (no actual reranking logic implemented)
- No integration point in the retrieval engine (HybridRetriever has no reranking step)
- Design assumes bge-reranker-v2-m3 on Model Serving — not provisioned

**Architectural Risks**:
- Without reranking, retrieval precision depends entirely on RRF fusion quality
- Legal relevance signals require structured metadata that doesn't exist on all chunks
- Cross-encoder latency (~100ms per document pair) × 30 candidates = 3s added latency

**Technical Debt**:
- Entire module unimplemented despite being documented as Step 6
- No degraded-mode fallback coded into retrieval pipeline
- Design docs reference model serving infrastructure that doesn't exist

**Demo Concerns**: Low — demo uses LLM classification instead of reranking (effectively a very expensive reranker).

**Production Concerns**:
- Legal domain requires high precision — running without reranking is a quality gap
- Model serving cost for cross-encoder inference not budgeted
- No A/B testing infrastructure to measure reranking improvement

---

### LAYER 9: INTELLIGENCE LAYER

**Purpose**: Compute negotiation intelligence (benchmarks, spend, savings, leverage, scenarios, renewals).

**Strengths**:
- Benchmarks use percentile_approx (Spark-native, numerically sound)
- Renewal priority scoring is multi-dimensional (urgency + impact + risk = 0-100)
- Recommended actions are programmatic (ALLOW_AUTO_RENEW, NEGOTIATE, ISSUE_NON_RENEWAL, ESCALATE)
- Feature flag clearly gates placeholder vs real data (CLAIMS_AVAILABLE)
- Clean separation: real data (benchmarks, renewals) vs placeholder (spend, savings, leverage, scenarios)

**Weaknesses**:
- Only 2 of 6 intelligence tables contain real data
- Spend/savings/leverage/scenarios removed from trimmed implementation (correct decision)
- Benchmark groups require ≥3 rates per group — excludes sparse service lines
- Renewal priority uses rate count as proxy for contract importance (not dollar volume)
- Impact_score formula (rate_count / 50 * 40) uses arbitrary scaling
- Risk_score formula ((pct_above_median - 50) / 50 * 20) can produce negative values
- No confidence interval on percentile calculations

**Architectural Risks**:
- Without claims feed, intelligence layer delivers ~30% of designed value
- Benchmark percentiles are computed across ALL providers regardless of market/geography
- A provider with 1 rate at the 90th percentile and 50 at the 10th shows 2% above median — misleading

**Technical Debt**:
- 4 modules unimplemented (09_scenario, 10_leverage, provider_spend, savings)
- Placeholder columns retained for "table compatibility" (estimated_spend, savings_opportunity always NULL)
- No refresh frequency — benchmarks computed once, never updated as rates change
- No market segmentation (all providers benchmarked against each other regardless of size/type)

**Scalability Concerns**:
- Current scale (728 benchmark groups, 493 renewals) is trivial
- With claims feed, spend calculations at 1M+ claims would need incremental aggregation

**Demo Concerns**: Medium — benchmarks and renewals work correctly. But "savings opportunity" showing as NULL in the dashboard could raise questions.

**Production Concerns**:
- Intelligence without claims is directional only — cannot support actual negotiation decisions
- No validation against historical negotiation outcomes
- Recommended actions have no escalation workflow or assignment system

---

### LAYER 10: EVALUATION LAYER

**Purpose**: Golden query set + monitoring view for continuous retrieval quality measurement.

**Strengths**:
- 20 golden queries across 6 categories (rate, clause, comparison, timeline, amendment, complex)
- Difficulty ratings (EASY/MEDIUM/HARD) enable progressive quality targets
- Monitoring view (v_retrieval_health_daily) aggregates telemetry for daily health checks
- Expected_type, expected_provider, expected_domain enable automated precision measurement

**Weaknesses**:
- Only 20 queries — insufficient for statistical significance
- No expected_answer or expected_unit_ids — can only measure retrieval, not end-to-end
- Golden queries reference specific providers (Providence, Kaiser, Sharp) that may not be in sample data
- No automated execution — queries must be manually tested
- Monitoring view depends on tbl_retrieval_telemetry which is only populated by citation_verification (unimplemented)
- No regression testing infrastructure (can't detect quality degradation automatically)

**Architectural Risks**:
- Evaluation depends on an unimplemented component (citation verification populates telemetry)
- No ground truth annotation process for expanding golden set
- v_retrieval_health_daily reads columns (checks_passed, checks_total, has_numerical_error) that may not exist yet

**Technical Debt**:
- No precision/recall measurement code (just table + view definitions)
- No batch evaluation runner
- No comparison across pipeline versions
- Difficulty ratings are subjective (no calibration)

**Demo Concerns**: Low — evaluation is backend; not shown in demo.

**Production Concerns**:
- Without automated evaluation, quality degradation is undetectable
- 20 queries cannot cover the diversity of 50+ service lines × 6 query types
- No human-in-the-loop annotation process for expanding coverage

---

### LAYER 11: DEMO NOTEBOOK LAYER

**Purpose**: Leadership demonstration of platform capabilities via interactive notebook.

**Strengths**:
- Self-contained (single notebook, install → setup → KPIs → charts → Q&A)
- Progressive disclosure (overview → detail → interactive)
- Impressive statistics (271 providers, 83K passages, 6,683 rates)
- "Ask Anything" engine demonstrates genuine analytical depth
- Multi-section HTML reports rival analyst-produced workbooks
- Provider universe cache eliminates repeated DB queries

**Weaknesses**:
- utf-8 surrogate error in cells 4/5 (KPIs and charts don't render)
- ~800-line "Ask Anything" cell is a monolith — cannot debug or iterate components
- No error recovery in demo flow (if one cell fails, presenter must restart)
- Widget-based input requires cell re-run (not interactive)
- 2-4 minute wait for "Ask Anything" results — dead air in demo
- Inconsistent data between tbl_genie_provider_profile (271) and fulltext provider list (326)

**Architectural Risks**:
- Depends on 3 external services simultaneously (VS endpoint, LLM endpoint, Spark SQL)
- Any service degradation produces cryptic errors, not graceful degradation
- Cell state dependencies (cell 3 must run before cell 6) — no error message if skipped
- plotly rendering fails silently with surrogate character issues

**Technical Debt**:
- Surrogate character bug (likely from PDF OCR producing invalid unicode) unfixed
- HTML generation uses Python string concatenation (fragile, no templating)
- Global variable mutation (_provider_universe_cache) makes notebook non-reentrant
- LLM endpoint URL constructed from spark.conf — breaks outside Databricks runtime

**Demo Concerns**: HIGH PRIORITY
- Charts cells produce error output (visible to audience)
- Ask Anything takes 2-4 minutes (audience loses attention)
- If LLM endpoint is under load, classification may timeout
- No pre-computed fallback results for demo reliability

**Production Concerns**: N/A — this is a demo artifact, not a production service.

---

### LAYER 12: USER INTERACTION LAYER (Genie Space + Dashboard)

**Purpose**: Natural language Q&A (Genie) + visual analytics (Dashboard) for end users.

**Strengths**:
- Genie Space backed by 4 purpose-built tables with 67 column comments (100% coverage)
- Dashboard provides portfolio-level metrics without technical knowledge
- Tables designed for Genie: pre-joined, deduplicated, sentinel-safe (no NULLs in key fields)
- program_normalized enables clean Program dimension analysis
- is_from_latest_doc flag enables current-state queries

**Weaknesses**:
- Genie Space limited to structured queries (cannot do free-text clause search)
- Dashboard had stale dataset reference (fixed to vw_genie_contract_terms)
- No user feedback loop (can't learn from Genie query patterns)
- No access control differentiation (all users see all providers)
- Limited to 271 facilities — full corpus would be 327+ unique providers

**Architectural Risks**:
- Genie AI may generate incorrect SQL (no verification layer)
- Dashboard refresh depends on extraction pipeline completion
- No cache invalidation strategy (stale data after pipeline re-run)

**Demo Concerns**: Low — Genie and Dashboard are stable, well-tested assets.

**Production Concerns**:
- No row-level security (all providers visible to all users)
- No audit trail for Genie queries
- No SLA for query response time
- Genie table comments must be maintained manually as schema evolves

---

## TOP 20 ARCHITECTURAL RISKS

| # | Risk | Severity | Likelihood | Impact |
|---|------|----------|-----------|--------|
| 1 | SQL injection in retrieval engine (f-string user input into SQL) | CRITICAL | HIGH | Data exfiltration, injection attacks |
| 2 | Unstable fulltext VS index (1.36M chunks, historically ~10% synced) | HIGH | HIGH | Demo "Ask Anything" degrades to SQL-only |
| 3 | No claims feed means intelligence is 30% functional | HIGH | CERTAIN | Cannot support negotiation decisions |
| 4 | Reranking module unimplemented (RERANKER_DEPLOYED=False) | HIGH | CERTAIN | Retrieval precision ~20% below design target |
| 5 | Document-level supersession marks valid rates as expired | HIGH | HIGH | 45 rates/provider incorrectly superseded |
| 6 | Demo notebook has utf-8 surrogate errors in chart cells | MEDIUM | CERTAIN | Visible errors during leadership demo |
| 7 | Citation verification unimplemented → no faithfulness checking | HIGH | CERTAIN | LLM can hallucinate contract terms |
| 8 | LLM model version change could silently degrade extraction quality | HIGH | MEDIUM | All downstream tables affected |
| 9 | No orchestration job DAG — manual cell execution | MEDIUM | HIGH | Partial state, missed steps, no monitoring |
| 10 | UUID() for rule_id means re-runs break FK integrity | HIGH | HIGH | stop_loss/lesser_of orphaned from base rules |
| 11 | formula_json not schema-validated — consumers may receive malformed JSON | MEDIUM | MEDIUM | Downstream parsing failures |
| 12 | Single notebook session for "Ask Anything" — no concurrent access | MEDIUM | HIGH | Cannot serve multiple users |
| 13 | No dead letter queue for failed extractions | MEDIUM | MEDIUM | Silent data loss for problematic PDFs |
| 14 | Scope classification uses STRING length heuristics | MEDIUM | HIGH | Amendment scope misclassification |
| 15 | VS endpoint single point of failure (no HA) | HIGH | LOW | Complete retrieval degradation |
| 16 | Provider universe inconsistency (271 vs 326 vs 327) across components | MEDIUM | CERTAIN | Confusing analytics, missing providers |
| 17 | No incremental refresh — full recomputation on each run | MEDIUM | MEDIUM | Growing runtime as corpus expands |
| 18 | Evaluation set (20 queries) insufficient for statistical significance | MEDIUM | CERTAIN | Cannot reliably measure quality |
| 19 | Two separate retrieval systems (platform vs demo) may diverge in quality | MEDIUM | HIGH | Inconsistent answers between interfaces |
| 20 | No telemetry in production retrieval path (only citation verification populates it, and that's unimplemented) | MEDIUM | CERTAIN | Blind to quality degradation |

---

## TOP 20 IMPROVEMENT OPPORTUNITIES

| # | Improvement | Effort | Impact | Priority |
|---|-------------|--------|--------|----------|
| 1 | Fix SQL injection: parameterize all user input in retrieval SQL | 2 hours | CRITICAL security fix | P0 |
| 2 | Fix demo surrogate error (sanitize unicode in provider names) | 1 hour | Visible demo improvement | P0 |
| 3 | Implement reranking with Databricks Foundation Model API (fallback) | 4 hours | 15-25% precision improvement | P1 |
| 4 | Deploy cross-encoder (bge-reranker-v2-m3) on Model Serving | 2 hours setup | Best-in-class legal reranking | P1 |
| 5 | Create Lakeflow Job DAG for full pipeline orchestration | 4 hours | Automated, monitored execution | P1 |
| 6 | Implement citation verification (6-check engine from design doc) | 8 hours | Eliminates hallucination pathway | P1 |
| 7 | Add chunk overlap strategy in legal chunking (128 token overlap) | 2 hours | Context preservation at boundaries | P2 |
| 8 | Replace document-level supersession with scope-aware logic | 4 hours | Recovers ~45 rates/provider | P2 |
| 9 | Add pre-computed demo results as fallback (cached answers) | 2 hours | Demo reliability guarantee | P2 |
| 10 | Unify retrieval: make demo use platform HybridRetriever | 8 hours | Consistent quality, single codebase | P2 |
| 11 | Add deterministic rule_id (SHA-based) instead of UUID | 2 hours | FK integrity across re-runs | P2 |
| 12 | Expand golden query set to 100+ with annotated ground truth | 8 hours | Statistically valid evaluation | P2 |
| 13 | Connect claims feed (even synthetic/sampled) | 16 hours | Unlocks full intelligence layer | P3 |
| 14 | Implement scenario engine for what-if analysis | 8 hours | High-value negotiation tool | P3 |
| 15 | Add row-level security for multi-tenant access | 4 hours | Enterprise access control | P3 |
| 16 | Refactor "Ask Anything" into modular service functions | 8 hours | Maintainability, testability | P3 |
| 17 | Add telemetry to all retrieval paths (latency, precision, channel contribution) | 4 hours | Operational visibility | P2 |
| 18 | Implement progressive/streaming results in demo | 4 hours | Eliminates 2-4 minute dead air | P2 |
| 19 | Add LLM extraction confidence scoring (not hardcoded 0.7) | 4 hours | Data quality awareness | P3 |
| 20 | Build automated evaluation runner (nightly golden query execution) | 4 hours | Continuous quality monitoring | P3 |

---

## COMPONENT CLASSIFICATION

### Enterprise-Grade Components
- 2-tier OCR extraction (pypdf multiprocess + ai_parse_document fallback)
- Direct REST API to Claude with per-file timeouts (hard-learned production pattern)
- Checkpoint-resumable extraction (parquet state persistence)
- Delta table architecture with CDF for VS sync
- Genie Space with 67 column comments (AI-optimized serving layer)
- Feature flag system (clean separation of real vs placeholder data)
- RRF fusion algorithm implementation (mathematically correct)
- Service line taxonomy with regex pattern matching

### Prototype-Grade Components
- Query understanding (keyword matching, no NLU)
- Lexical retrieval (ILIKE with position-based scoring, not BM25)
- Scope classification (string length heuristics)
- Intelligence layer (only benchmarks + renewals operational)
- Evaluation harness (20 queries, no automation)
- Structural expansion (naive "same file" retrieval)
- Formula JSON generation (template-based, not validated)

### Overengineered Components
- Bitemporal schema design (valid_from/to + tx_from/to) — no population logic exists
- 6-table supersession decision audit trail — never populated
- Scenario engine design (5-scenario what-if) — unnecessary without claims data
- 4-channel retrieval when 2 channels (semantic + metadata) provide 90% of value
- Leverage scoring framework (plan vs provider bilateral analysis) — no data to feed it

### Underengineered Components
- Demo error handling (try/except: pass everywhere)
- Telemetry (in-memory buffer, no guaranteed flush)
- Incremental processing (full TRUNCATE + INSERT, no MERGE)
- Rate supersession (document-level heuristic despite scope data being available)
- Carve-out detection (0 rows extracted — filter logic needs work)
- Chunk quality filtering (no removal of headers/boilerplate before embedding)

### Unnecessary Complexity
- Two separate retrieval pipelines (platform HybridRetriever vs demo 7-step engine)
- Three copies of log_step/dedup_extraction_versions across modules
- Maintaining 4 empty DDL tables that have no implementation timeline
- formula_json for simple FIXED rates (just the numeric value with JSON wrapper)
- 14 parallel LLM workers when 8 would be sufficient and more stable

### Missing Capabilities
- BM25 lexical retrieval (actual term frequency scoring)
- Automated pipeline orchestration (Lakeflow Job)
- Incremental table refresh (MERGE/upsert patterns)
- User access control and audit logging
- Cost tracking for LLM token consumption
- Dead letter queue for failed extractions
- A/B testing for retrieval quality experiments
- Cache layer for repeated queries
- Streaming/progressive results
- Ground truth annotation workflow
- Model version pinning and regression testing

---

## DEMO FAILURE RISKS

| Risk | Probability | Mitigation |
|------|-------------|-----------|
| utf-8 surrogate error in charts | 100% (currently broken) | Sanitize unicode in provider names |
| LLM endpoint throttled (14 concurrent calls) | 15% | Reduce to 8 workers, add backoff |
| VS endpoint unavailable | 5% | Cache recent results; fallback to SQL-only |
| "Ask Anything" returns 0 results | 10% | Pre-validate questions; cache known-good answers |
| 2-4 minute wait loses audience | 50% | Add progress indicators; show intermediate results |
| Query hits provider not in sample data | 30% | Limit suggested questions to known providers |
| Notebook session timeout | 5% | Keep-alive pattern; fresh cluster before demo |
| Plotly render failure | 20% | Fallback to displayHTML with simple HTML tables |

---

## RETRIEVAL PRECISION RISKS

| Issue | Estimated Precision Impact | Fix |
|-------|---------------------------|-----|
| No reranking → noise in top-5 | -20% precision@5 | Deploy cross-encoder |
| Synthetic RATE_TABLE text in embeddings | -10% for clause queries | Separate rate index from clause index |
| No BM25 (ILIKE position scoring instead) | -15% for exact-term queries | Implement BM25 scoring |
| Structural expansion adds irrelevant context | -5% | Filter by section_type similarity |
| No diversity constraint → same-provider clusters | -10% for comparison queries | Add MMR (Maximal Marginal Relevance) |

---

## RETRIEVAL RECALL RISKS

| Issue | Estimated Recall Impact | Fix |
|-------|------------------------|-----|
| Metadata channel only fires for RATE_LOOKUP | -25% recall for rate+clause hybrid queries | Expand metadata triggers |
| is_current filter excludes historical context | -15% for timeline queries | Make temporal filter configurable |
| Keyword queries limited to top-10 (lexical channel) | -10% | Increase lexical k or implement BM25 |
| No query expansion/synonyms | -15% for specialized terms | Add synonym dictionary |
| VS index only has 83K units (not full 1.36M corpus) | -40% vs fulltext search | Consider second VS index on fulltext |

---

## LATENCY BOTTLENECKS

| Component | Current Latency | Bottleneck | Optimization |
|-----------|----------------|-----------|--------------|
| Ask Anything (full pipeline) | 120-240 seconds | LLM classification (14 workers × N batches) | Reduce candidates with better retrieval |
| VS similarity_search | 200-500ms | Network round-trip to VS endpoint | Cache frequent queries |
| SQL keyword search (1.36M rows) | 3-8 seconds | Full table scan with LIKE | Add bloom filter or precomputed index |
| LLM intent classification | 1-2 seconds | REST API latency | Rule-based fast path (already exists) |
| Platform retrieval (4 channels) | 2-5 seconds | Sequential channel execution | Parallelize channels |
| Benchmarks computation | 5-10 seconds | GROUP BY + percentile_approx on 21K rows | Pre-materialize |
| State engine population | 10-20 seconds | Correlated subqueries | Rewrite as JOINs |

---

## HALLUCINATION PATHWAYS

| Pathway | Risk Level | Current Mitigation | Recommended Fix |
|---------|-----------|-------------------|-----------------|
| LLM generates contract terms not in source text | HIGH | None (citation verification unimplemented) | Implement faithfulness check |
| LLM classifies passage incorrectly → wrong provider status | MEDIUM | Disambiguation rules in prompt | Add confidence threshold; flag uncertain |
| Formula JSON assigns wrong formula_type | MEDIUM | Hardcoded confidence=0.7 | Validate against rate_text patterns |
| Benchmark percentiles presented as "your rate" | LOW | Source column = "estimated" | Add data lineage to UI |
| Renewal recommended_action based on arbitrary thresholds | MEDIUM | Priority_score computation is transparent | Validate against historical outcomes |
| Rate numeric extraction hallucination | MEDIUM | 63% populated rate_numeric | Cross-validate with rate_text patterns |

---

## TRUSTWORTHINESS CONCERNS

1. **No citation verification** — Platform answers are not verified against source text
2. **No confidence calibration** — Hardcoded confidence scores (0.6-0.9) are not validated against outcomes
3. **No provenance chain** — Cannot trace an answer back to specific PDF page
4. **Superseded content mixed with current** — is_current flag exists but V1 heuristic is known-flawed
5. **Benchmarks without market segmentation** — Comparing a rural clinic to a large health system
6. **Intelligence placeholders retained** — Empty columns suggest data exists when it doesn't
7. **No human-in-the-loop verification** for high-stakes outputs (negotiation recommendations)

---

## SCALABILITY BOTTLENECKS

| Bottleneck | Current Load | Breaking Point | Fix |
|-----------|-------------|---------------|-----|
| Single-node extraction | 199 PDFs | 10K+ (local disk limit) | Distributed extraction via Spark |
| In-memory JSON loading | 2,254 docs | 10K+ (driver OOM) | Stream from Delta table |
| TRUNCATE + INSERT (state engine) | 2K contracts | 50K+ (rebuild time) | MERGE for incremental |
| Sequential channel retrieval | 4 channels × 2-5s | Concurrent users | Async/parallel channels |
| LLM classification (demo) | 1 concurrent user | 5+ users | Queue or pre-compute |
| VS index size | 83K vectors | ~5M (VS endpoint limits) | Partition by provider |
| Demo notebook session | 1 user | Cannot scale | Extract to serving endpoint |

---

## IMMEDIATE FIXES (Do Now — 1-2 days)

1. **Fix SQL injection** in 05_retrieval_engine.py — parameterize user input
2. **Fix demo surrogate error** — add `.encode('utf-8', errors='replace').decode('utf-8')` to provider names
3. **Add pre-computed demo answers** — cache 5 known-good question results for fallback
4. **Fix UUID rule_id** — switch to SHA-256 deterministic IDs in reimbursement migration
5. **Add progress indicator** to "Ask Anything" (print step completion during wait)

## MEDIUM-TERM FIXES (1-4 weeks)

1. **Deploy cross-encoder reranker** — bge-reranker-v2-m3 on Model Serving
2. **Implement citation verification** — faithfulness check from design doc
3. **Create orchestration job** — Lakeflow Job DAG with dependencies
4. **Unify retrieval codebases** — make demo use platform modules (or vice versa)
5. **Implement scope-aware supersession** — integrate state engine into rate status
6. **Add chunk overlap** — 128-token overlap in legal chunking
7. **Expand golden queries** — 100+ with annotated expected results
8. **Add telemetry** — structured logging to Delta for all retrieval paths
9. **Fix carve-out extraction** — debug 0-row output from migration
10. **Refactor demo "Ask Anything"** — extract into importable module

## LONG-TERM PLATFORM EVOLUTION (1-6 months)

1. **Claims feed integration** — connect enterprise claims warehouse, unlock full intelligence layer
2. **Full corpus processing** — scale extraction to remaining 10K PDFs
3. **Distributed extraction** — Spark-based parallel PDF processing
4. **Real-time pipeline** — streaming ingestion as new contracts arrive
5. **Multi-tenant access control** — row-level security per user role
6. **Serving endpoint** — extract Q&A engine to REST API for concurrent access
7. **A/B testing framework** — measure retrieval/intelligence quality experiments
8. **Ground truth annotation** — human-labeled correct answers for retrieval evaluation
9. **Automated regression** — nightly golden query execution with alerting on degradation
10. **Model governance** — version pinning, quality gates, rollback procedures for LLM changes
