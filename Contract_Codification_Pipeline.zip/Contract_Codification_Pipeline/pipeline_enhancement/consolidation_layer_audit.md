# PROMPT 4 — Consolidation Layer Audit: `07_consolidation.py`
## Deep Architectural Review of the Most Critical Layer Decision

**Created**: May 2026  
**Source**: `extraction/07_consolidation` (notebook ID: 338955191380353)  
**Related**: `validation_layer_audit.md`, `CONTEXT_FOR_CONTINUATION.md`

---

# EXECUTIVE SUMMARY

**Verdict: This is (B) — an intermediate merge layer producing denormalized artifacts. It is NOT a canonical contract-state construction layer.**

It produces `json_consolidated/<provider_id>.json` files that are:
- Consumed by exactly ONE downstream step (`08_build_rates`) for supersession status
- Redundant with `08_build_rates` 11a-fix which recomputes supersession independently
- Redundant with `platform/02_state_engine` which reconstructs the same logic from V1 tables
- Creating technical debt by being the THIRD supersession implementation

**The layer should be ABSORBED into the state engine or eliminated entirely.**

---

# PART 1: WHAT CONSOLIDATION IS ACTUALLY DOING

## The Code (single cell, ~500 lines, 5 phases)

### Phase 1: Load all file extractions
```
json_extract/*.json → all_docs[] (in-memory)
```
Pure file I/O. Loads all 3,519 individual JSON extractions.

### Phase 2: Version de-duplication
```
Group by (provider_id, contract_id, document_type, effective_date)
Keep highest version number per group
```
Removes re-extraction duplicates (e.g., v1 vs v2 of same file). Legitimate but trivial operation.

### Phase 3: Provider grouping + amendment chain construction
```
Group by provider_id
Assign amendment_order via ordinal word parsing ("First" → 1, "Second" → 2)
Classify doc_role (base_agreement, amendment, cover_memo, settlement)
```
Filename-based document ordering. This is the same logic as `03_metadata_parsing` already computes.

### Phase 4: Rate supersession computation
```
For each provider, iterate documents in amendment_order
For each rate, key = (rate_type, service_category, program, network)
If key already seen → mark previous as 'superseded', mark new as 'current'
```
**This is the core operation.** It determines which rates are active.

### Phase 5: Write consolidated JSON
```
json_consolidated/<provider_id>.json with:
  - consolidation_metadata
  - contract_status
  - document_timeline
  - rate_timeline (all rates with status)
  - current_rates (filtered view)
  - superseded_rates (filtered view)
```

---

# PART 2: WHAT SEMANTICS ARE MERGED

| Semantic | How Merged | Quality |
| --- | --- | --- |
| Version dedup | Highest version string per key | Correct but trivial |
| Amendment ordering | Ordinal word parsing from doc_type | Brittle (works for ordinals 1-20 only) |
| Doc role classification | Pattern matching on doc_type string | Same logic exists in 06_validation's `classify_bucket()` |
| Rate supersession | Sequential key-match override | Naive — no temporal awareness |
| Contract active/inactive | Latest expiration_date vs today | Correct but simplistic |
| Provider identity | Raw provider_id from filename | No canonicalization |

---

# PART 3: IS CANONICAL STATE FORMED HERE?

**NO.** This layer produces a per-provider JSON file, not a canonical state representation. Here's why:

### What canonical state requires:
1. **Single source of truth** — one authoritative store for "what is the current contract state?"
2. **Point-in-time queryability** — "what was the state on 2023-06-15?"
3. **Provenance** — every state transition traceable to a source document
4. **Atomic transitions** — state changes are transactions, not overwrites
5. **Schema stability** — state representation doesn't change with extraction version

### What consolidation produces:
1. **Per-run artifact** — regenerated from scratch every pipeline run
2. **Flat file** — no query capability, must load entire provider JSON
3. **No provenance model** — `superseded_by` is a filename, not a state transition
4. **Non-atomic** — entire file rewritten; no append/delta model
5. **Schema coupled to extraction** — rate fields mirror extraction schema exactly

**This is a MATERIALIZED INTERMEDIATE, not a state engine.**

---

# PART 4: DOES AMENDMENT LOGIC BELONG HERE?

**NO.** Amendment logic is a GRAPH problem, not a MERGE problem.

### What consolidation does:
```python
# Linear ordering: Base → Amend1 → Amend2 → ... → Current
doc_entries.sort(key=lambda d: (role_priority, amendment_order, effective_date))
```

### What reality looks like:
```
Base Agreement (2018)
  ├── 1st Amendment (2019) — rate exhibit replacement
  ├── 2nd Amendment (2020) — term extension only
  ├── LOA (2020) — ACO carve-out (parallel, not sequential)
  ├── 3rd Amendment (2021) — full rate replacement
  └── Settlement (2022) — resolves dispute (doesn't supersede rates)
```

The consolidation treats this as a LINEAR CHAIN. In reality:
- LOAs may be PARALLEL to the amendment chain
- Settlements don't supersede rates — they resolve disputes
- A "term extension" amendment doesn't supersede ANY rates
- Exhibit-specific amendments only supersede rates in THAT exhibit

**The state engine (`platform/02`) already handles this with `scope_type` classification:**
- `FULL_REPLACEMENT` — supersedes all rates
- `EXHIBIT_SPECIFIC` — supersedes specific exhibits
- `RATE_SPECIFIC` — supersedes specific rates
- `TERM_EXTENSION` — supersedes nothing
- `SECTION_SPECIFIC` — supersedes specific clauses

Consolidation's naive "last-writer-wins" approach is INCORRECT for scope-limited amendments.

---

# PART 5: IS SUPERSESSION LOGIC DUPLICATED?

**YES — THREE TIMES.** This is the platform's worst architectural defect.

| Implementation | Location | Mechanism | Output |
| --- | --- | --- | --- |
| **Implementation 1** | `07_consolidation` | Python key-match override in amendment_order | `json_consolidated/rate_timeline[].status` |
| **Implementation 2** | `08_build_rates` 11a-fix | Spark SQL: `MAX(amendment_order) OVER(PARTITION BY provider_id)` | `tbl_contract_rates_all.status` |
| **Implementation 3** | `platform/02_state_engine` | SQL scope classification from `tbl_genie_amendment_timeline` | `tbl_v2_amendment_registry.scope_type` |

### They produce DIFFERENT results:

| Scenario | Consolidation (07) | Build Rates (08) | State Engine (02) |
| --- | --- | --- | --- |
| Term extension amendment | Supersedes all prior rates ❌ | Marks prior as superseded ❌ | Correctly classifies as TERM_EXTENSION ✅ |
| Exhibit-specific amendment | Supersedes all matching keys ❌ | Supersedes everything from prior docs ❌ | Classifies as EXHIBIT_SPECIFIC ✅ |
| LOA (parallel agreement) | Supersedes matching rates ❌ | Treated as highest amendment_order ❌ | Would need parallel chain support ⚠️ |

**The state engine is the most correct implementation, but it reads from V1 TABLES (which were built using the WRONG supersession logic from Implementation 1 and 2).**

This is circular dependency at its worst.

---

# PART 6: DOES THE STATE ENGINE ALREADY SUPERSEDE THIS LAYER?

**YES — architecturally.** But NO — in practice, because:

1. The state engine (`platform/02`) reads from `tbl_genie_amendment_timeline` — which was built by `12_build_genie`, which reads from `tbl_contract_documents_master`, which was built by `10_build_documents`, which reads from... `json_consolidated/*.json`.

2. So the data flow is:
```
07_consolidation → json_consolidated
   → 08_build_rates → tbl_contract_rates_all
   → 10_build_documents → tbl_contract_documents_master
      → 12_build_genie → tbl_genie_amendment_timeline
         → platform/02_state_engine → tbl_v2_contract_registry
```

3. The state engine is downstream of consolidation outputs. It SHOULD be upstream (defining truth), but it can't be because it was built after the extraction pipeline.

**The dependency arrow is BACKWARDS.** The state engine should define contract state, and downstream layers should read from it.

---

# PART 7: IS TEMPORAL LOGIC MODELED TWICE?

**Not really — it's modeled ZERO times properly.**

### Consolidation's "temporal" logic:
```python
is_active = exp_date is None or exp_date > datetime.now()
```
This is a SNAPSHOT check, not temporal modeling. It answers "is it active NOW?" but can't answer "was it active on 2023-03-15?" or "when did it become inactive?"

### State engine's temporal model:
```sql
CASE WHEN expiration_date_parsed < current_date() THEN 'EXPIRED' ELSE 'ACTIVE' END
```
Identical logic, same limitation.

### What's needed (bitemporal):
The empty `tbl_v2_rate_facts_bitemporal` table was designed for this but never populated. It has:
- `valid_from` / `valid_to` — business time (when the rate was contractually effective)
- `tx_from` / `tx_to` — system time (when we learned about it)

**Neither consolidation nor the state engine implements actual temporal logic.**

---

# PART 8: ARE BUSINESS RULES DUPLICATED?

| Business Rule | In Consolidation? | Elsewhere? |
| --- | --- | --- |
| Version de-duplication (keep highest) | ✅ Yes | ❌ No (only here) |
| Amendment ordering (ordinal parsing) | ✅ Yes | ✅ Also in `03_metadata_parsing` |
| Doc role classification | ✅ Yes | ✅ Also in `06_validation.classify_bucket()` |
| Rate supersession (key-match) | ✅ Yes | ✅ Also in `08_build_rates` 11a-fix |
| Contract active/inactive | ✅ Yes | ✅ Also in `platform/02_state_engine` |
| Provider grouping | ✅ Yes | ✅ Also in `10_build_documents` |

**4 of 6 business rules are duplicated elsewhere.** Only version de-duplication is unique to this layer.

---

# PART 9: DOES CONSOLIDATION CREATE TECHNICAL DEBT?

**YES — substantial.**

| Debt Item | Impact |
| --- | --- |
| Supersession computed incorrectly here, then corrected downstream | Confusion about source of truth |
| JSON files on disk as pipeline state | Not queryable, not observable, not auditable |
| In-memory processing (loads ALL files) | Will break at 10K files scale |
| No Delta table output | Invisible to Spark SQL, Unity Catalog, lineage |
| Provider_id as sole grouping key | Doesn't handle providers with multiple contracts |
| Rate key = (type, category, program, network) | Misses temporal dimension — same key, different years |
| `datetime.now()` for active/inactive | Non-deterministic — results change on re-run |
| `current_rates[]` is denormalized copy of rate_timeline filtered | Data redundancy in output JSON |

---

# PART 10: SEPARATION OF CONCERNS VIOLATION

**Consolidation violates SoC by combining 4 distinct responsibilities:**

1. **ETL mechanics** (version dedup, file grouping) — belongs in pipeline orchestration
2. **Domain logic** (amendment ordering, doc role) — belongs in metadata/state engine
3. **Business rules** (rate supersession) — belongs in state engine ONLY
4. **Materialization** (writing provider JSONs) — belongs in serving layer

A clean architecture would separate these:
```
[Pipeline Orchestration] → dedup, group, route
[State Engine] → amendment ordering, supersession, contract status
[Materialized Views] → provider-level aggregates for downstream consumers
```

---

# PART 11: DOWNSTREAM DEPENDENCY MAP

## Artifact: `json_consolidated/<provider_id>.json`

### Consumer 1: `08_build_rates` (Source 1)
```python
for p in providers_data:
    for rate in p.get('rate_timeline', []):
        # Uses: rate_type, service_category, rate, rate_numeric,
        #       program, network, status, superseded_by, source_document,
        #       amendment_order, effective_date
```
**What it takes:** `rate_timeline[]` with pre-computed `status` (current/superseded)

**What breaks if removed:** Status column would be NULL for all rates from this source. BUT — `08_build_rates` 11a-fix ALREADY recomputes status independently using `MAX(amendment_order)`. So the consolidated status is OVERWRITTEN.

**Verdict: DECORATIVE.** The consolidated status is consumed then immediately replaced.

### Consumer 2: `08_build_rates` (metadata)
```python
# provider_name, provider_id from consolidated
```
**What breaks if removed:** These fields exist on every individual JSON too. No information is unique to the consolidated file.

**Verdict: REDUNDANT.** Same data available from `json_extract/*.json` directly.

### Consumer 3: `10_build_documents`
```python
# Reads json_consolidated for document_timeline, amendment_order
```
**What breaks if removed:** Would need to compute amendment ordering from individual files. This is a 20-line function (`get_amendment_order()`).

**Verdict: CONVENIENCE, not foundational.** The ordering logic is trivial to inline.

### Consumer 4: `12_build_genie` (indirectly)
```python
# tbl_genie_amendment_timeline reads from tbl_contract_documents_master
# which reads from json_consolidated
```
**What breaks if removed:** `tbl_genie_amendment_timeline` loses `amendment_order`. But this is the same ordinal parsing that could run directly on document_type strings.

**Verdict: CONVENIENCE.**

### Consumer 5: `platform/02_state_engine` (very indirectly)
```python
# Reads tbl_genie_amendment_timeline (built from consolidated)
# to populate tbl_v2_contract_registry and tbl_v2_amendment_registry
```
**What breaks if removed:** State engine loses its data source. BUT — the state engine SHOULD read directly from `json_extract/*.json` (or from a clean Delta table built from them).

**Verdict: ACCIDENTAL DEPENDENCY.** Architecture should be inverted.

---

## Dependency Summary

| Consumer | Dependency Type | Foundational? | Redundant? |
| --- | --- | --- | --- |
| 08_build_rates (rate_timeline) | Direct | NO — status overwritten downstream | YES |
| 08_build_rates (metadata) | Direct | NO — same data in json_extract | YES |
| 10_build_documents | Direct | NO — 20-line inline alternative | Mostly |
| 12_build_genie | Indirect (via 10) | NO — same reasoning | Mostly |
| platform/02_state_engine | Indirect (via 12) | NO — should read from source | YES (architectural inversion) |

**NOTHING in the downstream pipeline REQUIRES the consolidated JSON that couldn't be trivially computed inline or read directly from the individual JSON files.**

---

# PART 12: SHOULD CONSOLIDATION EXIST?

## Option A: Keep as-is
**NO.** It produces incorrect supersession, creates technical debt, and its outputs are overwritten downstream.

## Option B: Emit state deltas instead?
**BETTER, but wrong layer.** State deltas should be emitted by the state engine, not by a batch merge script.

## Option C: Emit graph relationships?
**BETTER.** If consolidation emitted:
```json
{"amendment_id": "X", "parent_contract": "Y", "scope": "EXHIBIT_SPECIFIC", "supersedes_exhibits": ["A", "B"]}
```
...this would be genuinely useful as input to the state engine. But this is what the state engine already does.

## Option D: Fold into the state engine?
**YES — this is correct.** The state engine should:
1. Read from `json_extract/*.json` directly
2. Perform version dedup (the one unique operation here)
3. Compute amendment ordering
4. Apply scope-aware supersession (not naive key-match)
5. Write to `tbl_v2_contract_registry` and `tbl_v2_amendment_registry`
6. Downstream tables read from state engine tables, never from JSON

## Option E: Only create retrieval artifacts?
**PARTIAL.** The `document_timeline` in consolidated JSON is useful for retrieval (understanding doc relationships). But this should be a VIEW on the state engine, not a separate materialization.

## Option F: Disappear entirely?
**ALMOST.** Keep version de-duplication (move to `06_validation` or a new `06b_dedup` step). Everything else moves to the state engine.

---

# PART 13: WHAT A TRUE ENTERPRISE ARCHITECTURE LOOKS LIKE

## Current (wrong):
```
json_extract → [07_consolidation] → json_consolidated → [08-12 build tables] → V1 tables → [state_engine] → V2 tables
```

## Correct:
```
json_extract → [dedup] → [STATE ENGINE] → canonical state tables → [materialization] → serving tables
```

## Ideal Enterprise Contract State Architecture:

```
┌─────────────────────────────────────────────────────────────────────────┐
│  EXTRACTION LAYER (steps 01-06)                                        │
│  Output: json_extract/*.json (immutable, append-only)                  │
└───────────────────────────────────┬─────────────────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────────┐
│  CANONICAL STATE ENGINE (replaces 07 + platform/02)                    │
│                                                                         │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐                  │
│  │ Document     │  │ Contract     │  │ Rate Fact    │                  │
│  │ Registry     │  │ Graph        │  │ Store        │                  │
│  │              │  │              │  │ (bitemporal) │                  │
│  │ • dedup      │  │ • parent/    │  │ • valid_from │                  │
│  │ • version    │  │   child      │  │ • valid_to   │                  │
│  │ • hash       │  │ • scope      │  │ • tx_from    │                  │
│  │ • lineage    │  │ • supersedes │  │ • tx_to      │                  │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘                  │
│         │                  │                  │                          │
│         └──────────────────┼──────────────────┘                          │
│                            │                                             │
│         ┌──────────────────┴──────────────────┐                          │
│         │ Point-in-Time Query API              │                          │
│         │ "What was Provider X's per diem      │                          │
│         │  rate on 2023-06-15?"                │                          │
│         └──────────────────┬──────────────────┘                          │
└────────────────────────────┼────────────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────────────┐
│  MATERIALIZATION LAYER (replaces 08-12)                                 │
│                                                                         │
│  Reads FROM state engine tables, never from JSON.                       │
│  Each output table is a MATERIALIZED VIEW on canonical state.           │
│                                                                         │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐      │
│  │ rates_all   │ │ clauses     │ │ documents   │ │ genie       │      │
│  │ (current +  │ │ (current    │ │ (timeline)  │ │ (serving)   │      │
│  │  history)   │ │  versions)  │ │             │ │             │      │
│  └─────────────┘ └─────────────┘ └─────────────┘ └─────────────┘      │
└─────────────────────────────────────────────────────────────────────────┘
```

### Key Differences from Current:

| Aspect | Current | Ideal |
| --- | --- | --- |
| Source of truth for supersession | 3 competing implementations | ONE state engine |
| Rate status computation | Key-match override (wrong) | Scope-aware with temporal bounds |
| Point-in-time queries | Impossible | Built-in via bitemporal store |
| Amendment graph | Linear chain assumption | DAG with parallel branches |
| Provenance | filename strings | document_id + SHA256 + offset |
| Queryability | JSON files on disk | Delta tables with SQL access |
| Scalability | In-memory (all files) | Spark-distributed |
| Observability | stdout prints | Delta table lineage + metrics |

---

# PART 14: MIGRATION PATH (Pragmatic)

Given that 08_build_rates ALREADY reads from both `json_extract` and `json_consolidated`, and that the 11a-fix ALREADY recomputes supersession, the migration is:

### Phase 1: Inline version dedup (1 hour)
Move the version de-duplication logic (Phase 2 of consolidation, ~30 lines) into a utility function. Call it at the start of `08_build_rates` when loading individual JSONs.

### Phase 2: Remove consolidated dependency (2 hours)
Modify `08_build_rates` Source 1 to read `rate_timeline` from a computed structure (same logic as consolidation Phase 4) instead of reading from `json_consolidated/`. This eliminates the file dependency.

### Phase 3: Remove consolidation notebook (0 hours)
Once no downstream step reads from `json_consolidated/`, delete `07_consolidation` entirely.

### Phase 4: Unify supersession in state engine (8 hours)
Modify `platform/02_state_engine` to:
- Read from `json_extract/*.json` directly (not via V1 tables)
- Apply scope-aware supersession
- Write canonical rate status to `tbl_v2_rate_facts_bitemporal`
- Downstream tables read from this canonical store

### Phase 5: Migrate downstream to state engine (16 hours)
- `08_build_rates` reads status from state engine
- `12_build_genie` reads timeline from state engine
- V1 tables become materialized views on V2 canonical tables

---

# PART 15: THE HARD TRUTH

## What consolidation gives you today:
- **Version dedup** (valuable, 30 lines, should live elsewhere)
- **Amendment ordering** (duplicated from metadata parsing)
- **Naive supersession** (WRONG — overwritten downstream anyway)
- **Provider-level JSON** (consumed then discarded)

## What it costs you:
- A 500-line notebook that must run in sequence
- ~45 minutes of compute per pipeline run (loads all files into memory)
- The fiction of "canonical state" that isn't
- Confusion about where supersession logic lives
- A circular dependency between extraction and platform layers
- JSON files on local disk that aren't visible to Unity Catalog

## What you lose by removing it:
- **Nothing that isn't already available elsewhere or trivially inlinable.**

---

# FINAL VERDICT

| Question | Answer |
| --- | --- |
| Is this canonical state construction? | **NO** — it's intermediate materialization |
| Does amendment logic belong here? | **NO** — belongs in scope-aware state engine |
| Is supersession duplicated? | **YES** — 3 times, all producing different results |
| Does the state engine supersede this? | **YES** — architecturally (though dependency is inverted) |
| Is temporal logic modeled? | **NO** — neither here nor anywhere else properly |
| Are business rules duplicated? | **YES** — 4 of 6 rules exist elsewhere |
| Does it create technical debt? | **YES** — substantial (circular deps, wrong supersession, in-memory scale limits) |
| Does it violate separation of concerns? | **YES** — combines ETL, domain logic, business rules, materialization |

## Recommendation:

**ELIMINATE.** Inline the 30 lines of version de-duplication into `08_build_rates`. Unify all supersession logic in the state engine. Remove the `json_consolidated/` artifact entirely.

**Effort:** 3 hours to remove, 24 hours to do it properly (with state engine unification).

**Risk of removal:** ZERO. Every downstream consumer either:
1. Already recomputes what consolidation provides (08 11a-fix)
2. Could trivially inline the 20-line helper function
3. Should be reading from the state engine anyway

---

# SCORECARD

| Dimension | Score |
| --- | --- |
| Produces canonical state? | 0/100 |
| Correctly models amendments? | 20/100 (linear chain, not graph) |
| Supersession logic correct? | 30/100 (naive key-match, no scope awareness) |
| Architecturally necessary? | 10/100 (only version dedup is unique) |
| Correctly placed in pipeline? | 40/100 (post-validation is right; pre-state-engine is wrong) |
| Scales to 10K documents? | 20/100 (in-memory, loads all files) |
| Separation of concerns? | 15/100 (combines 4 responsibilities) |
| Observable/auditable? | 10/100 (JSON files, stdout, no Delta output) |
| Technical debt impact? | HIGH (circular deps, triple supersession, inverted arrows) |
| Enterprise audit survival? | **FAIL** — no auditor accepts 3 competing truth sources |
