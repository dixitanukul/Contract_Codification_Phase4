# PROVIDER CONTRACT INTELLIGENCE PLATFORM — COMPLETE SYSTEM UNDERSTANDING
## Pre-Enhancement Analysis Document
**Generated**: 2026-05-24  
**Author**: Pipeline Enhancement Review  
**Scope**: End-to-end architecture map, data lineage, risks, dependencies

---

## 1. END-TO-END ARCHITECTURE MAP

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│                        SOURCE DATA (27 GB, 10,372 PDFs)                               │
│  /Volumes/prod_adb/default/ext-data-volume-stmlz/.../Provider_Contracts               │
│  597 provider folders │ 3,260 Base Agreements │ 5,120 Amendments │ 1,468 Cover Memos  │
└───────────────────────────────────────┬─────────────────────────────────────────────────┘
                                        │
                                        ▼
┌─────────────────────────────────────────────────────────────────────────────────────┐
│ LAYER 1: EXTRACTION PIPELINE (extraction/ — 15 notebooks)                            │
│                                                                                       │
│  01_file_discovery ─→ 02_ocr_extraction ─→ 03_metadata_parsing                      │
│       │                      │                      │                                 │
│  Discovery of 10K PDFs  2-Tier OCR (pypdf      Filename parsing                      │
│  Prefetch to NVMe SSD    + ai_parse_document)   (provider, contract,                  │
│  Checkpoint recovery     14 processes parallel   doc_type, version)                   │
│                                                                                       │
│  04_llm_prompts ─→ 05_llm_extraction ─→ 06_validation                               │
│       │                    │                    │                                      │
│  4 doc-type prompts   REST API to Claude    JSON schema validation                    │
│  (Base/Amend/CM/       Sonnet 4.5           quarantine invalid                        │
│   Settlement)          3 concurrent workers  medical code extraction                  │
│                        Chunking >150K chars                                           │
│                        json_extract/ output                                           │
│                                                                                       │
│  08_build_rates ─→ 09_build_terms ─→ 10_build_documents                             │
│       │                  │                    │                                        │
│  3 rate tables       4 terms tables       Documents master                            │
│  (all, regional,     (clauses, codes,     (amendment_order,                           │
│   protections)        parties, services)   doc_role, lineage)                         │
│                                                                                       │
│  11_enrich_tables ─→ 12_build_genie ─→ 13_build_serving                             │
│       │                    │                    │                                      │
│  dim_provider_canonical  4 Genie tables      VS-ready tables                          │
│  rate supersession fix   67 col comments     (fulltext chunked)                       │
│  program normalization   Deduplication                                                │
│                                                                                       │
│  14_quality_audit ─→ 15_gap_filler                                                   │
│       │                    │                                                          │
│  DQ scoring            Fill missing rates/clauses                                     │
│  Telemetry flush       from LLM re-extraction                                        │
└───────────────────────────────────────┬─────────────────────────────────────────────────┘
                                        │
                    OUTPUT: V1 Tables (9 base + 4 Genie + 1 VS-ready)
                                        │
                                        ▼
┌─────────────────────────────────────────────────────────────────────────────────────┐
│ LAYER 2: FOUNDATION (platform/ 00-03)                                                │
│                                                                                       │
│  00_config.py ─→ 01_execute_ddl.py ─→ 02_state_engine.py ─→ 03_reimbursement.py    │
│       │               │                      │                       │                │
│  Constants,       Creates 18 empty      Populates registries    V1→V2 migration       │
│  table names,     tables + seeds        (685 contracts,         (13,263 rate rules,   │
│  feature flags,   taxonomy (50 svc      1,569 amendments)       529 stop-loss,        │
│  utilities        lines + 45 patterns)  Scope classification    23 lesser-of)         │
│                                         (deterministic)                                │
└───────────────────────────────────────┬─────────────────────────────────────────────────┘
                                        │
                    OUTPUT: V2 Tables (contract_registry, amendment_registry,
                            rate_rules, stop_loss, carve_outs, lesser_of, taxonomy)
                                        │
                                        ▼
┌─────────────────────────────────────────────────────────────────────────────────────┐
│ LAYER 3: RETRIEVAL (platform/ 04-07)                                                 │
│                                                                                       │
│  04_legal_chunking ─→ 05_retrieval_engine ─→ 06_reranking ─→ 07_citation_verify    │
│       │                      │                     │                │                 │
│  Bootstrap 83K legal    4-channel hybrid      3-stage rerank    6-check verify       │
│  units from V1 data     retrieval + RRF       (cross-encoder,   (faithfulness,       │
│  Register VS delta      (semantic/lexical/    legal relevance,  provenance,           │
│  sync index             metadata/structural)  recency, state)   numerical,           │
│  CDF-enabled table                                              state, scope)        │
│                                                                                       │
│  FEATURE FLAGS: VS_ENDPOINT active │ RERANKER_DEPLOYED=False │                       │
│  FALLBACK: score-weighted reranking when cross-encoder unavailable                   │
└───────────────────────────────────────┬─────────────────────────────────────────────────┘
                                        │
                    OUTPUT: tbl_retrieval_legal_units (83K), VS index,
                            tbl_retrieval_telemetry
                                        │
                                        ▼
┌─────────────────────────────────────────────────────────────────────────────────────┐
│ LAYER 4: INTELLIGENCE (platform/ 08-11)                                              │
│                                                                                       │
│  08_intelligence ─→ 09_scenario_engine ─→ 10_leverage_scoring ─→ 11_evaluation      │
│       │                   │                      │                     │              │
│  Benchmarks (728      What-if simulation    Bilateral leverage    20 golden queries   │
│  groups, percentiles) (rate/term/budget)    (plan vs provider)    Monitoring view     │
│  Renewal priority     5 sample scenarios    Strategy postures     Regression suite    │
│  (493 contracts)      CLAIMS_AVAILABLE=F    CLAIMS_AVAILABLE=F                       │
│                                                                                       │
│  STATUS: Benchmarks + Renewals = REAL DATA                                           │
│          Spend/Savings/Leverage/Scenarios = PLACEHOLDER (no claims feed)             │
└───────────────────────────────────────┬─────────────────────────────────────────────────┘
                                        │
                                        ▼
┌─────────────────────────────────────────────────────────────────────────────────────┐
│ LAYER 5: PRESENTATION (Demo + Genie + Dashboard)                                     │
│                                                                                       │
│  Contract_Intelligence_Demo (notebook)                                                │
│       │                                                                               │
│  Cell 3: Setup + helpers (VS client, LLM client, provider cache)                     │
│  Cell 4: Portfolio KPI dashboard (HTML cards)                                        │
│  Cell 5: Portfolio charts (Plotly agreement type + contract status)                   │
│  Cell 6: "Ask Anything" 7-step deep analysis engine                                  │
│       Steps: Understanding → Plan → Taxonomy → Retrieval → Dedup → Classify → Report│
│       Uses: tbl_contract_fulltext_vs_ready (1.36M chunks) OR vw_genie_contract_terms │
│       Output: Multi-section HTML with HAS/NO_MENTION/DENIED/MIXED rollup            │
│                                                                                       │
│  BSC Provider Contract Intelligence (Genie Space: 01f14d360bd51f8d801452065b2df600)  │
│       Tables: tbl_genie_rates_current, tbl_genie_provider_profile,                   │
│               vw_genie_contract_terms, tbl_genie_amendment_timeline                   │
│                                                                                       │
│  Dashboard (01f153b41dc51de8bb4e0a3cf16bb7e1)                                        │
│       Portfolio overview using Genie/V2 tables                                        │
└─────────────────────────────────────────────────────────────────────────────────────┘
```

---

## 2. PIPELINE FLOW DIAGRAM (Sequential Dependencies)

```
_config (shared widgets, paths, logging)
   │
   ├── 01_file_discovery
   │     └── 02_ocr_extraction (2-tier: pypdf 14 processes → ai_parse_document)
   │           └── 03_metadata_parsing (filename → provider_id, contract_id, doc_type)
   │                 └── 04_llm_prompts (4 document-type-specific prompt templates)
   │                       └── 05_llm_extraction (REST API → Claude Sonnet 4.5, 3 workers)
   │                             └── 06_validation (JSON schema, medical codes, quarantine)
   │                                   └── [08, 09, 10 can run in parallel]
   │                                         ├── 08_build_rates (rates_all, regional, protections)
   │                                         ├── 09_build_terms (clauses, codes, parties, services)
   │                                         └── 10_build_documents (documents_master, lineage)
   │                                               └── 11_enrich_tables (dim_provider, supersession)
   │                                                     └── 12_build_genie (4 Genie tables)
   │                                                           ├── 13_build_serving (VS-ready)
   │                                                           └── 14_quality_audit
   │                                                                 └── 15_gap_filler
   │
   └── [PLATFORM MODULES — run after extraction complete]
         ├── 00_config → 01_execute_ddl (18 tables + taxonomy seed)
         │     ├── 02_state_engine (contract_registry + amendment_registry)
         │     └── 03_reimbursement_migration (rate_rules + stop_loss + lesser_of)
         │           └── 04_legal_chunking (83K units + VS index registration)
         │                 └── 05_retrieval_engine (4-channel hybrid + RRF)
         │                       └── 06_reranking_service (3-stage legal reranking)
         │                             └── 07_citation_verification (6-check engine)
         │
         ├── 08_intelligence (benchmarks + renewal priority)
         ├── 09_scenario_engine (what-if simulation)
         ├── 10_leverage_scoring (bilateral leverage)
         └── 11_evaluation_harness (20 golden queries + monitoring view)
```

---

## 3. TABLE LINEAGE MAP

### V1 Tables (Built by extraction/ notebooks)

| Table | Built By | Rows | Source | Downstream Consumers |
|-------|----------|------|--------|---------------------|
| `tbl_contract_rates_all` | 08_build_rates | 39,549 | json_extract/ | 03_reimbursement, 12_build_genie, 04_legal_chunking |
| `tbl_contract_regional_factors` | 08_build_rates | 5,710 | json_extract/ | (analytics only) |
| `tbl_contract_financial_protections` | 08_build_rates | 2,077 | json_extract/ | 03_reimbursement, 12_build_genie |
| `tbl_contract_clauses_terms` | 09_build_terms | 31,056 | json_extract/ | 12_build_genie (→ vw_genie_contract_terms) |
| `tbl_contract_codes_events` | 09_build_terms | 7,473 | json_extract/ | 12_build_genie |
| `tbl_contract_parties` | 09_build_terms | 7,189 | json_extract/ | 12_build_genie |
| `tbl_contract_services_quality` | 09_build_terms | 13,103 | json_extract/ | 12_build_genie |
| `tbl_contract_documents_master` | 10_build_documents | ~2,254 | json_extract/ | 02_state_engine, 08_build_rates(fix), 12_build_genie |
| `dim_provider_canonical` | 11_enrich_tables | ~271 | documents_master | 12_build_genie (all tables) |
| `tbl_contract_terms_vs_ready` | 13_build_serving | ~69K | clauses+terms | 04_legal_chunking |
| `tbl_contract_fulltext_vs_ready` | 13_build_serving | ~1.36M | full OCR text | Demo notebook "Ask Anything" |

### V1 Genie Tables (Built by 12_build_genie)

| Table | Rows | Purpose | Consumers |
|-------|------|---------|-----------|
| `tbl_genie_provider_profile` | 271 | Facility-level summary | Genie Space, Dashboard, Demo |
| `tbl_genie_rates_current` | 6,683 | Deduplicated current rates | Genie Space, 03_reimbursement |
| `vw_genie_contract_terms` | 45,718 | Clauses+codes with latest flag | Genie Space, Dashboard |
| `tbl_genie_amendment_timeline` | 2,254 | Amendment chain | Genie Space |

### V2 Tables (Built by platform/ modules)

| Table | Built By | Rows | Source | Purpose |
|-------|----------|------|--------|---------|
| `tbl_v2_contract_registry` | 02_state_engine | 685-1,948 | documents_master | Contract entity registry |
| `tbl_v2_amendment_registry` | 02_state_engine | 1,569 | documents_master | Scope-classified amendments |
| `tbl_reimb_rate_rules` | 03_reimbursement | 13,263-21,074 | rates_all + capitation_card | Computable reimbursement |
| `tbl_reimb_stop_loss` | 03_reimbursement | 529-741 | financial_protections | Financial protections |
| `tbl_reimb_carve_outs` | 03_reimbursement | 0 | financial_protections | Carve-out provisions |
| `tbl_reimb_lesser_of` | 03_reimbursement | 23 | genie_rates_current | Lesser-of comparators |
| `dim_service_line_taxonomy` | 01_execute_ddl | 50 | taxonomy_seed.sql | Service line classification |
| `dim_service_line_patterns` | 01_execute_ddl | 45 | taxonomy_seed.sql | Pattern matching rules |
| `tbl_retrieval_legal_units` | 04_legal_chunking | 83,008 | terms_vs_ready + rate_rules | VS embedding source |
| `tbl_intel_benchmark_results` | 08_intelligence | 728-1,399 | rate_rules | Percentile benchmarks |
| `tbl_intel_renewal_priority` | 08_intelligence | 493-1,478 | contract_registry + rate_rules | Renewal scoring |
| `tbl_eval_golden_queries` | 11_evaluation | 20 | seeded | Retrieval evaluation |

---

## 4. RETRIEVAL FLOW MAP

```
User Query (natural language)
     │
     ▼
┌─────────────────────────────────────────────────────────┐
│ QUERY UNDERSTANDING (rule-based fast path)               │
│   Intent: RATE_LOOKUP│CLAUSE_SEARCH│COMPARISON│TIMELINE│GENERAL │
│   Temporal: CURRENT_ONLY│HISTORICAL│AS_OF_DATE           │
│   Keywords: stop-word filtered tokens                    │
│   Provider filter: extracted entity                      │
└─────────────────────────────────────────────────────────┘
     │
     ├──────────────────────┬──────────────────────┬──────────────────────┐
     ▼                      ▼                      ▼                      ▼
┌─────────────┐   ┌─────────────────┐   ┌────────────────┐   ┌──────────────────┐
│ CH1: SEMANTIC│   │ CH2: LEXICAL    │   │ CH3: METADATA  │   │ CH4: STRUCTURAL  │
│ VS ANN k=15 │   │ ILIKE on legal  │   │ Direct SQL on  │   │ Sibling expansion│
│ idx_legal_  │   │ units (keywords)│   │ rate_rules for │   │ from anchor docs │
│ units_v2    │   │ is_current filt │   │ RATE_LOOKUP    │   │ (same source_file│
│             │   │ top-k=10        │   │ intent only    │   │  different units)│
└──────┬──────┘   └────────┬────────┘   └───────┬────────┘   └────────┬─────────┘
       │                   │                     │                     │
       └─────────────────────────────────────────┘─────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────┐
│ RECIPROCAL RANK FUSION (RRF)                             │
│   Intent-weighted channel blending:                      │
│     RATE_LOOKUP:  semantic=0.2, lexical=0.1, meta=0.6   │
│     CLAUSE_SEARCH: semantic=0.5, lexical=0.25, meta=0.05│
│     COMPARISON:   semantic=0.3, lexical=0.2, meta=0.4   │
│   Score: weight * (1 / (k + rank))                      │
└─────────────────────────────────────────────────────────┘
     │
     ▼ (top-30 fused results)
┌─────────────────────────────────────────────────────────┐
│ RERANKING (3-stage, FALLBACK mode — no cross-encoder)    │
│   Stage 1: Cross-encoder scoring (DISABLED: bge-reranker│
│            not deployed on Model Serving)                │
│   Stage 2: Legal relevance signals (6 signals)          │
│   Stage 3: State-aware recency + scope boosting         │
│   CURRENT: Score-weighted fallback only                 │
└─────────────────────────────────────────────────────────┘
     │
     ▼
┌─────────────────────────────────────────────────────────┐
│ CITATION VERIFICATION (6-check engine)                   │
│   Check 1: Faithfulness (answer grounded in chunks?)    │
│   Check 2: Provenance (traceable to source PDF?)        │
│   Check 3: Numerical accuracy (rates match source?)     │
│   Check 4: State correctness (current vs superseded?)   │
│   Check 5: Scope purity (answer within query scope?)    │
│   Check 6: Completeness (all relevant info included?)   │
│   Output: confidence_score + needs_review flag          │
│   Telemetry → tbl_retrieval_telemetry                   │
└─────────────────────────────────────────────────────────┘
```

---

## 5. INTELLIGENCE FLOW MAP

```
V2 Rate Rules (13,263)    Contract Registry (685)    Taxonomy (50 svc lines)
        │                         │                         │
        ├─────────────────────────┼─────────────────────────┘
        │                         │
        ▼                         ▼
┌─────────────────┐      ┌─────────────────┐
│ BENCHMARKS      │      │ RENEWAL PRIORITY│
│ percentile_approx│     │ urgency (0-40)  │
│ per service_line │     │ + impact (0-40) │
│ per rate_domain  │     │ + risk (0-20)   │
│ per formula_type │     │ = priority_score│
│ 728 groups       │     │ 493 contracts   │
│ REAL DATA ✓      │     │ REAL DATA ✓     │
└────────┬────────┘      └────────┬────────┘
         │                        │
         │    ┌───────────────────┘
         │    │
         ▼    ▼
┌─────────────────────────────────────────┐
│ PLACEHOLDER (awaiting claims feed):      │
│   • Provider Spend Summary (hardcoded)  │
│   • Savings Opportunity (fabricated)    │
│   • Leverage Scores (hardcoded share)   │
│   • Scenario Results (hardcoded volume) │
│   FLAG: CLAIMS_AVAILABLE = False        │
└─────────────────────────────────────────┘
```

---

## 6. FRONTEND NOTEBOOK DEPENDENCY GRAPH

```
Contract_Intelligence_Demo
    │
    ├── Cell 2: %pip install databricks-vectorsearch
    │
    ├── Cell 3: SETUP
    │     ├── VectorSearchClient (VS_ENDPOINT + VS_INDEX)
    │     ├── LLM REST client (databricks-claude-sonnet-4-5)
    │     ├── Provider universe cache (271 names from tbl_genie_provider_profile)
    │     └── ask_llm() helper function
    │
    ├── Cell 4: KPI DASHBOARD
    │     ├── tbl_genie_provider_profile → total providers, avg per diem, amendments
    │     ├── tbl_intel_renewal_priority → expiring contracts (<90 days)
    │     └── tbl_genie_rates_current → total rate count
    │
    ├── Cell 5: CHARTS
    │     ├── tbl_genie_provider_profile → agreement_type distribution
    │     └── tbl_v2_contract_registry → contract status breakdown
    │
    └── Cell 6: "ASK ANYTHING" ENGINE (7-step pipeline)
          │
          ├── Step 1: Question Understanding (LLM → keywords, intent, is_negative)
          ├── Step 1.5: Execution Plan (LLM → core/extended/excluded keyword triage)
          ├── Step 2: Dynamic Taxonomy Generation (LLM → 5-7 sub-categories)
          │     [Steps 1.5 + 2 run in parallel]
          ├── Step 3: Hybrid Retrieval
          │     ├── Channel 1: VS semantic (tbl_contract_fulltext_vs_index, k=100)
          │     │     └── Fallback: idx_legal_units_v2 if fulltext unavailable
          │     └── Channel 2: SQL keyword (tbl_contract_fulltext_vs_ready)
          │           └── Spark-side scoring + ROW_NUMBER dedup
          │           └── Fallback: vw_genie_contract_terms
          ├── Step 4: Merge + Final Dedup (file-level, highest score wins)
          ├── Step 5: LLM Classification (all candidates, 10/batch, 14 workers)
          ├── Step 6: Provider Rollup (HAS/NO_MENTION/DENIED/MIXED)
          └── Step 7: HTML Report (multi-section, Excel-depth analytics)
```

---

## 7. CRITICAL-PATH COMPONENTS

These components are on the **critical path** — failure of any one breaks the platform:

| # | Component | Why Critical | Risk Level |
|---|-----------|-------------|------------|
| 1 | `json_extract/` (3,519 files) | ALL downstream tables built from these JSONs | HIGH — no redundancy |
| 2 | `tbl_contract_documents_master` | Amendment ordering, lineage, state engine input | HIGH — single point |
| 3 | `tbl_contract_rates_all` | Feeds both Genie rates AND V2 rate_rules | HIGH — dual consumer |
| 4 | `dim_provider_canonical` | Facility-level dedup join key for ALL Genie tables | HIGH — no fallback |
| 5 | `02_state_engine.py` | Produces contract_registry (FK for everything V2) | MEDIUM — idempotent |
| 6 | `VS endpoint` | Demo "Ask Anything" semantic channel requires it | HIGH — external dep |
| 7 | `Claude Sonnet 4.5` endpoint | LLM extraction + demo classification | HIGH — external dep |

---

## 8. HIGHEST-RISK COMPONENTS

| # | Component | Risk | Impact | Mitigation |
|---|-----------|------|--------|-----------|
| 1 | **Document-level supersession** (08_build_rates) | Marks ALL prior rates as superseded when amendment only touches one exhibit | 45 rates vanish per provider on average | V2 state engine provides scope_type but integration is partial |
| 2 | **VS index sync** (1.36M chunks) | fulltext VS index historically never reaches READY state | Demo "Ask Anything" degrades to SQL-only retrieval | Fallback to `idx_legal_units_v2` (83K, stable) |
| 3 | **No claims feed** (CLAIMS_AVAILABLE=False) | Spend, savings, leverage, scenarios are all placeholder/fabricated | Intelligence layer delivers only benchmarks + renewals | Feature flag blocks fabricated outputs |
| 4 | **Reranker not deployed** (RERANKER_DEPLOYED=False) | Retrieval uses score-weighted fallback instead of cross-encoder | Precision@5 likely 15-25% lower than designed | Design doc calls for bge-reranker-v2-m3 |
| 5 | **Single-notebook extraction** | No orchestration job DAG; manual cell execution | Re-run risk, partial state, no monitoring | Orchestrator notebook exists but only runs 3 modules |
| 6 | **Correlated subqueries in state_engine** | Uses subqueries that may fail on some runtimes | State engine may produce wrong counts | Documented workaround: rewrite as JOIN |
| 7 | **String-typed numeric columns** | exhibits_replaced_count, prior_rates_superseded are STRING | Comparison logic uses LENGTH() heuristic instead of COUNT | Documented in custom instructions |

---

## 9. DEMO-CRITICAL COMPONENTS

Components that MUST work for the leadership demo to succeed:

| Component | Required State | Current State | Gap |
|-----------|---------------|---------------|-----|
| `tbl_genie_provider_profile` | 271 rows, no NULLs in key fields | ✓ 271 rows | NONE |
| `tbl_genie_rates_current` | 6,683 deduplicated rates | ✓ Working | NONE |
| `vw_genie_contract_terms` | 45,718 rows with latest flag | ✓ Working | NONE |
| `tbl_v2_contract_registry` | Status counts for chart | ✓ Working | NONE |
| `tbl_intel_renewal_priority` | Expiring contract count | ✓ 493 rows | NONE |
| VS endpoint + fulltext index | Semantic retrieval for Ask Anything | PARTIAL — fulltext index unstable | Use idx_legal_units_v2 fallback |
| Claude Sonnet 4.5 endpoint | LLM classification (14 workers) | ✓ Working | NONE |
| `tbl_contract_fulltext_vs_ready` | SQL keyword retrieval | ✓ Working (1.36M rows) | NONE |
| Plotly rendering | HTML charts in notebook | ⚠ utf-8 surrogate error | Need fix |

---

## 10. RETRIEVAL-CRITICAL COMPONENTS

| Component | Role in Retrieval | Status | Notes |
|-----------|-------------------|--------|-------|
| `tbl_retrieval_legal_units` | 83K units for VS embedding | ✓ Populated | CDF-enabled for delta sync |
| `idx_legal_units_v2` | Vector Search delta sync index | ✓ Active | On `contract_intelligence_vs_endpoint` |
| `tbl_contract_fulltext_vs_ready` | 1.36M chunks for keyword search | ✓ Populated | Primary source for demo |
| `tbl_contract_fulltext_vs_index` | Fulltext VS index | ⚠ Unstable | ~10% synced historically |
| `tbl_reimb_rate_rules` | Metadata channel for RATE_LOOKUP | ✓ 13,263 rows | Structured SQL retrieval |
| `HybridRetriever` class | Orchestrates 4-channel retrieval | ✓ Implemented | In 05_retrieval_engine.py |
| RRF fusion weights | Intent-specific channel blending | ✓ Tuned | RATE_LOOKUP: meta=0.6, semantic=0.2 |
| `tbl_retrieval_telemetry` | Logs confidence + checks for monitoring | Created by 07_citation | Monitoring view depends on it |

---

## 11. COMPONENT-BY-COMPONENT ANALYSIS

### extraction/_config
- **Purpose**: Lightweight shared config (paths, widgets, logging) imported via `%run`
- **Inputs**: None (sets constants)
- **Outputs**: BASE_DIR, OUTPUT_DIR, DATA_DIR, CHECKPOINT_DIR, pipe_log, NEW_FILES_FOUND
- **Dependencies**: dbutils.widgets
- **Business value**: Enables checkpoint recovery and sample/full mode switching
- **Risk**: Widget defaults control full pipeline behavior; force_rebuild=true is default

### extraction/01_file_discovery
- **Purpose**: Scan source Volume, build file registry, prefetch to NVMe, select processing set
- **Inputs**: /Volumes/prod_adb/.../Provider_Contracts (10,372 PDFs, 27 GB)
- **Outputs**: file_registry dict, valid_files list, NEW_FILES_FOUND flag
- **Dependencies**: _config, local SSD availability
- **Business value**: Incremental processing — only new files get processed
- **Scalability**: 32-thread parallel copy, registry cache (parquet) for instant restart
- **Risk**: Local SSD space (~30 GB needed); registry cache can become stale

### extraction/08_build_rates
- **Purpose**: Build 3 rate tables directly from JSON files (zero table dependencies)
- **Inputs**: json_extract/*.json (2,254 docs after dedup)
- **Outputs**: tbl_contract_rates_all (39,549), regional_factors (5,710), financial_protections (2,077)
- **Dependencies**: json_extract files only
- **Business value**: Core reimbursement data — rates are the primary contract intelligence
- **Technical value**: V8 fix recovers +170 formula/cap rates from non-standard field naming
- **Risk**: Amendment supersession logic uses document-level heuristic (critical flaw documented in design docs)

### extraction/12_build_genie
- **Purpose**: Build 4 AI-optimized Genie tables with 67 column comments
- **Inputs**: 8 base tables + dim_provider_canonical
- **Outputs**: tbl_genie_provider_profile, tbl_genie_rates_current, vw_genie_contract_terms, tbl_genie_amendment_timeline
- **Dependencies**: All extraction steps 08-11
- **Business value**: Direct Genie Space consumption — enables natural language queries
- **Demo value**: CRITICAL — KPIs, charts, and Genie Space all read these tables
- **Risk**: V8 dedup fix reduced duplicates from 27.6% to 1.3% but residual remains

### platform/02_state_engine
- **Purpose**: Populate contract registry + amendment registry with scope classification
- **Inputs**: tbl_contract_documents_master
- **Outputs**: tbl_v2_contract_registry (685), tbl_v2_amendment_registry (1,569)
- **Dependencies**: 01_execute_ddl (creates empty tables)
- **Business value**: Amendment-aware state modeling — knows WHAT each amendment changed
- **Technical value**: Deterministic scope classification (FULL_REPLACEMENT, EXHIBIT_SPECIFIC, etc.)
- **Risk**: Scope confidence 0.60-0.90; classification uses STRING length heuristics on JSON arrays

### platform/03_reimbursement_migration
- **Purpose**: Migrate V1 rate data into V2 computable schema with formula_json
- **Inputs**: tbl_contract_rates_all, tbl_contract_financial_protections, tbl_serving_capitation_card, tbl_genie_rates_current
- **Outputs**: tbl_reimb_rate_rules (13,263), tbl_reimb_stop_loss (529), tbl_reimb_carve_outs (0), tbl_reimb_lesser_of (23)
- **Dependencies**: 01_execute_ddl + V1 tables from extraction
- **Business value**: Computable reimbursement logic — each rate has formula_json expression tree
- **Risk**: carve_outs=0 rows suggests extraction gap; confidence_score hardcoded to 0.7/0.9

### platform/04_legal_chunking
- **Purpose**: Bootstrap 83K legal units for Vector Search retrieval
- **Inputs**: tbl_contract_terms_vs_ready (69K rows) + tbl_reimb_rate_rules (V2)
- **Outputs**: tbl_retrieval_legal_units (83K), VS delta sync index registration
- **Dependencies**: 02_state_engine, 03_reimbursement, VS endpoint
- **Business value**: Enables semantic search over entire contract corpus
- **Retrieval value**: FOUNDATIONAL — this is what the VS index embeds
- **Risk**: CDF must be enabled (✓); VS endpoint must be active; rate units have synthetic text

### platform/05_retrieval_engine
- **Purpose**: 4-channel hybrid retrieval with Reciprocal Rank Fusion
- **Inputs**: User query, tbl_retrieval_legal_units, tbl_reimb_rate_rules, VS index
- **Outputs**: Ranked list of ScoredChunk objects
- **Dependencies**: 04_legal_chunking (VS index must be syncing), VS SDK
- **Business value**: Core search capability — how users find contract information
- **Retrieval value**: CORE — orchestrates all retrieval signals
- **Risk**: SQL injection via f-string interpolation of user keywords; no parameterized queries

### platform/08_intelligence (trimmed)
- **Purpose**: Compute real intelligence metrics (benchmarks + renewal priority)
- **Inputs**: tbl_reimb_rate_rules, tbl_v2_contract_registry, tbl_intel_benchmark_results
- **Outputs**: tbl_intel_benchmark_results (728), tbl_intel_renewal_priority (493)
- **Dependencies**: 03_reimbursement, 02_state_engine
- **Business value**: Rate positioning analysis + proactive renewal management
- **Quality**: Uses percentile_approx (Spark native) — numerically sound
- **Risk**: Impact_score uses total_rate_rules/50.0*40 — arbitrary scaling factor

### platform/11_evaluation_harness
- **Purpose**: Seed golden queries + create monitoring view
- **Inputs**: None (seeds data)
- **Outputs**: tbl_eval_golden_queries (20 rows), v_retrieval_health_daily view
- **Dependencies**: tbl_retrieval_telemetry (must exist for view)
- **Business value**: Continuous quality monitoring for retrieval system
- **Risk**: Golden queries reference specific providers that may not be in sample data

---

## 12. DATA FLOW SUMMARY (SOURCES → SINKS)

```
PDF Volume (27 GB)
  → OCR text (step1_parsed_v2.parquet)
    → Metadata (step2_with_metadata_v2.parquet)
      → LLM JSON (json_extract/, 3,519 files)
        ├→ V1 Base Tables (rates, terms, docs, parties)
        │    ├→ V1 Genie Tables (provider_profile, rates_current, terms, timeline)
        │    │    ├→ Genie Space (natural language Q&A)
        │    │    ├→ Dashboard (portfolio analytics)
        │    │    └→ Demo notebook (KPIs, charts)
        │    ├→ V2 State Engine (contract + amendment registries)
        │    ├→ V2 Reimbursement (rate_rules, stop_loss, lesser_of)
        │    │    ├→ V2 Intelligence (benchmarks, renewal priority)
        │    │    └→ V2 Legal Units (83K retrieval chunks)
        │    │         └→ VS Index (semantic retrieval)
        │    │              └→ Hybrid Retriever (4-channel search)
        │    │                   └→ Reranking → Citation Verification → Answer
        │    └→ VS-ready fulltext (1.36M chunks)
        │         └→ Demo "Ask Anything" (keyword + semantic channels)
        └→ Checkpoints (incremental resume)
```

---

## 13. KEY ARCHITECTURAL DECISIONS

1. **JSON files as intermediate** — All tables built from `json_extract/` not from each other. This makes the pipeline resilient to individual table failures but creates a 3,519-file dependency.

2. **Two retrieval corpora** — `idx_legal_units_v2` (83K structured units, stable) vs `tbl_contract_fulltext_vs_index` (1.36M raw chunks, unstable). The demo uses the fulltext index; the platform retriever uses the structured one.

3. **V1/V2 coexistence** — V2 tables read FROM V1 tables (not replacing them). This allows the Genie Space to continue working while V2 matures.

4. **Feature flags** — Three flags (CLAIMS, RERANKER, FULL_CORPUS) gate functionality that depends on external integrations. Clean separation of real vs placeholder data.

5. **Scope-aware supersession** — V2 state engine classifies amendment scope types to fix the V1 "latest document wins all" heuristic. Integration into rate supersession exists in 08_build_rates(fix) but is conditional on state engine having run.

6. **Direct REST API for LLM** — After ai_query() caused 10+ hour stalls, extraction uses direct requests.post() with per-file timeouts. This architectural decision is critical and should be preserved.

7. **Demo notebook as self-contained engine** — The "Ask Anything" cell implements its own 7-step pipeline independent of platform/ modules. It uses `tbl_contract_fulltext_vs_ready` (1.36M chunks) rather than the platform's `tbl_retrieval_legal_units` (83K). This is intentional: the demo needs exhaustive corpus coverage.

---

## 14. REDUNDANCIES IDENTIFIED

| Area | Redundancy | Justification |
|------|-----------|---------------|
| Config | 00_config.py duplicates constants in 01_execute_ddl, 02_state_engine, 03_reimbursement | Each module meant to be runnable standalone |
| log_step | Defined identically in 3+ modules | No shared import mechanism for .py files |
| dedup_extraction_versions | Copied in 08_build_rates AND 09_build_terms | Same JSON loading pattern needed by both |
| table_exists | Defined in 00_config AND 03_reimbursement | Standalone execution requirement |
| Retrieval engines | Platform HybridRetriever (05) vs Demo 7-step engine (Cell 6) | Different corpora + different purposes |
| Rate data | V1 tbl_contract_rates_all + V2 tbl_reimb_rate_rules + Genie tbl_genie_rates_current | Progressive refinement layers |

---

## 15. MISSING/INCOMPLETE COMPONENTS

| Component | Designed | Implemented | Gap |
|-----------|----------|-------------|-----|
| 06_reranking_service.py | ✓ (docs) | Not in platform/ folder | Module missing entirely |
| 07_citation_verification.py | ✓ (docs) | Not in platform/ folder | Module missing entirely |
| 09_scenario_engine.py | ✓ (docs) | Not in platform/ folder | Module missing entirely |
| 10_leverage_scoring.py | ✓ (docs) | Not in platform/ folder | Module missing entirely |
| tbl_v2_rate_facts_bitemporal | ✓ (DDL) | Table created, never populated | No population logic |
| tbl_v2_clause_facts_bitemporal | ✓ (DDL) | Table created, never populated | No population logic |
| tbl_v2_supersession_decisions | ✓ (DDL) | Table created, never populated | No population logic |
| tbl_v2_document_lineage | ✓ (DDL) | Table created, never populated | No population logic |
| Cross-encoder reranker | ✓ (design) | RERANKER_DEPLOYED=False | bge-reranker-v2-m3 not on serving |
| Claims feed | ✓ (design) | CLAIMS_AVAILABLE=False | No enterprise data connection |
| Full corpus processing | ✓ (design) | FULL_CORPUS_PROCESSED=False | 3,519/10,372 PDFs processed |
| Orchestration job DAG | ✓ (mentioned) | Orchestrator runs only 3 modules | No Lakeflow Job defined |

---

## 16. TECHNICAL DEBT INVENTORY

1. **SQL injection** — Retrieval engine uses f-string interpolation of user keywords into SQL ILIKE clauses (05_retrieval_engine.py line 166-167)
2. **Hardcoded schema** — `dev_adb.raw` appears as string literal in 5+ modules instead of using config
3. **No schema evolution** — Tables use `overwriteSchema=true` which can break downstream consumers
4. **No data validation** — V2 migration trusts V1 data quality without defensive checks
5. **Telemetry buffer** — In-memory buffer in 00_config never flushed if session crashes
6. **Plotly surrogate error** — Demo notebook cells 4/5 fail with utf-8 surrogate encoding issue
7. **Empty carve_outs** — Migration produces 0 rows, suggesting source data gap or filter issue
8. **Varying row counts** — tbl_v2_contract_registry reports 685 or 1,948 depending on run conditions
