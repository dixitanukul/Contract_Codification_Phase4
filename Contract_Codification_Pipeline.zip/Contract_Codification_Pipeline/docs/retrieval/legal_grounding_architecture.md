# LEGAL GROUNDING ARCHITECTURE
## Clause-Aware Chunking, Legal Unit Representation, and Span-Level Provenance

**Document Class:** Data Model & Processing Specification  
**Date:** 2026-05-22  
**Scope:** Transform raw OCR text into legally meaningful retrieval units with full provenance  
**Dependencies:** RETRIEVAL_ARCHITECTURE_V2.md (parent architecture)

---

## 1. THE CHUNKING PROBLEM IN LEGAL DOCUMENTS

### 1.1 Why Fixed-Size Chunks Fail for Contracts

Current system: 512-token fixed chunks with no overlap awareness.

**Failure modes observed:**

| Scenario | Fixed-Chunk Behavior | Correct Legal Unit |
| --- | --- | --- |
| Rate schedule spanning 2 pages | Split mid-table; one chunk has headers, another has values | Full rate table as one unit |
| "Subject to Section 4.2 above" | Reference chunk has no context of what 4.2 says | Section 4.2 + referencing clause together |
| Amendment modifying Exhibit B | Amendment text separated from original Exhibit B | Both linked as amendment chain |
| "...shall not exceed $75,000 per contract year, provided that..." | Split at "provided that" — condition lost | Complete conditional clause |
| Stop-loss with 3 sub-paragraphs | Each sub-paragraph a separate chunk | Parent + all sub-clauses |

### 1.2 Legal Documents Have Inherent Structure

Healthcare provider contracts follow predictable structures:

```
Contract
├── Preamble (parties, recitals, effective date)
├── Article I: Definitions
│   ├── Section 1.1: "Agreement" means...
│   ├── Section 1.2: "Covered Services" means...
│   └── ...
├── Article II: Scope of Services
├── Article III: Compensation
│   ├── Section 3.1: Inpatient Rates
│   │   ├── (a) Per Diem Rates [RATE TABLE]
│   │   ├── (b) Stop-Loss Provisions
│   │   └── (c) Carve-Outs
│   ├── Section 3.2: Outpatient Rates
│   └── Section 3.3: Payment Terms
├── Exhibit A: Covered Facilities
├── Exhibit B: Rate Schedule
│   ├── Table B-1: Inpatient Per Diem
│   ├── Table B-2: Outpatient Case Rates
│   └── Table B-3: Capitation Rates
└── Exhibit C: Quality Metrics
```

The chunking strategy must respect this hierarchy.

---

## 2. LEGAL SEMANTIC UNITS (LSU)

### 2.1 Definition

A **Legal Semantic Unit** (LSU) is the smallest fragment of a contract that:
1. Expresses a complete legal obligation, right, or definition
2. Can be understood without mandatory reference to adjacent text
3. Preserves all conditional logic ("provided that", "subject to", "except")
4. Maintains internal cross-references within the unit

### 2.2 LSU Types

| LSU Type | Description | Typical Size | Example |
| --- | --- | --- | --- |
| CLAUSE | Complete contractual obligation | 100-800 tokens | "Hospital shall be reimbursed at $1,500/day for Med/Surg, subject to stop-loss at $75,000" |
| DEFINITION | Term definition | 50-200 tokens | "'Covered Services' means all medically necessary services as defined by Plan's Medical Policy" |
| RATE_TABLE | Complete rate schedule | 200-2000 tokens | Full Exhibit B rate table with all service lines and amounts |
| CONDITION | If/then/else provision | 100-500 tokens | "If LOS exceeds 30 days, reimbursement converts to 80% of charges" |
| AMENDMENT_DELTA | What changed + effective date | 100-600 tokens | "Effective 01/01/2025, Exhibit B is hereby replaced in its entirety with the following..." |
| EXHIBIT_SECTION | Complete exhibit subsection | 200-1500 tokens | Full stop-loss exhibit with all tiers |
| CROSS_REFERENCE | Clause that references another | 50-200 tokens | "Payment subject to the lesser-of provisions in Section 4.2" |
| TERMINATION | Contract end provisions | 100-400 tokens | "Either party may terminate with 90 days written notice..." |

### 2.3 LSU Data Model

```python
@dataclass
class LegalSemanticUnit:
    """The atomic retrieval unit — a legally complete fragment."""
    # Identity
    unit_id: str                         # Stable hash: sha256(source_filename + char_offset)
    source_filename: str                 # Source PDF
    provider_id: str
    contract_id: str
    
    # Type classification
    unit_type: str                       # CLAUSE | DEFINITION | RATE_TABLE | etc.
    legal_function: str                  # OBLIGATION | RIGHT | CONDITION | DEFINITION | EXCEPTION
    
    # Hierarchy
    parent_unit_id: Optional[str]        # For sub-clauses within a parent clause
    section_path: str                    # "Article III > Section 3.1 > (b)"
    exhibit_name: Optional[str]          # "Exhibit B", "Attachment 1"
    
    # Content
    text: str                            # Full text of the legal unit
    summary: str                         # 1-line LLM summary for display
    key_entities: List[str]              # Extracted: amounts, dates, codes, parties
    
    # Provenance (span-level)
    page_start: int                      # Starting page in PDF
    page_end: int                        # Ending page
    char_offset_start: int               # Character offset in full OCR text
    char_offset_end: int
    bounding_boxes: Optional[List[dict]] # PDF coordinates for highlighting
    
    # State
    is_current: bool                     # Not superseded by amendment
    superseded_by_amendment: Optional[str]
    amendment_chain: List[str]           # Ordered amendments modifying this unit
    effective_date: date
    
    # Retrieval metadata
    domain: str                          # INPATIENT | OUTPATIENT | PROFESSIONAL | CAPITATION
    rate_category: Optional[str]         # Service line if rate-related
    programs: List[str]                  # Applicable programs
    networks: List[str]                  # Applicable networks
    
    # Embedding (computed at indexing time)
    embedding: List[float]              # 1024-dim from databricks-gte-large-en
```

---

## 3. CLAUSE-AWARE CHUNKING PIPELINE

### 3.1 Pipeline Architecture

```
Raw OCR Text (from 01_parse_pdfs)
        │
        ▼
┌─────────────────────────┐
│ STAGE 1: Structure      │  Detect section headers, numbered clauses,
│ Detection               │  exhibit boundaries, table structures
└────────────┬────────────┘
             │
             ▼
┌─────────────────────────┐
│ STAGE 2: Boundary       │  Identify clause boundaries using:
│ Identification          │  - Section numbering patterns
│                         │  - Legal transition signals
│                         │  - Table/exhibit delimiters
└────────────┬────────────┘
             │
             ▼
┌─────────────────────────┐
│ STAGE 3: Unit           │  Classify each boundary-delimited segment
│ Classification          │  into LSU types
└────────────┬────────────┘
             │
             ▼
┌─────────────────────────┐
│ STAGE 4: Context        │  Resolve cross-references, attach parent
│ Resolution              │  context, identify amendment relationships
└────────────┬────────────┘
             │
             ▼
┌─────────────────────────┐
│ STAGE 5: Embedding &    │  Generate embeddings, enrich metadata,
│ Indexing                 │  write to tbl_retrieval_legal_units
└─────────────────────────┘
```

### 3.2 Stage 1: Structure Detection

```python
SECTION_PATTERNS = [
    # Article/Section numbering
    r'^(Article|ARTICLE)\s+[IVXLCDM]+[.:]',           # Article VII:
    r'^(Section|SECTION)\s+\d+\.\d+[.:]?',            # Section 3.1:
    r'^\d+\.\d+(\.\d+)?\s+[A-Z]',                     # 3.1.2 Inpatient
    r'^\([a-z]\)\s',                                    # (a) Per Diem
    r'^\(\d+\)\s',                                      # (1) Subject to
    
    # Exhibit boundaries
    r'^(EXHIBIT|Exhibit|ATTACHMENT|Attachment)\s+[A-Z0-9]', 
    r'^(Table|TABLE)\s+[A-Z]-\d+',                     # Table B-1
    
    # Amendment signals
    r'^(AMENDMENT|Amendment)\s+(No\.|#|Number)\s*\d+',
    r'(hereby\s+amended|replaced\s+in\s+(its\s+)?entirety)',
    r'(effective\s+(as\s+of|on)\s+\w+\s+\d+,?\s*\d{4})',
]

CLAUSE_BOUNDARY_SIGNALS = [
    # Obligation markers
    r'\b(shall|must|will|agrees?\s+to)\b',
    # Conditional markers (DO NOT split here — include in same unit)
    r'\b(provided\s+that|subject\s+to|except\s+(that|as)|notwithstanding)\b',
    # Termination markers (end of clause)
    r'\.\s*$',                                          # Period at end of paragraph
    r';\s*$',                                           # Semicolon (list item end)
]
```

### 3.3 Stage 2: Boundary Rules

```python
def identify_boundaries(ocr_text: str, page_breaks: List[int]) -> List[Boundary]:
    """
    Identify legal unit boundaries in OCR text.
    
    Rules (in priority order):
    1. Exhibit headers ALWAYS start a new unit
    2. Section/Article numbers start new units
    3. Sub-clause markers ((a), (1)) start child units within parent
    4. Rate tables (detected by repeated $ or numeric patterns) are single units
    5. Paragraphs ending in period that exceed 100 chars are standalone units
    6. Never split mid-sentence or mid-conditional
    """
    boundaries = []
    
    # Rule: never split inside these constructs
    NO_SPLIT_ZONES = [
        (r'\bprovided\s+that\b', r'\.\s'),           # Keep conditional together
        (r'\bsubject\s+to\b', r'\.\s'),               # Keep subject-to together
        (r'\blesser\s+of\b', r'\.\s'),                # Keep lesser-of together
        (r'\$[\d,]+', r'[^$\d,]{20}'),                # Keep dollar amounts with context
    ]
    
    # Detect table regions (suppress normal boundary detection)
    table_regions = detect_table_regions(ocr_text)
    
    for match in re.finditer(COMBINED_PATTERN, ocr_text):
        position = match.start()
        
        # Skip if inside a no-split zone or table
        if in_no_split_zone(position, NO_SPLIT_ZONES, ocr_text):
            continue
        if any(start <= position <= end for start, end in table_regions):
            continue
            
        boundaries.append(Boundary(
            position=position,
            type=classify_boundary_type(match),
            level=determine_hierarchy_level(match)
        ))
    
    return boundaries
```

### 3.4 Stage 3: Unit Classification (LLM-Assisted)

```python
CLASSIFICATION_PROMPT = """Classify this contract fragment into exactly one type:
- CLAUSE: A complete contractual obligation or right
- DEFINITION: A term being defined
- RATE_TABLE: A rate schedule or payment table
- CONDITION: An if/then provision modifying another clause
- AMENDMENT_DELTA: Text describing what an amendment changes
- EXHIBIT_SECTION: A complete subsection of an exhibit
- CROSS_REFERENCE: A clause that primarily references another section
- TERMINATION: Contract end or termination provisions

Also extract:
- legal_function: OBLIGATION | RIGHT | CONDITION | DEFINITION | EXCEPTION
- key_entities: dollar amounts, dates, percentages, codes mentioned
- summary: One sentence describing what this unit establishes

Fragment:
{fragment_text}

Respond as JSON: {"unit_type": "...", "legal_function": "...", "key_entities": [...], "summary": "..."}"""
```

### 3.5 Stage 4: Context Resolution

```python
def resolve_context(units: List[LegalSemanticUnit]) -> List[LegalSemanticUnit]:
    """
    Post-processing: resolve cross-references and attach amendment context.
    
    Rules:
    1. CROSS_REFERENCE units get their target attached as metadata
    2. CONDITION units get linked to the CLAUSE they modify
    3. AMENDMENT_DELTA units get linked to the original clause/exhibit
    4. Rate tables get linked to applicable stop-loss and carve-out clauses
    """
    # Build section index for cross-reference resolution
    section_index = {u.section_path: u.unit_id for u in units}
    
    for unit in units:
        # Resolve "Subject to Section X.Y"
        refs = extract_cross_references(unit.text)
        for ref in refs:
            target_id = section_index.get(ref.target_section)
            if target_id:
                unit.cross_references.append(target_id)
        
        # Link conditions to parent clauses
        if unit.unit_type == 'CONDITION' and unit.parent_unit_id:
            parent = get_unit(unit.parent_unit_id)
            parent.conditions.append(unit.unit_id)
        
        # Resolve amendment state
        unit.is_current = check_supersession_state(unit)
        unit.amendment_chain = get_amendment_chain(unit)
    
    return units
```

---

## 4. SPAN-LEVEL PROVENANCE

### 4.1 Provenance Chain

Every generated answer must trace back through this chain:

```
Generated Answer Text
    ↓ (citation marker)
Supporting Claim [1]
    ↓ (span mapping)
Legal Semantic Unit (unit_id: abc123)
    ↓ (character offsets)
Source PDF Page 47, chars 12340-12890
    ↓ (file reference)
/Volumes/.../Provider_Contracts/ProviderX/contract_base_2023.pdf
```

### 4.2 Provenance Data Model

```python
@dataclass
class ProvenanceRecord:
    """Complete provenance chain for a single claim in a generated answer."""
    # What was claimed
    claim_text: str                      # The specific assertion in the answer
    claim_start: int                     # Char position in generated answer
    claim_end: int
    
    # Supporting evidence
    evidence_unit_id: str                # FK to LegalSemanticUnit
    evidence_text: str                   # The specific supporting text
    evidence_highlight_start: int        # Char position within unit for highlighting
    evidence_highlight_end: int
    
    # Source document
    source_filename: str
    page_number: int
    pdf_bounding_box: Optional[dict]     # For PDF viewer highlighting
    
    # State at time of retrieval
    evidence_is_current: bool
    evidence_effective_date: date
    amendment_context: Optional[str]     # Warning if modified by later amendment
    
    # Confidence
    support_strength: float             # 0-1: how strongly evidence supports claim
    faithfulness_verified: bool         # Whether claim was verified against evidence
```

### 4.3 PDF-Level Coordinate Mapping

```python
def map_to_pdf_coordinates(unit: LegalSemanticUnit) -> List[BoundingBox]:
    """
    Map character offsets back to PDF page coordinates for highlighting.
    
    Uses the OCR metadata stored during Step 01 (parse_pdfs):
    - ai_parse_document returns bounding boxes per text block
    - We store page_number + bbox in the parsed output
    """
    # Look up original OCR blocks that overlap with this unit's char range
    ocr_blocks = get_ocr_blocks(
        source_filename=unit.source_filename,
        char_start=unit.char_offset_start,
        char_end=unit.char_offset_end
    )
    
    return [BoundingBox(
        page=block.page_number,
        x1=block.bbox.x1,
        y1=block.bbox.y1,
        x2=block.bbox.x2,
        y2=block.bbox.y2
    ) for block in ocr_blocks]
```

---

## 5. GROUNDING RULES

### 5.1 What Constitutes a Grounded Claim

A claim in a generated answer is **grounded** if and only if:

1. **Direct support**: The claim is directly stated or logically entailed by one or more LSUs
2. **Correct state**: The supporting LSUs are in the correct temporal state for the query
3. **No contradiction**: No other current LSU contradicts the claim
4. **Scope match**: The supporting LSUs apply to the entities in the query (correct provider, program, network)

### 5.2 Grounding Violations (Ranked by Severity)

| Violation | Severity | Example |
| --- | --- | --- |
| FABRICATION | CRITICAL | Claiming a rate exists that appears in no document |
| STALE_REFERENCE | HIGH | Citing a superseded rate as current |
| SCOPE_MISMATCH | HIGH | Applying Provider A's rate to Provider B |
| OVERGENERALIZATION | MEDIUM | "All providers have stop-loss" when only 60% do |
| NUMERICAL_ERROR | HIGH | Stating "$1,500/day" when source says "$1,200/day" |
| CONDITIONAL_OMISSION | MEDIUM | Stating a rate without its "subject to" conditions |
| TEMPORAL_CONFUSION | HIGH | Mixing Year 1 and Year 3 rates in same answer |

### 5.3 Mandatory Disclaimers

The system MUST attach disclaimers when:

```python
DISCLAIMER_RULES = {
    "possibly_superseded": {
        "condition": lambda unit: unit.state_label == "POSSIBLY_SUPERSEDED",
        "text": "⚠️ This provision may have been modified by a subsequent amendment. "
                "Verify against the latest executed documents."
    },
    "partial_extraction": {
        "condition": lambda unit: unit.confidence_score < 0.8,
        "text": "⚠️ This information was extracted with moderate confidence. "
                "Cross-reference with the source document."
    },
    "amendment_exists": {
        "condition": lambda unit: len(unit.amendment_chain) > 0,
        "text": f"ℹ️ This clause has been modified by {len(unit.amendment_chain)} "
                f"amendment(s). The most recent change was effective {latest_date}."
    },
    "multiple_programs": {
        "condition": lambda query: len(query.programs) > 1,
        "text": "ℹ️ Rates shown may vary by program (Commercial vs Medicare vs Medi-Cal). "
                "Verify the applicable program."
    }
}
```

---

## 6. CHUNKING PIPELINE PERFORMANCE

### 6.1 Expected Volumes

| Metric | Current (V1) | Target (V2) |
| --- | --- | --- |
| Total chunks/units | 1,361,179 (fixed) | ~200,000 (clause-aware) |
| Avg unit size | 512 tokens | 150-800 tokens (variable) |
| Index sync time | Never completes | <4 hours (smaller, meaningful units) |
| Metadata per unit | filename only | 15+ fields (type, state, hierarchy, provenance) |
| Cross-reference resolution | None | >80% of internal references linked |

### 6.2 Processing Cost

```
10,372 PDFs × avg 5 pages × avg 4 legal units per page
= ~207,440 legal units

Classification: 207K × $0.003/unit (Claude Haiku batch) = ~$620
Embedding: 207K × $0.0001/unit (GTE-large-en) = ~$21
Total indexing cost: ~$650 (one-time)
Incremental: $0.003 per new PDF processed
```

---

*Legal grounding transforms retrieval from "here are some relevant text fragments" into "here is the authoritative contractual basis for this answer, with full provenance chain and state verification." This is the minimum standard for enterprise legal AI.*
