# RETRIEVAL ARCHITECTURE V2
## Enterprise-Grade Hybrid Retrieval for Provider Contract Intelligence

**Document Class:** System Architecture  
**Date:** 2026-05-22  
**Scope:** Replace naive ANN cosine search with legally-grounded, state-aware hybrid retrieval  
**Supersedes:** Tier 2B semantic search (notebook 17), Tier 3A hybrid router (notebook 19)

---

## 1. CURRENT STATE DEFICIENCIES

### 1.1 Retrieval Pipeline (As-Is)

```
User Query → LLM Intent Classification → {SQL | SEMANTIC | HYBRID}
                                              ↓
                            VS ANN Search (cosine, k=10)
                                              ↓
                            Raw chunks returned to LLM
                                              ↓
                            LLM generates answer (ungrounded)
```

### 1.2 Critical Gaps

| Gap | Impact | Severity |
| --- | --- | --- |
| No lexical retrieval | Misses exact contract language (clause numbers, dollar amounts, CPT codes) | HIGH |
| No reranking | Top-k ANN results are topically relevant but not legally precise | HIGH |
| No state awareness | Returns superseded rates alongside current ones without distinction | CRITICAL |
| No amendment awareness | Cannot determine if a clause has been modified by later amendments | CRITICAL |
| Heuristic confidence | "High/Medium/Low" based on chunk count, not calibrated probability | MEDIUM |
| No provenance | Cannot trace answer back to specific page/paragraph in source PDF | HIGH |
| No faithfulness check | LLM can hallucinate contract terms that appear plausible | CRITICAL |
| No metadata filtering | Cannot scope search to provider/program/date without post-filtering | MEDIUM |

### 1.3 Verified Symptoms

From ENGINEERING_STRENGTHS_AND_WEAKNESSES.md:
- W3: Full-text VS index never reaches ready state (1.36M chunks, ~10% synced)
- W5: Rate supersession is approximated, not verified
- W4: SQL injection in intelligence notebooks (f-string interpolation)
- Tier 3A router: 100% routing accuracy but no grounding verification

---

## 2. V2 ARCHITECTURE: GROUNDED LEGAL RETRIEVAL

### 2.1 Design Principles

1. **Every claim is traceable** — answer text maps to source span(s) with page numbers
2. **State is authoritative** — superseded content is flagged, not hidden (legal context)
3. **Confidence is calibrated** — probability scores validated against human judgment
4. **Retrieval is multi-signal** — lexical + semantic + metadata + structural signals fused
5. **Evaluation is continuous** — retrieval quality measured on every query, not batch-only

### 2.2 Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                    RETRIEVAL ENGINE V2 — PIPELINE                                 │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                   │
│  ┌──────────────┐   ┌──────────────┐   ┌──────────────┐   ┌──────────────────┐ │
│  │ QUERY        │──▶│ RETRIEVAL    │──▶│ RERANKING    │──▶│ GROUNDING &      │ │
│  │ UNDERSTANDING│   │ FUSION       │   │ PIPELINE     │   │ VERIFICATION     │ │
│  └──────────────┘   └──────────────┘   └──────────────┘   └──────────────────┘ │
│        │                   │                   │                    │             │
│        ▼                   ▼                   ▼                    ▼             │
│  ┌──────────────┐   ┌──────────────┐   ┌──────────────┐   ┌──────────────────┐ │
│  │ • Intent     │   │ • Semantic   │   │ • Cross-enc  │   │ • Citation map   │ │
│  │ • Entities   │   │ • Lexical    │   │ • Legal rel  │   │ • Faithfulness   │ │
│  │ • Temporal   │   │ • Metadata   │   │ • Recency    │   │ • Confidence     │ │
│  │ • Scope      │   │ • Structural │   │ • State-rank │   │ • Provenance     │ │
│  └──────────────┘   └──────────────┘   └──────────────┘   └──────────────────┘ │
│                                                                                   │
│  ┌───────────────────────────────────────────────────────────────────────────┐   │
│  │ TELEMETRY: Latency, precision@k, retrieval coverage, confidence cal      │   │
│  └───────────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────────┘
```

---

## 3. STAGE 1: QUERY UNDERSTANDING

### 3.1 Query Decomposition

```python
@dataclass
class ParsedQuery:
    """Structured representation of user intent."""
    # Intent classification
    intent: str                    # RATE_LOOKUP | CLAUSE_SEARCH | COMPARISON | TIMELINE | COMPLIANCE
    sub_intent: str               # e.g., 'per_diem_rate', 'stop_loss_threshold'
    
    # Entity extraction
    providers: List[str]          # Provider names/IDs mentioned
    service_lines: List[str]      # Service categories mentioned
    programs: List[str]           # Commercial, Medicare, Medi-Cal
    networks: List[str]           # HMO, PPO
    
    # Temporal scope
    temporal_intent: str          # CURRENT | HISTORICAL | TREND | AS_OF_DATE
    as_of_date: Optional[date]   # Specific date for point-in-time queries
    
    # Retrieval parameters
    require_current_only: bool    # Filter to non-superseded documents
    require_exact_match: bool     # Boost lexical over semantic
    scope_domain: str             # INPATIENT | OUTPATIENT | ALL
    
    # Derived search strategies
    search_strategies: List[str]  # ['semantic', 'lexical', 'metadata', 'sql']
```

### 3.2 Intent-Driven Strategy Selection

| Intent | Primary Strategy | Secondary | Filter Requirements |
| --- | --- | --- | --- |
| RATE_LOOKUP | SQL (structured tables) | Lexical (contract text) | provider + service_line + current_only |
| CLAUSE_SEARCH | Semantic (VS index) | Lexical (exact phrase) | provider + document_type |
| COMPARISON | SQL (multi-provider) | Semantic (context) | provider_list + service_line |
| TIMELINE | SQL + amendment table | Semantic (change context) | provider + temporal ordering |
| COMPLIANCE | Lexical (regulatory terms) | Semantic (clause intent) | document_type = base_agreement |

---

## 4. STAGE 2: RETRIEVAL FUSION

### 4.1 Multi-Channel Retrieval

Four parallel retrieval channels executed concurrently:

```python
async def retrieve_all_channels(query: ParsedQuery) -> List[RetrievalResult]:
    """Execute all retrieval channels in parallel."""
    results = await asyncio.gather(
        retrieve_semantic(query),      # VS ANN search
        retrieve_lexical(query),       # BM25 / keyword search
        retrieve_metadata(query),      # Filtered structured search
        retrieve_structural(query),    # Document structure-aware
    )
    return fuse_results(results, query)
```

### 4.2 Semantic Channel (Enhanced)

```python
def retrieve_semantic(query: ParsedQuery) -> List[ScoredChunk]:
    """
    Vector similarity search with metadata pre-filtering.
    Uses databricks-gte-large-en embeddings on clause-aware chunks.
    """
    filters = build_vs_filters(query)  # provider, domain, date range
    
    results = vs_index.similarity_search(
        query_text=query.reformulated_text,  # LLM-rewritten for retrieval
        columns=["chunk_text", "source_filename", "page_number", 
                 "section_type", "clause_id", "is_current", "provider_id"],
        filters=filters,
        num_results=50,  # Over-retrieve for reranking
        score_threshold=0.3  # Permissive — reranker will filter
    )
    
    return [ScoredChunk(
        text=r.chunk_text,
        score=r.score,
        channel='semantic',
        metadata=r.metadata
    ) for r in results]
```

### 4.3 Lexical Channel (NEW)

```python
def retrieve_lexical(query: ParsedQuery) -> List[ScoredChunk]:
    """
    BM25-based keyword search for exact contract language.
    Critical for: dollar amounts, clause numbers, CPT codes, legal terms.
    
    Implementation: Spark SQL full-text search on chunk table
    with token-level matching (no embedding required).
    """
    # Extract high-value keywords (amounts, codes, proper nouns)
    keywords = extract_legal_keywords(query.raw_text)
    
    # Build BM25 query against chunk text
    bm25_results = spark.sql(f"""
        SELECT chunk_text, source_filename, page_number, section_type,
               bm25_score(chunk_text, :keywords) AS score
        FROM dev_adb.raw.tbl_retrieval_chunks_v2
        WHERE {build_metadata_where(query)}
          AND chunk_text RLIKE :keyword_pattern
        ORDER BY score DESC
        LIMIT 50
    """, params={"keywords": keywords, "keyword_pattern": keyword_regex})
    
    return scored_chunks_from_spark(bm25_results, channel='lexical')
```

### 4.4 Metadata Channel (NEW)

```python
def retrieve_metadata(query: ParsedQuery) -> List[ScoredChunk]:
    """
    Structured metadata search when entities are clearly identified.
    Bypasses embedding entirely — direct SQL against normalized tables.
    """
    if not query.providers:
        return []
    
    # Query V2 rate rules, conditions, stop-loss tables directly
    structured_results = spark.sql("""
        SELECT 
            rr.formula_json, rr.rate_text, rr.rate_numeric,
            rr.source_filename, rr.service_line, rr.effective_date,
            sl.attachment_level, sl.reimburse_formula_type,
            t.display_name AS taxonomy_name
        FROM dev_adb.raw.tbl_reimb_rate_rules rr
        LEFT JOIN dev_adb.raw.tbl_reimb_stop_loss sl ON rr.rule_id = sl.rule_id
        LEFT JOIN dev_adb.raw.dim_service_line_taxonomy t 
            ON rr.service_line = t.service_line_code
        WHERE rr.provider_id IN (:provider_ids)
          AND (:service_line IS NULL OR rr.service_line = :service_line)
          AND (:domain IS NULL OR rr.rate_domain = :domain)
    """, params=query.to_sql_params())
    
    return structured_to_chunks(structured_results, channel='metadata')
```

### 4.5 Structural Channel (NEW)

```python
def retrieve_structural(query: ParsedQuery) -> List[ScoredChunk]:
    """
    Document-structure-aware retrieval.
    Uses exhibit/section hierarchy to retrieve complete legal units.
    
    Example: If a clause is found, also retrieve:
    - The parent section header
    - Sibling clauses in same section
    - Any amendments that modify this section
    """
    # First find anchor chunks via semantic/lexical
    anchors = retrieve_semantic(query, num_results=10)
    
    # Expand each anchor to its legal unit boundary
    expanded = []
    for anchor in anchors:
        unit = get_legal_unit(anchor.clause_id)  # Full clause context
        siblings = get_sibling_clauses(anchor.section_id)
        amendments = get_amendments_for_section(
            anchor.source_filename, anchor.section_type
        )
        expanded.append(StructuralResult(
            anchor=anchor,
            context=unit,
            related=siblings[:3],
            amendments=amendments
        ))
    
    return expanded
```

### 4.6 Reciprocal Rank Fusion

```python
def fuse_results(channel_results: List[List[ScoredChunk]], 
                 query: ParsedQuery) -> List[ScoredChunk]:
    """
    Fuse results from all channels using weighted Reciprocal Rank Fusion.
    
    Channel weights vary by query intent:
    - RATE_LOOKUP: metadata(0.4) + lexical(0.3) + semantic(0.2) + structural(0.1)
    - CLAUSE_SEARCH: semantic(0.4) + structural(0.3) + lexical(0.2) + metadata(0.1)
    - COMPARISON: metadata(0.5) + semantic(0.3) + lexical(0.1) + structural(0.1)
    """
    weights = get_channel_weights(query.intent)
    k = 60  # RRF constant
    
    # Score each document across all channels
    doc_scores = defaultdict(float)
    for channel_idx, results in enumerate(channel_results):
        channel_weight = weights[channel_idx]
        for rank, chunk in enumerate(results):
            doc_id = chunk.document_id
            doc_scores[doc_id] += channel_weight * (1.0 / (k + rank + 1))
    
    # Sort by fused score, return top-N for reranking
    fused = sorted(doc_scores.items(), key=lambda x: x[1], reverse=True)
    return [get_chunk(doc_id) for doc_id, score in fused[:30]]
```

---

## 5. STAGE 3: STATE-AWARE RETRIEVAL

### 5.1 Document State Resolution

Every retrieved chunk is annotated with its legal state before reaching the reranker:

```python
@dataclass
class ChunkState:
    """Legal state of a retrieved chunk."""
    is_current: bool                    # Not superseded
    superseded_by: Optional[str]        # Amendment that superseded this
    supersession_type: str              # FULL_REPLACEMENT | EXHIBIT_SPECIFIC | RATE_SPECIFIC
    supersession_confidence: float      # 0-1
    effective_date: date
    expiration_date: Optional[date]
    amendment_chain: List[str]          # Ordered list of amendments modifying this clause
    
    @property
    def state_label(self) -> str:
        if self.is_current:
            return "CURRENT"
        elif self.supersession_confidence > 0.8:
            return "SUPERSEDED"
        else:
            return "POSSIBLY_SUPERSEDED"
```

### 5.2 Amendment-Aware Context Enrichment

```python
def enrich_with_amendment_context(chunks: List[ScoredChunk]) -> List[ScoredChunk]:
    """
    For each chunk, determine if amendments have modified its content.
    Uses tbl_v2_amendment_registry.scope_type and exhibits_modified.
    """
    for chunk in chunks:
        # Find amendments that post-date this chunk's source document
        amendments = spark.sql("""
            SELECT a.amendment_id, a.effective_date, a.scope_type,
                   a.exhibits_modified, a.summary_of_changes,
                   a.scope_confidence
            FROM dev_adb.raw.tbl_v2_amendment_registry a
            WHERE a.contract_id = :contract_id
              AND a.effective_date > :chunk_date
              AND (a.scope_type = 'FULL_REPLACEMENT'
                   OR a.exhibits_modified LIKE :exhibit_pattern
                   OR a.rate_categories_modified LIKE :category_pattern)
            ORDER BY a.effective_date ASC
        """, params={
            "contract_id": chunk.contract_id,
            "chunk_date": chunk.effective_date,
            "exhibit_pattern": f"%{chunk.exhibit}%",
            "category_pattern": f"%{chunk.rate_category}%"
        })
        
        chunk.state = resolve_state(chunk, amendments)
        chunk.amendment_context = format_amendment_summary(amendments)
    
    return chunks
```

### 5.3 Temporal Filtering Modes

| Mode | Behavior | Use Case |
| --- | --- | --- |
| CURRENT_ONLY | Return only `is_current = TRUE` chunks | "What's the current per diem?" |
| HISTORICAL_INCLUDED | Return all, flag superseded with warning | "Show me the rate history" |
| AS_OF_DATE | Return what was current on a specific date | "What was the rate on 2024-06-15?" |
| FULL_LINEAGE | Return clause + all amendments in order | "How has this clause changed?" |

---

## 6. INDEXING STRATEGY

### 6.1 Dual-Index Architecture (Revised)

| Index | Content | Use Case | Status |
| --- | --- | --- | --- |
| `idx_legal_units_v2` | Clause-aware chunks (legal semantic units) | Primary semantic retrieval | NEW |
| `idx_fulltext_bm25` | Token-indexed full document text | Lexical keyword search | NEW |
| `idx_structured_vs` | Existing 69K structured chunks | Backward-compat, structured queries | EXISTING |

### 6.2 New Index: Legal Units

```sql
CREATE TABLE IF NOT EXISTS dev_adb.raw.tbl_retrieval_legal_units (
    -- Identity
    unit_id             STRING NOT NULL,
    source_filename     STRING NOT NULL,
    provider_id         STRING NOT NULL,
    contract_id         STRING NOT NULL,
    
    -- Legal unit boundaries
    section_type        STRING,          -- RATE_SCHEDULE | CLAUSE | DEFINITION | EXHIBIT_HEADER
    section_number      STRING,          -- "4.2.1", "Exhibit B", "Article VII"
    clause_id           STRING,          -- Stable clause identifier across amendments
    parent_unit_id      STRING,          -- Hierarchical structure
    
    -- Content
    unit_text           STRING NOT NULL,  -- Full text of the legal unit
    unit_summary        STRING,          -- LLM-generated 1-line summary
    
    -- Embedding
    embedding           ARRAY<FLOAT>,    -- databricks-gte-large-en (1024-dim)
    
    -- State
    is_current          BOOLEAN DEFAULT TRUE,
    superseded_by       STRING,
    effective_date      DATE,
    
    -- Provenance
    page_start          INT,
    page_end            INT,
    char_offset_start   INT,
    char_offset_end     INT,
    
    -- Metadata for filtering
    document_type       STRING,          -- base_agreement | amendment | settlement
    rate_domain         STRING,          -- INPATIENT | OUTPATIENT | PROFESSIONAL | CAPITATION
    exhibit_name        STRING,
    
    -- Retrieval stats
    retrieval_count     INT DEFAULT 0,
    avg_relevance_score FLOAT
) USING DELTA;
```

### 6.3 Chunking Migration Path

```
Current (V1):                          Target (V2):
─────────────                          ────────────
Fixed 512-token chunks                 Clause-aware legal units
No overlap awareness                   Parent-child hierarchy
No state tracking                      Amendment state resolved
No structural metadata                 Section/exhibit/page provenance
1.36M raw chunks (mostly unsynced)     ~200K legal units (fully indexed)
```

See **LEGAL_GROUNDING_ARCHITECTURE.md** for detailed chunking strategy.

---

## 7. IMPLEMENTATION PLAN

### Phase 1: Foundation (Week 1-2)
- Create `tbl_retrieval_legal_units` with clause-aware chunking pipeline
- Implement BM25 lexical search on existing chunk table
- Add state annotation to existing VS search results
- Build query understanding module (intent + entity extraction)

### Phase 2: Fusion (Week 3-4)
- Implement 4-channel parallel retrieval
- Build Reciprocal Rank Fusion with intent-weighted channels
- Integrate reranking pipeline (see RERANKING_PIPELINE_DESIGN.md)
- Add amendment-aware context enrichment

### Phase 3: Grounding (Week 5-6)
- Implement citation extraction and span mapping
- Build faithfulness verification (see CITATION_VERIFICATION_FRAMEWORK.md)
- Deploy calibrated confidence scoring
- Add provenance chain from answer → chunk → page → PDF

### Phase 4: Evaluation (Week 7-8)
- Deploy retrieval telemetry (latency, precision@k, coverage)
- Build evaluation harness with labeled query set
- Calibrate confidence against human judgments
- Establish retrieval quality baselines

---

## 8. PERFORMANCE TARGETS

| Metric | Current (V1) | Target (V2) | Measurement |
| --- | --- | --- | --- |
| Retrieval precision@5 | Unknown (~60% est.) | >85% | Human-judged relevance |
| State correctness | ~70% (heuristic) | >95% | Supersession accuracy |
| Citation faithfulness | Unverified | >90% | Claim-to-source verification |
| Confidence calibration | Heuristic buckets | ECE < 0.10 | Calibration curve |
| End-to-end latency (p95) | ~8s | <5s | Query to final answer |
| Amendment awareness | None | >90% | Correctly flags modified clauses |

---

## 9. DEPENDENCIES

| Dependency | Status | Required By |
| --- | --- | --- |
| V2 State Engine (tbl_v2_*) | ✅ DDL Complete | State-aware retrieval |
| V2 Reimbursement Engine (tbl_reimb_*) | ✅ DDL Complete | Metadata channel |
| dim_service_line_taxonomy | ✅ Seed data ready | Query understanding |
| VS endpoint capacity | ⚠️ Full-text index at 10% | Semantic channel |
| Cross-encoder model | 🔲 Not deployed | Reranking stage |
| Legal unit chunking pipeline | 🔲 Not built | New index |

---

*This architecture transforms retrieval from "find similar text" into "find legally authoritative, provenance-traced, state-resolved evidence" — the foundation for enterprise-grade contract intelligence.*
