# RETRIEVAL EVALUATION FRAMEWORK
## Continuous Measurement of Retrieval Quality, Faithfulness, and Legal Accuracy

**Document Class:** Evaluation & Telemetry Specification  
**Date:** 2026-05-22  
**Scope:** Define metrics, harnesses, and monitoring for enterprise-grade retrieval  
**Principle:** "If you can't measure it, you can't improve it — and you can't trust it."  

---

## 1. EVALUATION PHILOSOPHY

### 1.1 Three Evaluation Modes

| Mode | When | Purpose | Cost |
| --- | --- | --- | --- |
| **Offline** | Before deployment, after changes | Full benchmark suite, regression detection | Hours, human annotation |
| **Online** | Every production query | Telemetry, drift detection, automated checks | Milliseconds overhead |
| **Periodic** | Weekly/monthly | Confidence calibration, coverage analysis | Batch, sampling-based |

### 1.2 What Must Be Measured

```
┌───────────────────────────────────────────────────────────────────────┐
│                    EVALUATION DIMENSIONS                                │
├───────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  RETRIEVAL QUALITY          ANSWER QUALITY          SYSTEM QUALITY     │
│  ─────────────────          ──────────────          ──────────────     │
│  • Precision@K              • Faithfulness          • Latency (p50/95) │
│  • Recall@K                 • Completeness          • Throughput        │
│  • NDCG@K                   • Citation accuracy     • Error rate        │
│  • MRR                      • State correctness     • Coverage          │
│  • State precision          • Numerical accuracy    • Availability      │
│  • Scope purity             • Conditional preserve  • Cost per query    │
│  • Diversity                • Hallucination rate    • Cache hit rate    │
│                                                                         │
└───────────────────────────────────────────────────────────────────────┘
```

---

## 2. EVALUATION DATASET

### 2.1 Golden Query Set

A curated set of queries with human-annotated ground truth:

```python
@dataclass
class EvaluationQuery:
    """A single evaluation query with ground truth."""
    query_id: str
    query_text: str
    
    # Query metadata
    intent: str                           # RATE_LOOKUP | CLAUSE_SEARCH | COMPARISON | TIMELINE
    complexity: str                       # SIMPLE | MODERATE | COMPLEX | MULTI_HOP
    temporal_scope: str                   # CURRENT | HISTORICAL | TREND
    
    # Ground truth: relevant documents (human-judged)
    relevant_units: List[RelevanceJudgment]  # (unit_id, relevance: 0-3)
    
    # Ground truth: expected answer properties
    expected_providers: List[str]         # Which providers should appear
    expected_values: Dict[str, Any]       # Expected numeric values (rates, dates)
    expected_state: str                   # Expected current/superseded classification
    
    # Difficulty markers
    requires_amendment_awareness: bool    # True if answer depends on supersession
    requires_cross_reference: bool        # True if answer spans multiple sections
    has_lesser_of: bool                   # True if multiple rates must be compared
    has_conditions: bool                  # True if conditional logic applies

@dataclass
class RelevanceJudgment:
    unit_id: str
    relevance: int  # 0=not relevant, 1=marginal, 2=relevant, 3=highly relevant
    is_authoritative: bool  # True if this is THE correct source
    is_current: bool        # True if this represents current state
```

### 2.2 Query Categories (Target: 200+ queries)

| Category | Count | Examples |
| --- | --- | --- |
| Rate lookup (single provider) | 40 | "What is Providence's ICU per diem?" |
| Rate lookup (with conditions) | 30 | "What's the stop-loss threshold for St. Joseph?" |
| Multi-provider comparison | 25 | "Compare per diem rates for the top 5 providers" |
| Amendment-dependent | 30 | "What did Amendment 3 change for Kaiser?" |
| Temporal/timeline | 20 | "How have Sutter's rates changed over 3 years?" |
| Clause search (specific) | 25 | "Find the termination notice period for UCSF" |
| Clause search (thematic) | 15 | "Which providers have DRG-based reimbursement?" |
| Complex/multi-hop | 15 | "If LOS is 45 days at Providence, what's the total reimbursement including stop-loss?" |
| **Total** | **200** | |

### 2.3 Annotation Protocol

```python
RELEVANCE_GUIDELINES = """
For each (query, document) pair, assign a relevance score:

3 = HIGHLY RELEVANT: This document directly answers the query.
    It contains the specific rate, clause, or provision asked about.
    It is from the correct provider, program, and time period.
    
2 = RELEVANT: This document contains useful information for the query.
    It may be the right provider but wrong time period, or
    it provides important context (conditions, exceptions) for the answer.
    
1 = MARGINALLY RELEVANT: This document is topically related but doesn't
    directly answer the query. It might be about the same service line
    but a different provider, or a general section that mentions the topic.
    
0 = NOT RELEVANT: This document does not help answer the query.

SPECIAL ANNOTATIONS:
- Mark 'is_authoritative=True' for the single best source document
- Mark 'is_current=True' only if the document has not been superseded
- Mark 'state_matters=True' if the query requires distinguishing current vs superseded
"""
```

---

## 3. RETRIEVAL METRICS

### 3.1 Standard IR Metrics

```python
def compute_retrieval_metrics(retrieved: List[str], 
                              judgments: List[RelevanceJudgment],
                              k_values: List[int] = [1, 3, 5, 10]) -> Dict:
    """Compute standard information retrieval metrics."""
    relevant_ids = {j.unit_id for j in judgments if j.relevance >= 2}
    
    metrics = {}
    
    for k in k_values:
        top_k = retrieved[:k]
        
        # Precision@K: what fraction of retrieved docs are relevant?
        precision = len(set(top_k) & relevant_ids) / k
        metrics[f'precision@{k}'] = precision
        
        # Recall@K: what fraction of relevant docs are retrieved?
        recall = len(set(top_k) & relevant_ids) / max(len(relevant_ids), 1)
        metrics[f'recall@{k}'] = recall
    
    # MRR: reciprocal rank of first relevant result
    for rank, doc_id in enumerate(retrieved, 1):
        if doc_id in relevant_ids:
            metrics['mrr'] = 1.0 / rank
            break
    else:
        metrics['mrr'] = 0.0
    
    # NDCG@K: normalized discounted cumulative gain
    for k in k_values:
        dcg = sum(
            judgments_map.get(retrieved[i], 0) / np.log2(i + 2)
            for i in range(min(k, len(retrieved)))
        )
        ideal = sorted([j.relevance for j in judgments], reverse=True)[:k]
        idcg = sum(ideal[i] / np.log2(i + 2) for i in range(len(ideal)))
        metrics[f'ndcg@{k}'] = dcg / max(idcg, 1e-10)
    
    return metrics
```

### 3.2 Legal-Specific Metrics

```python
def compute_legal_metrics(retrieved: List[ScoredChunk],
                          judgments: List[RelevanceJudgment],
                          query: EvaluationQuery) -> Dict:
    """Metrics specific to legal contract retrieval."""
    metrics = {}
    
    # STATE PRECISION: of results marked "current", what % actually are?
    current_retrieved = [c for c in retrieved[:5] if c.state.is_current]
    truly_current = [c for c in current_retrieved 
                     if judgments_map[c.unit_id].is_current]
    metrics['state_precision'] = (
        len(truly_current) / max(len(current_retrieved), 1)
    )
    
    # SCOPE PURITY: are all top-5 results from the correct provider?
    if query.expected_providers:
        correct_provider = [c for c in retrieved[:5] 
                           if c.provider_id in query.expected_provider_ids]
        metrics['scope_purity@5'] = len(correct_provider) / min(5, len(retrieved))
    
    # AUTHORITY RANK: where does the authoritative source rank?
    authoritative_ids = {j.unit_id for j in judgments if j.is_authoritative}
    for rank, chunk in enumerate(retrieved, 1):
        if chunk.unit_id in authoritative_ids:
            metrics['authority_rank'] = rank
            break
    else:
        metrics['authority_rank'] = float('inf')
    
    # AMENDMENT AWARENESS: for amendment-dependent queries, is the latest version retrieved?
    if query.requires_amendment_awareness:
        latest_amendment_retrieved = any(
            c.metadata.get('document_type') == 'amendment' 
            and c.state.is_current
            for c in retrieved[:5]
        )
        metrics['amendment_awareness'] = 1.0 if latest_amendment_retrieved else 0.0
    
    # COMPLETENESS: for multi-hop queries, are all required pieces present?
    if query.complexity == 'MULTI_HOP':
        required = set(query.relevant_units_authoritative)
        found = set(c.unit_id for c in retrieved[:10])
        metrics['completeness'] = len(required & found) / max(len(required), 1)
    
    return metrics
```

### 3.3 Faithfulness Metrics

```python
def compute_faithfulness_metrics(answer: str, citations: List[ExtractedCitation],
                                  verification_result: VerificationResult) -> Dict:
    """Metrics for answer faithfulness to source evidence."""
    metrics = {}
    
    # CITATION COVERAGE: % of factual claims that are cited
    total_factual = count_factual_sentences(answer)
    metrics['citation_coverage'] = len(citations) / max(total_factual, 1)
    
    # FAITHFULNESS RATE: % of citations verified as faithful
    verified = sum(1 for c in citations if c.is_faithful)
    metrics['faithfulness_rate'] = verified / max(len(citations), 1)
    
    # HALLUCINATION RATE: % of claims with no supporting evidence
    unsupported = sum(1 for c in citations if c.support_strength < 0.3)
    metrics['hallucination_rate'] = unsupported / max(len(citations), 1)
    
    # NUMERICAL ACCURACY: % of numbers matching source exactly
    num_claims = extract_numeric_claims(answer)
    num_correct = sum(1 for nc in num_claims if nc.verified_correct)
    metrics['numerical_accuracy'] = num_correct / max(len(num_claims), 1)
    
    # CONDITIONAL PRESERVATION: % of cited clauses where conditions are included
    metrics['conditional_preservation'] = (
        verification_result.conditions_preserved_count / 
        max(verification_result.conditions_total_count, 1)
    )
    
    return metrics
```

---

## 4. ONLINE TELEMETRY

### 4.1 Per-Query Telemetry Record

```sql
CREATE TABLE IF NOT EXISTS dev_adb.raw.tbl_retrieval_telemetry (
    -- Identity
    query_id                STRING NOT NULL COMMENT 'Unique query identifier (UUID)',
    session_id              STRING COMMENT 'User session for multi-turn tracking',
    timestamp               TIMESTAMP NOT NULL COMMENT 'When query was processed',
    
    -- Query properties
    query_text              STRING COMMENT 'Raw user query (anonymized if needed)',
    intent                  STRING COMMENT 'Classified intent: RATE_LOOKUP | CLAUSE_SEARCH | ...',
    entity_count            INT COMMENT 'Number of entities extracted from query',
    
    -- Retrieval metrics
    semantic_results        INT COMMENT 'Results from semantic channel',
    lexical_results         INT COMMENT 'Results from lexical channel',
    metadata_results        INT COMMENT 'Results from metadata channel',
    structural_results      INT COMMENT 'Results from structural channel',
    fused_candidates        INT COMMENT 'Total unique candidates after fusion',
    final_results           INT COMMENT 'Results after reranking + diversity',
    
    -- Score distributions
    top1_final_score        FLOAT COMMENT 'Final score of top-ranked result',
    top5_avg_score          FLOAT COMMENT 'Average score of top-5 results',
    score_gap_1_2           FLOAT COMMENT 'Score gap between rank 1 and 2 (confidence signal)',
    
    -- State awareness
    current_pct_top5        FLOAT COMMENT '% of top-5 results that are current (not superseded)',
    amendment_enriched      BOOLEAN COMMENT 'Whether amendment context was added',
    
    -- Verification
    citation_count          INT COMMENT 'Number of citations in generated answer',
    faithful_citation_pct   FLOAT COMMENT '% of citations verified faithful',
    violations_critical     INT COMMENT 'Critical faithfulness violations detected',
    confidence_score        FLOAT COMMENT 'Calibrated confidence of final answer',
    was_remediated          BOOLEAN COMMENT 'Whether answer required remediation',
    
    -- Performance
    retrieval_latency_ms    INT COMMENT 'Time for retrieval fusion (4 channels)',
    reranking_latency_ms    INT COMMENT 'Time for reranking pipeline',
    verification_latency_ms INT COMMENT 'Time for faithfulness verification',
    total_latency_ms        INT COMMENT 'Total end-to-end latency',
    
    -- Feedback (when available)
    user_feedback           STRING COMMENT 'thumbs_up | thumbs_down | NULL',
    feedback_detail         STRING COMMENT 'User-provided correction or comment'
) USING DELTA
COMMENT 'Per-query retrieval telemetry for monitoring, evaluation, and improvement.'
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'delta.columnMapping.mode' = 'name'
);
```

### 4.2 Aggregated Monitoring Views

```sql
-- Daily retrieval health dashboard
CREATE OR REPLACE VIEW dev_adb.raw.v_retrieval_health_daily AS
SELECT
    DATE(timestamp) AS query_date,
    COUNT(*) AS total_queries,
    
    -- Quality
    AVG(faithful_citation_pct) AS avg_faithfulness,
    AVG(confidence_score) AS avg_confidence,
    SUM(CASE WHEN violations_critical > 0 THEN 1 ELSE 0 END) AS queries_with_critical_violations,
    AVG(current_pct_top5) AS avg_state_correctness,
    
    -- Performance
    PERCENTILE(total_latency_ms, 0.5) AS p50_latency_ms,
    PERCENTILE(total_latency_ms, 0.95) AS p95_latency_ms,
    
    -- Coverage
    AVG(final_results) AS avg_results_returned,
    SUM(CASE WHEN final_results = 0 THEN 1 ELSE 0 END) AS zero_result_queries,
    
    -- User satisfaction
    SUM(CASE WHEN user_feedback = 'thumbs_up' THEN 1 ELSE 0 END) AS positive_feedback,
    SUM(CASE WHEN user_feedback = 'thumbs_down' THEN 1 ELSE 0 END) AS negative_feedback

FROM dev_adb.raw.tbl_retrieval_telemetry
GROUP BY DATE(timestamp);
```

---

## 5. OFFLINE EVALUATION HARNESS

### 5.1 Regression Test Suite

```python
def run_regression_suite(config: RetrievalConfig) -> EvaluationReport:
    """
    Run full evaluation suite against golden query set.
    Used before deploying retrieval changes.
    """
    golden_queries = load_golden_queries()  # 200+ annotated queries
    results = []
    
    for query in golden_queries:
        # Run retrieval pipeline with current config
        parsed = understand_query(query.query_text)
        retrieved = retrieve_all_channels(parsed)
        reranked = rerank(retrieved, parsed)
        
        # Compute metrics
        retrieval_metrics = compute_retrieval_metrics(
            retrieved=[c.unit_id for c in reranked],
            judgments=query.relevant_units
        )
        legal_metrics = compute_legal_metrics(reranked, query.relevant_units, query)
        
        results.append(QueryResult(
            query_id=query.query_id,
            metrics={**retrieval_metrics, **legal_metrics},
            latency_ms=elapsed
        ))
    
    # Aggregate
    report = EvaluationReport(
        timestamp=datetime.now(),
        config_hash=hash(config),
        aggregate_metrics=aggregate(results),
        per_intent_metrics=aggregate_by_intent(results),
        regressions=detect_regressions(results, baseline),
        improvements=detect_improvements(results, baseline)
    )
    
    return report
```

### 5.2 A/B Testing Framework

```python
def evaluate_ab(config_a: RetrievalConfig, config_b: RetrievalConfig,
                query_set: List[EvaluationQuery]) -> ABTestResult:
    """
    Compare two retrieval configurations head-to-head.
    Used for evaluating reranking weight changes, new signals, etc.
    """
    results_a = [run_single(q, config_a) for q in query_set]
    results_b = [run_single(q, config_b) for q in query_set]
    
    # Paired comparison
    wins_a, wins_b, ties = 0, 0, 0
    for ra, rb in zip(results_a, results_b):
        if ra.ndcg5 > rb.ndcg5 + 0.01:  # Significance threshold
            wins_a += 1
        elif rb.ndcg5 > ra.ndcg5 + 0.01:
            wins_b += 1
        else:
            ties += 1
    
    # Statistical significance
    p_value = binomial_test(wins_b, wins_a + wins_b, 0.5)
    
    return ABTestResult(
        config_a_wins=wins_a,
        config_b_wins=wins_b,
        ties=ties,
        p_value=p_value,
        significant=p_value < 0.05,
        recommendation='B' if wins_b > wins_a and p_value < 0.05 else 'A'
    )
```

---

## 6. ALERTING & QUALITY GATES

### 6.1 Automated Alerts

| Metric | Warning Threshold | Critical Threshold | Action |
| --- | --- | --- | --- |
| Daily faithfulness rate | <85% | <75% | Page on-call, investigate LLM drift |
| Daily hallucination rate | >5% | >10% | Block deployment, review retrieval coverage |
| p95 latency | >5s | >10s | Scale compute, check VS index health |
| Zero-result rate | >5% | >15% | Expand index coverage, check query understanding |
| Negative feedback rate | >10% | >20% | Review flagged queries, update evaluation set |
| Confidence ECE | >0.12 | >0.20 | Recalibrate confidence model |
| State precision | <90% | <80% | Re-run supersession engine, check amendment links |

### 6.2 Deployment Quality Gate

```python
def check_deployment_gate(new_config: RetrievalConfig,
                          baseline: EvaluationReport) -> bool:
    """
    Must pass before any retrieval config change goes to production.
    
    Rules:
    1. No NDCG@5 regression > 3% on any intent category
    2. No state_precision regression > 5%
    3. No latency p95 increase > 50%
    4. Overall faithfulness >= 85%
    5. Zero regressions on CRITICAL-tagged queries
    """
    new_report = run_regression_suite(new_config)
    
    # Check each gate
    gates = [
        new_report.ndcg5 >= baseline.ndcg5 - 0.03,
        new_report.state_precision >= baseline.state_precision - 0.05,
        new_report.p95_latency <= baseline.p95_latency * 1.5,
        new_report.faithfulness >= 0.85,
        new_report.critical_regressions == 0,
    ]
    
    if all(gates):
        log.info("✅ Deployment gate PASSED")
        return True
    else:
        failed = [i for i, g in enumerate(gates) if not g]
        log.error(f"❌ Deployment gate FAILED on checks: {failed}")
        return False
```

---

## 7. CONTINUOUS IMPROVEMENT LOOP

```
┌─────────────────────────────────────────────────────────────────┐
│                                                                   │
│  Production Queries → Telemetry → Anomaly Detection              │
│        │                                    │                    │
│        ▼                                    ▼                    │
│  User Feedback ──────────────────▶ Query Pool for Annotation     │
│                                            │                    │
│                                            ▼                    │
│                                    Human Annotation              │
│                                    (weekly batch)                │
│                                            │                    │
│                                            ▼                    │
│  Golden Query Set ◀──── Add Annotated Queries (expand coverage) │
│        │                                                         │
│        ▼                                                         │
│  Run Regression Suite ──▶ Identify Weaknesses ──▶ Fix & Deploy  │
│                                                                   │
└─────────────────────────────────────────────────────────────────┘
```

### 7.1 Annotation Priority Queue

```python
def prioritize_for_annotation(telemetry: DataFrame) -> List[str]:
    """
    Select queries from production for human annotation.
    Priority: queries where the system is least confident or got negative feedback.
    """
    candidates = telemetry.filter(
        (col('confidence_score') < 0.6) |           # Low confidence
        (col('user_feedback') == 'thumbs_down') |   # Negative feedback
        (col('violations_critical') > 0) |          # Had violations
        (col('final_results') < 3)                  # Low retrieval coverage
    ).orderBy(
        col('confidence_score').asc()               # Least confident first
    ).limit(50)  # Annotate 50 per week
    
    return candidates.select('query_id', 'query_text').collect()
```

---

## 8. IMPLEMENTATION TIMELINE

| Week | Deliverable | Effort |
| --- | --- | --- |
| 1 | Telemetry table + online logging (every query) | 2 days |
| 2 | Golden query set v1 (50 queries, human-annotated) | 3 days |
| 3 | Offline harness + standard IR metrics | 2 days |
| 4 | Legal-specific metrics + state evaluation | 2 days |
| 5 | Faithfulness metrics + integration with verification | 2 days |
| 6 | Monitoring dashboard + alerting rules | 1 day |
| 7 | Deployment quality gate + A/B framework | 2 days |
| 8 | Expand golden set to 200 queries | 3 days |

---

*The evaluation framework closes the loop: you cannot claim enterprise-grade retrieval without continuous, automated measurement against human-verified ground truth. Every other component in this architecture — reranking, citation verification, confidence calibration — depends on this framework to prove it works and detect when it doesn't.*
