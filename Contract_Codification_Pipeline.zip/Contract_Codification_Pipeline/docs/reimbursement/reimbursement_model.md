# REIMBURSEMENT MODEL V2
## Enterprise-Grade Financial Intelligence Data Architecture

**Document Class:** Data Model Specification  
**Date:** 2026-05-22  
**Scope:** Replace lossy flat rate tables with computable reimbursement logic  
**Validation Basis:** Analysis of JSON_SCHEMA (05_llm_extraction.py), 08_build_rates.py, 13_build_serving.py  

---

## 1. CURRENT MODEL DEFICIENCIES (Verified)

### 1.1 Lossy Flattening

The current model stores ONE number per rate line (`rate_numeric`). Real healthcare reimbursement is compound:

| Contract Language | Current Representation | Information Lost |
| --- | --- | --- |
| "88.9% of charges, capped at $4,200" | rate_numeric=4200 | The 88.9% base formula |
| "$1,500/day + stop-loss at $75K" | rate_numeric=1500 | Stop-loss linkage |
| "Lesser of: charges, Medicare, or contracted rate" | lesser_of_language=TRUE (boolean) | Which rate to compare against |
| "3% annual escalator on Year 1 base" | Separate rows per year (disconnected) | The escalation formula itself |
| "Per diem UNLESS LOS < 1 day, then case rate" | rate_numeric=per_diem_value | Conditional logic and alternative |
| "DRG weight × $6,500 base rate" | formula="DRG × $6,500" (text only) | Not computable — string field |
| "Implants > $10K billed at cost + 10%" | threshold_numeric=10000 | The cost+markup formula |

### 1.2 Non-Computable Logic

Current `formula` column is a **free-text string** (e.g., `"CF=1.4 x Multiplier=0.95"`). It cannot be:
- Evaluated programmatically
- Used in scenario modeling
- Compared across providers
- Used for adjudication simulation

### 1.3 Missing Dimensions

| Dimension | Current State | Impact |
| --- | --- | --- |
| Reimbursement conditions | Not captured | Cannot determine WHEN a rate applies |
| Rate applicability constraints | Flat program/network columns | No LOS triggers, volume thresholds |
| Compound rate components | Single rate_numeric | Loses percentage+cap, per-diem+stop-loss linkage |
| Escalator formulas | Isolated year-N columns in capitation | Cannot project Year 5+ rates |
| Carve-out relationships | Not linked to base rates | Implant/drug exceptions disconnected from per diem |
| DRG logic | Not represented | Cannot model DRG-weighted reimbursement |
| Lesser-of comparators | Boolean flag | Cannot compute which rate wins |

### 1.4 Incorrect Abstractions

- **Stop-loss as "1 row per facility"** (13_build_serving): Real contracts have per-diem stop-loss, case-rate stop-loss, aggregate stop-loss, and corridor provisions — all with different thresholds
- **Capitation as flat PMPM** (tbl_serving_capitation_card): Loses multi-year escalation, risk-sharing tiers, supplemental payments, retroactive adjustment rules
- **Outpatient as single rate** (tbl_serving_outpatient_card): Loses surgical tier progression, percentage-of-charges + cap combinations, revenue code restrictions

---

## 2. V2 DATA MODEL: COMPUTABLE REIMBURSEMENT

### 2.1 Design Philosophy

```
Current: rate_table(provider, category, service, rate_numeric)
    → "Provider X pays $1,500/day for Med/Surg"

V2:     rate_rule(provider, rule_components[], conditions[], applicability[])
    → "Provider X pays the LESSER OF:
         (a) $1,500/day for Med/Surg
         (b) 85% of charges
       WHEN: LOS > 0 days, Network = HMO, Program = Commercial
       WITH: Stop-loss at $75,000 (reimburse at $900/day beyond)
       SUBJECT TO: 3% annual escalator from 2023-01-01 base"
```

### 2.2 Core Entity: Rate Rule

A **Rate Rule** is the atomic unit of reimbursement logic. It has:
1. **Formula** — how to compute the payment amount
2. **Conditions** — when this rule applies (LOS, diagnosis, service type)
3. **Applicability** — which programs/networks/providers
4. **Modifiers** — stop-loss, carve-outs, escalators that alter the base
5. **Precedence** — when multiple rules could apply, which wins

### 2.3 Formula Representation

Instead of a text string, formulas are structured as **expression trees**:

```json
{
  "formula_type": "LESSER_OF",
  "operands": [
    {
      "formula_type": "PER_DIEM",
      "base_rate": 1500.00,
      "unit": "day"
    },
    {
      "formula_type": "PERCENTAGE",
      "percentage": 85.0,
      "of": "BILLED_CHARGES"
    }
  ]
}
```

Supported formula types:
- `FIXED` — flat amount ($5,000 per case)
- `PER_DIEM` — daily rate × LOS
- `PERCENTAGE` — % of charges/Medicare/fee-schedule
- `DRG_WEIGHTED` — base rate × DRG weight
- `CONVERSION_FACTOR` — RVU × conversion factor × geographic multiplier
- `TIERED` — rate changes based on volume/threshold
- `LESSER_OF` — minimum of N sub-formulas
- `GREATER_OF` — maximum of N sub-formulas
- `COMPOUND` — sum of components (base + add-ons)
- `PERCENTAGE_PLUS_CAP` — % of charges capped at dollar maximum
- `ESCALATED` — base formula × (1 + escalator)^years

---

## 3. TABLE ARCHITECTURE

### 3.1 tbl_reimb_rate_rules (Master Rate Rules)

```sql
CREATE TABLE dev_adb.raw.tbl_reimb_rate_rules (
    -- Identity
    rule_id                 STRING NOT NULL,
    contract_id             STRING NOT NULL,
    provider_id             STRING NOT NULL,
    provider_name           STRING NOT NULL,
    
    -- Classification
    rate_domain             STRING NOT NULL,    -- INPATIENT | OUTPATIENT | CAPITATION | PROFESSIONAL
    service_line            STRING NOT NULL,    -- FK to service_line_taxonomy
    service_category_raw    STRING,             -- Original LLM-extracted text
    
    -- Formula (structured, computable)
    formula_type            STRING NOT NULL,    -- FIXED | PER_DIEM | PERCENTAGE | DRG_WEIGHTED | etc.
    formula_json            STRING NOT NULL,    -- Full expression tree as JSON
    
    -- Simplified numeric (backward compatible)
    rate_numeric            FLOAT,             -- Best single-number representation
    rate_text               STRING,            -- Original text
    rate_unit               STRING,            -- day | case | visit | member_month | procedure
    
    -- Applicability
    program                 STRING,            -- Commercial | Medicare | Medi-Cal | All
    network                 STRING,            -- HMO | PPO | All Networks
    revenue_codes           STRING,            -- Comma-separated applicable codes
    procedure_codes         STRING,            -- CPT/HCPCS codes
    drg_codes               STRING,            -- DRG codes if applicable
    
    -- Provenance
    source_filename         STRING NOT NULL,
    exhibit_reference       STRING,
    effective_date          DATE,
    
    -- Modifiers (FKs to modifier tables)
    has_stop_loss           BOOLEAN DEFAULT FALSE,
    has_carve_outs          BOOLEAN DEFAULT FALSE,
    has_escalator           BOOLEAN DEFAULT FALSE,
    has_conditions          BOOLEAN DEFAULT FALSE,
    
    -- Audit
    extracted_at            TIMESTAMP,
    confidence_score        FLOAT             -- How confident the extraction was
) USING DELTA;
```

### 3.2 tbl_reimb_formula_components (Expression Tree Nodes)

```sql
CREATE TABLE dev_adb.raw.tbl_reimb_formula_components (
    -- Identity
    component_id            STRING NOT NULL,
    rule_id                 STRING NOT NULL,   -- FK to rate_rules
    parent_component_id     STRING,            -- NULL for root, FK for children
    
    -- Component type
    component_type          STRING NOT NULL,   -- BASE_RATE | MULTIPLIER | CAP | FLOOR | OPERAND
    operator                STRING,            -- LESSER_OF | GREATER_OF | PLUS | TIMES | MIN | MAX
    
    -- Value (one of these populated depending on component_type)
    fixed_amount            FLOAT,             -- Dollar amount
    percentage              FLOAT,             -- 0-100
    percentage_of           STRING,            -- BILLED_CHARGES | MEDICARE_RATE | FEE_SCHEDULE | CONTRACTED_RATE
    multiplier              FLOAT,             -- Multiplication factor (e.g., DRG weight, geographic factor)
    reference_base          STRING,            -- What this multiplies (e.g., 'DRG_BASE_RATE', 'RVU')
    
    -- Bounds
    cap_amount              FLOAT,             -- Maximum payable
    floor_amount            FLOAT,             -- Minimum payable
    
    -- Position (for ordered operands like LESSER_OF)
    sequence_order          INT DEFAULT 0,
    
    -- Description
    description             STRING             -- Human-readable description of this component
) USING DELTA;
```

### 3.3 tbl_reimb_stop_loss (Multi-Tier Stop-Loss)

```sql
CREATE TABLE dev_adb.raw.tbl_reimb_stop_loss (
    -- Identity
    stop_loss_id            STRING NOT NULL,
    rule_id                 STRING NOT NULL,   -- FK to rate_rules (which base rate this protects)
    contract_id             STRING NOT NULL,
    provider_id             STRING NOT NULL,
    
    -- Stop-loss type
    stop_loss_type          STRING NOT NULL,   -- PER_DIEM | CASE_RATE | AGGREGATE | CORRIDOR
    
    -- Thresholds
    attachment_level        FLOAT,             -- Dollar amount where stop-loss kicks in
    attachment_unit         STRING,            -- TOTAL_CHARGES | TOTAL_DAYS | TOTAL_COST
    
    -- Reimbursement above threshold
    reimburse_formula_type  STRING,            -- FIXED_PER_DIEM | PERCENTAGE | CHARGES_LESS_THRESHOLD
    reimburse_rate          FLOAT,             -- Per-diem rate or percentage above threshold
    reimburse_percentage    FLOAT,             -- If percentage-based (e.g., 80% above threshold)
    
    -- Aggregate provisions
    aggregate_cap           FLOAT,             -- Annual aggregate stop-loss cap
    corridor_amount         FLOAT,             -- Corridor between attachment and coverage
    
    -- Applicability
    applies_to_services     STRING,            -- Which service lines this covers
    revenue_codes           STRING,            -- Revenue codes triggering stop-loss
    
    -- Provenance
    source_filename         STRING NOT NULL,
    exhibit_reference       STRING,
    effective_date          DATE
) USING DELTA;
```

### 3.4 tbl_reimb_carve_outs (Exception Provisions)

```sql
CREATE TABLE dev_adb.raw.tbl_reimb_carve_outs (
    -- Identity
    carve_out_id            STRING NOT NULL,
    contract_id             STRING NOT NULL,
    provider_id             STRING NOT NULL,
    
    -- What's carved out
    carve_out_type          STRING NOT NULL,   -- IMPLANT | DRUG | DEVICE | PROCEDURE | SUPPLY
    description             STRING,
    
    -- Trigger condition
    threshold_amount        FLOAT,             -- Dollar threshold to trigger carve-out
    threshold_type          STRING,            -- PER_ITEM | PER_CASE | PER_DAY
    
    -- Reimbursement for carved-out items
    reimburse_formula_type  STRING NOT NULL,   -- COST_PLUS | PERCENTAGE | FIXED | INVOICE
    reimburse_percentage    FLOAT,             -- E.g., "cost + 10%" → 110%
    reimburse_fixed         FLOAT,             -- Fixed amount if applicable
    reimburse_of            STRING,            -- INVOICE_COST | AWP | WAC | CHARGES
    
    -- Relationship to base rate
    base_rule_id            STRING,            -- FK: which rate rule this carves out FROM
    relationship            STRING,            -- ADDITIONAL_TO | INSTEAD_OF | ABOVE_THRESHOLD
    
    -- Revenue/procedure codes
    revenue_codes           STRING,
    procedure_codes         STRING,
    ndc_codes               STRING,            -- Drug codes for pharmacy carve-outs
    
    -- Provenance
    source_filename         STRING NOT NULL,
    effective_date          DATE
) USING DELTA;
```

### 3.5 tbl_reimb_escalators (Rate Progression)

```sql
CREATE TABLE dev_adb.raw.tbl_reimb_escalators (
    -- Identity
    escalator_id            STRING NOT NULL,
    rule_id                 STRING NOT NULL,   -- FK to rate_rules being escalated
    contract_id             STRING NOT NULL,
    
    -- Escalation type
    escalator_type          STRING NOT NULL,   -- FIXED_PERCENTAGE | CPI_LINKED | STEP_SCHEDULE | FORMULA
    
    -- For FIXED_PERCENTAGE
    annual_increase_pct     FLOAT,             -- E.g., 3.0 for 3% annual increase
    
    -- For CPI_LINKED
    cpi_index               STRING,            -- Which CPI index (e.g., "CPI-U Medical")
    cpi_floor               FLOAT,             -- Minimum increase even if CPI is lower
    cpi_cap                 FLOAT,             -- Maximum increase even if CPI is higher
    
    -- For STEP_SCHEDULE (explicit year-by-year)
    year_1_rate             FLOAT,
    year_1_effective        DATE,
    year_2_rate             FLOAT,
    year_2_effective        DATE,
    year_3_rate             FLOAT,
    year_3_effective        DATE,
    year_4_rate             FLOAT,
    year_4_effective        DATE,
    
    -- Temporal
    base_year_date          DATE,              -- When escalation starts
    escalation_frequency    STRING,            -- ANNUAL | SEMI_ANNUAL | QUARTERLY
    
    -- Provenance
    source_filename         STRING NOT NULL,
    effective_date          DATE
) USING DELTA;
```

### 3.6 tbl_reimb_conditions (Applicability Rules)

```sql
CREATE TABLE dev_adb.raw.tbl_reimb_conditions (
    -- Identity
    condition_id            STRING NOT NULL,
    rule_id                 STRING NOT NULL,   -- FK to rate_rules
    
    -- Condition type
    condition_type          STRING NOT NULL,   -- LOS | DIAGNOSIS | VOLUME | TIMING | SERVICE | AUTHORIZATION
    
    -- Condition expression
    field                   STRING NOT NULL,   -- What's being tested (e.g., 'length_of_stay', 'total_charges')
    operator                STRING NOT NULL,   -- GT | GTE | LT | LTE | EQ | IN | BETWEEN | NOT_IN
    value                   STRING NOT NULL,   -- Threshold value or list
    value_numeric           FLOAT,             -- Numeric representation if applicable
    value_unit              STRING,            -- DAYS | DOLLARS | VISITS | PROCEDURES
    
    -- When condition fails (alternative rule)
    else_rule_id            STRING,            -- FK: which rule applies if THIS condition fails
    else_description        STRING,            -- Human-readable "otherwise"
    
    -- Logic
    condition_group         INT DEFAULT 0,     -- For AND/OR grouping (same group = AND)
    group_operator          STRING DEFAULT 'AND' -- AND | OR between groups
) USING DELTA;
```

### 3.7 tbl_reimb_lesser_of (Comparison Logic)

```sql
CREATE TABLE dev_adb.raw.tbl_reimb_lesser_of (
    -- Identity
    lesser_of_id            STRING NOT NULL,
    rule_id                 STRING NOT NULL,   -- FK to rate_rules
    contract_id             STRING NOT NULL,
    
    -- Comparators (the payment is the MINIMUM of these)
    comparator_1_type       STRING NOT NULL,   -- CONTRACTED_RATE | BILLED_CHARGES | MEDICARE_RATE | FEE_SCHEDULE
    comparator_1_value      FLOAT,             -- NULL if dynamic (e.g., actual charges)
    comparator_2_type       STRING NOT NULL,
    comparator_2_value      FLOAT,
    comparator_3_type       STRING,            -- Optional third comparator
    comparator_3_value      FLOAT,
    
    -- Additional context
    medicare_version        STRING,            -- Which Medicare fee schedule (e.g., "2024 OPPS")
    applies_to_services     STRING,            -- Which services this lesser-of applies to
    
    -- Provenance
    source_filename         STRING NOT NULL,
    effective_date          DATE
) USING DELTA;
```

---

## 4. FORMULA JSON SPECIFICATION

### 4.1 Schema

```json
{
  "$schema": "rate_formula_v2",
  "formula_type": "LESSER_OF | PER_DIEM | PERCENTAGE | DRG_WEIGHTED | ...",
  "operands": [...],          // For composite formulas
  "base_rate": 1500.00,       // For simple formulas
  "unit": "day | case | ...", // What the rate applies to
  "cap": 75000,              // Maximum payment
  "floor": 500,              // Minimum payment
  "conditions": [...]         // Inline conditions (reference to conditions table)
}
```

### 4.2 Examples

**Per diem with stop-loss:**
```json
{
  "formula_type": "PER_DIEM",
  "base_rate": 1500.00,
  "unit": "day",
  "stop_loss": {
    "attachment": 75000,
    "above_attachment": {"formula_type": "PER_DIEM", "base_rate": 900.00, "unit": "day"}
  }
}
```

**Percentage of charges with cap:**
```json
{
  "formula_type": "PERCENTAGE_PLUS_CAP",
  "percentage": 88.9,
  "of": "BILLED_CHARGES",
  "cap": 4200.00
}
```

**DRG-weighted:**
```json
{
  "formula_type": "DRG_WEIGHTED",
  "base_rate": 6500.00,
  "weight_source": "CMS_DRG_WEIGHTS",
  "transfer_policy": "PER_DIEM_PRORATE",
  "outlier_threshold": 50000
}
```

**Lesser-of with three comparators:**
```json
{
  "formula_type": "LESSER_OF",
  "operands": [
    {"formula_type": "FIXED", "amount": 1500.00, "unit": "day"},
    {"formula_type": "PERCENTAGE", "percentage": 85.0, "of": "BILLED_CHARGES"},
    {"formula_type": "REFERENCE", "reference": "MEDICARE_RATE", "version": "2024"}
  ]
}
```

**Conversion factor with geographic adjustment:**
```json
{
  "formula_type": "CONVERSION_FACTOR",
  "conversion_factor": 72.50,
  "multiplied_by": "RVU",
  "geographic_adjustments": [
    {"factor_type": "PRACTICE_EXPENSE", "source": "COUNTY_TABLE"},
    {"factor_type": "MALPRACTICE", "source": "COUNTY_TABLE"}
  ]
}
```

---

## 5. MIGRATION FROM V1

### 5.1 Mapping Rules

| V1 Source | V2 Target | Transformation |
| --- | --- | --- |
| tbl_contract_rates_all.rate_numeric | tbl_reimb_rate_rules.rate_numeric + formula_json | Parse formula field; if empty, create FIXED formula |
| tbl_contract_rates_all.formula | tbl_reimb_formula_components | Parse "CF=X x Multiplier=Y" into structured components |
| tbl_contract_financial_protections | tbl_reimb_stop_loss + tbl_reimb_carve_outs | Split by protection_type |
| tbl_serving_capitation_card | tbl_reimb_rate_rules (domain=CAPITATION) + tbl_reimb_escalators | Link multi-year rates as escalator |
| chargemaster_provisions.lesser_of_language | tbl_reimb_lesser_of | Convert boolean to structured comparators |
| regional_factors | tbl_reimb_formula_components (MULTIPLIER type) | Geographic factors become formula modifiers |

### 5.2 Backward-Compatible View

```sql
CREATE OR REPLACE VIEW dev_adb.raw.tbl_genie_rates_current_reimb AS
SELECT
    rr.provider_name,
    rr.provider_id,
    rr.service_line AS rate_category,
    rr.service_category_raw AS service_category,
    rr.rate_text,
    rr.rate_numeric,
    rr.rate_unit AS rate_type_detail,
    rr.effective_date AS effective_date_parsed,
    rr.formula_json AS formula,
    NULL AS notes,
    rr.revenue_codes,
    rr.program,
    rr.network,
    rr.program AS program_normalized,
    rr.source_filename
FROM dev_adb.raw.tbl_reimb_rate_rules rr
WHERE rr.effective_date IS NOT NULL;  -- Filter as needed
```

---

## 6. WHAT THIS ENABLES

| Capability | V1 (Current) | V2 (Proposed) |
| --- | --- | --- |
| "What's the per diem?" | Returns flat number | Returns full formula with conditions |
| "What if LOS = 45 days?" | Cannot compute | Evaluates per diem + stop-loss trigger |
| "Compare two providers" | Compare rate_numeric | Compare full reimbursement logic |
| "Project Year 3 rates" | Manual lookup | Compute from escalator formula |
| "What does Medicare pay?" | Not in model | Lesser-of comparator evaluation |
| "Implant > $10K?" | Boolean flag | Computes carved-out reimbursement |
| "Scenario: 10% rate increase" | Edit 50 rows manually | Apply multiplier to formula tree |
| "Which rates have DRG logic?" | Cannot identify | Query formula_type = 'DRG_WEIGHTED' |

---

*This model transforms rates from passive lookup values into computable reimbursement logic — the foundation for adjudication simulation, negotiation modeling, and financial scenario analysis.*
