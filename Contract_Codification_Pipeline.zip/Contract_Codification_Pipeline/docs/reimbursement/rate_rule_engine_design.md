# RATE RULE ENGINE DESIGN
## Computable Reimbursement Evaluation Framework

**Document Class:** Engine Architecture Specification  
**Date:** 2026-05-22  
**Scope:** Runtime engine that evaluates rate rules against claim scenarios  

---

## 1. ENGINE PURPOSE

The Rate Rule Engine transforms passive rate data into an **active computation system** that can:
1. **Evaluate** — Given a claim scenario, compute the reimbursement amount
2. **Compare** — Show how two providers would pay differently for the same scenario
3. **Simulate** — "What if we negotiated 5% higher per diem?"
4. **Validate** — Check if a payment matches contracted terms
5. **Project** — Forecast future rates from escalator formulas

---

## 2. CLAIM SCENARIO (Input)

A claim scenario provides the context needed to evaluate reimbursement:

```python
@dataclass
class ClaimScenario:
    """Input to the rate rule engine — describes what happened."""
    # Service identification
    service_line: str              # 'Medical/Surgical', 'ICU/CCU', 'Outpatient Surgery'
    rate_domain: str               # INPATIENT | OUTPATIENT | PROFESSIONAL
    
    # Quantitative
    length_of_stay: int = 1        # Days (for per-diem calculations)
    total_charges: float = 0       # Billed charges (for percentage calculations)
    drg_code: str = None           # DRG code (for DRG-weighted)
    drg_weight: float = 1.0        # DRG relative weight
    rvu_total: float = 0           # Total RVUs (for conversion factor)
    
    # Financial
    implant_cost: float = 0        # Implant/device cost (for carve-out evaluation)
    drug_cost: float = 0           # Drug cost (for pharmacy carve-out)
    supply_cost: float = 0         # Supply cost
    
    # Context
    program: str = 'Commercial'    # Program
    network: str = 'All Networks'  # Network tier
    county: str = None             # For geographic adjustments
    admit_date: date = None        # For temporal applicability
    
    # Optional (for lesser-of evaluation)
    medicare_rate: float = None    # What Medicare would pay
    fee_schedule_rate: float = None # Fee schedule amount
```

---

## 3. ENGINE ARCHITECTURE

```
┌─────────────────────────────────────────────────────────────────┐
│                     RATE RULE ENGINE                              │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  ┌──────────────────┐    ┌──────────────────┐                   │
│  │  RULE MATCHER    │───▶│  FORMULA EVALUATOR│                   │
│  │                  │    │                   │                   │
│  │ Find applicable  │    │ Evaluate formula  │                   │
│  │ rules for this   │    │ expression tree   │                   │
│  │ scenario         │    │ against scenario  │                   │
│  └──────────────────┘    └─────────┬─────────┘                   │
│           │                        │                             │
│           ▼                        ▼                             │
│  ┌──────────────────┐    ┌──────────────────┐                   │
│  │ CONDITION        │    │ MODIFIER CHAIN   │                   │
│  │ EVALUATOR        │    │                  │                   │
│  │                  │    │ Apply:           │                   │
│  │ Check all        │    │ 1. Stop-loss     │                   │
│  │ conditions       │    │ 2. Carve-outs    │                   │
│  │ (LOS, diagnosis, │    │ 3. Lesser-of     │                   │
│  │  volume, timing) │    │ 4. Escalators    │                   │
│  └──────────────────┘    │ 5. Geographic adj│                   │
│                          └─────────┬─────────┘                   │
│                                    │                             │
│                                    ▼                             │
│                          ┌──────────────────┐                   │
│                          │ RESULT BUILDER   │                   │
│                          │                  │                   │
│                          │ Total amount +   │                   │
│                          │ Breakdown +      │                   │
│                          │ Audit trail      │                   │
│                          └──────────────────┘                   │
│                                                                   │
└─────────────────────────────────────────────────────────────────┘
```

---

## 4. RULE MATCHING

### 4.1 Find Applicable Rules

```python
def find_applicable_rules(scenario: ClaimScenario, provider_id: str) -> List[RateRule]:
    """
    Find all rate rules that could apply to this scenario.
    
    Match criteria:
    1. Same provider
    2. Matching rate_domain
    3. Matching service_line (exact or parent)
    4. Compatible program (exact match or 'All')
    5. Compatible network (exact match or 'All Networks')
    6. Valid date range (effective_date <= scenario.admit_date)
    7. All conditions satisfied
    """
    candidates = spark.sql(f"""
        SELECT * FROM tbl_reimb_rate_rules
        WHERE provider_id = '{provider_id}'
          AND rate_domain = '{scenario.rate_domain}'
          AND (service_line = '{scenario.service_line}' 
               OR service_line IN (SELECT parent_line FROM service_line_taxonomy 
                                   WHERE child_line = '{scenario.service_line}'))
          AND (program = '{scenario.program}' OR program = 'All' OR program IS NULL)
          AND (network = '{scenario.network}' OR network = 'All Networks' OR network IS NULL)
          AND (effective_date IS NULL OR effective_date <= '{scenario.admit_date}')
    """).collect()
    
    # Evaluate conditions for each candidate
    applicable = []
    for rule in candidates:
        if evaluate_conditions(rule.rule_id, scenario):
            applicable.append(rule)
    
    return applicable
```

### 4.2 Condition Evaluation

```python
def evaluate_conditions(rule_id: str, scenario: ClaimScenario) -> bool:
    """
    Check if all conditions for a rule are met.
    
    Conditions are AND within a group, OR between groups.
    """
    conditions = get_conditions_for_rule(rule_id)
    if not conditions:
        return True  # No conditions = always applies
    
    # Group conditions by condition_group
    groups = defaultdict(list)
    for cond in conditions:
        groups[cond.condition_group].append(cond)
    
    # All conditions within a group must be TRUE (AND)
    # At least one group must be fully TRUE (OR between groups)
    for group_id, group_conditions in groups.items():
        group_passes = True
        for cond in group_conditions:
            if not evaluate_single_condition(cond, scenario):
                group_passes = False
                break
        if group_passes:
            return True  # At least one group passed
    
    return False  # No group fully passed


def evaluate_single_condition(condition, scenario: ClaimScenario) -> bool:
    """Evaluate one condition against the scenario."""
    # Get the scenario value for the condition field
    value = getattr(scenario, condition.field, None)
    if value is None:
        return True  # Unknown field = don't restrict
    
    threshold = condition.value_numeric or float(condition.value)
    
    OPERATORS = {
        'GT': lambda v, t: v > t,
        'GTE': lambda v, t: v >= t,
        'LT': lambda v, t: v < t,
        'LTE': lambda v, t: v <= t,
        'EQ': lambda v, t: v == t,
        'BETWEEN': lambda v, t: t[0] <= v <= t[1],  # value is "low,high"
    }
    
    op_func = OPERATORS.get(condition.operator)
    if op_func:
        return op_func(value, threshold)
    
    return True  # Unknown operator = don't restrict
```

---

## 5. FORMULA EVALUATION

### 5.1 Expression Tree Evaluator

```python
def evaluate_formula(formula_json: str, scenario: ClaimScenario) -> float:
    """
    Evaluate a formula expression tree against a claim scenario.
    Returns the computed reimbursement amount.
    """
    formula = json.loads(formula_json)
    return _eval_node(formula, scenario)


def _eval_node(node: dict, scenario: ClaimScenario) -> float:
    """Recursively evaluate a formula node."""
    formula_type = node['formula_type']
    
    if formula_type == 'FIXED':
        return node['amount']
    
    elif formula_type == 'PER_DIEM':
        base = node['base_rate']
        days = scenario.length_of_stay
        total = base * days
        # Apply stop-loss if present
        if 'stop_loss' in node:
            sl = node['stop_loss']
            if total > sl['attachment']:
                excess_days = days - int(sl['attachment'] / base)
                above_attachment = _eval_node(sl['above_attachment'], 
                                             ClaimScenario(length_of_stay=excess_days))
                total = sl['attachment'] + above_attachment
        return total
    
    elif formula_type == 'PERCENTAGE':
        pct = node['percentage'] / 100.0
        base_value = _resolve_reference(node['of'], scenario)
        amount = pct * base_value
        # Apply cap if present
        if 'cap' in node and node['cap']:
            amount = min(amount, node['cap'])
        return amount
    
    elif formula_type == 'PERCENTAGE_PLUS_CAP':
        pct = node['percentage'] / 100.0
        base_value = _resolve_reference(node.get('of', 'BILLED_CHARGES'), scenario)
        return min(pct * base_value, node['cap'])
    
    elif formula_type == 'DRG_WEIGHTED':
        base = node['base_rate']
        weight = scenario.drg_weight
        return base * weight
    
    elif formula_type == 'CONVERSION_FACTOR':
        cf = node['conversion_factor']
        rvu = scenario.rvu_total
        geo_adj = 1.0
        for adj in node.get('geographic_adjustments', []):
            geo_adj *= _get_geographic_factor(adj, scenario.county)
        return cf * rvu * geo_adj
    
    elif formula_type == 'LESSER_OF':
        values = [_eval_node(op, scenario) for op in node['operands']]
        return min(v for v in values if v is not None and v > 0)
    
    elif formula_type == 'GREATER_OF':
        values = [_eval_node(op, scenario) for op in node['operands']]
        return max(v for v in values if v is not None)
    
    elif formula_type == 'COMPOUND':
        return sum(_eval_node(op, scenario) for op in node['operands'])
    
    elif formula_type == 'ESCALATED':
        base_amount = _eval_node(node['base_formula'], scenario)
        years = _years_since(node['base_year_date'], scenario.admit_date)
        escalator = node['annual_increase_pct'] / 100.0
        return base_amount * ((1 + escalator) ** years)
    
    elif formula_type == 'REFERENCE':
        return _resolve_reference(node['reference'], scenario)
    
    else:
        return node.get('amount', 0)


def _resolve_reference(reference: str, scenario: ClaimScenario) -> float:
    """Resolve a reference to an actual value from the scenario."""
    REFS = {
        'BILLED_CHARGES': scenario.total_charges,
        'MEDICARE_RATE': scenario.medicare_rate or 0,
        'FEE_SCHEDULE': scenario.fee_schedule_rate or 0,
        'CONTRACTED_RATE': None,  # Circular — handled by caller
    }
    return REFS.get(reference, 0) or 0
```

---

## 6. MODIFIER CHAIN

### 6.1 Stop-Loss Application

```python
def apply_stop_loss(base_amount: float, rule_id: str, scenario: ClaimScenario) -> float:
    """Apply stop-loss provisions to a computed base amount."""
    stop_losses = get_stop_loss_for_rule(rule_id)
    
    for sl in stop_losses:
        if sl.stop_loss_type == 'PER_DIEM' and scenario.length_of_stay > 0:
            per_diem_amount = base_amount / scenario.length_of_stay
            if base_amount > sl.attachment_level:
                # Reimburse excess at stop-loss rate
                excess = base_amount - sl.attachment_level
                if sl.reimburse_formula_type == 'FIXED_PER_DIEM':
                    excess_days = excess / per_diem_amount
                    base_amount = sl.attachment_level + (excess_days * sl.reimburse_rate)
                elif sl.reimburse_formula_type == 'PERCENTAGE':
                    base_amount = sl.attachment_level + (excess * sl.reimburse_percentage / 100)
        
        elif sl.stop_loss_type == 'AGGREGATE':
            # Aggregate stop-loss caps total annual payments
            if sl.aggregate_cap and base_amount > sl.aggregate_cap:
                base_amount = sl.aggregate_cap
    
    return base_amount
```

### 6.2 Carve-Out Evaluation

```python
def evaluate_carve_outs(base_amount: float, rule_id: str, scenario: ClaimScenario) -> tuple:
    """
    Evaluate carve-outs and return (adjusted_base, carve_out_additions).
    
    Carve-outs add payments ABOVE the base rate for specific items.
    """
    carve_outs = get_carve_outs_for_contract(rule_id)
    additions = []
    
    for co in carve_outs:
        triggered = False
        item_cost = 0
        
        if co.carve_out_type == 'IMPLANT' and scenario.implant_cost > 0:
            if scenario.implant_cost > (co.threshold_amount or 0):
                triggered = True
                item_cost = scenario.implant_cost
        elif co.carve_out_type == 'DRUG' and scenario.drug_cost > 0:
            if scenario.drug_cost > (co.threshold_amount or 0):
                triggered = True
                item_cost = scenario.drug_cost
        
        if triggered:
            if co.reimburse_formula_type == 'COST_PLUS':
                # Cost + markup (e.g., invoice + 10%)
                reimbursement = item_cost * (co.reimburse_percentage / 100)
            elif co.reimburse_formula_type == 'PERCENTAGE':
                reimbursement = item_cost * (co.reimburse_percentage / 100)
            elif co.reimburse_formula_type == 'FIXED':
                reimbursement = co.reimburse_fixed
            else:
                reimbursement = item_cost  # Invoice/actual cost
            
            additions.append({
                'type': co.carve_out_type,
                'item_cost': item_cost,
                'reimbursement': reimbursement,
                'formula': co.reimburse_formula_type,
                'description': co.description
            })
    
    total_additions = sum(a['reimbursement'] for a in additions)
    return base_amount, total_additions, additions
```

---

## 7. RESULT STRUCTURE

```python
@dataclass
class ReimbursementResult:
    """Complete output of the rate rule engine."""
    # Core result
    total_reimbursement: float         # Final computed payment
    
    # Breakdown
    base_amount: float                  # Before modifiers
    stop_loss_adjustment: float         # Reduction from stop-loss cap
    carve_out_additions: float          # Additional payments for carved-out items
    escalator_adjustment: float         # Amount from rate escalation
    lesser_of_reduction: float          # Reduction from lesser-of comparison
    geographic_adjustment: float        # Multiplier from county factors
    
    # Metadata
    rule_id: str                        # Which rule was applied
    formula_type: str                   # Type of formula used
    confidence: float                   # Extraction confidence
    
    # Audit trail
    computation_steps: List[dict]       # Step-by-step calculation
    applicable_rules: List[str]         # All rules considered
    conditions_evaluated: List[dict]    # Which conditions were checked
    
    # Warnings
    warnings: List[str]                 # E.g., "Stop-loss threshold exceeded"
```

---

## 8. INTELLIGENCE INTEGRATION

### 8.1 Rate Comparison Query

```python
def compare_reimbursement(scenario: ClaimScenario, provider_ids: List[str]) -> DataFrame:
    """Compare how multiple providers would reimburse the same scenario."""
    results = []
    for pid in provider_ids:
        result = evaluate_reimbursement(scenario, pid)
        results.append({
            'provider_id': pid,
            'total': result.total_reimbursement,
            'base': result.base_amount,
            'formula_type': result.formula_type,
            'stop_loss_triggered': result.stop_loss_adjustment != 0,
            'carve_outs': result.carve_out_additions,
        })
    return pd.DataFrame(results).sort_values('total')
```

### 8.2 Negotiation Scenario Modeling

```python
def model_negotiation_scenario(provider_id: str, adjustments: dict) -> dict:
    """
    Model the impact of proposed rate changes.
    
    adjustments = {'per_diem_pct_change': 5.0, 'stop_loss_threshold_change': 10000}
    """
    current_rules = get_rules_for_provider(provider_id)
    
    # Create modified rules
    modified_rules = deep_copy(current_rules)
    for rule in modified_rules:
        if 'per_diem_pct_change' in adjustments:
            rule.rate_numeric *= (1 + adjustments['per_diem_pct_change'] / 100)
            # Update formula_json as well
            formula = json.loads(rule.formula_json)
            if formula['formula_type'] == 'PER_DIEM':
                formula['base_rate'] *= (1 + adjustments['per_diem_pct_change'] / 100)
            rule.formula_json = json.dumps(formula)
    
    # Run scenarios against both current and proposed
    scenarios = generate_representative_scenarios(provider_id)
    current_total = sum(evaluate_formula(r.formula_json, s).total for r, s in zip(current_rules, scenarios))
    proposed_total = sum(evaluate_formula(r.formula_json, s).total for r, s in zip(modified_rules, scenarios))
    
    return {
        'current_annual_estimate': current_total,
        'proposed_annual_estimate': proposed_total,
        'change_amount': proposed_total - current_total,
        'change_pct': (proposed_total - current_total) / current_total * 100
    }
```

---

## 9. PERFORMANCE

| Operation | Expected Latency | Strategy |
| --- | --- | --- |
| Single rule evaluation | < 5ms | In-memory formula parsing |
| Multi-provider comparison (10) | < 100ms | Parallel evaluation |
| Full scenario suite (100 scenarios) | < 2s | Batch with caching |
| Annual projection (5 years) | < 500ms | Escalator formula |
| Network-wide benchmark | < 10s | Pre-materialized aggregates |

---

*The Rate Rule Engine transforms static rate lookups into dynamic reimbursement computation — enabling negotiation modeling, payment validation, and financial forecasting that was impossible with flat rate_numeric values.*
