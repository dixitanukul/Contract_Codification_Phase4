-- ═══════════════════════════════════════════════════════════════════════════════
-- REIMBURSEMENT MODEL V2 — V1 → V2 Data Migration (Part 2 of 5)
-- 
-- Migrates existing V1 data into V2 tables using INSERT INTO ... SELECT.
-- Non-destructive: V1 tables remain unchanged.
-- 
-- Prerequisites: V2_REIMB_01_DDL_tables.sql executed successfully
-- Source tables: tbl_contract_rates_all, tbl_contract_financial_protections,
--               tbl_serving_capitation_card, tbl_genie_rates_current
-- ═══════════════════════════════════════════════════════════════════════════════

-- ─────────────────────────────────────────────────────────────────────────────
-- MIGRATION 1: tbl_contract_rates_all → tbl_reimb_rate_rules
-- Build formula_json from rate_numeric + formula text using rate_category logic
-- ─────────────────────────────────────────────────────────────────────────────
INSERT INTO dev_adb.raw.tbl_reimb_rate_rules (
    rule_id, contract_id, provider_id, provider_name,
    rate_domain, service_line, service_category_raw,
    formula_type, formula_json,
    rate_numeric, rate_text, rate_unit,
    program, network, revenue_codes, procedure_codes, drg_codes,
    source_filename, exhibit_reference, effective_date,
    has_stop_loss, has_carve_outs, has_escalator, has_conditions,
    extracted_at, confidence_score
)
SELECT
    -- Identity
    uuid() AS rule_id,
    sha2(concat_ws('|', r.provider_id, r.source_filename), 256) AS contract_id,
    r.provider_id,
    r.provider_name,

    -- Classification: derive domain from rate_category
    CASE
        WHEN r.rate_category ILIKE '%inpatient%' OR r.rate_category ILIKE '%per_diem%' THEN 'INPATIENT'
        WHEN r.rate_category ILIKE '%outpatient%' OR r.rate_category ILIKE '%ambulatory%' THEN 'OUTPATIENT'
        WHEN r.rate_category ILIKE '%capitation%' OR r.rate_category ILIKE '%pmpm%' THEN 'CAPITATION'
        WHEN r.rate_category ILIKE '%professional%' OR r.rate_category ILIKE '%physician%' THEN 'PROFESSIONAL'
        ELSE 'INPATIENT'
    END AS rate_domain,
    COALESCE(r.service_category, 'Unclassified') AS service_line,
    r.service_category AS service_category_raw,

    -- Formula: build structured JSON from flat fields
    CASE
        WHEN r.formula ILIKE '%DRG%' OR r.formula ILIKE '%drg%weight%' THEN 'DRG_WEIGHTED'
        WHEN r.formula ILIKE '%CF%' OR r.formula ILIKE '%conversion%factor%' THEN 'CONVERSION_FACTOR'
        WHEN r.rate_category ILIKE '%per_diem%' OR r.rate_category ILIKE '%per diem%' THEN 'PER_DIEM'
        WHEN r.formula ILIKE '%percent%' OR r.formula ILIKE '%pct%' OR r.rate_category ILIKE '%pct%' THEN 'PERCENTAGE'
        WHEN r.lesser_of_language = TRUE THEN 'LESSER_OF'
        WHEN r.rate_category ILIKE '%case_rate%' OR r.rate_category ILIKE '%case rate%' THEN 'FIXED'
        WHEN r.rate_category ILIKE '%capitation%' THEN 'FIXED'
        ELSE 'FIXED'
    END AS formula_type,

    -- formula_json: construct expression tree from available data
    CASE
        WHEN r.formula ILIKE '%DRG%' THEN
            concat('{"formula_type":"DRG_WEIGHTED","base_rate":', COALESCE(CAST(r.rate_numeric AS STRING), '0'), ',"weight_source":"CMS_DRG_WEIGHTS"}')
        WHEN r.formula ILIKE '%CF%' THEN
            concat('{"formula_type":"CONVERSION_FACTOR","conversion_factor":', COALESCE(CAST(r.rate_numeric AS STRING), '0'), ',"multiplied_by":"RVU"}')
        WHEN r.rate_category ILIKE '%per_diem%' OR r.rate_category ILIKE '%per diem%' THEN
            concat('{"formula_type":"PER_DIEM","base_rate":', COALESCE(CAST(r.rate_numeric AS STRING), '0'), ',"unit":"day"}')
        WHEN r.formula ILIKE '%percent%' OR r.formula ILIKE '%pct%' THEN
            concat('{"formula_type":"PERCENTAGE","percentage":', COALESCE(CAST(r.rate_numeric AS STRING), '0'), ',"of":"BILLED_CHARGES"}')
        WHEN r.lesser_of_language = TRUE THEN
            concat('{"formula_type":"LESSER_OF","operands":[{"formula_type":"FIXED","amount":', COALESCE(CAST(r.rate_numeric AS STRING), '0'), '},{"formula_type":"REFERENCE","reference":"BILLED_CHARGES"}]}')
        ELSE
            concat('{"formula_type":"FIXED","amount":', COALESCE(CAST(r.rate_numeric AS STRING), '0'), '}')
    END AS formula_json,

    -- Backward-compat fields
    r.rate_numeric,
    r.rate_text,
    CASE
        WHEN r.rate_category ILIKE '%per_diem%' THEN 'day'
        WHEN r.rate_category ILIKE '%capitation%' THEN 'member_month'
        WHEN r.rate_category ILIKE '%case_rate%' THEN 'case'
        ELSE 'case'
    END AS rate_unit,

    -- Applicability
    r.program_normalized AS program,
    r.network,
    r.revenue_codes,
    NULL AS procedure_codes,
    NULL AS drg_codes,

    -- Provenance
    r.source_filename,
    NULL AS exhibit_reference,
    r.effective_date_parsed AS effective_date,

    -- Modifier flags (will be updated after stop-loss/carve-out migration)
    FALSE AS has_stop_loss,
    FALSE AS has_carve_outs,
    FALSE AS has_escalator,
    FALSE AS has_conditions,

    -- Audit
    current_timestamp() AS extracted_at,
    0.7 AS confidence_score  -- V1 migration = moderate confidence

FROM dev_adb.raw.tbl_contract_rates_all r
WHERE r.status = 'current';

-- ─────────────────────────────────────────────────────────────────────────────
-- MIGRATION 2: tbl_contract_financial_protections → tbl_reimb_stop_loss
-- WHERE protection_type contains stop-loss language
-- ─────────────────────────────────────────────────────────────────────────────
INSERT INTO dev_adb.raw.tbl_reimb_stop_loss (
    stop_loss_id, rule_id, contract_id, provider_id,
    stop_loss_type, attachment_level, attachment_unit,
    reimburse_formula_type, reimburse_rate, reimburse_percentage,
    aggregate_cap, corridor_amount,
    applies_to_services, revenue_codes,
    source_filename, exhibit_reference, effective_date
)
SELECT
    uuid() AS stop_loss_id,
    -- Link to best-matching rule (first inpatient rule for this provider)
    COALESCE(
        (SELECT rr.rule_id FROM dev_adb.raw.tbl_reimb_rate_rules rr
         WHERE rr.provider_id = fp.provider_id AND rr.rate_domain = 'INPATIENT'
         LIMIT 1),
        'UNLINKED'
    ) AS rule_id,
    sha2(concat_ws('|', fp.provider_id, fp.source_filename), 256) AS contract_id,
    fp.provider_id,

    -- Classify stop-loss type
    CASE
        WHEN fp.protection_type ILIKE '%per diem%' OR fp.protection_type ILIKE '%per_diem%' THEN 'PER_DIEM'
        WHEN fp.protection_type ILIKE '%aggregate%' OR fp.protection_type ILIKE '%annual%' THEN 'AGGREGATE'
        WHEN fp.protection_type ILIKE '%corridor%' THEN 'CORRIDOR'
        ELSE 'CASE_RATE'
    END AS stop_loss_type,

    fp.threshold_numeric AS attachment_level,
    'TOTAL_CHARGES' AS attachment_unit,

    -- Reimbursement above threshold
    CASE
        WHEN fp.reimbursement_pct_numeric IS NOT NULL THEN 'PERCENTAGE'
        ELSE 'FIXED_PER_DIEM'
    END AS reimburse_formula_type,
    NULL AS reimburse_rate,
    fp.reimbursement_pct_numeric AS reimburse_percentage,

    NULL AS aggregate_cap,
    NULL AS corridor_amount,
    fp.applies_to_services,
    NULL AS revenue_codes,
    fp.source_filename,
    NULL AS exhibit_reference,
    NULL AS effective_date

FROM dev_adb.raw.tbl_contract_financial_protections fp
WHERE fp.protection_type ILIKE '%stop%loss%'
   OR fp.protection_type ILIKE '%outlier%'
   OR fp.protection_type ILIKE '%threshold%';

-- ─────────────────────────────────────────────────────────────────────────────
-- MIGRATION 3: tbl_contract_financial_protections → tbl_reimb_carve_outs
-- WHERE protection_type contains carve-out/implant/drug language
-- ─────────────────────────────────────────────────────────────────────────────
INSERT INTO dev_adb.raw.tbl_reimb_carve_outs (
    carve_out_id, contract_id, provider_id,
    carve_out_type, description,
    threshold_amount, threshold_type,
    reimburse_formula_type, reimburse_percentage, reimburse_fixed, reimburse_of,
    base_rule_id, relationship,
    revenue_codes, procedure_codes, ndc_codes,
    source_filename, effective_date
)
SELECT
    uuid() AS carve_out_id,
    sha2(concat_ws('|', fp.provider_id, fp.source_filename), 256) AS contract_id,
    fp.provider_id,

    -- Classify carve-out type
    CASE
        WHEN fp.protection_type ILIKE '%implant%' THEN 'IMPLANT'
        WHEN fp.protection_type ILIKE '%drug%' OR fp.protection_type ILIKE '%pharm%' THEN 'DRUG'
        WHEN fp.protection_type ILIKE '%device%' THEN 'DEVICE'
        WHEN fp.protection_type ILIKE '%procedure%' THEN 'PROCEDURE'
        ELSE 'SUPPLY'
    END AS carve_out_type,
    fp.reimbursement_text AS description,

    fp.threshold_numeric AS threshold_amount,
    'PER_ITEM' AS threshold_type,

    -- Reimbursement formula
    CASE
        WHEN fp.reimbursement_text ILIKE '%cost%plus%' OR fp.reimbursement_text ILIKE '%cost +%' THEN 'COST_PLUS'
        WHEN fp.reimbursement_pct_numeric IS NOT NULL THEN 'PERCENTAGE'
        WHEN fp.reimbursement_text ILIKE '%invoice%' THEN 'INVOICE'
        ELSE 'COST_PLUS'
    END AS reimburse_formula_type,
    fp.reimbursement_pct_numeric AS reimburse_percentage,
    NULL AS reimburse_fixed,
    'INVOICE_COST' AS reimburse_of,

    NULL AS base_rule_id,
    'ADDITIONAL_TO' AS relationship,
    NULL AS revenue_codes,
    NULL AS procedure_codes,
    NULL AS ndc_codes,
    fp.source_filename,
    NULL AS effective_date

FROM dev_adb.raw.tbl_contract_financial_protections fp
WHERE fp.protection_type ILIKE '%carve%'
   OR fp.protection_type ILIKE '%implant%'
   OR fp.protection_type ILIKE '%drug%'
   OR fp.protection_type ILIKE '%device%';

-- ─────────────────────────────────────────────────────────────────────────────
-- MIGRATION 4: tbl_serving_capitation_card → tbl_reimb_rate_rules (CAPITATION)
--              + tbl_reimb_escalators (link multi-year rates)
-- ─────────────────────────────────────────────────────────────────────────────

-- 4a: Capitation base rates (Year 1 as base rule)
INSERT INTO dev_adb.raw.tbl_reimb_rate_rules (
    rule_id, contract_id, provider_id, provider_name,
    rate_domain, service_line, service_category_raw,
    formula_type, formula_json,
    rate_numeric, rate_text, rate_unit,
    program, network, revenue_codes, procedure_codes, drg_codes,
    source_filename, exhibit_reference, effective_date,
    has_stop_loss, has_carve_outs, has_escalator, has_conditions,
    extracted_at, confidence_score
)
SELECT
    uuid() AS rule_id,
    sha2(concat_ws('|', 'CAPITATION', c.provider_name, c.source_filename), 256) AS contract_id,
    NULL AS provider_id,
    c.provider_name,
    'CAPITATION' AS rate_domain,
    c.aid_category AS service_line,
    c.aid_category AS service_category_raw,
    'FIXED' AS formula_type,
    concat('{"formula_type":"FIXED","amount":', CAST(c.year_1_pmpm AS STRING), ',"unit":"member_month"}') AS formula_json,
    c.year_1_pmpm AS rate_numeric,
    concat('$', CAST(c.year_1_pmpm AS STRING), ' PMPM') AS rate_text,
    'member_month' AS rate_unit,
    'Medi-Cal' AS program,
    'All Networks' AS network,
    NULL AS revenue_codes,
    NULL AS procedure_codes,
    NULL AS drg_codes,
    c.source_filename,
    NULL AS exhibit_reference,
    c.effective_date,
    FALSE, FALSE, TRUE, FALSE,  -- has_escalator = TRUE
    current_timestamp(),
    0.9 AS confidence_score

FROM dev_adb.raw.tbl_serving_capitation_card c;

-- 4b: Escalators from multi-year PMPM rates
INSERT INTO dev_adb.raw.tbl_reimb_escalators (
    escalator_id, rule_id, contract_id,
    escalator_type,
    annual_increase_pct, cpi_index, cpi_floor, cpi_cap,
    year_1_rate, year_1_effective,
    year_2_rate, year_2_effective,
    year_3_rate, year_3_effective,
    year_4_rate, year_4_effective,
    base_year_date, escalation_frequency,
    source_filename, effective_date
)
SELECT
    uuid() AS escalator_id,
    -- Link to matching capitation rule
    COALESCE(
        (SELECT rr.rule_id FROM dev_adb.raw.tbl_reimb_rate_rules rr
         WHERE rr.provider_name = c.provider_name
           AND rr.rate_domain = 'CAPITATION'
           AND rr.service_line = c.aid_category
         LIMIT 1),
        'UNLINKED'
    ) AS rule_id,
    sha2(concat_ws('|', 'CAPITATION', c.provider_name, c.source_filename), 256) AS contract_id,
    'STEP_SCHEDULE' AS escalator_type,

    -- Compute average annual increase
    CASE WHEN c.year_1_pmpm > 0
         THEN ROUND((c.year_4_pmpm / c.year_1_pmpm - 1) / 3 * 100, 2)
         ELSE NULL
    END AS annual_increase_pct,
    NULL AS cpi_index,
    NULL AS cpi_floor,
    NULL AS cpi_cap,

    c.year_1_pmpm AS year_1_rate,
    c.effective_date AS year_1_effective,
    c.year_2_pmpm AS year_2_rate,
    date_add(c.effective_date, 365) AS year_2_effective,
    c.year_3_pmpm AS year_3_rate,
    date_add(c.effective_date, 730) AS year_3_effective,
    c.year_4_pmpm AS year_4_rate,
    date_add(c.effective_date, 1095) AS year_4_effective,

    c.effective_date AS base_year_date,
    'ANNUAL' AS escalation_frequency,
    c.source_filename,
    c.effective_date

FROM dev_adb.raw.tbl_serving_capitation_card c
WHERE c.year_2_pmpm IS NOT NULL;  -- Only create escalator if multi-year

-- ─────────────────────────────────────────────────────────────────────────────
-- MIGRATION 5: tbl_genie_rates_current lesser_of → tbl_reimb_lesser_of
-- Converts boolean lesser_of_language into structured comparator records
-- ─────────────────────────────────────────────────────────────────────────────
INSERT INTO dev_adb.raw.tbl_reimb_lesser_of (
    lesser_of_id, rule_id, contract_id,
    comparator_1_type, comparator_1_value,
    comparator_2_type, comparator_2_value,
    comparator_3_type, comparator_3_value,
    medicare_version, applies_to_services,
    source_filename, effective_date
)
SELECT
    uuid() AS lesser_of_id,
    COALESCE(
        (SELECT rr.rule_id FROM dev_adb.raw.tbl_reimb_rate_rules rr
         WHERE rr.provider_name = g.provider_name
           AND rr.service_category_raw = g.service_category
           AND rr.rate_numeric = g.rate_numeric
         LIMIT 1),
        'UNLINKED'
    ) AS rule_id,
    sha2(concat_ws('|', g.provider_id, g.source_filename), 256) AS contract_id,

    'CONTRACTED_RATE' AS comparator_1_type,
    g.rate_numeric AS comparator_1_value,
    'BILLED_CHARGES' AS comparator_2_type,
    NULL AS comparator_2_value,  -- Dynamic (actual charges)
    'MEDICARE_RATE' AS comparator_3_type,
    NULL AS comparator_3_value,  -- Dynamic (Medicare fee schedule)

    NULL AS medicare_version,
    g.service_category AS applies_to_services,
    g.source_filename,
    g.effective_date_parsed AS effective_date

FROM dev_adb.raw.tbl_genie_rates_current g
WHERE g.rate_text ILIKE '%lesser%of%'
   OR g.formula ILIKE '%lesser%'
   OR g.rate_text ILIKE '%lower%of%';

-- ─────────────────────────────────────────────────────────────────────────────
-- POST-MIGRATION: Update modifier flags on rate_rules
-- ─────────────────────────────────────────────────────────────────────────────
MERGE INTO dev_adb.raw.tbl_reimb_rate_rules AS rr
USING (
    SELECT DISTINCT rule_id FROM dev_adb.raw.tbl_reimb_stop_loss WHERE rule_id != 'UNLINKED'
) AS sl ON rr.rule_id = sl.rule_id
WHEN MATCHED THEN UPDATE SET rr.has_stop_loss = TRUE;

MERGE INTO dev_adb.raw.tbl_reimb_rate_rules AS rr
USING (
    SELECT DISTINCT rule_id FROM dev_adb.raw.tbl_reimb_escalators WHERE rule_id != 'UNLINKED'
) AS esc ON rr.rule_id = esc.rule_id
WHEN MATCHED THEN UPDATE SET rr.has_escalator = TRUE;
