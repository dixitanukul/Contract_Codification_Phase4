-- ═══════════════════════════════════════════════════════════════════════════════
-- REIMBURSEMENT MODEL V2 — Backward-Compatible Views (Part 3 of 5)
-- 
-- 5 views that let existing notebooks (12_build_genie, 13_build_serving)
-- and the Genie Space continue working unchanged against V2 tables.
-- 
-- Prerequisites: V2_REIMB_01_DDL_tables.sql + V2_REIMB_02_migration.sql executed
-- ═══════════════════════════════════════════════════════════════════════════════

-- ─────────────────────────────────────────────────────────────────────────────
-- VIEW 1: v_genie_rates_current_v2
-- Emulates tbl_genie_rates_current column structure from V2 rate_rules
-- Consumers: Genie Space, 12_build_genie, Dashboard
-- ─────────────────────────────────────────────────────────────────────────────
CREATE OR REPLACE VIEW dev_adb.raw.v_genie_rates_current_v2 AS
SELECT
    rr.provider_name,
    rr.provider_id,
    rr.service_line AS rate_category,
    rr.service_category_raw AS service_category,
    rr.rate_text,
    rr.rate_numeric,
    rr.rate_unit AS rate_type_detail,
    rr.effective_date AS effective_date_parsed,
    rr.formula_json AS formula,
    NULL AS notes,
    rr.revenue_codes,
    rr.program AS program_normalized,
    rr.network,
    rr.source_filename
FROM dev_adb.raw.tbl_reimb_rate_rules rr
WHERE rr.effective_date IS NOT NULL;

-- ─────────────────────────────────────────────────────────────────────────────
-- VIEW 2: v_serving_rate_card_v2
-- Emulates tbl_serving_rate_card — the 25-service-line pivot
-- Replaces hardcoded CASE WHEN with taxonomy JOIN
-- Consumers: 13_build_serving, Dashboard
-- ─────────────────────────────────────────────────────────────────────────────
CREATE OR REPLACE VIEW dev_adb.raw.v_serving_rate_card_v2 AS
SELECT
    rr.provider_name,
    rr.provider_id,
    rr.rate_domain,
    t.display_name AS service_line,
    t.comparable_group AS benchmark_group,
    rr.formula_type,
    rr.rate_numeric,
    rr.rate_text,
    rr.rate_unit,
    rr.program AS program_normalized,
    rr.network,
    rr.effective_date,
    rr.source_filename,
    -- Modifier summaries
    rr.has_stop_loss,
    rr.has_carve_outs,
    rr.has_escalator,
    rr.has_conditions,
    -- Formula detail for power users
    rr.formula_json
FROM dev_adb.raw.tbl_reimb_rate_rules rr
LEFT JOIN dev_adb.raw.dim_service_line_taxonomy t
    ON rr.service_line = t.service_line_code
       OR EXISTS (
           SELECT 1 FROM dev_adb.raw.dim_service_line_patterns p
           WHERE p.service_line_id = t.service_line_id
             AND rr.service_category_raw ILIKE p.pattern_value
             AND (p.exclude_pattern IS NULL OR rr.service_category_raw NOT ILIKE p.exclude_pattern)
       )
WHERE rr.rate_domain IN ('INPATIENT', 'OUTPATIENT', 'PROFESSIONAL');

-- ─────────────────────────────────────────────────────────────────────────────
-- VIEW 3: v_serving_stop_loss_v2
-- Emulates tbl_serving_stop_loss with multi-tier detail
-- V1 had MAX(threshold) per facility → V2 exposes all tiers
-- Consumers: 13_build_serving, Dashboard stop-loss widget
-- ─────────────────────────────────────────────────────────────────────────────
CREATE OR REPLACE VIEW dev_adb.raw.v_serving_stop_loss_v2 AS
SELECT
    sl.provider_id,
    rr.provider_name,
    sl.stop_loss_type,
    sl.attachment_level AS threshold_numeric,
    sl.attachment_unit,
    sl.reimburse_formula_type,
    sl.reimburse_rate,
    sl.reimburse_percentage,
    sl.aggregate_cap,
    sl.corridor_amount,
    sl.applies_to_services,
    sl.effective_date,
    sl.source_filename,
    -- Backward-compat: single summary row per provider (MAX threshold)
    MAX(sl.attachment_level) OVER (PARTITION BY sl.provider_id) AS max_threshold_per_provider
FROM dev_adb.raw.tbl_reimb_stop_loss sl
LEFT JOIN dev_adb.raw.tbl_reimb_rate_rules rr
    ON sl.rule_id = rr.rule_id;

-- ─────────────────────────────────────────────────────────────────────────────
-- VIEW 4: v_serving_capitation_v2
-- Emulates tbl_serving_capitation_card with escalator linkage
-- Consumers: 13_build_serving capitation card builder
-- ─────────────────────────────────────────────────────────────────────────────
CREATE OR REPLACE VIEW dev_adb.raw.v_serving_capitation_v2 AS
SELECT
    rr.provider_name,
    rr.service_line AS aid_category,
    rr.rate_numeric AS year_1_pmpm,
    esc.year_2_rate AS year_2_pmpm,
    esc.year_3_rate AS year_3_pmpm,
    esc.year_4_rate AS year_4_pmpm,
    esc.annual_increase_pct,
    esc.escalator_type,
    esc.cpi_index,
    esc.cpi_floor,
    esc.cpi_cap,
    rr.effective_date,
    rr.source_filename,
    rr.formula_json
FROM dev_adb.raw.tbl_reimb_rate_rules rr
LEFT JOIN dev_adb.raw.tbl_reimb_escalators esc
    ON rr.rule_id = esc.rule_id
WHERE rr.rate_domain = 'CAPITATION';

-- ─────────────────────────────────────────────────────────────────────────────
-- VIEW 5: v_rates_with_service_line
-- Rates joined to taxonomy (replaces hardcoded CASE WHEN)
-- Any rate_category → standardized taxonomy display_name + hierarchy
-- Consumers: Any notebook needing classified rates
-- ─────────────────────────────────────────────────────────────────────────────
CREATE OR REPLACE VIEW dev_adb.raw.v_rates_with_service_line AS
SELECT
    r.*,
    COALESCE(t.display_name, 'Unclassified') AS service_line_display,
    COALESCE(t.domain, 'UNKNOWN') AS service_domain,
    COALESCE(t.comparable_group, 'other') AS benchmark_group,
    t.service_line_id,
    t.service_line_code,
    t.level AS taxonomy_level,
    t.parent_id AS taxonomy_parent_id
FROM dev_adb.raw.tbl_contract_rates_all r
LEFT JOIN dev_adb.raw.dim_service_line_taxonomy t
    ON EXISTS (
        SELECT 1 FROM dev_adb.raw.dim_service_line_patterns p
        WHERE p.service_line_id = t.service_line_id
          AND r.service_category ILIKE p.pattern_value
          AND (p.exclude_pattern IS NULL OR r.service_category NOT ILIKE p.exclude_pattern)
    );
