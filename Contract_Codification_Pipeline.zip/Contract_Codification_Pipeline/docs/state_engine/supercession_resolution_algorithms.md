# SUPERCESSION RESOLUTION ALGORITHMS
## Deterministic Rules for Exhibit, Clause, and Section-Level Supersession

**Document Class:** Algorithm Specification  
**Date:** 2026-05-22  
**Scope:** Formal algorithms that replace the current "latest document wins" heuristic  

---

## 1. ALGORITHM OVERVIEW

Supersession resolution executes in 4 passes, each with increasing specificity:

```
Pass 1: DOCUMENT-LEVEL (coarsest)
  └── Does this amendment replace the entire prior agreement?

Pass 2: EXHIBIT-LEVEL
  └── Which specific exhibits does this amendment replace/modify?

Pass 3: RATE-LINE PAIRING (finest for financial data)
  └── Which specific rate lines are superseded by new rate lines?

Pass 4: CLAUSE-LEVEL (finest for legal text)
  └── Which specific clauses/sections are superseded?
```

Each pass produces supersession edges with confidence scores. Higher-specificity passes override lower-specificity conclusions when they conflict.

---

## 2. PASS 1: DOCUMENT-LEVEL SUPERSESSION

### 2.1 Algorithm

```python
def pass1_document_level(amendment: Amendment, contract: Contract) -> List[SupersessionDecision]:
    """
    Determine if amendment performs a FULL replacement of prior agreement.
    
    This is the ONLY case where all prior rates/clauses are superseded.
    Triggers: explicit "replaces and supersedes" language.
    """
    decisions = []
    
    # Check for full replacement signals
    impact = amendment.amendments_impact or {}
    summary = (impact.get('summary_of_changes', '') or '').lower()
    
    FULL_REPLACE_SIGNALS = [
        'replaces and supersedes the',
        'this agreement supersedes all prior',
        'entire agreement is replaced',
        'restated in its entirety',
        'amended and restated agreement',
    ]
    
    is_full_replace = any(signal in summary for signal in FULL_REPLACE_SIGNALS)
    
    # Additional signal: document_type explicitly says "Amended and Restated"
    if 'restated' in (amendment.document_type or '').lower():
        is_full_replace = True
    
    if is_full_replace:
        # Mark ALL prior rates and clauses as superseded
        prior_rates = get_current_rates_for_contract(contract.contract_id)
        for rate in prior_rates:
            decisions.append(SupersessionDecision(
                superseded_fact_id=rate.fact_id,
                superseded_by_amendment=amendment.amendment_id,
                supersession_type='FULL_REPLACEMENT',
                confidence=0.90,
                evidence=f"Full replacement language detected: '{summary[:100]}'"
            ))
    
    return decisions
```

### 2.2 Confidence Calibration

| Signal | Confidence |
| --- | --- |
| Explicit "replaces and supersedes" + "entire agreement" | 0.95 |
| "Amended and restated" in document type | 0.90 |
| "Supersedes all prior" in summary | 0.85 |
| Single signal word without context | 0.60 |

---

## 3. PASS 2: EXHIBIT-LEVEL SUPERSESSION

### 3.1 Algorithm

```python
def pass2_exhibit_level(amendment: Amendment, contract: Contract) -> List[SupersessionDecision]:
    """
    Determine which exhibits are modified/replaced by this amendment.
    
    Source signals:
    1. amendments_impact.exhibits_replaced (explicit)
    2. amendments_impact.exhibits_modified (explicit)
    3. Rate categories present in amendment (inferred)
    4. Section references in amendment text (inferred)
    """
    decisions = []
    impact = amendment.amendments_impact or {}
    
    # ─── Signal 1: Explicit exhibit replacement ───
    exhibits_replaced = impact.get('exhibits_replaced', [])
    if isinstance(exhibits_replaced, str):
        exhibits_replaced = parse_exhibit_list(exhibits_replaced)
    
    for exhibit in exhibits_replaced:
        # Find all current rates/clauses from this exhibit
        exhibit_items = get_items_from_exhibit(contract.contract_id, exhibit)
        for item in exhibit_items:
            decisions.append(SupersessionDecision(
                superseded_fact_id=item.fact_id,
                superseded_by_amendment=amendment.amendment_id,
                supersession_type='EXHIBIT_REPLACE',
                confidence=0.90,
                evidence=f"Exhibit '{exhibit}' explicitly replaced",
                exhibit_reference=exhibit
            ))
    
    # ─── Signal 2: Inferred from rate categories ───
    if not exhibits_replaced:
        amendment_categories = get_rate_categories_in_doc(amendment.source_filename)
        exhibit_map = get_exhibit_category_mapping(contract)
        
        for category in amendment_categories:
            exhibit = exhibit_map.get(category)
            if exhibit:
                prior_rates = get_current_rates_in_category(
                    contract.contract_id, category
                )
                for rate in prior_rates:
                    decisions.append(SupersessionDecision(
                        superseded_fact_id=rate.fact_id,
                        superseded_by_amendment=amendment.amendment_id,
                        supersession_type='EXHIBIT_INFERRED',
                        confidence=0.70,
                        evidence=f"Amendment contains {category} rates; mapped to {exhibit}",
                        exhibit_reference=exhibit
                    ))
    
    return decisions
```

### 3.2 Exhibit-to-Category Mapping

Healthcare contracts have semi-standard exhibit naming:

| Exhibit | Typical Content | Rate Categories |
| --- | --- | --- |
| Exhibit A / Schedule A | General terms and definitions | (clauses only) |
| Exhibit B | Inpatient rates | inpatient_per_diem, inpatient_case_rates |
| Exhibit C | Outpatient rates | outpatient_surgical, outpatient_emergency |
| Exhibit D | Capitation rates | capitation |
| Exhibit E | Stop-loss / reinsurance | financial_protections |
| Exhibit F | Regional factors | regional_factors |

**Discovery:** This mapping is built empirically from the extraction data:
```sql
-- Build exhibit-to-category mapping from base agreements
SELECT 
    contract_id,
    exhibit_reference,
    rate_category,
    COUNT(*) as rate_count
FROM tbl_v2_rate_facts
WHERE amendment_id IS NULL  -- Base agreement only
  AND exhibit_reference IS NOT NULL
GROUP BY contract_id, exhibit_reference, rate_category;
```

### 3.3 Exhibit Identification in Text

```python
EXHIBIT_PATTERNS = [
    r'Exhibit\s+([A-Z](?:-\d+)?)',           # Exhibit B, Exhibit D-1
    r'Schedule\s+([A-Z](?:-\d+)?)',           # Schedule A
    r'Appendix\s+(\d+|[A-Z])',               # Appendix 1, Appendix C
    r'Attachment\s+(\d+|[A-Z])',             # Attachment 2
    r'Rate\s+Schedule\s+(\d+|[A-Z])',        # Rate Schedule 1
]

def parse_exhibit_list(text: str) -> List[str]:
    """Extract exhibit identifiers from free text."""
    exhibits = []
    for pattern in EXHIBIT_PATTERNS:
        matches = re.findall(pattern, text, re.IGNORECASE)
        exhibits.extend([f"Exhibit {m}" for m in matches])
    return list(set(exhibits))
```

---

## 4. PASS 3: RATE-LINE PAIRING

### 4.1 Algorithm

```python
def pass3_rate_line_pairing(amendment: Amendment, contract: Contract) -> List[SupersessionDecision]:
    """
    Pair individual rate lines from amendment with their predecessors.
    
    Identity matching: two rates are "the same rate" if they match on:
    - rate_category (exact)
    - service_category (fuzzy, normalized)
    - program (normalized to 8 canonical buckets)
    
    Rate VALUE is NOT part of identity — it's what changes between versions.
    """
    decisions = []
    
    # Get rates introduced by this amendment
    new_rates = get_rates_from_amendment(amendment)
    
    # Get currently-active rates for this contract
    current_rates = get_current_rates_for_contract(contract.contract_id)
    
    for new_rate in new_rates:
        # Find matching predecessor
        candidates = find_rate_predecessors(new_rate, current_rates)
        
        if len(candidates) == 1:
            # Clear 1:1 match
            decisions.append(SupersessionDecision(
                superseded_fact_id=candidates[0].fact_id,
                superseding_fact_id=new_rate.fact_id,
                superseded_by_amendment=amendment.amendment_id,
                supersession_type='RATE_PAIR_EXACT',
                confidence=0.90,
                evidence=f"Exact match: {new_rate.rate_category}/{new_rate.service_category}"
            ))
        elif len(candidates) > 1:
            # Multiple candidates — use narrower matching
            best = disambiguate_rate_match(new_rate, candidates)
            if best:
                decisions.append(SupersessionDecision(
                    superseded_fact_id=best.fact_id,
                    superseding_fact_id=new_rate.fact_id,
                    superseded_by_amendment=amendment.amendment_id,
                    supersession_type='RATE_PAIR_FUZZY',
                    confidence=0.75,
                    evidence=f"Fuzzy match (disambiguated from {len(candidates)} candidates)"
                ))
            else:
                # Cannot determine — flag for review
                decisions.append(SupersessionDecision(
                    superseded_fact_id=None,
                    superseding_fact_id=new_rate.fact_id,
                    superseded_by_amendment=amendment.amendment_id,
                    supersession_type='RATE_NEW_OR_AMBIGUOUS',
                    confidence=0.50,
                    evidence=f"Ambiguous: {len(candidates)} candidates, cannot disambiguate",
                    needs_review=True
                ))
        else:
            # No predecessor — this is a genuinely new rate
            decisions.append(SupersessionDecision(
                superseded_fact_id=None,
                superseding_fact_id=new_rate.fact_id,
                superseded_by_amendment=amendment.amendment_id,
                supersession_type='RATE_NEW',
                confidence=0.85,
                evidence="No matching predecessor found — new rate line"
            ))
    
    return decisions


def find_rate_predecessors(new_rate, current_rates) -> List[RateFact]:
    """
    Find predecessor rates using multi-level matching.
    
    Level 1: Exact match (category + service_normalized + program_normalized)
    Level 2: Category + service match (ignore program)
    Level 3: Category match only (last resort)
    """
    # Level 1: Exact
    exact = [r for r in current_rates
             if r.rate_category == new_rate.rate_category
             and normalize_service(r.service_category) == normalize_service(new_rate.service_category)
             and normalize_program(r.program) == normalize_program(new_rate.program)]
    if exact:
        return exact
    
    # Level 2: Category + Service (program may have changed labeling)
    cat_service = [r for r in current_rates
                   if r.rate_category == new_rate.rate_category
                   and normalize_service(r.service_category) == normalize_service(new_rate.service_category)]
    if cat_service:
        return cat_service
    
    # Level 3: Category only (service naming may differ across amendments)
    cat_only = [r for r in current_rates
                if r.rate_category == new_rate.rate_category]
    return cat_only  # May be empty or have many — caller decides


def normalize_service(svc: str) -> str:
    """Normalize service category for matching across documents."""
    if not svc:
        return '__none__'
    normalized = svc.lower().strip()
    # Remove common noise
    normalized = re.sub(r'\s+', ' ', normalized)
    normalized = re.sub(r'[/\-]', ' ', normalized)
    # Canonicalize known variants
    VARIANTS = {
        'med surg': 'medical surgical',
        'icu ccu': 'icu ccu picu',
        'ip per diem': 'inpatient per diem',
        'op': 'outpatient',
    }
    for variant, canonical in VARIANTS.items():
        if variant in normalized:
            normalized = normalized.replace(variant, canonical)
    return normalized
```

### 4.2 Disambiguation Strategies

When multiple candidates exist:

```python
def disambiguate_rate_match(new_rate, candidates) -> Optional[RateFact]:
    """
    Break ties when multiple current rates could be the predecessor.
    
    Strategy:
    1. Prefer same exhibit_reference
    2. Prefer closest rate_numeric value (rate usually changes incrementally)
    3. Prefer same revenue_codes
    4. Prefer most recent effective_date (latest version of the "same" rate)
    """
    scored = []
    for c in candidates:
        score = 0
        # Same exhibit = strong signal
        if c.exhibit_reference and c.exhibit_reference == new_rate.exhibit_reference:
            score += 100
        # Rate proximity (within 50% = likely same rate adjusted)
        if c.rate_numeric and new_rate.rate_numeric:
            ratio = new_rate.rate_numeric / c.rate_numeric if c.rate_numeric != 0 else 999
            if 0.5 <= ratio <= 2.0:
                score += 50
            if 0.8 <= ratio <= 1.2:
                score += 25  # Extra bonus for <20% change
        # Same revenue codes
        if c.revenue_codes and c.revenue_codes == new_rate.revenue_codes:
            score += 30
        # More recent = more likely correct predecessor
        if c.effective_from:
            score += 10  # Any date better than none
        
        scored.append((score, c))
    
    scored.sort(key=lambda x: x[0], reverse=True)
    
    # Only return if clear winner (gap between #1 and #2)
    if len(scored) >= 2 and scored[0][0] - scored[1][0] >= 20:
        return scored[0][1]
    elif len(scored) == 1:
        return scored[0][1]
    
    return None  # Cannot disambiguate
```

---

## 5. PASS 4: CLAUSE-LEVEL SUPERSESSION

### 5.1 Clause Identity

Unlike rates (which have numeric values for matching), clauses need semantic identity:

```python
def clause_identity_hash(clause) -> str:
    """
    Generate a stable identity for a clause that persists across amendments.
    
    Identity components:
    1. Section reference (most stable — "Section 4.2" rarely renumbers)
    2. Topic/subject (normalized)
    3. Content type
    
    NOT included: content_text (that's what changes between versions)
    """
    components = [
        normalize_section_ref(clause.section_reference or ''),
        normalize_topic(clause.topic or ''),
        clause.content_type or 'clause'
    ]
    return hashlib.md5('|'.join(components).encode()).hexdigest()


def normalize_section_ref(ref: str) -> str:
    """Normalize section references for stable matching."""
    ref = ref.lower().strip()
    # Standardize: "Section 4.2" == "Sec. 4.2" == "§4.2"
    ref = re.sub(r'(section|sec\.?|§)\s*', 'section_', ref)
    # Standardize: "Article VII" == "Article 7"
    ref = re.sub(r'article\s+([ivxlcdm]+)', lambda m: f"article_{roman_to_int(m.group(1))}", ref)
    return ref
```

### 5.2 Clause Supersession Algorithm

```python
def pass4_clause_level(amendment: Amendment, contract: Contract) -> List[SupersessionDecision]:
    """
    Match amended clauses to their predecessors using semantic identity.
    """
    decisions = []
    
    new_clauses = get_clauses_from_amendment(amendment)
    current_clauses = get_current_clauses_for_contract(contract.contract_id)
    
    # Build identity index
    current_by_identity = {}
    for clause in current_clauses:
        identity = clause_identity_hash(clause)
        current_by_identity.setdefault(identity, []).append(clause)
    
    for new_clause in new_clauses:
        identity = clause_identity_hash(new_clause)
        predecessors = current_by_identity.get(identity, [])
        
        if len(predecessors) == 1:
            decisions.append(SupersessionDecision(
                superseded_fact_id=predecessors[0].fact_id,
                superseding_fact_id=new_clause.fact_id,
                superseded_by_amendment=amendment.amendment_id,
                supersession_type='CLAUSE_IDENTITY_MATCH',
                confidence=0.85,
                evidence=f"Identity match: {new_clause.section_reference or new_clause.topic}"
            ))
        elif len(predecessors) > 1:
            # Multiple clauses with same identity — use text similarity
            best = max(predecessors, key=lambda p: text_similarity(p.content_text, new_clause.content_text))
            decisions.append(SupersessionDecision(
                superseded_fact_id=best.fact_id,
                superseding_fact_id=new_clause.fact_id,
                superseded_by_amendment=amendment.amendment_id,
                supersession_type='CLAUSE_SIMILARITY_MATCH',
                confidence=0.70,
                evidence=f"Best text similarity match from {len(predecessors)} candidates"
            ))
        # else: new clause (no predecessor) — just add, no supersession needed
    
    return decisions
```

---

## 6. CONFLICT RESOLUTION

### 6.1 When Passes Disagree

```python
def resolve_conflicts(all_decisions: List[SupersessionDecision]) -> List[SupersessionDecision]:
    """
    When multiple passes produce conflicting decisions for the same fact,
    resolve using specificity and confidence.
    
    Rules:
    1. More specific pass wins (Pass 3 > Pass 2 > Pass 1)
    2. At same specificity: higher confidence wins
    3. If still tied: explicit evidence wins over inferred
    """
    # Group decisions by superseded_fact_id
    by_target = defaultdict(list)
    for d in all_decisions:
        if d.superseded_fact_id:
            by_target[d.superseded_fact_id].append(d)
    
    resolved = []
    for fact_id, decisions in by_target.items():
        if len(decisions) == 1:
            resolved.append(decisions[0])
            continue
        
        # Sort by: specificity (desc) → confidence (desc) → explicit over inferred
        SPECIFICITY = {
            'RATE_PAIR_EXACT': 4,
            'RATE_PAIR_FUZZY': 3,
            'CLAUSE_IDENTITY_MATCH': 4,
            'CLAUSE_SIMILARITY_MATCH': 3,
            'EXHIBIT_REPLACE': 2,
            'EXHIBIT_INFERRED': 1,
            'FULL_REPLACEMENT': 0,
        }
        
        decisions.sort(key=lambda d: (
            SPECIFICITY.get(d.supersession_type, 0),
            d.confidence,
            0 if 'INFERRED' in d.supersession_type else 1
        ), reverse=True)
        
        winner = decisions[0]
        
        # Log conflict for audit
        if len(decisions) > 1 and decisions[0].confidence - decisions[1].confidence < 0.1:
            winner.conflict_notes = f"Close call: {len(decisions)} competing decisions"
            winner.needs_review = True
        
        resolved.append(winner)
    
    # Add decisions with no conflict (new rates, etc.)
    for d in all_decisions:
        if d.superseded_fact_id is None:
            resolved.append(d)
    
    return resolved
```

### 6.2 Safety Net: Zero-Current Guard

```python
def apply_zero_current_guard(contract_id: str, decisions: List[SupersessionDecision]):
    """
    After all supersession decisions, ensure every contract has at least some
    current rates. If ALL rates would be superseded, flag for review.
    
    This catches the case where scope classification incorrectly marked
    a partial amendment as FULL_REPLACEMENT.
    """
    remaining_current = get_rates_not_superseded(contract_id, decisions)
    
    if len(remaining_current) == 0:
        # All rates superseded — but the amendment may not have introduced enough replacements
        new_rates_count = sum(1 for d in decisions if d.supersession_type == 'RATE_NEW')
        if new_rates_count < 5:  # Suspiciously few replacements for a "full" replace
            # Downgrade to EXHIBIT_INFERRED and reduce confidence
            for d in decisions:
                if d.supersession_type == 'FULL_REPLACEMENT':
                    d.confidence *= 0.5
                    d.needs_review = True
                    d.conflict_notes = "Zero-current guard triggered: full replacement left too few current rates"
```

---

## 7. OUTPUT FORMAT

### 7.1 Supersession Decision Record

```sql
CREATE TABLE dev_adb.raw.tbl_v2_supersession_decisions (
    decision_id             STRING NOT NULL,
    contract_id             STRING NOT NULL,
    amendment_id            STRING NOT NULL,
    
    -- What was superseded
    superseded_fact_id      STRING,          -- rate or clause fact that was superseded
    superseded_fact_type    STRING,          -- 'rate' | 'clause'
    
    -- What superseded it
    superseding_fact_id     STRING,          -- new rate/clause (NULL if just retired)
    
    -- Decision metadata
    supersession_type       STRING NOT NULL,  -- From algorithm pass
    confidence              FLOAT NOT NULL,
    evidence                STRING,
    algorithm_pass          INT,             -- 1, 2, 3, or 4
    
    -- Review
    needs_review            BOOLEAN DEFAULT FALSE,
    conflict_notes          STRING,
    reviewed_by             STRING,
    reviewed_at             TIMESTAMP,
    review_override         STRING,          -- NULL | 'CONFIRMED' | 'REJECTED' | 'MODIFIED'
    
    -- Audit
    computed_at             TIMESTAMP NOT NULL,
    computation_version     INT NOT NULL
) USING DELTA;
```

### 7.2 Decision Audit Trail

Every supersession decision is logged with:
- Which algorithm pass produced it
- What evidence was used
- Confidence score
- Whether it conflicted with other passes
- Whether human review is needed
- Whether a human overrode the algorithm

---

## 8. PERFORMANCE CHARACTERISTICS

| Pass | Complexity | Typical Runtime (per amendment) |
| --- | --- | --- |
| Pass 1 | O(1) per amendment | < 1ms |
| Pass 2 | O(exhibits × rates) | < 100ms |
| Pass 3 | O(new_rates × current_rates) | < 1s |
| Pass 4 | O(new_clauses × current_clauses) | < 500ms |
| Conflict Resolution | O(n log n) per fact | < 100ms |

**Full contract processing (all amendments):** < 10s per contract  
**Full corpus (600 contracts):** < 2 hours  
**Incremental (new amendment):** < 30s

---

*These algorithms replace a single heuristic (`max(amendment_order) = current`) with a 4-pass resolution system that handles the full complexity of healthcare contract amendments while remaining deterministic and auditable.*
