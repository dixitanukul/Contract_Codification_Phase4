# CONTRACT STATE ENGINE DESIGN
## Enterprise-Grade Amendment-Aware Contract State Reconstruction

**Document Class:** System Architecture Design  
**Date:** 2026-05-22  
**Scope:** Replace heuristic supersession with deterministic, auditable contract state computation  
**Validation Basis:** Independent analysis of 08_build_rates.py, 12_build_genie.py, 07_consolidation.py  

---

## 1. CURRENT STATE ANALYSIS (Verified)

### 1.1 How Current-State Is Computed Today

The system uses a **document-level latest-wins** heuristic:

```python
# From 08_build_rates.py, lines 477-488
# Window over provider_id only — ALL rates for a provider share the same window
w = Window.partitionBy("provider_id")
rates_with_order = rates_with_order.withColumn("max_order", F.max("doc_order").over(w))

# If rate comes from latest document → "current", else → "superseded"
rates_fixed = rates_with_order.withColumn(
    "status",
    F.when(F.col("status").isNotNull(), F.col("status"))  # keep LLM-assigned status
     .when(F.col("doc_order") == F.col("max_order"), F.lit("current"))
     .otherwise(F.lit("superseded"))
)
```

**Critical Problem:** This marks ALL rates from ALL prior documents as superseded, even if the latest amendment only modified Exhibit B rates. A provider with:
- Base Agreement (2020): 50 rate lines across Exhibits A, B, C
- Amendment 1 (2022): Modifies only Exhibit B (5 rate lines)

Result: All 50 original rates marked "superseded", only 5 new rates marked "current". The 45 unchanged rates from Exhibits A and C vanish from current-state.

### 1.2 How Amendment Ordering Works

```python
# From tbl_contract_documents_master, joined to rates:
dm_df = spark.table(f"{SCHEMA}.tbl_contract_documents_master").select(
    "provider_id", "source_filename", "amendment_order"
)
```

`amendment_order` is derived from filename parsing (contract_id numeric suffix) and effective dates. Documents within a provider are ordered linearly — no branching, no multi-contract awareness.

### 1.3 How the Genie Layer Handles It (12_build_genie.py)

The Genie rates table (lines 159-209) adds V8 dedup:
```sql
-- Partition by provider + category + service + rate_numeric + date
-- WITHOUT program/network (those vary by LLM extraction context)
-- Keeps only rn=1 per partition
WHERE r.status = 'current'  -- Already filtered to "current" only
```

This means:
1. First, `08_build_rates` eliminates everything not from the latest doc
2. Then, `12_build_genie` deduplicates what remains (collapses restatements)

The V8 dedup is sound engineering for its input — but its input is already corrupted by the document-level supersession heuristic.

### 1.4 Contract Terms Supersession

```sql
-- From 12_build_genie.py, lines 250-261
latest_docs AS (
  SELECT provider_id, source_filename
  FROM (
    SELECT provider_id, source_filename,
      ROW_NUMBER() OVER (
        PARTITION BY provider_id
        ORDER BY CASE WHEN amendment_order < 100 THEN amendment_order ELSE 0 END DESC,
                 effective_date_parsed DESC NULLS LAST
      ) AS rn
    FROM tbl_contract_documents_master
  ) WHERE rn = 1
)
```

Terms/clauses get `is_from_latest_doc = TRUE/FALSE`, but ALL terms from ALL docs are kept. Only a boolean flag distinguishes "current" from "historical". No clause-level supersession exists.

### 1.5 Summary of Deficiencies

| Aspect | Current Behavior | Correct Behavior |
| --- | --- | --- |
| Supersession unit | Entire document | Individual rate lines / exhibits / clauses |
| Multi-contract | Assumes 1 contract per provider | Provider may have multiple contracts |
| Partial amendments | Treated as full replacement | Should merge: only modified items change |
| Clause versioning | Boolean flag (latest doc or not) | Clause-level supersession with lineage |
| Temporal queries | Impossible | Point-in-time reconstruction required |
| Audit trail | None | Every state change traced to source doc + clause |

---

## 2. TARGET ARCHITECTURE: CONTRACT-CENTRIC STATE ENGINE

### 2.1 Core Design Principles

1. **Contract is the primary entity** — not provider, not document
2. **Amendments modify contracts** — they don't exist independently
3. **Supersession is explicit** — traced to specific exhibits, sections, clauses
4. **State is computed, not stored** — materialized views derive from immutable facts
5. **Bitemporal** — both "when did it take effect" and "when did we learn about it"
6. **Auditable** — every current-state assertion links to its proof chain

### 2.2 Entity Hierarchy

```
Provider (1)
  └── Contract (1..N)           ← NEW entity: a legal agreement with lifecycle
       ├── Base Agreement (1)   ← The original signed document
       ├── Amendment (0..N)     ← Modifications to the base
       │    ├── Scope (what it modifies)
       │    ├── Effective Date (when changes take effect)
       │    └── Modified Items (specific exhibits/sections/rates)
       └── State Snapshot (computed)
            ├── Current Rates (as of today)
            ├── Current Terms (as of today)
            ├── Current Parties (as of today)
            └── Lifecycle Status (ACTIVE/TERMINATED/EXPIRED)
```

### 2.3 Contract Identity Resolution

**Problem:** The current system has no "contract" concept. Multiple documents under the same provider may belong to different contracts (e.g., separate capitation and fee-for-service agreements, or a replacement contract after termination).

**Contract Identity Algorithm:**
```
contract_id = deterministic_hash(
    provider_id,
    base_agreement_filename,  -- Unique identifier of the originating agreement
    agreement_type            -- "capitation" vs "fee_for_service" vs "settlement"
)
```

**Amendment-to-Contract Linking:**
- Amendments explicitly reference their base agreement (extracted by LLM as `amendments_impact.base_agreement_reference`)
- Fallback: same provider_id + overlapping effective date range + compatible agreement_type
- Validation: an amendment cannot supersede a contract it's not linked to

### 2.4 Amendment Scope Classification

Each amendment is classified by what it modifies:

| Scope Type | Meaning | Example |
| --- | --- | --- |
| FULL_REPLACEMENT | Supersedes entire prior agreement | "This Agreement replaces and supersedes..." |
| EXHIBIT_SPECIFIC | Modifies named exhibits only | "Exhibit B is hereby replaced with..." |
| SECTION_SPECIFIC | Modifies named sections/articles | "Section 4.2 is amended to read..." |
| RATE_SPECIFIC | Modifies specific rate categories | "Inpatient per diem rates effective..." |
| TERM_EXTENSION | Extends dates without changing rates | "Term extended through 12/31/2025" |
| ADDENDUM | Adds new content without replacing | "The following services are added..." |

**Source:** The LLM extraction already captures `amendments_impact.exhibits_replaced` and `summary_of_changes`. The state engine will parse these into structured scope declarations.

### 2.5 State Computation Flow

```
[Immutable Facts Layer]              [Computation Layer]              [Materialized State]
                                                                     
┌─────────────────────┐     ┌──────────────────────────────┐     ┌───────────────────────┐
│ tbl_v2_documents    │────▶│ Amendment Graph Builder       │────▶│ tbl_v2_rates_current  │
│ tbl_v2_rates_raw    │     │ - Links amendments to base   │     │ tbl_v2_terms_current  │
│ tbl_v2_terms_raw    │     │ - Classifies scope           │     │ tbl_v2_contract_state │
│ tbl_v2_amendments   │     │ - Resolves conflicts         │     │ (materialized views)  │
└─────────────────────┘     │                              │     └───────────────────────┘
                            │ Supersession Resolver        │
                            │ - Exhibit-level matching     │     ┌───────────────────────┐
                            │ - Rate-line pairing          │────▶│ tbl_v2_rates_history  │
                            │ - Clause identity matching   │     │ tbl_v2_audit_trail    │
                            │ - Effective date ordering    │     │ (SCD Type 2)          │
                            └──────────────────────────────┘     └───────────────────────┘
```

---

## 3. DATA MODEL: CORE TABLES

### 3.1 Contract Registry

```sql
CREATE TABLE dev_adb.raw.tbl_v2_contract_registry (
    -- Identity
    contract_id             STRING NOT NULL,     -- Deterministic hash
    provider_id             STRING NOT NULL,
    provider_name           STRING NOT NULL,
    
    -- Classification
    agreement_type          STRING,              -- fee_for_service | capitation | settlement
    payment_model           STRING,              -- per_diem | case_rate | percentage | pmpm
    network_scope           STRING,              -- commercial | medicare | medi_cal | all
    
    -- Lifecycle
    status                  STRING NOT NULL,     -- ACTIVE | TERMINATED | EXPIRED | SUPERSEDED
    effective_from          DATE,                -- Original contract start
    effective_to            DATE,                -- NULL if active, populated on termination/expiry
    auto_renewal            BOOLEAN,
    term_years              FLOAT,
    
    -- Lineage
    base_agreement_doc      STRING NOT NULL,     -- source_filename of originating agreement
    total_amendments        INT DEFAULT 0,
    latest_amendment_date   DATE,
    latest_amendment_doc    STRING,
    
    -- Audit
    state_computed_at       TIMESTAMP NOT NULL,  -- When this row was last computed
    state_version           INT NOT NULL,        -- Monotonically increasing version
    computation_rule        STRING              -- Which algorithm produced this state
) USING DELTA
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'delta.columnMapping.mode' = 'name'
);
```

### 3.2 Amendment Registry

```sql
CREATE TABLE dev_adb.raw.tbl_v2_amendment_registry (
    -- Identity
    amendment_id            STRING NOT NULL,     -- Deterministic hash
    contract_id             STRING NOT NULL,     -- FK to contract_registry
    
    -- Document
    source_filename         STRING NOT NULL,
    document_type           STRING,             -- amendment | cover_memo | addendum
    amendment_order         INT NOT NULL,       -- Sequence within contract (1-based)
    
    -- Scope Classification
    scope_type              STRING NOT NULL,    -- FULL_REPLACEMENT | EXHIBIT_SPECIFIC | ...
    exhibits_modified       ARRAY<STRING>,      -- ['Exhibit B', 'Exhibit D-1']
    sections_modified       ARRAY<STRING>,      -- ['Section 4.2', 'Article VII']
    rate_categories_modified ARRAY<STRING>,     -- ['inpatient_per_diem', 'outpatient_surgical']
    
    -- Temporal
    effective_date          DATE,               -- When amendment takes effect
    execution_date          DATE,               -- When amendment was signed
    
    -- Content
    summary_of_changes      STRING,            -- LLM-generated summary
    amendments_impact_raw   STRING,            -- Raw JSON from extraction
    
    -- Confidence
    scope_confidence        FLOAT,             -- 0-1: how confident we are in scope classification
    scope_source            STRING,            -- 'explicit_text' | 'inferred_from_content' | 'default_full'
    
    -- Audit
    created_at              TIMESTAMP NOT NULL,
    classification_rule     STRING             -- Which rule classified this amendment's scope
) USING DELTA;
```

### 3.3 Rate Lineage (Immutable Facts)

```sql
CREATE TABLE dev_adb.raw.tbl_v2_rate_facts (
    -- Identity
    rate_fact_id            STRING NOT NULL,    -- Deterministic: hash(contract_id + source_filename + category + service + rate_numeric)
    contract_id             STRING NOT NULL,    -- FK to contract_registry
    amendment_id            STRING,             -- FK to amendment_registry (NULL for base agreement)
    
    -- Rate Content (immutable — exactly as extracted)
    rate_category           STRING,
    service_category        STRING,
    rate_text               STRING,
    rate_numeric            FLOAT,
    rate_type_detail        STRING,
    formula                 STRING,
    revenue_codes           STRING,
    program                 STRING,
    network                 STRING,
    
    -- Provenance
    source_filename         STRING NOT NULL,
    exhibit_reference       STRING,            -- Which exhibit this rate appeared in
    page_number             INT,
    
    -- Temporal (valid time)
    effective_from          DATE,              -- When this rate takes/took effect
    effective_to            DATE,              -- NULL until superseded
    
    -- Supersession (populated by state engine)
    is_current              BOOLEAN,           -- Computed: effective_to IS NULL
    superseded_by_fact_id   STRING,            -- FK to the rate_fact that replaced this one
    superseded_by_amendment STRING,            -- Which amendment caused supersession
    supersession_type       STRING,            -- EXPLICIT | EXHIBIT_REPLACE | FULL_REPLACE | INFERRED
    supersession_confidence FLOAT,             -- 0-1 confidence in supersession decision
    
    -- Audit
    extracted_at            TIMESTAMP,
    state_computed_at       TIMESTAMP
) USING DELTA
TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true');
```

### 3.4 Term/Clause Lineage

```sql
CREATE TABLE dev_adb.raw.tbl_v2_clause_facts (
    -- Identity
    clause_fact_id          STRING NOT NULL,
    contract_id             STRING NOT NULL,
    amendment_id            STRING,
    
    -- Content
    content_type            STRING,            -- clause | definition | code | party
    topic                   STRING,
    section_reference       STRING,            -- 'Section 4.2' | 'Article VII' | 'Exhibit A'
    title                   STRING,
    content_text            STRING,
    
    -- Provenance
    source_filename         STRING NOT NULL,
    page_number             INT,
    
    -- Temporal
    effective_from          DATE,
    effective_to            DATE,
    
    -- Supersession
    is_current              BOOLEAN,
    superseded_by_clause_id STRING,
    superseded_by_amendment STRING,
    supersession_type       STRING,
    
    -- Semantic identity (for matching across amendments)
    clause_identity_hash    STRING,            -- hash(topic + section_reference + normalized_title)
    
    -- Audit
    extracted_at            TIMESTAMP,
    state_computed_at       TIMESTAMP
) USING DELTA;
```

---

## 4. STATE COMPUTATION RULES

### 4.1 Rule Hierarchy (Precedence Order)

```
Rule 1: EXPLICIT SUPERSESSION (highest confidence)
  - Amendment text explicitly states "Exhibit B is replaced"
  - Source: amendments_impact.exhibits_replaced
  - Confidence: 0.95+

Rule 2: RATE-LINE PAIRING
  - Same provider + same category + same service → paired
  - Newer amendment's rate replaces older
  - Confidence: 0.85

Rule 3: EXHIBIT-SCOPE INFERENCE
  - Amendment modifies rates in Exhibit B → all prior Exhibit B rates superseded
  - Other exhibits untouched
  - Confidence: 0.75

Rule 4: DOCUMENT-LEVEL DEFAULT (current v1 behavior — fallback only)
  - If scope cannot be determined, apply full-document supersession
  - Confidence: 0.50
  - FLAG: mark as "needs_review"
```

### 4.2 Cross-Contract Safety

**Invariant:** Amendments to Contract A NEVER supersede rates in Contract B, even for the same provider.

```sql
-- Safety constraint: supersession only within same contract_id
ALTER TABLE tbl_v2_rate_facts ADD CONSTRAINT supersession_same_contract
CHECK (
    superseded_by_fact_id IS NULL 
    OR superseded_by_fact_id IN (
        SELECT rate_fact_id FROM tbl_v2_rate_facts 
        WHERE contract_id = tbl_v2_rate_facts.contract_id
    )
);
```

### 4.3 Partial Amendment Handling

When an amendment modifies only specific exhibits:

```
Input:
  Amendment 3 modifies Exhibit B (inpatient per diem rates)
  
Before Amendment 3:
  Exhibit A rates (from Amendment 2): CURRENT
  Exhibit B rates (from Amendment 2): CURRENT
  Exhibit C rates (from Base):        CURRENT

After Amendment 3:
  Exhibit A rates (from Amendment 2): CURRENT  ← UNCHANGED
  Exhibit B rates (from Amendment 2): SUPERSEDED by Amendment 3
  Exhibit B rates (from Amendment 3): CURRENT  ← NEW
  Exhibit C rates (from Base):        CURRENT  ← UNCHANGED
```

### 4.4 Conflict Resolution

When rules disagree:
1. Higher-precedence rule wins
2. If same precedence: more specific scope wins (rate-line > exhibit > document)
3. If still tied: later effective_date wins
4. If still tied: higher amendment_order wins
5. Log conflict for human review

---

## 5. INTEGRATION WITH EXISTING SYSTEM

### 5.1 Backward-Compatible Views

```sql
-- v2 tables feed into backward-compatible views
-- Existing intelligence notebooks see the same interface
CREATE OR REPLACE VIEW dev_adb.raw.tbl_genie_rates_current_v2 AS
SELECT
    provider_name,
    provider_id,
    rate_category,
    service_category,
    rate_text,
    rate_numeric,
    rate_type_detail,
    effective_from AS effective_date_parsed,
    formula,
    notes,
    revenue_codes,
    program,
    network,
    program_normalized,
    source_filename
FROM dev_adb.raw.tbl_v2_rate_facts
WHERE is_current = TRUE;
```

### 5.2 Migration Strategy

1. **Phase A:** Build v2 tables alongside v1 (no disruption)
2. **Phase B:** Run both systems in parallel, compare outputs
3. **Phase C:** Create backward-compatible views from v2 data
4. **Phase D:** Point intelligence notebooks at v2 views
5. **Phase E:** Deprecate v1 tables after validation period

### 5.3 Intelligence Notebook Changes

Minimal — only the SCHEMA reference changes:
```python
# Before: SCHEMA = "dev_adb.raw"  (v1 tables)
# After:  SCHEMA = "dev_adb.raw"  (v2 views with same interface)
```

---

## 6. IMPLEMENTATION PRIORITIES

| Priority | Component | Effort | Blocks |
| --- | --- | --- | --- |
| P0 | Contract Registry (identify contracts) | 1 week | Everything |
| P1 | Amendment Registry (link amendments) | 1 week | Supersession |
| P2 | Rate Facts (immutable rate records) | 3 days | State computation |
| P3 | Supersession Resolver (rules engine) | 2 weeks | Current-state accuracy |
| P4 | State Materialization (current views) | 3 days | Intelligence queries |
| P5 | Bitemporal tracking | 1 week | Point-in-time queries |
| P6 | Audit trail | 3 days | Compliance |

**Critical path:** P0 → P1 → P2 → P3 → P4 (6 weeks)

---

*This design replaces heuristic supersession with deterministic, auditable contract state computation. Every assertion about "current" rates is traceable to a specific supersession rule applied to specific source documents.*
