# BITEMPORAL STATE MODEL
## Dual-Timeline Tracking for Contract Intelligence

**Document Class:** Temporal Data Architecture  
**Date:** 2026-05-22  
**Scope:** Track both "when it was true" (valid time) and "when we learned it" (transaction time)  

---

## 1. WHY BITEMPORAL

### Problem: Two Different "When" Questions

1. **Valid Time (VT):** "When was this rate in effect?"
   - Answer: From 2022-01-01 to 2023-06-30 (per contract terms)
   
2. **Transaction Time (TT):** "When did we learn about this rate?"
   - Answer: We extracted it on 2026-05-15 (when we processed the PDF)

### Why Both Matter

| Scenario | Valid Time Only | Transaction Time Only | Bitemporal |
| --- | --- | --- | --- |
| "What rates were in effect on 2023-03-01?" | Answers correctly | Cannot answer | Answers correctly |
| "What did we know last Tuesday?" | Cannot answer | Answers correctly | Answers correctly |
| "A re-extraction corrected a rate — what did we believe before?" | Lost (overwritten) | Answers correctly | Answers correctly |
| "When did Amendment 3 take effect, and when did we process it?" | Partial | Partial | Both |

### Healthcare Contract Context

- An amendment executed on 2023-01-15 might be **retroactively effective** from 2022-07-01
- We might not process that amendment until 2026-05 (backlog extraction)
- A gap-fill re-extraction might correct a rate we initially got wrong
- Auditors need to know: "What did the system believe at time T?"

---

## 2. TEMPORAL DIMENSIONS

### 2.1 Valid Time (Business Reality)

```
valid_from: DATE — When this fact became true in the real world
valid_to:   DATE — When this fact stopped being true (NULL = still valid)
```

Examples:
- Rate effective_date = valid_from
- Rate superseded_date = valid_to  
- Contract start_date = valid_from
- Contract termination_date = valid_to

### 2.2 Transaction Time (System Knowledge)

```
tx_from: TIMESTAMP — When the system first recorded this fact
tx_to:   TIMESTAMP — When the system retracted/corrected this fact (NULL = current belief)
```

Examples:
- First extraction creates a fact: tx_from = extraction_timestamp, tx_to = NULL
- Re-extraction corrects the rate: old fact gets tx_to = correction_timestamp
- A new fact is created with tx_from = correction_timestamp, tx_to = NULL

### 2.3 Combined Bitemporal State

Each fact exists at the intersection of valid time and transaction time:

```
┌─────────────────────────────────────────────────────────────────┐
│                        Transaction Time →                         │
│   tx_from           tx_to                                        │
│   2026-05-15        NULL (current belief)                        │
│                                                                   │
│   ┌─────────────────────────────────────────────────────────┐   │
│ V │ valid_from: 2022-01-01                                   │   │
│ a │ valid_to:   2023-06-30                                   │   │
│ l │                                                           │   │
│ i │ Interpretation: "We currently believe this rate was      │   │
│ d │ in effect from 2022-01-01 to 2023-06-30, and we have    │   │
│   │ believed this since 2026-05-15."                         │   │
│ T │                                                           │   │
│ i └─────────────────────────────────────────────────────────┘   │
│ m                                                                 │
│ e                                                                 │
│ ↓                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 3. DELTA TABLE SCHEMA

### 3.1 Bitemporal Rate Facts

```sql
CREATE TABLE dev_adb.raw.tbl_v2_rate_facts_bitemporal (
    -- Identity (stable across corrections)
    rate_fact_id            STRING NOT NULL,
    rate_version_id         STRING NOT NULL,  -- Unique per version of this fact
    contract_id             STRING NOT NULL,
    amendment_id            STRING,
    
    -- Rate Content
    rate_category           STRING,
    service_category        STRING,
    rate_text               STRING,
    rate_numeric            FLOAT,
    rate_type_detail        STRING,
    formula                 STRING,
    program                 STRING,
    network                 STRING,
    source_filename         STRING NOT NULL,
    
    -- Valid Time (business reality)
    valid_from              DATE NOT NULL,     -- When rate took effect
    valid_to                DATE,              -- When rate was superseded (NULL = still valid)
    
    -- Transaction Time (system knowledge)
    tx_from                 TIMESTAMP NOT NULL, -- When we recorded this version
    tx_to                   TIMESTAMP,          -- When we retracted this version (NULL = current belief)
    
    -- Supersession
    superseded_by_fact_id   STRING,
    superseded_by_amendment STRING,
    supersession_type       STRING,
    supersession_confidence FLOAT,
    
    -- Derived (for query convenience)
    is_current_belief       BOOLEAN GENERATED ALWAYS AS (tx_to IS NULL),
    is_currently_valid      BOOLEAN GENERATED ALWAYS AS (tx_to IS NULL AND valid_to IS NULL),
    
    -- Audit
    extraction_run_id       STRING,           -- Which pipeline run created this
    correction_reason       STRING            -- Why tx_to was set (re-extraction, manual fix, etc.)
) USING DELTA
TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true');
```

### 3.2 Bitemporal Clause Facts

```sql
CREATE TABLE dev_adb.raw.tbl_v2_clause_facts_bitemporal (
    clause_fact_id          STRING NOT NULL,
    clause_version_id       STRING NOT NULL,
    contract_id             STRING NOT NULL,
    amendment_id            STRING,
    
    -- Content
    content_type            STRING,
    topic                   STRING,
    section_reference       STRING,
    title                   STRING,
    content_text            STRING,
    source_filename         STRING NOT NULL,
    
    -- Valid Time
    valid_from              DATE NOT NULL,
    valid_to                DATE,
    
    -- Transaction Time
    tx_from                 TIMESTAMP NOT NULL,
    tx_to                   TIMESTAMP,
    
    -- Supersession
    superseded_by_clause_id STRING,
    supersession_type       STRING,
    
    -- Derived
    is_current_belief       BOOLEAN GENERATED ALWAYS AS (tx_to IS NULL),
    is_currently_valid      BOOLEAN GENERATED ALWAYS AS (tx_to IS NULL AND valid_to IS NULL),
    
    -- Identity for matching
    clause_identity_hash    STRING
) USING DELTA;
```

### 3.3 Contract State History

```sql
CREATE TABLE dev_adb.raw.tbl_v2_contract_state_history (
    state_record_id         STRING NOT NULL,
    contract_id             STRING NOT NULL,
    
    -- State
    status                  STRING NOT NULL,  -- ACTIVE | TERMINATED | EXPIRED | SUPERSEDED
    effective_from          DATE,
    effective_to            DATE,
    auto_renewal            BOOLEAN,
    
    -- Valid Time
    valid_from              DATE NOT NULL,
    valid_to                DATE,
    
    -- Transaction Time
    tx_from                 TIMESTAMP NOT NULL,
    tx_to                   TIMESTAMP,
    
    -- Change provenance
    changed_by_amendment    STRING,
    change_description      STRING
) USING DELTA;
```

---

## 4. TEMPORAL OPERATIONS

### 4.1 INSERT (New Fact Discovered)

```python
def insert_rate_fact(rate, extraction_run_id: str):
    """Record a newly discovered rate fact."""
    spark.sql(f"""
        INSERT INTO tbl_v2_rate_facts_bitemporal
        VALUES (
            '{rate.fact_id}',           -- rate_fact_id (stable identity)
            '{uuid4()}',                -- rate_version_id (unique to this version)
            '{rate.contract_id}',
            '{rate.amendment_id}',
            '{rate.rate_category}',
            '{rate.service_category}',
            '{rate.rate_text}',
            {rate.rate_numeric},
            '{rate.rate_type_detail}',
            '{rate.formula}',
            '{rate.program}',
            '{rate.network}',
            '{rate.source_filename}',
            '{rate.effective_from}',     -- valid_from
            NULL,                        -- valid_to (NULL = still valid)
            current_timestamp(),         -- tx_from (now)
            NULL,                        -- tx_to (NULL = current belief)
            NULL, NULL, NULL, NULL,      -- supersession (populated by state engine)
            '{extraction_run_id}',
            NULL                         -- no correction
        )
    """)
```

### 4.2 CORRECT (Re-extraction Changes a Value)

```python
def correct_rate_fact(fact_id: str, new_rate_numeric: float, reason: str):
    """
    Correct a rate fact — preserves history via bitemporal update.
    
    1. Close the old version (set tx_to = now)
    2. Create new version with corrected value (tx_from = now)
    """
    now = current_timestamp()
    
    # Step 1: Retire old version
    spark.sql(f"""
        UPDATE tbl_v2_rate_facts_bitemporal
        SET tx_to = '{now}',
            correction_reason = '{reason}'
        WHERE rate_fact_id = '{fact_id}'
          AND tx_to IS NULL  -- Only close current belief
    """)
    
    # Step 2: Insert corrected version
    spark.sql(f"""
        INSERT INTO tbl_v2_rate_facts_bitemporal
        SELECT
            rate_fact_id,
            '{uuid4()}' AS rate_version_id,  -- New version
            contract_id, amendment_id,
            rate_category, service_category, rate_text,
            {new_rate_numeric} AS rate_numeric,  -- CORRECTED VALUE
            rate_type_detail, formula, program, network, source_filename,
            valid_from, valid_to,
            '{now}' AS tx_from,  -- New knowledge time
            NULL AS tx_to,       -- Current belief
            superseded_by_fact_id, superseded_by_amendment,
            supersession_type, supersession_confidence,
            extraction_run_id,
            '{reason}' AS correction_reason
        FROM tbl_v2_rate_facts_bitemporal
        WHERE rate_fact_id = '{fact_id}'
          AND tx_to = '{now}'  -- The version we just retired
    """)
```

### 4.3 SUPERSEDE (Amendment Replaces a Rate)

```python
def supersede_rate(old_fact_id: str, new_fact_id: str, amendment_id: str, 
                   supersession_date: date, supersession_type: str, confidence: float):
    """
    Record that one rate supersedes another.
    
    This sets valid_to on the old rate (it's no longer in effect)
    and records the supersession relationship.
    """
    now = current_timestamp()
    
    # Close old rate's valid time (it stopped being true on supersession_date)
    # But preserve old tx version — create new tx version with valid_to set
    spark.sql(f"""
        -- Retire current belief about old rate
        UPDATE tbl_v2_rate_facts_bitemporal
        SET tx_to = '{now}'
        WHERE rate_fact_id = '{old_fact_id}' AND tx_to IS NULL;
        
        -- Insert updated belief (same rate, now with valid_to populated)
        INSERT INTO tbl_v2_rate_facts_bitemporal
        SELECT
            rate_fact_id, '{uuid4()}', contract_id, amendment_id,
            rate_category, service_category, rate_text, rate_numeric,
            rate_type_detail, formula, program, network, source_filename,
            valid_from,
            '{supersession_date}' AS valid_to,  -- NOW HAS END DATE
            '{now}' AS tx_from, NULL AS tx_to,
            '{new_fact_id}' AS superseded_by_fact_id,
            '{amendment_id}' AS superseded_by_amendment,
            '{supersession_type}', {confidence},
            extraction_run_id, NULL
        FROM tbl_v2_rate_facts_bitemporal
        WHERE rate_fact_id = '{old_fact_id}' AND tx_to = '{now}';
    """)
```

---

## 5. QUERY PATTERNS

### 5.1 Current State (What's True Now)

```sql
-- Most common query: what rates are in effect today?
SELECT *
FROM tbl_v2_rate_facts_bitemporal
WHERE is_currently_valid = TRUE;
-- Equivalent to: tx_to IS NULL AND valid_to IS NULL
```

### 5.2 Point-in-Time (What Was True on Date X)

```sql
-- What rates were in effect on 2023-06-15?
SELECT *
FROM tbl_v2_rate_facts_bitemporal
WHERE tx_to IS NULL              -- Current belief (most recent knowledge)
  AND valid_from <= '2023-06-15'
  AND (valid_to IS NULL OR valid_to > '2023-06-15');
```

### 5.3 System Knowledge at Time T (What Did We Believe on Date T)

```sql
-- What did the system believe about rates as of 2026-05-16 10:00?
SELECT *
FROM tbl_v2_rate_facts_bitemporal
WHERE tx_from <= '2026-05-16 10:00:00'
  AND (tx_to IS NULL OR tx_to > '2026-05-16 10:00:00')
  AND valid_to IS NULL;  -- Still considered current at that belief time
```

### 5.4 Full Bitemporal (What Did We Believe at Time T About Date D)

```sql
-- What did the system believe on May 16, 2026 about rates in effect on Jan 1, 2023?
SELECT *
FROM tbl_v2_rate_facts_bitemporal
WHERE tx_from <= '2026-05-16 10:00:00'
  AND (tx_to IS NULL OR tx_to > '2026-05-16 10:00:00')
  AND valid_from <= '2023-01-01'
  AND (valid_to IS NULL OR valid_to > '2023-01-01');
```

### 5.5 Change History (How Has Our Understanding Evolved)

```sql
-- Show all versions of a specific rate fact
SELECT 
    rate_version_id,
    rate_numeric,
    valid_from, valid_to,
    tx_from, tx_to,
    correction_reason,
    CASE WHEN tx_to IS NULL THEN 'CURRENT BELIEF' ELSE 'SUPERSEDED BELIEF' END AS belief_status
FROM tbl_v2_rate_facts_bitemporal
WHERE rate_fact_id = :target_fact_id
ORDER BY tx_from DESC;
```

---

## 6. DELTA LAKE IMPLEMENTATION NOTES

### 6.1 Why Delta Works Well for Bitemporal

- **Time Travel:** Delta's built-in versioning provides an additional recovery layer
- **MERGE:** Efficient for the "close old version + insert new version" pattern
- **Change Data Feed:** Captures every mutation for downstream consumers
- **Partition Pruning:** Partition by contract_id for efficient single-contract queries

### 6.2 Partition Strategy

```sql
-- Rate facts: partition by contract for efficient per-contract queries
-- Z-ORDER by valid_from for temporal queries
ALTER TABLE tbl_v2_rate_facts_bitemporal
SET TBLPROPERTIES ('delta.autoOptimize.optimizeWrite' = 'true');

OPTIMIZE tbl_v2_rate_facts_bitemporal
ZORDER BY (contract_id, valid_from, tx_from);
```

### 6.3 Materialized Current-State View

For performance, materialize the most common query pattern:

```sql
-- Rebuild periodically (or via streaming)
CREATE OR REPLACE TABLE tbl_v2_rates_current_snapshot AS
SELECT 
    rate_fact_id, contract_id, amendment_id,
    rate_category, service_category, rate_text, rate_numeric,
    program, network, source_filename,
    valid_from AS effective_date,
    supersession_confidence
FROM tbl_v2_rate_facts_bitemporal
WHERE tx_to IS NULL AND valid_to IS NULL;
-- This is the "current state" = current belief about currently-valid rates
```

---

## 7. MIGRATION FROM V1

### 7.1 Bootstrapping Bitemporal from Existing Data

```python
def bootstrap_bitemporal_from_v1():
    """
    Migrate existing tbl_contract_rates_all into bitemporal model.
    
    Since v1 has no temporal tracking, we assign:
    - valid_from = effective_date_parsed (or extraction date if NULL)
    - valid_to = NULL for 'current' status, amendment_date for 'superseded'
    - tx_from = current_timestamp() (we're recording it now)
    - tx_to = NULL (all are current belief)
    """
    spark.sql("""
        INSERT INTO tbl_v2_rate_facts_bitemporal
        SELECT
            md5(concat(provider_id, source_filename, rate_category, 
                       coalesce(service_category, ''), 
                       coalesce(cast(rate_numeric as string), rate_text))) AS rate_fact_id,
            uuid() AS rate_version_id,
            -- contract_id: will be populated by contract discovery
            md5(concat(provider_id, 'default_contract')) AS contract_id,
            NULL AS amendment_id,
            rate_category, service_category, rate_text, rate_numeric,
            rate_type_detail, formula, program, network, source_filename,
            -- Valid time
            coalesce(
                try_cast(effective_date_parsed AS DATE),
                try_cast(effective_date AS DATE),
                DATE '2020-01-01'  -- fallback for missing dates
            ) AS valid_from,
            CASE WHEN status = 'superseded' 
                 THEN coalesce(try_cast(superseded_date AS DATE), current_date())
                 ELSE NULL 
            END AS valid_to,
            -- Transaction time
            current_timestamp() AS tx_from,
            NULL AS tx_to,
            -- Supersession (to be recomputed by state engine)
            NULL AS superseded_by_fact_id,
            superseded_by AS superseded_by_amendment,
            CASE WHEN status = 'superseded' THEN 'V1_HEURISTIC' ELSE NULL END AS supersession_type,
            CASE WHEN status = 'superseded' THEN 0.50 ELSE NULL END AS supersession_confidence,
            'v1_migration' AS extraction_run_id,
            'Migrated from v1 heuristic supersession' AS correction_reason
        FROM tbl_contract_rates_all
    """)
```

### 7.2 Post-Migration Recomputation

After migration, run the supersession resolver (Pass 1-4) on all contracts to:
1. Replace V1_HEURISTIC supersession with proper exhibit/rate-level decisions
2. Increase confidence scores where evidence supports the decision
3. Flag low-confidence decisions for review
4. Populate contract_id correctly (from contract discovery)

---

## 8. RETENTION AND COMPACTION

### 8.1 Retention Policy

```sql
-- Transaction-time retired versions: keep for 2 years (audit requirement)
-- After 2 years: compact into summary record
DELETE FROM tbl_v2_rate_facts_bitemporal
WHERE tx_to IS NOT NULL 
  AND tx_to < dateadd(YEAR, -2, current_timestamp())
  AND rate_fact_id IN (
      -- Only delete if a newer version exists
      SELECT rate_fact_id FROM tbl_v2_rate_facts_bitemporal WHERE tx_to IS NULL
  );
```

### 8.2 Delta Vacuum

```sql
-- Standard Delta housekeeping (30-day default retention)
VACUUM tbl_v2_rate_facts_bitemporal RETAIN 720 HOURS;  -- 30 days
```

---

*Bitemporal tracking enables the system to answer "what was true" and "what did we know" independently — critical for audit, correction handling, and point-in-time reconstruction of contract state.*
