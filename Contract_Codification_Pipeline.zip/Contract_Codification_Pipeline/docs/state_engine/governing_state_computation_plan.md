# GOVERNING STATE COMPUTATION PLAN
## Deterministic Pipeline for Current-State Materialization

**Document Class:** Computation Pipeline Specification  
**Date:** 2026-05-22  
**Scope:** Complete pipeline from raw extraction to auditable current-state  

---

## 1. COMPUTATION PIPELINE OVERVIEW

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    STATE ENGINE COMPUTATION PIPELINE                          │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  Stage 1: CONTRACT DISCOVERY                                                 │
│  ├── Identify distinct contracts per provider                               │
│  ├── Link base agreements to amendments                                      │
│  └── Populate: tbl_v2_contract_registry                                     │
│                                                                              │
│  Stage 2: AMENDMENT CLASSIFICATION                                           │
│  ├── Parse amendments_impact for each amendment                             │
│  ├── Classify scope (FULL | EXHIBIT | RATE | TERM | ADDENDUM)              │
│  └── Populate: tbl_v2_amendment_registry                                    │
│                                                                              │
│  Stage 3: FACT INGESTION                                                     │
│  ├── Load all rates from v1 tables into bitemporal model                    │
│  ├── Load all clauses/terms into bitemporal model                           │
│  └── Populate: tbl_v2_rate_facts_bitemporal, tbl_v2_clause_facts_bitemporal │
│                                                                              │
│  Stage 4: SUPERSESSION RESOLUTION                                            │
│  ├── Execute Pass 1-4 algorithms per contract                               │
│  ├── Resolve conflicts                                                       │
│  ├── Apply zero-current guard                                                │
│  └── Populate: tbl_v2_supersession_decisions                                │
│                                                                              │
│  Stage 5: STATE MATERIALIZATION                                              │
│  ├── Set valid_to on superseded facts                                       │
│  ├── Compute is_current flags                                                │
│  ├── Build materialized current-state snapshot                              │
│  └── Populate: tbl_v2_rates_current_snapshot                                │
│                                                                              │
│  Stage 6: VALIDATION & AUDIT                                                 │
│  ├── Run invariant checks                                                    │
│  ├── Compare against v1 output                                               │
│  ├── Flag discrepancies                                                      │
│  └── Populate: tbl_v2_computation_audit                                     │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 2. STAGE 1: CONTRACT DISCOVERY

### 2.1 Input

```sql
-- Primary input: all documents for all providers
SELECT provider_id, provider_name, source_filename, document_type,
       amendment_order, effective_date_parsed, doc_category
FROM dev_adb.raw.tbl_contract_documents_master
ORDER BY provider_id, amendment_order;
```

### 2.2 Algorithm

```python
def stage1_discover_contracts():
    """
    Identify distinct contracts per provider.
    
    Most providers (85%+) have exactly 1 contract.
    Some have 2-3 (separate capitation + FFS, or renewal after termination).
    """
    providers = spark.sql("""
        SELECT DISTINCT provider_id, provider_name
        FROM tbl_contract_documents_master
    """).collect()
    
    contracts = []
    for prov in providers:
        docs = get_provider_documents(prov.provider_id)
        
        # Separate base agreements from amendments
        bases = [d for d in docs if d.doc_category == 'base_agreement']
        amendments = [d for d in docs if d.doc_category == 'amendment']
        
        if not bases:
            # No explicit base agreement — treat earliest document as implicit base
            bases = [min(docs, key=lambda d: d.amendment_order or 999)]
        
        # Create contract per base agreement
        for base in bases:
            contract_id = generate_contract_id(prov.provider_id, base.source_filename)
            
            # Link amendments to this contract
            linked_amendments = link_amendments_to_base(base, amendments, docs)
            
            contracts.append({
                'contract_id': contract_id,
                'provider_id': prov.provider_id,
                'provider_name': prov.provider_name,
                'base_agreement_doc': base.source_filename,
                'agreement_type': infer_agreement_type(base, linked_amendments),
                'effective_from': base.effective_date_parsed,
                'total_amendments': len(linked_amendments),
                'status': determine_contract_status(base, linked_amendments),
            })
    
    # Write to registry
    write_to_delta(contracts, 'tbl_v2_contract_registry')
    return len(contracts)
```

### 2.3 Contract Identity Generation

```python
def generate_contract_id(provider_id: str, base_filename: str) -> str:
    """
    Deterministic contract ID from provider + base document.
    Ensures same input always produces same ID (idempotent).
    """
    import hashlib
    raw = f"{provider_id}|{base_filename}"
    return hashlib.sha256(raw.encode()).hexdigest()[:32]
```

### 2.4 Status Determination

```python
def determine_contract_status(base, amendments) -> str:
    """
    Determine current contract lifecycle status.
    
    Rules:
    1. If any amendment explicitly terminates → TERMINATED
    2. If term_end_date < today and no auto_renewal → EXPIRED
    3. If a newer base agreement exists for same provider → SUPERSEDED
    4. Otherwise → ACTIVE
    """
    # Check for termination language in amendments
    for amend in amendments:
        if amend.summary_of_changes and 'terminat' in amend.summary_of_changes.lower():
            return 'TERMINATED'
    
    # Check for expiry
    if base.term_end_date and base.term_end_date < date.today():
        if not base.auto_renewal:
            return 'EXPIRED'
    
    return 'ACTIVE'
```

---

## 3. STAGE 2: AMENDMENT CLASSIFICATION

### 3.1 Input

```sql
-- Amendments with their extracted impact data
SELECT dm.provider_id, dm.source_filename, dm.amendment_order, dm.effective_date_parsed,
       j.amendments_impact
FROM tbl_contract_documents_master dm
JOIN json_extractions j ON dm.source_filename = j.source_filename  
WHERE dm.doc_category = 'amendment'
ORDER BY dm.provider_id, dm.amendment_order;
```

### 3.2 Classification Pipeline

```python
def stage2_classify_amendments():
    """
    For each amendment, determine its scope using the cascade:
    1. Explicit exhibit references
    2. Rate category analysis
    3. Full-text analysis of summary_of_changes
    4. Default to full replacement (with low confidence)
    """
    amendments = get_all_amendments()
    classified = []
    
    for amend in amendments:
        impact = parse_amendments_impact(amend)
        
        # Cascade classification
        scope = classify_amendment_scope(amend, impact)
        
        classified.append({
            'amendment_id': generate_amendment_id(amend),
            'contract_id': amend.contract_id,
            'source_filename': amend.source_filename,
            'document_type': amend.document_type,
            'amendment_order': amend.amendment_order,
            'scope_type': scope.type,
            'exhibits_modified': scope.exhibits,
            'sections_modified': scope.sections,
            'rate_categories_modified': scope.rate_categories,
            'effective_date': amend.effective_date_parsed,
            'summary_of_changes': impact.get('summary_of_changes'),
            'scope_confidence': scope.confidence,
            'scope_source': scope.evidence_source,
        })
    
    write_to_delta(classified, 'tbl_v2_amendment_registry')
    
    # Report classification distribution
    print(f"  Classified {len(classified)} amendments:")
    for scope_type, count in Counter(c['scope_type'] for c in classified).items():
        print(f"    {scope_type}: {count}")
```

### 3.3 Exhibit Extraction from amendments_impact

```python
def parse_amendments_impact(amendment) -> dict:
    """
    Parse the LLM-extracted amendments_impact JSON.
    
    Expected structure (from V6 extraction schema):
    {
        "exhibits_replaced": ["Exhibit B", "Exhibit D-1"],
        "exhibits_modified": ["Exhibit A (Section 3 only)"],
        "summary_of_changes": "Increases inpatient per diem rates...",
        "effective_date": "2023-01-01",
        "rate_changes": [...],
        "term_extension": {...}
    }
    """
    raw = amendment.amendments_impact_raw
    if not raw:
        return {}
    
    if isinstance(raw, str):
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            return {'summary_of_changes': raw}
    
    return raw if isinstance(raw, dict) else {}
```

---

## 4. STAGE 3: FACT INGESTION

### 4.1 Rate Fact Loading

```python
def stage3_ingest_rate_facts():
    """
    Load all rate data into the bitemporal model.
    
    Source: tbl_contract_rates_all (v1 table — has all rates, all statuses)
    Target: tbl_v2_rate_facts_bitemporal
    
    Key transformation:
    - Add contract_id (from contract registry)
    - Add amendment_id (from amendment registry)
    - Set valid_from from effective_date
    - Leave valid_to as NULL (supersession resolver will set it)
    - Set tx_from = now, tx_to = NULL
    """
    spark.sql("""
        INSERT INTO dev_adb.raw.tbl_v2_rate_facts_bitemporal
        SELECT
            -- Rate identity
            md5(concat_ws('|', 
                r.provider_id, r.source_filename, 
                coalesce(r.rate_category, ''),
                coalesce(r.service_category, ''),
                coalesce(cast(r.rate_numeric as string), coalesce(r.rate_text, ''))
            )) AS rate_fact_id,
            uuid() AS rate_version_id,
            
            -- Contract linkage
            cr.contract_id,
            ar.amendment_id,
            
            -- Rate content (immutable)
            r.rate_category,
            r.service_category,
            r.rate_text,
            r.rate_numeric,
            r.rate_type_detail,
            r.formula,
            r.revenue_codes,
            r.program,
            r.network,
            r.source_filename,
            NULL AS exhibit_reference,  -- TODO: extract from clause context
            NULL AS page_number,
            
            -- Valid time (business reality)
            coalesce(
                try_cast(r.effective_date_parsed AS DATE),
                try_cast(r.effective_date AS DATE),
                cr.effective_from,
                DATE '2020-01-01'
            ) AS valid_from,
            NULL AS valid_to,  -- Will be set by supersession resolver
            
            -- Transaction time
            current_timestamp() AS tx_from,
            CAST(NULL AS TIMESTAMP) AS tx_to,
            
            -- Supersession (computed in Stage 4)
            FALSE AS is_current,  -- Will be recomputed
            CAST(NULL AS STRING) AS superseded_by_fact_id,
            CAST(NULL AS STRING) AS superseded_by_amendment,
            CAST(NULL AS STRING) AS supersession_type,
            CAST(NULL AS FLOAT) AS supersession_confidence,
            
            -- Audit
            current_timestamp() AS extracted_at,
            CAST(NULL AS TIMESTAMP) AS state_computed_at
            
        FROM dev_adb.raw.tbl_contract_rates_all r
        -- Join to contract registry
        JOIN dev_adb.raw.tbl_v2_contract_registry cr 
            ON r.provider_id = cr.provider_id
        -- Join to amendment registry (optional — base agreement rates won't match)
        LEFT JOIN dev_adb.raw.tbl_v2_amendment_registry ar
            ON r.source_filename = ar.source_filename
            AND cr.contract_id = ar.contract_id
    """)
```

---

## 5. STAGE 4: SUPERSESSION RESOLUTION

### 5.1 Orchestration

```python
def stage4_resolve_supersession():
    """
    Execute supersession resolution for all contracts.
    
    Process: one contract at a time, chronological amendment order.
    """
    contracts = spark.sql("""
        SELECT contract_id, provider_id, total_amendments
        FROM tbl_v2_contract_registry
        WHERE status != 'SUPERSEDED'
        ORDER BY total_amendments DESC  -- Process complex contracts first
    """).collect()
    
    total_decisions = 0
    
    for contract in contracts:
        decisions = resolve_contract_supersession(contract.contract_id)
        total_decisions += len(decisions)
    
    print(f"  Stage 4 complete: {total_decisions:,} supersession decisions across {len(contracts)} contracts")
    
    # Summary stats
    stats = spark.sql("""
        SELECT 
            supersession_type, 
            COUNT(*) as count,
            ROUND(AVG(confidence), 2) as avg_confidence,
            SUM(CASE WHEN needs_review THEN 1 ELSE 0 END) as needs_review
        FROM tbl_v2_supersession_decisions
        GROUP BY supersession_type
        ORDER BY count DESC
    """)
    stats.show()


def resolve_contract_supersession(contract_id: str) -> List[dict]:
    """
    Resolve supersession for a single contract using 4-pass algorithm.
    """
    # Get amendments in chronological order
    amendments = get_amendments_for_contract(contract_id)
    
    all_decisions = []
    
    for amendment in sorted(amendments, key=lambda a: a.amendment_order):
        # Execute all 4 passes
        pass1 = pass1_document_level(amendment, contract_id)
        pass2 = pass2_exhibit_level(amendment, contract_id)
        pass3 = pass3_rate_line_pairing(amendment, contract_id)
        pass4 = pass4_clause_level(amendment, contract_id)
        
        # Combine and resolve conflicts
        combined = pass1 + pass2 + pass3 + pass4
        resolved = resolve_conflicts(combined)
        
        # Apply zero-current guard
        apply_zero_current_guard(contract_id, resolved)
        
        all_decisions.extend(resolved)
    
    # Write decisions
    write_supersession_decisions(all_decisions)
    
    return all_decisions
```

### 5.2 Decision Application

```python
def stage4b_apply_decisions():
    """
    Apply supersession decisions to rate/clause facts.
    Sets valid_to and superseded_by fields on affected facts.
    """
    spark.sql("""
        -- Update superseded rate facts
        MERGE INTO tbl_v2_rate_facts_bitemporal AS facts
        USING (
            SELECT 
                sd.superseded_fact_id,
                sd.superseding_fact_id,
                sd.amendment_id,
                sd.supersession_type,
                sd.confidence,
                ar.effective_date AS supersession_date
            FROM tbl_v2_supersession_decisions sd
            JOIN tbl_v2_amendment_registry ar ON sd.amendment_id = ar.amendment_id
            WHERE sd.superseded_fact_type = 'rate'
              AND sd.superseded_fact_id IS NOT NULL
        ) AS decisions
        ON facts.rate_fact_id = decisions.superseded_fact_id
           AND facts.tx_to IS NULL  -- Only modify current belief
        WHEN MATCHED THEN UPDATE SET
            facts.valid_to = decisions.supersession_date,
            facts.is_current = FALSE,
            facts.superseded_by_fact_id = decisions.superseding_fact_id,
            facts.superseded_by_amendment = decisions.amendment_id,
            facts.supersession_type = decisions.supersession_type,
            facts.supersession_confidence = decisions.confidence,
            facts.state_computed_at = current_timestamp()
    """)
    
    # Mark non-superseded facts as current
    spark.sql("""
        UPDATE tbl_v2_rate_facts_bitemporal
        SET is_current = TRUE,
            state_computed_at = current_timestamp()
        WHERE tx_to IS NULL  -- Current belief
          AND valid_to IS NULL  -- Not superseded
          AND is_current = FALSE  -- Not already marked
    """)
```

---

## 6. STAGE 5: STATE MATERIALIZATION

### 6.1 Current-State Snapshot

```python
def stage5_materialize_current_state():
    """
    Build the materialized current-state snapshot used by intelligence notebooks.
    This is the fast-path table for the most common query pattern.
    """
    spark.sql("""
        CREATE OR REPLACE TABLE dev_adb.raw.tbl_v2_rates_current_snapshot AS
        SELECT
            rf.rate_fact_id,
            cr.contract_id,
            cr.provider_id,
            cr.provider_name,
            rf.rate_category,
            rf.service_category,
            rf.rate_text,
            rf.rate_numeric,
            rf.rate_type_detail,
            rf.formula,
            rf.revenue_codes,
            rf.program,
            rf.network,
            rf.source_filename,
            rf.valid_from AS effective_date,
            rf.supersession_confidence,
            -- Metadata
            cr.agreement_type,
            cr.status AS contract_status,
            current_timestamp() AS snapshot_generated_at
        FROM dev_adb.raw.tbl_v2_rate_facts_bitemporal rf
        JOIN dev_adb.raw.tbl_v2_contract_registry cr ON rf.contract_id = cr.contract_id
        WHERE rf.tx_to IS NULL       -- Current belief
          AND rf.valid_to IS NULL    -- Currently valid
          AND cr.status = 'ACTIVE'   -- Active contracts only
    """)
    
    count = spark.table("dev_adb.raw.tbl_v2_rates_current_snapshot").count()
    providers = spark.sql("SELECT COUNT(DISTINCT provider_id) FROM dev_adb.raw.tbl_v2_rates_current_snapshot").collect()[0][0]
    print(f"  Snapshot: {count:,} current rates across {providers} providers")
```

### 6.2 Backward-Compatible Views

```python
def stage5b_create_compatibility_views():
    """Create views that match v1 table interfaces exactly."""
    
    # Rates view (matches tbl_genie_rates_current schema)
    spark.sql("""
        CREATE OR REPLACE VIEW dev_adb.raw.tbl_genie_rates_current_v2 AS
        SELECT
            provider_name,
            provider_id,
            rate_category,
            service_category,
            rate_text,
            rate_numeric,
            rate_type_detail,
            effective_date AS effective_date_parsed,
            formula,
            CAST(NULL AS STRING) AS notes,
            revenue_codes,
            program,
            network,
            program AS program_normalized,
            source_filename
        FROM dev_adb.raw.tbl_v2_rates_current_snapshot
    """)
```

---

## 7. STAGE 6: VALIDATION & AUDIT

### 7.1 Invariant Checks

```python
def stage6_validate():
    """
    Run all invariant checks and log results.
    """
    checks = []
    
    # Check 1: No rate has valid_to < valid_from
    violation_1 = spark.sql("""
        SELECT COUNT(*) FROM tbl_v2_rate_facts_bitemporal
        WHERE valid_to IS NOT NULL AND valid_to < valid_from
    """).collect()[0][0]
    checks.append(('temporal_consistency', violation_1 == 0, violation_1))
    
    # Check 2: No cross-contract supersession
    violation_2 = spark.sql("""
        SELECT COUNT(*)
        FROM tbl_v2_supersession_decisions sd
        JOIN tbl_v2_rate_facts_bitemporal old_r ON sd.superseded_fact_id = old_r.rate_fact_id
        JOIN tbl_v2_rate_facts_bitemporal new_r ON sd.superseding_fact_id = new_r.rate_fact_id
        WHERE old_r.contract_id != new_r.contract_id
    """).collect()[0][0]
    checks.append(('no_cross_contract', violation_2 == 0, violation_2))
    
    # Check 3: Every active contract has at least 1 current rate
    violation_3 = spark.sql("""
        SELECT COUNT(*)
        FROM tbl_v2_contract_registry cr
        LEFT JOIN tbl_v2_rate_facts_bitemporal rf 
            ON cr.contract_id = rf.contract_id AND rf.is_current = TRUE AND rf.tx_to IS NULL
        WHERE cr.status = 'ACTIVE' AND rf.rate_fact_id IS NULL
    """).collect()[0][0]
    checks.append(('active_has_rates', violation_3 == 0, violation_3))
    
    # Check 4: Supersession confidence above threshold
    low_confidence = spark.sql("""
        SELECT COUNT(*) FROM tbl_v2_supersession_decisions
        WHERE confidence < 0.5 AND NOT needs_review
    """).collect()[0][0]
    checks.append(('confidence_threshold', low_confidence == 0, low_confidence))
    
    # Report
    print("\n  VALIDATION RESULTS:")
    all_pass = True
    for name, passed, detail in checks:
        status = "✅ PASS" if passed else "❌ FAIL"
        print(f"    {status} {name}: {detail}")
        if not passed:
            all_pass = False
    
    return all_pass
```

### 7.2 V1 Comparison

```python
def stage6b_compare_with_v1():
    """
    Compare v2 current-state against v1 for regression detection.
    
    Expected differences:
    - v2 should have MORE current rates (partial amendments no longer kill all prior rates)
    - v2 and v1 should agree on rates from the latest document
    - v2 may disagree on rates from earlier documents (those v1 killed erroneously)
    """
    comparison = spark.sql("""
        WITH v1_rates AS (
            SELECT provider_id, rate_category, service_category, rate_numeric
            FROM tbl_genie_rates_current
        ),
        v2_rates AS (
            SELECT provider_id, rate_category, service_category, rate_numeric
            FROM tbl_v2_rates_current_snapshot
        )
        SELECT
            'v1_only' AS source, COUNT(*) AS count
        FROM v1_rates v1
        LEFT JOIN v2_rates v2 USING (provider_id, rate_category, service_category, rate_numeric)
        WHERE v2.rate_numeric IS NULL
        
        UNION ALL
        
        SELECT 'v2_only', COUNT(*)
        FROM v2_rates v2
        LEFT JOIN v1_rates v1 USING (provider_id, rate_category, service_category, rate_numeric)
        WHERE v1.rate_numeric IS NULL
        
        UNION ALL
        
        SELECT 'both_agree', COUNT(*)
        FROM v1_rates v1
        JOIN v2_rates v2 USING (provider_id, rate_category, service_category, rate_numeric)
    """)
    comparison.show()
```

---

## 8. EXECUTION ORCHESTRATION

### 8.1 Full Computation Run

```python
def run_state_engine(mode='full'):
    """
    Execute the complete state computation pipeline.
    
    Modes:
    - 'full': Recompute everything from scratch
    - 'incremental': Only process new amendments since last run
    - 'validate_only': Skip computation, just run validation
    """
    print("═" * 80)
    print("  CONTRACT STATE ENGINE v2")
    print("═" * 80)
    
    if mode in ('full', 'incremental'):
        print("\n  [Stage 1] Contract Discovery...")
        n_contracts = stage1_discover_contracts()
        print(f"    → {n_contracts} contracts identified")
        
        print("\n  [Stage 2] Amendment Classification...")
        stage2_classify_amendments()
        
        print("\n  [Stage 3] Fact Ingestion...")
        stage3_ingest_rate_facts()
        
        print("\n  [Stage 4] Supersession Resolution...")
        stage4_resolve_supersession()
        stage4b_apply_decisions()
        
        print("\n  [Stage 5] State Materialization...")
        stage5_materialize_current_state()
        stage5b_create_compatibility_views()
    
    print("\n  [Stage 6] Validation & Audit...")
    passed = stage6_validate()
    stage6b_compare_with_v1()
    
    if passed:
        print("\n  ✅ STATE ENGINE COMPLETE — All invariants satisfied")
    else:
        print("\n  ⚠️  STATE ENGINE COMPLETE — Invariant violations detected (see above)")
    
    return passed
```

### 8.2 Lakeflow Job Integration

```yaml
# Job task: State Engine Computation
task_key: state_engine_computation
notebook_task:
  notebook_path: /Users/adixit01@blueshieldca.com/Contract_Codification_Pipeline/30_state_engine
  base_parameters:
    mode: incremental
depends_on:
  - task_key: table_rebuild  # Must run after extraction + table build
timeout_seconds: 7200  # 2 hours max
```

---

## 9. MIGRATION TIMELINE

| Week | Action | Risk | Rollback |
| --- | --- | --- | --- |
| 1 | Create v2 schemas (empty tables) | None | DROP tables |
| 2 | Stage 1-2: Discovery + Classification | None | Tables unused |
| 3 | Stage 3: Fact ingestion | None | Parallel to v1 |
| 4 | Stage 4: Supersession resolution | None | Decisions table only |
| 5 | Stage 5: Materialize + create views | Low | Drop views |
| 6 | Validate: compare v2 vs v1 | None | Observational |
| 7 | Switch: point intelligence at v2 views | Medium | Revert SCHEMA |
| 8 | Monitor: 1 week parallel operation | Low | Revert if issues |
| 9 | Retire: deprecate v1 tables | Low | Retain for 30 days |

**Total migration time: 9 weeks**  
**Zero downtime throughout**  
**Rollback at any stage: < 5 minutes**

---

*The governing computation plan ensures every step is deterministic, auditable, and backward-compatible. No intelligence notebook changes are required until Stage 7 (switching to v2 views).*
