# AMENDMENT GRAPH ARCHITECTURE
## Directed Acyclic Graph Model for Contract Amendment Chains

**Document Class:** Data Architecture Specification  
**Date:** 2026-05-22  
**Scope:** Model amendment relationships as a DAG with explicit edges and merge semantics  

---

## 1. WHY A GRAPH MODEL

### Current Model: Linear Chain

```
Base Agreement → Amendment 1 → Amendment 2 → Amendment 3 → ...
                 (order=1)       (order=2)       (order=3)
```

**Implicit assumption:** Each amendment supersedes everything before it.  
**Reality in healthcare contracts:**

```
Base Agreement (2019)
  ├── Amendment 1 (2020): Modifies Exhibit B (inpatient rates)
  ├── Amendment 2 (2021): Modifies Exhibit D (outpatient rates)  
  ├── Amendment 3 (2022): Modifies Exhibit B again (rate escalator)
  │                        ↑ This supersedes Amendment 1's Exhibit B,
  │                          NOT Amendment 2's Exhibit D
  └── Amendment 4 (2023): Extends term only (no rate changes)
```

Amendment 3 and Amendment 2 are **independent** — they modify different exhibits. A linear chain cannot represent this. A DAG can.

---

## 2. GRAPH DATA MODEL

### 2.1 Node Types

| Node Type | Represents | Key Attributes |
| --- | --- | --- |
| CONTRACT | The legal agreement entity | contract_id, provider, status, term |
| BASE_DOCUMENT | Original signed agreement | source_filename, effective_date, exhibits |
| AMENDMENT | A modification to the base | amendment_order, scope_type, effective_date |
| EXHIBIT | A named section (rate schedule, terms) | exhibit_name, content_type |
| RATE_LINE | Individual rate entry | category, service, rate_numeric |
| CLAUSE | Individual contract clause | section_ref, topic, content_text |

### 2.2 Edge Types

| Edge Type | From → To | Meaning | Cardinality |
| --- | --- | --- | --- |
| ORIGINATES | CONTRACT → BASE_DOCUMENT | Contract's origin document | 1:1 |
| AMENDS | AMENDMENT → CONTRACT | Amendment modifies contract | N:1 |
| MODIFIES_EXHIBIT | AMENDMENT → EXHIBIT | Which exhibit is changed | N:M |
| SUPERSEDES_RATE | RATE_LINE → RATE_LINE | New rate replaces old | 1:1 |
| SUPERSEDES_CLAUSE | CLAUSE → CLAUSE | New clause replaces old | 1:1 |
| ESTABLISHES | BASE_DOCUMENT → RATE_LINE | Base creates initial rates | 1:N |
| ESTABLISHES | BASE_DOCUMENT → CLAUSE | Base creates initial clauses | 1:N |
| INTRODUCES | AMENDMENT → RATE_LINE | Amendment creates new rates | 1:N |
| INTRODUCES | AMENDMENT → CLAUSE | Amendment creates new clauses | 1:N |

### 2.3 Graph Schema (Delta Table Representation)

```sql
-- Nodes table (polymorphic via node_type)
CREATE TABLE dev_adb.raw.tbl_v2_amendment_graph_nodes (
    node_id             STRING NOT NULL,
    node_type           STRING NOT NULL,  -- CONTRACT | BASE_DOCUMENT | AMENDMENT | EXHIBIT | RATE_LINE | CLAUSE
    contract_id         STRING NOT NULL,  -- All nodes belong to a contract
    
    -- Common attributes
    source_filename     STRING,
    effective_date      DATE,
    label               STRING,           -- Human-readable label
    
    -- Type-specific attributes (JSON for flexibility)
    attributes          STRING,           -- JSON blob with type-specific data
    
    -- Temporal
    created_at          TIMESTAMP,
    superseded_at       TIMESTAMP         -- NULL if still active
) USING DELTA;

-- Edges table
CREATE TABLE dev_adb.raw.tbl_v2_amendment_graph_edges (
    edge_id             STRING NOT NULL,
    edge_type           STRING NOT NULL,  -- AMENDS | MODIFIES_EXHIBIT | SUPERSEDES_RATE | ...
    from_node_id        STRING NOT NULL,
    to_node_id          STRING NOT NULL,
    contract_id         STRING NOT NULL,
    
    -- Edge attributes
    confidence          FLOAT,            -- 0-1 confidence in this relationship
    evidence_source     STRING,           -- What text/logic established this edge
    effective_date      DATE,             -- When this relationship takes effect
    
    -- Audit
    created_at          TIMESTAMP,
    created_by_rule     STRING            -- Which algorithm created this edge
) USING DELTA;
```

---

## 3. GRAPH CONSTRUCTION ALGORITHMS

### 3.1 Phase 1: Contract Discovery

```python
def discover_contracts(provider_id: str) -> List[Contract]:
    """
    Identify distinct contracts for a provider.
    
    Rules:
    1. Each base agreement document creates a new contract
    2. Amendments link to their parent contract via:
       a. Explicit reference in amendments_impact.base_agreement_reference
       b. Filename prefix matching (same contract_id prefix)
       c. Temporal proximity + agreement_type matching
    3. Settlements are standalone (not part of a contract chain)
    """
    docs = get_documents_for_provider(provider_id)
    
    # Partition into base agreements and amendments
    base_docs = [d for d in docs if d.document_type == 'Base Agreement']
    amendments = [d for d in docs if d.document_type in ('Amendment', 'Cover Memo')]
    
    contracts = []
    for base in base_docs:
        contract = Contract(
            id=hash(provider_id, base.source_filename, base.agreement_type),
            base_document=base,
            amendments=[]
        )
        contracts.append(contract)
    
    # Link amendments to contracts
    for amend in amendments:
        contract = resolve_amendment_parent(amend, contracts)
        if contract:
            contract.amendments.append(amend)
        else:
            # Orphan amendment — may indicate a missing base document
            log_orphan_amendment(amend)
    
    return contracts
```

### 3.2 Phase 2: Amendment Linking

```python
def resolve_amendment_parent(amendment, contracts) -> Optional[Contract]:
    """
    Determine which contract an amendment belongs to.
    
    Resolution order (highest confidence first):
    1. Explicit reference in extracted text
    2. Filename contract_id prefix match
    3. Same provider + compatible type + overlapping dates
    4. Single contract exists (trivial case)
    """
    # Rule 1: Explicit reference
    if amendment.amendments_impact:
        ref = amendment.amendments_impact.get('base_agreement_reference')
        if ref:
            match = find_contract_by_reference(ref, contracts)
            if match:
                return match  # confidence: 0.95
    
    # Rule 2: Filename prefix
    # Pattern: providerID_providerName_contractID_docType_version.pdf
    amend_contract_id = parse_contract_id_from_filename(amendment.source_filename)
    for c in contracts:
        base_contract_id = parse_contract_id_from_filename(c.base_document.source_filename)
        if amend_contract_id == base_contract_id:
            return c  # confidence: 0.90
    
    # Rule 3: Type + temporal compatibility
    for c in contracts:
        if (c.base_document.agreement_type == amendment.agreement_type
            and dates_overlap(c.effective_range, amendment.effective_date)):
            return c  # confidence: 0.70
    
    # Rule 4: Single contract (trivial)
    if len(contracts) == 1:
        return contracts[0]  # confidence: 0.60
    
    return None  # Orphan — needs human review
```

### 3.3 Phase 3: Scope Classification

```python
def classify_amendment_scope(amendment) -> AmendmentScope:
    """
    Determine what parts of the contract this amendment modifies.
    
    Input: LLM-extracted amendments_impact JSON
    Output: Structured scope declaration
    """
    impact = amendment.amendments_impact or {}
    
    # Check for explicit exhibit references
    exhibits_replaced = impact.get('exhibits_replaced', [])
    exhibits_modified = impact.get('exhibits_modified', [])
    sections_modified = impact.get('sections_modified', [])
    
    # Check for full replacement language
    summary = impact.get('summary_of_changes', '')
    if contains_full_replacement_language(summary):
        return AmendmentScope(
            type='FULL_REPLACEMENT',
            confidence=0.90,
            evidence=summary[:200]
        )
    
    # Exhibit-specific
    if exhibits_replaced or exhibits_modified:
        return AmendmentScope(
            type='EXHIBIT_SPECIFIC',
            exhibits=exhibits_replaced + exhibits_modified,
            confidence=0.85,
            evidence=f"Exhibits: {exhibits_replaced + exhibits_modified}"
        )
    
    # Infer from rate categories present
    rate_categories = get_rate_categories_in_amendment(amendment)
    if rate_categories:
        return AmendmentScope(
            type='RATE_SPECIFIC',
            rate_categories=rate_categories,
            confidence=0.70,
            evidence=f"Contains rates for: {rate_categories}"
        )
    
    # Term extension (has dates but no rates/clauses)
    if impact.get('term_extension') and not rate_categories:
        return AmendmentScope(
            type='TERM_EXTENSION',
            confidence=0.80,
            evidence="Term dates modified, no rate changes"
        )
    
    # Fallback: full replacement (v1 behavior)
    return AmendmentScope(
        type='FULL_REPLACEMENT',
        confidence=0.40,
        evidence="No explicit scope found — defaulting to full",
        needs_review=True
    )
```

### 3.4 Phase 4: Edge Construction

```python
def build_supersession_edges(contract: Contract) -> List[Edge]:
    """
    For each amendment, determine which specific rates/clauses it supersedes.
    """
    edges = []
    
    # Sort amendments by effective_date (chronological order)
    sorted_amendments = sorted(contract.amendments, key=lambda a: a.effective_date)
    
    # Build cumulative state
    current_rates = {}  # (category, service, rate_numeric) → rate_fact_id
    current_clauses = {}  # clause_identity_hash → clause_fact_id
    
    # Initialize from base agreement
    for rate in contract.base_document.rates:
        key = rate_identity_key(rate)
        current_rates[key] = rate.fact_id
    
    for clause in contract.base_document.clauses:
        key = clause.identity_hash
        current_clauses[key] = clause.fact_id
    
    # Process each amendment
    for amendment in sorted_amendments:
        scope = amendment.classified_scope
        
        if scope.type == 'FULL_REPLACEMENT':
            # Everything is superseded
            for key, fact_id in current_rates.items():
                edges.append(SupersessionEdge(
                    from_node=amendment.rates[0].fact_id if amendment.rates else None,
                    to_node=fact_id,
                    type='FULL_REPLACE',
                    confidence=scope.confidence
                ))
            current_rates = {rate_identity_key(r): r.fact_id for r in amendment.rates}
            
        elif scope.type == 'EXHIBIT_SPECIFIC':
            # Only rates/clauses from named exhibits are superseded
            for rate in get_rates_in_exhibits(current_rates, scope.exhibits):
                new_rate = find_replacement_rate(rate, amendment.rates)
                if new_rate:
                    edges.append(SupersessionEdge(
                        from_node=new_rate.fact_id,
                        to_node=rate.fact_id,
                        type='EXHIBIT_REPLACE',
                        confidence=scope.confidence
                    ))
                    current_rates[rate_identity_key(rate)] = new_rate.fact_id
            
        elif scope.type == 'RATE_SPECIFIC':
            # Only matching rate categories are superseded
            for rate in amendment.rates:
                key = rate_identity_key(rate)
                if key in current_rates:
                    old_fact_id = current_rates[key]
                    edges.append(SupersessionEdge(
                        from_node=rate.fact_id,
                        to_node=old_fact_id,
                        type='RATE_PAIR',
                        confidence=scope.confidence
                    ))
                current_rates[key] = rate.fact_id
    
    return edges
```

---

## 4. GRAPH TRAVERSAL PATTERNS

### 4.1 Current State Query

"What are the current rates for Provider X?"

```sql
-- Traverse graph: find all rate_line nodes with no incoming SUPERSEDES edge
SELECT rf.*
FROM tbl_v2_rate_facts rf
WHERE rf.contract_id IN (
    SELECT contract_id FROM tbl_v2_contract_registry
    WHERE provider_id = :provider_id AND status = 'ACTIVE'
)
AND rf.is_current = TRUE
AND rf.effective_to IS NULL;
```

### 4.2 Amendment Impact Query

"What did Amendment 3 change?"

```sql
-- Find all edges FROM amendment 3
SELECT 
    e.edge_type,
    new_rate.rate_category,
    new_rate.rate_numeric AS new_rate,
    old_rate.rate_numeric AS old_rate,
    new_rate.rate_numeric - old_rate.rate_numeric AS rate_change
FROM tbl_v2_amendment_graph_edges e
JOIN tbl_v2_rate_facts new_rate ON e.from_node_id = new_rate.rate_fact_id
JOIN tbl_v2_rate_facts old_rate ON e.to_node_id = old_rate.rate_fact_id
WHERE e.edge_type = 'SUPERSEDES_RATE'
  AND new_rate.amendment_id = :amendment_id;
```

### 4.3 Rate History Query

"Show me the history of inpatient per diem rates for Provider X"

```sql
-- Follow SUPERSEDES chain backward
WITH RECURSIVE rate_chain AS (
    -- Start with current rate
    SELECT rate_fact_id, rate_numeric, effective_from, source_filename, 0 AS depth
    FROM tbl_v2_rate_facts
    WHERE contract_id = :contract_id
      AND rate_category = 'inpatient_per_diem'
      AND is_current = TRUE
    
    UNION ALL
    
    -- Walk backward through supersession chain
    SELECT old.rate_fact_id, old.rate_numeric, old.effective_from, old.source_filename, rc.depth + 1
    FROM rate_chain rc
    JOIN tbl_v2_amendment_graph_edges e ON e.from_node_id = rc.rate_fact_id
    JOIN tbl_v2_rate_facts old ON e.to_node_id = old.rate_fact_id
    WHERE e.edge_type = 'SUPERSEDES_RATE'
)
SELECT * FROM rate_chain ORDER BY depth;
```

### 4.4 Conflict Detection

"Which rates have ambiguous supersession?"

```sql
SELECT rf.rate_fact_id, rf.rate_category, rf.service_category,
       COUNT(e.edge_id) AS superseding_edges,
       MIN(e.confidence) AS min_confidence
FROM tbl_v2_rate_facts rf
JOIN tbl_v2_amendment_graph_edges e ON e.to_node_id = rf.rate_fact_id
WHERE e.edge_type LIKE 'SUPERSEDES%'
GROUP BY rf.rate_fact_id, rf.rate_category, rf.service_category
HAVING COUNT(e.edge_id) > 1  -- Multiple things claiming to supersede same rate
   OR MIN(e.confidence) < 0.7;  -- Low confidence edges
```

---

## 5. GRAPH INVARIANTS (Enforced Constraints)

### 5.1 Structural Invariants

1. **No cycles:** The graph is a DAG — you cannot supersede something that supersedes you
2. **Single contract:** All nodes in a supersession chain belong to the same contract_id
3. **Temporal monotonicity:** Superseding nodes always have later effective_dates
4. **Base anchoring:** Every rate/clause chain terminates at a BASE_DOCUMENT node
5. **No orphans:** Every AMENDMENT node has exactly one AMENDS edge to a CONTRACT

### 5.2 Validation Queries

```sql
-- Invariant 1: No cycles (check that no rate supersedes itself through any path)
-- Implemented via: directed edge insertion validation

-- Invariant 2: Single contract constraint
SELECT e.edge_id, 'CROSS_CONTRACT_EDGE' AS violation
FROM tbl_v2_amendment_graph_edges e
JOIN tbl_v2_amendment_graph_nodes n1 ON e.from_node_id = n1.node_id
JOIN tbl_v2_amendment_graph_nodes n2 ON e.to_node_id = n2.node_id
WHERE n1.contract_id != n2.contract_id;

-- Invariant 3: Temporal monotonicity
SELECT e.edge_id, 'TEMPORAL_VIOLATION' AS violation
FROM tbl_v2_amendment_graph_edges e
JOIN tbl_v2_amendment_graph_nodes n1 ON e.from_node_id = n1.node_id
JOIN tbl_v2_amendment_graph_nodes n2 ON e.to_node_id = n2.node_id
WHERE e.edge_type LIKE 'SUPERSEDES%'
  AND n1.effective_date < n2.effective_date;  -- Newer superseded by older = wrong

-- Invariant 5: No orphan amendments
SELECT n.node_id, 'ORPHAN_AMENDMENT' AS violation
FROM tbl_v2_amendment_graph_nodes n
LEFT JOIN tbl_v2_amendment_graph_edges e ON n.node_id = e.from_node_id AND e.edge_type = 'AMENDS'
WHERE n.node_type = 'AMENDMENT' AND e.edge_id IS NULL;
```

---

## 6. PERFORMANCE CONSIDERATIONS

### 6.1 Graph Size Estimates

At full extraction (10,372 files):
- Contracts: ~600-800 (some providers have multiple)
- Amendments: ~6,754
- Rate lines: ~600K
- Clauses: ~70K
- Edges: ~1.2M (mostly SUPERSEDES_RATE)

### 6.2 Indexing Strategy

```sql
-- Primary traversal patterns need indexes:
-- 1. Find all current rates for a contract
CREATE INDEX idx_rate_facts_contract_current 
ON tbl_v2_rate_facts (contract_id, is_current);

-- 2. Follow supersession chains
CREATE INDEX idx_edges_from_type 
ON tbl_v2_amendment_graph_edges (from_node_id, edge_type);

CREATE INDEX idx_edges_to_type 
ON tbl_v2_amendment_graph_edges (to_node_id, edge_type);

-- 3. Contract lookup by provider
CREATE INDEX idx_contract_provider 
ON tbl_v2_contract_registry (provider_id, status);
```

Note: Delta Lake doesn't support traditional indexes, but these patterns inform:
- Liquid clustering keys
- Z-ORDER columns
- Partition strategies

### 6.3 Materialization Strategy

The graph is the **source of truth**. Materialized views serve query patterns:

```sql
-- Materialized: Current rates (most common query pattern)
CREATE OR REPLACE TABLE tbl_v2_rates_current_materialized AS
SELECT ... FROM tbl_v2_rate_facts WHERE is_current = TRUE;

-- Materialized: Rate change history (dashboard-ready)
CREATE OR REPLACE TABLE tbl_v2_rate_changes_materialized AS
SELECT 
    e.effective_date AS change_date,
    new.rate_category, new.service_category,
    old.rate_numeric AS old_rate, new.rate_numeric AS new_rate,
    (new.rate_numeric - old.rate_numeric) / NULLIF(old.rate_numeric, 0) * 100 AS pct_change
FROM tbl_v2_amendment_graph_edges e
JOIN tbl_v2_rate_facts new ON e.from_node_id = new.rate_fact_id
JOIN tbl_v2_rate_facts old ON e.to_node_id = old.rate_fact_id
WHERE e.edge_type = 'SUPERSEDES_RATE';
```

---

## 7. MIGRATION FROM LINEAR TO GRAPH

### Step 1: Populate Nodes from Existing Data

```python
# Read existing tbl_contract_documents_master
# Create CONTRACT nodes (one per provider initially — refine in step 2)
# Create AMENDMENT nodes (one per amendment document)
# Create RATE_LINE nodes (from tbl_contract_rates_all)
```

### Step 2: Classify Amendment Scopes

```python
# For each amendment, read amendments_impact JSON
# Apply scope classification rules
# Output: scope_type + exhibits_modified + confidence
```

### Step 3: Build Supersession Edges

```python
# Apply supersession rules in precedence order
# Create edges with confidence scores
# Flag low-confidence edges for review
```

### Step 4: Validate and Materialize

```python
# Run invariant checks
# Compute is_current for all rate_facts
# Materialize current-state views
# Compare against v1 output — log differences
```

---

*The graph model enables precise, auditable supersession that handles partial amendments, multi-contract providers, and exhibit-level modifications — all impossible with the current linear chain.*
