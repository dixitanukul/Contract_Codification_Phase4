# SCENARIO MODELING ENGINE
## Multi-Year Financial Simulation for Contract Negotiation and Portfolio Strategy

**Document Class:** Simulation Engine Architecture  
**Date:** 2026-05-22  
**Scope:** What-if analysis for rate changes, volume shifts, structural modifications  
**Consumers:** Provider Contracting (pre-negotiation), Finance (budgeting), Network Strategy  

---

## 1. WHY SCENARIO MODELING

### 1.1 Questions That Cannot Be Answered Today

| Question | Why It Can't Be Answered | Required Capability |
| --- | --- | --- |
| "If we reduce med/surg 5%, what's the 3-year savings?" | No volume data, no escalator projection | Spend-weighted multi-year model |
| "If Provider X terminates, what does redistribution cost?" | No alternative rate comparison, no volume mapping | Network simulation |
| "What if we convert per-diem to DRG-based?" | No DRG weight data, no case-level modeling | Payment model conversion |
| "What's the break-even on a volume guarantee?" | No volume-price elasticity estimate | Trade-off modeling |
| "If CPI hits 5%, what's the portfolio impact?" | No aggregate escalator exposure | Macro sensitivity analysis |

### 1.2 Design Principle: Scenarios, Not Predictions

The engine does NOT predict what will happen. It answers: **"IF this change occurs, THEN the financial impact is X."** Every output explicitly states assumptions.

---

## 2. SCENARIO TYPES

### 2.1 Taxonomy of Scenarios

```python
class ScenarioType(Enum):
    # Provider-level scenarios
    RATE_CHANGE = "rate_change"                  # What if rates change by X%?
    ESCALATION_CHANGE = "escalation_change"      # What if escalator is capped/changed?
    VOLUME_SHIFT = "volume_shift"                # What if volume moves to/from provider?
    TERMINATION = "termination"                  # What if contract terminates?
    PAYMENT_MODEL_CHANGE = "payment_model"       # What if per-diem → DRG?
    
    # Structural scenarios
    STOP_LOSS_MODIFICATION = "stop_loss"         # What if stop-loss threshold changes?
    CARVE_OUT_ADDITION = "carve_out"             # What if we add/remove carve-outs?
    LESSER_OF_ADDITION = "lesser_of"             # What if we add lesser-of provision?
    TERM_EXTENSION = "term_extension"            # Value of longer term at current rates
    
    # Portfolio scenarios
    NETWORK_REDESIGN = "network_redesign"        # Redesign entire service area network
    MACRO_SENSITIVITY = "macro_sensitivity"      # CPI change, utilization trend shift
    BUDGET_TARGET = "budget_target"              # "What rate changes hit our budget?"
```

### 2.2 Scenario Definition

```python
@dataclass
class Scenario:
    """A complete scenario definition for simulation."""
    scenario_id: str
    scenario_type: ScenarioType
    name: str                          # "5% Med/Surg reduction"
    description: str
    
    # Scope
    provider_ids: List[str]           # Which providers affected (None = all)
    service_lines: List[str]          # Which service lines (None = all)
    programs: List[str]               # Which programs
    
    # Parameters (type-specific)
    parameters: Dict[str, Any]        # Type-specific parameters
    
    # Temporal
    effective_date: date              # When scenario starts
    projection_years: int = 5         # How far to project
    
    # Assumptions
    volume_growth_pct: float = 2.0    # Annual volume growth assumption
    cpi_assumption_pct: float = 3.5   # CPI for CPI-linked escalators
    utilization_trend: str = 'stable' # increasing | stable | decreasing

# Example: 5% inpatient rate reduction
scenario = Scenario(
    scenario_id="SCN-001",
    scenario_type=ScenarioType.RATE_CHANGE,
    name="5% Inpatient Reduction - Providence",
    description="Model impact of 5% across-the-board inpatient rate reduction",
    provider_ids=["PROV_123"],
    service_lines=["IP_ACUTE_MEDSURG", "IP_ACUTE_ICU", "IP_ACUTE_NICU"],
    programs=None,  # All programs
    parameters={
        "rate_change_pct": -5.0,
        "applies_to": "INPATIENT",
        "phase_in": False,  # Immediate vs phased
    },
    effective_date=date(2026, 1, 1),
    projection_years=5
)
```

---

## 3. SIMULATION ENGINE

### 3.1 Core Simulation Pipeline

```
Scenario Definition
        │
        ▼
┌─────────────────────────────┐
│ 1. BASELINE COMPUTATION     │  Current spend by line (from claims + rates)
│    (What we spend today)    │
└────────────┬────────────────┘
             │
             ▼
┌─────────────────────────────┐
│ 2. SCENARIO APPLICATION     │  Apply rate/volume/structural changes
│    (What changes)           │
└────────────┬────────────────┘
             │
             ▼
┌─────────────────────────────┐
│ 3. MULTI-YEAR PROJECTION    │  Project forward with escalators + volume trends
│    (5-year forward view)    │
└────────────┬────────────────┘
             │
             ▼
┌─────────────────────────────┐
│ 4. IMPACT QUANTIFICATION    │  Δ from baseline: annual, cumulative, NPV
│    (What it's worth)        │
└────────────┬────────────────┘
             │
             ▼
┌─────────────────────────────┐
│ 5. SENSITIVITY ANALYSIS     │  How results change with ±20% in assumptions
│    (How robust is this?)    │
└─────────────────────────────┘
```

### 3.2 Simulation Execution

```python
def run_scenario(scenario: Scenario) -> ScenarioResult:
    """Execute a complete scenario simulation."""
    
    # Step 1: Compute baseline (current state)
    baseline = compute_baseline(
        provider_ids=scenario.provider_ids,
        service_lines=scenario.service_lines,
        programs=scenario.programs
    )
    
    # Step 2: Apply scenario changes to create modified state
    modified = apply_scenario_changes(baseline, scenario)
    
    # Step 3: Project both baseline and modified forward
    baseline_projection = project_forward(
        baseline, 
        years=scenario.projection_years,
        volume_growth=scenario.volume_growth_pct,
        cpi=scenario.cpi_assumption_pct
    )
    modified_projection = project_forward(
        modified,
        years=scenario.projection_years,
        volume_growth=scenario.volume_growth_pct,
        cpi=scenario.cpi_assumption_pct
    )
    
    # Step 4: Compute deltas
    impact = compute_impact(baseline_projection, modified_projection)
    
    # Step 5: Sensitivity analysis
    sensitivity = run_sensitivity(scenario, baseline, 
                                  vary_params=['volume_growth_pct', 'cpi_assumption_pct'],
                                  variation_pct=20)
    
    return ScenarioResult(
        scenario=scenario,
        baseline=baseline_projection,
        modified=modified_projection,
        impact=impact,
        sensitivity=sensitivity
    )
```

### 3.3 Rate Change Simulation

```python
def simulate_rate_change(baseline: Baseline, scenario: Scenario) -> ModifiedState:
    """
    Apply rate change to baseline spend.
    Handles: flat %, tiered by service line, phased over years.
    """
    rate_change = scenario.parameters['rate_change_pct'] / 100
    phase_in = scenario.parameters.get('phase_in', False)
    phase_years = scenario.parameters.get('phase_years', 3)
    
    modified_lines = []
    for line in baseline.service_lines:
        # Check if this line is in scope
        if scenario.service_lines and line.code not in scenario.service_lines:
            modified_lines.append(line)  # Unchanged
            continue
        
        if phase_in:
            # Gradual: 1/3 of change per year over phase_years
            annual_change = rate_change / phase_years
            new_rate = line.effective_rate * (1 + annual_change)  # Year 1 only partial
        else:
            new_rate = line.effective_rate * (1 + rate_change)
        
        modified_lines.append(ServiceLineState(
            code=line.code,
            effective_rate=new_rate,
            volume=line.volume,
            annual_spend=new_rate * line.volume,
            rate_change_applied=rate_change
        ))
    
    return ModifiedState(service_lines=modified_lines)
```

### 3.4 Termination Simulation

```python
def simulate_termination(provider_id: str, baseline: Baseline) -> TerminationResult:
    """
    Model complete financial impact of provider termination.
    
    Components:
    1. Volume redistribution to alternatives (at their rates)
    2. Out-of-network cost for non-redistributable volume
    3. Transition costs (admin, member communication)
    4. Member attrition risk (lost premium revenue)
    """
    volume_by_line = get_volume_by_service_line(provider_id)
    alternatives = get_alternative_providers(provider_id)
    
    redistribution_cost = 0
    oon_cost = 0
    stranded_lines = []
    
    for line_code, volume in volume_by_line.items():
        alt_providers = alternatives.get(line_code, [])
        
        if alt_providers:
            # Redistribute to best available alternative
            best_alt_rate = min(p.rate for p in alt_providers)
            current_rate = get_rate(provider_id, line_code)
            redistribution_cost += (best_alt_rate - current_rate) * volume
        else:
            # No alternative — goes out-of-network
            oon_rate = get_oon_rate(line_code)  # Typically billed charges
            current_rate = get_rate(provider_id, line_code)
            oon_cost += (oon_rate - current_rate) * volume
            stranded_lines.append(line_code)
    
    # Transition costs (one-time)
    transition_cost = estimate_transition_cost(provider_id)
    
    # Member attrition (ongoing revenue loss)
    risk = assess_network_risk(provider_id)
    annual_attrition_cost = (
        risk.estimated_member_attrition * 
        get_avg_premium(provider_id) * 12
    )
    
    return TerminationResult(
        annual_redistribution_delta=redistribution_cost,
        annual_oon_exposure=oon_cost,
        one_time_transition_cost=transition_cost,
        annual_attrition_risk=annual_attrition_cost,
        total_year_1_cost=redistribution_cost + oon_cost + transition_cost + annual_attrition_cost,
        stranded_service_lines=stranded_lines,
        # Walk-away rate: the rate at which termination becomes cheaper than paying
        walk_away_threshold=(redistribution_cost + oon_cost + annual_attrition_cost) / 
                            baseline.total_spend * 100 + 100  # % of current spend
    )
```

---

## 4. MULTI-SCENARIO COMPARISON

### 4.1 Side-by-Side Analysis

```python
def compare_scenarios(scenarios: List[Scenario]) -> ComparisonMatrix:
    """
    Run multiple scenarios and compare side-by-side.
    
    Typical use: "Compare 3%, 5%, 8% reduction + term extension vs status quo"
    """
    results = [run_scenario(s) for s in scenarios]
    
    comparison = ComparisonMatrix(
        scenario_names=[s.name for s in scenarios],
        metrics={
            'Year 1 Savings': [r.impact.year_1_savings for r in results],
            '5-Year Cumulative': [r.impact.cumulative_5yr_savings for r in results],
            'NPV (8% discount)': [r.impact.npv_savings for r in results],
            'Break-even Month': [r.impact.break_even_month for r in results],
            'Risk Level': [r.impact.risk_assessment for r in results],
            'Provider Acceptance': [estimate_acceptance(r) for r in results],
        }
    )
    
    return comparison
```

### 4.2 Budget-Backward Modeling

```python
def find_rate_for_budget(provider_id: str, target_annual_spend: float,
                         service_lines: List[str] = None) -> BudgetSolution:
    """
    Reverse-engineer: "What rate reduction achieves our budget target?"
    
    Instead of: "What if we reduce by 5%?"
    This answers: "What reduction % hits our $X budget?"
    """
    current_spend = get_annual_spend(provider_id, service_lines)
    target_reduction = current_spend - target_annual_spend
    
    # Distribute reduction across service lines proportionally to spend
    line_targets = []
    for line in get_service_line_spend(provider_id, service_lines):
        line_share = line.annual_spend / current_spend
        line_reduction = target_reduction * line_share
        required_pct = line_reduction / line.annual_spend * 100
        
        # Check feasibility against benchmark
        benchmark = get_benchmark(line.service_line_code)
        max_feasible_pct = (line.effective_rate - benchmark.p25_rate) / line.effective_rate * 100
        
        line_targets.append(LineTarget(
            service_line=line.service_line_code,
            current_rate=line.effective_rate,
            required_reduction_pct=required_pct,
            max_feasible_pct=max_feasible_pct,
            is_achievable=required_pct <= max_feasible_pct,
            target_rate=line.effective_rate * (1 - required_pct / 100)
        ))
    
    achievable = all(t.is_achievable for t in line_targets)
    
    return BudgetSolution(
        target_spend=target_annual_spend,
        required_overall_reduction_pct=target_reduction / current_spend * 100,
        line_targets=line_targets,
        is_achievable=achievable,
        budget_gap_if_not=sum(
            (t.required_reduction_pct - t.max_feasible_pct) * 
            get_line_spend(provider_id, t.service_line) / 100
            for t in line_targets if not t.is_achievable
        )
    )
```

---

## 5. SENSITIVITY ANALYSIS

### 5.1 Tornado Diagram Inputs

```python
def run_sensitivity(scenario: Scenario, baseline: Baseline,
                    vary_params: List[str], variation_pct: float = 20) -> SensitivityResult:
    """
    Vary each assumption ±X% and measure impact on result.
    Produces tornado diagram data.
    """
    base_result = run_scenario(scenario)
    base_savings = base_result.impact.cumulative_5yr_savings
    
    sensitivities = []
    for param in vary_params:
        # High case
        high_scenario = copy_scenario(scenario)
        set_param(high_scenario, param, get_param(scenario, param) * (1 + variation_pct/100))
        high_result = run_scenario(high_scenario)
        
        # Low case
        low_scenario = copy_scenario(scenario)
        set_param(low_scenario, param, get_param(scenario, param) * (1 - variation_pct/100))
        low_result = run_scenario(low_scenario)
        
        sensitivities.append(SensitivityParam(
            parameter=param,
            base_value=get_param(scenario, param),
            low_value=get_param(low_scenario, param),
            high_value=get_param(high_scenario, param),
            impact_at_low=low_result.impact.cumulative_5yr_savings - base_savings,
            impact_at_high=high_result.impact.cumulative_5yr_savings - base_savings,
            swing=abs(high_result.impact.cumulative_5yr_savings - low_result.impact.cumulative_5yr_savings)
        ))
    
    # Sort by swing (largest impact first)
    sensitivities.sort(key=lambda x: x.swing, reverse=True)
    
    return SensitivityResult(
        base_result=base_savings,
        parameters=sensitivities,
        most_sensitive_param=sensitivities[0].parameter,
        total_uncertainty_range=(
            min(s.impact_at_low for s in sensitivities),
            max(s.impact_at_high for s in sensitivities)
        )
    )
```

---

## 6. OUTPUT: SCENARIO RESULTS TABLE

```sql
CREATE TABLE IF NOT EXISTS dev_adb.raw.tbl_intel_scenario_results (
    -- Identity
    scenario_id             STRING NOT NULL COMMENT 'Unique scenario identifier',
    scenario_name           STRING NOT NULL COMMENT 'Human-readable scenario name',
    scenario_type           STRING NOT NULL COMMENT 'RATE_CHANGE | TERMINATION | VOLUME_SHIFT | etc.',
    
    -- Scope
    provider_id             STRING COMMENT 'Provider (NULL for portfolio-wide)',
    service_lines           STRING COMMENT 'JSON array of affected service lines',
    
    -- Parameters
    parameters_json         STRING COMMENT 'Full scenario parameters as JSON',
    assumptions_json        STRING COMMENT 'Assumptions: volume growth, CPI, utilization',
    
    -- Results: Year 1
    baseline_year1_spend    FLOAT COMMENT 'Baseline Year 1 projected spend',
    scenario_year1_spend    FLOAT COMMENT 'Scenario Year 1 projected spend',
    year1_savings           FLOAT COMMENT 'Year 1 savings (positive = saves money)',
    year1_savings_pct       FLOAT COMMENT 'Year 1 savings as % of baseline',
    
    -- Results: Cumulative
    cumulative_3yr_savings  FLOAT COMMENT '3-year cumulative savings',
    cumulative_5yr_savings  FLOAT COMMENT '5-year cumulative savings',
    npv_savings_8pct        FLOAT COMMENT 'NPV of savings at 8% discount rate',
    
    -- Risk
    risk_level              STRING COMMENT 'LOW | MEDIUM | HIGH | VERY_HIGH',
    acceptance_probability  FLOAT COMMENT 'Estimated probability provider accepts (0-1)',
    
    -- Sensitivity
    sensitivity_json        STRING COMMENT 'Tornado diagram data as JSON',
    most_sensitive_param    STRING COMMENT 'Which assumption has most impact',
    
    -- Audit
    computed_at             TIMESTAMP COMMENT 'When simulation was run',
    computed_by             STRING COMMENT 'User who requested simulation'
) USING DELTA
COMMENT 'Scenario simulation results. Each row = one what-if analysis with full financial projection.'
TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true', 'delta.columnMapping.mode' = 'name');
```

---

## 7. INTERACTION MODEL

### 7.1 Genie Space Integration

Natural language queries that invoke the simulation engine:

| User Query | Engine Action |
| --- | --- |
| "What if we reduce Providence inpatient by 5%?" | RATE_CHANGE scenario, project 5 years |
| "What's the cost if we lose Sutter?" | TERMINATION scenario with redistribution |
| "How do we hit $40M budget for Kaiser?" | BUDGET_BACKWARD solve for rates |
| "Compare 3%, 5%, 8% reduction for Providence" | Multi-scenario comparison |
| "What if CPI hits 6% next year?" | MACRO_SENSITIVITY on portfolio |
| "Model adding a stop-loss at $60K for St. Joseph" | STOP_LOSS_MODIFICATION |

---

*The scenario modeling engine transforms contract intelligence from descriptive ("here's what the rates are") to prescriptive ("here's what we should do and exactly what it's worth over 5 years"). Every recommendation becomes quantified, every trade-off becomes visible, every decision becomes defensible.*
