# RENEWAL INTELLIGENCE V2
## Spend-Prioritized Renewal Management with Network Risk Analysis

**Document Class:** Business Intelligence Architecture  
**Date:** 2026-05-22  
**Scope:** Replace days-to-expiry grouping with financially-prioritized, risk-adjusted renewal intelligence  
**Consumers:** Provider Contracting, Network Management, CFO Office  

---

## 1. CURRENT STATE DEFICIENCIES

### 1.1 What Exists (Notebook 24)

Current renewal intelligence:
- Groups contracts by days-to-expiry: <90, 90-180, 180-365, >365
- Flags auto-renewal vs manual-renewal
- Lists provider name and expiration date
- No prioritization beyond temporal urgency

### 1.2 The Problem

A $200K/year provider expiring in 60 days gets the SAME urgency as a $45M/year provider expiring in 60 days. Without spend-weighting:
- Contracting team works renewals by date, not by financial impact
- High-value renewals get the same preparation as low-value ones
- No early warning on strategically critical providers
- No escalation risk modeling (what if we DON'T renegotiate?)

---

## 2. RENEWAL PRIORITIZATION MODEL

### 2.1 Priority Score

```python
@dataclass
class RenewalPriority:
    """Prioritized renewal with financial and strategic context."""
    provider_id: str
    provider_name: str
    
    # Temporal
    contract_expiry_date: date
    days_to_expiry: int
    auto_renewal: bool
    notice_period_days: int          # Days before expiry to give notice
    notice_deadline: date            # expiry - notice_period
    days_to_notice_deadline: int     # Actual action deadline
    
    # Financial weight
    total_annual_spend: float
    spend_rank: int
    escalation_cost_if_unchanged: float  # What we'll pay extra if auto-renews at current escalator
    savings_opportunity_at_renewal: float # $ we could save by renegotiating
    
    # Strategic weight
    network_risk_if_lost: float      # 0-1: how much network suffers without them
    member_disruption_count: int     # Members who'd need new provider
    replacement_availability: int    # Alternative providers in area
    
    # Composite priority (higher = handle first)
    @property
    def priority_score(self) -> float:
        """
        Combines urgency (temporal) × impact (financial) × risk (strategic).
        
        Formula:
        - Urgency: exponential as deadline approaches (max at 0 days)
        - Impact: log-scaled spend (diminishing returns above $50M)
        - Risk: linear network dependency
        """
        # Urgency component (0-40 points)
        if self.days_to_notice_deadline <= 0:
            urgency = 40  # PAST DEADLINE
        elif self.days_to_notice_deadline <= 30:
            urgency = 35
        elif self.days_to_notice_deadline <= 90:
            urgency = 25
        elif self.days_to_notice_deadline <= 180:
            urgency = 15
        else:
            urgency = 5
        
        # Financial impact component (0-40 points)
        spend_score = min(np.log10(max(self.total_annual_spend, 1)) / 8 * 40, 40)
        savings_boost = min(self.savings_opportunity_at_renewal / 2_000_000 * 10, 10)
        impact = spend_score + savings_boost
        
        # Network risk component (0-20 points)
        risk = self.network_risk_if_lost * 20
        
        return urgency + impact + risk
    
    @property
    def priority_tier(self) -> str:
        score = self.priority_score
        if score >= 70:
            return "CRITICAL"    # Handle immediately
        elif score >= 50:
            return "HIGH"        # Schedule within 2 weeks
        elif score >= 30:
            return "MODERATE"    # Queue for next cycle
        else:
            return "ROUTINE"     # Auto-renew is acceptable
    
    @property
    def recommended_action(self) -> str:
        if self.days_to_notice_deadline <= 0:
            return "ESCALATE — Past notice deadline"
        elif self.auto_renewal and self.savings_opportunity_at_renewal < 50_000:
            return "ALLOW AUTO-RENEW — Low savings opportunity"
        elif self.auto_renewal and self.savings_opportunity_at_renewal >= 50_000:
            return "ISSUE NON-RENEWAL NOTICE — Renegotiate"
        elif self.network_risk_if_lost > 0.7:
            return "RENEW WITH IMPROVEMENTS — Cannot risk termination"
        elif self.savings_opportunity_at_renewal > 500_000:
            return "AGGRESSIVE RENEGOTIATION — High savings opportunity"
        else:
            return "STANDARD RENEWAL — Moderate terms improvement"
```

### 2.2 Renewal Calendar (Spend-Weighted)

```sql
-- Renewal calendar view: weighted by financial impact
CREATE OR REPLACE VIEW dev_adb.raw.v_intel_renewal_calendar AS
SELECT
    rp.provider_id,
    rp.provider_name,
    rp.contract_expiry_date,
    rp.days_to_expiry,
    rp.days_to_notice_deadline,
    rp.auto_renewal,
    rp.priority_tier,
    rp.priority_score,
    rp.recommended_action,
    
    -- Financial context
    sp.total_paid_amount AS annual_spend,
    sp.spend_rank,
    sp.savings_opportunity,
    sp.escalation_exposure,
    
    -- At-risk dollars
    CASE 
        WHEN rp.days_to_notice_deadline <= 0 THEN sp.total_paid_amount  -- Full spend at risk
        WHEN rp.auto_renewal = TRUE THEN sp.escalation_exposure          -- Escalation at risk
        ELSE sp.savings_opportunity                                        -- Savings at risk
    END AS dollars_at_risk,
    
    -- Network context
    rp.member_disruption_count,
    rp.network_risk_if_lost,
    rp.replacement_availability

FROM dev_adb.raw.tbl_intel_renewal_priority rp
JOIN dev_adb.raw.tbl_intel_provider_spend_summary sp
    ON rp.provider_id = sp.provider_id
ORDER BY rp.priority_score DESC;
```

---

## 3. ESCALATION FORECASTING

### 3.1 Multi-Year Cost Projection

```python
def project_escalation_cost(provider_id: str, 
                             years_forward: int = 5) -> EscalationProjection:
    """
    Project future costs based on contracted escalator formulas.
    Uses tbl_reimb_escalators to compute compounding effects.
    """
    # Get current spend baseline
    current_spend = get_annual_spend(provider_id)
    
    # Get escalator terms from V2 reimbursement tables
    escalators = spark.sql("""
        SELECT e.escalator_type, e.annual_increase_pct, e.cpi_floor, e.cpi_cap,
               e.year_1_rate, e.year_2_rate, e.year_3_rate, e.year_4_rate,
               rr.service_line, rr.rate_domain,
               sl.total_spend AS line_spend
        FROM dev_adb.raw.tbl_reimb_escalators e
        JOIN dev_adb.raw.tbl_reimb_rate_rules rr ON e.rule_id = rr.rule_id
        JOIN dev_adb.raw.tbl_intel_service_line_spend sl 
            ON rr.provider_id = sl.provider_id AND rr.service_line = sl.service_line_code
        WHERE rr.provider_id = :provider_id
    """, params={"provider_id": provider_id}).collect()
    
    projections = []
    for year in range(1, years_forward + 1):
        year_cost = 0
        for esc in escalators:
            if esc.escalator_type == 'FIXED_PERCENTAGE':
                year_cost += esc.line_spend * (1 + esc.annual_increase_pct / 100) ** year
            elif esc.escalator_type == 'CPI_LINKED':
                cpi_est = estimate_cpi(year)  # Forecasted CPI
                effective_pct = max(min(cpi_est, esc.cpi_cap or 10), esc.cpi_floor or 0)
                year_cost += esc.line_spend * (1 + effective_pct / 100) ** year
            elif esc.escalator_type == 'STEP_SCHEDULE':
                step_rates = [esc.year_1_rate, esc.year_2_rate, esc.year_3_rate, esc.year_4_rate]
                rate = step_rates[min(year - 1, 3)] or step_rates[-1]
                year_cost += rate * get_volume(provider_id, esc.service_line)
        
        projections.append(YearProjection(
            year=year,
            projected_spend=year_cost,
            increase_from_baseline=year_cost - current_spend,
            cumulative_escalation=sum(p.increase_from_baseline for p in projections) + (year_cost - current_spend)
        ))
    
    return EscalationProjection(
        provider_id=provider_id,
        baseline_spend=current_spend,
        projections=projections,
        total_5yr_escalation=sum(p.increase_from_baseline for p in projections),
        avg_annual_increase_pct=(projections[-1].projected_spend / current_spend) ** (1/years_forward) - 1
    )
```

### 3.2 Escalation Alerting

| Alert | Condition | Action |
| --- | --- | --- |
| HIGH ESCALATION | Projected 3yr increase > 15% of current spend | Flag for early renegotiation |
| CPI RISK | CPI-linked escalator + CPI forecast > 4% | Model cap impact, consider fixed-rate conversion |
| UNCAPPED | No escalator cap on provider > $5M spend | Negotiate cap at next renewal |
| STEP SCHEDULE END | Step schedule expires within 12 months | Negotiate new schedule or convert to fixed % |
| COMPOUND RISK | Multiple service lines escalating independently | Aggregate impact may exceed expectations |

---

## 4. NETWORK RISK ANALYSIS

### 4.1 Provider Dependency Assessment

```python
@dataclass
class NetworkRiskAssessment:
    """What happens if we lose this provider?"""
    provider_id: str
    
    # Volume exposure
    total_attributed_members: int      # Members who primarily use this provider
    total_annual_encounters: int       # Encounters at this provider
    
    # Service area analysis
    service_area_counties: List[str]   # Counties this provider serves
    alternative_providers: Dict[str, int]  # service_line → count of alternatives
    sole_provider_lines: List[str]     # Service lines where they're the ONLY option
    
    # Member disruption
    members_requiring_redirect: int    # Members who'd need to find new provider
    estimated_member_attrition: float  # % of members who might leave plan
    attrition_revenue_risk: float      # $ of premium revenue at risk
    
    # Clinical risk
    services_with_no_alternative: List[str]  # Could create access gaps
    geographic_gap_if_removed: bool    # Would create >30-mile travel for members
    specialty_risk: List[str]          # Specialties that can't be replaced
    
    @property
    def network_risk_score(self) -> float:
        """0-1: how much network integrity depends on this provider."""
        risk = 0.0
        
        # Sole-provider penalty (0.4 max)
        if len(self.sole_provider_lines) > 0:
            risk += min(len(self.sole_provider_lines) / 5, 1.0) * 0.4
        
        # Member disruption (0.3 max)
        member_pct = self.members_requiring_redirect / max(self.total_attributed_members, 1)
        risk += min(member_pct * 2, 1.0) * 0.3
        
        # Access gap (0.2 max)
        if self.geographic_gap_if_removed:
            risk += 0.2
        
        # Revenue risk (0.1 max)
        risk += min(self.estimated_member_attrition / 10, 1.0) * 0.1
        
        return min(risk, 1.0)
```

### 4.2 Termination Impact Model

```python
def model_termination_impact(provider_id: str) -> TerminationImpact:
    """
    Model: what happens financially and operationally if this contract terminates?
    Used to set walk-away thresholds in negotiation.
    """
    risk = assess_network_risk(provider_id)
    
    # Volume redistribution
    redistributable = estimate_redistributable_volume(provider_id)
    stranded = estimate_stranded_volume(provider_id)  # No alternative exists
    
    # Cost of redistribution
    redirect_costs = 0
    for line, volume in redistributable.items():
        alternative_rates = get_alternative_rates(provider_id, line)
        if alternative_rates:
            avg_alternative = np.median(alternative_rates)
            current_rate = get_current_rate(provider_id, line)
            redirect_costs += (avg_alternative - current_rate) * volume
    
    # Out-of-network cost for stranded volume
    oon_costs = sum(
        get_oon_rate(line) * vol for line, vol in stranded.items()
    )
    
    # Member attrition
    attrition_cost = risk.estimated_member_attrition * avg_pmpm * 12
    
    # Administrative costs
    admin_costs = estimate_transition_admin_cost(provider_id)
    
    return TerminationImpact(
        provider_id=provider_id,
        redirect_cost_delta=redirect_costs,          # Δ cost from higher alternative rates
        oon_cost_exposure=oon_costs,                  # OON cost for stranded volume
        member_attrition_cost=attrition_cost,        # Lost premium revenue
        transition_admin_cost=admin_costs,           # One-time transition cost
        total_termination_cost=redirect_costs + oon_costs + attrition_cost + admin_costs,
        max_acceptable_rate_premium=redirect_costs / get_annual_spend(provider_id)
        # ^ The % above benchmark we'd still accept rather than terminate
    )
```

---

## 5. AUTO-RENEWAL DECISION ENGINE

### 5.1 Decision Tree

```python
def auto_renewal_decision(provider_id: str) -> RenewalDecision:
    """
    Automated recommendation: let auto-renew, issue non-renewal, or renegotiate.
    """
    spend = get_spend_summary(provider_id)
    renewal = get_renewal_details(provider_id)
    risk = assess_network_risk(provider_id)
    savings = compute_savings_opportunity(provider_id)
    
    # Decision logic
    if not renewal.auto_renewal:
        # Manual renewal — must act
        return RenewalDecision(
            action="NEGOTIATE",
            reason="Contract requires affirmative renewal",
            urgency=compute_urgency(renewal.days_to_notice_deadline)
        )
    
    # Auto-renewal with low savings opportunity
    if savings.savings_opportunity < 50_000:
        return RenewalDecision(
            action="ALLOW_AUTO_RENEW",
            reason=f"Savings opportunity ({fmt_dollars(savings.savings_opportunity)}) "
                   f"below negotiation threshold ($50K)",
            urgency="LOW"
        )
    
    # Auto-renewal with high savings but high network risk
    if savings.savings_opportunity >= 50_000 and risk.network_risk_score > 0.7:
        return RenewalDecision(
            action="NEGOTIATE_CAREFULLY",
            reason=f"${fmt_dollars(savings.savings_opportunity)} opportunity but "
                   f"network risk is {risk.network_risk_score:.0%} — cannot risk termination",
            urgency="HIGH",
            constraints=["Do not issue non-renewal notice", "Target modest improvement only"]
        )
    
    # Auto-renewal with high savings and manageable risk
    if savings.savings_opportunity >= 200_000:
        return RenewalDecision(
            action="ISSUE_NON_RENEWAL_NOTICE",
            reason=f"${fmt_dollars(savings.savings_opportunity)} opportunity with "
                   f"manageable risk ({risk.network_risk_score:.0%}). "
                   f"Issue non-renewal to force renegotiation.",
            urgency="HIGH",
            deadline=renewal.notice_deadline
        )
    
    # Default: moderate opportunity
    return RenewalDecision(
        action="NEGOTIATE_AT_RENEWAL",
        reason=f"${fmt_dollars(savings.savings_opportunity)} opportunity. "
               f"Open discussion at renewal window.",
        urgency="MODERATE"
    )
```

---

## 6. IMPLEMENTATION: RENEWAL PRIORITY TABLE

```sql
CREATE TABLE IF NOT EXISTS dev_adb.raw.tbl_intel_renewal_priority (
    -- Identity
    provider_id             STRING NOT NULL COMMENT 'Provider ID',
    provider_name           STRING NOT NULL COMMENT 'Canonical provider name',
    contract_id             STRING COMMENT 'FK to contract registry',
    
    -- Temporal
    contract_expiry_date    DATE COMMENT 'Contract expiration date',
    days_to_expiry          INT COMMENT 'Days until expiration',
    auto_renewal            BOOLEAN COMMENT 'TRUE if contract auto-renews',
    notice_period_days      INT COMMENT 'Required notice period for non-renewal',
    notice_deadline         DATE COMMENT 'Last day to issue non-renewal notice',
    days_to_notice_deadline INT COMMENT 'Days until notice deadline (negative = past due)',
    
    -- Priority scoring
    priority_score          FLOAT COMMENT 'Composite priority (0-100, higher = more urgent)',
    priority_tier           STRING COMMENT 'CRITICAL | HIGH | MODERATE | ROUTINE',
    recommended_action      STRING COMMENT 'ALLOW_AUTO_RENEW | NEGOTIATE | ISSUE_NON_RENEWAL | ESCALATE',
    
    -- Financial context
    annual_spend            FLOAT COMMENT 'Total annual spend with this provider',
    savings_opportunity     FLOAT COMMENT 'Estimated savings from renegotiation',
    escalation_exposure_3yr FLOAT COMMENT 'Projected 3-year escalation cost if unchanged',
    dollars_at_risk         FLOAT COMMENT 'Financial exposure: spend that could be impacted',
    
    -- Network risk
    network_risk_score      FLOAT COMMENT 'Network dependency 0-1 (1=critical)',
    member_disruption_count INT COMMENT 'Members affected if provider lost',
    replacement_availability INT COMMENT 'Alternative providers in service area',
    sole_provider_services  STRING COMMENT 'JSON array of services with no alternative',
    
    -- Termination modeling
    termination_cost        FLOAT COMMENT 'Estimated total cost of termination',
    max_rate_premium_pct    FLOAT COMMENT 'Max % above benchmark before termination is cheaper',
    
    -- Audit
    computed_at             TIMESTAMP COMMENT 'When this priority was last computed'
) USING DELTA
COMMENT 'Renewal prioritization with spend weighting, network risk, and escalation forecasting.'
TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true', 'delta.columnMapping.mode' = 'name');
-- Z-ORDER: OPTIMIZE ZORDER BY (priority_tier, days_to_notice_deadline)
```

---

## 7. MONITORING & ALERTING

### 7.1 Renewal Pipeline Alerts

| Alert | Trigger | Audience | Frequency |
| --- | --- | --- | --- |
| CRITICAL RENEWAL | priority_tier = CRITICAL | VP Contracting + Director | Immediate |
| NOTICE DEADLINE | days_to_notice_deadline < 30 | Assigned Negotiator | Daily |
| HIGH-SPEND AUTO-RENEW | auto_renewal AND savings > $200K | Director | Weekly |
| ESCALATION SPIKE | projected increase > 20% in next year | Finance + Contracting | Monthly |
| NETWORK GAP RISK | network_risk > 0.8 AND days_to_expiry < 180 | Network Mgmt | Weekly |

### 7.2 KPIs for Renewal Program

| KPI | Definition | Target |
| --- | --- | --- |
| Renewals with negotiation prep | % of CRITICAL/HIGH renewals with brief generated | >95% |
| Savings captured at renewal | Actual $ saved vs prior contract terms | Track quarterly |
| Missed notice deadlines | Count of auto-renewals that should have been renegotiated | 0 |
| Average prep lead time | Days between first alert and negotiation start | >90 days |
| Network risk events | Providers lost without planned replacement | 0 |

---

*Renewal intelligence V2 transforms expiration management from a calendar exercise into a financially-prioritized, risk-assessed strategic function. Every renewal decision is backed by spend data, network risk analysis, and escalation projections.*
