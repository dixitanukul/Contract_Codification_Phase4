# SPEND-WEIGHTED ANALYTICS
## Claims Integration, Financial Defensibility, and Annualized Impact Projections

**Document Class:** Data Integration & Analytics Specification  
**Date:** 2026-05-22  
**Scope:** Bridge between contract rates (what we COULD pay) and claims reality (what we DO pay)  
**Principle:** No metric is meaningful without volume context. $50 above benchmark × 10 cases ≠ $50 × 10,000 cases.  

---

## 1. THE WEIGHT PROBLEM

### 1.1 Unweighted vs Weighted Analysis

| Analysis | Unweighted (V1) | Weighted (V2) |
| --- | --- | --- |
| "Above benchmark" | Provider X is 12% above peer median | Provider X costs us $2.1M more than peer median annually |
| "Rate comparison" | ICU: $3,200 vs $2,950 peer | ICU: $250/day × 890 days = $222K annual overspend |
| "Best negotiation target" | Highest rate_numeric | Highest (rate - benchmark) × volume = most $ on table |
| "Portfolio health" | 34% of providers above median | 41% of SPEND is above median (concentrated in top 10) |
| "Escalation risk" | 3% annual increase | $1.4M additional annual cost in Year 3 |

### 1.2 Why Claims Integration Is Non-Negotiable

Contract rates tell you **what you'd pay per unit**. Only claims tell you:
- How many units actually occurred (volume)
- Which service lines have the most activity (mix)
- Whether stop-loss thresholds are actually triggered (utilization patterns)
- Whether lesser-of provisions actually save money (charges vs contracted)
- What the effective discount is (paid vs billed)

---

## 2. DATA MODEL: CLAIMS INTEGRATION LAYER

### 2.1 Integration Architecture

```
┌─────────────────────┐     ┌─────────────────────┐     ┌─────────────────────┐
│ CONTRACT LAYER      │     │ CLAIMS LAYER         │     │ ANALYTICS LAYER     │
│ (what we agreed)    │     │ (what happened)      │     │ (what it means)     │
├─────────────────────┤     ├─────────────────────┤     ├─────────────────────┤
│                     │     │                      │     │                     │
│ tbl_reimb_rate_rules│─────│ tbl_claims_summary   │─────│ tbl_intel_provider_ │
│ (contracted rates)  │ JOIN│   _feed              │     │   spend_summary     │
│                     │     │ (actual volume/$)    │     │                     │
│ dim_service_line_   │─────│                      │─────│ tbl_intel_service_  │
│   taxonomy          │ MAP │                      │     │   line_spend        │
│ (classification)    │     │                      │     │                     │
│                     │     │ tbl_membership_feed  │─────│ tbl_intel_benchmark │
│ tbl_reimb_          │     │ (members, pmpm)      │     │   _results          │
│   escalators        │     │                      │     │                     │
│ (rate changes)      │     │ tbl_utilization_feed │     │ tbl_intel_savings_  │
│                     │     │ (admits, days)       │     │   opportunity       │
└─────────────────────┘     └─────────────────────┘     └─────────────────────┘
```

### 2.2 Claims Summary Feed (Required)

```sql
-- Pre-aggregated: provider × service_line × month
-- Source: Enterprise data warehouse or claims adjudication system
CREATE TABLE IF NOT EXISTS dev_adb.raw.tbl_claims_summary_feed (
    -- Keys
    provider_id             STRING NOT NULL COMMENT 'Provider TIN or BSC internal ID',
    service_line_code       STRING NOT NULL COMMENT 'FK to dim_service_line_taxonomy',
    month_year              STRING NOT NULL COMMENT 'Period: YYYY-MM format',
    program                 STRING COMMENT 'Commercial | Medicare | Medi-Cal',
    network                 STRING COMMENT 'HMO | PPO',
    
    -- Volume metrics
    case_count              INT COMMENT 'Distinct cases/encounters',
    inpatient_days          INT COMMENT 'Total IP days (for per-diem weighting)',
    outpatient_visits       INT COMMENT 'Total OP visits',
    professional_services   INT COMMENT 'Total professional service units',
    unique_members          INT COMMENT 'Distinct members with claims',
    
    -- Financial metrics
    total_billed            FLOAT COMMENT 'Sum of billed charges (gross)',
    total_allowed           FLOAT COMMENT 'Sum of allowed amounts',
    total_plan_paid         FLOAT COMMENT 'Sum of plan-paid amounts (net of member cost-share)',
    total_member_paid       FLOAT COMMENT 'Member copay + coinsurance + deductible',
    
    -- Derived metrics
    avg_billed_per_case     FLOAT COMMENT 'Avg billed charges per case',
    avg_paid_per_case       FLOAT COMMENT 'Avg plan paid per case',
    avg_paid_per_day        FLOAT COMMENT 'Avg plan paid per inpatient day',
    discount_pct            FLOAT COMMENT '1 - (paid/billed): effective discount from contract',
    
    -- Quality indicators
    denied_claims_count     INT COMMENT 'Claims denied in period',
    denial_rate_pct         FLOAT COMMENT 'denied / total submitted',
    readmit_30day_count     INT COMMENT '30-day readmissions',
    avg_drg_weight          FLOAT COMMENT 'Average DRG relative weight (acuity)',
    
    -- Load metadata
    loaded_at               TIMESTAMP DEFAULT current_timestamp() COMMENT 'When row was loaded'
) USING DELTA
COMMENT 'Monthly claims summary by provider and service line. Source for spend-weighted analytics.'
TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true', 'delta.columnMapping.mode' = 'name');
```

### 2.3 Utilization Summary Feed

```sql
-- Membership and utilization context
CREATE TABLE IF NOT EXISTS dev_adb.raw.tbl_utilization_feed (
    -- Keys
    provider_id             STRING NOT NULL COMMENT 'Provider ID',
    service_area            STRING COMMENT 'Geographic service area code',
    month_year              STRING NOT NULL COMMENT 'Period: YYYY-MM',
    
    -- Membership
    attributed_members      INT COMMENT 'Members attributed to this provider (PCP assignment)',
    total_plan_members      INT COMMENT 'Total plan members in service area',
    market_share_pct        FLOAT COMMENT 'Provider attributed / total in area',
    
    -- Utilization rates (per 1000 members)
    admits_per_1000         FLOAT COMMENT 'Inpatient admissions per 1000 members',
    days_per_1000           FLOAT COMMENT 'Inpatient days per 1000 members',
    er_visits_per_1000      FLOAT COMMENT 'ER visits per 1000 members',
    op_visits_per_1000      FLOAT COMMENT 'Outpatient visits per 1000',
    
    -- Cost metrics
    pmpm_total              FLOAT COMMENT 'Per member per month total cost',
    pmpm_inpatient          FLOAT COMMENT 'PMPM inpatient component',
    pmpm_outpatient         FLOAT COMMENT 'PMPM outpatient component',
    pmpm_professional       FLOAT COMMENT 'PMPM professional component',
    
    -- Benchmarks
    pmpm_target             FLOAT COMMENT 'Budget PMPM target for this population',
    pmpm_variance_pct       FLOAT COMMENT 'Actual vs target variance %'
) USING DELTA
COMMENT 'Monthly utilization and membership summary. Enables PMPM analysis and utilization benchmarking.'
TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true', 'delta.columnMapping.mode' = 'name');
```

---

## 3. SPEND-WEIGHTED BENCHMARKING

### 3.1 Benchmark Computation Engine

```python
def compute_benchmarks(analysis_period: str = 'R12M') -> DataFrame:
    """
    Compute spend-weighted benchmarks across all providers.
    
    Benchmarks computed:
    1. Peer median: Median rate among similar providers (volume-weighted)
    2. Peer p25: 25th percentile (aggressive negotiation target)
    3. Market rate: Broader market median (all payers)
    4. Medicare reference: CMS rate for comparison
    5. Plan-wide average: Average across all BSC contracts
    """
    # Get actual paid rates (from claims)
    actual_rates = spark.sql("""
        SELECT 
            c.provider_id,
            c.service_line_code,
            -- Effective per-unit rate from claims
            CASE 
                WHEN SUM(c.inpatient_days) > 0 
                    THEN SUM(c.total_plan_paid) / SUM(c.inpatient_days)
                WHEN SUM(c.case_count) > 0 
                    THEN SUM(c.total_plan_paid) / SUM(c.case_count)
                ELSE NULL
            END AS effective_rate,
            SUM(c.total_plan_paid) AS total_spend,
            SUM(c.case_count) AS total_cases,
            SUM(c.inpatient_days) AS total_days
        FROM dev_adb.raw.tbl_claims_summary_feed c
        WHERE c.month_year >= :period_start
        GROUP BY c.provider_id, c.service_line_code
        HAVING SUM(c.total_plan_paid) > 0
    """)
    
    # Compute percentiles per service line (volume-weighted)
    benchmarks = actual_rates.groupBy("service_line_code").agg(
        F.expr("percentile_approx(effective_rate, 0.25)").alias("p25_rate"),
        F.expr("percentile_approx(effective_rate, 0.50)").alias("median_rate"),
        F.expr("percentile_approx(effective_rate, 0.75)").alias("p75_rate"),
        F.avg("effective_rate").alias("mean_rate"),
        F.sum("total_spend").alias("total_line_spend"),
        F.sum("total_cases").alias("total_line_cases"),
        F.count("provider_id").alias("provider_count")
    )
    
    return benchmarks
```

### 3.2 Savings Opportunity Quantification

```python
def compute_savings_opportunity(provider_id: str, target: str = 'median') -> SavingsOpportunity:
    """
    Compute exactly how much we'd save by moving this provider to target benchmark.
    
    Granular by service line — not a single blended number.
    """
    lines = get_service_line_spend(provider_id)
    benchmarks = get_benchmarks()
    
    total_savings = 0
    line_details = []
    
    for line in lines:
        benchmark = benchmarks.get(line.service_line_code)
        if not benchmark:
            continue
        
        target_rate = getattr(benchmark, f'{target}_rate')
        
        if line.effective_rate > target_rate:
            # This line is above benchmark — savings opportunity
            rate_delta = line.effective_rate - target_rate
            annual_savings = rate_delta * line.volume  # volume = days or cases
            pct_reduction = rate_delta / line.effective_rate * 100
            
            line_details.append(ServiceLineSavings(
                service_line=line.service_line_code,
                current_rate=line.effective_rate,
                target_rate=target_rate,
                rate_delta=rate_delta,
                annual_volume=line.volume,
                annual_savings=annual_savings,
                pct_reduction_needed=pct_reduction,
                pct_of_total_opportunity=0  # Computed after loop
            ))
            total_savings += annual_savings
    
    # Compute % contribution of each line
    for detail in line_details:
        detail.pct_of_total_opportunity = detail.annual_savings / max(total_savings, 1) * 100
    
    # Sort by $ impact (largest savings first)
    line_details.sort(key=lambda x: x.annual_savings, reverse=True)
    
    return SavingsOpportunity(
        provider_id=provider_id,
        total_annual_savings=total_savings,
        line_details=line_details,
        top_3_lines_savings=sum(d.annual_savings for d in line_details[:3]),
        pct_of_spend=total_savings / get_total_spend(provider_id) * 100,
        target_benchmark=target
    )
```

---

## 4. ANNUALIZED PROJECTIONS

### 4.1 Forward-Looking Financial Model

```python
@dataclass
class AnnualizedProjection:
    """Multi-year financial projection for a provider contract."""
    provider_id: str
    base_year_spend: float            # Current annual spend
    
    # Year-by-year projections
    projections: List[YearProjection]  # Years 1-5
    
    # Scenario variants
    status_quo: float                  # 5-year total if no changes
    post_negotiation: float            # 5-year total if we hit targets
    cumulative_savings: float          # status_quo - post_negotiation
    
    # Key assumptions
    volume_growth_assumption: float    # % annual volume growth
    escalator_applied: str             # Which escalator formula used
    utilization_trend: str             # Increasing | Stable | Decreasing

@dataclass
class YearProjection:
    year: int
    projected_spend: float
    rate_component: float       # Spend attributable to rate level
    volume_component: float     # Spend attributable to volume changes
    escalation_component: float # Spend from contractual escalators
    mix_component: float        # Spend from case-mix / acuity changes

def project_annual_spend(provider_id: str, years: int = 5,
                         rate_change_pct: float = 0,
                         volume_trend_pct: float = 2.0) -> AnnualizedProjection:
    """
    Project forward spending with decomposed components.
    
    Enables: "If we negotiate 5% reduction, how much do we save over 5 years
    considering volume growth and remaining escalators?"
    """
    base = get_annual_spend(provider_id)
    escalators = get_escalator_terms(provider_id)
    
    projections = []
    for year in range(1, years + 1):
        # Rate component: base rate + negotiated change
        rate_factor = (1 + rate_change_pct / 100) if year == 1 else 1.0
        
        # Escalation component: contractual increases
        esc_factor = compute_escalation_factor(escalators, year)
        
        # Volume component: utilization trend
        vol_factor = (1 + volume_trend_pct / 100) ** year
        
        # Compound
        year_spend = base * rate_factor * esc_factor * vol_factor
        
        projections.append(YearProjection(
            year=year,
            projected_spend=year_spend,
            rate_component=base * rate_factor - base,
            volume_component=base * vol_factor - base,
            escalation_component=base * esc_factor - base,
            mix_component=0  # Populated from claims trend if available
        ))
    
    status_quo = sum(
        project_year(base, escalators, volume_trend_pct, yr, rate_change=0)
        for yr in range(1, years + 1)
    )
    post_neg = sum(p.projected_spend for p in projections)
    
    return AnnualizedProjection(
        provider_id=provider_id,
        base_year_spend=base,
        projections=projections,
        status_quo=status_quo,
        post_negotiation=post_neg,
        cumulative_savings=status_quo - post_neg
    )
```

---

## 5. FINANCIAL DEFENSIBILITY FRAMEWORK

### 5.1 Every Number Must Be Explainable

```python
@dataclass
class DefensibleMetric:
    """A metric that can be explained, audited, and defended."""
    value: float
    unit: str                          # "$", "%", "days", "cases"
    label: str                         # Human-readable name
    
    # Explainability
    formula: str                       # How it was computed
    inputs: Dict[str, float]           # Named inputs to the formula
    source_tables: List[str]           # Which tables contributed
    
    # Auditability
    computation_date: datetime
    data_freshness: str                # "Claims through 2025-04"
    sample_size: int                   # How many data points
    
    # Confidence
    confidence_interval: Tuple[float, float]  # 95% CI
    data_completeness: float           # % of expected data present
    known_limitations: List[str]       # Caveats
    
    def explain(self) -> str:
        """Generate human-readable explanation."""
        return (
            f"{self.label}: {self.format_value()}\n"
            f"Formula: {self.formula}\n"
            f"Inputs: {', '.join(f'{k}={v}' for k, v in self.inputs.items())}\n"
            f"Based on: {self.sample_size} data points, data through {self.data_freshness}\n"
            f"95% CI: [{self.confidence_interval[0]:.2f}, {self.confidence_interval[1]:.2f}]\n"
            f"Limitations: {'; '.join(self.known_limitations) if self.known_limitations else 'None'}"
        )
```

### 5.2 Audit Trail Requirements

Every analytics output must include:

| Requirement | Implementation |
| --- | --- |
| Data lineage | Which source tables, which time period, which filters |
| Methodology | Formula used, weights applied, benchmark definition |
| Assumptions | Volume growth rate, CPI forecast, acuity trends |
| Sensitivity | How result changes with ±10% in key assumptions |
| Known gaps | Missing claims months, providers without utilization data |
| Approval chain | Who validated methodology, when approved for use |

---

## 6. GRACEFUL DEGRADATION: NO-CLAIMS MODE

### 6.1 Estimated Volume When Claims Are Unavailable

```python
def estimate_volume_without_claims(provider_id: str, service_line: str) -> EstimatedVolume:
    """
    When claims data isn't available, estimate volume from:
    1. Provider profile (bed count, annual admits from publicly available data)
    2. Market averages for provider type/size
    3. Contracted rate structure hints (stop-loss thresholds suggest volume)
    """
    profile = get_provider_profile(provider_id)
    
    # Method 1: Public utilization data (hospital compare, OSHPD/HCAI)
    if profile.annual_discharges:
        market_share = estimate_bsc_market_share(profile.county)
        estimated_cases = profile.annual_discharges * market_share
        return EstimatedVolume(cases=estimated_cases, source='public_data', confidence=0.6)
    
    # Method 2: Stop-loss threshold implies expected spend level
    stop_loss = get_stop_loss(provider_id)
    if stop_loss and stop_loss.attachment_level:
        # If stop-loss is at $75K, expected annual spend ≈ 2-3x attachment
        estimated_spend = stop_loss.attachment_level * 2.5
        rate = get_contracted_rate(provider_id, service_line)
        if rate:
            estimated_cases = estimated_spend / rate
            return EstimatedVolume(cases=int(estimated_cases), source='stop_loss_inference', confidence=0.4)
    
    # Method 3: Market average for provider type
    avg_volume = get_market_avg_volume(profile.provider_type, service_line)
    return EstimatedVolume(cases=avg_volume, source='market_average', confidence=0.3)
```

---

## 7. ANALYTICS OUTPUT TABLES

### 7.1 Benchmark Results (Computed)

```sql
CREATE TABLE IF NOT EXISTS dev_adb.raw.tbl_intel_benchmark_results (
    -- Keys
    service_line_code       STRING NOT NULL COMMENT 'FK to dim_service_line_taxonomy',
    analysis_period         STRING NOT NULL COMMENT 'Analysis period identifier',
    program                 STRING COMMENT 'Commercial | Medicare | Medi-Cal | All',
    
    -- Benchmark distribution
    p10_rate                FLOAT COMMENT '10th percentile rate (best rates in market)',
    p25_rate                FLOAT COMMENT '25th percentile (aggressive target)',
    median_rate             FLOAT COMMENT 'Median rate (standard target)',
    mean_rate               FLOAT COMMENT 'Volume-weighted mean rate',
    p75_rate                FLOAT COMMENT '75th percentile (above average)',
    p90_rate                FLOAT COMMENT '90th percentile (highest rates)',
    
    -- Context
    provider_count          INT COMMENT 'Number of providers in benchmark set',
    total_cases             INT COMMENT 'Total cases across benchmark set',
    total_spend             FLOAT COMMENT 'Total spend across benchmark set',
    
    -- Medicare reference
    medicare_rate           FLOAT COMMENT 'CMS Medicare reference rate',
    pct_of_medicare_median  FLOAT COMMENT 'Plan median as % of Medicare rate',
    
    -- Audit
    computed_at             TIMESTAMP COMMENT 'When benchmarks were computed'
) USING DELTA
COMMENT 'Service-line benchmarks computed from claims/rate data. Updated monthly.'
TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true', 'delta.columnMapping.mode' = 'name');
```

### 7.2 Savings Opportunity Detail

```sql
CREATE TABLE IF NOT EXISTS dev_adb.raw.tbl_intel_savings_opportunity (
    -- Keys
    provider_id             STRING NOT NULL COMMENT 'Provider ID',
    service_line_code       STRING NOT NULL COMMENT 'Service line code',
    analysis_period         STRING NOT NULL COMMENT 'Analysis period',
    
    -- Current state
    current_rate            FLOAT COMMENT 'Current effective rate (from claims or contract)',
    current_volume          INT COMMENT 'Annual volume (cases or days)',
    current_annual_spend    FLOAT COMMENT 'rate × volume',
    
    -- Benchmark targets
    target_rate_median      FLOAT COMMENT 'Peer median target rate',
    target_rate_p25         FLOAT COMMENT 'Aggressive (p25) target rate',
    
    -- Savings at each target
    savings_to_median       FLOAT COMMENT 'Annual $ saved at median',
    savings_to_p25          FLOAT COMMENT 'Annual $ saved at p25',
    pct_reduction_to_median FLOAT COMMENT '% rate reduction needed for median',
    
    -- Ranking
    savings_rank            INT COMMENT 'Rank by savings opportunity (1=highest)',
    pct_of_total_opportunity FLOAT COMMENT 'This line as % of total provider savings',
    cumulative_pct          FLOAT COMMENT 'Cumulative % (for Pareto analysis)',
    
    -- Audit
    computed_at             TIMESTAMP COMMENT 'When this was computed'
) USING DELTA
COMMENT 'Granular savings opportunity by provider and service line. Supports Pareto-based negotiation targeting.'
TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true', 'delta.columnMapping.mode' = 'name');
```

---

*Spend-weighted analytics is the mathematical foundation for every other intelligence capability. Without volume context, rates are abstract numbers. With it, they become dollars — and dollars drive decisions.*
