# NEGOTIATION INTELLIGENCE V2
## Spend-Weighted, Claims-Integrated Contract Negotiation Analytics

**Document Class:** Business Intelligence Architecture  
**Date:** 2026-05-22  
**Scope:** Replace rate-comparison-only analytics with financially defensible negotiation intelligence  
**Consumers:** Provider Contracting, Network Management, Finance  

---

## 1. CURRENT STATE DEFICIENCIES

### 1.1 What Exists (Notebooks 20-25)

Current intelligence capabilities:
- Rate benchmarking: Compare rate_numeric across providers (unweighted)
- Amendment timeline: Chronological list of amendments
- Expiration tracking: Days-to-expiry grouping
- Peer cohort: Similar providers by service mix
- Composite scoring: Weighted score from coverage, rates, complexity

### 1.2 What's Missing for Enterprise Negotiation

| Gap | Business Impact | Severity |
| --- | --- | --- |
| No spend weighting | A $50 rate difference on 10 annual cases ≠ $50 on 5,000 cases | CRITICAL |
| No claims integration | Cannot compute actual vs contracted, cannot quantify savings | CRITICAL |
| No concession modeling | Cannot model "if we give 3% on inpatient, what do we need on outpatient?" | HIGH |
| No escalation analysis | Cannot project Year 3 cost from Year 1 base + escalator formula | HIGH |
| No market positioning | Don't know if our rates are at p25, p50, or p75 of market | HIGH |
| No leverage scoring | Don't know which providers have negotiating power vs which don't | MEDIUM |
| No scenario simulation | Cannot answer "what if we move 20% of volume to Provider B?" | HIGH |
| Flat benchmarking | Compares raw rates without adjusting for acuity, case mix, or geography | MEDIUM |

### 1.3 The Fundamental Problem

**Current:** "Provider X's Med/Surg per diem is $1,500 vs peer average of $1,350."  
**What contracting needs:** "Provider X's Med/Surg per diem costs us $4.2M annually (2,800 cases × $1,500). Moving to peer median would save $420K/year. However, Provider X handles 34% of our ICU volume in this service area — replacement risk is HIGH. Recommended strategy: target 5% reduction ($75/day) in exchange for 2-year term extension, yielding $210K savings with acceptable disruption risk."

---

## 2. V2 ARCHITECTURE: SPEND-WEIGHTED NEGOTIATION INTELLIGENCE

### 2.1 Data Integration Model

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                  NEGOTIATION INTELLIGENCE DATA FLOW                           │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                               │
│  CONTRACT DATA              CLAIMS/UTILIZATION           EXTERNAL             │
│  (internal — exists)        (integration needed)         (market data)        │
│                                                                               │
│  ┌─────────────────┐       ┌─────────────────┐        ┌────────────────┐   │
│  │ tbl_reimb_       │       │ claims_summary   │        │ market_rates   │   │
│  │   rate_rules     │       │ (paid, allowed,  │        │ (CMS, FAIR    │   │
│  │ tbl_reimb_       │       │  units, cases)   │        │  Health,       │   │
│  │   stop_loss      │       ├─────────────────┤        │  state avg)    │   │
│  │ tbl_reimb_       │       │ utilization      │        ├────────────────┤   │
│  │   escalators     │       │ (admits, days,   │        │ geo_factors    │   │
│  │ dim_service_     │       │  visits, members)│        │ (GPCI, wage    │   │
│  │   line_taxonomy  │       ├─────────────────┤        │  index, COL)   │   │
│  └────────┬─────────┘       │ membership       │        └───────┬────────┘   │
│           │                 │ (lives, pmpm     │                │             │
│           │                 │  budget, mix)    │                │             │
│           │                 └────────┬─────────┘                │             │
│           │                          │                          │             │
│           └────────────────┬─────────┘──────────────────────────┘             │
│                            ▼                                                  │
│              ┌──────────────────────────┐                                    │
│              │  SPEND-WEIGHTED           │                                    │
│              │  ANALYTICS ENGINE         │                                    │
│              │                           │                                    │
│              │  • Annual spend per line  │                                    │
│              │  • Savings opportunity    │                                    │
│              │  • Negotiation targets    │                                    │
│              │  • Concession modeling    │                                    │
│              │  • Risk-adjusted ranking  │                                    │
│              └──────────────────────────┘                                    │
│                                                                               │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 2.2 Core Principle: Every Metric Is Dollarized

| Metric Type | V1 (Current) | V2 (Target) |
| --- | --- | --- |
| Rate comparison | "$1,500 vs $1,350 peer avg" | "$420K annual overspend on Med/Surg (2,800 cases × $150 delta)" |
| Escalation | "3% annual increase" | "$126K Year-1 → $163K Year-5 cumulative escalation cost" |
| Stop-loss | "$75,000 threshold" | "4 cases/year trigger stop-loss, saving $312K vs uncapped" |
| Carve-out | "Implants at cost + 10%" | "$890K annual implant spend, $81K markup captured" |
| Lesser-of | "Lesser of charges or contracted" | "Lesser-of saved $1.2M (23% of gross charges)" |

---

## 3. NEGOTIATION SCORING MODEL

### 3.1 Provider Negotiation Score

```python
@dataclass
class NegotiationScore:
    """Composite score driving negotiation priority and strategy."""
    provider_id: str
    provider_name: str
    
    # Financial (weight: 40%)
    total_annual_spend: float           # Total $ paid to this provider
    spend_vs_benchmark_pct: float       # +15% = 15% above benchmark
    savings_opportunity: float          # $ recoverable at benchmark rates
    escalation_exposure: float          # Projected 3-year cost increase
    
    # Strategic (weight: 30%)
    leverage_score: float               # 0-1: our leverage in negotiation
    dependency_score: float             # 0-1: how dependent are we on them
    replacement_difficulty: float       # 0-1: how hard to move volume away
    contract_term_remaining_days: int   # Urgency of action
    
    # Operational (weight: 20%)
    quality_score: float                # Claims denial rate, readmission, etc.
    administrative_burden: float        # Auth requirements, payment disputes
    member_disruption_risk: float       # Members who'd need new provider
    
    # Market (weight: 10%)
    market_rate_percentile: float       # Where they sit in market distribution
    competitor_alternatives: int        # How many alternatives exist in area
    geographic_monopoly: bool           # Sole provider in service area
    
    @property
    def composite_score(self) -> float:
        """0-100 composite: higher = more negotiation opportunity."""
        financial = (
            min(self.spend_vs_benchmark_pct / 30 * 100, 100) * 0.5 +  # Overspend
            min(self.savings_opportunity / 1_000_000 * 20, 100) * 0.3 +  # $ opportunity
            min(self.escalation_exposure / 500_000 * 20, 100) * 0.2   # Escalation risk
        ) * 0.40
        
        strategic = (
            self.leverage_score * 100 * 0.4 +
            (1 - self.dependency_score) * 100 * 0.3 +  # Low dependency = easier negotiation
            (1 - self.replacement_difficulty) * 100 * 0.3
        ) * 0.30
        
        operational = (
            (1 - self.quality_score) * 100 * 0.4 +  # Low quality = negotiation leverage
            self.administrative_burden * 100 * 0.3 +
            (1 - self.member_disruption_risk) * 100 * 0.3
        ) * 0.20
        
        market = (
            self.market_rate_percentile * 0.6 +  # Higher percentile = more room to negotiate
            min(self.competitor_alternatives / 5 * 100, 100) * 0.4
        ) * 0.10
        
        return financial + strategic + operational + market
    
    @property
    def recommended_strategy(self) -> str:
        if self.geographic_monopoly:
            return "CONTAIN"  # Cannot replace; focus on limiting increases
        elif self.savings_opportunity > 500_000 and self.leverage_score > 0.6:
            return "AGGRESSIVE_REDUCTION"  # High savings, high leverage
        elif self.savings_opportunity > 200_000 and self.leverage_score > 0.4:
            return "MODERATE_REDUCTION"  # Target benchmark alignment
        elif self.contract_term_remaining_days < 180:
            return "URGENT_RENEWAL"  # Time pressure
        elif self.escalation_exposure > 300_000:
            return "ESCALATION_CAP"  # Focus on future cost containment
        else:
            return "MAINTAIN"  # Low priority, maintain current terms
```

### 3.2 Service-Line Negotiation Analysis

```python
@dataclass
class ServiceLineNegotiation:
    """Per-service-line analysis for targeted negotiation."""
    provider_id: str
    service_line: str           # From dim_service_line_taxonomy
    
    # Volume
    annual_cases: int
    annual_days: int            # For per-diem calculations
    annual_visits: int          # For outpatient
    
    # Spend
    contracted_rate: float      # Per-unit rate
    total_annual_spend: float   # cases × rate (or days × rate)
    pct_of_provider_spend: float  # This line as % of total provider spend
    
    # Benchmarking
    peer_median_rate: float
    peer_p25_rate: float        # Aggressive target
    peer_p75_rate: float
    market_median_rate: float
    medicare_rate: float        # CMS reference rate
    
    # Savings analysis
    savings_to_median: float    # $ saved if move to peer median
    savings_to_p25: float       # $ saved if move to p25 (aggressive)
    savings_pct: float          # % reduction to reach median
    
    # Negotiation positioning
    rate_percentile: float      # Where this rate sits among peers (0-100)
    is_above_median: bool
    spread_from_median_pct: float  # +12% = 12% above peer median
```

---

## 4. CONCESSION MODELING

### 4.1 Trade-Off Framework

Negotiations involve concessions. The system must model multi-dimensional trade-offs:

```python
@dataclass
class ConcessionScenario:
    """Model: 'If we concede X, what must we gain on Y to break even?'"""
    provider_id: str
    
    # What we're giving
    concessions: List[Concession]  # Things we offer the provider
    
    # What we're getting
    gains: List[Gain]              # Things we demand in return
    
    # Net financial impact
    net_annual_impact: float       # Positive = net savings for plan
    break_even_threshold: float    # What gain level makes this neutral
    
    # Risk assessment
    probability_of_acceptance: float  # 0-1: likelihood provider accepts
    provider_value_perception: float  # 0-1: how much provider values our concession

@dataclass
class Concession:
    """Something we offer to the provider."""
    concession_type: str          # RATE_INCREASE | TERM_EXTENSION | VOLUME_GUARANTEE |
                                  # ADMIN_SIMPLIFICATION | FASTER_PAYMENT | EXCLUSIVITY
    service_line: Optional[str]   # Which service line (or None for all)
    value_to_provider: float      # Estimated annual $ value to provider
    cost_to_plan: float          # Annual $ cost to us
    description: str

@dataclass
class Gain:
    """Something we demand from the provider."""
    gain_type: str               # RATE_REDUCTION | ESCALATION_CAP | QUALITY_BONUS |
                                 # STOP_LOSS_IMPROVEMENT | CARVE_OUT_TERMS | VOLUME_DISCOUNT
    service_line: Optional[str]
    value_to_plan: float         # Annual $ value to us
    cost_to_provider: float      # Annual $ cost to provider
    description: str
```

### 4.2 Common Negotiation Trades

| We Concede | We Gain | Financial Logic |
| --- | --- | --- |
| 2% rate increase on low-volume lines ($30K) | 5% reduction on high-volume lines ($180K) | Net: +$150K savings |
| 3-year term (vs 1-year) | Rate lock (no escalator) | Avoid $90K/yr escalation × 2 yrs = $180K |
| Volume guarantee (80% of admits) | Tier pricing at volume thresholds | 8% discount above 2,000 cases = $240K |
| Faster payment (15 days vs 30) | 1% prompt-pay discount | $82K annual savings |
| Reduce prior-auth requirements | Quality withhold (2% at-risk) | Admin savings $45K + quality incentive |
| Exclusive network status | 10% rate reduction across all lines | $1.2M savings but network flexibility lost |

### 4.3 Concession Evaluation Engine

```python
def evaluate_concession_package(scenario: ConcessionScenario,
                                 claims_data: DataFrame) -> ConcessionResult:
    """
    Compute net financial impact of a concession package.
    Uses actual claims volume to weight each trade-off.
    """
    # Cost of concessions (what we give)
    total_concession_cost = 0
    for c in scenario.concessions:
        if c.concession_type == 'RATE_INCREASE':
            # Weight by actual volume on that service line
            volume = get_annual_volume(scenario.provider_id, c.service_line, claims_data)
            total_concession_cost += c.value_pct_increase * volume.annual_spend
        elif c.concession_type == 'TERM_EXTENSION':
            # Cost = foregoing renegotiation opportunity for N years
            # Estimate: could save 3-5% at next negotiation
            total_concession_cost += 0.04 * get_total_spend(scenario.provider_id)
        elif c.concession_type == 'VOLUME_GUARANTEE':
            # Cost = lost flexibility to redirect volume
            total_concession_cost += estimate_volume_lock_cost(scenario.provider_id, c)
    
    # Value of gains (what we get)
    total_gain_value = 0
    for g in scenario.gains:
        if g.gain_type == 'RATE_REDUCTION':
            volume = get_annual_volume(scenario.provider_id, g.service_line, claims_data)
            total_gain_value += g.value_pct_reduction * volume.annual_spend
        elif g.gain_type == 'ESCALATION_CAP':
            # Value = avoided escalation over remaining term
            total_gain_value += compute_escalation_savings(scenario.provider_id, g)
        elif g.gain_type == 'STOP_LOSS_IMPROVEMENT':
            # Value = reduced high-cost case exposure
            total_gain_value += compute_stop_loss_savings(scenario.provider_id, g, claims_data)
    
    return ConcessionResult(
        net_annual_impact=total_gain_value - total_concession_cost,
        roi=total_gain_value / max(total_concession_cost, 1),
        concession_cost=total_concession_cost,
        gain_value=total_gain_value,
        break_even_pct=total_concession_cost / get_total_spend(scenario.provider_id) * 100
    )
```

---

## 5. NEGOTIATION PREPARATION PACKAGE

### 5.1 Auto-Generated Negotiation Brief

For each provider approaching renewal, auto-generate:

```python
@dataclass
class NegotiationBrief:
    """Complete preparation package for a contract negotiation."""
    provider_id: str
    provider_name: str
    generated_at: datetime
    
    # Executive Summary
    total_annual_spend: float
    spend_rank: int                 # Rank among all providers (1 = highest spend)
    savings_opportunity: float      # $ at stake
    recommended_strategy: str
    key_message: str               # "Target 5% Med/Surg reduction, offer term extension"
    
    # Rate Analysis
    service_line_analysis: List[ServiceLineNegotiation]
    top_savings_lines: List[str]   # Top 3 lines by savings opportunity
    rate_vs_peer: Dict[str, float] # Service line → % above/below peer median
    
    # Historical Context
    amendment_history: List[dict]   # Timeline of rate changes
    escalation_pattern: str         # "3% annual" | "CPI-linked" | "Step schedule"
    years_since_last_negotiation: float
    prior_concessions_given: List[str]  # What we conceded last time
    
    # Leverage Assessment
    leverage_score: float
    leverage_factors: List[str]    # ["Multiple alternatives in area", "Low member disruption"]
    risk_factors: List[str]        # ["Sole cardiac surgery provider", "High member loyalty"]
    
    # Recommended Targets
    target_scenarios: List[ConcessionScenario]  # 3 scenarios: aggressive, moderate, conservative
    walk_away_threshold: float     # Rate above which we should consider termination
    
    # Supporting Evidence
    peer_comparison_data: DataFrame
    market_rate_references: Dict[str, float]
    claims_volume_summary: DataFrame
```

### 5.2 Negotiation Simulation Output

```
╔══════════════════════════════════════════════════════════════════════════╗
║  NEGOTIATION BRIEF: Providence Health System                             ║
║  Annual Spend: $18.4M | Rank: #3 | Savings Opportunity: $1.8M          ║
╠══════════════════════════════════════════════════════════════════════════╣
║                                                                          ║
║  TOP SAVINGS OPPORTUNITIES (by annual $ impact):                         ║
║  ┌──────────────────────┬────────┬──────────┬────────────┬────────────┐ ║
║  │ Service Line         │ Rate   │ Peer Med │ Volume     │ Savings    │ ║
║  ├──────────────────────┼────────┼──────────┼────────────┼────────────┤ ║
║  │ Med/Surg Per Diem    │ $1,500 │ $1,320   │ 2,800 days │ $504,000   │ ║
║  │ ICU Per Diem         │ $3,200 │ $2,950   │ 890 days   │ $222,500   │ ║
║  │ OP Surgery Tier 5    │ $4,800 │ $4,100   │ 420 cases  │ $294,000   │ ║
║  │ OP Surgery Tier 3    │ $2,900 │ $2,600   │ 680 cases  │ $204,000   │ ║
║  └──────────────────────┴────────┴──────────┴────────────┴────────────┘ ║
║                                                                          ║
║  RECOMMENDED SCENARIOS:                                                  ║
║  A) Aggressive: 8% across-the-board → saves $1.47M (risk: termination) ║
║  B) Moderate: 5% inpatient + 3% outpatient → saves $920K               ║
║  C) Conservative: escalation cap (2%) + stop-loss improvement → $340K  ║
║                                                                          ║
║  LEVERAGE: 0.72 (FAVORABLE)                                             ║
║  • 3 competing systems within 15 miles                                  ║
║  • 12% of their revenue comes from BSC                                  ║
║  • Low member disruption (4,200 attributed members, 2 alternatives)     ║
║                                                                          ║
║  RISK FACTORS:                                                           ║
║  • Sole Level 1 trauma center in service area                           ║
║  • High cardiac surgery volume (no easy redirect)                       ║
║                                                                          ║
╚══════════════════════════════════════════════════════════════════════════╝
```

---

## 6. IMPLEMENTATION: TABLES

### 6.1 Spend-Weighted Provider Summary

```sql
CREATE TABLE IF NOT EXISTS dev_adb.raw.tbl_intel_provider_spend_summary (
    -- Identity
    provider_id             STRING NOT NULL COMMENT 'Provider ID',
    provider_name           STRING NOT NULL COMMENT 'Canonical provider name',
    analysis_period         STRING NOT NULL COMMENT 'Fiscal year or rolling 12mo: FY2025, R12M_202505',
    
    -- Total spend
    total_paid_amount       FLOAT COMMENT 'Total dollars paid in analysis period',
    total_allowed_amount    FLOAT COMMENT 'Total allowed amount before member cost-share',
    total_billed_amount     FLOAT COMMENT 'Total billed charges',
    pct_of_plan_spend       FLOAT COMMENT 'This providers % of total plan spend',
    spend_rank              INT COMMENT 'Rank by spend (1 = highest)',
    
    -- Volume
    total_cases             INT COMMENT 'Total unique cases/encounters',
    total_member_months     INT COMMENT 'Member months attributed to this provider',
    unique_members          INT COMMENT 'Distinct members using this provider',
    
    -- Service mix
    inpatient_spend         FLOAT COMMENT 'Inpatient total paid',
    outpatient_spend        FLOAT COMMENT 'Outpatient total paid',
    professional_spend      FLOAT COMMENT 'Professional services total paid',
    capitation_spend        FLOAT COMMENT 'Capitation payments total',
    inpatient_pct           FLOAT COMMENT 'IP as % of total spend',
    
    -- Benchmarking
    spend_vs_benchmark_pct  FLOAT COMMENT '% above/below benchmark (+ = overspend)',
    savings_opportunity     FLOAT COMMENT '$ savings if moved to benchmark rates',
    market_rate_percentile  FLOAT COMMENT 'Where rates sit in market (0-100)',
    
    -- Contract status
    contract_expiry_date    DATE COMMENT 'Current contract expiration',
    days_to_expiry          INT COMMENT 'Days until contract expires',
    escalation_exposure     FLOAT COMMENT 'Projected 3-year escalation cost',
    
    -- Negotiation scoring
    negotiation_score       FLOAT COMMENT 'Composite negotiation priority score (0-100)',
    recommended_strategy    STRING COMMENT 'AGGRESSIVE_REDUCTION | MODERATE | CONTAIN | MAINTAIN',
    leverage_score          FLOAT COMMENT 'Our leverage in negotiation (0-1)',
    
    -- Audit
    computed_at             TIMESTAMP COMMENT 'When this analysis was last computed'
) USING DELTA
COMMENT 'Provider-level spend summary with negotiation scoring. Refreshed monthly.'
TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true', 'delta.columnMapping.mode' = 'name');
-- Z-ORDER: OPTIMIZE ZORDER BY (spend_rank, provider_id)
```

### 6.2 Service-Line Negotiation Detail

```sql
CREATE TABLE IF NOT EXISTS dev_adb.raw.tbl_intel_service_line_spend (
    -- Identity
    provider_id             STRING NOT NULL COMMENT 'Provider ID',
    service_line_code       STRING NOT NULL COMMENT 'FK to dim_service_line_taxonomy',
    analysis_period         STRING NOT NULL COMMENT 'Analysis period identifier',
    
    -- Volume
    annual_cases            INT COMMENT 'Cases/encounters in period',
    annual_days             INT COMMENT 'Inpatient days (for per-diem lines)',
    annual_visits           INT COMMENT 'Visits (for outpatient lines)',
    avg_los                 FLOAT COMMENT 'Average length of stay',
    avg_acuity              FLOAT COMMENT 'Average case mix / DRG weight',
    
    -- Rates (contracted)
    contracted_rate         FLOAT COMMENT 'Per-unit contracted rate',
    contracted_rate_unit    STRING COMMENT 'day | case | visit | procedure',
    effective_date          DATE COMMENT 'Rate effective date',
    
    -- Spend
    total_spend             FLOAT COMMENT 'Total paid for this service line',
    pct_of_provider_spend   FLOAT COMMENT 'This line as % of provider total',
    avg_cost_per_case       FLOAT COMMENT 'Total spend / cases',
    
    -- Benchmarking
    peer_median_rate        FLOAT COMMENT 'Median rate among peer providers',
    peer_p25_rate           FLOAT COMMENT '25th percentile (aggressive target)',
    peer_p75_rate           FLOAT COMMENT '75th percentile',
    market_median_rate      FLOAT COMMENT 'Broader market median',
    medicare_reference_rate FLOAT COMMENT 'CMS Medicare rate for reference',
    rate_percentile         FLOAT COMMENT 'Percentile rank of this rate (0-100)',
    
    -- Savings
    savings_to_median       FLOAT COMMENT '$ saved annually if moved to peer median',
    savings_to_p25          FLOAT COMMENT '$ saved if moved to p25 (aggressive)',
    savings_pct_to_median   FLOAT COMMENT '% reduction needed to reach median',
    
    -- Audit
    computed_at             TIMESTAMP COMMENT 'When this row was computed'
) USING DELTA
COMMENT 'Service-line-level spend and benchmark analysis per provider. Foundation for negotiation targets.'
TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true', 'delta.columnMapping.mode' = 'name');
-- Z-ORDER: OPTIMIZE ZORDER BY (provider_id, service_line_code)
```

---

## 7. CLAIMS DATA INTEGRATION STRATEGY

### 7.1 Required Claims Feed (Minimum Viable)

The intelligence engine does NOT require raw claims — only pre-aggregated summaries:

```sql
-- INPUT: Expected feed from claims warehouse (or manual upload)
-- Granularity: provider × service_line × month
CREATE TABLE IF NOT EXISTS dev_adb.raw.tbl_claims_summary_feed (
    provider_id         STRING NOT NULL COMMENT 'Provider TIN or BSC ID',
    service_line_code   STRING NOT NULL COMMENT 'Service line (mapped to taxonomy)',
    month_year          STRING NOT NULL COMMENT 'YYYY-MM',
    
    -- Volume
    case_count          INT COMMENT 'Number of cases/encounters',
    total_days          INT COMMENT 'Inpatient days',
    total_visits        INT COMMENT 'Outpatient visits',
    unique_members      INT COMMENT 'Distinct members',
    
    -- Financial
    total_billed        FLOAT COMMENT 'Total billed charges',
    total_allowed       FLOAT COMMENT 'Total allowed amount',
    total_paid          FLOAT COMMENT 'Total paid (plan + member)',
    plan_paid           FLOAT COMMENT 'Plan-paid portion',
    member_cost_share   FLOAT COMMENT 'Member copay + coinsurance + deductible',
    
    -- Quality indicators
    denial_count        INT COMMENT 'Number of denied claims',
    readmit_count       INT COMMENT 'Readmissions within 30 days',
    avg_drg_weight      FLOAT COMMENT 'Average DRG weight (acuity proxy)'
) USING DELTA
COMMENT 'Monthly claims summary feed. Minimum data needed for spend-weighted analytics.';
```

### 7.2 Graceful Degradation Without Claims

If claims data is unavailable, the system degrades gracefully:

| Capability | With Claims | Without Claims |
| --- | --- | --- |
| Spend weighting | Actual $ by service line | Estimated from rate × market avg volume |
| Savings projections | Precise annual impact | Directional ("$X per unit above median") |
| Volume-weighted percentile | Exact position | Equal-weight position only |
| Case-mix adjustment | DRG-weight adjusted | Not adjusted (raw rate only) |
| Concession modeling | Exact $ trade-offs | Approximate ranges |

---

## 8. PERFORMANCE TARGETS

| Metric | Target | Measurement |
| --- | --- | --- |
| Negotiation score accuracy | >80% correlation with actual savings achieved | Back-test against prior negotiations |
| Savings projection accuracy | ±15% of actual realized savings | Compare projection to post-renegotiation spend |
| Brief generation time | <30 seconds per provider | End-to-end from query to formatted output |
| Coverage | 100% of top-50 providers by spend | All must have complete analysis |
| Refresh frequency | Monthly (aligned with claims close) | Automated pipeline trigger |

---

*Negotiation intelligence V2 transforms contract analytics from "what are the rates?" to "what should we do about the rates, what's it worth, and how do we execute?" Every metric is dollarized, volume-weighted, and actionable.*
