# CONTRACT LEVERAGE FRAMEWORK
## Provider Dependency, Market Position, and Negotiating Power Assessment

**Document Class:** Strategic Analytics Architecture  
**Date:** 2026-05-22  
**Scope:** Quantify relative negotiating power between Blue Shield and each provider  
**Key Question:** "For each provider, who needs whom more — and by how much?"  

---

## 1. WHAT IS LEVERAGE?

### 1.1 Definition

**Leverage** = the relative ability to obtain favorable terms in negotiation.

In provider contracting, leverage is determined by:
- **Substitutability**: Can we send volume elsewhere? Can they get other payers?
- **Dependency**: What % of their revenue comes from us? What % of our network depends on them?
- **Alternatives**: How many functionally equivalent providers exist in the service area?
- **Consequences**: What happens to each party if the contract terminates?

### 1.2 Leverage Is Not Fixed

Leverage shifts based on:
- Time (approaching renewal = less leverage for the urgent party)
- Market events (competitor closure increases provider's leverage)
- Regulatory changes (network adequacy requirements)
- Volume trends (growing membership increases plan's leverage)
- Quality data (poor quality data reduces provider's leverage)

---

## 2. LEVERAGE SCORING MODEL

### 2.1 Dual-Perspective Scoring

```python
@dataclass
class LeverageAssessment:
    """Bilateral leverage assessment: Plan vs Provider."""
    provider_id: str
    provider_name: str
    
    # PLAN'S LEVERAGE (our advantages)
    plan_leverage: PlanLeverage
    
    # PROVIDER'S LEVERAGE (their advantages)  
    provider_leverage: ProviderLeverage
    
    # NET POSITION
    @property
    def net_leverage_score(self) -> float:
        """
        -1.0 to +1.0
        Positive = plan has more leverage (favorable)
        Negative = provider has more leverage (unfavorable)
        Zero = balanced
        """
        return self.plan_leverage.score - self.provider_leverage.score
    
    @property
    def leverage_label(self) -> str:
        score = self.net_leverage_score
        if score > 0.4:
            return "STRONG PLAN LEVERAGE"
        elif score > 0.1:
            return "MODERATE PLAN LEVERAGE"
        elif score > -0.1:
            return "BALANCED"
        elif score > -0.4:
            return "MODERATE PROVIDER LEVERAGE"
        else:
            return "STRONG PROVIDER LEVERAGE"
    
    @property
    def strategic_implication(self) -> str:
        score = self.net_leverage_score
        if score > 0.3:
            return "Pursue aggressive rate reduction. Provider needs us more than we need them."
        elif score > 0:
            return "Target moderate improvements. Balanced position favors incremental gains."
        elif score > -0.3:
            return "Focus on containment. Avoid escalation-heavy terms. Offer stability."
        else:
            return "Defensive posture. Prioritize retention and relationship. Minimize disruption risk."
```

### 2.2 Plan Leverage Components

```python
@dataclass
class PlanLeverage:
    """Factors that give the health plan negotiating power."""
    
    # Revenue dependency: what % of provider's revenue comes from us?
    revenue_share_of_provider: float  # 0-1: 0.20 = we're 20% of their revenue
    
    # Volume leverage: can we credibly redirect volume?
    volume_redirectability: float     # 0-1: how easily we can move volume away
    alternative_count: int            # Number of in-network alternatives
    alternative_capacity: float       # 0-1: do alternatives have capacity?
    
    # Market position: how dominant is BSC in this area?
    market_share_in_area: float       # BSC lives / total commercial lives
    membership_growth: float          # YoY membership growth (growing = more leverage)
    
    # Contractual: what terms favor us?
    termination_notice_days: int      # Shorter = more flexibility
    non_compete_restrictions: bool    # Provider has non-compete
    performance_withhold_pct: float   # % of payment at risk for quality
    
    # Quality data: objective performance issues
    denial_rate: float                # Higher = more leverage
    readmission_rate: float           # Higher = more leverage
    quality_score_vs_peers: float     # Lower = more leverage for plan
    
    @property
    def score(self) -> float:
        """0-1 composite plan leverage score."""
        components = [
            min(self.revenue_share_of_provider / 0.3, 1.0) * 0.25,  # Revenue dep
            self.volume_redirectability * 0.20,                        # Redirect ability
            min(self.market_share_in_area / 0.4, 1.0) * 0.15,        # Market position
            min(self.alternative_count / 5, 1.0) * 0.15,              # Alternatives
            (1 - self.quality_score_vs_peers) * 0.15,                  # Quality leverage
            min(self.denial_rate / 0.10, 1.0) * 0.10,                 # Denial leverage
        ]
        return sum(components)
```

### 2.3 Provider Leverage Components

```python
@dataclass
class ProviderLeverage:
    """Factors that give the provider negotiating power."""
    
    # Network essentiality: how critical are they to our network?
    is_sole_community_provider: bool   # Only hospital in area
    sole_service_lines: List[str]      # Services where they're the only option
    network_adequacy_critical: bool    # Losing them violates adequacy standards
    
    # Member attachment: how disruptive is losing them?
    attributed_members: int            # Members who primarily use this provider
    member_satisfaction_score: float   # 0-1: member loyalty
    geographic_necessity: bool         # Only option within 30 miles
    
    # Market power: are they a must-have brand?
    brand_recognition: float           # 0-1: public perception strength
    academic_medical_center: bool      # AMC status = negotiating power
    system_affiliation_size: int       # Larger system = more leverage
    payer_diversity: float             # 0-1: how diversified their payer mix is
    
    # Competitive alternatives for them: can they replace our volume?
    other_payer_growth: float          # Are other payers growing? (they need us less)
    self_funded_employer_access: bool  # Can they go direct to employers?
    
    # Regulatory: what protections do they have?
    essential_community_provider: bool # CMS-designated ECP
    trauma_center_level: int           # 1-5 (1 = highest leverage)
    teaching_hospital: bool
    
    @property
    def score(self) -> float:
        """0-1 composite provider leverage score."""
        components = [
            (0.30 if self.is_sole_community_provider else 
             min(len(self.sole_service_lines) / 5, 1.0) * 0.20) * 1.0,  # Essentiality
            min(self.attributed_members / 20000, 1.0) * 0.20,             # Member lock
            (0.15 if self.academic_medical_center else 0.05),              # Prestige
            min(self.system_affiliation_size / 20, 1.0) * 0.10,           # System size
            self.payer_diversity * 0.10,                                    # Diversification
            (0.10 if self.network_adequacy_critical else 0.02),            # Regulatory
            self.brand_recognition * 0.10,                                 # Brand
        ]
        return min(sum(components), 1.0)
```

---

## 3. PROVIDER DEPENDENCY ANALYSIS

### 3.1 Dependency Metrics

```python
@dataclass
class DependencyMetrics:
    """Quantified dependency between plan and provider."""
    provider_id: str
    
    # Plan depends on provider (higher = we need them)
    plan_dependency_score: float       # 0-1
    plan_dependency_factors: Dict[str, float]
    
    # Provider depends on plan (higher = they need us)
    provider_dependency_score: float   # 0-1
    provider_dependency_factors: Dict[str, float]
    
    # Mutual dependency ratio
    @property
    def dependency_ratio(self) -> float:
        """
        > 1.0: We depend on them MORE (unfavorable)
        < 1.0: They depend on us MORE (favorable)
        = 1.0: Balanced
        """
        return self.plan_dependency_score / max(self.provider_dependency_score, 0.01)

def compute_plan_dependency(provider_id: str) -> float:
    """How much does the plan depend on this provider?"""
    
    # Service area coverage
    coverage = compute_service_area_coverage(provider_id)
    # If losing this provider creates a geographic gap: high dependency
    gap_risk = 0.4 if coverage.creates_gap_if_removed else 0.0
    
    # Volume concentration
    total_plan_spend = get_total_plan_spend()
    provider_spend = get_provider_spend(provider_id)
    concentration = min(provider_spend / total_plan_spend / 0.05, 1.0) * 0.2
    
    # Service uniqueness
    sole_services = get_sole_provider_services(provider_id)
    uniqueness = min(len(sole_services) / 3, 1.0) * 0.25
    
    # Member impact
    members_affected = get_attributed_members(provider_id)
    total_members = get_total_members_in_area(provider_id)
    member_impact = min(members_affected / total_members / 0.15, 1.0) * 0.15
    
    return gap_risk + concentration + uniqueness + member_impact

def compute_provider_dependency(provider_id: str) -> float:
    """How much does the provider depend on BSC?"""
    
    # Revenue share: BSC payments / provider total revenue
    bsc_payments = get_annual_spend_with_provider(provider_id)
    estimated_total_revenue = estimate_provider_revenue(provider_id)
    revenue_share = min(bsc_payments / max(estimated_total_revenue, 1) / 0.25, 1.0) * 0.40
    
    # Volume share: BSC cases / provider total cases
    bsc_cases = get_annual_cases(provider_id)
    total_cases = estimate_provider_total_cases(provider_id)
    volume_share = min(bsc_cases / max(total_cases, 1) / 0.20, 1.0) * 0.25
    
    # Market dynamics: is BSC growing or shrinking in this area?
    membership_trend = get_membership_trend(provider_id)
    market_factor = 0.20 if membership_trend > 0.05 else 0.10  # Growing = they need us more
    
    # Payer alternatives: can they easily replace BSC volume?
    payer_diversity = estimate_payer_diversity(provider_id)
    alt_factor = (1 - payer_diversity) * 0.15  # Less diverse = more dependent on each payer
    
    return revenue_share + volume_share + market_factor + alt_factor
```

---

## 4. MARKET BENCHMARKING

### 4.1 Rate Positioning Analysis

```python
@dataclass
class MarketPosition:
    """Where our contracted rates sit relative to market."""
    provider_id: str
    service_line_code: str
    
    # Our rate
    bsc_rate: float
    bsc_rate_type: str              # per_diem | case_rate | percentage
    
    # Market distribution (all payers in area)
    market_p10: float               # Best rates in market
    market_p25: float
    market_median: float
    market_p75: float
    market_p90: float               # Worst rates in market
    
    # BSC position
    bsc_percentile: float           # Where we sit (0-100)
    bsc_vs_median_pct: float        # +8% = 8% above market median
    
    # Reference rates
    medicare_rate: float
    bsc_as_pct_of_medicare: float   # 120% = we pay 20% above Medicare
    
    # Peer plan comparison (other health plans)
    peer_plan_rates: List[float]    # Anonymized rates from other plans
    peer_plan_median: float
    bsc_vs_peer_plan_pct: float     # +5% = we pay 5% more than peer plans

def compute_market_position(provider_id: str, service_line: str) -> MarketPosition:
    """
    Determine market position using available data sources:
    1. Internal: All BSC contracts for same service line (peer providers)
    2. CMS: Medicare rates (public data)
    3. FAIR Health: Commercial benchmark (if licensed)
    4. State data: OSHPD/HCAI hospital financial data (California)
    """
    # Internal benchmark (always available)
    peer_rates = spark.sql("""
        SELECT rr.rate_numeric
        FROM dev_adb.raw.tbl_reimb_rate_rules rr
        WHERE rr.service_line = :service_line
          AND rr.rate_domain = :domain
          AND rr.provider_id != :provider_id
          AND rr.rate_numeric > 0
    """, params={"service_line": service_line, 
                 "domain": get_domain(service_line),
                 "provider_id": provider_id}).collect()
    
    bsc_rate = get_current_rate(provider_id, service_line)
    
    # Compute percentile position
    all_rates = sorted([r.rate_numeric for r in peer_rates])
    bsc_percentile = compute_percentile_position(bsc_rate, all_rates)
    
    return MarketPosition(
        provider_id=provider_id,
        service_line_code=service_line,
        bsc_rate=bsc_rate,
        market_p25=np.percentile(all_rates, 25),
        market_median=np.percentile(all_rates, 50),
        market_p75=np.percentile(all_rates, 75),
        bsc_percentile=bsc_percentile,
        bsc_vs_median_pct=(bsc_rate / np.median(all_rates) - 1) * 100,
        medicare_rate=get_medicare_rate(service_line),
        bsc_as_pct_of_medicare=bsc_rate / max(get_medicare_rate(service_line), 1) * 100
    )
```

---

## 5. LEVERAGE CHANGE DETECTION

### 5.1 Leverage Shift Monitoring

```python
def detect_leverage_shifts() -> List[LeverageAlert]:
    """
    Monitor for events that change leverage position.
    Run weekly to detect material changes.
    """
    alerts = []
    
    # Market events
    closed_providers = detect_provider_closures()  # Public data monitoring
    for closure in closed_providers:
        affected = find_affected_contracts(closure)
        for contract in affected:
            alerts.append(LeverageAlert(
                type="COMPETITOR_CLOSURE",
                provider_id=contract.provider_id,
                description=f"{closure.name} closed — {contract.provider_name} "
                           f"gains leverage in {closure.service_area}",
                leverage_shift=-0.15,  # Provider gains leverage
                urgency="HIGH"
            ))
    
    # Membership changes
    for provider_id in get_all_providers():
        prev_members = get_attributed_members(provider_id, period='prior_quarter')
        curr_members = get_attributed_members(provider_id, period='current')
        if curr_members > prev_members * 1.15:  # 15% growth
            alerts.append(LeverageAlert(
                type="MEMBERSHIP_GROWTH",
                provider_id=provider_id,
                description=f"BSC membership up {(curr_members/prev_members - 1)*100:.0f}% "
                           f"in {provider_id}'s area — our leverage increases",
                leverage_shift=0.05,  # Plan gains leverage
                urgency="LOW"
            ))
    
    # Regulatory changes (manual input + monitoring)
    adequacy_issues = check_network_adequacy()
    for issue in adequacy_issues:
        alerts.append(LeverageAlert(
            type="ADEQUACY_RISK",
            provider_id=issue.critical_provider_id,
            description=f"Network adequacy at risk in {issue.service_area} — "
                       f"{issue.critical_provider_name} gains leverage",
            leverage_shift=-0.20,
            urgency="CRITICAL"
        ))
    
    return alerts
```

---

## 6. IMPLEMENTATION: LEVERAGE TABLE

```sql
CREATE TABLE IF NOT EXISTS dev_adb.raw.tbl_intel_leverage_scores (
    -- Identity
    provider_id             STRING NOT NULL COMMENT 'Provider ID',
    provider_name           STRING NOT NULL COMMENT 'Canonical provider name',
    assessment_date         DATE NOT NULL COMMENT 'When this assessment was computed',
    
    -- Net leverage
    net_leverage_score      FLOAT COMMENT 'Net position: -1 (provider dominates) to +1 (plan dominates)',
    leverage_label          STRING COMMENT 'STRONG_PLAN | MODERATE_PLAN | BALANCED | MODERATE_PROVIDER | STRONG_PROVIDER',
    strategic_implication   STRING COMMENT 'Recommended negotiation posture',
    
    -- Plan leverage components
    plan_leverage_total     FLOAT COMMENT 'Plan composite leverage (0-1)',
    plan_revenue_share      FLOAT COMMENT 'BSC revenue as % of provider total',
    plan_volume_redirect    FLOAT COMMENT 'Ability to redirect volume (0-1)',
    plan_alternative_count  INT COMMENT 'In-network alternatives available',
    plan_market_share       FLOAT COMMENT 'BSC market share in service area',
    plan_quality_leverage   FLOAT COMMENT 'Quality-based leverage (0-1)',
    
    -- Provider leverage components
    provider_leverage_total FLOAT COMMENT 'Provider composite leverage (0-1)',
    provider_sole_community BOOLEAN COMMENT 'Sole community provider status',
    provider_sole_services  STRING COMMENT 'JSON: services with no alternative',
    provider_member_lock    INT COMMENT 'Members attributed to this provider',
    provider_brand_score    FLOAT COMMENT 'Brand recognition (0-1)',
    provider_system_size    INT COMMENT 'Facilities in affiliated system',
    provider_adequacy_critical BOOLEAN COMMENT 'Loss would violate network adequacy',
    
    -- Dependency analysis
    plan_dependency_score   FLOAT COMMENT 'How much plan depends on provider (0-1)',
    provider_dependency_score FLOAT COMMENT 'How much provider depends on plan (0-1)',
    dependency_ratio        FLOAT COMMENT '>1: plan depends more; <1: provider depends more',
    
    -- Market position
    avg_rate_percentile     FLOAT COMMENT 'Average rate percentile across service lines',
    pct_above_market_median FLOAT COMMENT 'Avg % above market median rate',
    
    -- Audit
    computed_at             TIMESTAMP COMMENT 'Computation timestamp',
    data_sources            STRING COMMENT 'JSON: which data sources contributed'
) USING DELTA
COMMENT 'Bilateral leverage assessment per provider. Updated quarterly or on material market events.'
TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true', 'delta.columnMapping.mode' = 'name');
-- Z-ORDER: OPTIMIZE ZORDER BY (net_leverage_score, provider_id)
```

---

## 7. LEVERAGE-INFORMED NEGOTIATION STRATEGY

### 7.1 Strategy Matrix

| Net Leverage | Provider Spend | Recommended Strategy |
| --- | --- | --- |
| Strong Plan (+0.4 to +1.0) | High (>$10M) | Aggressive reduction: target p25 rates |
| Strong Plan | Low (<$2M) | Maintain — don't spend negotiation capital |
| Moderate Plan (+0.1 to +0.4) | High | Moderate reduction: target median rates |
| Moderate Plan | Low | Auto-renew with escalation cap |
| Balanced (-0.1 to +0.1) | High | Trade-based: concede on one line, gain on another |
| Moderate Provider (-0.4 to -0.1) | High | Containment: cap escalators, extend term |
| Strong Provider (-1.0 to -0.4) | High | Defensive: prevent rate explosion, maintain access |
| Strong Provider | Low | Accept terms — leverage investment not worth it |

### 7.2 Leverage-Adjusted Savings Targets

```python
def compute_leverage_adjusted_target(provider_id: str) -> AdjustedTarget:
    """
    Adjust savings targets based on leverage position.
    High leverage → aggressive target (p25).
    Low leverage → conservative target (p60 or just cap escalation).
    """
    leverage = get_leverage_assessment(provider_id)
    savings = get_savings_opportunity(provider_id)
    
    # Adjust target based on leverage
    if leverage.net_leverage_score > 0.4:
        # Strong leverage: target p25 (aggressive)
        target = savings.savings_to_p25
        target_label = "P25 (aggressive)"
        achievability = 0.7
    elif leverage.net_leverage_score > 0.1:
        # Moderate leverage: target median
        target = savings.savings_to_median
        target_label = "Median"
        achievability = 0.8
    elif leverage.net_leverage_score > -0.1:
        # Balanced: target midpoint between current and median
        target = savings.savings_to_median * 0.5
        target_label = "Partial (50% of gap to median)"
        achievability = 0.85
    else:
        # Provider leverage: target escalation cap only
        escalation = get_escalation_exposure(provider_id)
        target = escalation * 0.5  # Save 50% of projected escalation
        target_label = "Escalation containment"
        achievability = 0.9
    
    return AdjustedTarget(
        provider_id=provider_id,
        raw_opportunity=savings.total_annual_savings,
        leverage_adjusted_target=target,
        target_label=target_label,
        achievability_estimate=achievability,
        expected_value=target * achievability
    )
```

---

*The leverage framework quantifies what experienced negotiators know intuitively: negotiation outcomes depend not just on "what are the rates?" but on "who has the power to change them?" By making leverage explicit and data-driven, the platform enables consistent strategy across all 278+ providers regardless of which individual negotiator handles the renewal.*
