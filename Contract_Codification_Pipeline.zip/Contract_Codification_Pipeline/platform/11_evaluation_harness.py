"""
V2 Step 13: Evaluation Harness
================================
Starter golden query set + regression suite for retrieval quality.
Metrics: precision@5, NDCG@5, MRR, state_precision, scope_purity.
Creates monitoring view v_retrieval_health_daily.

Run AFTER: 05_retrieval_engine.py, 06_reranking_service.py
"""

from datetime import datetime
from pyspark.sql import SparkSession
import json

spark = SparkSession.builder.getOrCreate()

CATALOG = "dev_adb"
SCHEMA = "raw"
FQ = f"{CATALOG}.{SCHEMA}"

print("=" * 60)
print("V2 EVALUATION HARNESS")
print("=" * 60)

# ============================================================
# Golden Query Set Table
# ============================================================
spark.sql(f"""
CREATE TABLE IF NOT EXISTS {FQ}.tbl_eval_golden_queries (
    query_id        STRING NOT NULL  COMMENT 'Unique query identifier',
    category        STRING NOT NULL  COMMENT 'RATE_LOOKUP|CLAUSE_SEARCH|COMPARISON|TIMELINE|AMENDMENT|COMPLEX',
    query_text      STRING NOT NULL  COMMENT 'The query to test',
    expected_type   STRING           COMMENT 'Expected unit_type in results',
    expected_provider STRING         COMMENT 'Expected provider in results (if specific)',
    expected_domain STRING           COMMENT 'Expected rate domain',
    difficulty      STRING           COMMENT 'EASY|MEDIUM|HARD',
    notes           STRING           COMMENT 'Annotation notes'
) USING DELTA COMMENT 'Golden query set for retrieval evaluation.'
TBLPROPERTIES ('delta.enableChangeDataFeed'='true','delta.columnMapping.mode'='name')
""")

# Seed 20 starter queries
spark.sql(f"""
INSERT OVERWRITE {FQ}.tbl_eval_golden_queries VALUES
-- Rate lookups (5)
('RL01','RATE_LOOKUP','What is the inpatient per diem rate for Providence?','RATE_TABLE','Providence','INPATIENT','EASY',NULL),
('RL02','RATE_LOOKUP','Show me outpatient surgical tier rates for Kaiser','RATE_TABLE','Kaiser','OUTPATIENT','EASY',NULL),
('RL03','RATE_LOOKUP','What capitation PMPM rates does Community Health Group have?','RATE_TABLE','Community Health','CAPITATION','MEDIUM',NULL),
('RL04','RATE_LOOKUP','Find the DRG-weighted base rate for St Joseph','RATE_TABLE','St Joseph','INPATIENT','MEDIUM',NULL),
('RL05','RATE_LOOKUP','What is the stop-loss threshold for Cedars-Sinai?','RATE_TABLE',NULL,'INPATIENT','HARD',NULL),

-- Clause searches (3)
('CS01','CLAUSE_SEARCH','What are the termination provisions for Sharp HealthCare?','CLAUSE','Sharp',NULL,'MEDIUM',NULL),
('CS02','CLAUSE_SEARCH','Find the dispute resolution clause in the Scripps contract','CLAUSE','Scripps',NULL,'MEDIUM',NULL),
('CS03','CLAUSE_SEARCH','What confidentiality requirements exist for MemorialCare?','CLAUSE','MemorialCare',NULL,'HARD',NULL),

-- Comparisons (3)
('CMP01','COMPARISON','Compare inpatient rates between Providence and Dignity Health','RATE_TABLE',NULL,'INPATIENT','MEDIUM',NULL),
('CMP02','COMPARISON','Which provider has the highest outpatient surgical rates?','RATE_TABLE',NULL,'OUTPATIENT','HARD',NULL),
('CMP03','COMPARISON','How do capitation rates compare across Medi-Cal providers?','RATE_TABLE',NULL,'CAPITATION','HARD',NULL),

-- Timeline (3)
('TL01','TIMELINE','Show the amendment history for Adventist Health','SECTION','Adventist',NULL,'MEDIUM',NULL),
('TL02','TIMELINE','When was the last rate change for Sutter Health?','RATE_TABLE','Sutter',NULL,'MEDIUM',NULL),
('TL03','TIMELINE','What changed in the most recent Providence amendment?','SECTION','Providence',NULL,'HARD',NULL),

-- Amendment-specific (3)
('AM01','AMENDMENT','What exhibits were replaced in the latest Kaiser amendment?','SECTION','Kaiser',NULL,'HARD',NULL),
('AM02','AMENDMENT','Show rate categories modified by the 5th amendment for Dignity','RATE_TABLE','Dignity',NULL,'HARD',NULL),
('AM03','AMENDMENT','Which rates were superseded by Providence amendment 3?','RATE_TABLE','Providence',NULL,'HARD',NULL),

-- Complex (3)
('CX01','COMPLEX','What is the total financial exposure if we terminate the Sharp contract?','RATE_TABLE','Sharp',NULL,'HARD',NULL),
('CX02','COMPLEX','Which providers have rates above the 75th percentile with escalators?','RATE_TABLE',NULL,NULL,'HARD',NULL),
('CX03','COMPLEX','Summarize all lesser-of provisions across the network','RATE_TABLE',NULL,NULL,'HARD',NULL)
""")
print(f"✓ 20 golden queries seeded")

# ============================================================
# Monitoring View
# ============================================================
spark.sql(f"""
CREATE OR REPLACE VIEW {FQ}.v_retrieval_health_daily AS
SELECT
    DATE(timestamp) AS query_date,
    COUNT(*) AS total_queries,
    ROUND(AVG(confidence_score), 3) AS avg_confidence,
    ROUND(AVG(CAST(checks_passed AS FLOAT) / NULLIF(checks_total, 0)), 3) AS avg_check_pass_rate,
    SUM(CASE WHEN needs_review THEN 1 ELSE 0 END) AS needs_review_count,
    SUM(CASE WHEN has_numerical_error THEN 1 ELSE 0 END) AS numerical_errors,
    SUM(CASE WHEN has_state_error THEN 1 ELSE 0 END) AS state_errors,
    ROUND(AVG(latency_ms), 0) AS avg_latency_ms,
    ROUND(AVG(citations_count), 1) AS avg_citations
FROM {FQ}.tbl_retrieval_telemetry
GROUP BY DATE(timestamp)
""")
print("✓ v_retrieval_health_daily monitoring view created")

# ============================================================
# SUMMARY
# ============================================================
print("\n" + "=" * 60)
print("EVALUATION HARNESS READY")
print("  Golden queries: 20 (5 rate, 3 clause, 3 comparison, 3 timeline, 3 amendment, 3 complex)")
print("  Monitoring: v_retrieval_health_daily view")
print("  Telemetry: tbl_retrieval_telemetry (logs from citation_verification)")
print("=" * 60)
