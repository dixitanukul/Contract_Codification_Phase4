# Provider Contract Intelligence Platform

**Blue Shield of California** — Provider Contracting Analytics  
**Schema**: `dev_adb.raw` | **Runtime**: DBR 18.0 | **Cloud**: Azure

---

## What This Does

Extracts structured intelligence from 10,372 provider contract PDFs and serves it through:
- **Genie Space** for natural language contract queries
- **Dashboard** for portfolio-level analytics
- **Retrieval Engine** for citation-grounded legal Q&A
- **Intelligence Engine** for negotiation, renewal, and leverage scoring

---

## End-to-End Flow

```
┌──────────────────────────────────────────────────────────────┐
│ LAYER 1: EXTRACTION (extraction/)                            │
│ PDFs → OCR → Metadata → LLM Extraction → Build Tables       │
│ Input:  /Volumes/prod_adb/.../Provider_Contracts (10K PDFs)  │
│ Output: V1 analytical tables (tbl_contract_*, tbl_genie_*)   │
└──────────────────────────┬───────────────────────────────────┘
                           ▼
┌──────────────────────────────────────────────────────────────┐
│ LAYER 2: FOUNDATION (platform/ 00-03)                        │
│ DDL → State Engine → Reimbursement Migration                 │
│ Input:  V1 tables                                            │
│ Output: contract_registry, amendment_registry, rate_rules,   │
│         stop_loss, lesser_of, taxonomy                       │
└──────────────────────────┬───────────────────────────────────┘
                           ▼
┌──────────────────────────────────────────────────────────────┐
│ LAYER 3: INTELLIGENCE (platform/ 04-11)                      │
│ Chunking → Retrieval → Reranking → Citation Verification →   │
│ Benchmarks → Scenarios → Leverage → Evaluation               │
│ Input:  Foundation tables + VS index                         │
│ Output: Intelligence tables + retrieval serving stack        │
└──────────────────────────────────────────────────────────────┘
```

---

## Folder Structure

```
Contract_Codification_Pipeline/
├── extraction/              ← PDF extraction pipeline (15 notebooks)
│   ├── 01_file_discovery.py
│   ├── 02_ocr_extraction.py
│   ├── 03_metadata_parsing.py
│   ├── 04_llm_prompts.py
│   ├── 05_llm_extraction.py
│   ├── 06_validation.py
│   ├── 07_consolidation.py
│   ├── 08_build_rates.py
│   ├── 09_build_terms.py
│   ├── 10_build_documents.py
│   ├── 11_enrich_tables.py
│   ├── 12_build_genie.py
│   ├── 13_build_serving.py
│   ├── 14_quality_audit.py
│   └── 15_gap_filler.py
├── platform/                ← Intelligence platform (12 modules)
│   ├── 00_config.py             Config, constants, utilities
│   ├── 01_execute_ddl.py        Create tables + seed taxonomy
│   ├── 02_state_engine.py       Contract & amendment registries
│   ├── 03_reimbursement_migration.py   V1→V2 data migration
│   ├── 04_legal_chunking.py     83K legal units + VS index
│   ├── 05_retrieval_engine.py   4-channel hybrid retrieval + RRF
│   ├── 06_reranking_service.py  3-stage reranking (6 legal signals)
│   ├── 07_citation_verification.py  6-check verification + telemetry
│   ├── 08_intelligence.py       Benchmarks, spend, savings, renewal
│   ├── 09_scenario_engine.py    What-if simulation engine
│   ├── 10_leverage_scoring.py   Bilateral leverage (plan vs provider)
│   └── 11_evaluation_harness.py Golden queries + monitoring
├── sql/                     ← DDL files (executed by platform/01)
│   ├── state_engine_ddl.sql
│   ├── reimbursement_ddl.sql
│   └── taxonomy_seed.sql
├── data/                    ← Pipeline artifacts
│   ├── checkpoints/             Extraction resume state
│   ├── json_extract/            Per-PDF LLM extraction outputs (3,519)
│   └── json_consolidated/       Merged provider-level outputs (456)
├── docs/                    ← Architecture & design reference
│   ├── state_engine/            6 design docs
│   ├── reimbursement/           4 design docs + 3 reference SQL
│   ├── retrieval/               5 design docs
│   ├── intelligence/            5 design docs
│   ├── implementation_prompt.md
│   └── contract_corpus_summary.md
└── README.md                ← This file
```

---

## Execution Order

### First-time setup (run once)
```
platform/00_config.py          → Load constants
platform/01_execute_ddl.py     → Create 18 empty tables + seed taxonomy
platform/02_state_engine.py    → Populate registries (1,948 contracts, 1,570 amendments)
platform/03_reimbursement_migration.py → Migrate V1 rates (21K rules, 741 stop-loss)
```

### Retrieval infrastructure
```
platform/04_legal_chunking.py        → Bootstrap 83K legal units + VS index
platform/05_retrieval_engine.py      → 4-channel hybrid retrieval
platform/06_reranking_service.py     → 3-stage legal signal reranking
platform/07_citation_verification.py → 6-check answer verification
```

### Intelligence layer
```
platform/08_intelligence.py      → Benchmarks, spend summaries, savings, renewals
platform/09_scenario_engine.py   → Rate change / termination / budget-backward scenarios
platform/10_leverage_scoring.py  → Plan vs provider leverage, strategy postures
platform/11_evaluation_harness.py → 20 golden queries + daily health monitoring
```

---

## Key Tables (dev_adb.raw)

| Table | Rows | Purpose |
| --- | --- | --- |
| tbl_v2_contract_registry | 1,948 | All contracts with status (ACTIVE/EXPIRED) |
| tbl_v2_amendment_registry | 1,570 | Amendments with scope classification |
| tbl_reimb_rate_rules | 21,074 | FFS + capitation reimbursement rules |
| tbl_reimb_stop_loss | 741 | Stop-loss provisions |
| tbl_retrieval_legal_units | 83,008 | Chunked legal units for retrieval |
| tbl_intel_benchmark_results | 1,399 | Percentile rates by service line |
| tbl_intel_provider_spend_summary | 348 | Provider-level spend + savings |
| tbl_intel_savings_opportunity | 500 | Pareto-ranked savings opportunities |
| tbl_intel_renewal_priority | 1,478 | Renewal scoring + recommended action |
| tbl_intel_leverage_scores | 348 | Bilateral leverage + posture |

---

## Feature Flags (platform/00_config.py)

| Flag | Status | When to Enable |
| --- | --- | --- |
| CLAIMS_AVAILABLE | False | Connect enterprise claims warehouse feed |
| RERANKER_DEPLOYED | False | Deploy bge-reranker-v2-m3 on Model Serving |
| FULL_CORPUS_PROCESSED | False | Process remaining ~10K PDFs |

---

## External Dependencies

- **Source PDFs**: `/Volumes/prod_adb/default/ext-data-volume-stmlz/Health_Plan_Ops_Transformation/Provider_Contracts`
- **VS Endpoint**: `contract_intelligence_vs_endpoint`
- **Embedding Model**: `databricks-gte-large-en`
- **LLM**: `databricks-claude-sonnet-4-5`
- **Genie Space**: `01f14d360bd51f8d801452065b2df600`
- **Dashboard**: `01f153b41dc51de8bb4e0a3cf16bb7e1`
