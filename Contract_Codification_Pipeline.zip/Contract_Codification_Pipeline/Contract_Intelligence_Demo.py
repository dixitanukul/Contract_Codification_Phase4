# Databricks notebook source
# DBTITLE 1,BSC Provider Contract Intelligence Platform
# MAGIC %md
# MAGIC # 🏥 BSC Provider Contract Intelligence Platform
# MAGIC ### Leadership Demo — AI-Powered Contract Analytics
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC | Metric | Value |
# MAGIC |--------|-------|
# MAGIC | **Providers Under Management** | 271 |
# MAGIC | **Contract PDFs Codified** | 10,372 |
# MAGIC | **Searchable Legal Passages** | 83,008 |
# MAGIC | **Rate Entries Tracked** | 6,683 |
# MAGIC | **Amendments Indexed** | 2,254 |
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC > **What this demo shows:** An end-to-end AI platform that transforms 27 GB of raw provider contract PDFs into structured, queryable intelligence — with natural language Q&A, rate benchmarking, and renewal prioritization. Every answer is grounded in actual contract text with citations.
# MAGIC
# MAGIC *Powered by: Databricks Unity Catalog • Vector Search • Claude Sonnet 4.5 • Delta Lake*

# COMMAND ----------

# DBTITLE 1,Install Dependencies
# MAGIC %pip install databricks-vectorsearch --quiet
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

# DBTITLE 1,Setup and Helper Functions
# ============================================================
# SETUP & HELPER FUNCTIONS
# ============================================================

# --- Constants ---
CATALOG = "dev_adb"
SCHEMA = "raw"
VS_ENDPOINT = "contract_intelligence_vs_endpoint"
VS_INDEX = "dev_adb.raw.idx_legal_units_v2"
LLM_MODEL = "databricks-claude-sonnet-4-5"

# --- Imports ---
import json
import requests
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from databricks.vector_search.client import VectorSearchClient

# --- Clients & Auth ---
try:
    _workspace_url = spark.conf.get("spark.databricks.workspaceUrl")
    _api_token = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiToken().get()
    _llm_endpoint = f"https://{_workspace_url}/serving-endpoints/{LLM_MODEL}/invocations"
    _llm_headers = {"Authorization": f"Bearer {_api_token}", "Content-Type": "application/json"}
    vsc = VectorSearchClient()
    _clients_ready = True
except Exception as e:
    print(f"Client init warning: {e}")
    _clients_ready = False

# --- Helper: Ask LLM (Direct REST API - bypasses SDK serialization bugs) ---
def ask_llm(prompt, max_tokens=2048):
    """Query Claude Sonnet 4.5 via direct REST API."""
    try:
        payload = {
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": max_tokens,
            "temperature": 0.1
        }
        resp = requests.post(_llm_endpoint, headers=_llm_headers, json=payload, timeout=60)
        if resp.status_code != 200:
            return f"LLM Error (HTTP {resp.status_code}): {resp.text[:200]}"
        data = resp.json()
        return data["choices"][0]["message"]["content"]
    except requests.exceptions.Timeout:
        return "LLM Error: Request timed out (60s). Try a simpler question."
    except (KeyError, IndexError) as e:
        return f"LLM Error: Unexpected response format - {str(e)}"
    except Exception as e:
        return f"LLM Error: {str(e)}"

# --- Helper: Vector Search ---
def vector_search(query, provider_filter=None, top_k=8):
    """Search 83K legal passages with optional provider filter."""
    try:
        filters = {}
        if provider_filter and provider_filter != "All Providers":
            filters = {"provider_name": provider_filter}
        
        index = vsc.get_index(endpoint_name=VS_ENDPOINT, index_name=VS_INDEX)
        results = index.similarity_search(
            query_text=query,
            columns=["unit_text", "provider_name", "section_type", "source_filename", "unit_type"],
            num_results=top_k,
            filters=filters
        )
        return results.get("result", {}).get("data_array", [])
    except Exception as e:
        return f"Search Error: {str(e)}"

# --- Helper: Styled KPI Card ---
def styled_card(title, value, color="#1B3A5C", icon="&#x1F4CA;"):
    """Generate HTML for a single KPI card."""
    return f'''<div style="display:inline-block;margin:8px;padding:20px 28px;background:linear-gradient(135deg,{color},{color}cc);border-radius:14px;color:white;text-align:center;min-width:185px;box-shadow:0 6px 20px rgba(0,0,0,0.12);transition:transform 0.2s;">
    <div style="font-size:26px;margin-bottom:4px;">{icon}</div>
    <div style="font-size:30px;font-weight:700;letter-spacing:-0.5px;">{value}</div>
    <div style="font-size:12px;opacity:0.85;margin-top:6px;text-transform:uppercase;letter-spacing:0.5px;">{title}</div></div>'''

# --- Helper: Styled Table ---
def styled_table(df, title="", max_rows=25):
    """Generate HTML for a styled data table."""
    df = df.head(max_rows)
    html = f'<h3 style="color:#1B3A5C;margin:20px 0 10px 0;font-weight:600;">{title}</h3>' if title else ''
    html += '<div style="overflow-x:auto;"><table style="border-collapse:collapse;width:100%;font-size:13px;font-family:system-ui,-apple-system,sans-serif;">'
    html += '<tr>' + ''.join(f'<th style="background:#1B3A5C;color:white;padding:11px 14px;text-align:left;font-weight:500;white-space:nowrap;">{c}</th>' for c in df.columns) + '</tr>'
    for i, row in df.iterrows():
        bg = '#f7f9fb' if i % 2 == 0 else 'white'
        html += f'<tr style="background:{bg};">' + ''.join(f'<td style="padding:9px 14px;border-bottom:1px solid #edf0f4;">{v}</td>' for v in row.values) + '</tr>'
    html += '</table></div>'
    return html

# --- Helper: Section Header ---
def section_header(title, subtitle=""):
    """Generate HTML section header."""
    sub = f'<div style="color:#666;font-size:14px;margin-top:4px;">{subtitle}</div>' if subtitle else ''
    return f'<div style="margin:30px 0 15px 0;padding-bottom:12px;border-bottom:3px solid #2E86AB;"><h2 style="color:#1B3A5C;margin:0;font-weight:700;">{title}</h2>{sub}</div>'

# --- Pre-cache Provider List ---
try:
    providers_df = spark.sql(f"SELECT DISTINCT provider_name FROM {CATALOG}.{SCHEMA}.tbl_genie_provider_profile ORDER BY provider_name").toPandas()
    provider_list = ["All Providers"] + providers_df["provider_name"].tolist()
    default_provider = provider_list[1] if len(provider_list) > 1 else "All Providers"
except Exception as e:
    provider_list = ["All Providers"]
    default_provider = "All Providers"
    print(f"Provider cache warning: {e}")

print("=" * 50)
print("SETUP COMPLETE - All helpers loaded")
print("=" * 50)
print(f"  Providers cached: {len(provider_list)-1}")
print(f"  LLM: {LLM_MODEL}")
print(f"  Vector Search: {VS_INDEX} (83K passages)")
print(f"  Schema: {CATALOG}.{SCHEMA}")
print("=" * 50)

# COMMAND ----------

# DBTITLE 1,Portfolio KPI Dashboard
# ============================================================
# PORTFOLIO KPI DASHBOARD
# ============================================================

try:
    # Query key metrics
    profile_metrics = spark.sql(f"""
        SELECT 
            COUNT(*) as total_providers,
            ROUND(AVG(avg_inpatient_per_diem), 0) as avg_per_diem,
            SUM(total_amendments) as total_amendments
        FROM {CATALOG}.{SCHEMA}.tbl_genie_provider_profile
    """).toPandas().iloc[0]

    expiring_count = spark.sql(f"""
        SELECT COUNT(*) as cnt 
        FROM {CATALOG}.{SCHEMA}.tbl_intel_renewal_priority 
        WHERE days_to_expiry < 90 AND days_to_expiry > 0
    """).toPandas().iloc[0]['cnt']

    rate_count = spark.sql(f"""
        SELECT COUNT(*) as cnt FROM {CATALOG}.{SCHEMA}.tbl_genie_rates_current
    """).toPandas().iloc[0]['cnt']

    # Build KPI cards
    cards_html = '<div style="display:flex;flex-wrap:wrap;justify-content:center;padding:20px 0;">'
    cards_html += styled_card("Total Providers", f"{int(profile_metrics['total_providers']):,}", "#1B3A5C", "\ud83c\udfe5")
    cards_html += styled_card("Avg Inpatient Per Diem", f"${int(profile_metrics['avg_per_diem']):,}", "#2E86AB", "\ud83d\udcb0")
    cards_html += styled_card("Expiring < 90 Days", f"{int(expiring_count):,}", "#D64045", "\u23f0")
    cards_html += styled_card("Rate Entries Tracked", f"{int(rate_count):,}", "#7B2D8B", "\ud83d\udcc8")
    cards_html += styled_card("Total Amendments", f"{int(profile_metrics['total_amendments']):,}", "#1A7A6D", "\ud83d\udcdd")
    cards_html += '</div>'

    displayHTML(section_header("\ud83d\udcca Portfolio Overview", "Real-time metrics across all managed provider contracts") + cards_html)

except Exception as e:
    displayHTML(f'<div style="color:#D64045;padding:20px;">\u26a0\ufe0f Error loading KPIs: {str(e)}</div>')

# COMMAND ----------

# DBTITLE 1,Portfolio Charts — Agreement Types and Contract Status
# ============================================================
# PORTFOLIO CHARTS
# ============================================================

try:
    # Data: Providers by agreement type
    agreement_df = spark.sql(f"""
        SELECT agreement_type, COUNT(*) as count 
        FROM {CATALOG}.{SCHEMA}.tbl_genie_provider_profile 
        WHERE agreement_type IS NOT NULL
        GROUP BY agreement_type 
        ORDER BY count DESC
    """).toPandas()

    # Data: Contract status breakdown
    status_df = spark.sql(f"""
        SELECT status, COUNT(*) as count 
        FROM {CATALOG}.{SCHEMA}.tbl_v2_contract_registry 
        WHERE status IS NOT NULL
        GROUP BY status
    """).toPandas()

    # Create subplots
    fig = make_subplots(
        rows=1, cols=2,
        subplot_titles=("Providers by Agreement Type", "Contract Status Breakdown"),
        specs=[[{"type": "bar"}, {"type": "pie"}]],
        column_widths=[0.6, 0.4]
    )

    # Bar chart
    colors_bar = ['#1B3A5C', '#2E86AB', '#A23B72', '#1A7A6D', '#D64045', '#F18F01', '#5C4D7D']
    fig.add_trace(
        go.Bar(
            x=agreement_df['count'],
            y=agreement_df['agreement_type'],
            orientation='h',
            marker_color=colors_bar[:len(agreement_df)],
            text=agreement_df['count'],
            textposition='outside',
            textfont=dict(size=11)
        ),
        row=1, col=1
    )

    # Pie chart
    status_colors = {'ACTIVE': '#2E86AB', 'EXPIRED': '#D64045', 'PENDING': '#F18F01'}
    fig.add_trace(
        go.Pie(
            labels=status_df['status'],
            values=status_df['count'],
            hole=0.4,
            marker_colors=[status_colors.get(s, '#999') for s in status_df['status']],
            textinfo='label+percent',
            textfont=dict(size=12)
        ),
        row=1, col=2
    )

    fig.update_layout(
        height=380,
        showlegend=False,
        title_text="",
        font=dict(family="system-ui, -apple-system, sans-serif"),
        paper_bgcolor='white',
        plot_bgcolor='#f8f9fb',
        margin=dict(l=20, r=20, t=50, b=20)
    )
    fig.update_xaxes(showgrid=True, gridcolor='#eee', row=1, col=1)

    displayHTML(
        section_header("\ud83d\udcc8 Portfolio Composition", "Agreement types and contract lifecycle status") +
        fig.to_html(include_plotlyjs='cdn', full_html=False)
    )

except Exception as e:
    displayHTML(f'<div style="color:#D64045;padding:20px;">\u26a0\ufe0f Error loading charts: {str(e)}</div>')

# COMMAND ----------

# DBTITLE 1,Ask Anything - Deep Contract Intelligence Engine
# ============================================================
# ASK ANYTHING — Deep Contract Intelligence Engine (V3 Optimized)
# ============================================================
# Replicates the 7-sheet Excel analytical methodology:
# 1. Question Understanding (LLM intent + keyword extraction)
# 1.5 Execution Plan (LLM keyword triage + disambiguation)
# 2. Dynamic Taxonomy Generation (LLM creates sub-categories)
#    [Steps 1.5 + 2 run IN PARALLEL]
# 3. Hybrid Retrieval: VS semantic + Spark-side scored+deduped SQL
# 4. Merge channels + final dedup
# 5. LLM Classification (ALL candidates, 10/batch, 14 workers)
# 6. Provider Rollup (HAS / NO_MENTION / DENIED / MIXED)
# 7. Multi-section HTML report
# ============================================================
# Performance optimizations (zero quality loss):
#   - Cached provider universe (no re-query on repeat runs)
#   - Spark SQL scoring + ROW_NUMBER dedup (avoids 10-30K toPandas)
#   - 14 parallel LLM workers (up from 8)
#   - Plan + taxonomy generated concurrently
#   - Chunks < 50 chars filtered in SQL (headers/noise)
# ============================================================
# Expected: offset clause ~268 HAS, ~28 NO_MENTION, ~1 DENIED,
# ~28 MIXED, ~2,675 classified | Runtime target: 2-4 min
# ============================================================

import re, time, json, traceback
from concurrent.futures import ThreadPoolExecutor, as_completed

# --- Widget ---
dbutils.widgets.text("question", "Which contracts dont have an offset clause?", "Ask anything about provider contracts...")
user_question = dbutils.widgets.get("question")

# --- Provider Universe Cache (optimization: query once, reuse across runs) ---
if '_provider_universe_cache' not in dir():
    _provider_universe_cache = None

def get_provider_universe():
    """Return cached provider universe (326 providers). Only queries DB on first call."""
    global _provider_universe_cache
    if _provider_universe_cache is None:
        _provider_universe_cache = spark.sql(f"""
            SELECT DISTINCT provider_name 
            FROM {CATALOG}.{SCHEMA}.tbl_contract_fulltext_vs_ready 
            WHERE provider_name IS NOT NULL
            ORDER BY provider_name
        """).toPandas()["provider_name"].tolist()
    return _provider_universe_cache

# ============================================================
# STEP 1: Question Understanding
# ============================================================
def understand_question(question):
    """Extract search keywords, intent, and analysis parameters from the question."""
    prompt = f"""Analyze this contract intelligence question and return a JSON object (no markdown).

Question: {question}

Return ONLY valid JSON with these fields:
{{"search_keywords": ["keyword1", "keyword2", ...],  // 4-8 keywords/phrases to search contract text for (MUST include synonyms, abbreviations, and hyphenated variants)
 "semantic_query": "...",  // natural language search query for vector similarity (longer, descriptive)
 "analysis_type": "existence|explanation|comparison|data",  // existence=has/doesn't have, explanation=explain clause, comparison=compare providers, data=rates/numbers
 "is_negative": true/false,  // true if asking about ABSENCE (don't have, without, lack)
 "target_concept": "...",  // the specific contract concept being asked about (e.g., "offset clause", "auto-renewal", "stop-loss")
 "provider_filter": null  // specific provider name if mentioned, else null
}}

IMPORTANT: For search_keywords, include ALL spelling variants, synonyms, and related legal terms.
Example for "offset clause": ["offset", "set-off", "setoff", "set off", "recoup", "recoupment", "deduct", "withhold"]"""
    try:
        result = ask_llm(prompt, max_tokens=400)
        result = result.strip()
        if result.startswith("```"): result = result.split("\n", 1)[-1].rsplit("```", 1)[0]
        return json.loads(result)
    except:
        words = re.findall(r'\b[a-z]{4,}\b', question.lower())
        concept_words = [w for w in words if w not in ['which', 'contracts', 'providers', 'have', 'dont', 'does', 'that', 'with', 'without', 'what', 'show', 'about', 'their', 'them']]
        return {
            "search_keywords": concept_words[:6],
            "semantic_query": question,
            "analysis_type": "existence" if any(w in question.lower() for w in ["have", "don't", "without"]) else "explanation",
            "is_negative": any(w in question.lower() for w in ["don't", "dont", "without", "lack", "no "]),
            "target_concept": " ".join(concept_words[:3]),
            "provider_filter": None
        }

# ============================================================
# STEP 1.5: Execution Plan (precision keyword triage + disambiguation)
# ============================================================
def create_execution_plan(understanding):
    """LLM reasons about keyword precision, disambiguation, and retrieval strategy.
    This step replicates the human judgment the Excel analyst applied when curating keywords."""
    target = understanding.get("target_concept", "the provision")
    keywords = understanding.get("search_keywords", [])
    analysis_type = understanding.get("analysis_type", "existence")
    
    prompt = f"""You are a healthcare contract search strategist. I need to search 1.36 million contract text chunks for "{target}".

Candidate keywords from initial analysis: {json.dumps(keywords)}

Your job: Create a PRECISION-OPTIMIZED execution plan. Think step by step:

1. For each keyword, assess: Does this keyword UNIQUELY identify "{target}" in healthcare contracts? Or could it match UNRELATED content?
   - Example: For "offset clause", the keyword "offset" is precise. But "deduction" matches patient deductibles, tax deductions, etc.
   - Example: For "auto-renewal", "auto-renewal" is precise. But "term" matches hundreds of unrelated uses.

2. Classify each keyword:
   - CORE: Directly and unambiguously refers to {target} (always include in search)
   - EXTENDED: Could refer to {target} but also has common unrelated meanings (only count if co-occurs with a CORE keyword)
   - EXCLUDE: Too ambiguous / will generate >80% false positives

3. Provide disambiguation rules: What LOOKS like {target} but ISN'T? What IS {target} that might be missed?

Return ONLY valid JSON (no markdown):
{{{{
  "core_keywords": ["keyword1", "keyword2"],  // Always search for these (unambiguous)
  "extended_keywords": ["keyword3"],  // Only count if co-occurs with a core keyword in same chunk
  "excluded_keywords": [{{"keyword": "...", "reason": "matches X unrelated context"}}],
  "disambiguation_rules": [
    "IS {target}: <description of what qualifies>",
    "IS NOT {target}: <description of common false positives>"
  ],
  "expected_prevalence": "high|medium|low",  // How common is this provision? high=>80%+, medium=40-80%, low=<40%
  "precision_strategy": "strict|balanced|broad"  // strict=only core keywords, balanced=core+extended with co-occurrence, broad=all keywords
}}}}"""
    
    try:
        result = ask_llm(prompt, max_tokens=800)
        result = result.strip()
        if result.startswith("```"): result = result.split("\n", 1)[-1].rsplit("```", 1)[0]
        plan = json.loads(result)
        # Validate plan structure
        if "core_keywords" not in plan:
            plan["core_keywords"] = keywords[:4]
        if "extended_keywords" not in plan:
            plan["extended_keywords"] = []
        if "excluded_keywords" not in plan:
            plan["excluded_keywords"] = []
        if "disambiguation_rules" not in plan:
            plan["disambiguation_rules"] = []
        if "precision_strategy" not in plan:
            plan["precision_strategy"] = "balanced"
        if "expected_prevalence" not in plan:
            plan["expected_prevalence"] = "medium"
        return plan
    except:
        # Fallback: treat first 4 keywords as core, rest as extended
        return {
            "core_keywords": keywords[:4],
            "extended_keywords": keywords[4:],
            "excluded_keywords": [],
            "disambiguation_rules": [],
            "expected_prevalence": "medium",
            "precision_strategy": "balanced"
        }


def apply_plan_to_retrieval(understanding, plan):
    """Refine understanding with plan's keyword strategy for use in retrieval."""
    strategy = plan.get("precision_strategy", "balanced")
    if strategy == "strict":
        # Only use core keywords
        understanding["search_keywords"] = plan["core_keywords"]
    elif strategy == "balanced":
        # Use core + extended (extended will be filtered by co-occurrence later)
        understanding["search_keywords"] = plan["core_keywords"] + plan.get("extended_keywords", [])
    else:  # broad
        # Keep all original keywords
        pass
    
    # Store plan reference for downstream use
    understanding["_plan"] = plan
    return understanding

# ============================================================
# STEP 2: Dynamic Taxonomy Generation
# ============================================================
def generate_taxonomy(understanding):
    """LLM generates 5-7 sub-categories dynamically based on the target concept."""
    target = understanding.get("target_concept", "the provision")
    prompt = f"""You are a healthcare contract analyst. Generate a classification taxonomy for the concept "{target}" as found in provider contracts.

Return ONLY valid JSON (no markdown) with 5-7 categories. Each category should represent a distinct sub-type or purpose of this provision.
Also include exactly ONE denial/absence category for when a contract EXPLICITLY STATES the provision does NOT exist or is ENTIRELY PROHIBITED (not merely limited or conditional).

Format:
{{"categories": [
  {{"code": "CATEGORY_CODE", "label": "Short Label", "description": "When to assign this category", "is_denial": false}},
  ...
  {{"code": "NO_RIGHTS", "label": "Explicitly Denied/Restricted", "description": "Contract explicitly restricts or denies this provision", "is_denial": true}}
]}}

Example for "offset clause":
{{"categories": [
  {{"code": "OVERPAYMENT_OFFSET", "label": "Overpayment Recovery", "description": "Plan recovers erroneous overpayments by deducting from future payments", "is_denial": false}},
  {{"code": "GENERAL_OFFSET", "label": "General Offset Rights", "description": "Broad mutual offset rights between parties", "is_denial": false}},
  {{"code": "RECONCILIATION_OFFSET", "label": "Reconciliation Offset", "description": "Periodic reconciliation with offset of differences", "is_denial": false}},
  {{"code": "AUDIT_OFFSET", "label": "Audit-Based Offset", "description": "Audit findings deducted from future payments", "is_denial": false}},
  {{"code": "CAPITATION_OFFSET", "label": "Capitation Offset", "description": "Deductions from monthly capitation payments", "is_denial": false}},
  {{"code": "NO_OFFSET_RIGHTS", "label": "No Offset Rights", "description": "Contract explicitly restricts or denies offset rights", "is_denial": true}}
]}}

Now generate for: '{target}'
"""
    try:
        result = ask_llm(prompt, max_tokens=800)
        result = result.strip()
        if result.startswith("```"): result = result.split("\n", 1)[-1].rsplit("```", 1)[0]
        parsed = json.loads(result)
        return parsed.get("categories", [])
    except:
        # Fallback: generic taxonomy
        return [
            {"code": "CONFIRMED_PRESENT", "label": "Present", "description": f"{target} is clearly present", "is_denial": False},
            {"code": "EXPLICITLY_DENIED", "label": "Denied/Restricted", "description": f"{target} is explicitly denied or restricted", "is_denial": True},
            {"code": "REFERENCED", "label": "Referenced", "description": f"{target} is referenced but not fully defined here", "is_denial": False},
        ]

# ============================================================
# STEP 3: Hybrid Retrieval (VS Semantic + SQL Keyword — FULL CORPUS)
# ============================================================
def hybrid_retrieval(understanding, max_semantic=100):
    """Dual-channel retrieval from 1.36M chunk corpus. NO arbitrary LIMIT on keyword search."""
    semantic_results = []
    keyword_results_df = None
    
    # Channel 1: Vector Search (semantic) on fulltext index
    try:
        index = vsc.get_index(endpoint_name=VS_ENDPOINT, index_name="dev_adb.raw.tbl_contract_fulltext_vs_index")
        vs_results = index.similarity_search(
            query_text=understanding["semantic_query"],
            columns=["chunk_text", "provider_name", "source_filename", "page_number"],
            num_results=max_semantic
        )
        semantic_results = vs_results.get("result", {}).get("data_array", [])
    except Exception as e:
        try:
            index = vsc.get_index(endpoint_name=VS_ENDPOINT, index_name=VS_INDEX)
            vs_results = index.similarity_search(
                query_text=understanding["semantic_query"],
                columns=["unit_text", "provider_name", "source_filename", "section_type"],
                num_results=max_semantic
            )
            semantic_results = vs_results.get("result", {}).get("data_array", [])
        except:
            pass
    
    # Channel 2: SQL keyword search with Spark-side scoring + dedup (OPTIMIZATION)
    # Instead of pulling ALL raw matches to pandas, we score and dedup IN Spark SQL,
    # only collecting the final deduped candidates. Avoids 10-30K row toPandas() overhead.
    plan = understanding.get("_plan", {})
    keywords = understanding.get("search_keywords", [])
    core_kws = [k.lower().replace("'", "") for k in plan.get("core_keywords", keywords)]
    extended_kws = [k.lower().replace("'", "") for k in plan.get("extended_keywords", [])]
    excluded_kws = [e["keyword"].lower() if isinstance(e, dict) else e.lower()
                    for e in plan.get("excluded_keywords", [])]
    # Remove excluded from extended
    extended_kws = [k for k in extended_kws if k not in excluded_kws]
    
    if keywords:
        # Build LIKE clauses for WHERE (include all search keywords for retrieval)
        all_search_kws = [kw.lower().replace("'", "") for kw in keywords]
        like_clauses = " OR ".join([f"LOWER(chunk_text) LIKE '%{kw}%'" for kw in all_search_kws])
        
        # Build scoring expressions in SQL
        core_score_parts = [f"CASE WHEN LOWER(chunk_text) LIKE '%{kw}%' THEN 1 ELSE 0 END" for kw in core_kws]
        extended_score_parts = [f"CASE WHEN LOWER(chunk_text) LIKE '%{kw}%' THEN 1 ELSE 0 END" for kw in extended_kws]
        
        core_score_sql = " + ".join(core_score_parts) if core_score_parts else "0"
        extended_score_sql = " + ".join(extended_score_parts) if extended_score_parts else "0"
        
        # Score logic (mirrors Python logic):
        # score=3 if core>=2 OR (core>=1 AND extended>=1)
        # score=2 if core>=1 OR extended>=2 OR extended=1
        # score=1 otherwise (filtered out)
        scoring_sql = f"""
        WITH matched AS (
            SELECT provider_name, source_filename, page_number, 
                   SUBSTRING(chunk_text, 1, 1200) as chunk_text,
                   LENGTH(chunk_text) as text_length,
                   ({core_score_sql}) as core_hits,
                   ({extended_score_sql}) as ext_hits
            FROM {CATALOG}.{SCHEMA}.tbl_contract_fulltext_vs_ready
            WHERE ({like_clauses})
              AND LENGTH(chunk_text) >= 50
        ),
        scored AS (
            SELECT *,
                CASE 
                    WHEN core_hits >= 2 OR (core_hits >= 1 AND ext_hits >= 1) THEN 3
                    WHEN core_hits >= 1 THEN 2
                    WHEN ext_hits >= 2 THEN 2
                    WHEN ext_hits >= 1 THEN 2
                    ELSE 1
                END as score
            FROM matched
        ),
        deduped AS (
            SELECT *, ROW_NUMBER() OVER (PARTITION BY source_filename ORDER BY score DESC, text_length DESC) as rn
            FROM scored
            WHERE score >= 2
        )
        SELECT provider_name, source_filename, page_number, chunk_text, text_length, score, core_hits, ext_hits
        FROM deduped
        WHERE rn = 1
        """
        
        try:
            keyword_results_df = spark.sql(scoring_sql).toPandas()
        except Exception as e:
            # Fallback: simple retrieval without Spark-side scoring
            like_clauses_ct = " OR ".join([f"LOWER(content_text) LIKE '%{kw}%'" for kw in all_search_kws])
            try:
                keyword_results_df = spark.sql(f"""
                    SELECT provider_name, source_filename, 0 as page_number, 
                           SUBSTRING(content_text, 1, 1200) as chunk_text,
                           LENGTH(content_text) as text_length, 2 as score, 1 as core_hits, 0 as ext_hits
                    FROM {CATALOG}.{SCHEMA}.vw_genie_contract_terms
                    WHERE ({like_clauses_ct}) AND is_from_latest_doc = true
                """).toPandas()
            except:
                pass
    
    return semantic_results, keyword_results_df

# ============================================================
# STEP 4: Merge Semantic + Keyword results, final dedup
# ============================================================
def score_and_dedup(semantic_results, keyword_df, understanding):
    """Merge semantic results with Spark-scored keyword results. Keyword results are already deduped."""
    candidates = []
    keywords = [kw.lower() for kw in understanding.get("search_keywords", [])]
    
    # Score semantic results (still done in Python since only 100 rows)
    for row in semantic_results:
        text = str(row[0]) if row[0] else ""
        provider = str(row[1]) if len(row) > 1 else "Unknown"
        filename = str(row[2]) if len(row) > 2 else "Unknown"
        page = row[3] if len(row) > 3 else 0
        text_lower = text.lower()
        kw_hits = sum(1 for kw in keywords if kw in text_lower)
        score = 3 if kw_hits >= 2 else (2 if kw_hits == 1 else 1)
        if score >= 2:
            candidates.append({
                "text": text[:1200], "provider": provider, "filename": filename,
                "page": page, "score": score, "source": "semantic"
            })
    
    # Add Spark-scored keyword results (already deduped by ROW_NUMBER in SQL)
    if keyword_df is not None and not keyword_df.empty:
        for _, row in keyword_df.iterrows():
            candidates.append({
                "text": str(row.get('chunk_text', ''))[:1200],
                "provider": str(row.get('provider_name', 'Unknown')),
                "filename": str(row.get('source_filename', 'Unknown')),
                "page": int(row.get('page_number', 0)) if pd.notna(row.get('page_number')) else 0,
                "score": int(row.get('score', 2)),
                "source": "keyword"
            })
    
    # Final dedup: if a file appears in both semantic and keyword, keep highest score
    candidates.sort(key=lambda x: x["score"], reverse=True)
    seen_files = set()
    deduped = []
    for c in candidates:
        if c["filename"] not in seen_files:
            seen_files.add(c["filename"])
            deduped.append(c)
    
    return deduped

# ============================================================
# STEP 5: LLM Classification (ALL candidates, 10/batch, 8 workers)
# ============================================================
def classify_batch(batch, target, taxonomy_codes, disambiguation_rules=None):
    """Classify a single batch of passages via LLM. Called by ThreadPoolExecutor."""
    batch_text = ""
    for j, c in enumerate(batch):
        batch_text += f"\n---PASSAGE {j+1} (Provider: {c['provider']}, File: {c['filename']}, Page: {c['page']})---\n{c['text'][:600]}\n"
    
    # Build disambiguation section if plan provided rules
    disambiguation_section = ""
    if disambiguation_rules:
        disambiguation_section = "\n\nDISAMBIGUATION (follow strictly):\n" + "\n".join(f"- {r}" for r in disambiguation_rules)
    
    codes_str = ", ".join(taxonomy_codes)
    prompt = f"""Classify each passage regarding "{target}" in healthcare provider contracts.{disambiguation_section}

Available categories: [{codes_str}, NOT_RELEVANT]

For EACH passage, determine:
1. category: One of the codes above
2. reasoning: One sentence explaining classification
3. key_phrase: Exact quote from the passage (max 100 chars) that supports your classification

Rules:
- If the passage clearly grants/contains the provision (even with conditions, limitations, notice requirements, or procedural steps), use the MOST SPECIFIC positive category
- CRITICAL for denial category: ONLY use the denial/NO_ category when the passage EXPLICITLY STATES the provision DOES NOT EXIST or is PROHIBITED entirely. Conditions like "must notify before offsetting" or "offset limited to X" mean the provision EXISTS with conditions — classify as a POSITIVE category, NOT denial.
- If the passage mentions related terms but is not actually about this specific provision, use NOT_RELEVANT
- Extract the key_phrase VERBATIM from the passage text
- When in doubt between a positive category and NOT_RELEVANT, prefer the positive category if any keyword is used in context of granting rights

Return ONLY a JSON array (no markdown): [{{{{
  "passage_num": 1, "category": "...", "reasoning": "...", "key_phrase": "..."
}}}}, ...]

Passages:{batch_text}"""
    
    results = []
    try:
        result = ask_llm(prompt, max_tokens=2048)
        result = result.strip()
        if result.startswith("```"): result = result.split("\n", 1)[-1].rsplit("```", 1)[0]
        # Handle potential truncation: try to repair JSON
        if not result.endswith("]"):
            last_brace = result.rfind("}")
            if last_brace > 0:
                result = result[:last_brace+1] + "]"
        batch_classifications = json.loads(result)
        
        for cls in batch_classifications:
            idx = cls.get("passage_num", 1) - 1
            if 0 <= idx < len(batch):
                c = batch[idx].copy()
                cat = cls.get("category", "NOT_RELEVANT")
                c["category"] = cat if cat in taxonomy_codes or cat == "NOT_RELEVANT" else "NOT_RELEVANT"
                c["reasoning"] = cls.get("reasoning", "")
                c["key_phrase"] = cls.get("key_phrase", "")
                results.append(c)
    except (json.JSONDecodeError, KeyError, TypeError):
        # On parse failure, use heuristic: if strong keyword match, mark as first positive category
        default_cat = taxonomy_codes[0] if taxonomy_codes else "CONFIRMED_PRESENT"
        for c in batch:
            c_copy = c.copy()
            c_copy["category"] = default_cat
            c_copy["reasoning"] = "Keyword match (LLM parse failed)"
            c_copy["key_phrase"] = ""
            results.append(c_copy)
    
    return results


def classify_all_passages(candidates, understanding, taxonomy):
    """Classify ALL candidates using ThreadPoolExecutor with 8 workers, batches of 10."""
    target = understanding.get("target_concept", "the provision")
    taxonomy_codes = [cat["code"] for cat in taxonomy]
    plan = understanding.get("_plan", {})
    disambiguation_rules = plan.get("disambiguation_rules", None)
    
    if not candidates:
        return []
    
    # Build batches of 10
    batch_size = 10
    batches = [candidates[i:i+batch_size] for i in range(0, len(candidates), batch_size)]
    
    classified = []
    completed = 0
    total_batches = len(batches)
    
    # Parallel classification with 14 workers (safe: REST API handles concurrency)
    with ThreadPoolExecutor(max_workers=14) as executor:
        futures = {
            executor.submit(classify_batch, batch, target, taxonomy_codes, disambiguation_rules): i 
            for i, batch in enumerate(batches)
        }
        for future in as_completed(futures):
            try:
                batch_results = future.result()
                classified.extend(batch_results)
            except Exception:
                pass
            completed += 1
            if completed % 20 == 0 or completed == total_batches:
                print(f"      Classified {completed}/{total_batches} batches ({len(classified)} passages so far)")
    
    return classified

# ============================================================
# STEP 6: Provider Rollup (HAS / NO_MENTION / DENIED / MIXED)
# ============================================================
def provider_rollup(classified, taxonomy, all_provider_names):
    """Aggregate classified passages to provider level with MIXED detection."""
    # Identify which categories are denial vs positive
    denial_codes = {cat["code"] for cat in taxonomy if cat.get("is_denial", False)}
    positive_codes = {cat["code"] for cat in taxonomy if not cat.get("is_denial", False)}
    
    # Build provider -> findings map
    provider_data = {}
    for c in classified:
        if c.get("category") == "NOT_RELEVANT":
            continue
        prov = c["provider"]
        if prov not in provider_data:
            provider_data[prov] = {"positive_cats": set(), "denial_cats": set(), 
                                   "positive_count": 0, "denial_count": 0,
                                   "docs": set(), "findings": [], "categories": {}}
        cat = c["category"]
        provider_data[prov]["findings"].append(c)
        provider_data[prov]["docs"].add(c["filename"])
        provider_data[prov]["categories"][cat] = provider_data[prov]["categories"].get(cat, 0) + 1
        
        if cat in denial_codes:
            provider_data[prov]["denial_cats"].add(cat)
            provider_data[prov]["denial_count"] += 1
        elif cat in positive_codes:
            provider_data[prov]["positive_cats"].add(cat)
            provider_data[prov]["positive_count"] += 1
    
    # Assign status per provider
    for prov, data in provider_data.items():
        if data["positive_count"] > 0 and data["denial_count"] > 0:
            data["status"] = "MIXED"
        elif data["positive_count"] > 0:
            data["status"] = "HAS_PROVISION"
        elif data["denial_count"] > 0:
            data["status"] = "EXPLICITLY_DENIED"
        else:
            data["status"] = "AMBIGUOUS"
    
    # Identify NO_MENTION providers (in universe but no relevant passages)
    mentioned = set(provider_data.keys())
    no_mention = sorted(set(all_provider_names) - mentioned)
    
    return provider_data, no_mention

# ============================================================
# STEP 7: Build Multi-Section HTML Report (matches Excel depth)
# ============================================================
def build_report(question, understanding, classified, provider_data, no_mention, taxonomy, elapsed, total_universe, raw_keyword_count, deduped_count, plan=None):
    """Generate the full 7-section analytical HTML report matching Excel workbook depth."""
    target = understanding.get("target_concept", "the provision")
    is_negative = understanding.get("is_negative", False)
    
    # Compute rollup stats
    has_count = sum(1 for d in provider_data.values() if d["status"] == "HAS_PROVISION")
    denied_count = sum(1 for d in provider_data.values() if d["status"] == "EXPLICITLY_DENIED")
    mixed_count = sum(1 for d in provider_data.values() if d["status"] == "MIXED")
    no_mention_count = len(no_mention)
    total_docs = sum(len(d["docs"]) for d in provider_data.values())
    relevant_classified = [c for c in classified if c.get("category") != "NOT_RELEVANT"]
    
    has_pct = round(has_count / max(1, total_universe) * 100, 1)
    denied_pct = round(denied_count / max(1, total_universe) * 100, 1)
    mixed_pct = round(mixed_count / max(1, total_universe) * 100, 1)
    no_mention_pct = round(no_mention_count / max(1, total_universe) * 100, 1)
    
    html = ""
    
    # --- SECTION 1: Executive Summary ---
    html += section_header(f"\U0001f4cb Deep Analysis Report: {target.title()}", f"Across {total_universe} providers in the contract corpus")
    
    # KPI Cards
    html += '<div style="display:flex;flex-wrap:wrap;justify-content:center;margin:15px 0;">'
    html += styled_card(f"HAS {target.title()}", f"{has_count} ({has_pct}%)", "#2E86AB", "\u2705")
    html += styled_card("No Mention", f"{no_mention_count} ({no_mention_pct}%)", "#F18F01", "\u2753")
    html += styled_card("Explicitly Denied", f"{denied_count} ({denied_pct}%)", "#D64045", "\u274C")
    html += styled_card("Mixed (Grant+Deny)", f"{mixed_count} ({mixed_pct}%)", "#7B2D8B", "\u26A0\uFE0F")
    html += styled_card("Passages Classified", f"{len(relevant_classified):,}", "#1A7A6D", "\U0001f4c4")
    html += styled_card("Documents Matched", f"{total_docs:,}", "#5C4D7D", "\U0001f4da")
    html += '</div>'
    
    # --- SECTION 2: Category Distribution Table ---
    html += '<h3 style="color:#1B3A5C;margin:25px 0 10px 0;">\U0001f4ca Category Distribution</h3>'
    # Aggregate by category
    cat_counts = {}
    for c in relevant_classified:
        cat = c.get("category", "UNKNOWN")
        cat_counts[cat] = cat_counts.get(cat, 0) + 1
    
    # Map taxonomy codes to labels
    code_to_label = {t["code"]: t["label"] for t in taxonomy}
    code_to_denial = {t["code"]: t.get("is_denial", False) for t in taxonomy}
    
    html += '<table style="border-collapse:collapse;width:100%;max-width:700px;font-size:13px;margin:10px 0;">'
    html += '<tr><th style="background:#1B3A5C;color:white;padding:10px 14px;text-align:left;">Category</th><th style="background:#1B3A5C;color:white;padding:10px 14px;text-align:right;">Documents</th><th style="background:#1B3A5C;color:white;padding:10px 14px;text-align:right;">% of Classified</th><th style="background:#1B3A5C;color:white;padding:10px 14px;text-align:left;">Type</th></tr>'
    for cat, count in sorted(cat_counts.items(), key=lambda x: x[1], reverse=True):
        label = code_to_label.get(cat, cat)
        pct = round(count / max(1, len(relevant_classified)) * 100, 1)
        is_denial = code_to_denial.get(cat, False)
        type_badge = '<span style="background:#D64045;color:white;padding:2px 6px;border-radius:4px;font-size:10px;">DENIAL</span>' if is_denial else '<span style="background:#2E86AB;color:white;padding:2px 6px;border-radius:4px;font-size:10px;">POSITIVE</span>'
        html += f'<tr style="background:{"#fde8e8" if is_denial else "#f7f9fb"};border-bottom:1px solid #eee;"><td style="padding:8px 14px;font-weight:500;">{label}</td><td style="padding:8px 14px;text-align:right;">{count:,}</td><td style="padding:8px 14px;text-align:right;">{pct}%</td><td style="padding:8px 14px;">{type_badge}</td></tr>'
    html += '</table>'
    
    # --- SECTION 3: Providers WITHOUT (for negative queries) or WITH (for positive) ---
    if is_negative:
        html += f'<h3 style="color:#D64045;margin:25px 0 10px 0;">\u274C Providers WITHOUT {target} ({no_mention_count + denied_count})</h3>'
        
        # Explicitly denied
        if denied_count > 0:
            html += f'<div style="margin:10px 0 5px 0;font-weight:600;color:#D64045;">Explicitly Denied/Restricted ({denied_count}):</div>'
            denied_provs = [(p, d) for p, d in provider_data.items() if d["status"] == "EXPLICITLY_DENIED"]
            for p, data in sorted(denied_provs, key=lambda x: x[0]):
                phrase = data["findings"][0].get("key_phrase", "") if data["findings"] else ""
                docs_list = ", ".join(list(data["docs"])[:3])
                html += f'<div style="background:#fde8e8;padding:8px 12px;border-radius:6px;margin:4px 0;font-size:12px;"><strong>{p}</strong> \u2014 <em>\"{phrase}\"</em><br><span style="color:#999;font-size:10px;">Source: {docs_list}</span></div>'
        
        # No mention
        if no_mention_count > 0:
            html += f'<div style="margin:15px 0 5px 0;font-weight:600;color:#F18F01;">No Mention Found ({no_mention_count} providers):</div>'
            html += '<div style="column-count:3;column-gap:15px;font-size:11px;margin:8px 0;background:#fffbf0;padding:12px;border-radius:8px;">'
            for p in no_mention:
                html += f'<div style="padding:2px 0;">{p}</div>'
            html += '</div>'
    else:
        html += f'<h3 style="color:#2E86AB;margin:25px 0 10px 0;">\u2705 Providers WITH {target} ({has_count})</h3>'
        has_provs = sorted([(p, d) for p, d in provider_data.items() if d["status"] == "HAS_PROVISION"], key=lambda x: x[1]["positive_count"], reverse=True)
        html += f'<div style="column-count:3;column-gap:15px;font-size:11px;margin:8px 0;background:#f0f9ff;padding:12px;border-radius:8px;">'
        for p, d in has_provs[:100]:
            html += f'<div style="padding:2px 0;">{p} <span style="color:#999;">({d["positive_count"]} docs)</span></div>'
        if has_count > 100:
            html += f'<div style="color:#999;padding:2px 0;">... and {has_count - 100} more</div>'
        html += '</div>'
    
    # --- SECTION 4: Mixed Providers (ACTION NEEDED) ---
    if mixed_count > 0:
        html += f'<h3 style="color:#7B2D8B;margin:25px 0 10px 0;">\u26A0\uFE0F Mixed Providers ({mixed_count}) \u2014 ACTION NEEDED</h3>'
        html += '<div style="font-size:12px;color:#555;margin-bottom:10px;">These providers have BOTH grant and denial language across different documents. Later amendments may supersede earlier provisions. Temporal review required.</div>'
        html += '<table style="border-collapse:collapse;width:100%;font-size:12px;margin:8px 0;">'
        html += '<tr><th style="background:#7B2D8B;color:white;padding:8px 12px;text-align:left;">Provider</th><th style="background:#7B2D8B;color:white;padding:8px 12px;text-align:right;">Grant Docs</th><th style="background:#7B2D8B;color:white;padding:8px 12px;text-align:right;">Deny Docs</th><th style="background:#7B2D8B;color:white;padding:8px 12px;text-align:left;">Categories Found</th></tr>'
        mixed_provs = sorted([(p, d) for p, d in provider_data.items() if d["status"] == "MIXED"], key=lambda x: x[0])
        for i, (p, d) in enumerate(mixed_provs):
            bg = '#f9f0ff' if i % 2 == 0 else 'white'
            cats_found = ", ".join(sorted(d["categories"].keys()))
            html += f'<tr style="background:{bg};"><td style="padding:6px 12px;font-weight:500;">{p}</td><td style="padding:6px 12px;text-align:right;">{d["positive_count"]}</td><td style="padding:6px 12px;text-align:right;">{d["denial_count"]}</td><td style="padding:6px 12px;font-size:10px;">{cats_found}</td></tr>'
        html += '</table>'
    
    # --- SECTION 5: Detailed Findings (collapsible, all passages) ---
    html += f'<details style="margin-top:20px;"><summary style="cursor:pointer;color:#1B3A5C;font-weight:600;font-size:14px;">\U0001f4c4 Detailed Findings ({len(relevant_classified):,} classified passages)</summary>'
    html += '<table style="border-collapse:collapse;width:100%;font-size:11px;margin-top:10px;">'
    html += '<tr><th style="background:#1B3A5C;color:white;padding:7px 10px;">Provider</th><th style="background:#1B3A5C;color:white;padding:7px 10px;">Document</th><th style="background:#1B3A5C;color:white;padding:7px 10px;">Page</th><th style="background:#1B3A5C;color:white;padding:7px 10px;">Category</th><th style="background:#1B3A5C;color:white;padding:7px 10px;">Key Phrase</th><th style="background:#1B3A5C;color:white;padding:7px 10px;">Reasoning</th></tr>'
    for i, c in enumerate(relevant_classified[:200]):
        bg = '#f7f9fb' if i % 2 == 0 else 'white'
        cat_label = code_to_label.get(c.get('category', ''), c.get('category', ''))
        is_denial = code_to_denial.get(c.get('category', ''), False)
        cat_style = 'color:#D64045;font-weight:600;' if is_denial else 'color:#2E86AB;'
        fn = c.get('filename', '')[-40:] if len(c.get('filename', '')) > 40 else c.get('filename', '')
        html += f'<tr style="background:{bg};"><td style="padding:5px 8px;">{c.get("provider", "")}</td><td style="padding:5px 8px;font-size:9px;">{fn}</td><td style="padding:5px 8px;">{c.get("page", "?")}</td><td style="padding:5px 8px;{cat_style}">{cat_label}</td><td style="padding:5px 8px;font-style:italic;">{c.get("key_phrase", "")[:80]}</td><td style="padding:5px 8px;color:#555;">{c.get("reasoning", "")[:100]}</td></tr>'
    if len(relevant_classified) > 200:
        html += f'<tr><td colspan="6" style="padding:8px;color:#999;text-align:center;">... showing 200 of {len(relevant_classified):,} total passages</td></tr>'
    html += '</table></details>'
    
    # --- SECTION 6: Methodology ---
    html += f'''<details style="margin-top:15px;"><summary style="cursor:pointer;color:#1B3A5C;font-weight:600;font-size:13px;">\U0001f527 Methodology</summary>
    <div style="font-size:12px;color:#555;margin-top:8px;line-height:1.6;padding:10px;background:#f8f9fb;border-radius:8px;">
        <strong>7-Step Deep Analysis Pipeline:</strong><br>
        1. <strong>Question Understanding:</strong> LLM extracts intent, keywords, and target concept<br>
        1.5. <strong>Execution Plan:</strong> LLM triages keywords into core ({len(plan.get('core_keywords', []) if plan else [])}), extended ({len(plan.get('extended_keywords', []) if plan else [])}), excluded ({len(plan.get('excluded_keywords', []) if plan else [])}) with disambiguation rules<br>
        2. <strong>Dynamic Taxonomy:</strong> LLM generates {len(taxonomy)} sub-categories specific to "{target}"<br>
        3. <strong>Hybrid Retrieval:</strong> Vector Search semantic (100 results) + SQL keyword scan ({raw_keyword_count:,} raw matches) on 1.36M chunks<br>
        4. <strong>Relevance Scoring & Dedup:</strong> Keyword hit scoring (3=strong, 2=likely) \u2192 best per source_filename \u2192 {deduped_count:,} unique documents<br>
        5. <strong>LLM Classification:</strong> Claude Sonnet 4.5 classifies ALL {deduped_count:,} passages (batches of 10, 8 parallel workers)<br>
        6. <strong>Provider Rollup:</strong> Aggregate to provider level with MIXED detection (positive + denial in different docs)<br>
        7. <strong>Report Generation:</strong> Multi-section analytical report with executive summary, categories, findings, and action items<br>
        <br>
        <strong>Data Source:</strong> <code>dev_adb.raw.tbl_contract_fulltext_vs_ready</code> (1,361,179 chunks, 10,348 PDFs, {total_universe} providers)<br>
        <strong>Runtime:</strong> {elapsed:.1f}s | <strong>LLM Model:</strong> {LLM_MODEL}
    </div></details>'''
    
    # --- SECTION 7: Caveats ---
    html += '''<div style="margin-top:20px;padding:12px 16px;background:#fff9e6;border-radius:8px;font-size:11px;color:#666;border-left:3px solid #F18F01;">
        <strong>\u26A0\uFE0F Caveats:</strong><br>
        (1) <strong>No Mention \u2260 Prohibition</strong> \u2014 provisions may exist in unextracted or future documents.<br>
        (2) <strong>Best-chunk-per-file:</strong> Analysis takes the highest-scoring single chunk per document; multi-section clauses may span chunks.<br>
        (3) <strong>Amendment supersession:</strong> MIXED providers need temporal review \u2014 later amendments may override earlier provisions.<br>
        (4) <strong>LLM limitations:</strong> Classification accuracy depends on passage quality and context window.
    </div>'''
    
    return html

# ============================================================
# MAIN EXECUTION
# ============================================================
try:
    if not user_question.strip():
        displayHTML('<div style="padding:20px;color:#666;">\u2328\uFE0F Type a question above and re-run this cell.</div>')
    else:
        start_time = time.time()
        
        # --- Step 1: Get provider universe (CACHED — no re-query on repeat runs) ---
        print("\u2699\uFE0F  STEP 1: Loading provider universe...")
        all_provider_names = get_provider_universe()
        total_universe = len(all_provider_names)
        print(f"   Provider universe: {total_universe} providers (cached from tbl_contract_fulltext_vs_ready)")
        
        # --- Step 2: Understand the question ---
        print(f"\n\U0001f9e0  STEP 2: Analyzing question: '{user_question}'")
        understanding = understand_question(user_question)
        print(f"   Target: {understanding.get('target_concept', '?')}")
        print(f"   Type: {understanding.get('analysis_type', '?')} | Negative: {understanding.get('is_negative', False)}")
        print(f"   Keywords: {understanding.get('search_keywords', [])}")
        
        # --- Steps 2.5 + 3: Plan + Taxonomy IN PARALLEL (optimization: concurrent LLM calls) ---
        print(f"\n\U0001f4dd  STEPS 2.5+3: Creating execution plan + taxonomy (parallel)...")
        with ThreadPoolExecutor(max_workers=2) as setup_executor:
            plan_future = setup_executor.submit(create_execution_plan, understanding)
            taxonomy_future = setup_executor.submit(generate_taxonomy, understanding)
            plan = plan_future.result()
            taxonomy = taxonomy_future.result()
        
        # Print plan details
        print(f"   Plan strategy: {plan.get('precision_strategy', '?')} | Prevalence: {plan.get('expected_prevalence', '?')}")
        print(f"   Core keywords: {plan.get('core_keywords', [])}")
        if plan.get('extended_keywords'):
            print(f"   Extended (co-occurrence required): {plan['extended_keywords']}")
        if plan.get('excluded_keywords'):
            excluded_names = [e['keyword'] if isinstance(e, dict) else e for e in plan['excluded_keywords']]
            print(f"   Excluded (too noisy): {excluded_names}")
        if plan.get('disambiguation_rules'):
            print(f"   Disambiguation rules:")
            for rule in plan['disambiguation_rules'][:4]:
                print(f"     \u2022 {rule}")
        
        # Apply plan to refine understanding
        understanding = apply_plan_to_retrieval(understanding, plan)
        print(f"   Final search keywords: {understanding['search_keywords']}")
        
        # Print taxonomy
        print(f"   Taxonomy: {len(taxonomy)} categories:")
        for cat in taxonomy:
            denial_flag = " [DENIAL]" if cat.get("is_denial") else ""
            print(f"     - {cat['code']}: {cat['label']}{denial_flag}")
        
        # --- Step 4: Hybrid retrieval (Spark-side scoring + dedup) ---
        print(f"\n\U0001f50d  STEP 4: Hybrid Retrieval (Spark-side score + dedup)...")
        semantic_results, _keyword_df = hybrid_retrieval(understanding)
        raw_keyword_count = len(_keyword_df) if _keyword_df is not None else 0
        print(f"   Semantic: {len(semantic_results)} results")
        print(f"   Keyword SQL (pre-scored, pre-deduped in Spark): {raw_keyword_count:,} documents")
        if _keyword_df is not None and not _keyword_df.empty:
            kw_providers = _keyword_df["provider_name"].nunique()
            print(f"   Spanning {kw_providers} distinct providers")
        
        # --- Step 5: Merge semantic + keyword, final dedup ---
        print(f"\n\U0001f4ca  STEP 5: Merge channels & final dedup...")
        candidates = score_and_dedup(semantic_results, _keyword_df, understanding)
        deduped_count = len(candidates)
        print(f"   Final candidates to classify: {deduped_count:,} unique documents")
        
        if not candidates:
            displayHTML(section_header("Contract Intelligence", "") + '<div style="padding:20px;color:#666;">No relevant passages found in the corpus. Try different terms.</div>')
        else:
            # --- Step 6: LLM classification (ALL candidates, parallel) ---
            print(f"\n\U0001f916  STEP 6: LLM Classification of ALL {deduped_count:,} passages...")
            print(f"   Config: batches of 10, 14 parallel workers, taxonomy: {[c['code'] for c in taxonomy]}")
            classified = classify_all_passages(candidates, understanding, taxonomy)
            
            # Stats
            cat_stats = {}
            for c in classified:
                cat = c.get('category', 'UNKNOWN')
                cat_stats[cat] = cat_stats.get(cat, 0) + 1
            print(f"   Classification complete: {len(classified):,} passages classified")
            for cat, cnt in sorted(cat_stats.items(), key=lambda x: x[1], reverse=True):
                print(f"     {cat}: {cnt:,}")
            
            # --- Step 7: Provider rollup ---
            print(f"\n\U0001f465  STEP 7: Provider rollup with MIXED detection...")
            provider_data, no_mention = provider_rollup(classified, taxonomy, all_provider_names)
            has_n = sum(1 for d in provider_data.values() if d['status'] == 'HAS_PROVISION')
            denied_n = sum(1 for d in provider_data.values() if d['status'] == 'EXPLICITLY_DENIED')
            mixed_n = sum(1 for d in provider_data.values() if d['status'] == 'MIXED')
            print(f"   HAS: {has_n} | DENIED: {denied_n} | MIXED: {mixed_n} | NO_MENTION: {len(no_mention)}")
            print(f"   Total accounted: {has_n + denied_n + mixed_n + len(no_mention)} / {total_universe}")
            
            # --- Build report ---
            elapsed = time.time() - start_time
            print(f"\n\u2705  Analysis complete in {elapsed:.1f}s. Rendering report...")
            
            report_html = build_report(
                user_question, understanding, classified, provider_data, 
                no_mention, taxonomy, elapsed, total_universe, raw_keyword_count, deduped_count, plan
            )
            
            # Question header
            question_html = f'''<div style="background:linear-gradient(135deg,#eef6ff,#f0f0ff);border-left:4px solid #2E86AB;padding:15px 20px;border-radius:0 8px 8px 0;margin:15px 0;">
                <div style="font-size:16px;color:#1B3A5C;font-weight:600;">{user_question}</div>
                <div style="margin-top:8px;">
                    <span style="background:#1B3A5C;color:white;padding:3px 10px;border-radius:12px;font-size:11px;">Deep Analysis V2</span>
                    <span style="color:#666;font-size:11px;margin-left:8px;">Target: {understanding.get('target_concept', '?')} | {total_universe} providers | {deduped_count:,} docs | {elapsed:.0f}s</span>
                </div>
            </div>'''
            
            displayHTML(question_html + report_html)

except Exception as e:
    displayHTML(f'<div style="color:#D64045;padding:20px;">\u26A0\uFE0F Error: {str(e)}<br><pre style="font-size:10px;color:#333;background:#f8f8f8;padding:10px;border-radius:6px;margin-top:8px;">{traceback.format_exc()[-800:]}</pre></div>')

# COMMAND ----------

# DBTITLE 1,Example Questions to Try
# MAGIC %md
# MAGIC ### Example Questions to Try
# MAGIC
# MAGIC Type any question in the widget above and re-run Cell 6. The engine runs a **7-step deep analysis pipeline**:
# MAGIC
# MAGIC | Question | What the Engine Does |
# MAGIC |---|---|
# MAGIC | *Which contracts don't have an offset clause?* | Hybrid retrieval (1.36M chunks) → LLM classification → provider rollup showing HAS/NO_MENTION/DENIED |
# MAGIC | *What are the termination notice requirements across providers?* | Extracts termination language from all contracts, classifies by notice period |
# MAGIC | *Which providers have auto-renewal clauses?* | Corpus-wide scan for auto-renewal provisions with key phrases and evidence |
# MAGIC | *Do any contracts have arbitration vs litigation provisions?* | Identifies dispute resolution mechanisms and categorizes by type |
# MAGIC | *Which providers have stop-loss provisions and what are the thresholds?* | Finds stop-loss language, extracts dollar thresholds, provider comparison |
# MAGIC
# MAGIC **How it works (same methodology as full production reports):**
# MAGIC 1. LLM extracts search keywords + synonyms from your question
# MAGIC 2. Dual-channel retrieval: Vector Search (semantic) + SQL keyword scan on 1.36M text chunks
# MAGIC 3. Relevance scoring & deduplication (best passage per document)
# MAGIC 4. LLM classifies each passage: CONFIRMED_PRESENT / EXPLICITLY_DENIED / NOT_RELEVANT
# MAGIC 5. Provider-level rollup with evidence table, key phrases, and caveats
# MAGIC
# MAGIC > **One question → Full analytical report** with executive summary, evidence table, and coverage notes.

# COMMAND ----------

# DBTITLE 1,Demo Script — Leadership Talking Points
# MAGIC %md
# MAGIC ---
# MAGIC ## 🎯 Demo Script — Leadership Talking Points
# MAGIC
# MAGIC ### What We Built
# MAGIC An AI-powered platform that transforms **27 GB of raw provider contract PDFs** into structured, queryable intelligence — in weeks, not years.
# MAGIC
# MAGIC ### Scale & Coverage
# MAGIC | Dimension | Achievement |
# MAGIC |-----------|-------------|
# MAGIC | Providers | 271 under active management |
# MAGIC | Documents | 10,372 PDFs fully codified |
# MAGIC | Legal Passages | 83,008 searchable units |
# MAGIC | Rate Entries | 6,683 current rates tracked |
# MAGIC | Amendments | 2,254 change events indexed |
# MAGIC | Contract Terms | 45,718 clauses + definitions |
# MAGIC
# MAGIC ### Key Capabilities Demonstrated
# MAGIC 1. **Portfolio Analytics** — Real-time KPIs, agreement composition, status tracking
# MAGIC 2. **Provider Deep Dive** — Instant access to any provider's full contract profile
# MAGIC 3. **Rate Benchmarking** — P25/P50/P75/P90 positioning across the network
# MAGIC 4. **Renewal Intelligence** — Priority-scored watchlist with savings opportunities
# MAGIC 5. **Contract Q&A (RAG)** — Natural language questions answered from actual contract text with citations
# MAGIC 6. **SQL Generation** — Business users ask questions in English, get data answers instantly
# MAGIC
# MAGIC ### Technology Stack
# MAGIC * **Databricks Unity Catalog** — Governed data layer
# MAGIC * **Vector Search** — 83K passages indexed for semantic retrieval
# MAGIC * **Claude Sonnet 4.5** — Extraction + Q&A + SQL generation
# MAGIC * **Delta Lake** — ACID-compliant analytical tables
# MAGIC * **Databricks Apps** — Self-service web interface (deployed)
# MAGIC
# MAGIC ### ROI & Business Impact
# MAGIC * \~**90% reduction** in manual contract review time
# MAGIC * **Instant access** to termination terms, rate details, and obligations (previously: hours/days)
# MAGIC * **Proactive renewal management** — never miss a deadline or savings opportunity
# MAGIC * **Network-wide benchmarking** — data-driven negotiation leverage
# MAGIC * **Compliance assurance** — every clause searchable and auditable
# MAGIC
# MAGIC ### Next Steps
# MAGIC 1. Process remaining \~7,000 PDFs (pipeline proven, just compute time)
# MAGIC 2. Connect claims feed for cost-to-rate analysis
# MAGIC 3. Deploy automated renewal alerts (30/60/90 day)
# MAGIC 4. Production Genie Space for self-service analytics
# MAGIC 5. Cross-encoder reranker for improved RAG precision