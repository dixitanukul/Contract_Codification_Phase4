-- ═══════════════════════════════════════════════════════════════════════════════
-- REIMBURSEMENT MODEL V2 — Taxonomy Seed Data (Part 4 of 5)
-- 
-- ~50 rows in dim_service_line_taxonomy (full 4-level hierarchy)
-- ~30 rows in dim_service_line_patterns (replaces 25-entry CASE WHEN)
-- 
-- Prerequisites: V2_REIMB_01_DDL_tables.sql executed
-- Source: SERVICE_LINE_NORMALIZATION.md §2.1 hierarchy + 13_build_serving.py CASE WHEN
-- ═══════════════════════════════════════════════════════════════════════════════

-- ─────────────────────────────────────────────────────────────────────────────
-- TAXONOMY: dim_service_line_taxonomy
-- Columns: service_line_id, service_line_code, level, domain, parent_id,
--          display_name, short_name, match_patterns, match_priority,
--          cms_category, drg_range, apc_range, revenue_code_range,
--          sort_order, is_active, comparable_group
-- ─────────────────────────────────────────────────────────────────────────────

-- === INPATIENT DOMAIN ===
INSERT INTO dev_adb.raw.dim_service_line_taxonomy VALUES
-- Level 0: Domain root
(100, 'IP', 0, 'INPATIENT', NULL, 'Inpatient', 'IP', '[]', 0, NULL, NULL, NULL, NULL, 1, TRUE, NULL),

-- Level 1: Service Groups
(110, 'IP_ACUTE', 1, 'INPATIENT', 100, 'Acute Care', NULL, '[]', 0, NULL, NULL, NULL, NULL, 2, TRUE, NULL),
(120, 'IP_SPECIALTY', 1, 'INPATIENT', 100, 'Specialty Care', NULL, '[]', 0, NULL, NULL, NULL, NULL, 15, TRUE, NULL),
(130, 'IP_SUBACUTE', 1, 'INPATIENT', 100, 'Subacute/SNF', NULL, '[]', 0, NULL, NULL, NULL, NULL, 20, TRUE, NULL),
(140, 'IP_MATERNITY', 1, 'INPATIENT', 100, 'Maternity', NULL, '[]', 0, NULL, '768-782', NULL, NULL, 25, TRUE, NULL),

-- Level 2: Acute Care service lines
(111, 'IP_ACUTE_MEDSURG', 2, 'INPATIENT', 110, 'Medical/Surgical/Peds', 'Med/Surg', '["%Medical/Surgical%","%Med/Surg%","%Med-Surg%","%Pediatric%"]', 10, 'medsurg', NULL, NULL, '0200-0219', 3, TRUE, 'medsurg'),
(112, 'IP_ACUTE_ICU', 2, 'INPATIENT', 110, 'ICU/CCU/PICU', 'ICU', '["%ICU%","%CCU%","%PICU%","%Critical Care%","%Intensive%"]', 20, 'icu', NULL, NULL, '0210-0219', 4, TRUE, 'icu'),
(113, 'IP_ACUTE_NICU4', 2, 'INPATIENT', 110, 'NICU Level IV', 'NICU IV', '["%NICU%IV%","%NICU%Level 4%"]', 30, 'nicu', NULL, NULL, NULL, 5, TRUE, 'nicu'),
(114, 'IP_ACUTE_NICU3', 2, 'INPATIENT', 110, 'NICU Level III', 'NICU III', '["%NICU%III%","%NICU%Level 3%"]', 29, 'nicu', NULL, NULL, NULL, 6, TRUE, 'nicu'),
(115, 'IP_ACUTE_NICU2', 2, 'INPATIENT', 110, 'NICU Level II', 'NICU II', '["%NICU%II%","%NICU%Level 2%"]', 28, 'nicu', NULL, NULL, NULL, 7, TRUE, 'nicu'),
(116, 'IP_ACUTE_NICU1', 2, 'INPATIENT', 110, 'NICU Level I', 'NICU I', '["%NICU%","%Neonatal%"]', 5, 'nicu', NULL, NULL, NULL, 8, TRUE, 'nicu'),

-- Level 2: Specialty Care
(121, 'IP_SPEC_CARDIAC', 2, 'INPATIENT', 120, 'Cardiac', NULL, '["%Cardiac%","%Heart%","%CABG%","%PTCA%"]', 15, NULL, '215-285', NULL, NULL, 16, TRUE, 'cardiac'),
(122, 'IP_SPEC_PSYCH', 2, 'INPATIENT', 120, 'Psychiatric/Behavioral', 'Psych', '["%Psych%","%Behavioral%","%Mental%"]', 10, NULL, '876-897', NULL, NULL, 17, TRUE, 'psych'),
(123, 'IP_SPEC_REHAB', 2, 'INPATIENT', 120, 'Rehabilitation', 'Rehab', '["%Rehab%","%Rehabilitation%"]', 10, NULL, '945-946', NULL, NULL, 18, TRUE, 'rehab'),
(124, 'IP_SPEC_TRANSPLANT', 2, 'INPATIENT', 120, 'Transplant', NULL, '["%Transplant%"]', 20, NULL, '001-017', NULL, NULL, 19, TRUE, 'transplant'),

-- Level 2: Subacute
(131, 'IP_SUB_L1', 2, 'INPATIENT', 130, 'Subacute Level I', 'Sub I', '["%Subacute%I%","%Sub-Acute%Level 1%","%SNF%Level 1%"]', 10, NULL, NULL, NULL, NULL, 21, TRUE, 'subacute'),
(132, 'IP_SUB_L2', 2, 'INPATIENT', 130, 'Subacute Level II', 'Sub II', '["%Subacute%II%","%Sub-Acute%Level 2%","%SNF%Level 2%"]', 11, NULL, NULL, NULL, NULL, 22, TRUE, 'subacute'),
(133, 'IP_SUB_L3', 2, 'INPATIENT', 130, 'Subacute Level III', 'Sub III', '["%Subacute%III%","%Sub-Acute%Level 3%","%SNF%Level 3%"]', 12, NULL, NULL, NULL, NULL, 23, TRUE, 'subacute'),

-- Level 2: Maternity
(141, 'IP_MAT_NORMAL', 2, 'INPATIENT', 140, 'Normal Delivery', NULL, '["%Normal Delivery%","%Vaginal%"]', 10, NULL, '768-770', NULL, NULL, 26, TRUE, 'maternity'),
(142, 'IP_MAT_CSECTION', 2, 'INPATIENT', 140, 'C-Section', NULL, '["%C-Section%","%Cesarean%","%C Section%"]', 10, NULL, '765-766', NULL, NULL, 27, TRUE, 'maternity'),
(143, 'IP_MAT_BOARDER', 2, 'INPATIENT', 140, 'Boarder Baby/Well Newborn', 'Boarder', '["%Boarder%","%Well Newborn%","%Well Baby%","%Nursery%"]', 10, NULL, NULL, NULL, NULL, 28, TRUE, 'maternity');

-- === OUTPATIENT DOMAIN ===
INSERT INTO dev_adb.raw.dim_service_line_taxonomy VALUES
-- Level 0: Domain root
(200, 'OP', 0, 'OUTPATIENT', NULL, 'Outpatient', 'OP', '[]', 0, NULL, NULL, NULL, NULL, 30, TRUE, NULL),

-- Level 1: Service Groups
(210, 'OP_SURGICAL', 1, 'OUTPATIENT', 200, 'Surgical', NULL, '["%Surgical%","%Surgery%"]', 0, NULL, NULL, NULL, NULL, 31, TRUE, NULL),
(220, 'OP_EMERGENCY', 1, 'OUTPATIENT', 200, 'Emergency', 'ER', '["%Emergency%","%ER %","%Urgent%"]', 10, NULL, NULL, NULL, '0450-0459', 42, TRUE, NULL),
(230, 'OP_THERAPY', 1, 'OUTPATIENT', 200, 'Therapy Services', NULL, '["%Therapy%"]', 0, NULL, NULL, NULL, NULL, 50, TRUE, NULL),
(240, 'OP_DIAGNOSTIC', 1, 'OUTPATIENT', 200, 'Diagnostic', NULL, '["%Radiology%","%Pathology%","%Lab%","%Imaging%","%Diagnostic%"]', 0, NULL, NULL, NULL, NULL, 55, TRUE, NULL),
(250, 'OP_INFUSION', 1, 'OUTPATIENT', 200, 'Infusion/Injection', NULL, '["%Infusion%","%Injection%","%Chemotherapy%","%Chemo%"]', 10, NULL, NULL, NULL, NULL, 60, TRUE, NULL),

-- Level 2: Surgical tiers (10 tiers per typical contract)
(211, 'OP_SURG_TIER1', 2, 'OUTPATIENT', 210, 'Tier 1 - Minor', 'T1', '["%Tier 1%","%Tier I %","%Minor%Surg%"]', 10, NULL, NULL, NULL, NULL, 32, TRUE, 'op_surgical'),
(212, 'OP_SURG_TIER2', 2, 'OUTPATIENT', 210, 'Tier 2 - Intermediate Low', 'T2', '["%Tier 2%","%Tier II%"]', 10, NULL, NULL, NULL, NULL, 33, TRUE, 'op_surgical'),
(213, 'OP_SURG_TIER3', 2, 'OUTPATIENT', 210, 'Tier 3 - Intermediate', 'T3', '["%Tier 3%","%Tier III%"]', 10, NULL, NULL, NULL, NULL, 34, TRUE, 'op_surgical'),
(214, 'OP_SURG_TIER4', 2, 'OUTPATIENT', 210, 'Tier 4 - Intermediate High', 'T4', '["%Tier 4%","%Tier IV%"]', 10, NULL, NULL, NULL, NULL, 35, TRUE, 'op_surgical'),
(215, 'OP_SURG_TIER5', 2, 'OUTPATIENT', 210, 'Tier 5 - Moderate', 'T5', '["%Tier 5%","%Tier V %"]', 10, NULL, NULL, NULL, NULL, 36, TRUE, 'op_surgical'),
(216, 'OP_SURG_TIER6', 2, 'OUTPATIENT', 210, 'Tier 6 - Moderate High', 'T6', '["%Tier 6%","%Tier VI%"]', 10, NULL, NULL, NULL, NULL, 37, TRUE, 'op_surgical'),
(217, 'OP_SURG_TIER7', 2, 'OUTPATIENT', 210, 'Tier 7 - Complex Low', 'T7', '["%Tier 7%","%Tier VII%"]', 10, NULL, NULL, NULL, NULL, 38, TRUE, 'op_surgical'),
(218, 'OP_SURG_TIER8', 2, 'OUTPATIENT', 210, 'Tier 8 - Complex', 'T8', '["%Tier 8%","%Tier VIII%"]', 10, NULL, NULL, NULL, NULL, 39, TRUE, 'op_surgical'),
(219, 'OP_SURG_TIER9', 2, 'OUTPATIENT', 210, 'Tier 9 - Complex High', 'T9', '["%Tier 9%","%Tier IX%"]', 10, NULL, NULL, NULL, NULL, 40, TRUE, 'op_surgical'),
(2110, 'OP_SURG_TIER10', 2, 'OUTPATIENT', 210, 'Tier 10 - Major', 'T10', '["%Tier 10%","%Tier X %","%Major%Surg%"]', 10, NULL, NULL, NULL, NULL, 41, TRUE, 'op_surgical'),

-- Level 2: Therapy subtypes
(231, 'OP_THER_PT', 2, 'OUTPATIENT', 230, 'Physical Therapy', 'PT', '["%Physical Therapy%","%PT %"]', 10, NULL, NULL, NULL, NULL, 51, TRUE, 'therapy'),
(232, 'OP_THER_OT', 2, 'OUTPATIENT', 230, 'Occupational Therapy', 'OT', '["%Occupational%","%OT %"]', 10, NULL, NULL, NULL, NULL, 52, TRUE, 'therapy'),
(233, 'OP_THER_ST', 2, 'OUTPATIENT', 230, 'Speech Therapy', 'ST', '["%Speech%"]', 10, NULL, NULL, NULL, NULL, 53, TRUE, 'therapy'),
(234, 'OP_THER_RT', 2, 'OUTPATIENT', 230, 'Respiratory Therapy', 'RT', '["%Respiratory%"]', 10, NULL, NULL, NULL, NULL, 54, TRUE, 'therapy');

-- === PROFESSIONAL DOMAIN ===
INSERT INTO dev_adb.raw.dim_service_line_taxonomy VALUES
(300, 'PROF', 0, 'PROFESSIONAL', NULL, 'Professional', 'Prof', '[]', 0, NULL, NULL, NULL, NULL, 70, TRUE, NULL),
(310, 'PROF_PHYSICIAN', 1, 'PROFESSIONAL', 300, 'Physician Services', 'Physician', '["%Physician%","%Doctor%"]', 0, NULL, NULL, NULL, NULL, 71, TRUE, NULL),
(320, 'PROF_ANESTHESIA', 1, 'PROFESSIONAL', 300, 'Anesthesia', NULL, '["%Anesthesia%","%Anesthesiol%"]', 10, NULL, NULL, NULL, NULL, 72, TRUE, NULL),
(330, 'PROF_ALLIED', 1, 'PROFESSIONAL', 300, 'Allied Health', NULL, '["%Allied%","%Nurse Pract%","%PA %","%Midwi%"]', 0, NULL, NULL, NULL, NULL, 73, TRUE, NULL);

-- === CAPITATION DOMAIN ===
INSERT INTO dev_adb.raw.dim_service_line_taxonomy VALUES
(400, 'CAP', 0, 'CAPITATION', NULL, 'Capitation', 'Cap', '[]', 0, NULL, NULL, NULL, NULL, 80, TRUE, NULL),
(410, 'CAP_AGED', 2, 'CAPITATION', 400, 'Aged', NULL, '["%Aged%","%Senior%","%65+%"]', 10, NULL, NULL, NULL, NULL, 81, TRUE, 'capitation'),
(420, 'CAP_DISABLED', 2, 'CAPITATION', 400, 'Disabled', NULL, '["%Disabled%","%Disability%"]', 10, NULL, NULL, NULL, NULL, 82, TRUE, 'capitation'),
(430, 'CAP_FAMILY', 2, 'CAPITATION', 400, 'Family/Child', NULL, '["%Family%","%Child%","%TANF%","%Children%"]', 10, NULL, NULL, NULL, NULL, 83, TRUE, 'capitation'),
(440, 'CAP_MCE', 2, 'CAPITATION', 400, 'MCE', NULL, '["%MCE%","%Medi-Cal Expansion%"]', 10, NULL, NULL, NULL, NULL, 84, TRUE, 'capitation');

-- ─────────────────────────────────────────────────────────────────────────────
-- PATTERNS: dim_service_line_patterns
-- Replaces the 25 CASE WHEN entries from 13_build_serving.py lines 111-129
-- Plus additional patterns for improved coverage
-- 
-- Columns: pattern_id, service_line_id, pattern_type, pattern_value,
--          exclude_pattern, priority, applies_to_domain, applies_to_provider
-- ─────────────────────────────────────────────────────────────────────────────
INSERT INTO dev_adb.raw.dim_service_line_patterns VALUES
-- INPATIENT patterns (from original CASE WHEN + expansions)
(1,  111, 'ILIKE', '%Medical/Surgical%', NULL, 10, 'INPATIENT', NULL),
(2,  111, 'ILIKE', '%Med/Surg%', NULL, 10, 'INPATIENT', NULL),
(3,  111, 'ILIKE', '%Med-Surg%', NULL, 10, 'INPATIENT', NULL),
(4,  111, 'ILIKE', '%Pediatric%', '%PICU%', 5, 'INPATIENT', NULL),  -- Exclude PICU → goes to ICU
(5,  112, 'ILIKE', '%ICU%', NULL, 20, 'INPATIENT', NULL),
(6,  112, 'ILIKE', '%CCU%', NULL, 20, 'INPATIENT', NULL),
(7,  112, 'ILIKE', '%PICU%', NULL, 20, 'INPATIENT', NULL),
(8,  112, 'ILIKE', '%Critical Care%', NULL, 15, 'INPATIENT', NULL),
(9,  112, 'ILIKE', '%Intensive%', NULL, 10, 'INPATIENT', NULL),
(10, 113, 'ILIKE', '%NICU%IV%', NULL, 30, 'INPATIENT', NULL),
(11, 113, 'ILIKE', '%NICU%Level 4%', NULL, 30, 'INPATIENT', NULL),
(12, 114, 'ILIKE', '%NICU%III%', NULL, 29, 'INPATIENT', NULL),
(13, 115, 'ILIKE', '%NICU%II%', '%III%', 28, 'INPATIENT', NULL),  -- Exclude III
(14, 116, 'ILIKE', '%NICU%', '%Level%', 5, 'INPATIENT', NULL),     -- Catch-all NICU
(15, 116, 'ILIKE', '%Neonatal%', NULL, 5, 'INPATIENT', NULL),
(16, 121, 'ILIKE', '%Cardiac%', NULL, 15, 'INPATIENT', NULL),
(17, 122, 'ILIKE', '%Psych%', NULL, 10, 'INPATIENT', NULL),
(18, 122, 'ILIKE', '%Behavioral%', NULL, 10, 'INPATIENT', NULL),
(19, 123, 'ILIKE', '%Rehab%', NULL, 10, 'INPATIENT', NULL),
(20, 124, 'ILIKE', '%Transplant%', NULL, 20, 'INPATIENT', NULL),
(21, 131, 'ILIKE', '%Subacute%I%', '%II%', 10, 'INPATIENT', NULL),
(22, 132, 'ILIKE', '%Subacute%II%', '%III%', 11, 'INPATIENT', NULL),
(23, 133, 'ILIKE', '%Subacute%III%', NULL, 12, 'INPATIENT', NULL),
(24, 133, 'ILIKE', '%Sub-Acute%Level 3%', NULL, 12, 'INPATIENT', NULL),
(25, 141, 'ILIKE', '%Normal Delivery%', NULL, 10, 'INPATIENT', NULL),
(26, 142, 'ILIKE', '%C-Section%', NULL, 10, 'INPATIENT', NULL),
(27, 142, 'ILIKE', '%Cesarean%', NULL, 10, 'INPATIENT', NULL),
(28, 143, 'ILIKE', '%Boarder%', NULL, 10, 'INPATIENT', NULL),
(29, 143, 'ILIKE', '%Well Newborn%', NULL, 10, 'INPATIENT', NULL),
(30, 143, 'ILIKE', '%Nursery%', NULL, 5, 'INPATIENT', NULL),

-- OUTPATIENT patterns
(31, 220, 'ILIKE', '%Emergency%', NULL, 15, 'OUTPATIENT', NULL),
(32, 220, 'ILIKE', '%ER %', NULL, 10, 'OUTPATIENT', NULL),
(33, 220, 'ILIKE', '%Urgent Care%', NULL, 10, 'OUTPATIENT', NULL),
(34, 250, 'ILIKE', '%Infusion%', NULL, 10, 'OUTPATIENT', NULL),
(35, 250, 'ILIKE', '%Chemotherapy%', NULL, 15, 'OUTPATIENT', NULL),
(36, 231, 'ILIKE', '%Physical Therapy%', NULL, 10, 'OUTPATIENT', NULL),
(37, 232, 'ILIKE', '%Occupational%', NULL, 10, 'OUTPATIENT', NULL),
(38, 233, 'ILIKE', '%Speech%', NULL, 10, 'OUTPATIENT', NULL),
(39, 240, 'ILIKE', '%Radiology%', NULL, 10, 'OUTPATIENT', NULL),
(40, 240, 'ILIKE', '%Lab%', NULL, 5, 'OUTPATIENT', NULL),

-- CAPITATION patterns
(41, 410, 'ILIKE', '%Aged%', NULL, 10, 'CAPITATION', NULL),
(42, 420, 'ILIKE', '%Disabled%', NULL, 10, 'CAPITATION', NULL),
(43, 430, 'ILIKE', '%Family%', NULL, 10, 'CAPITATION', NULL),
(44, 430, 'ILIKE', '%Child%', NULL, 5, 'CAPITATION', NULL),
(45, 440, 'ILIKE', '%MCE%', NULL, 15, 'CAPITATION', NULL);
