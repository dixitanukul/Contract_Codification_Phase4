# Contract Intelligence V4 — Active Request Lifecycle

**Report**: 3 of N  
**Date**: 2026-07-26  
**Author**: Genie Code (automated audit assistant)  
**Status**: COMPLETE  
**Prerequisite**: Reports 1 (Scoping) and 2 (Repository Map & Liveness)

---

## 1. Executive Summary

This report traces the **complete active lifecycle** of a user question from frontend submit to rendered answer. The system operates as a bounded ReAct (Reason → Act → Observe) loop with multiple early-exit fast paths.

**Critical architectural finding (F-006 CONFIRMED → UPGRADED to F-006a):**  
`agent_controller.py` is 8,465 lines containing **3 complete copies** of the controller body. Python uses the *last* definition when methods share a name. The active methods are:

| Method | Active Line | Dead Copies (shadowed) |
| --- | --- | --- |
| `_run_direct_dispatch` | 6570 | 2738, 4815 |
| `_maybe_decompose` | 8187 | 4049, 5797 |
| `_run_decomposed` | 8195 | 4057, 5805 |
| `_build_response` | 6344 | 2512, 4589 |
| `_maybe_route` | 6562 | 2730, 4807 |
| `_format_steps` | 6080 | 2252, 4332 |
| `_evidence_summary` | 6096 | 2268, 4348 |
| `_sanitize_answer` | 6128 | 2300, 4380 |
| `_format_rows_as_markdown` | 6172 | 2344, 4424 |
| `_best_effort_synthesis` | 6321 | 2489, 4566 |

This means ~5,800 lines (69%) of agent_controller.py are **dead shadowed code** that can never execute but can confuse developers reading the file.

---

## 2. Architecture Diagram (Active Flow)

```
┌─────────────────────────────────────────────────────────────────────────┐
│                        FRONTEND (React/Vite)                            │
│  ChatPageV2 → POST /api/v1/query {question, provider_name, stream, sid}│
└────────────────────────────────┬────────────────────────────────────────┘
                                 │ HTTPS
┌────────────────────────────────▼────────────────────────────────────────┐
│                  FastAPI (app/main.py)                                  │
│  query() → session_id resolution → StreamingResponse | run_in_executor │
│  _stream_generator() → runtime.stream_ask() in ThreadPool              │
└────────────────────────────────┬────────────────────────────────────────┘
                                 │ sync call
┌────────────────────────────────▼────────────────────────────────────────┐
│             NotebookRuntime (notebook_entry.py)                         │
│  ask() → load_session(sid) → context_manager.resume_session()          │
│         → AgentController.run(AgentRequest)                            │
└────────────────────────────────┬────────────────────────────────────────┘
                                 │
┌────────────────────────────────▼────────────────────────────────────────┐
│            AgentController.run() [line 1146]                            │
│                                                                        │
│  ┌── Pre-flight Guards ──────────────────────────────────┐             │
│  │  1. Quote stripping (BUG-1 FIX)                       │             │
│  │  2. Profile facts injection (_inject_profile_facts)    │             │
│  │  3. Empty input guard → canned response               │             │
│  │  4. Temporal real-time guard ("yesterday","today")     │             │
│  │  5. Contract-value guard ("total dollar value")       │             │
│  │  6. Contact-info guard (PII/phone/email)              │             │
│  └───────────────────────────────────────────────────────┘             │
│                           │ passes all guards                          │
│  ┌── Multi-turn context enrichment ──────────────────────┐             │
│  │  Coreference resolution ("compare those") via history │             │
│  └───────────────────────────────────────────────────────┘             │
│                           │                                            │
│  ┌── Short-circuits (before routing) ────────────────────┐             │
│  │  a. LOB analytics → rate_query direct                 │             │
│  │  b. Stop-loss multi-type → rate_query direct          │             │
│  │  c. Stop-loss compound → rate_query direct            │             │
│  │  d. Recent amendment → sql_query direct               │             │
│  └───────────────────────────────────────────────────────┘             │
│                           │ no short-circuit matched                   │
│  ┌── Routing Layer ──────────────────────────────────────┐             │
│  │  _maybe_route() → QuestionRouter.route()              │             │
│  │  → _run_direct_dispatch() [line 6570]                 │             │
│  │     → Single-tool call → validation → return          │             │
│  └─────────────────┬─────────────────────────────────────┘             │
│                    │ returns None (fall-through)                        │
│  ┌── Decomposition ──────────────────────────────────────┐             │
│  │  _maybe_decompose() → QuestionDecomposer.analyze()    │             │
│  │  if COMPLEX → _run_decomposed() [line 8195]           │             │
│  │     → sub-question mini-ReAct loops → synthesis       │             │
│  └─────────────────┬─────────────────────────────────────┘             │
│                    │ is_simple=True                                     │
│  ┌── Full ReAct Loop ────────────────────────────────────┐             │
│  │  for step in 1..max_steps(10):                        │             │
│  │    _react_step() → _call_reasoning_llm()              │             │
│  │    → LLM returns {action, tool_name, tool_input}      │             │
│  │    → execute tool via registry.get(tool_name)._run()  │             │
│  │    → accumulate results → PERF-1 max-hops(5) guard    │             │
│  │    → if SYNTHESIZE → _validate_answer() → break       │             │
│  └───────────────────────────────────────────────────────┘             │
│                           │                                            │
│  ┌── Response Assembly [line 6344] ──────────────────────┐             │
│  │  _build_response():                                   │             │
│  │    1. Collect & filter citations (provider scoped)    │             │
│  │    2. Deduplicate by (filename, page_number)          │             │
│  │    3. Confidence: min of tool confidences             │             │
│  │    4. Hallucination guard (5 checks, zero-LLM-cost)   │             │
│  │    5. P5-CONF confidence upgrade (SQL evidence)       │             │
│  │    6. _sanitize_answer() last-mile cleanup            │             │
│  │    7. Emit StreamEvent.FINAL_ANSWER                   │             │
│  │    8. Return AgentResponse                            │             │
│  └───────────────────────────────────────────────────────┘             │
└────────────────────────────────┬────────────────────────────────────────┘
                                 │ AgentResponse
┌────────────────────────────────▼────────────────────────────────────────┐
│  stream_ask() → yields SSE events → _stream_generator() → NDJSON      │
│  → _persist_turn() → SessionRepo.save() → Delta table                 │
└────────────────────────────────┬────────────────────────────────────────┘
                                 │ SSE/JSON
┌────────────────────────────────▼────────────────────────────────────────┐
│  Frontend renders: answer_chunk → citations → confidence → done        │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## 3. Stage-by-Stage Lifecycle Detail

### 3.1 App Open & Frontend Initialization

| Attribute | Detail |
| --- | --- |
| Entry | `app.yaml` → `uvicorn app.main:app --host 0.0.0.0 --port 8000` |
| Lifespan | `lifespan()` context manager → `_lifespan_init(app)` background task |
| Init duration | ~30-150s (SQL/VS/LLM warmup in background) |
| Static serving | `app/static/index.html` + bundled JS/CSS (React build) |
| Init-not-ready | `GET /api/v1/startup-status` returns `{"ready": false, "eta_seconds": N}` |
| Frontend retry | Polls `/health` until `dependencies.runtime = "ok"` |

**Lifespan init sequence** (`main.py:230`):
1. Build WarehouseSpark (Statement Execution API) — no classic Spark needed
2. Create DatabricksLLMClient.from_sdk()
3. Create VectorSearchService
4. Create WorkspaceConfig, Settings
5. Create CurrentEffectiveFilter, RetrievalService, TelemetryRepo
6. Create ProvenanceResolver, ProviderService
7. Create GenieClient (GENIE_ENABLED=True)
8. `init_runtime()` → `NotebookRuntime()` → `_build_registry()` (25 tools)
9. Create TelemetryWriter, SessionRepo, FeedbackRepo
10. Set `app.state.runtime_ready = True`

**Error handling**: Each component wraps in try/except. If LLM or VS init fails, the app still starts (serves frontend + provider list) but `/api/v1/query` returns 503.

### 3.2 Conversation Creation / Loading

| Attribute | Detail |
| --- | --- |
| File | `app/main.py:899-906` |
| First message | `session_id=""` → generate UUID, skip `load_session()` |
| Follow-up | `session_id` present → `runtime.ask(session_id=sid)` triggers load |
| Load path | `notebook_entry.py:408` → `SessionRepo.load_session(sid)` → SQL query on `tbl_agent_sessions` |
| Resume path | `context_manager.resume_session(sid, question, rows)` → rebuilds conversation_history, resolved_entities |
| Fallback | If load fails → warning logged, `resumed_context=None`, proceeds without history |
| Persistence | Post-response: `_persist_turn()` → `SessionRepo.save(SessionRecord)` → Delta write |
| MT buffer | Sync in-memory buffer (`_sync_repo._buffer.append`) ensures next-turn visibility before Delta commit |

### 3.3 Question Submit → Backend Receipt

| Attribute | Detail |
| --- | --- |
| Frontend payload | `POST /api/v1/query` with `QueryRequest{question, provider_name, stream, session_id}` |
| Rate limiting | `slowapi` middleware (not inspected in detail) |
| PII redaction | `app/middleware/` — applied before handler |
| Runtime check | If `runtime is None` → 503 with ETA and available_features |
| Streaming decision | `req.stream=True` → `StreamingResponse(_stream_generator(...))` |
| Non-streaming | `loop.run_in_executor(_EXECUTOR, runtime.ask(...))` |
| Executor | `concurrent.futures.ThreadPoolExecutor` (shared) |

### 3.4 Classification / Routing

**QuestionRouter** (`question_router.py:124`):

| Step | Detail |
| --- | --- |
| Provider detection | Exact substring match against all canonical names → alias/capitalized-token resolution via ProviderService.resolve() |
| Route decision | LLM-based (if llm_client present) OR heuristic (keyword matching) |
| Override rules | 6 deterministic overrides: RE-1 (rate rescue), RE-2 (unresolvable comparison), CE-FIX (concept extraction), EXTR (extraction redirect), CONSTR (provider count), PROF-SQL (profile shortcut) |
| Output | `RoutingDecision(route, tool_name, providers, concepts, target_concept, search_keywords, is_negative, confidence)` |
| LLM model | `databricks-claude-sonnet-4-6` (same as reasoning) |
| LLM fallback | On any exception → `_heuristic_route()` |

**16 recognized routes** (mapped to tools):

| Route | Tool | When |
| --- | --- | --- |
| clause_existence | clause_existence | "Does X have Y clause?" (non-profile clauses) |
| structured_extraction | field_extraction | Specific value extraction (days, amounts, limits) |
| single_provider | provider_deep_dive | One provider's overview |
| comparison | comparison | Compare 2+ providers |
| rate_query | rate_query | Rates, costs, PMPM, per diem |
| explanation | explanation | "Explain", "Describe" |
| multi_concept | multi_concept | 2+ concepts with AND/OR logic |
| temporal | temporal_analysis | Changes over time, amendment history |
| sql_query | sql_query | Profile lookups, counts, aggregations |
| risk_alert | risk_alert | Risk scores, alerts, deadlines |
| financial_analysis | financial_analysis | Spend exposure, repricing |
| system_membership | system_membership | Health system affiliation |
| compliance_query | compliance_query | Regulatory compliance |
| clause_text | clause_text | Verbatim clause language |
| provenance | provenance | Extraction audit trail |

### 3.5 Pre-flight Guards (run() lines 1213-1282)

These fire **before any LLM or tool call** — zero cost, instant response:

| Guard | Pattern | Response | Impact |
| --- | --- | --- | --- |
| Empty input | `not question.strip()` | Canned example prompt | Prevents wasted LLM calls |
| Temporal real-time | "yesterday", "today", "just now" | Static extract explanation | Prevents hallucinated "most recent" pivots |
| Contract value | "total dollar value", "how much is the contract" | Explanation + rate offer | Prevents fabricated totals |
| Contact info | "phone number", "email address", "contact" | PII unavailability note | Prevents PII hallucination |

### 3.6 Direct Dispatch Path (`_run_direct_dispatch`, line 6570)

This is the **fast path** — single tool call without ReAct loop:

1. Get `tool_name` from RoutingDecision
2. Resolve provider: API hint > router extraction > context entities > scope fallback
3. Guard checks: vague provider, clause content, contract-language
4. Build `tool_input` dict
5. Call `tool._run(**tool_input)`
6. If tool succeeds → `_build_response()` → return AgentResponse
7. If tool fails OR guard fires → return None (fall through to ReAct)

**Provider resolution cascade** (lines 6644-6779):
1. `request.provider_hint` (API-level, from frontend selection) — HIGHEST priority
2. Router-extracted providers (LLM classification)
3. RC-2 token matching (hint token matches router providers)
4. RC-3A portfolio clearing (network-wide → clear all providers)
5. RC-3B hallucination clearing (no token in question text)
6. Scope fallback (`provider_hint` when router found nothing)
7. W9-22 context fallback (resolved entities from prior turns)

**Answer validation** (post-dispatch, before return):
- `AnswerValidator._validate_answer()` checks for ungrounded claims
- If validation fails → inject correction seeds into ReAct loop (`_validator_corrections`)
- Falls through to ReAct with corrections as initial evidence

### 3.7 Decomposition Path (`_maybe_decompose`, line 8187)

| Attribute | Detail |
| --- | --- |
| Entry | `self._decomposer.analyze(question)` |
| Heuristic check | Conjunction, conditional, calculation patterns + keyword scoring |
| LLM decomposition | Only for genuinely complex questions (multiple independent info needs) |
| Result | `DecompositionPlan(is_simple, sub_questions, execution_groups, complexity)` |
| MT bypass | Multi-turn coreference compare with prior rate context → force `is_simple=True` |

**Decomposed execution** (`_run_decomposed`, line 8195):
1. Iterate execution groups (dependency-ordered)
2. Each sub-question gets `sub_max_steps = max(3, max_steps // 2)` = 5 steps
3. Run mini ReAct loop per sub-question
4. Capture result summaries with data rows
5. Final synthesis via `_synthesize_sub_results()` (LLM call)
6. Return `_build_response()`

### 3.8 Full ReAct Loop (lines 1654-1867)

| Attribute | Detail |
| --- | --- |
| Max steps | 10 (default, from AGENT_MAX_STEPS) |
| Budget | $15 USD (AGENT_DEFAULT_BUDGET_USD) |
| Step timeout | 120s per step |
| Total timeout | 600s (AGENT_TOTAL_TIMEOUT_S) |
| LLM model | `databricks-claude-sonnet-4-6` |
| Max tokens | 6000 (AGENT_REASONING_MAX_TOKENS) |

**Per-step flow** (`_react_step`, line 1868):
1. Inject provider scope into question text (ALWAYS when hint set)
2. Call `_call_reasoning_llm()` with system prompt + tool catalogue + prior steps + evidence
3. Parse LLM JSON → `(action, tool_name, tool_input, thought)`
4. If `CALL_TOOL`:
   - P4 provider pre-flight validation
   - Guard 3: block provider_deep_dive for clause-content questions
   - Delegation function redirect (→ sql_query)
   - Execute tool via `registry.get(tool_name)._run(**tool_input)`
5. If `SYNTHESIZE`: validate answer → break loop
6. If `THINK`: reasoning-only step (no tool call)
7. If `ABORT`: stop with refusal
8. PERF-1 guard: after 5 successful tool calls → cap steps to force synthesis next

### 3.9 SQL Generation & Validation (sql_query.py)

| Step | Detail |
| --- | --- |
| Schema context | `SchemaContextBuilder` provides table whitelist with column descriptions |
| LLM prompt | Schema + question + provider scope prefix → SQL |
| Post-processing | Period stripping in LIKE, DOFR is_current removal, superseded_by rewrite |
| Provider enforcement | If provider_name specified but SQL lacks filter → inject WHERE clause |
| Validation | Whitelist check (13 tables only), DDL/DML keyword block |
| Execution | `spark.sql(sql).toPandas()` → list[dict] rows |
| Row limit | 1000 max (SQL_MAX_ROWS), 100 default |
| Timeout | 300s (SQL_QUERY_TIMEOUT_S) |

**Security model**: Only tables in `CONTRACT_TABLES_FOR_SQL` whitelist can appear in generated SQL. DDL (CREATE, DROP, ALTER) and DML (INSERT, UPDATE, DELETE) keywords are blocked pre-execution.

### 3.10 Rate Query Tool (rate_query.py)

**12 query types** (classified via heuristic + LLM):

| Type | Method | Description |
| --- | --- | --- |
| SINGLE_PROVIDER | `_query_provider_rates` | Rate schedule for one provider |
| AMENDMENT_COMPARISON | `_query_amendment_comparison` | Rate changes across amendments |
| BENCHMARK | `_query_benchmark` | Provider vs network comparison |
| AGGREGATION | `_query_aggregation` | Network-wide rate statistics |
| LOB_PORTFOLIO | `_query_lob_portfolio` | LOB analytics (commercial %) |
| CAPITATION | `_query_capitation` | Capitation/PMPM-specific |
| STOP_LOSS | `_query_stop_loss` | Stop-loss provisions |
| CARVE_OUT | `_query_carve_outs` | Carve-out provisions |
| DISTRIBUTION | `_query_distribution` | Rate distribution analytics |
| TOP_N | `_query_top_n` | Top N providers by rate |
| THRESHOLD | `_query_threshold` | Providers above/below threshold |
| MULTI_TYPE | `_query_stop_loss` (sub) | Multi-type stop-loss |

Each type uses **hardcoded SQL templates** (not LLM-generated) with parameterized provider names. This is the most trustworthy path — SQL is deterministic and pre-validated.

### 3.11 Vector Search Retrieval (passage_search)

| Attribute | Detail |
| --- | --- |
| Endpoint | `contract_intelligence_vs_endpoint` |
| Index | `dev_adb.raw.idx_unified_v4` (727K chunks) |
| Top-K | 20 (PASSAGE_SEARCH_TOP_K) |
| Provider filter | Applied at VS query level (metadata filter) |
| is_current filter | Applied via CurrentEffectiveFilter |
| Result | Chunk text + score + metadata (filename, page, section) |

### 3.12 Response Assembly & Trust Layer

**Hallucination Guard** (5 checks, zero LLM cost):
1. Numeric consistency — numbers in answer must appear in cited sources
2. Provider identity — named providers must be in resolved context
3. Date plausibility — years within reasonable range
4. Ungrounded assertion detection — high-specificity sentences without citations
5. Confidence floor — empty/UNVERIFIED citations → cap at MODERATE

**Confidence assignment** (`_build_response`, line 6344):
- Base: minimum confidence across all successful tool results
- P5-CONF upgrade: if primary evidence tool returned HIGH → boost overall
- SQL bypass: SQL-grounded answers skip guard blocks (structurally grounded)
- Final: HIGH (0.90) | MODERATE (0.65) | LOW (0.35) | UNCERTAIN (0.15)

**Citation handling**:
- Collect from all tool results
- Filter to requested provider (bidirectional match)
- Deduplicate by (source_filename, page_number)
- Enrich with provenance metadata

### 3.13 Streaming & Persistence

**Streaming path** (`stream_ask` → `_stream_generator`):
1. `stream_ask()` calls `ask()` synchronously (collects full response)
2. Yields SSE events: thinking → tool_start/tool_result (per step) → answer_chunk (200-char) → citations → confidence → done
3. `_stream_generator()` wraps in ThreadPoolExecutor, yields NDJSON lines
4. Post-yield: fire-and-forget `_persist_turn()` → Delta write

**NOTE**: Streaming is "fake" — the full response is computed before any tokens stream. The system does NOT do token-level LLM streaming. This is documented as a "Phase 4 upgrade path" but not yet implemented.

**Persistence**:
1. Immediate: sync buffer append (in-memory, for next-turn visibility)
2. Async: `SessionRepo.save()` → INSERT to `tbl_agent_sessions` via WarehouseSpark
3. Telemetry: `TelemetryWriter` → `app_query_telemetry` table (separate path)

---

## 4. Path Comparison Matrix

### 4.1 Dispatch Paths (how similar questions route differently)

| Path | Trigger | LLM Calls | Tool Calls | Typical Latency | User Visibility |
| --- | --- | --- | --- | --- | --- |
| **Pre-flight guard** | Regex match (temporal/value/contact) | 0 | 0 | <100ms | Canned message, no citations |
| **Short-circuit** | Regex match (stop-loss, LOB, amendment) | 0 | 1 (rate_query) | 3-8s | Rate data with HIGH confidence |
| **Direct dispatch** | Router → tool_name + providers resolved | 1 (router) | 1 | 5-30s | Single-tool answer, HIGH/MODERATE |
| **ReAct loop** | Direct dispatch returns None | 1 (router) + 1-10 (reasoning) | 1-5 | 15-120s | Multi-step answer, variable confidence |
| **Decomposed** | Decomposer returns is_simple=False | 1 (router) + 1 (decompose) + N (sub-Qs) | 2-8 | 30-180s | Synthesized answer, variable |

### 4.2 Question Type → Path Mapping

| Question Pattern | Primary Path | Tool | Example |
| --- | --- | --- | --- |
| "Does X have offset/DOFR/IPA?" | Direct → sql_query | sql_query (profile table) | "Does Adventist have a DOFR clause?" |
| "What are the rates for X?" | Direct → rate_query | rate_query (SINGLE_PROVIDER) | "Show rates for Sharp Chula Vista" |
| "Compare X vs Y" | Direct → comparison | comparison | "Compare Sharp vs Scripps rates" |
| "Which providers have X clause?" | Direct → clause_existence | clause_existence (5-module) | "Which providers have arbitration?" |
| "How many providers are active?" | Direct → sql_query | sql_query | "How many commercial providers?" |
| "What does contract say about X?" | Guard 3 → ReAct → passage_search | passage_search | "What does it say about indemnification?" |
| "Show me the DOFR matrix" | Guard 2 → ReAct → passage_search | passage_search | "Show DOFR matrix for Allied Pacific" |
| "Which delegated functions?" | Delegation redirect → sql_query | sql_query (delegation_matrix) | "What IPA functions are delegated?" |
| "Expiring soon" / "alerts" | Direct → risk_alert | risk_alert | "Active alerts?" |
| "Stop-loss + threshold" | Short-circuit → rate_query | rate_query (stop_loss branch) | "Does X have stop-loss and threshold?" |
| "Total contract value" | Pre-flight guard | (none) | "What is the dollar value?" |
| "Contact information" | Pre-flight guard | (none) | "Phone number for X?" |
| "Yesterday's rates" | Pre-flight guard | (none) | "What changed yesterday?" |

### 4.3 Where Similar Questions Route Differently

| Question A | Route A | Question B (similar) | Route B | Why Different |
| --- | --- | --- | --- | --- |
| "Does X have DOFR?" | sql_query (profile HAS/NO) | "Show me X's DOFR matrix" | ReAct → passage_search | Content vs. existence |
| "What are X's rates?" | rate_query | "What are X's reimbursement terms?" | ReAct (passage_search) | "terms" triggers explanation route |
| "Compare X and Y" | comparison tool | "X and Y both have..." | multi_concept | "both" + concept = multi_concept |
| "Amendment history for X" | temporal_analysis | "Most recent amendment for X" | sql_query (short-circuit) | Recency vs. history |
| "Active alerts" | risk_alert | "Expired contracts" | sql_query | Alerts vs. status query |
| "Stop-loss threshold" | rate_query (short-circuit) | "Does X have stop-loss?" | rate_query (via router) | Compound bypass vs. simple |

---

## 5. Model Serving & LLM Invocations

| Purpose | Model Endpoint | Caller | Max Tokens | Cost Estimate |
| --- | --- | --- | --- | --- |
| Agent reasoning (ReAct) | `databricks-claude-sonnet-4-6` | `_call_reasoning_llm()` | 6000 | $0.005/step |
| Question routing | `databricks-claude-sonnet-4-6` | `QuestionRouter._llm_route()` | 600 | $0.003/call |
| SQL generation | `databricks-claude-sonnet-4-6` | `SqlQueryTool._generate_sql()` | 800 | $0.003/call |
| Question decomposition | `databricks-claude-sonnet-4-6` | `QuestionDecomposer` | varies | $0.005/call |
| Citation verification | `databricks-claude-haiku-4-5` | `CitationVerifyTool` | varies | $0.020/call |
| Coreference / entity extraction | `databricks-claude-haiku-4-5` | various fast tasks | varies | varies |
| Clause classification | `databricks-claude-sonnet-4-6` | `clause_existence` sub-pkg | varies | $5.50/call |
| Sub-question synthesis | `databricks-claude-sonnet-4-6` | `_synthesize_sub_results()` | varies | $0.005/call |

**Key observation**: The system uses a SINGLE model (`databricks-claude-sonnet-4-6`) for almost everything. The fast model (`databricks-claude-haiku-4-5`) is only used for citation verification and lightweight extraction tasks.

---

## 6. Stage Failure Points & User-Visible Impact

| Stage | Failure Mode | Detection | User-Visible Impact | Fallback |
| --- | --- | --- | --- | --- |
| Frontend → API | Network timeout | fetch error | Error toast in UI | Retry button |
| Runtime not ready | 503 response | status check | "AI warming up" message + ETA | Polls /health |
| Session load | Delta query failure | try/except | Silent — proceeds without history | No multi-turn context |
| QuestionRouter | LLM timeout/error | try/except | Silent — heuristic fallback used | Heuristic routing |
| Provider resolution | No match found | _validate_provider_exists | "Not found" + suggestions | Suggestions list |
| Direct dispatch fail | Tool returns error | check .success | Falls through to ReAct | Full reasoning loop |
| SQL generation | LLM returns no SQL | check None | Falls through to best_effort | Other tools in ReAct |
| SQL execution | Spark error | try/except | Tool returns failure result | ReAct tries next tool |
| VS retrieval | VS endpoint down | circuit breaker | Low confidence / no passages | SQL-only answers |
| LLM reasoning | Timeout/error | try/except | ABORT action returned | Best-effort synthesis |
| Answer validation | Ungrounded claims | _validate_answer | Falls back to ReAct with corrections | Retry with seeds |
| Hallucination guard | BLOCK finding | guard_result.has_blocks | Confidence downgraded | SQL bypass exception |
| Session persist | Delta write failure | try/except | Silent — logged, non-blocking | Multi-turn may lose turn |
| Stream emit | Callback error | try/except | Silent — logged, non-blocking | Response still returned |

### 6.1 Hidden Fallbacks (NOT visible to users)

| Fallback | Trigger | User Perception | Quality Risk |
| --- | --- | --- | --- |
| Heuristic routing | LLM router failure | Answer still works | May route to wrong tool |
| Profile facts injection failure | SQL error | Answer lacks ground truth | Higher hallucination risk |
| Provider hint override | Router hallucinated wrong provider | Correct provider used | None (fix) |
| RC-3B provider clearing | Router hallucinated provider | Network-wide scan runs | May miss provider-specific data |
| MT context loss | Session load failure | Answer ignores prior turns | User must re-state context |
| PERF-1 forced synthesis | 5+ tool calls | Answer may be incomplete | Truncated evidence |
| Best-effort synthesis | All ReAct steps exhausted | Concatenated tool summaries | Poor formatting, low confidence |
| Confidence SQL bypass | Guard blocks on SQL answer | HIGH confidence maintained | May pass hallucinated SQL answers |

---

## 7. Configuration Summary

| Parameter | Value | Source | Impact |
| --- | --- | --- | --- |
| AGENT_MAX_STEPS | 10 | settings.py:78 | Max reasoning iterations |
| AGENT_DEFAULT_BUDGET_USD | $15.00 | settings.py:79 | Cost cap per query |
| AGENT_STEP_TIMEOUT_S | 120s | settings.py:80 | Per-step timeout |
| AGENT_TOTAL_TIMEOUT_S | 600s | settings.py:81 | Total query timeout |
| AGENT_REASONING_MAX_TOKENS | 6000 | settings.py:82 | LLM output limit |
| SQL_MAX_ROWS | 1000 | settings.py:85 | Query result cap |
| SQL_QUERY_TIMEOUT_S | 300s | settings.py:86 | SQL execution timeout |
| PASSAGE_SEARCH_TOP_K | 20 | settings.py:88 | VS retrieval depth |
| LLM_REASONING | databricks-claude-sonnet-4-6 | settings.py:16 | Primary model |
| LLM_FAST | databricks-claude-haiku-4-5 | settings.py:17 | Fast model |
| GENIE_ENABLED | True | settings.py:118 | Genie Space integration |
| V4_MULTI_TURN_ENABLED | True | settings.py:114 | Multi-turn context |
| V4_TRUST_LAYER_ENABLED | True | settings.py:116 | Hallucination guard |
| CATALOG / SCHEMA | dev_adb / raw | settings.py:10-11 | Data location |

---

## 8. Documentation vs. Reality Differences

| Document Says | Reality | Risk |
| --- | --- | --- |
| Architecture doc: "V2 notebook_stream_handler for streaming" | Dead code — streaming is in main.py + stream_ask() | LOW — doc stale |
| Architecture doc: "amendment_chain tool" as live | NOT registered in _build_registry() (D-1) | LOW — doc misleading |
| Docstring: "V3 ReAct orchestrator" | Actually V4 (naming confusion) | LOW — internal |
| Settings: AGENT_TOTAL_TIMEOUT_S = 600 | Comment says "NO-TIMEOUT-OUR-SIDE" | MEDIUM — misleading name |
| stream_ask docstring: "token-level" | Fake streaming (full response first, then chunked) | MEDIUM — user expectation |
| Settings: V4_QUERY_CACHE_ENABLED = True | QueryCacheRepo never wired (D-8) | LOW — flag is meaningless |
| Architecture: "5-layer stack" | Only 3 layers active in deployed path | LOW — doc aspirational |

---

## 9. Updated Issue Ledger

| ID | Severity | Category | Status | Title | Evidence |
| --- | --- | --- | --- | --- | --- |
| F-001 | LOW | LIVENESS | CONFIRMED | amendment_chain.py tool not registered | _build_registry() has 25 tools, no AmendmentChainTool |
| F-002 | LOW | LIVENESS | CONFIRMED | 6 dead runtime files | api_entry.py, async_bridge.py, notebook_stream_handler.py, notebook_compat_adapter.py, tier_service.py, planning.py |
| F-003 | LOW | CONSISTENCY | CONFIRMED | Architecture doc lists amendment_chain as live tool | docs/ vs. registry mismatch |
| F-004 | LOW | CORRECTNESS | HYPOTHESIS | logger used before definition at main.py:45 | Pre-warm block references logger before logging.getLogger call |
| F-005 | MEDIUM | LIVENESS | CONFIRMED | QueryCacheRepo not wired | V4_QUERY_CACHE_ENABLED=True but no runtime connection |
| F-006a | HIGH | MAINTAINABILITY | CONFIRMED | agent_controller.py: 5,800 lines dead shadowed code (3 duplicated bodies) | Method defs at lines 2738/4815/6570, 4049/5797/8187 etc. — Python uses last def only |
| F-007 | LOW | LIVENESS | CONFIRMED | LegacyBranchAdapter always inert (is_ready=False) | dispatch_fn=None in notebook_entry.py |
| F-008 | MEDIUM | CONSISTENCY | CONFIRMED | Fake streaming — full response computed before any SSE yield | stream_ask() calls ask() synchronously, then yields chunked |
| F-009 | LOW | CORRECTNESS | HYPOTHESIS | Debug print statement in production code | agent_controller.py:888 — `print(f"[VPE-DEBUG]...")` |
| F-010 | LOW | CONSISTENCY | CONFIRMED | V4_QUERY_CACHE_ENABLED flag has no effect | Flag checked nowhere in active runtime path |
| F-011 | MEDIUM | CORRECTNESS | HYPOTHESIS | Confidence SQL bypass may pass hallucinated SQL answers | _all_evidence_from_sql bypasses guard.has_blocks — if SQL returns wrong data, guard can't catch it |
| F-012 | LOW | CORRECTNESS | HYPOTHESIS | Quote stripping applied twice in run() | Lines 1156-1174 AND 1182-1199 both strip quotes — second may re-strip if first fails |

---

## 10. Severity Assessment: F-006a Upgrade Rationale

Previously F-006 was MEDIUM ("suspected duplicated controller bodies"). Now CONFIRMED as HIGH:

1. **8,465 lines** in a single file where **only 2,665 are active** (31%)
2. Three complete copies means a developer editing `_run_direct_dispatch` at line 2738 would see NO EFFECT — the active version is at line 6570
3. The dead versions contain older logic (e.g., version 1 is ~1,310 lines vs. active version 1,616 lines) — they have diverged
4. Grep for bugs or features hits 3x results, causing confusion
5. Code review tools show false positives on the dead code
6. NOT a correctness issue (Python resolves correctly) but HIGH maintainability risk for the evaluation team

---

## 11. Key Architectural Observations

1. **ReAct system prompt is ~600 lines** (lines 123-746) — contains extensive hardcoded business rules, known data model quirks, and provider-specific examples. This is fragile: adding a new table or changing schema requires prompt surgery.

2. **Provider resolution has 7 levels of fallback** — designed to prevent hallucination but creates complex debugging surface when wrong provider is selected.

3. **Tool dispatch is deterministic for critical paths** — rate_query uses hardcoded SQL templates, not LLM-generated SQL. This is the safest path in the system.

4. **Hallucination guard is permissive by design** — flags but rarely blocks. SQL-derived answers bypass the guard entirely (P5-CONF + _all_evidence_from_sql). This is intentional but means SQL injection of wrong data would go undetected.

5. **No true streaming** — the "streaming" implementation computes the full answer first, then chunks it into 200-char segments. User sees progressive reveal but total latency is identical to non-streaming.

6. **Cost controller is advisory, not enforcing** — `budget_usd` is tracked but there's no evidence of hard cutoff mid-execution when budget is exceeded (only checked between steps).

---

*End of Report 3*