# Contract Intelligence V4 — Consolidated Findings Register

**Report**: 10 of N  
**Date**: 2026-07-26  
**Author**: Genie Code (automated audit assistant)  
**Status**: COMPLETE  
**Scope**: Deduplicated, actionable findings from Reports 1–9

---

## Methodology

**Included**: Issues affecting answer correctness, SQL/temporal/provider/rate/clause logic, evidence/citations/confidence, user understanding, UI reliability, evaluation capability, useful observability, dead-code confusion.

**Excluded**: Unverified hypotheses (F-004 logger ordering), production-only hardening not affecting controlled evaluation, generic best-practice advice, duplicate entries consolidated into single issues.

**Consolidations performed**:
- F-001 + F-003 → C-01 (amendment_chain dead tool + doc drift)
- F-005 + F-010 → C-03 (query cache entirely dead)
- F-014 + F-030 → C-08 (delegation is_current data loss)
- F-019 + F-029 → absorbed into C-16 (synthetic benchmarks note)
- F-020 + F-021 + F-022 + F-032 → C-16 (whitelist duplicates)
- F-002 + F-007 → Dead-code table (not individual findings)
- F-009 + F-033 → C-17 (debug prints)

**Result**: 65 original findings → **42 consolidated actionable issues**.

---

## Master Register

### CRITICAL (2 issues)

---

#### C-01: DOFR is_current Three-Way Contradiction Causes Wrong Answers

| Field | Value |
| --- | --- |
| **Original IDs** | F-013 |
| **Category** | SQL / Temporal correctness |
| **Severity** | CRITICAL |
| **Confidence** | Confirmed |
| **Description** | Three competing instructions for `tbl_dofr_matrix_extracted.is_current`: (1) whitelist says "filter by is_current=TRUE"; (2) architecture doc says "never filter"; (3) only 60/1,821 rows have is_current=TRUE, with 0 rows for Behavioral Health, Pharmacy, and Emergency. Any query that filters is_current=TRUE on DOFR silently drops entire service categories. |
| **Evidence** | `SELECT service_category, COUNT(*) FROM tbl_dofr_matrix_extracted WHERE is_current=TRUE GROUP BY 1` returns 0 for BH/Pharmacy/Emergency. Whitelist description in `table_whitelist.py` says "is_current=TRUE for latest." |
| **File/Line** | `platform/v4/config/table_whitelist.py` (DOFR entry description); `platform/v4/tools/sql_query.py` system prompt |
| **Active path** | sql_query (LLM-generated) → WHERE is_current=TRUE → 0 rows for 3 service categories |
| **Classification** | Defect: contradictory instructions + data model gap |
| **Likelihood** | HIGH — any DOFR question routed through sql_query (not rate_query) can trigger |
| **Impact** | **User**: gets "no data found" for valid DOFR questions. **Model**: LLM follows whitelist instruction, produces wrong SQL. **Trust**: answer appears confident but is empty. **Trial**: evaluators will mark FAIL on DOFR tasks. |
| **Fix** | Remove is_current filtering instruction from DOFR whitelist entry. Add "NEVER filter is_current on tbl_dofr_matrix_extracted" to system prompt rules. |
| **Files to change** | `table_whitelist.py` (1 line), `sql_query.py` system prompt (1 rule) |
| **Complexity** | Low (2 string edits) |
| **Regression risk** | None — removing a filter cannot break queries that don't use it |
| **Validation** | Run B-022 through B-025 (DOFR benchmarks); verify all service categories return rows |
| **Phase** | Phase 1 (immediate, pre-evaluation) |

---

#### C-02: System Prompt Rule 7 References Phantom Column `is_current_effective`

| Field | Value |
| --- | --- |
| **Original IDs** | F-023 |
| **Category** | SQL / Schema correctness |
| **Severity** | CRITICAL |
| **Confidence** | Confirmed |
| **Description** | System prompt Rule 7 in sql_query.py instructs the LLM: "Use `is_current_effective = true` to filter for current records." This column does not exist in any table. When the LLM follows this instruction, queries fail with UNRESOLVED_COLUMN or return unexpected results if silently ignored. |
| **Evidence** | `DESCRIBE dev_adb.raw.tbl_contract_rates_all` — no column named is_current_effective. Schema confirmed 2026-07-26. The correct filter is `status = 'current'`. |
| **File/Line** | `platform/v4/tools/sql_query.py`, system prompt string, Rule 7 |
| **Active path** | sql_query tool → system prompt → LLM generates SQL with phantom column → execution error or silent wrong results |
| **Classification** | Defect: phantom column reference in active prompt |
| **Likelihood** | HIGH — any rate query routed through sql_query (not rate_query templates) triggers |
| **Impact** | **User**: query error or missing data. **Model**: LLM follows wrong instruction. **Trust**: error response destroys confidence. **Trial**: blocks any sql_query-routed rate question. |
| **Fix** | Replace Rule 7 text with: "Use `status = 'current'` to filter for current rates in tbl_contract_rates_all." |
| **Files to change** | `sql_query.py` (1 line in system prompt) |
| **Complexity** | Trivial (string replacement) |
| **Regression risk** | Low — correct column already used by rate_query templates |
| **Validation** | Run B-001–B-012; verify no UNRESOLVED_COLUMN errors; verify status='current' appears in generated SQL |
| **Phase** | Phase 1 (immediate, pre-evaluation) |

---

### HIGH (12 issues)

---

#### C-03: agent_controller.py Contains 5,800 Lines of Dead Shadowed Code

| Field | Value |
| --- | --- |
| **Original IDs** | F-006a |
| **Category** | Dead code / Maintainability |
| **Severity** | HIGH |
| **Confidence** | Confirmed |
| **Description** | Single `AgentController` class (8,465 lines) has 10 methods defined 3 times each. Python uses LAST definition only. ~5,800 lines (69%) are dead but visually indistinguishable from active code. Developers cannot safely modify behavior without understanding which copy is live. |
| **Evidence** | `_run_direct_dispatch` defined at lines 2738, 4815, **6570** (active). `_build_response` at 2512, 4589, **6344** (active). Confirmed via Python class semantics (last definition wins). |
| **File/Line** | `platform/v4/core/agent_controller.py`, lines 746–8465 |
| **Active path** | Every request passes through AgentController.run() → active methods are lines 6000–8465 |
| **Classification** | Defect: unmaintainable, blocks safe modification |
| **Likelihood** | 100% present; developer confusion certain during any modification |
| **Impact** | **Development**: editing wrong copy silently changes nothing. **Evaluation**: cannot reliably assess which logic is active. **Risk**: accidental edit to dead copy gives false sense of fix. |
| **Fix** | Delete lines 746–5999 (dead copies), retain lines 6000–8465 (active). Verify via unit tests. |
| **Files to change** | `agent_controller.py` (delete ~5,200 lines) |
| **Complexity** | Medium (large diff, but purely subtractive) |
| **Regression risk** | Low if tests pass — dead code by definition cannot affect runtime |
| **Validation** | Full test suite passes identically before and after deletion |
| **Phase** | Phase 2 (before first major code change) |

---

#### C-04: No Canonical Join Enforcement — 28% Data Loss on rates→profile

| Field | Value |
| --- | --- |
| **Original IDs** | F-025 |
| **Category** | SQL / Join correctness |
| **Severity** | HIGH |
| **Confidence** | Confirmed |
| **Description** | No mechanism prevents the LLM from using `provider_id` (instead of `canonical_provider_id`) when joining `tbl_contract_rates_all` to `tbl_genie_provider_profile`. The wrong join produces 128,896 orphan rows (28% of rates), silently dropping data from answers. |
| **Evidence** | `SELECT COUNT(*) FROM tbl_contract_rates_all r LEFT JOIN tbl_genie_provider_profile p ON r.provider_id = p.provider_id WHERE p.provider_id IS NULL` = 128,896. Same query on `canonical_provider_id` = 0 orphans. |
| **File/Line** | `platform/v4/tools/sql_query.py` (no join validation in `_validate_sql`) |
| **Active path** | sql_query tool → LLM generates JOIN ON provider_id → 28% data missing → wrong counts/rates |
| **Classification** | Weakness: no structural guard against known-harmful join |
| **Likelihood** | MEDIUM — LLM sometimes uses correct key, but whitelist doesn't enforce |
| **Impact** | **User**: undercounted rates, missing providers. **Model**: silently wrong numbers. **Trust**: answer looks complete but isn't. |
| **Fix** | Add post-generation SQL AST check: if rates→profile join uses provider_id, rewrite to canonical_provider_id OR reject+retry. |
| **Files to change** | `sql_query.py` (`_validate_sql` method) |
| **Complexity** | Medium (SQL AST parsing + rewrite logic) |
| **Regression risk** | Low — correct key already works |
| **Validation** | B-001–B-012 pass; generate 20 rate questions, verify all use canonical_provider_id |
| **Phase** | Phase 1 (pre-evaluation) |

---

#### C-05: Amendment Comparison Uses STRING Sort (Wrong Order)

| Field | Value |
| --- | --- |
| **Original IDs** | F-026 |
| **Category** | SQL / Temporal correctness |
| **Severity** | HIGH |
| **Confidence** | Confirmed |
| **Description** | Amendment comparison template in `rate_query.py` uses `amendment_order` (STRING type) for ordering. String sort: "10" < "2" < "9". The correct column is `amendment_order_int` (INTEGER). Any comparison across amendments with order ≥10 returns wrong "previous" amendment. |
| **Evidence** | Schema: `amendment_order STRING`, `amendment_order_int INTEGER`. Template at rate_query.py amendment_comparison type uses ORDER BY amendment_order. |
| **File/Line** | `platform/v4/tools/rate_query.py`, amendment_comparison query template |
| **Active path** | rate_query tool (AMENDMENT_COMPARISON type) → ORDER BY amendment_order → wrong ordering |
| **Classification** | Defect: wrong column type for ordering |
| **Likelihood** | HIGH — any provider with ≥10 amendments triggers |
| **Impact** | **User**: sees wrong "previous" rate. **Correctness**: directly wrong answer. **Trial**: B-014, B-016, B-031 will FAIL. |
| **Fix** | Replace `amendment_order` with `amendment_order_int` in ORDER BY clause of amendment_comparison template. |
| **Files to change** | `rate_query.py` (1 ORDER BY clause) |
| **Complexity** | Trivial |
| **Regression risk** | None — integer ordering is strictly correct |
| **Validation** | B-014 (amendment comparison); verify ordering with provider having 10+ amendments |
| **Phase** | Phase 1 (immediate) |

---

#### C-06: Benchmark Template COUNT(*) Aliased as n_providers (Misleading)

| Field | Value |
| --- | --- |
| **Original IDs** | F-024 |
| **Category** | SQL / Aggregation correctness |
| **Severity** | HIGH |
| **Confidence** | Confirmed |
| **Description** | Rate benchmark template uses `COUNT(*)` aliased as `n_providers`. Since rates table has multiple rows per provider, COUNT(*) returns rate-line count, not provider count. LLM may report this as "number of providers" in answers. |
| **Evidence** | Template in `rate_query_templates.py` benchmark query: `COUNT(*) AS n_providers`. Should be `COUNT(DISTINCT canonical_provider_id)`. |
| **File/Line** | `platform/v4/services/rate_query_templates.py`, benchmark template |
| **Active path** | rate_query (BENCHMARK type) → result includes n_providers → LLM cites it as provider count |
| **Classification** | Defect: wrong aggregation |
| **Likelihood** | HIGH — every benchmark query returns this |
| **Impact** | **User**: told "15 providers" when really 15 rate lines. **Correctness**: factually wrong number. |
| **Fix** | Change `COUNT(*)` to `COUNT(DISTINCT canonical_provider_id)` in benchmark template. |
| **Files to change** | `rate_query_templates.py` (1 line) |
| **Complexity** | Trivial |
| **Regression risk** | None |
| **Validation** | Run benchmark query; verify count matches unique providers |
| **Phase** | Phase 1 (immediate) |

---

#### C-07: SQL Confidence Bypass May Pass Hallucinated Answers

| Field | Value |
| --- | --- |
| **Original IDs** | F-011 |
| **Category** | Confidence / Correctness |
| **Severity** | HIGH |
| **Confidence** | Highly likely |
| **Description** | In `_build_response`, when `_all_evidence_from_sql()` returns True, the hallucination guard's `has_blocks` check is skipped. If the LLM synthesizes claims beyond what SQL returned (e.g., inventing percentages not in result set), these pass unchecked with HIGH confidence. |
| **Evidence** | `agent_controller.py` active `_build_response` (line ~6344): `if self._all_evidence_from_sql(steps): skip guard.has_blocks`. Guard checks are the only runtime defense against hallucination. |
| **File/Line** | `platform/v4/core/agent_controller.py`, `_build_response`, ~line 6400 |
| **Active path** | sql_query returns data → `_all_evidence_from_sql=True` → guard bypassed → unsupported claims get HIGH confidence |
| **Classification** | Weakness: defense bypass on common path |
| **Likelihood** | MEDIUM — requires LLM to add claims beyond SQL data (happens with synthesis) |
| **Impact** | **Trust**: HIGH confidence on ungrounded claims. **Trial**: evaluators mark confidence as "too high." |
| **Fix** | Run numeric-consistency check (guard check 1) even when SQL-grounded. Only skip the full guard when all answer numbers appear in result data. |
| **Files to change** | `agent_controller.py` (conditional in `_build_response`) |
| **Complexity** | Medium |
| **Regression risk** | Low — adds checks, doesn't remove |
| **Validation** | Run questions where LLM synthesizes "average" from individual rates; verify guard catches it |
| **Phase** | Phase 2 |

---

#### C-08: Delegation is_current Filter Drops 73% of IPA Providers

| Field | Value |
| --- | --- |
| **Original IDs** | F-014, F-030 |
| **Category** | SQL / Temporal correctness |
| **Severity** | HIGH |
| **Confidence** | Confirmed |
| **Description** | Whitelist instructs LLM to use `is_current=TRUE` on `tbl_delegation_matrix`, but only 32/120 providers have is_current=TRUE rows. Filtering drops 73% of delegated providers. |
| **Evidence** | `SELECT COUNT(DISTINCT provider_name) FROM tbl_delegation_matrix` = 120. With `WHERE is_current=TRUE` = 32. |
| **File/Line** | `platform/v4/config/table_whitelist.py` (delegation entry) |
| **Active path** | sql_query → WHERE is_current=TRUE → 88 providers invisible |
| **Classification** | Defect: whitelist instruction causes data loss |
| **Likelihood** | HIGH — any delegation question through sql_query triggers |
| **Impact** | **User**: "Provider X has no delegation" when it does. **Correctness**: false negative. |
| **Fix** | Remove is_current=TRUE instruction from delegation whitelist entry. Add note: "Use all rows; is_current coverage is incomplete." |
| **Files to change** | `table_whitelist.py` (1 entry) |
| **Complexity** | Trivial |
| **Regression risk** | None — showing more data is strictly more complete |
| **Validation** | B-026, B-027; verify delegation queries return all 120 providers |
| **Phase** | Phase 1 (immediate) |

---

#### C-09: No Measurable Confidence Components (Opaque Trust Signal)

| Field | Value |
| --- | --- |
| **Original IDs** | F-043 |
| **Category** | Confidence / Trust |
| **Severity** | HIGH |
| **Confidence** | Confirmed |
| **Description** | Confidence is a single string (HIGH/MODERATE/LOW/UNCERTAIN) derived from min(tool_confidences) with ad-hoc P5-CONF boost. No data-quality, query-quality, or evidence-quality components. Users cannot understand WHY a confidence level was assigned. |
| **Evidence** | `_build_response` in agent_controller.py: `confidence = min(step.confidence for step in steps if step.confidence)`. ConfidenceBadge in ChatPageV2.tsx shows badge only. |
| **File/Line** | `agent_controller.py` `_build_response`; `ChatPageV2.tsx` line 43–51 |
| **Active path** | Every answer → opaque confidence badge → user has no basis to judge trust |
| **Classification** | Design gap: stakeholder requirement unmet |
| **Likelihood** | 100% — every answer |
| **Impact** | **Trust**: users cannot distinguish data-grounded HIGH from lucky guess. **Trial**: confidence usefulness will score low on questionnaire. |
| **Fix** | Implement Report 7 component framework (C1–C7 scores). Surface in evidence panel. |
| **Files to change** | `agent_controller.py`, new `confidence_scorer.py`, frontend evidence component |
| **Complexity** | High (new subsystem) |
| **Regression risk** | Medium — new code path |
| **Validation** | Report 7 acceptance thresholds; ECE < 0.20 on benchmark suite |
| **Phase** | Phase 2–3 |

---

#### C-10: No Calibration Data (Confidence Never Validated Against Accuracy)

| Field | Value |
| --- | --- |
| **Original IDs** | F-044 |
| **Category** | Confidence / Statistical |
| **Severity** | HIGH |
| **Confidence** | Confirmed |
| **Description** | No historical comparison of displayed confidence vs. actual correctness. The system may be systematically overconfident or underconfident with no mechanism to detect or correct. |
| **Evidence** | No calibration table, no ECE computation, no reliability diagram anywhere in codebase. |
| **File/Line** | N/A (not implemented) |
| **Active path** | Every answer carries uncalibrated confidence |
| **Classification** | Design gap |
| **Likelihood** | 100% |
| **Impact** | **Trust**: misleading if confidence is uncalibrated. **Trial**: stakeholders require statistical defensibility. |
| **Fix** | Run 109-question benchmark, collect accuracy per confidence band, compute ECE/Brier, publish reliability diagram. |
| **Files to change** | New `evaluation/calibration.py`; benchmark runner |
| **Complexity** | Medium |
| **Regression risk** | None (additive) |
| **Validation** | ECE < 0.20; Brier < 0.25 |
| **Phase** | Phase 2 |

---

#### C-11: No Onboarding/Coverage Explanation for Users

| Field | Value |
| --- | --- |
| **Original IDs** | F-048 |
| **Category** | UX / User understanding |
| **Severity** | HIGH |
| **Confidence** | Confirmed |
| **Description** | Users land on empty chat with only "What would you like to know?" No explanation of purpose, supported topics, data coverage, or limitations. First-time users have no guidance. |
| **Evidence** | ChatPageV2.tsx lines 440–449: empty state shows icon + single sentence. No onboarding modal, no coverage guide, no examples. |
| **File/Line** | `frontend/src/pages/ChatPageV2.tsx`, lines 439–450 |
| **Active path** | Every first visit → no context → unsupported questions → frustration |
| **Classification** | Design gap |
| **Likelihood** | 100% for new users |
| **Impact** | **Trial**: evaluators won't know what to ask. **Trust**: unmet expectations erode confidence in tool. |
| **Fix** | Add onboarding modal (Report 8 §3.1) + example questions panel (§3.2). |
| **Files to change** | `ChatPageV2.tsx` (new component), optional new route `/welcome` |
| **Complexity** | Medium (frontend only) |
| **Regression risk** | None |
| **Validation** | Task completion rate ≥70% in user trial (Report 8 §9.1) |
| **Phase** | Phase 1 (before evaluation) |

---

#### C-12: Feedback Limited to Thumbs Up/Down (Cannot Diagnose Errors)

| Field | Value |
| --- | --- |
| **Original IDs** | F-049, F-055 |
| **Category** | Evaluation / Feedback |
| **Severity** | HIGH |
| **Confidence** | Confirmed |
| **Description** | Frontend sends only `rating: 'up'|'down'` despite API accepting `correction`, `note`, and `thumbs_up`. No structured error categories, no expected-answer field, no confidence assessment. Cannot analyze error patterns from feedback data. |
| **Evidence** | ChatPageV2.tsx line 87: `body: JSON.stringify({ session_id, query_id: \`msg-${messageIndex}\`, rating: value })`. API FeedbackRequest (main.py:1688) has `correction`, `note` fields unused by frontend. |
| **File/Line** | `frontend/src/pages/ChatPageV2.tsx` line 78–103 (FeedbackControls) |
| **Active path** | Every feedback interaction → binary only → no error pattern analysis possible |
| **Classification** | Design gap: evaluation requirement unmet |
| **Likelihood** | 100% |
| **Impact** | **Evaluation**: cannot compute error-category distribution, confidence calibration from user perspective, or correction corpus. |
| **Fix** | Replace FeedbackControls with structured feedback component (Report 8 §4). |
| **Files to change** | `ChatPageV2.tsx` (new StructuredFeedback component), `types/api.ts` (new type), `main.py` (extend schema) |
| **Complexity** | Medium |
| **Regression risk** | Low (backward-compatible API extension) |
| **Validation** | Structured feedback submitted for ≥80% of rated answers in trial |
| **Phase** | Phase 1 (before evaluation) |

---

#### C-13: No Evidence Panel (Users Cannot Assess Answer Basis)

| Field | Value |
| --- | --- |
| **Original IDs** | F-050 |
| **Category** | UX / Trust |
| **Severity** | HIGH |
| **Confidence** | Confirmed |
| **Description** | After an answer, users see a confidence badge and citations but no evidence summary: which tables were queried, how many rows matched, whether data is current or superseded, what method was used (direct lookup vs. inference), or what limitations apply. |
| **Evidence** | ChatPageV2.tsx answer rendering (lines 458–488): MarkdownContent + ConfidenceBadge + tool_names + CitationCards. No evidence summary component. |
| **File/Line** | `frontend/src/pages/ChatPageV2.tsx` lines 458–488 |
| **Active path** | Every answer → user must blindly trust badge |
| **Classification** | Design gap: stakeholder requirement unmet |
| **Likelihood** | 100% |
| **Impact** | **Trust**: experts cannot verify data basis. **Trial**: trust score will be low without evidence visibility. |
| **Fix** | Add evidence summary panel (Report 8 §3.3). Requires backend to return `evidence_summary` in query response. |
| **Files to change** | Frontend: new EvidencePanel component. Backend: extend query response schema in `main.py`, add evidence assembly in `agent_controller.py`. |
| **Complexity** | High (backend + frontend) |
| **Regression risk** | Low (additive) |
| **Validation** | Evaluators rate evidence usefulness ≥3.5/5 |
| **Phase** | Phase 2 |

---

#### C-14: No Client-Side Evaluation Analytics

| Field | Value |
| --- | --- |
| **Original IDs** | F-051 |
| **Category** | Evaluation / Observability |
| **Severity** | HIGH |
| **Confidence** | Confirmed |
| **Description** | No client-side event tracking for task success, citation engagement, time-on-task, or navigation patterns. Cannot measure evaluation metrics without manual observation. |
| **Evidence** | No analytics library in `frontend/src/`. No event-emission code in any page component. |
| **File/Line** | `frontend/src/` (absence) |
| **Active path** | Evaluation period → no data collection → cannot compute scorecards |
| **Classification** | Design gap |
| **Likelihood** | 100% |
| **Impact** | **Evaluation**: task completion rate, citation click rate, time-saved cannot be computed. |
| **Fix** | Add analytics event layer (Report 8 §8.1): 10 client events + backend `/api/v1/events` endpoint. |
| **Files to change** | New `frontend/src/services/analytics.ts`; instrument ChatPageV2, CitationCard; new endpoint in `main.py` |
| **Complexity** | Medium |
| **Regression risk** | None (additive, fire-and-forget) |
| **Validation** | Events appear in analytics table during pilot run |
| **Phase** | Phase 1 (before evaluation) |

---

### MEDIUM (16 issues)

---

#### C-15: Provider Filter Case Sensitivity Edge Cases

| Field | Value |
| --- | --- |
| **Original IDs** | F-028 |
| **Category** | SQL / Provider resolution |
| **Severity** | MEDIUM |
| **Confidence** | Confirmed |
| **Description** | Provider name matching in sql_query post-processing uses exact-case comparison. If LLM generates `WHERE provider_name = 'sharp healthcare'` but data has `'Sharp HealthCare'`, 0 rows returned. |
| **File/Line** | `platform/v4/tools/sql_query.py`, provider enforcement logic |
| **Fix** | Use LOWER() on both sides or ILIKE for provider_name comparisons. |
| **Complexity** | Low |
| **Phase** | Phase 1 |

---

#### C-16: Whitelist Has 3 Duplicate Entries (Last-Wins Dict Semantics)

| Field | Value |
| --- | --- |
| **Original IDs** | F-020, F-021, F-022, F-032 |
| **Category** | Configuration / Correctness |
| **Severity** | MEDIUM |
| **Confidence** | Confirmed |
| **Description** | `CONTRACT_TABLES_FOR_SQL` dict has duplicate keys: `tbl_provider_identifiers`, `tbl_rate_escalators`, `tbl_service_areas`. Python dict takes last value only. First definition's description is silently lost. |
| **File/Line** | `platform/v4/config/table_whitelist.py` |
| **Fix** | Remove duplicate entries, keeping the most complete description. |
| **Complexity** | Trivial |
| **Phase** | Phase 1 |

---

#### C-17: Debug Prints in Production Code

| Field | Value |
| --- | --- |
| **Original IDs** | F-009, F-033 |
| **Category** | Operations / Code quality |
| **Severity** | MEDIUM |
| **Confidence** | Confirmed |
| **Description** | `print()` statements at `agent_controller.py:888` and `rate_query.py:574-575` produce unstructured stdout output in production. |
| **File/Line** | `agent_controller.py:888`, `rate_query.py:574-575` |
| **Fix** | Replace with `logger.debug()` calls. |
| **Complexity** | Trivial |
| **Phase** | Phase 2 |

---

#### C-18: Clause/Provider Count Queries May Use COUNT(*) Instead of DISTINCT

| Field | Value |
| --- | --- |
| **Original IDs** | F-027 |
| **Category** | SQL / Aggregation |
| **Severity** | MEDIUM |
| **Confidence** | Confirmed |
| **Description** | LLM-generated SQL for "how many providers have X" can use COUNT(*) on `tbl_contract_clauses` (7,863 rows, 300 providers) instead of COUNT(DISTINCT provider_name). Overcounts by ~26x. |
| **File/Line** | `platform/v4/tools/sql_query.py` (no grain enforcement) |
| **Fix** | Add system prompt rule: "For provider counts from multi-row tables, always use COUNT(DISTINCT provider_name)." Add AST check. |
| **Complexity** | Low–Medium |
| **Phase** | Phase 1 |

---

#### C-19: No Hard-Failure Override Mechanism

| Field | Value |
| --- | --- |
| **Original IDs** | F-045 |
| **Category** | Confidence / Architecture |
| **Severity** | MEDIUM |
| **Confidence** | Confirmed |
| **Description** | No mechanism to force confidence to UNCERTAIN/UNABLE when a hard failure is detected (e.g., wrong join, phantom column, zero-rows-as-absence). Bad queries can still get HIGH confidence. |
| **File/Line** | `agent_controller.py` `_build_response` (no HF checks) |
| **Fix** | Implement Report 7 hard-failure rules (HF-01 through HF-10) as post-processing checks. |
| **Complexity** | Medium |
| **Phase** | Phase 2 |

---

#### C-20: Fake Streaming (Backend Buffers Then Sends)

| Field | Value |
| --- | --- |
| **Original IDs** | F-008 |
| **Category** | UX / Performance perception |
| **Severity** | MEDIUM |
| **Confidence** | Confirmed |
| **Description** | SSE streaming sends thinking/tool events progressively, but the final answer arrives as a single large chunk (not word-by-word). Users see spinner for full processing time, then complete answer appears at once. |
| **File/Line** | `app/main.py` streaming endpoint; `agent_controller.py` stream_ask() |
| **Fix** | Implement true token-by-token streaming from LLM synthesis step. |
| **Complexity** | High |
| **Phase** | Phase 3 (deferred) |

---

#### C-21: Offset Clause Count Mismatch (Profile 47 vs. Clauses Table 72)

| Field | Value |
| --- | --- |
| **Original IDs** | F-017 |
| **Category** | Data quality / Consistency |
| **Severity** | MEDIUM |
| **Confidence** | Confirmed |
| **Description** | Profile table shows 47 providers with offset_clause_status='HAS', but clauses table has 72 distinct providers with OFFSET_CLAUSE entries. 25 providers have clause records but profile doesn't reflect them. Conflicting answers depending on which table is queried. |
| **File/Line** | Data issue in `tbl_genie_provider_profile` vs `tbl_contract_clauses` |
| **Fix** | Data reconciliation pipeline; add data quality check to Layer 1 assertions. |
| **Complexity** | Medium (pipeline fix) |
| **Phase** | Phase 2 |

---

#### C-22: No Example Questions or Category Guide

| Field | Value |
| --- | --- |
| **Original IDs** | F-052 |
| **Category** | UX / Onboarding |
| **Severity** | MEDIUM |
| **Confidence** | Confirmed |
| **Description** | Empty chat state shows no categorized examples. Users must guess what questions work. |
| **File/Line** | `ChatPageV2.tsx` lines 439–450 |
| **Fix** | Add categorized example questions (Report 8 §3.2). |
| **Complexity** | Low |
| **Phase** | Phase 1 |

---

#### C-23: No Provider Name Autocomplete

| Field | Value |
| --- | --- |
| **Original IDs** | F-053 |
| **Category** | UX / Input assistance |
| **Severity** | MEDIUM |
| **Confidence** | Confirmed |
| **Description** | No typeahead or suggestion for provider names. Typos/variants produce 0 results with no guidance. |
| **File/Line** | `ChatPageV2.tsx` (absence); no `/api/v1/providers/suggest` endpoint |
| **Fix** | Add autocomplete endpoint + frontend typeahead component. |
| **Complexity** | Medium |
| **Phase** | Phase 2 |

---

#### C-24: Error/No-Result States Not Distinguished

| Field | Value |
| --- | --- |
| **Original IDs** | F-054 |
| **Category** | UX / Error handling |
| **Severity** | MEDIUM |
| **Confidence** | Confirmed |
| **Description** | API errors, 0-result queries, and unsupported questions all render as generic text. User cannot tell if they asked wrong, data is missing, or system failed. |
| **File/Line** | `ChatPageV2.tsx` line 434 (single error div) |
| **Fix** | Implement distinct states per Report 8 §3.4. |
| **Complexity** | Medium |
| **Phase** | Phase 2 |

---

#### C-25: No SQL Semantic Assertion Layer in Test Suite

| Field | Value |
| --- | --- |
| **Original IDs** | F-058 |
| **Category** | Testing / Evaluation |
| **Severity** | MEDIUM |
| **Confidence** | Confirmed |
| **Description** | Current test suite validates answers but never inspects generated SQL structure. Phantom columns, wrong joins, missing filters pass undetected until answer-level judgment (which is LLM-dependent and non-deterministic). |
| **File/Line** | `Contract_Intelligence_Comprehensive_Test_Suite` (absence) |
| **Fix** | Add Layer 2 SQL AST validation per Report 9 §1. |
| **Complexity** | Medium |
| **Phase** | Phase 2 |

---

#### C-26: No Stability/Repeatability Testing

| Field | Value |
| --- | --- |
| **Original IDs** | F-059, F-060 |
| **Category** | Testing / Evaluation |
| **Severity** | MEDIUM |
| **Confidence** | Confirmed |
| **Description** | Tests run once only. No repeat-run consistency or paraphrase-variant testing. Cannot detect non-deterministic failures or route instability. |
| **File/Line** | Test suite (absence) |
| **Fix** | Add Layer 4 stability testing per Report 9 §1. |
| **Complexity** | Medium |
| **Phase** | Phase 2 |

---

#### C-27: No Per-Question-Type Confidence Scoring

| Field | Value |
| --- | --- |
| **Original IDs** | F-046 |
| **Category** | Confidence / Design |
| **Severity** | MEDIUM |
| **Confidence** | Confirmed |
| **Description** | Same confidence rules apply to all question types. Rate lookups (deterministic SQL) should score differently than clause-text extraction (vector search + LLM synthesis). |
| **File/Line** | `agent_controller.py` `_build_response` |
| **Fix** | Implement question-type-specific scoring per Report 7 §6. |
| **Complexity** | Medium |
| **Phase** | Phase 3 |

---

#### C-28: fact_supersession Documentation Says provider_id ALL NULL (Actually Populated)

| Field | Value |
| --- | --- |
| **Original IDs** | F-015 |
| **Category** | Documentation drift |
| **Severity** | MEDIUM |
| **Confidence** | Confirmed |
| **Description** | Architecture doc and whitelist describe `fact_supersession.provider_id` as always NULL. Live data shows it's fully populated. May cause LLM to avoid using this column. |
| **File/Line** | `table_whitelist.py` (fact_supersession entry) |
| **Fix** | Update whitelist description to reflect actual data. |
| **Complexity** | Trivial |
| **Phase** | Phase 1 |

---

#### C-29: dim_table_schema Missing 2 Tables

| Field | Value |
| --- | --- |
| **Original IDs** | F-018 |
| **Category** | Schema / Completeness |
| **Severity** | MEDIUM |
| **Confidence** | Confirmed |
| **Description** | `dim_table_schema` (used by SchemaContextBuilder to inform LLM) is missing `tbl_reimb_stop_loss` and `tbl_reimb_carve_outs`. LLM cannot use these tables for stop-loss/carve-out questions. |
| **File/Line** | `dev_adb.raw.dim_table_schema` (data gap) |
| **Fix** | Add schema entries for the 2 missing tables. |
| **Complexity** | Low (INSERT 2 rows) |
| **Phase** | Phase 1 |

---

#### C-30: No Statistical Significance Testing for Version Comparisons

| Field | Value |
| --- | --- |
| **Original IDs** | F-061 |
| **Category** | Testing / Evaluation |
| **Severity** | MEDIUM |
| **Confidence** | Confirmed |
| **Description** | No McNemar's or similar test to determine if accuracy changes between versions are significant. Cannot distinguish real regression from noise. |
| **File/Line** | Test suite (absence) |
| **Fix** | Implement paired-sample comparison per Report 9 §5.3. |
| **Complexity** | Low |
| **Phase** | Phase 2 |

---

### LOW (12 issues)

---

| ID | Original | Title | Category | Description | Phase |
| --- | --- | --- | --- | --- | --- |
| C-31 | F-001, F-003 | amendment_chain.py not registered + doc says it is | Dead code / Doc drift | Tool file exists, registered in architecture doc, but `_build_registry()` doesn't include it. Causes developer confusion. | Phase 2 |
| C-32 | F-008 partial | Query cache entirely dead (flag + repo) | Dead code | `V4_QUERY_CACHE_ENABLED=True` but `QueryCacheRepo` never wired. Flag has no effect. | Phase 3 |
| C-33 | F-016 | Whitelist rate counts stale (135K/324K vs live 171K/288K) | Doc drift | Whitelist description for rates table shows old counts. LLM may cite stale stats. | Phase 2 |
| C-34 | F-031 | No fallback/retry for empty results outside DOFR | UX gap | Only DOFR has a fallback query when 0 rows returned. Other tables get silent empty answer. | Phase 3 |
| C-35 | F-047 | No stability/repeatability measurement | Evaluation gap | Per-question consistency never measured (covered by C-26 for testing). | Phase 2 |
| C-36 | F-056 | No long-answer collapse or TOC | UX | Long markdown answers cause scroll fatigue. No expand/collapse. | Phase 3 |
| C-37 | F-057 | No session search/filter | UX | Session sidebar has no search. Hard to find past conversations. | Phase 3 |
| C-38 | F-062 | Benchmark definitions embedded in notebook | Testing | Tests are inline cells, not externalized YAML. Hard to version, diff, or re-use. | Phase 2 |
| C-39 | F-063 | No automated regression dashboard | Testing | No trend tracking, no visual regression detection. | Phase 3 |
| C-40 | F-012 | Quote stripping may be applied twice | Code quality | Minor: answer cleanup strips quotes that may already be stripped. Cosmetic impact only. | Phase 3 |
| C-41 | F-019/F-029 | Synthetic benchmark table in whitelist without warning | Doc drift | `tbl_rate_benchmarks` is 100% synthetic. LLM may cite it as real contract data. | Phase 2 |
| C-42 | F-014 partial | No fallback/empty-result guidance for users | UX | When queries return 0 rows, no "try these alternatives" or explanation shown. | Phase 3 |

---

## Top 10 Blockers for Controlled Evaluation

| Rank | ID | Title | Why Blocking | Fix Effort |
| --- | --- | --- | --- | --- |
| 1 | C-02 | Phantom column `is_current_effective` | Any sql_query rate question may fail with schema error | 15 min |
| 2 | C-01 | DOFR is_current contradiction | DOFR tasks return empty for BH/Pharmacy/Emergency | 15 min |
| 3 | C-05 | Amendment STRING sort | Amendment comparisons give wrong "previous" | 15 min |
| 4 | C-06 | Benchmark COUNT(*) mislabeled | Provider count answers will be 26x too high | 15 min |
| 5 | C-08 | Delegation is_current drops 73% | Delegation questions miss most providers | 15 min |
| 6 | C-04 | No canonical join enforcement | 28% rate data loss on some sql_query runs | 4h |
| 7 | C-11 | No onboarding/coverage | Evaluators won't know what to ask | 8h |
| 8 | C-12 | Feedback is thumbs only | Cannot collect structured evaluation data | 12h |
| 9 | C-14 | No client analytics | Cannot measure task success or engagement | 8h |
| 10 | C-15 | Provider case sensitivity | Variant-case names return 0 results | 2h |

**Items 1–5 are trivial 1-line string/template fixes. Items 6–10 are small development tasks. All 10 should complete in <1 sprint (40h).**

---

## Top Model/Trust/UX Issues

| Rank | ID | Title | Impact on Trust |
| --- | --- | --- | --- |
| 1 | C-07 | SQL confidence bypass passes hallucinations | HIGH confidence on ungrounded claims |
| 2 | C-09 | No measurable confidence components | Users cannot judge why confidence was assigned |
| 3 | C-10 | No calibration data | Confidence may be systematically misleading |
| 4 | C-13 | No evidence panel | Users have no basis to verify answers |
| 5 | C-19 | No hard-failure override | Known-bad queries get HIGH confidence |
| 6 | C-27 | No per-question-type scoring | Rate lookup and clause extraction scored identically |
| 7 | C-20 | Fake streaming | Long perceived wait times damage UX |

---

## Dead-Code Cleanup List

| Item | File | Lines | Confidence Dead | Impact of Removal |
| --- | --- | --- | --- | --- |
| Shadowed method copies | `agent_controller.py` | ~5,200 lines | 100% (Python semantics) | Resolves C-03, enables safe editing |
| `amendment_chain.py` | `platform/v4/tools/` | ~200 lines | 95% (not in registry) | Resolves C-31, reduces confusion |
| `api_entry.py` | `platform/v4/runtime/` | ~150 lines | 90% (no caller) | Cleaner module tree |
| `async_bridge.py` | `platform/v4/runtime/` | ~100 lines | 90% (no caller) | Cleaner module tree |
| `notebook_stream_handler.py` | `platform/v4/runtime/` | ~100 lines | 90% (no caller) | Cleaner module tree |
| `notebook_compat_adapter.py` | `platform/v4/adapters/` | ~80 lines | 92% (no caller) | Cleaner module tree |
| `tier_service.py` | `platform/v4/services/` | ~120 lines | 95% (no caller) | Cleaner module tree |
| `planning.py` | `platform/v4/core/` | ~200 lines | 90% (no caller) | Cleaner module tree |
| `query_cache_repo.py` | `platform/v4/data/` | ~150 lines | 80% (imported but never wired) | Resolves C-32 |
| `init_runtime_api()` | `notebook_entry.py:134` | ~30 lines | 95% (no caller) | Cleaner entry point |
| **Total** | | **~6,330 lines** | | |

---

## Deferred Production Issues (Not Blocking Evaluation)

| ID | Title | Why Deferred | When to Address |
| --- | --- | --- | --- |
| C-20 | Fake streaming | UX polish, not correctness | Pre-production GA |
| C-32 | Query cache dead code | No user impact | Cleanup sprint |
| C-34 | No empty-result fallback (non-DOFR) | Covered by C-24 error states | Phase 3 |
| C-36 | No long-answer collapse | Cosmetic | Phase 3 |
| C-37 | No session search | Convenience | Phase 3 |
| C-39 | No regression dashboard | Operational maturity | Phase 3 |
| C-40 | Double quote stripping | Cosmetic only | Cleanup sprint |
| C-41 | Synthetic benchmark table | Document, don't remove | Phase 2 |

---

## Final Consolidated Ledger

| Severity | Count | IDs |
| --- | --- | --- |
| CRITICAL | 2 | C-01, C-02 |
| HIGH | 12 | C-03–C-14 |
| MEDIUM | 16 | C-15–C-30 |
| LOW | 12 | C-31–C-42 |
| **TOTAL** | **42** | |

### By Classification

| Type | Count | Examples |
| --- | --- | --- |
| Confirmed defect | 12 | C-01, C-02, C-05, C-06, C-08, C-15, C-16, C-17, C-28, C-29, C-33, C-40 |
| Confirmed weakness | 4 | C-04, C-07, C-18, C-21 |
| Design gap | 17 | C-09–C-14, C-19, C-22–C-27, C-30, C-34–C-39 |
| Documentation drift | 5 | C-28, C-31, C-33, C-41, C-42 |
| Dead code confusion | 4 | C-03, C-31, C-32, dead-code table |

### By Phase

| Phase | Count | Effort |
| --- | --- | --- |
| Phase 1 (pre-evaluation, immediate) | 14 | ~50h |
| Phase 2 (during/after evaluation) | 17 | ~120h |
| Phase 3 (production maturity) | 11 | ~80h |

---

*End of Report 10*