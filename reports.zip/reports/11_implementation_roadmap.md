# Contract Intelligence V4 — Incremental Implementation Roadmap

**Report**: 11 of N  
**Date**: 2026-07-26  
**Author**: Genie Code (automated audit assistant)  
**Status**: COMPLETE  
**Principle**: No large rewrite. Every change is independently testable, reversible, and linked to a validated finding.

---

## Phase 0 — Trusted Baseline (Days 1–2)

**Objective**: Establish a known-good reference point before any modification.

---

### R-001: Confirm Runtime and Deployed Build

| Field | Value |
| --- | --- |
| Objective | Record exact deployed state: git commit, app.yaml, model endpoints, warehouse ID, data snapshot date |
| Linked issues | None (prerequisite) |
| Files/Components | `app.yaml`, git HEAD, `settings.py` |
| Prerequisites | Access to running Databricks App |
| Tasks | 1. Record git SHA. 2. Capture `GET /health` + `/api/v1/startup-status` output. 3. Record LLM_ENDPOINT versions. 4. Record warehouse ID. 5. Save to `baselines/v4.0.0/manifest.json`. |
| Impact | Trust: all future changes measured against known state. Trial: enables regression detection. |
| Complexity | Trivial | Risk: None | Owner: DevOps |
| Test/Acceptance | manifest.json exists and matches running app |
| Sequence | First action, blocks all others |
| Data/Workspace | Read-only access to app, git |

---

### R-002: Run Characterization Test Suite (Existing 132 Cells)

| Field | Value |
| --- | --- |
| Objective | Execute full test suite against current build, record baseline scores |
| Linked issues | None (prerequisite) |
| Files/Components | `Contract_Intelligence_Comprehensive_Test_Suite` notebook (132 cells) |
| Prerequisites | R-001 (runtime confirmed) |
| Tasks | 1. Run cells 1–132. 2. Export results to `baselines/v4.0.0/results.jsonl`. 3. Record category accuracy, latency P50/P95, judge pass rate. |
| Impact | Regression: establishes comparison baseline. Trial: proves system functional. |
| Complexity | Low | Risk: None (read-only) | Owner: QA |
| Test/Acceptance | All 13 data model checks pass; overall PASS+PARTIAL ≥70% |
| Sequence | After R-001 |
| Data/Workspace | Existing notebook, SQL warehouse access |

---

### R-003: Pin Version IDs (App, Prompt, Model)

| Field | Value |
| --- | --- |
| Objective | Create version manifest: app version, system prompt hash, LLM model version, whitelist hash |
| Linked issues | C-30 (version comparison) |
| Files/Components | `settings.py`, `sql_query.py` (prompt), `table_whitelist.py` |
| Prerequisites | R-001 |
| Tasks | 1. SHA-256 hash system prompt. 2. SHA-256 hash whitelist dict. 3. Record model endpoint versions. 4. Store in manifest. |
| Impact | Evaluation: enables before/after comparison with McNemar's test |
| Complexity | Trivial | Risk: None | Owner: Dev |
| Test/Acceptance | Hashes reproducible on re-run |
| Sequence | Parallel with R-002 |
| Data/Workspace | None |

---

### R-004: Identify Highest-Risk Duplicate-Body Behavior

| Field | Value |
| --- | --- |
| Objective | Confirm which `_build_response` copy is active; document its exact behavior for regression testing |
| Linked issues | C-03 |
| Files/Components | `agent_controller.py` lines 6344–6500 |
| Prerequisites | R-001 |
| Tasks | 1. Add logging `__qualname__` + line number to active `_build_response` entry. 2. Run 5 questions. 3. Confirm line 6344 is always the entry. 4. Document in baseline. |
| Impact | Safety: proves which code path runs before any removal |
| Complexity | Trivial | Risk: None (logging only) | Owner: Dev |
| Test/Acceptance | All 5 runs show same entry line |
| Sequence | After R-001 |
| Data/Workspace | None |

---

## Phase 1 — Semantic Foundations (Days 3–5)

**Objective**: Fix data/query-level correctness issues that produce wrong answers. All are string edits in configuration/prompt, not logic changes.

---

### R-005: Fix Phantom Column `is_current_effective`

| Field | Value |
| --- | --- |
| Objective | Remove phantom column reference from system prompt Rule 7 |
| Linked issues | C-02 (CRITICAL) |
| Files/Components | `platform/v4/tools/sql_query.py` — system prompt string |
| Prerequisites | R-002 (baseline recorded) |
| Tasks | 1. Find Rule 7 in system prompt. 2. Replace `is_current_effective = true` with `status = 'current'`. 3. Run B-001–B-012 benchmarks. |
| Impact | Answer: eliminates UNRESOLVED_COLUMN errors for rate queries. Trust: removes invisible failure. Trial: rate tasks now pass. |
| Complexity | Trivial (1 string edit) | Risk: None | Owner: Dev |
| Test/Acceptance | 0 UNRESOLVED_COLUMN errors in 12 rate benchmarks; no regression vs. R-002 baseline |
| Sequence | First code change |
| Data/Workspace | None |

---

### R-006: Fix DOFR is_current Contradiction

| Field | Value |
| --- | --- |
| Objective | Remove is_current filtering instruction from DOFR whitelist entry |
| Linked issues | C-01 (CRITICAL) |
| Files/Components | `platform/v4/config/table_whitelist.py` (DOFR entry) |
| Prerequisites | R-002 |
| Tasks | 1. Find DOFR entry in whitelist. 2. Remove "filter by is_current=TRUE" instruction. 3. Add: "Do NOT filter by is_current on this table (incomplete coverage)." 4. Run B-022–B-025. |
| Impact | Answer: BH/Pharmacy/Emergency DOFR questions now return data. Trial: DOFR tasks pass. |
| Complexity | Trivial | Risk: None | Owner: Dev |
| Test/Acceptance | B-022–B-025 return non-zero rows for all service categories |
| Sequence | After R-005 (or parallel) |
| Data/Workspace | None |

---

### R-007: Fix Delegation is_current Data Loss

| Field | Value |
| --- | --- |
| Objective | Remove is_current=TRUE instruction from delegation whitelist entry |
| Linked issues | C-08 (HIGH) |
| Files/Components | `table_whitelist.py` (delegation entry) |
| Prerequisites | R-002 |
| Tasks | 1. Find delegation entry. 2. Remove is_current instruction. 3. Add coverage note. 4. Run B-026–B-027. |
| Impact | Answer: 88 additional providers visible in delegation queries |
| Complexity | Trivial | Risk: None | Owner: Dev |
| Test/Acceptance | Delegation query returns 120 providers (not 32) |
| Sequence | Parallel with R-006 |
| Data/Workspace | None |

---

### R-008: Fix Amendment STRING Sort

| Field | Value |
| --- | --- |
| Objective | Replace `amendment_order` with `amendment_order_int` in ORDER BY |
| Linked issues | C-05 (HIGH) |
| Files/Components | `platform/v4/tools/rate_query.py` (amendment_comparison template) |
| Prerequisites | R-002 |
| Tasks | 1. Find ORDER BY amendment_order in template. 2. Replace with amendment_order_int. 3. Run B-014, B-016, B-031. |
| Impact | Answer: correct "previous amendment" identification |
| Complexity | Trivial | Risk: None | Owner: Dev |
| Test/Acceptance | Provider with 10+ amendments shows correct integer ordering |
| Sequence | Parallel with R-005–R-007 |
| Data/Workspace | None |

---

### R-009: Fix Benchmark COUNT(*) Mislabel

| Field | Value |
| --- | --- |
| Objective | Change COUNT(*) to COUNT(DISTINCT canonical_provider_id) in benchmark template |
| Linked issues | C-06 (HIGH) |
| Files/Components | `platform/v4/services/rate_query_templates.py` |
| Prerequisites | R-002 |
| Tasks | 1. Find `COUNT(*) AS n_providers`. 2. Replace with `COUNT(DISTINCT canonical_provider_id) AS n_providers`. 3. Run benchmark query. |
| Impact | Answer: correct provider counts in benchmark answers |
| Complexity | Trivial | Risk: None | Owner: Dev |
| Test/Acceptance | Benchmark n_providers matches `SELECT COUNT(DISTINCT canonical_provider_id)` directly |
| Sequence | Parallel |
| Data/Workspace | None |

---

### R-010: Fix Whitelist Duplicates and Documentation Drift

| Field | Value |
| --- | --- |
| Objective | Remove 3 duplicate dict entries; update stale descriptions (fact_supersession, rate counts) |
| Linked issues | C-16, C-28, C-29, C-33 |
| Files/Components | `table_whitelist.py` |
| Prerequisites | R-002 |
| Tasks | 1. Remove duplicate entries (provider_identifiers, rate_escalators, service_areas). 2. Fix fact_supersession provider_id description. 3. Update rate status counts. 4. Add dim_table_schema note for missing tables. |
| Impact | Model: LLM gets correct table descriptions. Answer: fewer mis-selections. |
| Complexity | Low | Risk: None | Owner: Dev |
| Test/Acceptance | `len(CONTRACT_TABLES_FOR_SQL)` = 29 (no duplicates); descriptions match live data |
| Sequence | Parallel |
| Data/Workspace | None |

---

### R-011: Add COUNT(DISTINCT) System Prompt Rule

| Field | Value |
| --- | --- |
| Objective | Add rule: "For provider counts from multi-row tables, always use COUNT(DISTINCT provider_name or canonical_provider_id)" |
| Linked issues | C-18 |
| Files/Components | `sql_query.py` system prompt |
| Prerequisites | R-005 (prompt already being edited) |
| Tasks | 1. Add as Rule 24 in system prompt. 2. Run B-027, B-028 count questions. |
| Impact | Answer: correct provider counts from clauses/rates tables |
| Complexity | Trivial | Risk: None | Owner: Dev |
| Test/Acceptance | Count queries on multi-row tables use DISTINCT |
| Sequence | After R-005 |
| Data/Workspace | None |

---

## Phase 2 — SQL Correctness Guards (Days 5–8)

**Objective**: Add deterministic post-generation validation for generated SQL.

---

### R-012: Canonical Join Enforcement

| Field | Value |
| --- | --- |
| Objective | Detect and reject/rewrite rates→profile joins using provider_id |
| Linked issues | C-04 (HIGH) |
| Files/Components | `platform/v4/tools/sql_query.py` (`_validate_sql` method) |
| Prerequisites | R-005–R-010 (foundations stable) |
| Tasks | 1. Parse generated SQL for JOIN ON clauses. 2. If rates→profile on provider_id detected, rewrite to canonical_provider_id. 3. Log rewrite event. 4. Run B-001–B-012. |
| Impact | Answer: eliminates 28% data loss. Trust: all rate answers use correct join. |
| Complexity | Medium (SQL string matching or light AST) | Risk: Low (additive) | Owner: Dev |
| Test/Acceptance | No orphan rows in any rate benchmark result; log shows 0 rewrites needed for template path |
| Sequence | Start of Phase 2 |
| Data/Workspace | None |

---

### R-013: Provider Name Case-Insensitive Matching

| Field | Value |
| --- | --- |
| Objective | Ensure provider_name comparisons use LOWER() or ILIKE |
| Linked issues | C-15 |
| Files/Components | `sql_query.py` (provider enforcement logic) |
| Prerequisites | R-012 |
| Tasks | 1. Find provider_name injection in post-processing. 2. Wrap both sides in LOWER(). 3. Test with mixed-case variants. |
| Impact | Answer: "sharp healthcare" resolves same as "Sharp HealthCare" |
| Complexity | Low | Risk: None | Owner: Dev |
| Test/Acceptance | B-008 (variant spelling), B-037 (misspelled) pass |
| Sequence | After R-012 |
| Data/Workspace | None |

---

### R-014: Add dim_table_schema Entries for Missing Tables

| Field | Value |
| --- | --- |
| Objective | Insert schema rows for tbl_reimb_stop_loss and tbl_reimb_carve_outs |
| Linked issues | C-29 |
| Files/Components | `dev_adb.raw.dim_table_schema` (2 INSERT statements) |
| Prerequisites | R-002 |
| Tasks | 1. DESCRIBE both tables. 2. INSERT INTO dim_table_schema. 3. Verify SchemaContextBuilder picks them up. |
| Impact | Model: LLM can now use these tables for stop-loss/carve-out questions |
| Complexity | Low | Risk: None | Owner: Data |
| Test/Acceptance | `SELECT COUNT(*) FROM dim_table_schema WHERE table_name IN (...)` = 2 new rows |
| Sequence | Parallel with R-012 |
| Data/Workspace | SQL warehouse write access to dim_table_schema |

---

## Phase 3 — Grounding & Trust (Days 8–12)

**Objective**: Prevent ungrounded claims from reaching users with HIGH confidence.

---

### R-015: Numeric Reproducibility Check

| Field | Value |
| --- | --- |
| Objective | Verify all numbers in answer exist in tool_result.data before returning |
| Linked issues | C-07, C-19 (confidence bypass, hard-failure override) |
| Files/Components | `agent_controller.py` `_build_response` |
| Prerequisites | R-004 (confirmed active copy) |
| Tasks | 1. After synthesis, extract all numbers from answer. 2. Check each against tool_result rows. 3. If number not found AND not a count/percentage derivable from data, flag as ungrounded. 4. If ungrounded numeric, downgrade confidence to MODERATE. |
| Impact | Trust: no uncited numeric claims with HIGH confidence. Trial: confidence rated "appropriate" more often. |
| Complexity | Medium | Risk: Low (adds check, doesn't remove) | Owner: Dev |
| Test/Acceptance | Answer containing LLM-estimated "average" not in SQL result gets MODERATE not HIGH |
| Sequence | Start of Phase 3 |
| Data/Workspace | None |

---

### R-016: Hard-Failure Confidence Override

| Field | Value |
| --- | --- |
| Objective | Implement top-4 hard failures (HF-01: missing status filter, HF-02: wrong join, HF-05: uncited numeric, HF-07: zero-rows-as-absence) |
| Linked issues | C-19, C-07 |
| Files/Components | `agent_controller.py` `_build_response` |
| Prerequisites | R-012 (join enforcement provides data), R-015 (numeric check) |
| Tasks | 1. After SQL execution, check for HF conditions. 2. If triggered, override confidence to UNCERTAIN. 3. Add `hard_failure_flags` to response metadata. |
| Impact | Trust: known-bad queries never display HIGH confidence |
| Complexity | Medium | Risk: Low | Owner: Dev |
| Test/Acceptance | Query with missing temporal filter gets UNCERTAIN; query with correct filter gets original confidence |
| Sequence | After R-015 |
| Data/Workspace | None |

---

### R-017: Evidence Summary in API Response

| Field | Value |
| --- | --- |
| Objective | Add `evidence_summary` object to /api/v1/query response |
| Linked issues | C-13 |
| Files/Components | `agent_controller.py` `_build_response`, `app/main.py` response schema |
| Prerequisites | R-015, R-016 |
| Tasks | 1. Collect tables queried, row counts, method (template vs LLM-SQL vs passage_search). 2. Include data freshness (max created_at from result). 3. Add limitations list (formula-only rates, truncation). 4. Serialize in response JSON. |
| Impact | Trust: frontend can show evidence panel. Trial: users rate trust higher with transparency. |
| Complexity | Medium | Risk: Low | Owner: Dev |
| Test/Acceptance | Every response contains evidence_summary with tables[], row_count, method, limitations[] |
| Sequence | After R-016 |
| Data/Workspace | None |

---

## Phase 4 — UX for Evaluation (Days 10–15)

**Objective**: Enable controlled-group users to understand, judge, and provide feedback on answers.

---

### R-018: Onboarding Modal + Example Questions

| Field | Value |
| --- | --- |
| Objective | Show purpose, coverage, supported/unsupported categories on first visit |
| Linked issues | C-11, C-22 |
| Files/Components | `frontend/src/pages/ChatPageV2.tsx` (new component) |
| Prerequisites | None (frontend-only) |
| Tasks | 1. Create OnboardingModal component. 2. Show on first visit (localStorage flag). 3. Include coverage stats from /health endpoint. 4. Add categorized examples in empty-chat state. |
| Impact | Trial: evaluators know what to ask; task completion rate increases. |
| Complexity | Medium | Risk: None | Owner: Frontend |
| Test/Acceptance | New user sees modal; examples populate empty state; localStorage prevents re-show |
| Sequence | Start of Phase 4 (parallel with Phase 3) |
| Data/Workspace | None |

---

### R-019: Structured Feedback Component

| Field | Value |
| --- | --- |
| Objective | Replace thumbs up/down with structured feedback (accuracy, error categories, confidence, expected answer) |
| Linked issues | C-12 |
| Files/Components | `ChatPageV2.tsx` (replace FeedbackControls), `main.py` (extend schema) |
| Prerequisites | None |
| Tasks | 1. Create StructuredFeedback component. 2. Extend FeedbackRequest model in main.py. 3. Store full structured data in tbl_user_feedback. 4. Backward-compatible (old clients still work). |
| Impact | Evaluation: enables error-category analysis, confidence calibration from user perspective. |
| Complexity | Medium | Risk: Low | Owner: Frontend + Backend |
| Test/Acceptance | Structured feedback stored; aggregation query returns category distribution |
| Sequence | Parallel with R-018 |
| Data/Workspace | tbl_user_feedback schema extension |

---

### R-020: Client-Side Analytics Events

| Field | Value |
| --- | --- |
| Objective | Instrument 10 key events for evaluation measurement |
| Linked issues | C-14 |
| Files/Components | New `frontend/src/services/analytics.ts`; new `POST /api/v1/events` endpoint |
| Prerequisites | None |
| Tasks | 1. Create analytics service. 2. Emit events: question_submitted, answer_received, citation_clicked, feedback_submitted, example_clicked, etc. 3. Store in new tbl_evaluation_events table. |
| Impact | Evaluation: enables task success measurement, citation engagement, time-on-task. |
| Complexity | Medium | Risk: None | Owner: Frontend + Backend |
| Test/Acceptance | Events appear in table during smoke test |
| Sequence | Parallel with R-018–R-019 |
| Data/Workspace | New table creation |

---

### R-021: Evidence Panel in Answer Display

| Field | Value |
| --- | --- |
| Objective | Show evidence_summary from R-017 in collapsible panel below answer |
| Linked issues | C-13 |
| Files/Components | `ChatPageV2.tsx` (new EvidencePanel component) |
| Prerequisites | R-017 (backend returns evidence_summary) |
| Tasks | 1. Create EvidencePanel (tables, rows, method, limitations, freshness). 2. Show below answer, above citations. 3. Collapsible, open by default. |
| Impact | Trust: users can assess data basis. Trial: trust scores increase. |
| Complexity | Low–Medium | Risk: None | Owner: Frontend |
| Test/Acceptance | Panel renders for every answer with non-empty evidence_summary |
| Sequence | After R-017 |
| Data/Workspace | None |

---

## Phase 5 — Statistical Evaluation Infrastructure (Days 12–18)

**Objective**: Enable data-science-grade measurement of system quality.

---

### R-022: Externalized Benchmark YAML

| Field | Value |
| --- | --- |
| Objective | Extract 109 benchmark cases into `benchmarks/v4.0.0.yaml` with full schema |
| Linked issues | C-38 |
| Files/Components | New `benchmarks/` directory + YAML file |
| Prerequisites | R-002 (baseline results exist) |
| Tasks | 1. Define YAML schema per Report 9 §2. 2. Populate 109 cases. 3. Add loader to test framework. |
| Impact | Evaluation: versionable, diffable benchmark definitions. |
| Complexity | Medium | Risk: None | Owner: QA |
| Test/Acceptance | `yaml.safe_load()` loads 109 cases; all fields validate |
| Sequence | Start of Phase 5 |
| Data/Workspace | None |

---

### R-023: SQL AST Validation Layer

| Field | Value |
| --- | --- |
| Objective | Parse generated SQL, check tables/joins/filters against benchmark expectations |
| Linked issues | C-25 |
| Files/Components | New `evaluation/sql_validator.py` |
| Prerequisites | R-022 (benchmark YAML provides expectations) |
| Tasks | 1. Parse SQL (sqlglot or regex). 2. Extract tables, join keys, WHERE clauses. 3. Compare vs. expected_tables, expected_joins, required_filters from YAML. 4. Report per-question structural pass/fail. |
| Impact | Evaluation: deterministic SQL quality metric without LLM judge. |
| Complexity | Medium | Risk: Low | Owner: Dev |
| Test/Acceptance | Runs on 109 benchmarks; flags known issues (C-04, C-05) correctly |
| Sequence | After R-022 |
| Data/Workspace | None |

---

### R-024: Stability/Paraphrase Testing

| Field | Value |
| --- | --- |
| Objective | Run 3× repeat + 5 paraphrase groups; compute consistency metrics |
| Linked issues | C-26, C-30 |
| Files/Components | New `evaluation/stability_runner.py` |
| Prerequisites | R-022 |
| Tasks | 1. Run each of 5 paraphrase groups 3 variants. 2. Run 20-question sample 3× each. 3. Compute semantic cosine similarity. 4. Compute route/SQL/citation consistency. |
| Impact | Evaluation: quantifies non-determinism. Flags unstable categories. |
| Complexity | Medium | Risk: None (read-only) | Owner: QA |
| Test/Acceptance | Repeatability ≥0.85 for SUPPORTED-band answers; paraphrase consistency ≥0.80 |
| Sequence | After R-022 |
| Data/Workspace | LLM endpoint access for embedding similarity |

---

### R-025: Calibration Analysis

| Field | Value |
| --- | --- |
| Objective | Compute ECE, Brier, reliability diagram from benchmark + judge results |
| Linked issues | C-10 |
| Files/Components | New `evaluation/calibration.py` |
| Prerequisites | R-022 + R-002 (benchmark results with confidence labels + judge scores) |
| Tasks | 1. Bin answers by confidence band. 2. Compute accuracy per bin. 3. ECE = weighted |accuracy - midpoint|. 4. Plot reliability diagram. |
| Impact | Trust: quantifies whether confidence is misleading. Blocks overconfident answers. |
| Complexity | Low | Risk: None | Owner: Data Science |
| Test/Acceptance | ECE computed and <0.20; reliability diagram saved |
| Sequence | After full benchmark run post-Phase 1–3 fixes |
| Data/Workspace | None |

---

## Phase 6 — Development Reliability (Days 15–20)

**Objective**: System behaviors that affect reproducibility and development stability.

---

### R-026: Remove Debug Prints

| Field | Value |
| --- | --- |
| Objective | Replace print() with logger.debug() |
| Linked issues | C-17 |
| Files/Components | `agent_controller.py:888`, `rate_query.py:574-575` |
| Prerequisites | R-004 (confirmed active code path) |
| Tasks | 1. Replace 3 print() calls with logger.debug(). 2. Verify no stdout pollution. |
| Impact | Operations: clean logs. Development: easier debugging. |
| Complexity | Trivial | Risk: None | Owner: Dev |
| Test/Acceptance | No print() output in stdout during 5-question run |
| Sequence | Anytime after R-004 |
| Data/Workspace | None |

---

### R-027: Structured Trace Logging

| Field | Value |
| --- | --- |
| Objective | Log route decision, tool sequence, SQL, row count, confidence per question |
| Linked issues | C-14 (observability) |
| Files/Components | `agent_controller.py` `run()` method |
| Prerequisites | R-004 |
| Tasks | 1. At end of run(), emit structured JSON log: {session_id, question_hash, route, tools, sql_hash, rows, confidence, latency_ms}. 2. Log to structured logger (not print). |
| Impact | Evaluation: enables offline analysis of routing, tool usage, latency distribution. |
| Complexity | Low | Risk: None | Owner: Dev |
| Test/Acceptance | Structured log line appears for every query in /health log stream |
| Sequence | Phase 6 |
| Data/Workspace | None |

---

## Phase 7 — Dead-Code Quarantine (Days 18–22)

**Objective**: Remove dead code that blocks safe development. Subtractive only.

---

### R-028: Quarantine Shadowed Methods in agent_controller.py

| Field | Value |
| --- | --- |
| Objective | Delete lines 746–5999 (dead copies of 10 methods) |
| Linked issues | C-03 (HIGH) |
| Files/Components | `agent_controller.py` |
| Prerequisites | R-004 (confirmed active copy), R-002 (full test pass on current code) |
| Tasks | 1. Create branch. 2. Delete lines 746–5999. 3. Renumber/adjust class start. 4. Run full test suite. 5. Diff output: must be identical. |
| Impact | Development: file goes from 8,465 to ~3,265 lines. Safe editing possible. |
| Complexity | Medium (large diff) | Risk: Low (dead code) | Owner: Dev |
| Test/Acceptance | Full 132-cell test suite produces identical results before and after |
| Sequence | After all Phase 1–3 changes proven |
| Data/Workspace | None |

---

### R-029: Remove Unused Files

| Field | Value |
| --- | --- |
| Objective | Delete 7 confirmed-dead files from platform/v4/ |
| Linked issues | C-31, dead-code table |
| Files/Components | `amendment_chain.py`, `api_entry.py`, `async_bridge.py`, `notebook_stream_handler.py`, `notebook_compat_adapter.py`, `tier_service.py`, `planning.py` |
| Prerequisites | R-028 (proved deletion doesn't break anything) |
| Tasks | 1. Delete files. 2. Remove any stale imports. 3. Run test suite. |
| Impact | Development: cleaner repository, fewer false leads for developers |
| Complexity | Low | Risk: Low | Owner: Dev |
| Test/Acceptance | Test suite identical; no import errors |
| Sequence | After R-028 |
| Data/Workspace | None |

---

## Phase 8 — Controlled User Trial (Days 22–36)

**Objective**: Run the structured evaluation with 8 evaluators.

---

### R-030: Pre-Trial Validation Run

| Field | Value |
| --- | --- |
| Objective | Full benchmark suite on final build; compute all metrics; publish readiness report |
| Linked issues | All |
| Files/Components | Benchmark runner, calibration analysis |
| Prerequisites | R-005–R-025 complete |
| Tasks | 1. Run 109 benchmarks. 2. Compute category accuracy, Wilson CIs. 3. Run stability tests. 4. Compute ECE. 5. Publish summary. 6. Go/no-go decision. |
| Impact | Trial: confirms system ready. Blocks trial if thresholds not met. |
| Complexity | Low (automation exists) | Risk: None | Owner: QA |
| Test/Acceptance | Report 9 §6.2 Expert Gate thresholds all met |
| Sequence | Gate before trial |
| Data/Workspace | None |

---

### R-031: Execute Guided Evaluation (Report 8 Protocol)

| Field | Value |
| --- | --- |
| Objective | 8 evaluators × 15 tasks + free exploration + questionnaire |
| Linked issues | C-11, C-12, C-13, C-14 |
| Files/Components | App (deployed), evaluation forms, questionnaire |
| Prerequisites | R-030 (go decision), R-018–R-021 (UX ready) |
| Tasks | 1. Schedule 90-min sessions. 2. Distribute task scripts. 3. Collect per-task assessments. 4. Collect post-session questionnaires. 5. Aggregate into scorecards. |
| Impact | Trial: produces go/no-go evidence for broader rollout. |
| Complexity | High (coordination) | Risk: Medium (depends on availability) | Owner: PM + QA |
| Test/Acceptance | Report 8 §9.2 Go/No-Go matrix evaluated |
| Sequence | Final phase |
| Data/Workspace | Scheduled calendar time; evaluator access to app |

---

## Minimum Viable Trusted Application (MVTA)

The minimum set of changes to make the application trustworthy for controlled evaluation:

| Required | ID | Effort | Cumulative |
| --- | --- | --- | --- |
| Fix phantom column | R-005 | 15 min | 15 min |
| Fix DOFR is_current | R-006 | 15 min | 30 min |
| Fix delegation is_current | R-007 | 15 min | 45 min |
| Fix amendment STRING sort | R-008 | 15 min | 1h |
| Fix benchmark COUNT(*) | R-009 | 15 min | 1h 15m |
| Fix whitelist duplicates/drift | R-010 | 30 min | 1h 45m |
| Add DISTINCT rule | R-011 | 15 min | 2h |
| Canonical join enforcement | R-012 | 4h | 6h |
| Case-insensitive provider | R-013 | 2h | 8h |
| **MVTA TOTAL** | | | **8 hours** |

After MVTA: re-run full benchmark suite. Expected improvement: +10–15% accuracy over baseline (eliminates known wrong-answer categories).

---

## Best-Development-Version Plan

| Phase | Duration | Cumulative | Key Deliverable |
| --- | --- | --- | --- |
| Phase 0 | 2 days | Day 2 | Baseline recorded |
| Phase 1 | 3 days | Day 5 | All prompt/config fixes live; MVTA achieved |
| Phase 2 | 3 days | Day 8 | SQL guards active; join/filter enforcement |
| Phase 3 | 4 days | Day 12 | Grounding checks; confidence override; evidence API |
| Phase 4 | 5 days | Day 15 | UX ready for evaluation (onboarding, feedback, analytics) |
| Phase 5 | 3 days | Day 18 | Statistical infrastructure; calibration |
| Phase 6 | 2 days | Day 20 | Clean logs; structured traces |
| Phase 7 | 2 days | Day 22 | Dead code removed; lean codebase |
| Phase 8 | 14 days | Day 36 | Trial complete; go/no-go decision |

---

## Changes NOT to Attempt Yet

| Change | Why Not Now | When |
| --- | --- | --- |
| True token-by-token streaming (C-20) | High complexity, no correctness impact | Post-trial, if UX scores demand |
| Per-question-type confidence scoring (C-27) | Requires calibration data from trial | Post-trial Phase 2 |
| Full component confidence (C-09) | Requires Phase 5 calibration baseline | Post-trial |
| Query cache resurrection (C-32) | No user impact; adds complexity | Only if latency a concern |
| Provider autocomplete (C-23) | Nice-to-have, not trial-blocking | Post-trial |
| Long-answer collapse (C-36) | Cosmetic | Post-trial |
| Session search (C-37) | Convenience | Post-trial |
| Regression dashboard (C-39) | Operational maturity | Post-Phase 5 |

---

## Readiness Checklist (Pre-Trial Gate)

| # | Criterion | Source | Required |
| --- | --- | --- | --- |
| 1 | Baseline manifest recorded | R-001, R-003 | Yes |
| 2 | No CRITICAL findings open | C-01, C-02 fixed | Yes |
| 3 | All HIGH defects fixed or mitigated | C-04–C-08 | Yes |
| 4 | Benchmark accuracy ≥85% overall | R-030 | Yes |
| 5 | No category below 75% (Wilson CI lower bound) | R-030 | Yes |
| 6 | 0 UNRESOLVED_COLUMN errors | R-005 validation | Yes |
| 7 | 0 unapproved-join hard failures | R-012 validation | Yes |
| 8 | Onboarding modal deployed | R-018 | Yes |
| 9 | Structured feedback deployed | R-019 | Yes |
| 10 | Analytics instrumented | R-020 | Yes |
| 11 | Evidence panel deployed | R-021 | Yes |
| 12 | ECE < 0.20 | R-025 | Warning (not blocking) |
| 13 | Stability ≥0.85 | R-024 | Warning (not blocking) |
| 14 | Dead code removed | R-028 | Recommended (not blocking) |

---

## Go/No-Go Framework

| Decision | Criteria | Action |
| --- | --- | --- |
| GO | Checklist items 1–11 all YES; benchmark ≥85%; 0 new CRITICAL | Proceed to trial |
| CONDITIONAL GO | Items 1–11 YES; benchmark 80–85%; 1–2 warnings unresolved | Proceed with documented gaps |
| HOLD | Any of items 1–11 is NO; OR benchmark <80% | Fix blockers; re-run in 1 week |
| NO-GO | Benchmark <70% OR new CRITICAL found OR 3+ HIGH open | Major rework required |

---

## Implementation Prompt Order

The exact sequence of file edits for a developer:

```
1. table_whitelist.py    ← R-006, R-007, R-010 (remove DOFR/delegation is_current; fix duplicates; fix descriptions)
2. sql_query.py          ← R-005, R-011 (fix Rule 7; add Rule 24 DISTINCT)
3. rate_query.py         ← R-008 (amendment_order_int)
4. rate_query_templates.py ← R-009 (COUNT DISTINCT)
5. sql_query.py          ← R-012, R-013 (join enforcement + case normalization)
6. agent_controller.py   ← R-015, R-016, R-017 (numeric check, HF override, evidence_summary)
7. main.py               ← R-017, R-019, R-020 (extend response schema, feedback schema, events endpoint)
8. ChatPageV2.tsx        ← R-018, R-019, R-020, R-021 (onboarding, feedback, analytics, evidence panel)
9. agent_controller.py   ← R-026, R-027 (debug prints, structured traces)
10. agent_controller.py  ← R-028 (delete dead code)
11. Dead files            ← R-029 (delete 7 files)
```

**Critical invariant**: After steps 1–4, re-run full benchmark suite. If accuracy degrades vs. baseline, stop and investigate before proceeding.

---

## Final Consolidated Ledger

| Severity | Count | Status After Roadmap |
| --- | --- | --- |
| CRITICAL | 2 | Both fixed (R-005, R-006) |
| HIGH | 12 | 8 fixed (R-007–R-012, R-015–R-016); 4 mitigated (C-09, C-10, C-11, C-13 via Phase 3–4) |
| MEDIUM | 16 | 10 fixed; 6 deferred to post-trial |
| LOW | 12 | 4 fixed; 8 deferred |
| **TOTAL** | **42** | **24 fixed, 10 mitigated, 8 deferred** |

---

*End of Report 11*