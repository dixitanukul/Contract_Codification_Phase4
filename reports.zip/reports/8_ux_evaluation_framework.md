# Contract Intelligence V4 — UX Audit & Controlled Evaluation Framework

**Report**: 8 of N  
**Date**: 2026-07-26  
**Author**: Genie Code (automated audit assistant)  
**Status**: COMPLETE  
**Scope**: Frontend experience gaps, onboarding design, structured feedback, evaluation scorecards, guided trial tasks, analytics instrumentation

---

## 1. Current Frontend State (Evidence-Based Inventory)

### 1.1 Pages Deployed

| Route | Page | Lines | Purpose |
| --- | --- | --- | --- |
| `/` | ChatPageV2.tsx | 577 | Primary Q&A conversation interface |
| `/providers` | ProviderExplorerV2.tsx | — | Provider list + detail drill-down |
| `/reports` | ReportPageV2.tsx | — | Concept/clause coverage reports |
| `/alerts` | AlertsPageV2.tsx | — | Alert queue (critical/non-critical) |
| `/compliance` | CompliancePageV2.tsx | — | Regulation compliance tracker |
| `/calendar` | DeadlineCalendarV2.tsx | — | Contract deadline calendar |
| `/status` | StatusPageV2.tsx | — | System health + usage metrics |
| `/viewer` | DocumentViewerV2.tsx | — | Source document viewer (citation links) |

### 1.2 Chat Experience (Current)

**Input**: Single textarea, `provider_name` scope, `session_id` for multi-turn. No example prompts, no category hints, no input validation.

**Loading/Progress**: Streaming SSE with tool-step badges, thinking text, animated spinner. Functional.

**Answer Display**:
- Markdown rendering with GFM tables (good)
- DOFR-aware color-coded Yes/No cells (good)
- Confidence badge: `HIGH`/`MODERATE`/`LOW`/`UNCERTAIN` (4-level enum)
- Latency + cost + tool names shown inline
- Citations: 2-column card grid with source/page/snippet/provider (links to DocumentViewer)

**Feedback**: Thumbs up / Thumbs down ONLY. Backend accepts `correction` and `note` fields but frontend sends only `rating: 'up'|'down'`.

**Session Management**: Sidebar with paginated session list, new-chat button, session resume, copy/export.

### 1.3 Confidence Display (Current)

The `ConfidenceBadge` shows one of 4 color-coded labels. There is:
- NO explanation of why the label was assigned
- NO component breakdown (data quality / query quality / evidence)
- NO evidence summary (which tables, how many rows, currentness)
- NO limitations disclosure
- NO "how to interpret this" guidance

---

## 2. Frontend Gaps Register

| Gap ID | Category | Finding | Severity | Impact |
| --- | --- | --- | --- | --- |
| UX-01 | Onboarding | No landing/welcome page explaining purpose, coverage, or supported questions | HIGH | Users ask unsupported questions, get frustrated |
| UX-02 | Onboarding | No example questions or category guide | HIGH | Users don't know what's possible |
| UX-03 | Guidance | No input validation, spell-check, or provider name suggestion | MEDIUM | Mistyped providers return 0 results |
| UX-04 | Confidence | No evidence panel (sources, rows, freshness, limitations) | HIGH | Users cannot judge trustworthiness |
| UX-05 | Confidence | No explanation of confidence components | MEDIUM | Opaque trust signal |
| UX-06 | Feedback | Only thumbs up/down — no structured error categories | HIGH | Cannot diagnose error patterns |
| UX-07 | Feedback | `correction` field exists in API but not exposed in UI | MEDIUM | Lost correction data |
| UX-08 | Evaluation | No in-app questionnaire or NPS mechanism | HIGH | Cannot measure controlled-group satisfaction |
| UX-09 | Error states | Generic error message; no retry/rephrase guidance | MEDIUM | Dead-end UX |
| UX-10 | No-result | No specific "I couldn't find data" vs "question unsupported" distinction | MEDIUM | User doesn't know what to do next |
| UX-11 | Long answers | No collapse/expand for long markdown; no table-of-contents | LOW | Scroll fatigue |
| UX-12 | Responsive | Sessions sidebar absolute on mobile; no tablet optimization | LOW | Usability on smaller screens |
| UX-13 | History | No search/filter on session history | LOW | Hard to find past conversations |
| UX-14 | Export | Export available (markdown) but no PDF/structured report | LOW | Limited sharing options |
| UX-15 | Analytics | No client-side event tracking for evaluation | HIGH | Cannot measure task success |

---

## 3. Recommended Experience Design

### 3.1 Landing/Onboarding (New: First-Visit Modal or Dedicated `/welcome` route)

```
┌───────────────────────────────────────────────────────────────────────┐
│  🛡️ Contract Intelligence V4                                         │
│                                                                       │
│  What this tool does:                                                │
│  Answers questions about provider contracts, rates, clauses,          │
│  delegations, DOFR responsibilities, and compliance using live        │
│  contract data from 306 providers and 10,349 documents.               │
│                                                                       │
│  ✅ Supported questions:                                              │
│  • Provider rates and rate comparisons                                │
│  • Clause existence (offset, auto-renewal, termination)               │
│  • DOFR responsibility lookups                                        │
│  • Delegation and IPA status                                          │
│  • Amendment history and supersession                                 │
│  • Contract deadlines and expirations                                 │
│  • Compliance and quality metrics                                     │
│  • Network and health system membership                               │
│                                                                       │
│  ⚠️ Not supported:                                                    │
│  • Claims payment/utilization data (not in contract DB)               │
│  • Real-time eligibility verification                                 │
│  • Non-Blue Shield contracts                                          │
│  • Legal advice or contract interpretation                            │
│                                                                       │
│  📊 Data coverage:                                                    │
│  • 306 providers (194 active) across 531 canonical entities           │
│  • 459,902 rate lines (171,763 current)                               │
│  • Contracts from 2018–2026, latest refresh: [date]                   │
│                                                                       │
│  [Start asking →]    [See example questions]    [Provider directory]   │
└───────────────────────────────────────────────────────────────────────┘
```

### 3.2 Example Questions Panel (Shown on empty chat state)

Replace current "What would you like to know?" with categorized examples:

```
┌─── Quick Start ──────────────────────────────────────────────────────┐
│                                                                       │
│  Provider Rates                                                       │
│  • "What are Sharp HealthCare's current inpatient rates?"            │
│  • "Compare Kaiser and Sutter ED rates"                              │
│                                                                       │
│  Clauses & Coverage                                                   │
│  • "Does Adventist have an offset clause?"                           │
│  • "Which providers have auto-renewal clauses?"                      │
│                                                                       │
│  DOFR & Delegation                                                    │
│  • "Who is responsible for pharmacy for Scripps?"                    │
│  • "What functions are delegated to Dignity Health?"                  │
│                                                                       │
│  Compliance & Risk                                                    │
│  • "Show critical alerts for this month"                             │
│  • "Which providers have upcoming deadlines?"                        │
│                                                                       │
│  💡 Tips: Name the provider explicitly. Ask one concept per question. │
│     For rates, specify service category if possible.                  │
└───────────────────────────────────────────────────────────────────────┘
```

### 3.3 Enhanced Answer Layout

```
┌─── Answer ────────────────────────────────────────────────────────────┐
│  [Markdown answer content with tables/formatting]                     │
│                                                                       │
├─── Evidence Summary (collapsible, open by default) ──────────────────┤
│  📊 Data Source: tbl_contract_rates_all                              │
│     Records: 14 matching rate lines                                   │
│     Status: current (not superseded)                                  │
│     Freshness: data current as of 2026-07-20                          │
│                                                                       │
│  🔍 Method: Direct SQL lookup (rate_query tool)                      │
│     No inference or estimation used                                   │
│                                                                       │
│  ⚠️ Limitations:                                                      │
│     • 2 rate lines have formula-only values (excluded from averages)  │
│     • Rates reflect contract terms, not actual reimbursement          │
│                                                                       │
├─── Confidence: SUPPORTED ────────────────────────────────────────────┤
│  Data quality: ██████████ 1.00  (all PK/FK valid)                    │
│  Query quality: ████████░░ 0.85  (-0.15: 1 rate without numeric)     │
│  Evidence:      █████████░ 0.92  (14/14 claims have source row)      │
│                                                                       │
├─── Citations (2 documents) ──────────────────────────────────────────┤
│  [Citation cards as today]                                            │
│                                                                       │
├─── Feedback ─────────────────────────────────────────────────────────┤
│  Was this answer: [Correct] [Partially correct] [Incorrect] [Unsure] │
│  Issue (optional): [dropdown: wrong provider | wrong rate | ...]      │
│  Expected answer: [__________]                                        │
│  Comment: [__________]                                                │
│  Confidence: [Too high] [Appropriate] [Too low]                       │
└───────────────────────────────────────────────────────────────────────┘
```

### 3.4 Error/No-Result States

| State | Current Behavior | Recommended |
| --- | --- | --- |
| API error | Red banner with HTTP code | "Something went wrong. [Retry] [Rephrase suggestion]" |
| 0 results | Answer says "no data found" in prose | Structured: "No matching records found. Possible reasons: [provider name spelling] [data not yet loaded] [question outside coverage]." + [Try these providers] |
| Unsupported question | LLM improvises | Explicit: "This question is outside current coverage. Supported topics: [links]. [Rephrase] [Report as gap]" |
| Timeout | "Client timeout after Xs" | "This query is taking longer than expected. [Wait] [Cancel] [Simplify question]" |
| Provider not found | 0-row answer treated as fact | "Could not resolve provider 'X'. Did you mean: [fuzzy matches]?" |

---

## 4. Structured Feedback System

### 4.1 Feedback Schema (Replaces Thumbs Up/Down)

```typescript
interface StructuredFeedback {
  session_id: string;
  query_id: string;           // message index or UUID
  timestamp: string;
  evaluator_role: 'business_user' | 'contract_expert' | 'data_owner' | 'technical';
  
  // Correctness
  accuracy_rating: 'correct' | 'partially_correct' | 'incorrect' | 'unable_to_judge';
  
  // Error categories (multi-select when accuracy != 'correct')
  error_categories: (
    | 'wrong_provider'
    | 'wrong_contract'
    | 'wrong_date_period'
    | 'wrong_aggregation'
    | 'wrong_rate_value'
    | 'wrong_clause_status'
    | 'missing_data'
    | 'citation_issue'
    | 'unclear_explanation'
    | 'outdated_information'
    | 'hallucinated_fact'
  )[];
  
  // Confidence assessment
  confidence_appropriateness: 'too_high' | 'appropriate' | 'too_low' | null;
  
  // Corrections
  expected_answer: string;    // what should the answer be
  comment: string;            // free-form
  
  // Question difficulty (evaluator's judgment)
  question_difficulty: 'trivial' | 'moderate' | 'complex' | 'expert' | null;
  
  // Task completion
  task_completed: boolean;    // did user get what they needed
  would_trust_for_decision: boolean;  // would use this in actual work
}
```

### 4.2 Feedback UI Flow

**Step 1** (inline, always visible): `Was this answer: [✓ Correct] [~ Partial] [✗ Incorrect] [? Unsure]`

**Step 2** (expands on Partial/Incorrect):
- Multi-select error categories (checkboxes)
- Confidence assessment radio (Too high / Appropriate / Too low)
- Expected answer textarea (optional)
- Comment textarea (optional)

**Step 3** (optional, dismissible): Task success question: "Did this answer what you needed? [Yes] [No, I need more] [No, wrong topic]"

---

## 5. Evaluation Scorecards (4 User Roles)

### 5.1 Business User Scorecard

| Dimension | Metric | Measurement | Scale |
| --- | --- | --- | --- |
| Task Success | % of questions that got a usable answer | feedback.task_completed / total_queries | 0–100% |
| Correctness | % rated correct or partially correct | (correct + partial) / rated_total | 0–100% |
| Trust | % where user would trust for decision | feedback.would_trust / rated_total | 0–100% |
| Confidence Usefulness | % where confidence rated "appropriate" | appropriate / (appropriate + too_high + too_low) | 0–100% |
| Citation Usefulness | Avg citations clicked / citations shown | click_events / citation_count | 0.0–1.0 |
| Time Saved | Self-reported time saved vs. manual lookup | Questionnaire Likert (1–5) | 1–5 |
| Ease of Use | Task completion without help/confusion | Questionnaire Likert (1–5) | 1–5 |
| Question Difficulty | Distribution of question difficulty ratings | histogram | Distribution |
| Future Use Intent | "Would you use this weekly?" | Questionnaire binary | Yes/No |
| Net Value | NPS or value score | Questionnaire (0–10) | 0–10 |

### 5.2 Contract Expert Scorecard

| Dimension | Metric | Measurement | Scale |
| --- | --- | --- | --- |
| Factual Accuracy | % of claims verified correct by expert | expert_review / total_claims | 0–100% |
| Data Completeness | % of expected data included in answer | expert-identified gaps / expected_items | 0–100% |
| Citation Accuracy | % of citations pointing to correct source | expert-verified citations / total | 0–100% |
| Temporal Correctness | % of answers using current (not stale) data | correct_temporal / temporal_questions | 0–100% |
| Amendment Awareness | Correct identification of latest amendment | correct_amendment / amendment_questions | 0–100% |
| Edge Case Handling | Performance on known difficult questions | edge_correct / edge_total | 0–100% |
| Confidence Calibration | Expert agrees with displayed confidence | agreement / rated | 0–100% |
| Missing Nuance | Cases where important caveats omitted | expert_flagged_nuance / total | Rate |

### 5.3 Data Owner Scorecard

| Dimension | Metric | Measurement | Scale |
| --- | --- | --- | --- |
| SQL Accuracy | Generated SQL returns correct result set | gold_match / total_sql_queries | 0–100% |
| Join Correctness | Approved keys used in all joins | correct_joins / total_joins | 0–100% |
| Filter Completeness | Required WHERE clauses present | correct_filters / required_filters | 0–100% |
| Table Selection | Correct tables chosen for question type | correct_tables / total_queries | 0–100% |
| Grain Correctness | COUNT(DISTINCT) used where needed | correct_grain / grain_questions | 0–100% |
| Data Coverage | All relevant tables utilized | tables_used / tables_available | 0–100% |
| Schema Adherence | No phantom columns or deprecated fields | valid_columns / referenced_columns | 0–100% |
| Performance | Query execution time acceptable | queries_under_30s / total | 0–100% |

### 5.4 Technical Evaluator Scorecard

| Dimension | Metric | Measurement | Scale |
| --- | --- | --- | --- |
| Latency P50/P95 | Response time distribution | timer metrics | Seconds |
| Error Rate | % of queries returning errors | error_count / total | 0–100% |
| Cost Efficiency | Average cost per query | total_cost / total_queries | USD |
| Routing Accuracy | Correct tool selected for question type | correct_route / total | 0–100% |
| Stability | Same answer on repeat (cosine >0.90) | consistent / repeat_tests | 0–100% |
| Timeout Rate | Queries exceeding 120s | timeouts / total | 0–100% |
| Circuit Breaker Events | Breaker trips during evaluation | count | Integer |
| Streaming Fidelity | SSE events delivered completely | complete_streams / total | 0–100% |

---

## 6. Guided Evaluation Task Script

### 6.1 Evaluation Protocol

**Duration**: 90 minutes per evaluator  
**Preparation**: 5-minute onboarding video + coverage guide  
**Tasks**: 15 structured tasks across 5 difficulty tiers  
**Post-tasks**: 10-minute questionnaire  

### 6.2 Task Set (15 Tasks, Stratified)

#### Tier 1: Simple Lookup (3 tasks, ~2 min each)

| Task | Question | Expected Answer Source | Validates |
| --- | --- | --- | --- |
| T-01 | "What are Sharp HealthCare's current inpatient per diem rates?" | rate_query tool → direct lookup | Rate lookup, provider resolution |
| T-02 | "Does Sutter Health have an auto-renewal clause?" | clause lookup → profile flag | Clause existence, binary answer |
| T-03 | "How many active providers are in the system?" | sql_query → COUNT(*) WHERE is_active | Aggregation, system-wide |

#### Tier 2: Moderate Complexity (4 tasks, ~4 min each)

| Task | Question | Expected Answer Source | Validates |
| --- | --- | --- | --- |
| T-04 | "Who is responsible for pharmacy services for Scripps?" | DOFR matrix → boolean columns | DOFR routing, table selection |
| T-05 | "What functions are delegated to Dignity Health?" | delegation_matrix → IPA delegation | Delegation status, multi-row |
| T-06 | "Show me Kaiser's amendment history" | hierarchy + documents + rates | Temporal ordering, amendment_order_int |
| T-07 | "Which providers have offset clauses and auto-renewal?" | clauses table + profile flags | Multi-concept, provider count |

#### Tier 3: Complex Analysis (4 tasks, ~6 min each)

| Task | Question | Expected Answer Source | Validates |
| --- | --- | --- | --- |
| T-08 | "Compare Sharp and Kaiser emergency room rates" | rate_query (comparison type) | Rate comparison, unit normalization |
| T-09 | "What are the top 5 providers by total rate line count?" | sql_query → aggregation | Top-N, grain correctness |
| T-10 | "Which providers have contracts expiring in the next 90 days?" | deadlines + documents | Temporal filtering, date arithmetic |
| T-11 | "Show all critical alerts for providers in the Dignity Health system" | alerts + system membership | System expansion, join correctness |

#### Tier 4: Expert/Edge Cases (3 tasks, ~5 min each)

| Task | Question | Expected Answer Source | Validates |
| --- | --- | --- | --- |
| T-12 | "What is Scripps' capitation rate for behavioral health?" | rate_query → possible 0 rows | Empty result handling, no-data messaging |
| T-13 | "Has Sharp's inpatient rate changed from the previous amendment?" | rate_query (amendment_comparison) | Amendment ordering, string vs int |
| T-14 | "Which providers are NOT in any health system?" | provider_system_membership LEFT JOIN | Negative query, NULL handling |

#### Tier 5: Multi-Turn / Ambiguity (1 task, ~8 min)

| Task | Question Sequence | Validates |
| --- | --- | --- |
| T-15 | 1. "Tell me about Kaiser's contract" → 2. "What about their rates?" → 3. "Compare to last year" | Session continuity, context carry, temporal |

### 6.3 Per-Task Evaluation Form

After each task, evaluator completes:

```
Task T-XX Assessment:
1. Did the system answer your question?        [Yes] [Partially] [No]
2. Is the answer factually correct?            [Correct] [Partial] [Incorrect] [Can't tell]
3. Was the confidence level appropriate?       [Too high] [Right] [Too low]
4. Were citations helpful?                     [Very] [Somewhat] [Not at all] [None shown]
5. How long would this take manually?          [<1 min] [1-5 min] [5-15 min] [15+ min] [Impossible]
6. Would you trust this for a business decision? [Yes] [With verification] [No]
7. Any issues? (check all that apply):
   [ ] Wrong provider  [ ] Wrong rate  [ ] Wrong date  [ ] Missing data
   [ ] Citation wrong  [ ] Unclear     [ ] Too verbose [ ] Too brief
8. Expected answer (if incorrect): [___________]
9. Comments: [___________]
```

---

## 7. Post-Evaluation Questionnaire

### Section A: Overall Experience (All Roles)

| Q# | Question | Scale |
| --- | --- | --- |
| A1 | How easy was it to understand what questions the system supports? | 1–5 (Very difficult → Very easy) |
| A2 | How easy was it to formulate effective questions? | 1–5 |
| A3 | How useful were the example questions / guidance? | 1–5 |
| A4 | How clearly did the system communicate when it couldn't answer? | 1–5 |
| A5 | How trustworthy did the confidence indicators feel? | 1–5 |
| A6 | How useful were the source citations? | 1–5 |
| A7 | How much time would this save you per week if used in your role? | [0] [<30 min] [30-60 min] [1-2 hr] [2+ hr] |
| A8 | Would you use this tool weekly in your current work? | [Definitely] [Probably] [Uncertain] [Probably not] [Definitely not] |
| A9 | Net Promoter: How likely to recommend to a colleague? | 0–10 |
| A10 | What is the most valuable thing this tool did during the evaluation? | Free text |
| A11 | What is the biggest gap or frustration you experienced? | Free text |
| A12 | What single improvement would most increase your trust? | Free text |

### Section B: Role-Specific Questions

**Business Users (B-BU)**:
- B-BU1: Did the system answer questions you would normally ask a colleague? [Yes/Partly/No]
- B-BU2: Were there questions you wanted to ask but couldn't figure out how? [Yes → describe]
- B-BU3: How does answer quality compare to asking a contract analyst? [Better/Same/Worse/N/A]

**Contract Experts (B-CE)**:
- B-CE1: What percentage of answers did you find factually accurate? [0-100%]
- B-CE2: Were any answers dangerously wrong (could lead to bad decisions)? [Yes → describe]
- B-CE3: Did the system ever miss critical nuance that would matter in practice? [Yes → describe]

**Data Owners (B-DO)**:
- B-DO1: Were generated SQL queries using correct tables and joins? [Always/Usually/Sometimes/Rarely]
- B-DO2: Did you spot any data quality issues surfaced by the system? [Yes → describe]
- B-DO3: Are there tables/data the system should use but doesn't? [Yes → describe]

**Technical Evaluators (B-TE)**:
- B-TE1: Was response latency acceptable for interactive use? [Yes/Borderline/No]
- B-TE2: Did you observe any system instability or errors? [Yes → describe]
- B-TE3: Is the streaming/progress feedback sufficient? [Yes/Needs improvement → describe]

---

## 8. Usage Analytics Instrumentation

### 8.1 Client-Side Events (New)

| Event | Payload | Purpose |
| --- | --- | --- |
| `page_view` | route, timestamp, evaluator_id | Navigation patterns |
| `question_submitted` | question_length, has_provider, session_turn | Question complexity |
| `answer_received` | latency_ms, confidence, citation_count, answer_length | Response quality |
| `citation_clicked` | citation_index, source_filename, page | Citation engagement |
| `feedback_submitted` | accuracy_rating, error_categories, confidence_appropriateness | Structured feedback |
| `example_clicked` | example_text, category | Onboarding engagement |
| `session_exported` | format, message_count | Export usage |
| `clarification_shown` | type (no_result / unsupported / error) | Error UX engagement |
| `evidence_panel_toggled` | expanded/collapsed, time_on_panel | Trust engagement |
| `task_timer` | task_id, start_time, end_time, duration_s | Task completion time |

### 8.2 Server-Side Metrics (Existing + New)

| Metric | Source | Status |
| --- | --- | --- |
| Query count, latency, cost | `tbl_agent_sessions` | EXISTS |
| Confidence distribution | `tbl_agent_sessions` | EXISTS |
| Tool usage frequency | `tbl_agent_sessions.tool_calls` | EXISTS |
| Route distribution | NEW: log route decisions | NEEDED |
| Hard failure rate | NEW: log HF-01 through HF-10 triggers | NEEDED |
| Empty result rate | NEW: log 0-row queries | NEEDED |
| Provider resolution failures | NEW: log unresolved names | NEEDED |
| Structured feedback aggregates | NEW: from structured feedback | NEEDED |

---

## 9. Evaluation Metrics & Success Criteria

### 9.1 Minimum Viable Thresholds for Controlled Group Approval

| Metric | Minimum | Target | Measurement |
| --- | --- | --- | --- |
| Task completion rate | ≥70% | ≥85% | T-01 through T-15 |
| Factual accuracy (expert-rated) | ≥75% | ≥90% | Contract expert review |
| Confidence calibration (ECE) | <0.20 | <0.10 | Expert agreement with displayed band |
| User trust score | ≥3.5/5 | ≥4.0/5 | Questionnaire A5 |
| Time-saved perception | ≥3.0/5 | ≥4.0/5 | Questionnaire A7 |
| Future use intent | ≥60% "Definitely/Probably" | ≥80% | Questionnaire A8 |
| NPS | ≥30 | ≥50 | Questionnaire A9 |
| Structured feedback: "incorrect" rate | <20% | <10% | Feedback accuracy_rating |
| Citation click rate | ≥0.20 | ≥0.40 | Analytics |
| Error rate | <10% | <5% | API errors / total queries |

### 9.2 Go/No-Go Decision Matrix

| Outcome | Criteria | Action |
| --- | --- | --- |
| GO (expand to full group) | All minimums met, ≥50% targets met | Proceed to broader rollout |
| CONDITIONAL GO | All minimums met, <50% targets met | Proceed with documented gaps + improvement plan |
| HOLD | 1–2 minimums not met | Fix issues, re-run with same evaluators (2 weeks) |
| NO-GO | 3+ minimums not met OR accuracy <70% | Major rework required before re-evaluation |

---

## 10. Frontend Change List (Priority-Ordered)

| Priority | Change | Effort | Addresses |
| --- | --- | --- | --- |
| P1 | Onboarding modal (purpose, coverage, examples) | 8h | UX-01, UX-02 |
| P1 | Structured feedback component (replaces thumbs) | 12h | UX-06, UX-07 |
| P1 | Evidence summary panel (sources, rows, method, limitations) | 16h | UX-04 |
| P1 | Client-side analytics instrumentation | 8h | UX-15 |
| P2 | Example questions on empty chat state (categorized) | 4h | UX-02 |
| P2 | Error/no-result/unsupported state redesign | 8h | UX-09, UX-10 |
| P2 | Confidence component breakdown (bar chart) | 8h | UX-05 |
| P2 | Provider name autocomplete/suggestion | 8h | UX-03 |
| P3 | Post-task evaluation form (inline modal) | 8h | UX-08 |
| P3 | Post-session questionnaire (end of evaluation) | 6h | UX-08 |
| P3 | Long-answer collapse/expand with TOC | 4h | UX-11 |
| P3 | Session search/filter | 4h | UX-13 |
| **Total** | | **94h** | |

---

## 11. API Changes Required

| Endpoint | Change | Purpose |
| --- | --- | --- |
| `POST /api/v1/feedback` | Accept StructuredFeedback schema (backward-compatible superset) | Rich evaluation data |
| `POST /api/v1/query` (response) | Add `evidence_summary` object: {tables, row_count, method, limitations[]} | Evidence panel |
| `POST /api/v1/query` (response) | Add `confidence_components` object: {data_quality, query_quality, evidence_quality} | Component display |
| `GET /api/v1/examples` | New endpoint returning categorized example questions | Onboarding panel |
| `POST /api/v1/events` | New endpoint for client analytics events | Usage tracking |
| `GET /api/v1/providers/suggest?q=` | New endpoint for provider name autocomplete | Input assistance |

---

## 12. Risks & Mitigations

| Risk | Impact | Mitigation |
| --- | --- | --- |
| Evaluators give superficial feedback | Low data quality | Per-task forms with required fields; compensate time |
| Sample too small for stats | Wide confidence intervals | Minimum 8 evaluators (2 per role) × 15 tasks = 120 data points |
| Hawthorne effect | Evaluators behave differently than real users | Include "free exploration" period (15 min) alongside structured tasks |
| Evaluation fatigue | Later tasks get less attention | Randomize task order per evaluator; limit to 90 min |
| Technical issues during evaluation | Lost data, frustration | Run system health check before each session; have fallback recording |
| Confidence not yet implemented | Can't evaluate Report 7 framework | Evaluate current opaque confidence; note as gap |

---

## 13. Updated Issue Ledger

| ID | Severity | Report | Category | Classification | Title |
| --- | --- | --- | --- | --- | --- |
| F-048 | HIGH | R8 | UX | Design gap | No onboarding or coverage explanation for new users |
| F-049 | HIGH | R8 | UX | Design gap | Feedback limited to thumbs up/down (no error categories) |
| F-050 | HIGH | R8 | UX | Design gap | No evidence panel (users cannot assess answer basis) |
| F-051 | HIGH | R8 | UX | Design gap | No client-side evaluation analytics |
| F-052 | MEDIUM | R8 | UX | Design gap | No example questions or supported-category guide |
| F-053 | MEDIUM | R8 | UX | Design gap | No provider name autocomplete (typo = 0 results) |
| F-054 | MEDIUM | R8 | UX | Design gap | Error/no-result states not distinguished or actionable |
| F-055 | MEDIUM | R8 | UX | Missing feature | API correction field exists but not exposed in UI |
| F-056 | LOW | R8 | UX | Design gap | No long-answer collapse or table of contents |
| F-057 | LOW | R8 | UX | Design gap | No session search or filter |

**Running totals (Reports 1–8):** 3 CRITICAL, 14 HIGH, 20 MEDIUM, 20 LOW = **57 total findings**.

---

## 14. Implementation Sequence for Controlled Evaluation

### Phase 0: Pre-Evaluation (1 week)
1. Deploy onboarding modal + example questions (P1 items)
2. Deploy structured feedback component (P1)
3. Instrument client analytics (P1)
4. Prepare task scripts + evaluation forms (digital)
5. Recruit evaluators: 2 business users, 2 contract experts, 2 data owners, 2 technical

### Phase 1: Controlled Evaluation (2 weeks)
- Week 1: Guided task sessions (90 min each, scheduled)
- Week 2: Free exploration (evaluators use tool in real work, log questions)
- Continuous: Structured feedback collected per-answer
- End of Week 2: Post-evaluation questionnaire

### Phase 2: Analysis (1 week)
- Compute scorecards per role
- Wilson CIs on accuracy/completion rates
- Inter-rater agreement (Cohen's κ) between expert reviewers
- Calibration analysis (confidence band vs. expert accuracy rating)
- Go/No-Go decision per §9.2

---

*End of Report 8*