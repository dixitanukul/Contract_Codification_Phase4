# Contract Intelligence V4 — Evidence & Citation Traceability Audit

**Report**: 6 of N  
**Date**: 2026-07-26  
**Author**: Genie Code (automated audit assistant)  
**Status**: COMPLETE  
**Prerequisite**: Reports 1–5

---

## 1. Executive Summary

Answer traceability has significant structural gaps. Citations are **passage-only** — SQL-derived answers (rate_query, sql_query, provider_deep_dive) produce numeric/factual claims with **zero citations** in the response payload. The hallucination guard's SQL bypass (F-011/Report 3) explicitly allows uncited SQL answers through, meaning the most common answer path (structured data) has no reproducible evidence chain in the API response.

**Most critical finding (F-034 CRITICAL)**: Session persistence truncates answers to 2,000 characters and stores **zero citation data**. Exported sessions (markdown/CSV) contain no citations at all. The JSON export includes a `citations` field but it reads from the persisted turn which is always `[]`. Evidence is **irrecoverably lost** after the HTTP response is returned.

---

## 2. Evidence Architecture

### 2.1 Evidence Sources (by tool)

| Tool | Evidence Type | Citation Generated? | Reproducible? |
| --- | --- | --- | --- |
| passage_search | VS retrieved passages | YES (passage text + source_filename + page) | Yes (re-run VS query) |
| citation_verify | LLM verification of passage claims | YES (VERIFIED/SUPERSEDED/HALLUCINATED) | No (LLM-dependent) |
| sql_query | SQL result rows (structured) | NO | Yes (re-run SQL) |
| rate_query | Rate data from templates | NO | Yes (re-run template) |
| provider_deep_dive | Profile + rate summary | NO | Yes (re-run queries) |
| clause_existence | Clause status from profile/clauses table | NO | Yes (re-run query) |
| provider_lookup | Provider resolution | NO | Yes |
| genie_query | Genie Space response | NO | Partial (Genie state) |

**Critical gap**: 6 of 8 primary evidence tools produce **no citations**. Only passage_search and citation_verify generate Citation objects.

### 2.2 Citation Data Model

```python
@dataclass
class Citation:
    source_doc_id: str          # tbl_contract_documents_master.document_id
    provider_name: str
    passage_text: str           # Full retrieved passage (200-2000 chars)
    page_number: int | None
    clause_type: str
    effective_date: str | None
    is_current_effective: bool
    doc_role: str               # base_agreement | amendment
    amendment_order: int | None
    confidence: float           # 0-1
    retrieval_score: float      # VS similarity score
    source_filename: str        # PDF filename
    contract_id: str
    pdf_path: str               # Volume path to PDF
    document_type: str
    provider_id: str
```

**Strengths**: Rich provenance (filename, page, amendment_order, provider_id, effective_date).  
**Weakness**: Only attached to passage-search results. SQL-derived data has no equivalent.

### 2.3 Answer Synthesis Pipeline

```
Tool calls → ToolResult objects (each has .data, .citations, .confidence)
    ↓
ReAct loop SYNTHESIZE → LLM generates answer from tool results
    ↓
_build_response():
  1. Collect all citations from all ToolResults
  2. Filter by provider_hint (bidirectional match)
  3. Deduplicate by (source_filename, page_number)
  4. Run HallucinationGuard (7 checks, zero-LLM-cost)
  5. Compute confidence (worst-of-tools, with P5-CONF upgrade)
  6. SQL bypass: if all evidence from SQL tools, skip guard blocks
  7. Sanitize answer text
  8. Return AgentResponse
    ↓
REST API → JSON response to frontend
    ↓
_persist_turn(): Save to tbl_agent_sessions
  - answer[:2000], question[:1000], confidence, citation_count (int only)
  - NO citation text/details persisted
  - NO tool result data persisted
  - NO SQL queries persisted
```

---

## 3. Hallucination Guard Analysis

### 3.1 Seven Checks (zero LLM cost)

| # | Check | Severity | Catches | Misses |
| --- | --- | --- | --- | --- |
| 1 | Confidence floor | WARN | No citations + no SQL data | SQL answers always bypass |
| 2 | Numeric grounding | WARN | Numbers >4 digits not in source data | Small numbers (e.g., count=47) pass unchecked |
| 3 | Provider name grounding | BLOCK | Provider names not in resolved context | Regex-based, misses many patterns |
| 4 | Date plausibility | WARN | Years outside 2000-2035 | Doesn't validate date accuracy |
| 5 | Non-BSC provider blocklist | BLOCK | Kaiser, Aetna, UnitedHealth in answers | Limited to 14 hardcoded names |
| 6 | Universality claim | WARN | "All N providers have X" without SQL proof | Only fires on specific patterns |
| 7 | Same-provider cross-dimensional | WARN | "Same provider tops both X and Y" | Only fires on multi-hop ranking |

### 3.2 SQL Bypass (F-011 from Report 3)

When ALL evidence comes from SQL tools (`sql_query`, `rate_query`, `provider_deep_dive`, `provider_lookup`, `clause_existence`), the guard's `has_blocks` flag is **ignored** and confidence can still be upgraded to HIGH.

**Rationale** (per code comment): "SQL-derived answers are structurally grounded and should not be penalised by a passage-origin guard."

**Risk**: A hallucinated LLM synthesis of SQL data (e.g., misinterpreting COUNT(*) as provider count, or inventing a rate value) bypasses the only safety check. The guard was designed for passage-search answers and offers **no protection** for the most common answer path.

---

## 4. What Is NOT Validated

| Check | Status | Risk |
| --- | --- | --- |
| Numeric values match SQL results | NOT CHECKED (guard only checks >4-digit numbers against passage text) | LLM can misquote rate amounts |
| Count grain correctness | NOT CHECKED | "498 providers" from COUNT(*) passes |
| Rate unit accuracy | NOT CHECKED | LLM can say "$1,500 per day" when data says "per case" |
| Temporal accuracy | NOT CHECKED | LLM can present superseded rate as current |
| Provider-rate attribution | NOT CHECKED | LLM can attribute Provider A's rate to Provider B |
| Comparison fairness | NOT CHECKED | Comparing different rate_units passes |
| Clause negation preservation | NOT CHECKED | "Does NOT have offset" can become "has offset" in synthesis |
| Citation-to-claim alignment | NOT CHECKED | Citations may not support the specific claim |

---

## 5. Evidence Lost in Pipeline

### 5.1 Persistence Loss (F-034 CRITICAL)

| Field | In API Response | Persisted to Session | In Export |
| --- | --- | --- | --- |
| answer (full) | YES | TRUNCATED to 2000 chars | Truncated |
| citations (list) | YES (full objects) | citation_count (int only) | JSON: empty []; MD/CSV: absent |
| tool_calls | YES (names) | YES (names, max 20) | Absent |
| steps (full trace) | YES | step_count (int only) | Absent |
| SQL queries executed | In ToolResult.metadata | NOT persisted | Absent |
| confidence | YES | YES | MD only |
| warnings/guard | YES | NOT persisted | Absent |
| resolved_entities | In metadata | YES (JSON string) | Absent |

**Impact**: After the initial HTTP response, there is **no way to reproduce** or audit what evidence supported an answer. Session history cannot be audited for correctness.

### 5.2 Frontend Evidence Gaps

The frontend (`ChatPageV2`) receives citations in the JSON response and renders them as source links. However:
- SQL-derived answers have 0 citations → no source links shown
- Rate answers from `rate_query` show no source document
- Only passage_search answers have clickable document references
- No SQL query trace is exposed to users

---

## 6. Claim-Evidence Payload Design

### 6.1 Proposed Claim Structure

```json
{
  "claim_id": "CLM-001",
  "claim_text": "Sharp Memorial has an inpatient per diem rate of $2,450",
  "claim_type": "NUMERIC_RATE",
  "evidence": {
    "source_type": "SQL_RESULT",
    "source_tool": "rate_query",
    "source_query": "SELECT rate_numeric FROM ... WHERE ...",
    "source_table": "dev_adb.raw.tbl_contract_rates_all",
    "source_row": {
      "provider_name": "Sharp Memorial Hospital",
      "rate_category": "inpatient_per_diem",
      "rate_numeric": 2450.0,
      "rate_unit": "PER_DAY",
      "status": "current",
      "effective_date_parsed": "2024-03-01"
    },
    "retrieval_id": "tool_call_003",
    "is_current": true,
    "calculation_method": "DIRECT_LOOKUP",
    "evidence_completeness": "COMPLETE",
    "contradiction_status": "NONE",
    "grain_verified": true
  },
  "confidence_components": {
    "data_freshness": "HIGH",
    "provider_resolution": "HIGH",
    "grain_correctness": "HIGH",
    "value_reproducibility": "HIGH",
    "overall": "HIGH"
  }
}
```

### 6.2 Claim Types and Minimum Evidence

| Claim Type | Minimum Evidence Required |
| --- | --- |
| NUMERIC_RATE | Source table + row with exact rate_numeric + rate_unit + status + provider |
| PERCENTAGE | Formula/calculation + source values + denominator verification |
| COUNT | Source table + exact SQL with DISTINCT verification + grain statement |
| PROVIDER_STATUS | Profile table row + field name + value |
| DATE/TEMPORAL | Source field + effective_date + currentness check |
| CLAUSE_EXISTENCE | Profile flag OR clause table row + clause_status |
| CLAUSE_ABSENCE | Profile flag = 'NO_MENTION' OR zero-row result from clause table |
| COMPARISON | Both compared values from same grain + unit + temporal scope |
| HISTORICAL | Explicit status='superseded' or amendment_order + effective_date |
| INTERPRETATION | Source passage text + page + retrieval_score |
| RECOMMENDATION | Clearly labelled as inference (not fact) |
| NO_ANSWER | Distinguish: data unavailable vs. system error vs. out-of-scope |

---

## 7. Grounding Defects Register

| ID | Severity | Classification | Title | Impact |
| --- | --- | --- | --- | --- |
| F-034 | CRITICAL | Evidence loss | Session persistence stores 0 citation data | Answers cannot be audited after response |
| F-035 | HIGH | Ungrounded claims | SQL-derived answers have no citation objects | Frontend shows no source links for most answers |
| F-036 | HIGH | Bypass | SQL bypass allows guard-blocked answers through | Hallucinated SQL synthesis unchecked |
| F-037 | MEDIUM | Truncation | Answer truncated to 2000 chars in persistence | Long answers lose evidence text |
| F-038 | MEDIUM | Missing trace | No SQL query text persisted | Cannot reproduce answer logic |
| F-039 | MEDIUM | Export gap | Markdown/CSV exports have zero citations | Exported sessions not auditable |
| F-040 | MEDIUM | Guard gap | Numeric guard only checks >4-digit numbers | Small counts/percentages unchecked |
| F-041 | LOW | Citation quality | Citation passage_text is preview only (200 chars in to_dict) | Insufficient for verification |
| F-042 | LOW | Confidence opacity | Single confidence string, no component breakdown | Cannot identify WHY confidence is low |

---

## 8. Semantic Evidence Validator Design

### 8.1 Mandatory Checks (Post-Synthesis, Pre-Response)

```python
class EvidenceValidator:
    """Validates that every factual claim in the answer is evidenced."""
    
    def validate(self, answer: str, tool_results: list[ToolResult], 
                 citations: list[dict]) -> ValidationResult:
        claims = self._extract_claims(answer)  # NLP claim extraction
        
        for claim in claims:
            # Rule 1: Numeric claims must reproduce
            if claim.type == 'NUMERIC':
                assert claim.value in self._all_numeric_values(tool_results)
            
            # Rule 2: Provider names must be in resolved context
            if claim.mentions_provider:
                assert claim.provider in self._resolved_providers(tool_results)
            
            # Rule 3: Counts must preserve grain
            if claim.type == 'COUNT':
                assert self._verify_count_grain(claim, tool_results)
            
            # Rule 4: Current/historical must match evidence
            if claim.temporal_assertion:
                assert self._verify_temporal(claim, tool_results)
            
            # Rule 5: Comparisons must use same grain/unit
            if claim.type == 'COMPARISON':
                assert self._verify_comparable(claim, tool_results)
            
            # Rule 6: Clause negation preserved
            if claim.type == 'CLAUSE_ABSENCE':
                assert self._verify_absence_evidence(claim, tool_results)
            
            # Rule 7: Citations identify specific sources
            if claim.requires_passage_evidence:
                assert any(self._citation_supports(c, claim) for c in citations)
            
            # Rule 8: Contradictions disclosed
            contradictions = self._find_contradictions(claim, tool_results)
            if contradictions:
                assert claim.discloses_contradiction
            
            # Rule 9: Truncation/limits disclosed
            if self._was_truncated(claim, tool_results):
                assert claim.discloses_limit
            
            # Rule 10: Unsupported claims labelled
            if not self._has_any_evidence(claim, tool_results, citations):
                claim.mark_unsupported()  # or remove from answer
```

### 8.2 Implementation Phases

| Phase | Scope | Effort | Impact |
| --- | --- | --- | --- |
| Phase 1 | Persist citation objects (not just count) to sessions | 4 hours | Fixes F-034 |
| Phase 2 | Generate SQL-evidence citations (tool, query, result hash) | 8 hours | Fixes F-035 |
| Phase 3 | Numeric reproduction check (answer numbers ∈ result data) | 4 hours | Catches misquoted rates |
| Phase 4 | Count grain validator (DISTINCT check for provider counts) | 4 hours | Catches F-027 |
| Phase 5 | Export with full citations | 4 hours | Fixes F-039 |
| Phase 6 | Full claim-evidence payload in response | 16 hours | Production readiness |

---

## 9. Citation Tests (for test suite)

| Test ID | Category | Assertion |
| --- | --- | --- |
| CIT-01 | Passage citation present | passage_search answer has ≥1 citation with source_filename |
| CIT-02 | SQL answer has evidence | sql_query answer has tool_result.data rows |
| CIT-03 | Rate value traceable | Rate in answer appears in tool_result.data.rate_numeric |
| CIT-04 | Provider name grounded | Provider in answer is in resolved_entities or tool_result |
| CIT-05 | Count reproducible | Count in answer matches COUNT query result |
| CIT-06 | Date in evidence | Date in answer appears in tool_result effective_date |
| CIT-07 | Clause status accurate | "HAS" or "NO_MENTION" matches profile query result |
| CIT-08 | No empty-result answer | 0-row result → refusal, not fabricated answer |
| CIT-09 | Comparison uses same unit | Compared rates have same rate_unit |
| CIT-10 | Historical labelled | Superseded data explicitly noted as historical |
| CIT-11 | Citation page exists | Citation page_number is not null for passage answers |
| CIT-12 | Confidence components | Confidence reflects worst evidence quality |

---

## 10. Updated Cumulative Issue Ledger

| ID | Severity | Report | Title |
| --- | --- | --- | --- |
| F-034 | CRITICAL | R6 | Session persistence stores 0 citation data |
| F-035 | HIGH | R6 | SQL-derived answers have no citation objects |
| F-036 | HIGH | R6 | SQL bypass allows guard-blocked answers through |
| F-037 | MEDIUM | R6 | Answer truncated to 2000 chars in persistence |
| F-038 | MEDIUM | R6 | No SQL query text persisted |
| F-039 | MEDIUM | R6 | Markdown/CSV exports have zero citations |
| F-040 | MEDIUM | R6 | Numeric guard only checks >4-digit numbers |
| F-041 | LOW | R6 | Citation passage_text preview only (200 chars) |
| F-042 | LOW | R6 | Confidence is single opaque string, no components |

**Running totals (Reports 1–6):** 3 CRITICAL, 8 HIGH, 14 MEDIUM, 17 LOW = **42 total findings**.

---

*End of Report 6*