# Contract Intelligence V4 — Data Model Audit

**Report**: 4 of N  
**Date**: 2026-07-26  
**Author**: Genie Code (automated audit assistant)  
**Status**: COMPLETE  
**Prerequisite**: Reports 1-3

---

## 1. Executive Summary

This report validates the 31-table production data model against documentation, application code (whitelist, schema context, system prompt), and live data. Three **CRITICAL** contradictions found where the SQL generation context tells the LLM one thing but the data behaves differently — causing silent answer degradation.

**Most critical finding (F-013 CRITICAL)**: The `tbl_dofr_matrix_extracted` table has a **three-way contradiction** between documentation, whitelist, and system prompt regarding `is_current` filtering. The whitelist tells the SQL LLM to filter `is_current=TRUE`, but this returns **ZERO rows** for all major service categories (BEHAVIORAL HEALTH, PHARMACY, EMERGENCY — all 417 rows have `is_current=FALSE`). The system prompt explicitly says "NEVER filter by is_current". Result: LLM-generated SQL for DOFR questions returns empty results when following whitelist instructions.

---

## 2. Table Inventory (Live vs. Documented)

| Table | Doc Rows | Live Rows | Delta | Status |
| --- | --- | --- | --- | --- |
| tbl_contract_rates_all | 459,902 | 459,902 | 0 | MATCH |
| tbl_contract_documents_master | 10,349 | 10,349 | 0 | MATCH |
| tbl_contract_hierarchy | 10,349 | 10,349 | 0 | MATCH |
| tbl_vs_unified_ready | 727,875 | 727,876 | +1 | MATCH (rounding) |
| tbl_dofr_matrix_extracted | 1,821 | 1,821 | 0 | MATCH |
| tbl_delegation_matrix | 770 | 770 | 0 | MATCH |
| tbl_contract_clauses | 7,863 | 7,863 | 0 | MATCH |
| tbl_genie_amendment_timeline | 6,609 | 6,609 | 0 | MATCH |
| tbl_genie_provider_profile | 306 | 306 | 0 | MATCH |
| tbl_compliance_tracking | 2,871 | 2,871 | 0 | MATCH |
| tbl_quality_performance | 894 | 894 | 0 | MATCH |
| tbl_contract_notifications | 1,934 | 1,934 | 0 | MATCH |
| tbl_rate_escalators | 104 | 104 | 0 | MATCH |
| tbl_contract_risk_scores | 272 | 272 | 0 | MATCH |
| tbl_clause_deviations | 7,777 | 7,777 | 0 | MATCH |
| tbl_contract_deadlines | 713 | 713 | 0 | MATCH |
| tbl_alert_queue | 351 | 351 | 0 | MATCH |
| tbl_provider_identifiers | 50,159 | 50,159 | 0 | MATCH |
| tbl_financial_exposure | 172 | 172 | 0 | MATCH |
| tbl_extraction_provenance | 15,368 | 15,368 | 0 | MATCH |
| tbl_repricing_scenarios | 7,600 | 7,600 | 0 | MATCH |
| tbl_reimb_stop_loss | 3,847 | 3,847 | 0 | MATCH |
| tbl_reimb_carve_outs | 17,229 | 17,229 | 0 | MATCH |
| dim_provider_canonical | 531 | 531 | 0 | MATCH |
| dim_health_system | 20 | 20 | 0 | MATCH |
| tbl_provider_system_membership | 112 | 112 | 0 | MATCH |
| dim_table_schema | 468 | 468 | 0 | MATCH |
| tbl_service_areas | 306 | 306 | 0 | MATCH |
| tbl_agent_sessions | 2,229 | 2,594 | +365 | DRIFT (active writes) |
| fact_retrieval_telemetry | 1,300 | 1,587 | +287 | DRIFT (active writes) |
| fact_supersession | 2,380 | 2,380 | 0 | MATCH |

**Observation**: Static tables perfectly match documentation. Runtime-written tables (sessions, telemetry) show expected growth from ongoing app traffic.

---

## 3. Critical Semantic Context Contradictions

### 3.1 F-013 — DOFR is_current Three-Way Contradiction (CRITICAL)

**The contradiction:**

| Source | Instruction | Effect |
| --- | --- | --- |
| `DATA_MODEL_PRODUCTION_STATE.md` §1.5 | "Only 60 of 1,821 rows have is_current=TRUE — always query the full table, do not filter on is_current" | Correct |
| `agent_controller.py` system prompt line 570 | "NEVER filter tbl_dofr_matrix_extracted by is_current" | Correct |
| `table_whitelist.py` line 216-225 | "Use is_current = TRUE for temporal filtering — this is the ONLY correct approach" | **WRONG** |

**Live data proof:**
- Total rows: 1,821 (149 providers)
- `is_current=TRUE`: 60 rows (29 providers)
- `is_current=FALSE`: 1,761 rows (149 providers)
- BEHAVIORAL HEALTH: 136 rows, **0 with is_current=TRUE**
- PHARMACY: 140 rows, **0 with is_current=TRUE**
- EMERGENCY: 141 rows, **0 with is_current=TRUE**

**Impact**: When the `sql_query` tool generates SQL for DOFR questions, it uses the whitelist description (which says `is_current=TRUE`). This returns ZERO rows for all major service categories. The agent_controller system prompt countermands this (says "NEVER filter"), but only the ReAct reasoning loop sees the system prompt — the sql_query tool's own SQL generation sees only the whitelist.

**Resolution path**: The ReAct loop system prompt (line 570) contains a hardcoded override that strips `is_current=TRUE` from generated SQL post-hoc (`sql_query.py` line 484). This means the **actual behavior is correct** — the sql_query tool removes the filter after generation. But the whitelist creates unnecessary LLM confusion and wasted reasoning tokens.

**Classification**: Confirmed semantic ambiguity with correct runtime behavior (sql_query.py post-processing catches it).

---

### 3.2 F-014 — Delegation Matrix is_current Drops 73% of Providers (HIGH)

**The problem:**
- `tbl_delegation_matrix`: 120 providers total, 770 rows
- Rows with `is_current=TRUE`: only 60 rows across 32 providers
- `tbl_genie_provider_profile.ipa_delegation_status='HAS'`: 120 providers

**Whitelist instruction** (line 256): "For current rows only: WHERE is_current = TRUE"

**Impact**: SQL queries following whitelist instructions see only 32/120 IPA providers (27%). Questions like "Which providers delegate claims_processing?" miss 73% of delegated providers.

**Root cause**: The `is_current` flag marks rows from the latest amendment only. Most IPA delegation was established in base agreements (amendment_order=0) and never re-stated in later amendments, so `is_current=FALSE` even though the delegation is still active.

**Classification**: Confirmed schema issue — `is_current` semantics are misleading for this table.

---

### 3.3 F-015 — fact_supersession.provider_id NOT NULL (Documentation Error) (MEDIUM)

**Documentation states** (DATA_MODEL_PRODUCTION_STATE.md §4.3 and ER_DIAGRAM.md line 58):
> "CRITICAL: `provider_id` ALL NULL on all 2,380 rows — never join on `provider_id`"

**Live data**: provider_id is populated on **ALL 2,380 rows** (0 NULLs).

**Impact**: The documentation forces a needlessly complex join path (via filename). Direct `provider_id` joins would work and be simpler. However, since the app currently uses filename-based joins correctly, this doesn't cause wrong answers — it's a documentation maintenance issue.

**Classification**: Confirmed documentation defect.

---

### 3.4 F-016 — Whitelist Rate Status Counts Are Stale (LOW)

**Whitelist says** (table_whitelist.py line 103): `status ('current'=135,485 or 'superseded'=324,417)`

**Live data**: `current=171,763` / `superseded=288,139`

**Root cause**: Whitelist text was written before the P2-J1 re-label on 2026-07-20. The DATA_MODEL_PRODUCTION_STATE.md correctly documents the new counts.

**Impact**: The LLM may reason about rate counts using stale numbers (e.g., "I expect ~135K current rates") but this rarely affects answer quality since the LLM doesn't typically use these counts in its reasoning.

**Classification**: Confirmed documentation defect (stale whitelist text).

---

### 3.5 F-017 — Offset Clause Count Mismatch: Profile vs Clauses Table (MEDIUM)

**Profile**: `offset_clause_status='HAS'` → 47 providers  
**Clauses table**: `clause_category='OFFSET_CLAUSE' AND clause_status='HAS'` → 72 providers

**Gap**: 25 providers have offset clause rows in `tbl_contract_clauses` but are marked `NO_MENTION` in the profile. This means the profile is a **subset** (more conservative) of the clauses table.

**Impact**: Questions routed to the profile ("Does X have offset?") may say "no" when the clauses table says "yes". The system prompt routes offset existence checks to the profile, so these 25 providers get incorrect "no" answers.

**Classification**: Probable data issue — profile was rebuilt with stricter extraction criteria but clauses table retains broader matches.

---

### 3.6 F-018 — dim_table_schema Missing 2 Whitelist Tables (LOW)

`tbl_reimb_stop_loss` and `tbl_reimb_carve_outs` are in the SQL whitelist but **not** in `dim_table_schema`. This means the SchemaContextBuilder falls back to DESCRIBE TABLE for these tables (less rich context, no sample_values or is_filterable hints).

**Impact**: SQL generation for stop-loss and carve-out questions has less context, increasing the chance of generating incorrect column names. Mitigated by the very detailed whitelist descriptions.

**Classification**: Confirmed schema issue (gap in metadata registry).

---

## 4. Entity/Grain Matrix

| Table | Grain | Entity | Natural Key | Technical Key | Providers |
| --- | --- | --- | --- | --- | --- |
| tbl_contract_rates_all | Rate line × document version | Rate | provider_id + source_filename + service_category + rate_text | (composite) | 518 |
| tbl_contract_documents_master | Document version | Document | source_filename | contract_id | 531 |
| tbl_contract_hierarchy | Document in chain | Document chain | source_filename | contract_id | 531 |
| tbl_vs_unified_ready | Text chunk | Passage | chunk_id | chunk_id | ~520 |
| tbl_dofr_matrix_extracted | Service category × provider × version | DOFR entry | provider_id + service_category + source_filename | (composite) | 149 |
| tbl_delegation_matrix | Delegated function × provider × version | Delegation | delegation_id | delegation_id | 120 |
| tbl_contract_clauses | Clause × provider × version | Clause | clause_id | clause_id | 300 |
| tbl_genie_provider_profile | Provider | Provider | provider_id | provider_id | 306 |
| tbl_compliance_tracking | Regulation × provider | Compliance | compliance_id | compliance_id | ~290 |
| tbl_quality_performance | Program × provider | Quality metric | quality_id | quality_id | ~280 |
| tbl_contract_notifications | Notification × provider | Notification | notification_id | notification_id | ~290 |
| tbl_reimb_stop_loss | Stop-loss rule × provider | Stop-loss | stop_loss_id | stop_loss_id | 389 |
| tbl_reimb_carve_outs | Carve-out item × provider × version | Carve-out | (composite) | (composite) | ~300 |
| tbl_contract_risk_scores | Provider | Risk score | provider_id | provider_id | 272 |
| tbl_contract_deadlines | Deadline × provider | Deadline | deadline_id (NOT unique) | (composite) | ~270 |
| tbl_alert_queue | Alert | Alert | alert_id | alert_id | ~180 |
| dim_provider_canonical | Provider identity | Provider | provider_id | provider_id | 531 |
| fact_supersession | Supersession event | Version transition | supersession_id | supersession_id | ~200 |

---

## 5. Approved vs. Dangerous Joins

### 5.1 Approved Joins (100% resolution, documented)

| From | To | Key | Resolution | Notes |
| --- | --- | --- | --- | --- |
| tbl_contract_rates_all | tbl_genie_provider_profile | `canonical_provider_id` = `provider_id` | 100% (0 orphans) | ALWAYS use this for rates→profile |
| tbl_contract_hierarchy | tbl_contract_documents_master | `source_filename` | 100% | |
| tbl_service_areas | tbl_genie_provider_profile | `provider_id` | 100% (1:1) | |
| tbl_alert_queue | tbl_contract_deadlines | `source_deadline_id` = `deadline_id` | 100% | deadline_id is NOT unique |
| tbl_provider_system_membership | dim_health_system | `system_id` | 100% | |
| tbl_extraction_provenance | tbl_genie_provider_profile | `provider_id` | 100% | |

### 5.2 Dangerous Joins (row-multiplying or high orphan rate)

| From | To | Key | Issue | Risk |
| --- | --- | --- | --- | --- |
| tbl_contract_rates_all | tbl_genie_provider_profile | `provider_id` = `provider_id` | 28% orphans (128,896 rows) | Silently drops 28% of rates |
| tbl_contract_deadlines (self) | Any table via `deadline_id` | `deadline_id` not unique (414 distinct / 713 rows) | 1.7x row multiplication | Use DISTINCT |
| tbl_contract_clauses | tbl_genie_provider_profile | `provider_id` | 3,038 orphans (~39%) | Use LEFT JOIN |
| tbl_contract_documents_master | tbl_genie_provider_profile | `provider_id` | 3,086 orphans (~30%) | Use LEFT JOIN |

### 5.3 Join Key Semantics

| Key | Semantics | Unique? | Notes |
| --- | --- | --- | --- |
| `provider_id` | String UUID from source system | Unique in dim_provider_canonical, tbl_genie_provider_profile | NOT unique in fact tables |
| `canonical_provider_id` | Resolved provider ID (maps many source IDs to one canonical) | Present only in tbl_contract_rates_all | Use for rates→profile |
| `source_filename` | PDF filename (unique per document version) | Unique per document row | Safe join key to documents |
| `contract_id` | Surrogate key in tbl_contract_hierarchy | Unique in hierarchy | |
| `deadline_id` | NOT unique in tbl_contract_deadlines | 414 distinct / 713 rows | ALWAYS use DISTINCT |

---

## 6. Temporal / Currentness / Version Rulebook

| Table | Version Field | Current Filter | Meaning of "current" | Risk |
| --- | --- | --- | --- | --- |
| tbl_contract_rates_all | `status` | `WHERE status = 'current'` | Latest version of this rate line (not superseded) | Safe — 171,763 rows |
| tbl_contract_rates_all | `amendment_order_int` | ORDER BY for version history | 0=base, N=Nth amendment | 2,782 NULLs |
| tbl_vs_unified_ready | `is_current` | `WHERE is_current = TRUE` | Latest amendment's chunks only | Safe |
| tbl_dofr_matrix_extracted | `is_current` | **DO NOT FILTER** | Only 60/1,821 rows are TRUE; major categories have 0 | DANGEROUS |
| tbl_delegation_matrix | `is_current` | Use cautiously | Only 32/120 providers have current rows | LOSSY |
| tbl_contract_clauses | `is_current` | `WHERE is_current = TRUE` for latest only | 670 current / 7,193 historical | Safe for latest-only queries |
| tbl_contract_documents_master | `contract_status` | `WHERE contract_status IN ('ACTIVE','ACTIVE_NO_EXPIRY')` | Non-expired documents | 998 active docs |

---

## 7. Rate Rulebook

| Rule | Detail |
| --- | --- |
| Rate units | PER_DAY (217K), PER_VISIT (119K), PMPM (64K), PER_CASE (48K), PER_PROCEDURE (2K), AWP_DISCOUNT (25) |
| Plausibility bounds | PER_DAY: ≤$500K; PER_VISIT: ≤$100K; PMPM: ≤$25K; PER_CASE: ≤$1M; PER_PROCEDURE: ≤$50K |
| Version semantics | `status='current'` = active rate; `status='superseded'` = historical |
| Supersession key | `superseded_by` format: `eff:YYYY-MM-DD\|src:<filename>` — requires REGEXP_EXTRACT for joins |
| Point-in-time query | `WHERE effective_date_parsed <= :date AND (superseded_date > :date OR superseded_date IS NULL)` |
| Provider join | ALWAYS use `canonical_provider_id` (not `provider_id`) to join rates → profile |
| NULL rate_numeric | 8,297 rows (4,819 current + 3,478 superseded) — formula or text-only rates |
| Future rates | 2,187 rows with effective_date > 2026-07-26 (max: 2027-10-15) — valid |

---

## 8. Profiling Results Summary

| Check | Result | Status |
| --- | --- | --- |
| Rate status distribution | current=171,763 / superseded=288,139 | MATCHES doc |
| Provider profile is_active | 194 active / 112 inactive | MATCHES doc |
| Document status distribution | EXPIRED=9,349 / ACTIVE=554 / ACTIVE_NO_EXPIRY=444 / FUTURE=2 | MATCHES doc |
| canonical_provider_id → profile join | 0 orphans | CORRECT |
| provider_id → profile join (rates) | 128,896 orphans (28%) | MATCHES doc (~28%) |
| DOFR is_current=TRUE | 60 rows (29 providers) | MATCHES doc |
| Delegation is_current=TRUE | 60 rows (32 providers of 120 total) | NEW FINDING |
| fact_supersession.provider_id | 2,380/2,380 NOT NULL | CONTRADICTS doc |
| Clause status | HAS=7,849 / FALSE_POSITIVE=14 | MATCHES doc |
| Hierarchy sequential_order NULL | 460 rows | MATCHES doc (459 ± 1) |
| dim_table_schema coverage | 29 tables (missing stop_loss, carve_outs) | NEW FINDING |

---

## 9. Semantic Context Gaps (Unanswerable Questions)

Questions the system cannot reliably answer due to data model limitations:

| Question Type | Why Unanswerable | Data Gap |
| --- | --- | --- |
| "Total contract dollar value for X" | No total-value column; only unit rates | System correctly refuses (pre-flight guard) |
| "Which delegation functions for [73% of IPA providers]?" | `is_current=TRUE` filter drops them | F-014 |
| "DOFR matrix for [any provider]" via sql_query only | Whitelist instructs wrong filter | F-013 (mitigated by post-processing) |
| "What are the benchmark rates?" | tbl_rate_benchmarks is 100% synthetic | Excluded table, but in whitelist |
| "Contact info / phone / email" | Not in data model | System correctly refuses |
| "Real-time changes" | Static extract, no timestamps | System correctly refuses |

---

## 10. Updated Issue Ledger

| ID | Severity | Category | Classification | Title |
| --- | --- | --- | --- | --- |
| F-013 | CRITICAL | CORRECTNESS | Confirmed semantic ambiguity | DOFR is_current three-way contradiction (whitelist vs. prompt vs. doc) |
| F-014 | HIGH | CORRECTNESS | Confirmed schema issue | Delegation is_current=TRUE loses 73% of IPA providers |
| F-015 | MEDIUM | CONSISTENCY | Confirmed documentation defect | fact_supersession.provider_id documented as ALL NULL but is fully populated |
| F-016 | LOW | CONSISTENCY | Confirmed documentation defect | Whitelist rate status counts stale (pre-P2-J1 values) |
| F-017 | MEDIUM | CORRECTNESS | Probable data issue | Offset clause: profile says 47 HAS, clauses table has 72 providers |
| F-018 | LOW | COMPLETENESS | Confirmed schema issue | dim_table_schema missing tbl_reimb_stop_loss and tbl_reimb_carve_outs |
| F-019 | LOW | CONSISTENCY | Confirmed documentation defect | tbl_rate_benchmarks in whitelist but documented as synthetic-only / excluded |
| F-020 | LOW | CORRECTNESS | Confirmed code defect | tbl_provider_identifiers listed TWICE in whitelist (duplicate key) |
| F-021 | LOW | CORRECTNESS | Confirmed code defect | tbl_rate_escalators listed TWICE in whitelist (duplicate key) |
| F-022 | LOW | CORRECTNESS | Confirmed code defect | tbl_service_areas listed TWICE in whitelist (duplicate key) |

---

## 11. Automation-Suitable Profiling Queries

The following queries can be scheduled as regression sentinels:

```sql
-- S-DM-1: Rate status count drift
SELECT status, COUNT(*) as cnt FROM dev_adb.raw.tbl_contract_rates_all GROUP BY status;
-- Threshold: current should be 170K-175K; superseded 285K-290K

-- S-DM-2: DOFR is_current sanity
SELECT is_current, COUNT(*) FROM dev_adb.raw.tbl_dofr_matrix_extracted GROUP BY is_current;
-- Threshold: is_current=TRUE should be < 100 (currently 60)

-- S-DM-3: canonical_provider_id orphan check
SELECT COUNT(*) as orphans FROM dev_adb.raw.tbl_contract_rates_all r
LEFT JOIN dev_adb.raw.tbl_genie_provider_profile p ON r.canonical_provider_id = p.provider_id
WHERE p.provider_id IS NULL;
-- Threshold: MUST be 0

-- S-DM-4: Profile flag consistency
SELECT 
  (SELECT COUNT(*) FROM dev_adb.raw.tbl_genie_provider_profile WHERE ipa_delegation_status='HAS') as profile_ipa,
  (SELECT COUNT(DISTINCT provider_id) FROM dev_adb.raw.tbl_delegation_matrix) as delegation_providers;
-- Threshold: should be equal (both 120)
```

---

*End of Report 4*