# Contract Intelligence V4 — SQL Architecture & Correctness Audit

**Report**: 5 of N  
**Date**: 2026-07-26  
**Author**: Genie Code (automated audit assistant)  
**Status**: COMPLETE  
**Prerequisite**: Reports 1–4

---

## 1. Executive Summary

The application has **two SQL execution paths**: a deterministic template path (`rate_query.py`) and an LLM-generated path (`sql_query.py`). Validation is **security-only** (DDL guard + table whitelist). There is **no semantic validation layer** — no column existence checks, no join correctness enforcement, no grain validation, no required-filter rules. This means SQL that passes validation can still produce **businessly incorrect answers** (wrong provider, wrong temporal scope, wrong count grain).

**Most critical finding (F-023 CRITICAL)**: The sql_query system prompt Rule 7 instructs the LLM to use `is_current_effective = true` for rate filtering, but **this column does not exist** in `tbl_contract_rates_all`. The correct filter is `status = 'current'`. When the LLM follows Rule 7, the generated SQL fails at execution with UNRESOLVED_COLUMN. The rate_query tool uses the correct `status = 'current'` filter.

---

## 2. SQL Architecture Overview

### 2.1 Two Execution Paths

```
┌─────────────────────────────────────────────────────────────────────────────┐
│ Path A: rate_query.py (DETERMINISTIC)                                       │
│ • 10 query types (provider_rates, benchmark, amendment_comparison, etc.)     │
│ • Hardcoded SQL templates with parameterized provider/category filters       │
│ • Uses RATES_CURRENT_SQL subquery (status='current' AND is_valid_rate=true)  │
│ • QUALIFY ROW_NUMBER() dedup on canonical_provider_id + rate_category + ...  │
│ • Provider resolution via ProviderService.resolve()                          │
│ • TRUSTWORTHINESS: HIGH (deterministic, tested)                              │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ Path B: sql_query.py (LLM-GENERATED)                                        │
│ • 23 system prompt rules + whitelist descriptions                            │
│ • LLM generates SQL from natural language                                    │
│ • Post-processing: DOFR is_current strip, period strip, superseded_by fix    │
│ • Provider enforcement: injects WHERE if LLM omits it                        │
│ • Validation: DDL/DML block + table whitelist (SECURITY ONLY)                │
│ • TRUSTWORTHINESS: MEDIUM (correct 80-90%, silent wrong answers 10-20%)      │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 2.2 Validation Pipeline (sql_query.py)

```
Question → [PROVIDER SCOPE injection] → LLM SQL generation → Post-processing:
  • Period stripping from LIKE literals
  • DOFR is_current removal
  • superseded_by REGEXP_EXTRACT rewrite
  • Provider enforcement injection
→ _validate_sql():
  • DDL/DML keyword block (CREATE, INSERT, UPDATE, DELETE, DROP, ALTER, TRUNCATE, MERGE)
  • Table whitelist check (FROM/JOIN table names vs CONTRACT_TABLES_FOR_SQL)
→ spark.sql(sql) → result rows
```

**What _validate_sql does NOT check:**
- Column existence (phantom columns pass)
- Join key correctness (provider_id vs canonical_provider_id)
- Required filters (status='current' for rate queries)
- Aggregation grain (COUNT(*) vs COUNT(DISTINCT))
- Result cardinality expectations
- Temporal bounds (missing lower/upper date bounds)
- Semantic consistency with question intent

---

## 3. SQL Correctness Risk Register

### 3.1 CRITICAL Risks

| ID | Risk | Impact | Source |
| --- | --- | --- | --- |
| F-023 | System prompt Rule 7: `is_current_effective = true` phantom column | SQL execution failure (UNRESOLVED_COLUMN) | sql_query.py line 92 |
| F-024 | Benchmark template: `COUNT(*)` aliased as `n_providers` | LLM reports "150,000 providers" when real count is ~300 | rate_query_templates.py benchmark() |
| F-025 | No join-key enforcement: LLM can use provider_id instead of canonical_provider_id | 28% of rates silently dropped from results | No semantic validator |

### 3.2 HIGH Risks

| ID | Risk | Impact | Source |
| --- | --- | --- | --- |
| F-026 | Amendment comparison uses STRING `amendment_order` without CAST | Join/filter on string "10" < "2" (lexicographic) | rate_query.py line 548 |
| F-027 | No COUNT(DISTINCT) enforcement for clause/provider counts | Over-counts by amendment versions (498 vs real 300) | Rule 12a partially mitigates |
| F-028 | Provider filter token matching is case-sensitive in some paths | "St. Mary" vs "st mary" mismatch silently returns 0 rows | _PROVIDER_FILTER_TOKENS |
| F-029 | tbl_rate_benchmarks in whitelist but 100% synthetic | LLM generates SQL against synthetic data, answers look real | table_whitelist.py |

### 3.3 MEDIUM Risks

| ID | Risk | Impact | Source |
| --- | --- | --- | --- |
| F-030 | Delegation/clause is_current filter drops valid data | 73% delegation loss, some clause loss | Whitelist instructions |
| F-031 | No result-size guard: empty results don't trigger retry for all tables | User sees "no data" when filter was too narrow | Only DOFR has fallback |
| F-032 | Whitelist duplicate entries (tbl_provider_identifiers, tbl_rate_escalators, tbl_service_areas) | Python dict: last definition wins, earlier description lost | table_whitelist.py |
| F-033 | Debug print statements in production rate_query.py | Information leak + performance cost | rate_query.py line 574-575 |

---

## 4. Valid SQL / Wrong Answer Examples

These queries pass validation and execute successfully but produce **businessly incorrect** answers:

### 4.1 Provider Count Over-Estimation

**Question**: "How many providers have a dispute resolution clause?"

```sql
-- WRONG (passes validation, executes, returns 498)
SELECT COUNT(*) AS provider_count
FROM dev_adb.raw.tbl_contract_clauses
WHERE clause_category = 'DISPUTE_RESOLUTION' AND clause_status = 'HAS'

-- CORRECT (returns accurate count ~300)
SELECT COUNT(DISTINCT provider_name) AS provider_count
FROM dev_adb.raw.tbl_contract_clauses
WHERE clause_category = 'DISPUTE_RESOLUTION' AND clause_status = 'HAS'
```
**Error**: COUNT(*) counts amendment versions, not distinct providers. Real max = 300 providers.

### 4.2 Silent Rate Drop from Wrong Join Key

**Question**: "What are Sharp's current inpatient rates?"

```sql
-- WRONG (passes validation, executes, drops 28% of rates)
SELECT r.rate_category, r.rate_numeric
FROM dev_adb.raw.tbl_contract_rates_all r
JOIN dev_adb.raw.tbl_genie_provider_profile p ON r.provider_id = p.provider_id
WHERE LOWER(p.provider_name) LIKE '%sharp%' AND r.status = 'current'

-- CORRECT (uses canonical_provider_id for 100% resolution)
SELECT r.rate_category, r.rate_numeric
FROM dev_adb.raw.tbl_contract_rates_all r
JOIN dev_adb.raw.tbl_genie_provider_profile p ON r.canonical_provider_id = p.provider_id
WHERE LOWER(p.provider_name) LIKE '%sharp%' AND r.status = 'current'
```
**Error**: Using provider_id loses 128,896 rate rows (28%). Answer is incomplete.

### 4.3 Benchmark Provider Count Inflation

**Question**: "How does Sharp compare to the network average for inpatient rates?"

The benchmark template returns `n_providers` = COUNT(*) which could be 150,000+ (rate rows). The LLM synthesizes this as "compared against 150,000 providers" when the real provider count is ~300.

### 4.4 Phantom Column Runtime Error

**Question**: "Show me current rates for Scripps"

If LLM follows Rule 7 literally:
```sql
-- FAILS at execution (UNRESOLVED_COLUMN)
SELECT * FROM dev_adb.raw.tbl_contract_rates_all
WHERE LOWER(provider_name) LIKE '%scripps%'
  AND is_current_effective = true  -- DOES NOT EXIST
```

### 4.5 Amendment Order Lexicographic Comparison

**Question**: "Compare amendment 2 vs amendment 10 rates for Adventist"

```sql
-- WRONG: STRING comparison "10" < "2" (lexicographic)
WHERE amendment_order = '10'  -- matches, but ORDER BY amendment_order sorts wrong

-- CORRECT: use INT column
WHERE amendment_order_int = 10
```

---

## 5. Golden SQL Benchmark (32 Test Questions)

### Category A: Provider/Contract Lookup (5 questions)

| # | Question | Tables | Key Rule | Expected SQL Pattern | Common Error |
| --- | --- | --- | --- | --- | --- |
| A1 | "Is Sharp Memorial active?" | tbl_genie_provider_profile | Rule 8 (no auto is_active filter) | SELECT provider_name, is_active FROM ... WHERE LOWER(provider_name) LIKE '%sharp memorial%' | Adding AND is_active=TRUE as filter |
| A2 | "What payment type does Cedars-Sinai use?" | tbl_genie_provider_profile | Direct lookup | SELECT payment_type FROM ... WHERE LOWER(provider_name) LIKE '%cedars%' | Using payment_type_normalized |
| A3 | "Does Adventist have auto-renewal?" | tbl_genie_provider_profile | Rule 10 (STRING booleans) | WHERE auto_renewal = 'True' | WHERE auto_renewal = TRUE (boolean) |
| A4 | "How many amendments does Stanford have?" | tbl_genie_provider_profile | Rule 18 | SELECT total_amendments FROM profile WHERE LIKE '%stanford%' | COUNT(*) from documents table |
| A5 | "Which health system is Mercy General part of?" | tbl_provider_system_membership JOIN dim_health_system | System join | JOIN on system_id | Searching for 'mercy' in dim_health_system |

### Category B: Current/Historical Rates (5 questions)

| # | Question | Tables | Key Rule | Expected SQL Pattern | Common Error |
| --- | --- | --- | --- | --- | --- |
| B1 | "What are Sharp's current inpatient per diem rates?" | tbl_contract_rates_all | status='current', canonical_provider_id | WHERE status='current' AND rate_category='inpatient_per_diem' AND LIKE '%sharp%' | is_current_effective=true |
| B2 | "Show all historical rates for Scripps ER" | tbl_contract_rates_all | include_historical, service_category | No status filter, service_category LIKE '%emergency%' | Only current rates |
| B3 | "What was Adventist's rate in 2020?" | tbl_contract_rates_all | Point-in-time | effective_date_parsed <= '2020-12-31' AND (superseded_date > '2020-01-01' OR superseded_date IS NULL) | Missing lower bound |
| B4 | "What are Kaiser's PMPM capitation rates?" | tbl_contract_rates_all | rate_unit=PMPM | WHERE rate_unit='PMPM' OR rate_category='capitation' | Searching for 'kaiser' (not in system) |
| B5 | "Average inpatient rate across all providers" | tbl_contract_rates_all | Aggregation, is_valid_rate | WHERE status='current' AND is_valid_rate=true AND rate_category LIKE 'inpatient%' | Including invalid rates |

### Category C: Rate Comparisons (4 questions)

| # | Question | Tables | Key Rule | Expected SQL Pattern | Common Error |
| --- | --- | --- | --- | --- | --- |
| C1 | "Compare Sharp's rates to network median" | tbl_contract_rates_all | Benchmark template | Provider AVG vs PERCENTILE_CONT(0.5) | n_providers = COUNT(*) instead of COUNT(DISTINCT) |
| C2 | "Compare amendment 3 vs amendment 5 for Adventist" | tbl_contract_rates_all | Amendment comparison | FULL OUTER JOIN on rate_category+service_category with amendment_order_int filter | Using STRING amendment_order |
| C3 | "Which provider has the highest inpatient per diem?" | tbl_contract_rates_all | TOP_N | ORDER BY rate_numeric DESC LIMIT 1, status='current' | Missing status filter |
| C4 | "Rate change percentage from amendment 1 to 2 for Stanford" | tbl_contract_rates_all | Amendment + calculation | (new-old)/old * 100 with same service_category | Division by zero, missing NULLs |

### Category D: Clauses (4 questions)

| # | Question | Tables | Key Rule | Expected SQL Pattern | Common Error |
| --- | --- | --- | --- | --- | --- |
| D1 | "Does Providence have an offset clause?" | tbl_genie_provider_profile | Rule 11 (existence) | SELECT offset_clause_status FROM profile WHERE LIKE '%providence%' | WHERE offset_clause_status='HAS' as filter |
| D2 | "How many providers have auto-renewal?" | tbl_contract_clauses or profile | Rule 12a (DISTINCT) | COUNT(DISTINCT provider_name) WHERE clause_category='AUTO_RENEWAL' | COUNT(*) |
| D3 | "Show me the termination clause text for Sharp" | tbl_contract_clauses | Clause text lookup | WHERE clause_category='TERMINATION_PROVISIONS' AND is_current=TRUE | Missing provider filter |
| D4 | "Which providers have NO offset clause?" | tbl_genie_provider_profile | Profile status check | WHERE offset_clause_status = 'NO_MENTION' | WHERE clause_status='ABSENT' (doesn't exist) |

### Category E: DOFR and Delegation (4 questions)

| # | Question | Tables | Key Rule | Expected SQL Pattern | Common Error |
| --- | --- | --- | --- | --- | --- |
| E1 | "Show the DOFR matrix for Sharp" | tbl_dofr_matrix_extracted | NO is_current filter | WHERE LOWER(provider_name) LIKE '%sharp%' (no is_current) | AND is_current=TRUE (returns 0 rows) |
| E2 | "Which services is the hospital responsible for in DOFR?" | tbl_dofr_matrix_extracted | Responsibility boolean | WHERE hospital_responsible=TRUE | WHERE responsible_party='Hospital' (phantom col) |
| E3 | "Which providers delegate claims processing?" | tbl_delegation_matrix | Do NOT filter is_current | WHERE delegated_function='claims_processing' (all rows) | AND is_current=TRUE (loses 73% providers) |
| E4 | "Does Sutter have IPA delegation?" | tbl_genie_provider_profile | Profile flag check | SELECT ipa_delegation_status FROM profile WHERE LIKE '%sutter%' | Querying delegation_matrix with is_current |

### Category F: Aggregation/Counts (4 questions)

| # | Question | Tables | Key Rule | Expected SQL Pattern | Common Error |
| --- | --- | --- | --- | --- | --- |
| F1 | "How many active providers are in the network?" | tbl_genie_provider_profile | is_active=TRUE | SELECT COUNT(*) WHERE is_active=TRUE (answer: 194) | Missing is_active filter |
| F2 | "How many providers have DOFR?" | tbl_genie_provider_profile | Profile flag | COUNT(*) WHERE dofr_status='HAS' (answer: 141) | Querying dofr_matrix (different count) |
| F3 | "Distribution of payment types" | tbl_genie_provider_profile | Rule 17 normalization | GROUP BY payment_type_normalized | GROUP BY raw payment_type (case variants) |
| F4 | "How many Commercial providers?" | tbl_genie_provider_profile | LOB filtering | WHERE lob_normalized LIKE '%Commercial%' | WHERE line_of_business (76 raw values) |

### Category G: Temporal/Expiration (3 questions)

| # | Question | Tables | Key Rule | Expected SQL Pattern | Common Error |
| --- | --- | --- | --- | --- | --- |
| G1 | "Which contracts expire before 2027?" | tbl_contract_documents_master | Rule 13 (both bounds) | WHERE expiration_date_parsed > CURRENT_DATE() AND expiration_date_parsed < '2027-01-01' | Missing CURRENT_DATE() lower bound |
| G2 | "Show amendment history for Providence" | tbl_genie_amendment_timeline | ORDER BY effective_date_parsed | ORDER BY effective_date_parsed ASC | ORDER BY amendment_order (string sort) |
| G3 | "When was Scripps' latest amendment?" | tbl_genie_provider_profile | Pre-computed | SELECT latest_amendment_date FROM profile WHERE LIKE '%scripps%' | Complex query against documents |

### Category H: Edge Cases (3 questions)

| # | Question | Tables | Key Rule | Expected SQL Pattern | Common Error |
| --- | --- | --- | --- | --- | --- |
| H1 | "Are there any non-compliant providers?" | tbl_compliance_tracking | Zero-result correct | COUNT(*) WHERE compliance_status='NON_COMPLIANT' (answer: 0) | Assuming data exists |
| H2 | "What is the responsible party in Sharp's DOFR?" | tbl_dofr_matrix_extracted | No responsible_party col | Three boolean columns | WHERE responsible_party = '...' |
| H3 | "Show me Dignity Health's rates" | tbl_contract_rates_all | Rule 14 (system expansion) | LIKE '%mercy%' OR LIKE '%dominican%' | LIKE '%dignity health%' (0 rows) |

---

## 6. Semantic Validator Design

### 6.1 Current State (Security-Only)

```python
def _validate_sql(sql: str) -> Optional[str]:
    # Check 1: DDL/DML keywords
    # Check 2: Table whitelist
    return None  # passes
```

### 6.2 Proposed Semantic Validation Layer

A deterministic, zero-LLM-cost validation layer that catches the most common wrong-answer patterns:

```python
def semantic_validate(sql: str, question: str, provider_name: str) -> list[Warning]:
    warnings = []
    
    # LAYER 1: Column existence (parse AST, check against dim_table_schema)
    for table, columns in extract_table_columns(sql):
        invalid = check_columns_exist(table, columns)  # lookup dim_table_schema
        if invalid:
            warnings.append(ColumnError(table, invalid))
    
    # LAYER 2: Approved join graph
    for join in extract_joins(sql):
        if join matches (rates, profile) and key != 'canonical_provider_id':
            warnings.append(JoinWarning("Use canonical_provider_id for rates→profile"))
    
    # LAYER 3: Required filters
    if 'tbl_contract_rates_all' in sql and 'status' not in sql.lower():
        if 'historical' not in question.lower():
            warnings.append(FilterWarning("Missing status='current' filter on rates"))
    
    if 'tbl_dofr_matrix_extracted' in sql and 'is_current' in sql.lower():
        warnings.append(FilterWarning("DOFR: remove is_current filter (only 60/1821 rows)"))
    
    # LAYER 4: Grain checks
    if 'COUNT(*)' in sql and 'provider' in question.lower():
        if 'tbl_contract_clauses' in sql or 'tbl_contract_rates_all' in sql:
            if 'DISTINCT' not in sql:
                warnings.append(GrainWarning("Use COUNT(DISTINCT provider_name) for provider counts"))
    
    # LAYER 5: Temporal bounds
    if 'expir' in question.lower() and 'CURRENT_DATE' not in sql:
        warnings.append(TemporalWarning("Missing lower date bound for expiration query"))
    
    # LAYER 6: Provider presence (if provider named but no WHERE filter)
    if provider_name and not provider_filter_present(sql, provider_name):
        warnings.append(ProviderWarning(f"Missing provider filter for {provider_name}"))
    
    return warnings
```

### 6.3 Implementation Priority (Incremental)

| Phase | Checks | Effort | Impact |
| --- | --- | --- | --- |
| Phase 1 (immediate) | Fix Rule 7 phantom column; fix benchmark n_providers | 1 hour | Eliminates F-023, F-024 |
| Phase 2 (1-2 days) | Add column existence check via dim_table_schema lookup | 4 hours | Prevents all phantom column errors |
| Phase 3 (1 week) | Add join-graph validator + grain check | 8 hours | Catches F-025, F-027 |
| Phase 4 (2 weeks) | Full semantic layer with temporal rules | 16 hours | Covers all 32 benchmark cases |

---

## 7. Post-Processing Rewrites (Current)

The system has 6 post-processing rewrites that fire between LLM generation and execution:

| # | Rewrite | Trigger | Effect | Correctness |
| --- | --- | --- | --- | --- |
| 1 | Period stripping from LIKE | Always | `'%st. mary%'` → `'%st mary%'` | CORRECT |
| 2 | DOFR is_current removal | `tbl_dofr_matrix_extracted` in SQL + DOFR question | Strips `AND is_current=TRUE` | CORRECT (fixes F-013) |
| 3 | DOFR LIMIT 1 removal | Same trigger | Strips `LIMIT 1` | CORRECT |
| 4 | superseded_by rewrite | `superseded_by` in SQL | Rewrites direct join to REGEXP_EXTRACT | CORRECT |
| 5 | Provider enforcement | provider_name in kwargs but not in SQL WHERE | Injects LIKE filter | CORRECT |
| 6 | DOFR responsibility injection | Question asks "responsible" + DOFR table | Injects `AND <col>=TRUE` before ORDER BY | CORRECT |

**Gap**: No equivalent rewrite for delegation_matrix is_current (F-014) or clause count grain.

---

## 8. Result Handling Rules

| Scenario | Current Behavior | Correct Behavior | Gap |
| --- | --- | --- | --- |
| 0 rows from DOFR | Fallback query (broader) | CORRECT | None |
| 0 rows from other tables | Return empty ToolResult | Should suggest broadening | F-031 |
| >200 rows | LIMIT 200 (prompt rule) | Aggregate or paginate | Acceptable |
| NULL rate_numeric | Included in results | Should be noted as formula-based | Documentation only |
| rate_numeric > plausibility bound | Included | Should flag as suspect | No guard |
| All rows same provider | Expected for provider query | CORRECT | None |
| Multiple providers in provider query | Provider filter failed | Should warn | Caught by enforcement |

---

## 9. Immediate Fixes (No Code Modification — Documented)

| Priority | Fix | File | Line | Change |
| --- | --- | --- | --- | --- |
| P0 | Replace `is_current_effective = true` with `status = 'current'` in Rule 7 | sql_query.py | 92-93 | Text replacement in system prompt |
| P0 | Change `COUNT(*)` to `COUNT(DISTINCT provider_name)` in benchmark template | rate_query_templates.py | benchmark() | In portfolio CTE |
| P1 | Use `amendment_order_int` instead of `amendment_order` in amendment comparison | rate_query.py | ~548 | Change filter to use INT column |
| P1 | Remove duplicate `tbl_provider_identifiers` / `tbl_rate_escalators` / `tbl_service_areas` from whitelist | table_whitelist.py | ~130/265/325 | Remove duplicate dict entries |
| P2 | Add delegation_matrix is_current post-processing strip (like DOFR) | sql_query.py | after line 503 | New rewrite block |
| P2 | Remove `tbl_rate_benchmarks` from whitelist or add synthetic disclaimer | table_whitelist.py | entry | Edit description |
| P3 | Remove debug print statements | rate_query.py | lines 574-575 | Delete print() calls |

---

## 10. Updated Issue Ledger (from this report)

| ID | Severity | Category | Classification | Title |
| --- | --- | --- | --- | --- |
| F-023 | CRITICAL | CORRECTNESS | Confirmed code defect | System prompt Rule 7: `is_current_effective` column does not exist |
| F-024 | HIGH | CORRECTNESS | Confirmed code defect | Benchmark template: COUNT(*) aliased as n_providers (should be COUNT(DISTINCT)) |
| F-025 | HIGH | CORRECTNESS | Semantic gap | No enforcement of canonical_provider_id for rates→profile joins |
| F-026 | HIGH | CORRECTNESS | Confirmed code defect | Amendment comparison uses STRING amendment_order (lexicographic sort) |
| F-027 | MEDIUM | CORRECTNESS | Partially mitigated | Clause/provider count queries can use COUNT(*) instead of COUNT(DISTINCT) |
| F-028 | MEDIUM | CORRECTNESS | Confirmed code defect | Provider filter token case sensitivity in edge cases |
| F-029 | MEDIUM | CONSISTENCY | Confirmed documentation defect | tbl_rate_benchmarks in whitelist but 100% synthetic |
| F-030 | MEDIUM | CORRECTNESS | Confirmed semantic gap | Delegation/clause is_current whitelist instruction drops valid data |
| F-031 | LOW | UX | Design gap | No fallback/retry for empty results outside DOFR |
| F-032 | LOW | CORRECTNESS | Confirmed code defect | Duplicate whitelist entries (dict last-wins) |
| F-033 | LOW | OPERATIONS | Confirmed code defect | Debug print statements in production rate_query.py |

---

## 11. Cumulative Issue Ledger (Reports 1–5)

| ID | Severity | Report | Title |
| --- | --- | --- | --- |
| F-001 | LOW | R3 | amendment_chain.py tool not registered |
| F-002 | LOW | R3 | 6 dead runtime files |
| F-003 | LOW | R3 | Architecture doc lists amendment_chain as live tool |
| F-004 | LOW | R3 | logger used before definition at main.py:45 |
| F-005 | MEDIUM | R3 | QueryCacheRepo not wired |
| F-006a | HIGH | R3 | agent_controller.py: 5800 lines dead shadowed code |
| F-007 | LOW | R3 | LegacyBranchAdapter always inert |
| F-008 | MEDIUM | R3 | Fake streaming |
| F-009 | LOW | R3 | Debug print in agent_controller.py:888 |
| F-010 | LOW | R3 | V4_QUERY_CACHE_ENABLED flag has no effect |
| F-011 | MEDIUM | R3 | SQL confidence bypass may pass hallucinated answers |
| F-012 | LOW | R3 | Quote stripping applied twice |
| F-013 | CRITICAL | R4 | DOFR is_current three-way contradiction |
| F-014 | HIGH | R4 | Delegation is_current drops 73% of providers |
| F-015 | MEDIUM | R4 | fact_supersession.provider_id documented as NULL but populated |
| F-016 | LOW | R4 | Whitelist rate status counts stale |
| F-017 | MEDIUM | R4 | Offset clause: profile 47 vs clauses 72 providers |
| F-018 | LOW | R4 | dim_table_schema missing stop_loss/carve_outs |
| F-019 | LOW | R4 | tbl_rate_benchmarks synthetic-only but in whitelist |
| F-020 | LOW | R4 | tbl_provider_identifiers duplicate in whitelist |
| F-021 | LOW | R4 | tbl_rate_escalators duplicate in whitelist |
| F-022 | LOW | R4 | tbl_service_areas duplicate in whitelist |
| F-023 | CRITICAL | R5 | Phantom column is_current_effective in system prompt |
| F-024 | HIGH | R5 | Benchmark n_providers = COUNT(*) not COUNT(DISTINCT) |
| F-025 | HIGH | R5 | No canonical_provider_id join enforcement |
| F-026 | HIGH | R5 | Amendment comparison STRING vs INT sort |
| F-027 | MEDIUM | R5 | COUNT(*) vs COUNT(DISTINCT) for provider counts |
| F-028 | MEDIUM | R5 | Provider filter case sensitivity |
| F-029 | MEDIUM | R5 | tbl_rate_benchmarks synthetic in whitelist |
| F-030 | MEDIUM | R5 | Delegation is_current whitelist instruction |
| F-031 | LOW | R5 | No empty-result fallback outside DOFR |
| F-032 | LOW | R5 | Duplicate whitelist dict entries |
| F-033 | LOW | R5 | Debug print in rate_query.py |

**Summary**: 2 CRITICAL, 6 HIGH, 10 MEDIUM, 15 LOW across 33 findings.

---

*End of Report 5*