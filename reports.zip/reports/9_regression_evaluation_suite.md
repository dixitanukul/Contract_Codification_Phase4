# Contract Intelligence V4 — Regression & Evaluation Suite Design

**Report**: 9 of N  
**Date**: 2026-07-26  
**Author**: Genie Code (automated audit assistant)  
**Status**: COMPLETE  
**Prerequisite**: Reports 1–8 (especially R5 golden SQL, R7 confidence framework, R8 evaluation framework)

---

## 1. Test Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  LAYER 1: DATA MODEL ASSERTIONS (deterministic, no LLM)                    │
│  • Table existence, row counts, schema, constraints                         │
│  • FK integrity, temporal overlap detection, status consistency             │
│  • Runs: every deployment + hourly background                              │
├─────────────────────────────────────────────────────────────────────────────┤
│  LAYER 2: SQL SEMANTICS (deterministic, no LLM)                            │
│  • Generated SQL → AST parse → structural assertions                       │
│  • Table selection, join keys, filters, grain, aggregation                  │
│  • Expected query plan vs. actual plan                                      │
│  • Runs: every code change, per-question in CI                             │
├─────────────────────────────────────────────────────────────────────────────┤
│  LAYER 3: END-TO-END ANSWER (LLM-dependent)                                │
│  • Question → answer pipeline with gold-standard comparison                 │
│  • Correctness, groundedness, citations, confidence                         │
│  • Runs: nightly full suite, per-PR on sample                              │
├─────────────────────────────────────────────────────────────────────────────┤
│  LAYER 4: STABILITY & ROBUSTNESS (LLM-dependent, multi-run)                │
│  • Repeatability (3× same question)                                         │
│  • Paraphrase consistency (3 variants per question)                         │
│  • Version regression (compare answer sets across code versions)            │
│  • Runs: weekly, pre-release                                               │
├─────────────────────────────────────────────────────────────────────────────┤
│  LAYER 5: HUMAN EVALUATION (expert + user trial)                           │
│  • Expert contract review (gold correctness labels)                         │
│  • Controlled user evaluation (Report 8 tasks)                              │
│  • Runs: quarterly, major release                                          │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 1.1 Data Strategies

| Strategy | Description | Used In |
| --- | --- | --- |
| Live production data | Current dev_adb.raw tables (459K rates, 306 providers) | Layers 1–5 |
| Synthetic fixtures | Controlled inserts into test schema with known answers | Layer 2, 3 |
| Frozen snapshots | Point-in-time copies for version comparison | Layer 4 |
| Expert-curated gold | Hand-verified SQL + expected answers | Layers 3, 5 |

### 1.2 Execution Modes

| Mode | Trigger | Layers | Duration | Parallelism |
| --- | --- | --- | --- | --- |
| CI-fast | Every PR | 1, 2 (sample) | <5 min | 4 concurrent |
| CI-full | Merge to main | 1, 2, 3 (sample 30) | <30 min | 4 concurrent |
| Nightly | Cron 02:00 UTC | 1, 2, 3 (all 120) | <90 min | 2 concurrent |
| Weekly-stability | Cron Sunday 04:00 | 1–4 | <4 hr | 1 sequential |
| Release-gate | Manual pre-deploy | 1–4 | <4 hr | 2 concurrent |
| Human-eval | Quarterly | 5 | 2 weeks | N/A |

---

## 2. Benchmark Record Schema

Every benchmark case is defined by this record:

```yaml
test_id: "B-042"                        # Unique, sequential
category: "RATE_LOOKUP"                 # Primary category
subcategory: "single_provider_service"  # Subcategory
question: "What are Sharp HealthCare's current inpatient per diem rates?"
paraphrase_group: "PG-012"             # Links variants of same question
difficulty: "simple"                    # simple | moderate | complex | expert
entities:
  provider: "Sharp HealthCare"
  service_category: "INPATIENT"
  rate_type: "PER_DIEM"
intent: "rate_lookup_single_provider"    # Semantic intent tag

# SQL expectations
expected_tables: ["tbl_contract_rates_all", "tbl_genie_provider_profile"]
expected_joins:
  - left: "tbl_contract_rates_all.canonical_provider_id"
    right: "tbl_genie_provider_profile.canonical_provider_id"
prohibited_joins:
  - left: "tbl_contract_rates_all.provider_id"
    right: "tbl_genie_provider_profile.provider_id"
temporal_rule: "status = 'current'"
required_filters: ["status = 'current'", "canonical_provider_id IN (...)"]
prohibited_filters: ["is_current_effective"]
aggregation: null                       # or "COUNT(DISTINCT ...)"
expected_grain: "one_row_per_rate_line"
query_plan: "rate_query.PROVIDER_RATES"  # Expected tool + query type

# Answer expectations
expected_facts:
  - "Per diem rates exist for Sharp HealthCare"
  - "Rates are current (not superseded)"
  - "Rate values are numeric"
prohibited_facts:
  - "Percent of charges"              # Stale pricing model reference
  - "is_latest_version"               # Phantom column
expected_citations:
  source_filename_pattern: ".*sharp.*|.*SHP.*"
  min_citations: 1
confidence_expectation: "HIGH"          # Expected band
clarification_expected: false
no_answer_expected: false

# Metadata
notes: "Sharp has 14 current inpatient rate lines"
data_version: "2026-07-20"              # Data snapshot this test targets
app_version: "4.0.0"                    # App version when test was authored
```

---

## 3. Benchmark Taxonomy & Allocation

| # | Category | Subcategory | Quantity | Difficulty Mix | Key Data Scenario | Primary Metric | Acceptance |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | RATE_LOOKUP | single_provider_service | 12 | 6S/4M/2C | Current rates, multiple service categories | Numeric accuracy | ≥90% exact match |
| 2 | RATE_COMPARISON | two_provider | 8 | 2S/4M/2C | Same service, different providers | Both rates correct + comparison | ≥85% |
| 3 | RATE_COMPARISON | amendment_history | 6 | 2M/4C | Current vs. superseded for same provider | Temporal ordering correct | ≥80% |
| 4 | CLAUSE_EXISTENCE | has_clause | 8 | 6S/2M | Profile flag = HAS | Binary correct | ≥95% |
| 5 | CLAUSE_EXISTENCE | no_clause | 5 | 3S/2M | Profile flag ≠ HAS or no row | Absence correct without HF-07 | ≥90% |
| 6 | CLAUSE_TEXT | extract_language | 4 | 2M/2C | Clause table has actual text | Citation points to correct doc | ≥80% |
| 7 | DOFR | responsibility_lookup | 8 | 4S/3M/1C | Boolean columns, multi-service | Correct party identified | ≥90% |
| 8 | DOFR | temporal_caveat | 3 | 3C | is_current=TRUE has only 60 rows | No filter on is_current | 100% |
| 9 | DELEGATION | ipa_status | 6 | 3S/2M/1C | Delegation matrix + profile flag | Status correct | ≥85% |
| 10 | PROVIDER_COUNT | aggregation | 6 | 2S/2M/2C | Multiple tables need DISTINCT | COUNT(DISTINCT) used | ≥90% |
| 11 | TEMPORAL | expiration | 5 | 2S/2M/1C | Date arithmetic, both bounds | Correct date range | ≥85% |
| 12 | TEMPORAL | amendment_order | 4 | 2M/2C | amendment_order_int vs STRING | Integer ordering | ≥80% |
| 13 | NETWORK | system_membership | 5 | 2S/2M/1C | LEFT JOIN, 63% NULL | Correct expansion/non-membership | ≥85% |
| 14 | COMPLIANCE | regulation_status | 4 | 2S/2M | NON_COMPLIANT = 0 in live data | Correct zero acknowledgment | ≥90% |
| 15 | RISK_FINANCE | exposure_alerts | 4 | 2M/2C | Alert priority, financial exposure | Correct severity/amounts | ≥85% |
| 16 | PROVENANCE | supersession | 3 | 3C | fact_supersession join logic | Correct chain reconstruction | ≥75% |
| 17 | MULTI_TURN | session_context | 4 | 4C | 3-turn sessions with context carry | Turn 2/3 use prior context | ≥75% |
| 18 | EDGE_CASE | unsupported_question | 3 | 1S/1M/1C | Claims/eligibility/legal | Appropriate refusal | ≥90% |
| 19 | EDGE_CASE | provider_not_found | 3 | 2S/1M | Misspelled/non-existent provider | Fuzzy match or clear "not found" | ≥85% |
| 20 | EDGE_CASE | zero_rows_valid | 3 | 1M/2C | Query correct but data genuinely absent | No hallucinated presence | 100% |
| 21 | STABILITY | paraphrase_set | 5 | — | Same question, 3 phrasings each | Cosine ≥0.85 across variants | ≥85% |
| — | **TOTAL** | | **109** | | | | |

---

## 4. Sample Benchmark Cases (30 of 109)

### 4.1 RATE_LOOKUP

| test_id | question | entities | query_plan | expected_facts | prohibited | difficulty |
| --- | --- | --- | --- | --- | --- | --- |
| B-001 | What are Sharp HealthCare's current inpatient per diem rates? | Sharp/INPATIENT/PER_DIEM | rate_query.PROVIDER_RATES | Numeric rates exist; status=current; ≥5 rate lines | Percent of charges; is_latest_version | simple |
| B-002 | Show me Kaiser Permanente's outpatient rates | Kaiser/OUTPATIENT | rate_query.PROVIDER_RATES | Rates returned; provider correctly resolved | Hallucinated rates for wrong provider | simple |
| B-003 | What does Sutter charge for emergency services? | Sutter/EMERGENCY | rate_query.PROVIDER_RATES | ED rates present; rate_unit specified | DOFR data mixed in | moderate |
| B-004 | Give me all current capitation rates for Scripps | Scripps/CAPITATION | rate_query.CAPITATION | Capitation-specific rates; may be 0 rows | Fabricated capitation values | moderate |
| B-005 | What are the stop-loss thresholds for Dignity Health? | Dignity/STOP_LOSS | rate_query.STOP_LOSS | Stop-loss amounts if they exist; clear no-data if not | Invented dollar amounts | complex |
| B-006 | List all rate categories for Providence with their units | Providence/ALL | rate_query.PROVIDER_RATES | Multiple categories; rate_unit column included | Single category only | simple |
| B-007 | What is the per-case rate for behavioral health at Sharp? | Sharp/BEHAVIORAL_HEALTH/PER_CASE | rate_query.PROVIDER_RATES | Specific BH rates or clear absence | Wrong service category rates | moderate |
| B-008 | Show current rates for Cedar-Sinai Medical Center | Cedars-Sinai/ALL | rate_query.PROVIDER_RATES | Provider resolved despite variant spelling | "Provider not found" when data exists | simple |
| B-009 | What are the carve-out arrangements for Kaiser? | Kaiser/CARVE_OUT | rate_query.CARVE_OUT | Carve-out details if present | Non-carve-out rates mixed in | moderate |
| B-010 | What is the DRG base rate for Adventist Health? | Adventist/DRG | rate_query.PROVIDER_RATES | DRG-specific rate or clear absence | Made-up DRG weights | complex |
| B-011 | Show me distribution of rate types across all Sharp contracts | Sharp/DISTRIBUTION | rate_query.DISTRIBUTION | Category breakdown with counts | Only one category shown | complex |
| B-012 | What are the top 5 highest per-diem rates for any provider? | ALL/TOP_N | rate_query.TOP_N | Ranked rates with provider names; status=current | Superseded rates included | moderate |

### 4.2 RATE_COMPARISON

| test_id | question | entities | expected_facts | prohibited | difficulty |
| --- | --- | --- | --- | --- | --- |
| B-013 | Compare Sharp and Kaiser emergency rates | Sharp+Kaiser/ED | Both rates shown; same unit/period for comparison | Comparing different units without disclosure | moderate |
| B-014 | How have Sharp's inpatient rates changed from the last amendment? | Sharp/INPATIENT/AMENDMENT | Current vs. previous amendment; amendment_order_int used | STRING comparison of amendment_order (F-026) | complex |
| B-015 | Which provider has higher outpatient rates: Sutter or Dignity? | Sutter+Dignity/OUTPATIENT | Both rates plus explicit comparison; directional answer | Hallucinated ranking without data | moderate |
| B-016 | Show rate trends for Kaiser across all amendments | Kaiser/ALL/TEMPORAL | Multiple amendment versions ordered by amendment_order_int | Out-of-order due to STRING sort | complex |

### 4.3 CLAUSE_EXISTENCE

| test_id | question | entities | expected_facts | prohibited | difficulty |
| --- | --- | --- | --- | --- | --- |
| B-017 | Does Sharp HealthCare have an offset clause? | Sharp/OFFSET | "Yes" + profile flag offset_clause_status=HAS | Incorrect "No" when profile says HAS | simple |
| B-018 | Which providers have auto-renewal clauses? | ALL/AUTO_RENEWAL | Count with COUNT(DISTINCT); profile.auto_renewal='True' | COUNT(*) without DISTINCT on multi-row table | moderate |
| B-019 | Does Memorial Hospital have a termination for convenience clause? | Memorial/TERMINATION | Correct binary based on profile flag | Asserting absence from 0-row query (HF-07) | simple |
| B-020 | List all clause types present in Adventist Health's contracts | Adventist/ALL_CLAUSES | All clause_category values for this provider | Missing categories that exist in data | moderate |
| B-021 | Which providers do NOT have offset clauses? | ALL/OFFSET_ABSENCE | Providers where offset_clause_status != HAS | Including providers with HAS status | complex |

### 4.4 DOFR

| test_id | question | entities | expected_facts | prohibited | difficulty |
| --- | --- | --- | --- | --- | --- |
| B-022 | Who is responsible for pharmacy for Scripps? | Scripps/PHARMACY | Correct party from boolean columns | Filter by is_current (only 60 rows TRUE in DOFR) | simple |
| B-023 | Show the full DOFR matrix for Kaiser | Kaiser/ALL_SERVICES | Multi-row table with all service categories | Missing BH/Pharmacy/Emergency (0 is_current rows) | moderate |
| B-024 | Is the health plan responsible for emergency services at Sharp? | Sharp/EMERGENCY/HP | Boolean answer from health_plan_responsible column | Using responsible_party column (doesn't exist) | simple |
| B-025 | For which providers is the group responsible for behavioral health? | ALL/BH/GROUP | Provider list where group_responsible=true for BH | Filtering is_current=TRUE which drops BH entirely | complex |

### 4.5 DELEGATION & PROVIDER_COUNT

| test_id | question | entities | expected_facts | prohibited | difficulty |
| --- | --- | --- | --- | --- | --- |
| B-026 | What functions are delegated to Dignity Health? | Dignity/DELEGATION | Delegation functions from tbl_delegation_matrix | Mixing delegation with DOFR | moderate |
| B-027 | How many providers have IPA delegation? | ALL/IPA_COUNT | 120 (from profile ipa_delegation_status=HAS) | COUNT(*) on delegation_matrix (overcounts) | simple |
| B-028 | How many providers have contracts with offset clauses? | ALL/OFFSET_COUNT | 47 (from profile) or 72 (from clauses table — F-017) | COUNT(*) without DISTINCT from clauses | moderate |
| B-029 | How many active providers are in the Sharp system? | Sharp_system/ACTIVE | System expansion via tbl_provider_system_membership | Counting without is_active filter | complex |

### 4.6 TEMPORAL & NETWORK

| test_id | question | entities | expected_facts | prohibited | difficulty |
| --- | --- | --- | --- | --- | --- |
| B-030 | Which providers have contracts expiring in the next 90 days? | ALL/EXPIRATION_90D | Date-bounded query with both lower and upper bounds | Missing lower bound (shows all past expirations) | moderate |
| B-031 | What is the latest amendment for Sharp HealthCare? | Sharp/LATEST_AMENDMENT | Highest amendment_order_int; not STRING max | STRING max of amendment_order giving wrong result | moderate |
| B-032 | Which health system does Scripps belong to? | Scripps/SYSTEM | System name from dim_health_system + membership | NULL if Scripps not in any system (correct) | simple |
| B-033 | List all providers NOT in any health system | ALL/NO_SYSTEM | 63% of providers; LEFT JOIN where system IS NULL | Missing the LEFT JOIN, returning 0 | complex |

### 4.7 EDGE CASES & MULTI-TURN

| test_id | question | entities | expected_facts | prohibited | difficulty |
| --- | --- | --- | --- | --- | --- |
| B-034 | What are the claims costs for Sharp last quarter? | Sharp/CLAIMS | Appropriate refusal (claims not in contract DB) | Hallucinated dollar amounts | simple |
| B-035 | Is Sharp compliant with HIPAA? | Sharp/HIPAA | Answer from compliance_tracking (7 regulations) | Made-up compliance status | moderate |
| B-036 | What are rates for XyzNonexistent Medical? | XyzNonexistent | "Provider not found" or fuzzy suggestions | Fabricated rates for non-existent provider | simple |
| B-037 | Tell me about Shrp HealthCare rates (misspelled) | Shrp→Sharp | Fuzzy-resolved to Sharp; rates returned | "Provider not found" when resolvable | moderate |
| B-038 | [Turn 1] What are Sharp's rates? [Turn 2] How do they compare to last year? | Sharp/MULTI_TURN | Turn 2 carries provider context; compares amendments | Turn 2 asks "which provider?" | complex |
| B-039 | [Turn 1] Tell me about Kaiser [Turn 2] What about their DOFR? [Turn 3] And pharmacy specifically? | Kaiser/3-TURN | Progressive narrowing; session context preserved | Each turn treated independently | expert |
| B-040 | What is the meaning of life? | NONE/UNSUPPORTED | Appropriate refusal (off-topic) | Attempting to answer | simple |

### 4.8 STABILITY (Paraphrase Groups)

| test_id | paraphrase_group | variants | metric |
| --- | --- | --- | --- |
| B-041a/b/c | PG-001 | "Sharp inpatient rates" / "Current per diem for Sharp" / "What does Sharp charge for inpatient?" | Cosine ≥0.85 |
| B-042a/b/c | PG-002 | "Does Kaiser have offset?" / "Is there an offset clause for Kaiser?" / "Kaiser offset clause status" | Same binary answer |
| B-043a/b/c | PG-003 | "Who handles pharmacy for Scripps?" / "Pharmacy DOFR responsibility Scripps" / "For Scripps, which party is responsible for pharmacy?" | Same entity identified |
| B-044a/b/c | PG-004 | "How many providers have IPA?" / "Count of IPA-delegated providers" / "Total providers with IPA delegation status" | Same count ±0 |
| B-045a/b/c | PG-005 | "Sharp's latest amendment" / "Most recent amendment for Sharp HealthCare" / "What's the newest Sharp contract amendment?" | Same amendment identified |

---

## 5. Statistical Design

### 5.1 Sample Size Justification

| Parameter | Value | Rationale |
| --- | --- | --- |
| Total benchmarks | 109 | ≥30 per major category for Wilson CI validity |
| Per-category minimum | 3 | Even rare categories have statistical signal |
| Paraphrase variants | 3 per group × 5 groups = 15 | Detect instability at 80% power |
| Repeat runs | 3× full suite for stability | Minimum for meaningful variance estimate |
| Human review sample | 50 (from 109) stratified | Sufficient for Cohen's κ calculation |

### 5.2 Confidence Intervals

**Method**: Wilson score interval (95% CI) per category.

For n=12 (RATE_LOOKUP) with 11/12 correct: CI = [0.68, 0.99]  
For n=109 (overall) with 95/109 correct: CI = [0.82, 0.92]  

**Minimum reportable**: n≥10 per category. Categories with <10 cases are reported as point estimates with "low confidence" flag.

### 5.3 Significance Testing

| Comparison | Test | Threshold |
| --- | --- | --- |
| Version A vs. B accuracy | McNemar's χ² (paired) | p<0.05 |
| Category accuracy vs. target | One-proportion z-test | p<0.05 |
| Latency regression | Welch's t-test (log-transformed) | p<0.05, >20% increase |
| Paraphrase consistency | Cochran's Q (k related samples) | p<0.05 |

### 5.4 Calibration Assessment

Bin answers by predicted trust band (5 bands from Report 7). Compute:
- ECE = Σ(n_bin/N) × |accuracy_bin - midpoint_bin|
- Brier score = (1/N) Σ(predicted_i - actual_i)²
- Reliability diagram (plotted per run)

**Target**: ECE < 0.15 for deployment; ECE < 0.10 for "well-calibrated" label.

---

## 6. Acceptance Gates

### 6.1 Developer Gate (CI — Every PR)

| Criterion | Metric | Threshold | Blocking |
| --- | --- | --- | --- |
| Data model integrity | Layer 1 assertions | 100% pass | Yes |
| No phantom columns | QQ-02 on all generated SQL | 0 phantom refs | Yes |
| No prohibited joins | QQ-03 on all generated SQL | 0 unapproved joins | Yes |
| Required filters present | QQ-05 on rate/DOFR queries | 100% present | Yes |
| No new hard failures | HF-01 through HF-10 | 0 new vs. baseline | Yes |
| Latency P95 | Layer 3 sample (30 questions) | <60s | Warning |
| Smoke correctness | Layer 3 sample (30 questions) | ≥80% PASS/PARTIAL | Warning |

### 6.2 Expert Gate (Nightly + Pre-Release)

| Criterion | Metric | Threshold | Blocking |
| --- | --- | --- | --- |
| Overall accuracy | 109 benchmarks, judge-scored | ≥85% PASS+PARTIAL | Yes |
| Per-category accuracy | Each of 21 categories | ≥75% (lower CI) | Yes |
| Numeric accuracy | Rate questions (B-001–B-016) | ≥90% exact values | Yes |
| Temporal correctness | Temporal questions (B-030–B-031) | ≥85% correct ordering | Yes |
| Zero hallucinated presence | B-036, edge cases | 100% (no HF-07 violations) | Yes |
| Citation precision | All questions with citations | ≥80% relevant citations | Yes |
| Unsupported claim rate | All answers | <15% claims without evidence | Yes |
| Repeatability | 3× full run, semantic similarity | ≥85% cosine consistency | Warning |
| Paraphrase consistency | 5 groups × 3 variants | ≥80% same-answer rate | Warning |
| Calibration (ECE) | Full suite binned by confidence | <0.20 | Warning |
| Latency P95 | Full 109 questions | <90s | Warning |

### 6.3 User-Trial Gate (Quarterly)

| Criterion | Metric | Threshold | Blocking |
| --- | --- | --- | --- |
| Task completion | Report 8 tasks (T-01–T-15) | ≥70% completed | Yes |
| User accuracy rating | Structured feedback: correct+partial | ≥75% of rated answers | Yes |
| Trust score | Questionnaire A5 | ≥3.5/5.0 mean | Yes |
| Future use intent | Questionnaire A8 "Definitely/Probably" | ≥60% | Yes |
| NPS | Questionnaire A9 | ≥30 | Warning |
| Dangerous errors | Expert-flagged "could lead to bad decision" | 0 | Yes |
| Confidence appropriateness | Feedback: "appropriate" rating | ≥50% | Warning |
| Inter-rater agreement | Cohen's κ between 2 expert reviewers | ≥0.60 | Yes |

### 6.4 Continued-Investment Gate (Annual)

| Criterion | Metric | Threshold | Blocking |
| --- | --- | --- | --- |
| Year-over-year accuracy trend | ΔAccuracy vs. prior year | Non-negative (no regression) | Yes |
| Cost efficiency | Cost per correct answer | <$0.50 | Warning |
| Coverage expansion | New categories/tables supported | ≥2 new per year | No |
| User adoption | Weekly active users (WAU) | ≥10 | Yes |
| Expert validation | Annual expert re-review (50 questions) | ≥85% accuracy | Yes |
| Calibration stability | ECE drift from baseline | <0.05 absolute increase | Warning |

---

## 7. Regression Strategy

### 7.1 Baseline Management

```
baselines/
├── v4.0.0/
│   ├── answers.jsonl          # 109 gold answers (frozen)
│   ├── sql_plans.jsonl        # Expected SQL per question
│   ├── metrics.json           # Aggregate scores at this version
│   └── stability.json         # 3× run consistency scores
├── v4.1.0/
│   └── ... (new baseline after significant change)
└── current → v4.0.0           # Symlink to active baseline
```

### 7.2 Regression Detection Rules

| Signal | Detection | Action |
| --- | --- | --- |
| Accuracy drop >5% overall | McNemar's p<0.05 | Block release |
| Any category drops below minimum | Lower Wilson CI < threshold | Block release |
| New hard failure type | Count(new HF) > 0 | Block release |
| Latency P95 increases >50% | Welch's t-test p<0.05 | Warning + investigation |
| Paraphrase consistency drops | Cochran's Q p<0.05 | Warning |
| New phantom column reference | AST scan finds unknown column | Block release |
| New unapproved join | Join graph validation fails | Block release |

### 7.3 Version Comparison Protocol

1. Run full 109-question suite on version N (baseline)
2. Run same suite on version N+1 (candidate)
3. Paired comparison: for each question, classify as (IMPROVED, UNCHANGED, REGRESSED)
4. McNemar's test on (REGRESSED vs. IMPROVED) counts
5. If p<0.05 and REGRESSED > IMPROVED: block
6. Per-category breakdown: any category with >2 regressions → investigate

---

## 8. Execution Plan

### 8.1 Test Runner Architecture

```python
# Pseudocode — test runner structure
class BenchmarkRunner:
    def __init__(self, benchmark_file: str, mode: str):
        self.cases = load_benchmarks(benchmark_file)  # 109 cases from YAML
        self.mode = mode  # 'ci-fast', 'nightly', 'stability'
        self.results = []
    
    def run_layer1(self):
        """Deterministic data model assertions (no LLM)."""
        for case in self.data_model_cases:
            result = run_sql_assertion(case.sql, case.validator)
            self.results.append(result)
    
    def run_layer2(self, cases):
        """SQL semantic assertions (parse generated SQL, no execution needed)."""
        for case in cases:
            sql = generate_sql(case.question, case.entities)
            ast = parse_sql(sql)
            result = validate_sql_structure(ast, case.expected_tables, 
                                           case.expected_joins, case.required_filters)
            self.results.append(result)
    
    def run_layer3(self, cases, concurrent=2):
        """End-to-end answer evaluation."""
        with ThreadPoolExecutor(max_workers=concurrent) as pool:
            futures = [pool.submit(self._evaluate_case, c) for c in cases]
            for f in futures:
                self.results.append(f.result(timeout=300))
    
    def run_layer4_stability(self, cases, n_repeats=3):
        """Repeatability: run each case n times, compute consistency."""
        for case in cases:
            answers = [self._get_answer(case) for _ in range(n_repeats)]
            consistency = compute_pairwise_similarity(answers)
            self.results.append(StabilityResult(case.test_id, consistency))
    
    def compute_metrics(self) -> SuiteMetrics:
        """Aggregate per-category and overall metrics."""
        ...
```

### 8.2 Concurrency & Rate Limits

| Resource | Limit | Rationale |
| --- | --- | --- |
| SQL warehouse queries | 4 concurrent | Shared cluster, avoid throttling |
| LLM judge calls | 2 concurrent | Model serving rate limits |
| End-to-end questions | 2 concurrent | Each may issue 1–5 tool calls internally |
| Vector search calls | 4 concurrent | Endpoint scales to 4 |
| Total suite wall-clock target | <90 min for nightly | Fits maintenance window |

### 8.3 Latency Budget

| Question Type | P50 Target | P95 Target | Hard Timeout |
| --- | --- | --- | --- |
| Simple lookup (rate_query) | <8s | <20s | 60s |
| Moderate (sql_query) | <15s | <45s | 120s |
| Complex (ReAct multi-step) | <30s | <90s | 180s |
| Multi-turn (session context) | <20s per turn | <60s | 120s per turn |

---

## 9. Dashboard Design

### 9.1 Nightly Run Summary

```
┌──────────────────────────────────────────────────────────────────┐
│  REGRESSION SUITE: 2026-07-26 02:00 UTC  │  v4.0.0  │  109/109  │
├──────────────────────────────────────────────────────────────────┤
│  Overall: 94/109 PASS (86.2%)  [CI: 78.5%–91.7%]               │
│  PARTIAL: 8  │  FAIL: 5  │  ERROR: 2                           │
├──────────────────────────────────────────────────────────────────┤
│  Category Breakdown:                                             │
│  ████████████ RATE_LOOKUP        11/12  91.7%  ✓ above 90%      │
│  ████████░░░░ RATE_COMPARISON     6/8   75.0%  ⚠ below 85%     │
│  ████████████ CLAUSE_EXISTENCE   12/13  92.3%  ✓ above 90%      │
│  ████████████ DOFR               10/11  90.9%  ✓ above 90%      │
│  ████████░░░░ DELEGATION          4/6   66.7%  ✗ below 75%      │
│  ████████████ PROVIDER_COUNT      6/6   100%   ✓                │
│  ████████████ TEMPORAL            8/9   88.9%  ✓ above 85%      │
│  ...                                                             │
├──────────────────────────────────────────────────────────────────┤
│  Hard Failures: 2                                                │
│  • HF-02 (unapproved join) — B-028                              │
│  • HF-07 (zero-rows-as-absence) — B-036                         │
├──────────────────────────────────────────────────────────────────┤
│  Latency:  P50=12.3s  P95=67.2s  Max=142s                      │
│  Cost:     Total=$1.84  Avg=$0.017/question                      │
├──────────────────────────────────────────────────────────────────┤
│  vs. Baseline (v4.0.0): +2 improved, -1 regressed, 106 unchanged│
│  McNemar's p=0.62 (no significant change)                        │
└──────────────────────────────────────────────────────────────────┘
```

### 9.2 Trend Charts (Weekly)

- Overall accuracy % with Wilson CI band (line chart, 12-week window)
- Per-category accuracy heatmap (rows=categories, columns=weeks)
- Latency P95 trend (line chart)
- Hard failure count trend (bar chart)
- Stability/paraphrase consistency (line chart)
- Calibration ECE trend (line chart)

---

## 10. Relationship to Existing Test Suite

The current notebook (`Contract_Intelligence_Comprehensive_Test_Suite`, 132 cells) covers:
- 13 data model checks (Section 0: A–M) — aligns with **Layer 1**
- 99 application questions across 15 categories — aligns with **Layer 3**
- 3 multi-turn sessions — aligns with **Layer 3**

**Gaps in current suite vs. this design:**

| Gap | Current State | This Design |
| --- | --- | --- |
| SQL semantic assertions (Layer 2) | Not present | AST validation per question |
| Stability/repeatability (Layer 4) | Not present | 3× runs + paraphrase groups |
| Paraphrase variants | Not present | 5 groups × 3 variants = 15 tests |
| Statistical analysis | Not present | Wilson CIs, McNemar's, ECE |
| Baseline comparison | Not present | Version-pinned baselines |
| Hard-failure detection | Not present | 10 HF rules checked per answer |
| Concurrency control | ThreadPoolExecutor(1) | Configurable 2–4 |
| Structured benchmarks file | Inline in notebook cells | External YAML/JSONL |
| Dashboard/reporting | Final scorecards cell | Automated trend dashboard |
| Human evaluation integration | Not present | Quarterly expert review protocol |

---

## 11. Updated Issue Ledger

| ID | Severity | Report | Category | Classification | Title |
| --- | --- | --- | --- | --- | --- |
| F-058 | MEDIUM | R9 | TESTING | Design gap | No SQL semantic assertion layer (generated SQL not structurally validated) |
| F-059 | MEDIUM | R9 | TESTING | Design gap | No stability/repeatability testing (single-run only) |
| F-060 | MEDIUM | R9 | TESTING | Design gap | No paraphrase variant testing |
| F-061 | MEDIUM | R9 | TESTING | Design gap | No statistical significance testing for version comparisons |
| F-062 | LOW | R9 | TESTING | Design gap | No externalized benchmark definitions (tests embedded in notebook) |
| F-063 | LOW | R9 | TESTING | Design gap | No automated regression dashboard with trend tracking |

**Running totals (Reports 1–9):** 3 CRITICAL, 14 HIGH, 26 MEDIUM, 22 LOW = **65 total findings**.

---

## 12. Implementation Priorities

### Phase 1: Foundation (1 week)
1. Extract 109 benchmark definitions into `benchmarks/v4.0.0.yaml`
2. Add Layer 2 SQL AST validator (parse + check tables, joins, filters)
3. Add hard-failure detection to existing test runner
4. Baseline current nightly accuracy as v4.0.0 baseline

### Phase 2: Automation (2 weeks)
1. Implement BenchmarkRunner with configurable modes
2. Add paraphrase groups (15 additional test variants)
3. Implement 3× repeatability runs in weekly mode
4. Build nightly summary report (markdown → Delta table for trending)

### Phase 3: Statistical Rigor (1 week)
1. Implement Wilson CI calculation per category
2. Implement McNemar's for version comparison
3. Implement ECE/Brier calibration scoring
4. Build trend dashboard (Lakeview or notebook visualization)

### Phase 4: Human Integration (Quarterly)
1. Select 50-question stratified sample for expert review
2. Run dual-reviewer protocol (Report 8 §8.2)
3. Compute Cohen's κ and calibration diagram
4. Publish go/no-go recommendation per §6.3

---

*End of Report 9*