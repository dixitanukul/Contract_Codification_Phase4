# Contract Intelligence V4 — Confidence & Quality Validation Framework

**Report**: 7 of N  
**Date**: 2026-07-26  
**Author**: Genie Code (automated audit assistant)  
**Status**: COMPLETE  
**Prerequisite**: Reports 1–6

---

## 1. Core Principle: Confidence Is Not a Single Number

The current system uses a single opaque string (`HIGH`/`MODERATE`/`LOW`/`GENERATED`) derived from the worst ToolResult confidence, optionally upgraded by P5-CONF. This is **not statistical confidence** — it is an ordinal self-assessment by the system with no calibration, no measurable components, and no documented relationship to answer correctness.

This framework replaces that with **7 separable, measurable component scores** that compose into a user-facing trust band and a technical diagnostic panel.

---

## 2. Component Architecture

```
┌──────────────────────────────────────────────────────────────────────┐
│  COMPONENT SCORES (each 0.0–1.0, deterministic where possible)          │
├──────────────────────────────────────────────────────────────────────┤
│ C1. Data Quality         | Source data health for tables touched       │
│ C2. Query Quality        | SQL/retrieval correctness (deterministic)    │
│ C3. Evidence Quality     | Claim→evidence mapping completeness          │
│ C4. Answer Correctness   | Factual accuracy vs. evidence (LLM-judged)   │
│ C5. Stability            | Repeatability across runs/paraphrases         │
│ C6. Coverage             | What fraction of the question is addressed    │
│ C7. Business Rule Compl. | Adherence to domain constraints               │
└──────────────────────────────────────────────────────────────────────┘
        │                                              │
        ▼                                              ▼
┌─────────────────────────┐    ┌──────────────────────────────────┐
│ USER TRUST BAND          │    │ TECHNICAL DIAGNOSTIC PANEL      │
│ (shown to end users)     │    │ (shown to admins/auditors)      │
│                          │    │                                  │
│ VERIFIED / SUPPORTED /   │    │ Component scores + deductions   │
│ INDICATIVE / UNCERTAIN / │    │ + hard-failure flags + SQL trace │
│ UNABLE TO VALIDATE       │    │ + evidence manifest              │
└─────────────────────────┘    └──────────────────────────────────┘
```

---

## 3. Metric Catalogue

### 3.1 C1 — Data Quality Metrics

| Metric ID | Name | Purpose | Formula | Numerator | Denominator | Warning | Failure | Deterministic | LLM-Dependent |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| DQ-01 | Key Uniqueness | PK integrity | 1 - (duplicate_keys / total_rows) | Rows with duplicate PKs | Total rows in table | <0.99 | <0.95 | Yes | No |
| DQ-02 | Null Rate (critical cols) | Completeness | 1 - (null_count / total_rows) per required col | NULL values in required columns | Total rows | <0.95 | <0.80 | Yes | No |
| DQ-03 | FK Orphan Rate | Referential integrity | 1 - (orphan_rows / total_rows) | Rows with no parent | Total rows | <0.95 | <0.70 | Yes | No |
| DQ-04 | Status Conflict Rate | Consistency | 1 - (conflicting_status / total_rows) | Rows where status contradicts related table | Total rows | <0.99 | <0.95 | Yes | No |
| DQ-05 | Temporal Overlap | No conflicting effective periods | 1 - (overlapping_pairs / total_pairs) | Provider+category with overlapping current rates | All provider+category pairs | <0.99 | <0.95 | Yes | No |
| DQ-06 | Staleness | Data freshness | 1 if max(created_at) within 7 days else decay | Days since last update | 7-day window | >14 days | >30 days | Yes | No |
| DQ-07 | Amendment Completeness | Chain integrity | providers_with_sequential_order / total_providers | Providers with non-null sequential_order | All providers in hierarchy | <0.95 | <0.90 | Yes | No |
| DQ-08 | Rate Validity | Valid rate coverage | valid_rates / total_rates | is_valid_rate=true rows | All rate rows | <0.95 | <0.90 | Yes | No |

**When computed**: At system startup (cached) and refreshed hourly. Per-query: compute only for tables touched by the query.

**Ground truth**: Schema metadata + live aggregate queries (no human labels needed).

---

### 3.2 C2 — Query Quality Metrics

| Metric ID | Name | Purpose | Formula | Inputs | Warning | Failure | Deterministic | LLM-Dependent |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| QQ-01 | Table Selection | Correct tables for question type | 1 if all tables in approved set for intent | Parsed SQL tables vs. question-type→table map | N/A | Wrong table | Yes (after SQL parse) | No |
| QQ-02 | Column Existence | All referenced columns exist | 1 - (phantom_cols / total_cols_referenced) | SQL AST columns vs. dim_table_schema | Any phantom | Any phantom | Yes | No |
| QQ-03 | Join Correctness | Approved join keys used | 1 if all joins use approved keys from join graph | SQL AST joins vs. approved_join_map | Unapproved join | rates→profile via provider_id | Yes | No |
| QQ-04 | Grain Correctness | COUNT uses DISTINCT where required | 1 if provider counts use COUNT(DISTINCT) on multi-row tables | SQL AST + table grain metadata | Missing DISTINCT | On clauses/rates tables | Yes | No |
| QQ-05 | Required Filter Present | Temporal/status filters applied | 1 if required filters present for table | SQL WHERE vs. required_filter_map | Missing status='current' | On rates without 'historical' intent | Yes | No |
| QQ-06 | Provider Filter Present | Provider scoped when provider named | 1 if provider filter exists when provider_name in kwargs | SQL WHERE + provider_name input | Missing provider | Always when provider specified | Yes | No |
| QQ-07 | Result Cardinality | Non-zero rows returned | 1 if rows>0, 0.5 if 0 rows with valid question | Row count from execution | 0 rows | 0 rows + non-empty question | Yes | No |
| QQ-08 | Execution Success | SQL runs without error | 1 if no exception, 0 if exception | Execution outcome | N/A | Any exception | Yes | No |

**When computed**: Per-query, after SQL generation, before and after execution.

**Ground truth**: Deterministic — SQL AST parsing + schema lookup. No human labels.

---

### 3.3 C3 — Evidence Quality Metrics

| Metric ID | Name | Purpose | Formula | Numerator | Denominator | Warning | Failure | Deterministic | LLM-Dependent |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| EQ-01 | Claim Coverage | Fraction of answer claims with evidence | claims_with_evidence / total_claims | Claims traceable to tool result | All factual claims in answer | <0.80 | <0.50 | No | Yes (claim extraction) |
| EQ-02 | Citation Precision | Citations that actually support their claim | supporting_citations / total_citations | Citations verified as relevant | All citations returned | <0.90 | <0.70 | No | Yes (relevance check) |
| EQ-03 | Citation Recall | Claims that have a citation | cited_claims / citable_claims | Claims with at least one citation | All claims needing citation | <0.70 | <0.40 | No | Yes (claim extraction) |
| EQ-04 | Evidence Currentness | Evidence from current (not superseded) sources | current_evidence / total_evidence | Evidence items with status=current or is_current=true | All evidence items | <0.90 | <0.70 | Yes (check status field) | No |
| EQ-05 | Numeric Reproducibility | Numbers in answer exist in result data | matching_numbers / answer_numbers | Numbers found in tool_result.data | All numbers in answer | <0.90 | <0.70 | Yes | No |
| EQ-06 | Contradiction Rate | Evidence items that contradict each other | 1 - (contradicting_pairs / total_evidence_pairs) | Pairs with conflicting values | All evidence pairs | <0.99 | <0.95 | Partial | Partial |
| EQ-07 | Source Directness | Evidence from primary source vs. inferred | direct_evidence / total_evidence | Evidence from source table (not synthesized) | All evidence items | <0.70 | <0.50 | Yes | No |

**When computed**: Per-answer, after synthesis but before returning to user.

**Ground truth**: EQ-01/02/03 require LLM-based claim extraction OR human review for calibration.

---

### 3.4 C4 — Answer Quality Metrics

| Metric ID | Name | Purpose | Formula | Warning | Failure | Deterministic | LLM-Dependent |
| --- | --- | --- | --- | --- | --- | --- | --- |
| AQ-01 | Factual Correctness | Answer matches ground truth | Correct claims / total claims (human-judged) | <0.90 | <0.70 | No | Requires human labels |
| AQ-02 | Groundedness | All facts traceable to evidence | Grounded sentences / total factual sentences | <0.85 | <0.60 | No | Yes (LLM judge) |
| AQ-03 | Numeric Accuracy | Rate/count values correct | Correct numerics / total numerics | <0.95 | <0.80 | Partial (compare to SQL) | Partial |
| AQ-04 | Temporal Correctness | Current/historical correctly labelled | Correct temporal labels / total temporal claims | <0.95 | <0.80 | Yes (check status field) | No |
| AQ-05 | Completeness | All asked sub-questions answered | Addressed sub-questions / total sub-questions | <0.80 | <0.50 | No | Yes |
| AQ-06 | Unsupported Claim Rate | Claims not in evidence | Unsupported claims / total claims | >0.10 | >0.30 | No | Yes |
| AQ-07 | Business Rule Compliance | Domain rules not violated | Rules passed / rules checked | <0.95 | <0.80 | Yes (rule engine) | No |

**When computed**: Per-answer for automated checks; periodically via human benchmark for AQ-01.

---

### 3.5 C5 — Stability Metrics

| Metric ID | Name | Purpose | Formula | Method | Warning | Failure | Deterministic | LLM-Dependent |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ST-01 | Repeated Run Consistency | Same question → same answer | Semantic similarity of N runs | Run same question 3x, compute pairwise cosine | <0.90 | <0.70 | No | Yes (embedding) |
| ST-02 | Paraphrase Consistency | Paraphrased question → same answer | Sim(original_answer, paraphrase_answer) | Generate 2 paraphrases, compare answers | <0.85 | <0.65 | No | Yes |
| ST-03 | Route Stability | Same question → same tool path | route_matches / total_runs | Run 3x, check tool_calls list equality | <0.90 | <0.70 | Yes | No |
| ST-04 | SQL Stability | Same question → same SQL | SQL equality (normalized) across runs | Run 3x, normalize whitespace, compare | <0.85 | <0.60 | Yes | No |
| ST-05 | Citation Stability | Same question → same citations | Jaccard(citation_sets) across runs | Run 3x, compare source_filename sets | <0.80 | <0.50 | Yes | No |

**When computed**: Offline batch evaluation (too expensive for per-query).

---

## 4. Hard-Failure Rules

Hard failures **override** component averages. Any single hard failure forces the trust band to UNCERTAIN or UNABLE TO VALIDATE regardless of other scores.

| ID | Hard Failure | Detection Method | Override To |
| --- | --- | --- | --- |
| HF-01 | Missing temporal filter on rate query (not historical) | QQ-05 check: rates table without status='current' | UNCERTAIN |
| HF-02 | Unapproved join key (rates→profile via provider_id) | QQ-03 check: join graph validation | UNCERTAIN |
| HF-03 | Unresolved provider (0 rows returned for named provider) | QQ-07 + provider_name in kwargs | UNABLE TO VALIDATE |
| HF-04 | Conflicting current records (2+ current rates for same service) | DQ-05 check on result set | UNCERTAIN |
| HF-05 | Uncited numeric claim (rate/dollar value not in tool results) | EQ-05 check: numbers not in data | UNCERTAIN |
| HF-06 | Undisclosed result truncation (LIMIT hit but not mentioned) | Row count = LIMIT value + no disclosure | INDICATIVE |
| HF-07 | Zero rows treated as confirmed absence | 0-row result + positive assertion in answer | UNABLE TO VALIDATE |
| HF-08 | Unsupported model facts (claims about data not queried) | EQ-01 check: claim without any tool call evidence | UNCERTAIN |
| HF-09 | Phantom column in generated SQL | QQ-02 check: UNRESOLVED_COLUMN error | UNABLE TO VALIDATE |
| HF-10 | Hallucinated provider (not in resolved context) | Guard check 3/5: ungrounded provider | UNABLE TO VALIDATE |

---

## 5. User Trust Bands

| Band | Label | Criteria | User Message |
| --- | --- | --- | --- |
| 5 | VERIFIED | All components ≥0.90, no hard failures, human-reviewed gold answer exists | "This answer is verified against contract records." |
| 4 | SUPPORTED | All components ≥0.80, no hard failures, SQL-grounded | "This answer is supported by contract data." |
| 3 | INDICATIVE | All components ≥0.60, no critical hard failures, ≤1 warning-level hard failure | "This answer is based on available data but may be incomplete." |
| 2 | UNCERTAIN | Any component <0.60 OR 1+ hard failure | "This answer requires verification — some evidence may be incomplete or conflicting." |
| 1 | UNABLE TO VALIDATE | Any critical hard failure (HF-03/07/09/10) OR evidence component <0.40 | "Unable to validate this answer. Please consult the original contract documents." |

---

## 6. Question-Type-Specific Scoring

| Question Type | Required Metrics | Weight Adjustments | Special Rules |
| --- | --- | --- | --- |
| Provider Rate Lookup | DQ-08, QQ-03, QQ-05, EQ-05, AQ-03 | Numeric accuracy 2x weight | HF-01, HF-02, HF-05 mandatory |
| Provider Count | QQ-04, AQ-03 | Grain correctness 2x weight | Must use COUNT(DISTINCT) |
| Clause Existence | EQ-04, AQ-07 | Currentness 2x weight | Profile flag is truth source |
| Clause Absence | EQ-07, AQ-06 | Source directness 2x weight | HF-07 mandatory |
| Rate Comparison | QQ-05, EQ-06, AQ-04 | Temporal correctness 2x | Both rates must be same unit+period |
| Amendment History | DQ-07, QQ-05, AQ-04 | Amendment completeness 2x | Order by amendment_order_int |
| DOFR Responsibility | QQ-05, AQ-07 | Business rules 2x | Never filter is_current on DOFR |
| Delegation Status | EQ-04, AQ-07 | Coverage 2x | Profile flag ≠ matrix is_current |
| Network Aggregation | QQ-04, QQ-06, AQ-03 | Grain 2x | Must not scope to single provider |
| Temporal/Expiration | QQ-05, AQ-04 | Both date bounds required | HF-01 (both bounds) |

---

## 7. Statistical Validation Plan

### 7.1 Accuracy Confidence Intervals

**Method**: Wilson score interval (preferred over Wald for small samples and proportions near 0/1).

**Formula**: For proportion p̂ with n observations and z = 1.96 (95% CI):
```
CI = (p̂ + z²/2n ± z√(p̂(1-p̂)/n + z²/4n²)) / (1 + z²/n)
```

**Sample size requirements**:
- For 95% CI with ±5% margin: n ≥ 385 (at p=0.5)
- For 95% CI with ±10% margin: n ≥ 97
- Per question category (15 categories): n ≥ 30 per category for meaningful intervals
- **Minimum viable**: 450 total (30×15 categories)
- **Recommended**: 750 total (50×15 categories)

### 7.2 Calibration Assessment

**Purpose**: Does confidence band X correspond to actual accuracy X%?

**Method**:
1. Bin answers by assigned trust band (5 bins)
2. Compute actual accuracy per bin (from human review)
3. Plot reliability diagram: predicted confidence vs. actual accuracy
4. Compute Expected Calibration Error (ECE): `ECE = Σ(n_bin/N) * |accuracy_bin - confidence_bin|`

**Threshold**: ECE < 0.10 (well-calibrated); ECE > 0.20 (poorly calibrated, misleading).

**Brier Score**: `BS = (1/N) Σ(confidence_i - correctness_i)²` where correctness ∈ {0,1}.
- BS < 0.15: good; BS > 0.25: poor.

### 7.3 Inter-Rater Agreement (Human Review)

**Method**: Cohen's kappa (κ) for 2 reviewers on ordinal correctness scale.

```
κ = (p_observed - p_expected) / (1 - p_expected)
```

- κ > 0.80: near-perfect agreement
- 0.60 < κ < 0.80: substantial
- 0.40 < κ < 0.60: moderate (minimum acceptable)
- κ < 0.40: re-train reviewers or revise rubric

### 7.4 Repeatability Testing

**Method**: Run each benchmark question 5 times. Compute:
- Answer consistency: % of runs producing semantically equivalent answers
- Bootstrap 95% CI on consistency rate

**Threshold**: Repeatability ≥ 0.85 for SUPPORTED band; ≥ 0.70 for INDICATIVE.

### 7.5 Version Significance Testing

**Purpose**: When code changes, is accuracy change statistically significant?

**Method**: McNemar's test (paired, binary correct/incorrect per question).

```
χ² = (|b - c| - 1)² / (b + c)
```
where b = questions correct in V1 but wrong in V2, c = wrong in V1 but correct in V2.

**Threshold**: p < 0.05 for significance. Require n ≥ 100 shared questions.

### 7.6 Category Error Analysis

**Method**: Per-category accuracy with Wilson CIs. Flag categories where lower CI bound < 0.70.

**Severity weighting**: Weight errors by impact (rate errors 3x, status errors 2x, metadata errors 1x).

---

## 8. Human Benchmark Review Design

### 8.1 Sampling Strategy

| Stratum | Target n | Selection Method |
| --- | --- | --- |
| Provider Rate Lookup | 50 | Random from test suite category B |
| Count/Aggregation | 50 | Random from category F |
| Clause Existence/Absence | 40 | Random from category D |
| DOFR/Delegation | 30 | Random from category E |
| Temporal/Amendment | 30 | Random from category G |
| Comparison | 30 | Random from category C |
| Edge Cases | 20 | All known edge cases |
| **Total** | **250** | Stratified random |

### 8.2 Review Process

1. **Two independent reviewers** per question (domain experts with contract knowledge)
2. **Blinded**: Reviewers see question + system answer but NOT confidence band or tool trace
3. **Gold standard**: For each question, pre-compute correct SQL + expected answer
4. **Scoring rubric**: 5-point scale (Correct / Mostly Correct / Partially Correct / Mostly Wrong / Wrong)
5. **Disagreement resolution**: Third reviewer adjudicates; majority wins
6. **Leakage prevention**: Gold answers not visible to system developers during review period

### 8.3 Gold Answer Construction

For each benchmark question:
- **Gold SQL**: Hand-written, reviewed SQL that produces the correct result
- **Gold Answer**: Expected natural-language answer with specific values
- **Gold Evidence**: Which table rows/columns constitute evidence
- **Severity tier**: Critical (rate/dollar) / Important (status/count) / Minor (metadata)
- **Version tag**: Which data model version the gold answer applies to

---

## 9. Business Trust Panel (User-Facing)

```
┌─────────────────────────────────────────────────────────────────┐
│  ██ SUPPORTED                                                    │
│                                                                 │
│  This answer is supported by contract data.                      │
│                                                                 │
│  Evidence basis:                                                 │
│  • Source: tbl_contract_rates_all (171,763 current rates)        │
│  • Records matched: 14 rate lines for this provider              │
│  • Data currentness: rates effective 2024-03-01 (not superseded) │
│  • Calculation: Direct lookup (no inference)                     │
│                                                                 │
│  Agreement: All 14 records consistent (no contradictions)        │
│                                                                 │
│  Limitations:                                                    │
│  • Rates reflect contract terms, not actual reimbursement        │
│  • 2 rate lines have formula-only (no numeric value)             │
│                                                                 │
│  Citations: 2 source documents                                   │
└─────────────────────────────────────────────────────────────────┘
```

---

## 10. Technical Diagnostic Panel (Admin-Facing)

```
┌─────────────────────────────────────────────────────────────────┐
│  DIAGNOSTIC: Query session_abc_123, Q3                            │
├─────────────────────────────────────────────────────────────────┤
│  Component Scores:                                               │
│    C1 Data Quality:     0.98 (1 null in rate_numeric)            │
│    C2 Query Quality:    1.00 (all checks pass)                   │
│    C3 Evidence Quality:  0.85 (1 uncited claim: "average")       │
│    C4 Answer Correct.:  [requires human review]                  │
│    C5 Stability:        [offline only]                           │
│    C6 Coverage:          0.90 (sub-Q about "compared to" unaddr) │
│    C7 Business Rules:   1.00                                     │
├─────────────────────────────────────────────────────────────────┤
│  Hard Failures: NONE                                             │
├─────────────────────────────────────────────────────────────────┤
│  SQL Trace:                                                      │
│    Tool: rate_query (PROVIDER_RATES)                             │
│    Template: provider_rates(canonical_provider_id IN (...))      │
│    Rows returned: 14                                             │
│    Dedup: QUALIFY ROW_NUMBER() applied                           │
├─────────────────────────────────────────────────────────────────┤
│  Deductions:                                                     │
│    -0.15 on C3: answer says "average $2,450" but no AVG()       │
│          computed — LLM estimated from visible rows              │
│  Trust Band: SUPPORTED (no hard failures, min component 0.85)    │
└─────────────────────────────────────────────────────────────────┘
```

---

## 11. Risks of Misleading Confidence

| Risk | Manifestation | Mitigation |
| --- | --- | --- |
| Overconfident SQL answers | SQL executes without error → system reports HIGH, but query used wrong join → 28% data loss | QQ-03 join check as hard failure |
| False VERIFIED on stale data | Data 30+ days old but passes all checks | DQ-06 staleness decay |
| Calibration drift | Initial calibration accurate but degrades as data/code changes | Quarterly recalibration with fresh human review |
| Single-point confidence | Reporting "85%" without CI misleads stakeholders | Always report with Wilson CI |
| Confidence as accuracy | Users interpret "HIGH confidence" as "95% likely correct" | Use trust bands (not percentages) for users; reserve stats for technical panel |
| Small-sample categories | 5 questions per category → CI is [0.30, 0.95] | Require n≥30 per category for reporting |

---

## 12. Implementation Roadmap

### 12.1 Minimum Viable (Phase 1, 2 weeks)

| Component | Scope | Effort |
| --- | --- | --- |
| QQ-02 Column existence check | Parse SQL AST, lookup dim_table_schema | 8h |
| QQ-03 Join correctness check | Hardcoded approved_join_map (5 entries) | 4h |
| QQ-05 Required filter check | Table→required_filter map (3 tables) | 4h |
| EQ-05 Numeric reproducibility | Match answer numbers to tool_result.data | 4h |
| Hard failures HF-01/02/05/09 | Wire into _build_response | 8h |
| Trust band assignment | min(C2, C3) + hard failure check → band | 4h |
| **Total Phase 1** | | **32h** |

### 12.2 Advanced (Phase 2, 6 weeks)

| Component | Scope | Effort |
| --- | --- | --- |
| Full C1 data quality cache | Hourly aggregate queries for DQ-01–DQ-08 | 16h |
| C3 claim coverage (LLM-based) | Claim extraction + evidence matching | 24h |
| C5 stability testing | Offline batch: 3 runs per benchmark question | 16h |
| Human benchmark review | 250 questions, 2 reviewers, gold answers | 80h |
| Calibration analysis | ECE, Brier, reliability diagram | 8h |
| Business trust panel UI | Frontend component for evidence display | 24h |
| Technical diagnostic panel | Admin-only panel with full trace | 16h |
| **Total Phase 2** | | **184h** |

---

## 13. Updated Issue Ledger

| ID | Severity | Classification | Title |
| --- | --- | --- | --- |
| F-043 | HIGH | Design gap | No measurable confidence components (single opaque string) |
| F-044 | HIGH | Design gap | No calibration data (confidence not validated against accuracy) |
| F-045 | MEDIUM | Design gap | No hard-failure override mechanism (bad SQL gets HIGH confidence) |
| F-046 | MEDIUM | Design gap | No per-question-type scoring rules |
| F-047 | LOW | Design gap | No stability/repeatability measurement |

**Running totals (Reports 1–7):** 3 CRITICAL, 10 HIGH, 16 MEDIUM, 18 LOW = **47 total findings**.

---

*End of Report 7*