# CONTRACT INTELLIGENCE DEVELOPMENT APPLICATION
# QUALITY, TRUST AND USER-EVALUATION PLAN

**Version**: 1.0  
**Date**: 2026-07-26  
**Prepared by**: Genie Code (automated audit)  
**Basis**: 11 audit reports, 132-cell test suite, full codebase inspection  
**Scope**: Controlled development user-group evaluation readiness

---

## 1. Executive Summary

Contract Intelligence V4 is a FastAPI + React application that answers natural-language questions about 306 healthcare provider contracts using deterministic SQL templates, LLM-generated SQL, and vector-search retrieval. It is deployed as a Databricks App serving Blue Shield of California contract analysts.

This plan consolidates a complete evidence-based audit (11 reports, 42 validated findings) into a single actionable document for preparing the application for a controlled development user trial.

**Key findings:**
- **2 CRITICAL defects** cause wrong answers for entire question categories (DOFR, rates via sql_query path)
- **5 HIGH defects** produce incorrect values (amendment ordering, provider counts, join data loss, delegation coverage)
- All CRITICAL/HIGH defects are trivial 1-line configuration fixes (total: ~2 hours)
- Confidence is an opaque, uncalibrated string with no measurable components
- Feedback is binary (thumbs up/down); no structured evaluation capability exists
- No onboarding explains purpose, coverage, or supported questions
- 69% of the main controller file (5,800 lines) is dead shadowed code
- The system produces correct answers for deterministic SQL-template questions (rate_query path) but has correctness gaps in LLM-generated SQL (sql_query path)

**Recommendation**: Fix the 7 trivial configuration defects (Items 1–5 below), deploy structured feedback and onboarding, then proceed to controlled trial. Total pre-trial effort: ~50 hours across 3 weeks.

---

## 2. Development Objective

Prepare the application for a **controlled development user trial** with 8 evaluators (2 business users, 2 contract experts, 2 data owners, 2 technical evaluators) to determine whether answers are sufficiently correct, trustworthy, and useful to justify continued investment.

**Success criteria**: ≥85% benchmark accuracy, ≥70% task completion, ≥0 dangerous errors, NPS ≥30.

---

## 3. Current Architecture and Active Code Map

### 3.1 System Architecture

```
User → React SPA → FastAPI (/api/v1/query) → AgentController.run()
                                                    │
                              ┌────────────────────────┤
                              ▼                        ▼
                      QuestionRouter            Pre-flight guard
                              │                   (regex → 0 LLM)
                 ┌───────────┼────────────┐
                 ▼            ▼            ▼
           Direct Dispatch  Full ReAct   Decomposed
           (1 tool call)    (1-10 steps) (sub-questions)
                 │            │            │
                 ▼            ▼            ▼
           ┌───────────────────────────────┐
           │         25 Registered Tools         │
           ├───────────────────────────────┤
           │ rate_query (14 instances, templates) │
           │ sql_query (1 instance, LLM SQL)     │
           │ passage_search (4, vector search)   │
           │ citation_verify (5)                 │
           │ summarize (1)                       │
           └───────────────────────────────┘
                        │
              ┌─────────┼──────────┐
              ▼         ▼          ▼
        SQL Warehouse  Vector Search  LLM Endpoints
        (Statement API) (VS endpoint) (Sonnet/Haiku)
```

### 3.2 Active File Map (Production Entry: `app.yaml` → `uvicorn app.main:app`)

| File | Lines | Role |
| --- | --- | --- |
| `app/main.py` | 2,604 | FastAPI app, all REST endpoints |
| `app/sql_client.py` | ~200 | WarehouseSpark (Statement Execution API) |
| `platform/v4/core/agent_controller.py` | 8,465 | AgentController (69% dead — see §4) |
| `platform/v4/core/question_router.py` | ~400 | 16-route classifier |
| `platform/v4/tools/rate_query.py` | 1,879 | 10 deterministic SQL templates |
| `platform/v4/tools/sql_query.py` | 1,071 | LLM-generated SQL with whitelist validation |
| `platform/v4/services/rate_query_templates.py` | ~300 | RATES_CURRENT_SQL, benchmark templates |
| `platform/v4/config/table_whitelist.py` | ~500 | 32 table entries (3 duplicates) for LLM context |
| `platform/v4/config/settings.py` | ~200 | All configuration constants |
| `platform/v4/runtime/notebook_entry.py` | 696 | NotebookRuntime, init_runtime() |
| `platform/v4/data/schema_context_builder.py` | ~150 | Reads dim_table_schema for LLM prompt |
| `frontend/src/pages/ChatPageV2.tsx` | 577 | Primary conversation UI |

### 3.3 Key Configuration

| Setting | Value |
| --- | --- |
| Catalog/Schema | `dev_adb.raw` |
| LLM Reasoning | `databricks-claude-sonnet-4-6` |
| LLM Fast | `databricks-claude-haiku-4-5` |
| VS Endpoint | `contract_intelligence_vs_endpoint` |
| SQL Warehouse | `2c99c6485f03ee73` |
| Agent Max Steps | 10 |
| Agent Budget | $15.00 USD |

---

## 4. Dead/Duplicate Code Summary

| Item | Location | Lines | Reason Dead |
| --- | --- | --- | --- |
| **Shadowed method bodies** | `agent_controller.py` lines 746–5999 | ~5,200 | Python last-definition-wins; 10 methods ×3 copies |
| `amendment_chain.py` | `platform/v4/tools/` | ~200 | Not in `_build_registry()` |
| `api_entry.py` | `platform/v4/runtime/` | ~150 | No caller |
| `async_bridge.py` | `platform/v4/runtime/` | ~100 | No caller |
| `notebook_stream_handler.py` | `platform/v4/runtime/` | ~100 | No caller |
| `notebook_compat_adapter.py` | `platform/v4/adapters/` | ~80 | No caller |
| `tier_service.py` | `platform/v4/services/` | ~120 | No caller |
| `planning.py` | `platform/v4/core/` | ~200 | No caller |
| `query_cache_repo.py` | `platform/v4/data/` | ~150 | Imported but never wired |
| **Total** | | **~6,300** | |

**Impact**: Developers cannot safely modify behavior without understanding which copy is active. The active `_build_response` is at line 6344 (confirmed by runtime logging). Dead code removal is Phase 7 — after all correctness fixes are proven.

---

## 5. Question Flow (5 Dispatch Paths)

| Path | Trigger | LLM Calls | Tool Calls | Latency | Trust Level |
| --- | --- | --- | --- | --- | --- |
| Pre-flight guard | Regex match | 0 | 0 | <100ms | N/A (no answer) |
| Short-circuit | Regex (SL/LOB/amendment) | 0 | 1 (rate_query) | 3–8s | HIGH (template SQL) |
| Direct dispatch | Router → tool_name | 1 | 1 | 5–30s | HIGH if rate_query; MEDIUM if sql_query |
| Full ReAct | Direct returns None | 1 + 1–10 | 1–5 | 15–120s | MEDIUM |
| Decomposed | is_simple=False | 1+1+N | 2–8 | 30–180s | LOW–MEDIUM |

---

## 6. Validated Findings: Model, Semantic, Join, Temporal, Rate, Clause

### 6.1 CRITICAL: Phantom Column in System Prompt (C-02)

| Field | Detail |
| --- | --- |
| **Evidence** | System prompt Rule 7: "Use `is_current_effective = true`." Column does not exist in any table. `DESCRIBE dev_adb.raw.tbl_contract_rates_all` confirms absence (inspected 2026-07-26). |
| **Confirmation** | Schema inspection — deterministic, 100% certain |
| **Importance** | Any rate question through sql_query path may fail with UNRESOLVED_COLUMN |
| **Correction** | Replace with `status = 'current'` in Rule 7 |
| **Test** | Run 12 rate benchmarks (B-001–B-012); 0 schema errors |
| **Acceptance** | Zero UNRESOLVED_COLUMN errors across full benchmark suite |

### 6.2 CRITICAL: DOFR is_current Three-Way Contradiction (C-01)

| Field | Detail |
| --- | --- |
| **Evidence** | Whitelist says "filter is_current=TRUE." Only 60/1,821 rows are TRUE. BH, Pharmacy, Emergency have 0 rows with is_current=TRUE. Confirmed by `SELECT service_category, COUNT(*) ... WHERE is_current=TRUE GROUP BY 1`. |
| **Confirmation** | Live aggregate query — deterministic |
| **Importance** | Any DOFR question for BH/Pharmacy/Emergency returns empty. 3 of 8 service categories invisible. |
| **Correction** | Remove is_current instruction from DOFR whitelist entry. Add: "Do NOT filter is_current on this table." |
| **Test** | B-022–B-025; all service categories return rows |
| **Acceptance** | Non-zero results for every service category in DOFR queries |

### 6.3 HIGH: Canonical Join Not Enforced — 28% Data Loss (C-04)

| Field | Detail |
| --- | --- |
| **Evidence** | `SELECT COUNT(*) FROM tbl_contract_rates_all r LEFT JOIN tbl_genie_provider_profile p ON r.provider_id = p.provider_id WHERE p.provider_id IS NULL` = 128,896 (28%). Same on canonical_provider_id = 0. |
| **Confirmation** | Live query, deterministic |
| **Importance** | LLM may generate JOIN ON provider_id. 28% of rate data silently drops. |
| **Correction** | Post-generation SQL check: detect provider_id join on rates→profile, rewrite to canonical_provider_id |
| **Test** | Generate 20 rate questions; verify all use canonical_provider_id |
| **Acceptance** | 0 orphan rows in any rate benchmark result |

### 6.4 HIGH: Amendment Comparison Uses STRING Sort (C-05)

| Field | Detail |
| --- | --- |
| **Evidence** | `amendment_order` is STRING type; `amendment_order_int` is INTEGER. Template uses ORDER BY amendment_order. String sort: "10" < "2". |
| **Confirmation** | Schema inspection + template code |
| **Importance** | Any provider with ≥10 amendments gets wrong "previous" identification |
| **Correction** | Replace `amendment_order` with `amendment_order_int` in ORDER BY |
| **Test** | B-014, B-016, B-031; verify integer ordering |
| **Acceptance** | Provider with 12 amendments shows amendment 11 as previous (not amendment 9) |

### 6.5 HIGH: Benchmark COUNT(*) Mislabeled as n_providers (C-06)

| Field | Detail |
| --- | --- |
| **Evidence** | Template: `COUNT(*) AS n_providers`. Rates table has multiple rows per provider. COUNT(*) = rate-line count, not provider count. |
| **Confirmation** | Code inspection of rate_query_templates.py |
| **Importance** | Benchmark answers report 10x–26x inflated "provider counts" |
| **Correction** | Change to `COUNT(DISTINCT canonical_provider_id) AS n_providers` |
| **Test** | Run benchmark query; compare to direct `SELECT COUNT(DISTINCT ...)` |
| **Acceptance** | n_providers matches unique provider count |

### 6.6 HIGH: Delegation is_current Drops 73% of Providers (C-08)

| Field | Detail |
| --- | --- |
| **Evidence** | `SELECT COUNT(DISTINCT provider_name) FROM tbl_delegation_matrix` = 120. With `WHERE is_current=TRUE` = 32. |
| **Confirmation** | Live query |
| **Importance** | Delegation questions miss 88 providers |
| **Correction** | Remove is_current=TRUE from delegation whitelist entry |
| **Test** | B-026–B-027; verify 120 providers returned |
| **Acceptance** | Delegation query returns all 120 providers |

### 6.7 MEDIUM: Provider Case Sensitivity (C-15)

| Field | Detail |
| --- | --- |
| **Evidence** | Provider enforcement uses exact-case. "sharp healthcare" ≠ "Sharp HealthCare" |
| **Correction** | Use LOWER() or ILIKE |
| **Test** | B-008, B-037 (variant/misspelled names) |
| **Acceptance** | Mixed-case variants resolve to same provider |

### 6.8 MEDIUM: COUNT(*) Without DISTINCT on Multi-Row Tables (C-18)

| Field | Detail |
| --- | --- |
| **Evidence** | LLM generates `COUNT(*)` on tbl_contract_clauses (7,863 rows, 300 providers). Overcounts 26x. |
| **Correction** | System prompt rule: "Always COUNT(DISTINCT provider_name) for provider counts" |
| **Test** | B-027, B-028 |
| **Acceptance** | COUNT queries use DISTINCT on multi-row tables |

---

## 7. SQL Validation

### 7.1 Current State

The `_validate_sql` method in sql_query.py performs:
- DDL/DML blocking (DROP, ALTER, DELETE, etc.)
- Table whitelist check (only 29 approved tables)

It does **NOT** check:
- Column existence (phantom columns pass)
- Join key correctness (wrong join passes)
- Required filter presence (missing status='current' passes)
- Grain correctness (COUNT(*) vs DISTINCT passes)

### 7.2 Recommended SQL Validation Layer

Post-generation, before execution:
1. **Column existence**: Parse SQL, check all columns against dim_table_schema
2. **Join graph**: If rates→profile, must use canonical_provider_id
3. **Required filters**: rates must have `status = 'current'`; DOFR must NOT have `is_current = TRUE`
4. **Grain check**: COUNT on multi-row tables → must include DISTINCT

All checks are deterministic (no LLM cost). Implementation: regex or sqlglot AST parse.

---

## 8. Grounding, Citations, and Evidence

### 8.1 Current Citation Flow

```
Tool execution → ToolResult(data, citations, confidence)
    → _build_response() collects citations
    → Filter by provider scope
    → Deduplicate by (source_filename, page_number)
    → Return in answer payload
```

### 8.2 Grounding Gap: SQL Confidence Bypass (C-07)

| Field | Detail |
| --- | --- |
| **Evidence** | `_build_response`: if `_all_evidence_from_sql()` returns True, hallucination guard `has_blocks` check is skipped |
| **Importance** | LLM can synthesize claims beyond SQL data (e.g., "average $2,450" when no AVG() computed) and get HIGH confidence |
| **Correction** | Always run numeric-consistency check (guard check 1). Only skip full guard if ALL answer numbers appear in tool_result.data. |
| **Test** | Ask question where LLM synthesizes "average" from individual rate lines; verify confidence is not HIGH |
| **Acceptance** | No uncited numeric claim receives HIGH confidence |

### 8.3 Evidence Summary (Not Yet Implemented)

Current answer includes: markdown text + confidence badge + citation cards.  
Missing: which tables, how many rows, data freshness, method (template vs LLM-SQL vs vector search), limitations.

**Recommended evidence_summary object:**
```json
{
  "tables": ["tbl_contract_rates_all"],
  "row_count": 14,
  "method": "rate_query.PROVIDER_RATES",
  "data_currentness": "current (not superseded)",
  "limitations": ["2 rate lines have formula-only values"]
}
```

---

## 9. Confidence and Statistical Framework

### 9.1 Current State (Opaque, Uncalibrated)

Confidence is derived from: `min(step.confidence for step in successful_steps)` with ad-hoc P5-CONF boost for HIGH-evidence tools. Displayed as one of 4 labels: HIGH / MODERATE / LOW / UNCERTAIN.

**This is NOT statistical confidence. It is an ordinal self-assessment with no calibration, no measured relationship to correctness, and no documented components.**

### 9.2 Recommended Framework (7 Measurable Components)

| Component | Formula | Deterministic | LLM-Needed |
| --- | --- | --- | --- |
| C1. Data Quality | 1 - (null_critical_cols + FK_orphans + status_conflicts) / total_rows | Yes | No |
| C2. Query Quality | 1 if all structural checks pass (table, join, filter, grain, execution) | Yes | No |
| C3. Evidence Quality | claims_with_evidence / total_claims | Partial | Yes (claim extraction) |
| C4. Answer Correctness | correct_claims / total (human-judged) | No | Requires labels |
| C5. Stability | pairwise_cosine(3_repeat_runs) | No | Yes (embedding) |
| C6. Coverage | addressed_subquestions / total_subquestions | Partial | Yes |
| C7. Business Rules | domain_rules_passed / rules_checked | Yes | No |

**Composition**: Trust band = min(C1, C2, C3_lower_bound) with hard-failure override.

### 9.3 Hard Failures (Override Averages)

| ID | Condition | Forced Band |
| --- | --- | --- |
| HF-01 | Missing status='current' on rate query | UNCERTAIN |
| HF-02 | rates→profile via provider_id | UNCERTAIN |
| HF-03 | Provider resolved to 0 rows | UNABLE TO VALIDATE |
| HF-05 | Numeric in answer not in tool_result | UNCERTAIN |
| HF-07 | 0 rows treated as confirmed absence | UNABLE TO VALIDATE |
| HF-09 | Phantom column (UNRESOLVED_COLUMN) | UNABLE TO VALIDATE |

### 9.4 Trust Bands (User-Facing)

| Band | Criteria | Message |
| --- | --- | --- |
| VERIFIED | All components ≥0.90, gold-reviewed | "Verified against contract records" |
| SUPPORTED | All ≥0.80, no hard failures, SQL-grounded | "Supported by contract data" |
| INDICATIVE | All ≥0.60, ≤1 warning | "Based on available data but may be incomplete" |
| UNCERTAIN | Any <0.60 OR hard failure | "Requires verification" |
| UNABLE TO VALIDATE | Critical hard failure | "Please consult original documents" |

### 9.5 Statistical Methods

| Method | Purpose | Formula |
| --- | --- | --- |
| Wilson score interval | Accuracy CI per category | CI = (p̂ + z²/2n ± z√(p̂(1-p̂)/n + z²/4n²)) / (1 + z²/n) |
| ECE | Calibration error | Σ(n_bin/N) × |accuracy_bin - confidence_bin| |
| Brier score | Calibration quality | (1/N) Σ(predicted_i - actual_i)² |
| Cohen's κ | Inter-rater agreement | (p_obs - p_exp) / (1 - p_exp) |
| McNemar's χ² | Version comparison | (|b-c|-1)² / (b+c) |

**Required sample sizes**: n≥30 per category for Wilson CI validity; 450+ total for 15 categories.

---

## 10. Trust, UI, and Onboarding

### 10.1 Current Frontend Gaps

| Gap | Impact | Fix Effort |
| --- | --- | --- |
| No onboarding/coverage explanation | Users ask unsupported questions | 8h |
| Feedback = thumbs only (backend has correction/note fields unused) | Cannot diagnose error patterns | 12h |
| No evidence panel (tables/rows/method/limitations) | Users cannot judge answer basis | 16h |
| No client-side analytics | Cannot measure task success | 8h |
| No example questions | Users don't know what's possible | 4h |
| No provider autocomplete | Typos = 0 results | 8h |
| No error-state differentiation | User stuck | 8h |

### 10.2 Recommended Onboarding Content

- Purpose statement: "Answers questions about provider contracts, rates, clauses, delegations using live contract data"
- Supported categories (8): rate lookup, rate comparison, clause existence, DOFR, delegation, temporal/amendment, network, compliance
- Not supported: claims/utilization data, real-time eligibility, legal advice, non-BSC contracts
- Data coverage: 306 providers (194 active), 459,902 rate lines, 10,349 documents
- Asking tips: name provider explicitly, one concept per question, specify service category for rates

### 10.3 Evidence Panel Design

Show after every answer:
- Data source table(s) + row count
- Method (direct SQL lookup vs. LLM-generated vs. vector search)
- Data currentness (current/superseded status)
- Limitations (formula-only rates, truncation, incomplete coverage)
- Agreement indicator (contradictions found or all consistent)

---

## 11. Databricks Development Limitations

| Limitation | Impact | Mitigation |
| --- | --- | --- |
| Databricks App cold start (503 for ~60s) | Test suite retries on 503 | Frontend already retries 8×10s |
| Statement Execution API 300s timeout | Complex queries may timeout | AGENT_STEP_TIMEOUT_S=120 catches most |
| Shared compute cluster | Concurrent test runs can interfere | Limit concurrency to 2 |
| Delta table eventual consistency | Freshly written rows may not appear | Tests use stable tables (no active writes during test) |
| App deployment build time ~5 min | Iteration cycle includes rebuild | Use TestClient for development |
| VS endpoint cold start | First vector search slow | Warm via /health startup |

---

## 12. Benchmark and Testing Architecture

### 12.1 Test Layers

| Layer | Content | Deterministic | Run Frequency |
| --- | --- | --- | --- |
| 1. Data Model | 13 SQL assertions (table counts, FK integrity, status distribution) | Yes | Every deployment |
| 2. SQL Semantics | AST validation of generated SQL (tables, joins, filters, grain) | Yes | Every PR |
| 3. End-to-End | 109 benchmark questions with gold answers + LLM judge | No | Nightly |
| 4. Stability | 3× repeat runs + 5 paraphrase groups | No | Weekly |
| 5. Human Review | 50-question expert review with Cohen's κ | No | Quarterly |

### 12.2 Benchmark Allocation (109 Total)

| Category | Count | Acceptance |
| --- | --- | --- |
| Rate Lookup | 12 | ≥90% exact match |
| Rate Comparison | 14 | ≥85% |
| Clause Existence | 13 | ≥95% |
| DOFR | 11 | ≥90% |
| Delegation | 6 | ≥85% |
| Provider Count | 6 | ≥90% |
| Temporal/Amendment | 9 | ≥85% |
| Network | 5 | ≥85% |
| Compliance/Risk | 8 | ≥85% |
| Provenance | 3 | ≥75% |
| Multi-Turn | 4 | ≥75% |
| Edge Cases | 9 | ≥85% |
| Stability (paraphrase) | 9 | cosine ≥0.85 |

### 12.3 Existing Test Suite (132 Cells)

The notebook `Contract_Intelligence_Comprehensive_Test_Suite` contains:
- 13 data model checks (cells 6–18)
- 99 application questions across 15 categories (cells 19–131)
- 3 multi-turn sessions
- LLM judge scoring per question
- Final scorecards (cell 132)

This suite serves as the Phase 0 baseline (R-002 in roadmap).

---

## 13. Consolidated Issue Register

### CRITICAL (2)

| ID | Title | File | Active Path | Classification |
| --- | --- | --- | --- | --- |
| C-01 | DOFR is_current contradiction: 0 rows for BH/Pharmacy/Emergency | `table_whitelist.py` | sql_query → WHERE is_current=TRUE | Confirmed defect |
| C-02 | Phantom column `is_current_effective` in system prompt | `sql_query.py` Rule 7 | sql_query → LLM generates phantom column | Confirmed defect |

### HIGH (12)

| ID | Title | File | Classification |
| --- | --- | --- | --- |
| C-03 | agent_controller.py 5,800 lines dead shadowed code | `agent_controller.py` | Confirmed (blocks development) |
| C-04 | No canonical join enforcement (28% data loss) | `sql_query.py` _validate_sql | Confirmed weakness |
| C-05 | Amendment comparison STRING sort | `rate_query.py` template | Confirmed defect |
| C-06 | Benchmark COUNT(*) mislabeled as n_providers | `rate_query_templates.py` | Confirmed defect |
| C-07 | SQL confidence bypass passes hallucinated claims | `agent_controller.py` _build_response | Highly likely weakness |
| C-08 | Delegation is_current drops 73% providers | `table_whitelist.py` | Confirmed defect |
| C-09 | No measurable confidence components | `agent_controller.py` | Design gap |
| C-10 | No calibration data | N/A (not implemented) | Design gap |
| C-11 | No onboarding or coverage explanation | `ChatPageV2.tsx` | Design gap |
| C-12 | Feedback limited to thumbs up/down | `ChatPageV2.tsx` | Design gap |
| C-13 | No evidence panel | `ChatPageV2.tsx` | Design gap |
| C-14 | No client-side evaluation analytics | `frontend/src/` | Design gap |

### MEDIUM (16)

| ID | Title |
| --- | --- |
| C-15 | Provider filter case sensitivity |
| C-16 | Whitelist 3 duplicate entries |
| C-17 | Debug prints in production code |
| C-18 | COUNT(*) without DISTINCT on multi-row tables |
| C-19 | No hard-failure confidence override |
| C-20 | Fake streaming (buffered then sent) |
| C-21 | Offset clause count mismatch (47 vs 72) |
| C-22 | No example questions in UI |
| C-23 | No provider autocomplete |
| C-24 | Error/no-result states not distinguished |
| C-25 | No SQL semantic assertion in test suite |
| C-26 | No stability/repeatability testing |
| C-27 | No per-question-type confidence scoring |
| C-28 | fact_supersession doc says provider_id NULL (populated) |
| C-29 | dim_table_schema missing 2 tables |
| C-30 | No version significance testing |

### LOW (12)

| ID | Title |
| --- | --- |
| C-31 | amendment_chain.py dead + doc says live |
| C-32 | Query cache entirely dead |
| C-33 | Whitelist rate counts stale |
| C-34 | No empty-result fallback (non-DOFR) |
| C-35 | No stability measurement |
| C-36 | No long-answer collapse |
| C-37 | No session search |
| C-38 | Benchmarks embedded in notebook |
| C-39 | No regression dashboard |
| C-40 | Double quote stripping |
| C-41 | Synthetic benchmark table in whitelist |
| C-42 | No fallback guidance for users |

---

## 14. Implementation Roadmap

| Phase | Days | Items | Key Deliverable |
| --- | --- | --- | --- |
| **0: Baseline** | 1–2 | R-001–R-004 | Manifest, baseline scores, version IDs |
| **1: Semantic Fixes** | 3–5 | R-005–R-011 | All CRITICAL/HIGH config fixes (MVTA: 8h) |
| **2: SQL Guards** | 5–8 | R-012–R-014 | Join enforcement, case normalization |
| **3: Grounding** | 8–12 | R-015–R-017 | Numeric check, hard-failure override, evidence API |
| **4: UX** | 10–15 | R-018–R-021 | Onboarding, feedback, analytics, evidence panel |
| **5: Statistics** | 12–18 | R-022–R-025 | Benchmark YAML, SQL AST, stability, calibration |
| **6: Reliability** | 15–20 | R-026–R-027 | Clean logs, structured traces |
| **7: Dead Code** | 18–22 | R-028–R-029 | Remove 6,300 dead lines |
| **8: Trial** | 22–36 | R-030–R-031 | Validation run + 8-evaluator controlled trial |

**Minimum Viable Trusted Application (MVTA)**: R-005 through R-013 = 8 hours of work. Fixes all known wrong-answer defects.

---

## 15. User Trial Design

### 15.1 Evaluators

| Role | Count | Focus |
| --- | --- | --- |
| Business user | 2 | Task success, time saved, ease |
| Contract expert | 2 | Factual accuracy, nuance, dangerous errors |
| Data owner | 2 | SQL correctness, table/join/filter quality |
| Technical evaluator | 2 | Latency, stability, streaming, errors |

### 15.2 Protocol

- 90 minutes per evaluator
- 15 guided tasks (5 difficulty tiers)
- Per-task assessment form (correctness, confidence, citations, time-saved, trust)
- 15-minute free exploration
- 12-question post-session questionnaire

### 15.3 Structured Feedback (Per Answer)

- Accuracy: Correct / Partially correct / Incorrect / Unable to judge
- Error category (if not correct): wrong provider, wrong rate, wrong date, wrong aggregation, missing data, citation issue, unclear, hallucinated
- Confidence assessment: Too high / Appropriate / Too low
- Expected answer (optional text)
- Comment (optional text)

---

## 16. Acceptance Criteria

### 16.1 Developer Gate (Every PR)

| Criterion | Threshold |
| --- | --- |
| Data model assertions | 100% pass |
| No phantom columns | 0 |
| No unapproved joins | 0 |
| Required filters present | 100% |
| No new hard failures | 0 vs baseline |

### 16.2 Expert Gate (Nightly)

| Criterion | Threshold |
| --- | --- |
| Overall accuracy (109 benchmarks) | ≥85% |
| Per-category accuracy (lower CI) | ≥75% |
| Numeric accuracy (rate questions) | ≥90% |
| Citation precision | ≥80% |
| Unsupported claim rate | <15% |
| Latency P95 | <90s |

### 16.3 User-Trial Gate

| Criterion | Threshold |
| --- | --- |
| Task completion (T-01–T-15) | ≥70% |
| User accuracy rating (correct+partial) | ≥75% |
| Trust score (questionnaire) | ≥3.5/5 |
| Future use intent | ≥60% "Definitely/Probably" |
| Dangerous errors (expert-flagged) | 0 |
| NPS | ≥30 |
| Inter-rater agreement (κ) | ≥0.60 |

---

## 17. Go/No-Go Framework

| Decision | Criteria |
| --- | --- |
| **GO** | All §16.3 thresholds met; benchmark ≥85%; 0 CRITICAL open |
| **CONDITIONAL GO** | All thresholds met but 1–2 warnings unresolved |
| **HOLD** | Any threshold NOT met; fix blockers; re-run in 1 week |
| **NO-GO** | Benchmark <70% OR new CRITICAL OR 3+ HIGH open OR dangerous errors found |

---

## 18. Open Questions

| # | Question | Decision Needed By |
| --- | --- | --- |
| 1 | Should evaluation include real production questions or only synthetic benchmarks? | Phase 5 start |
| 2 | Is the offset-clause count mismatch (47 vs 72) a data pipeline bug or intentional? | Phase 2 |
| 3 | Should DOFR table be backfilled so is_current has complete coverage, or permanently excluded? | Phase 1 |
| 4 | What is the acceptable latency P95 for evaluators? (Current design: 90s) | Phase 4 |
| 5 | Should dead-code removal happen before or after evaluation? | Phase 7 timing |
| 6 | Will evaluators have access to the technical diagnostic panel or only the business trust panel? | Phase 4 |

---

## 19. Deferred Production Issues (Not Blocking Trial)

| Item | Why Deferred | Address When |
| --- | --- | --- |
| True token-by-token streaming | UX polish, not correctness | Post-trial GA |
| Per-question-type confidence scoring | Needs calibration data from trial | Post-trial |
| Full 7-component confidence system | Needs baseline measurements | Post-trial |
| Query cache resurrection | No user impact | Only if latency concern |
| Provider autocomplete | Nice-to-have, not blocking | Post-trial |
| Regression trend dashboard | Operational maturity | Post-Phase 5 |
| Session search/filter | Convenience | Post-trial |

---

## Appendix A: Read-Only Validation Queries

These queries confirm findings without modifying any data or code.

### A.1 Confirm Phantom Column Absence
```sql
DESCRIBE dev_adb.raw.tbl_contract_rates_all;
-- Verify: no column named 'is_current_effective'
```

### A.2 Confirm DOFR is_current Coverage Gap
```sql
SELECT service_category,
       COUNT(*) AS total_rows,
       SUM(CASE WHEN is_current = TRUE THEN 1 ELSE 0 END) AS current_rows
FROM dev_adb.raw.tbl_dofr_matrix_extracted
GROUP BY service_category
ORDER BY current_rows;
-- Verify: BEHAVIORAL_HEALTH, PHARMACY, EMERGENCY show 0 current_rows
```

### A.3 Confirm Canonical vs Provider-ID Join Orphan Rates
```sql
-- Wrong join (provider_id): high orphan count
SELECT COUNT(*) AS orphans
FROM dev_adb.raw.tbl_contract_rates_all r
LEFT JOIN dev_adb.raw.tbl_genie_provider_profile p
  ON r.provider_id = p.provider_id
WHERE p.provider_id IS NULL;
-- Expected: ~128,896 (28%)

-- Correct join (canonical_provider_id): zero orphans
SELECT COUNT(*) AS orphans
FROM dev_adb.raw.tbl_contract_rates_all r
LEFT JOIN dev_adb.raw.tbl_genie_provider_profile p
  ON r.canonical_provider_id = p.canonical_provider_id
WHERE p.canonical_provider_id IS NULL;
-- Expected: 0
```

### A.4 Confirm Amendment Column Types
```sql
SELECT column_name, data_type
FROM dev_adb.raw.dim_table_schema
WHERE table_name = 'tbl_contract_rates_all'
  AND column_name IN ('amendment_order', 'amendment_order_int');
-- Verify: amendment_order = STRING, amendment_order_int = INTEGER
```

### A.5 Confirm Delegation is_current Coverage
```sql
SELECT
  COUNT(DISTINCT provider_name) AS total_providers,
  COUNT(DISTINCT CASE WHEN is_current = TRUE THEN provider_name END) AS providers_with_current
FROM dev_adb.raw.tbl_delegation_matrix;
-- Expected: total=120, with_current=32 (73% invisible if filtered)
```

### A.6 Confirm Rate Status Distribution
```sql
SELECT status, COUNT(*) AS cnt
FROM dev_adb.raw.tbl_contract_rates_all
GROUP BY status;
-- Expected: current=171,763; superseded=288,139
```

### A.7 Confirm Provider Profile Counts
```sql
SELECT
  COUNT(*) AS total,
  SUM(CASE WHEN is_active THEN 1 ELSE 0 END) AS active,
  SUM(CASE WHEN offset_clause_status = 'HAS' THEN 1 ELSE 0 END) AS offset_has
FROM dev_adb.raw.tbl_genie_provider_profile;
-- Expected: total=306, active=194, offset_has=47
```

### A.8 Confirm Whitelist Duplicate Keys
```sql
-- Run in Python against the codebase (read-only):
-- from platform.v4.config.table_whitelist import CONTRACT_TABLES_FOR_SQL
-- # If duplicates exist, dict has fewer keys than defined entries
-- # Inspect source file for repeated keys: tbl_provider_identifiers, tbl_rate_escalators, tbl_service_areas
```

---

## Appendix B: Verification Checklist (Pre-Submission)

- [x] All CRITICAL/HIGH findings reference active code paths (confirmed via runtime line-number logging)
- [x] Every confidence metric has a formula (Section 9.2, 9.5)
- [x] LLM self-reported confidence is never called statistical confidence (Section 9.1 explicitly disclaims)
- [x] Data model validation included (Section 12.1, Layer 1; Appendix A)
- [x] Temporal logic covered (C-01, C-05, C-08; Sections 6.2, 6.4, 6.6)
- [x] Join/grain correctness covered (C-04, C-06, C-18; Sections 6.3, 6.5, 6.8)
- [x] Evidence/citations covered (Section 8; C-07, C-13)
- [x] User trial design included (Section 15)
- [x] Statistical testing included (Section 9.5)
- [x] Dead code is separate section (Section 4) with deferred cleanup (Phase 7)
- [x] Recommendations are sequenced (Section 14) and testable (Section 16)

---

*End of Plan*