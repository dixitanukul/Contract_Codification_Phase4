# Contract Intelligence V4 — Repository Map & Code Liveness Analysis

**Report**: 2 of N  
**Date**: 2026-07-26  
**Author**: Genie Code (automated audit assistant)  
**Status**: COMPLETE  
**Depends on**: Report 1 (scoping)

---

## 1. Confirmed Entry Points

| Entry Point | File | Mechanism | Evidence |
|---|---|---|---|
| **Databricks App (production)** | `app/main.py` | `app.yaml` → `uvicorn app.main:app --host 0.0.0.0 --port 8000` | app.yaml line 11 |
| **Notebook standalone** | `platform/v4/runtime/notebook_entry.py` | `init_runtime_standalone(spark=spark)` | notebook_entry.py:62 |
| **Build & Deploy** | `build_and_deploy.py` | `exec(open(...).read())` from notebook cell | build_and_deploy.py:12 (dev-only) |
| **Test harness** | `conftest.py` | pytest auto-discovery | conftest.py:1 |

The `init_runtime_api()` function (notebook_entry.py:134) is **NOT** called by `main.py`. Instead, `main.py:_lifespan_init()` replicates its logic with `WarehouseSpark` instead of `DatabricksSession`. This was an intentional divergence (comment at line 233).

---

## 2. Active Dependency Graph (from `app/main.py`)

```
app.yaml
└── uvicorn app.main:app
    └── app/main.py (create_app + lifespan)
        ├── app/sql_client.py (WarehouseSpark)
        ├── app/middleware/circuit_breaker.py
        └── _lifespan_init()
            ├── platform.v4.runtime.databricks_llm_client.DatabricksLLMClient
            ├── platform.v4.services.vector_search_service.VectorSearchService
            ├── platform.v4.config.workspace_config.WorkspaceConfig
            ├── platform.v4.config.settings.Settings
            ├── platform.v4.core.current_effective_filter.CurrentEffectiveFilter
            ├── platform.v4.services.retrieval_service.build_retrieval_service
            ├── platform.v4.data.telemetry_repo.TelemetryRepo
            ├── platform.v4.core.provenance.ProvenanceResolver
            ├── platform.v4.services.provider_service.ProviderService
            ├── platform.v4.tools.genie_query.GenieClient
            ├── platform.v4.services.telemetry_writer.TelemetryWriter
            ├── platform.v4.data.session_repo.SessionRepo
            ├── platform.v4.data.feedback_repo.FeedbackRepo
            └── platform.v4.runtime.notebook_entry.init_runtime()
                └── NotebookRuntime()
                    ├── platform.v4.core.question_router.QuestionRouter
                    ├── platform.v4.core.response_assembler.ResponseAssembler
                    ├── platform.v4.adapters.legacy_branch_adapter.LegacyBranchAdapter
                    ├── platform.v4.adapters.retrieval_adapter.RetrievalAdapter
                    ├── platform.v4.adapters.citation_adapter.CitationAdapter
                    ├── platform.v4.adapters.provider_adapter.ProviderAdapter
                    ├── platform.v4.core.context_manager.ContextManager
                    ├── platform.v4.core.cost_controller.CostController
                    ├── platform.v4.data.schema_context_builder.SchemaContextBuilder
                    ├── platform.v4.core.agent_controller.AgentController
                    │   ├── platform.v4.core.hallucination_guard.HallucinationGuard
                    │   ├── platform.v4.core.answer_validator.AnswerValidator
                    │   ├── platform.v4.services.answer_grounding.AnswerGroundingEnforcer
                    │   └── platform.v4.core.question_decomposer.QuestionDecomposer
                    └── ToolRegistry._build_registry() → 25 registered tools
                        ├── sql_query (SqlQueryTool)
                        ├── calculate (CalculateTool)
                        ├── provider_lookup (ProviderLookupTool)
                        ├── passage_search (PassageSearchTool)
                        ├── citation_verify (CitationVerifyTool)
                        │   └── platform.v4.services.verification.citation_verifier
                        ├── document_fetch (DocumentFetchTool)
                        ├── summarize (SummarizeTool)
                        ├── draft_text (DraftTextTool)
                        ├── chart_generate (ChartGenerateTool)
                        ├── export_data (ExportDataTool)
                        ├── genie_query (GenieQueryTool)
                        │   └── platform.v4.services.polling
                        ├── provider_deep_dive (ProviderDeepDiveTool)
                        ├── temporal_analysis (TemporalAnalysisTool)
                        ├── rate_query (RateQueryTool)
                        ├── field_extraction (FieldExtractionTool)
                        ├── clause_existence (ClauseExistenceTool)
                        │   └── platform.v4.tools.clause_existence/ (5 sub-modules)
                        │       ├── classifier.py
                        │       ├── passage_retrieval.py
                        │       ├── rescue.py
                        │       ├── taxonomy_builder.py
                        │       └── revalidation.py
                        ├── explanation (ExplanationTool)
                        ├── multi_concept (MultiConceptTool)
                        ├── comparison (ComparisonTool)
                        ├── risk_alert (RiskAlertTool)
                        ├── financial_analysis (FinancialAnalysisTool)
                        ├── system_membership (SystemMembershipTool)
                        ├── compliance_query (ComplianceQueryTool)
                        ├── clause_text (ClauseTextTool)
                        └── provenance (ProvenanceTool)
```

**Shared services consumed by multiple tools:**
* `platform.v4.services.text_utils` — used by multi_concept, retrieval_service, answer_grounding, evidence_gate
* `platform.v4.services.concepts` — used by taxonomies.py, clause_existence/classifier, clause_existence/rescue, clause_existence/taxonomy_builder
* `platform.v4.services.recall_boost` — used by retrieval_service (indirectly by passage_search)
* `platform.v4.services.rate_query_templates` — used by rate_query tool
* `platform.v4.services.sql_helpers` — used by sql_query tool
* `platform.v4.services.verification.evidence_gate` — used by answer_grounding

---

## 3. Complete Repository Classification

### 3.1 Confirmed Active Runtime Code (deployed to Databricks App)

| Path | Role | Files |
|---|---|---|
| `app/main.py` | FastAPI application, all REST endpoints | 1 |
| `app/sql_client.py` | WarehouseSpark SQL client (Statement Execution API) | 1 |
| `app/__init__.py` | Package marker | 1 |
| `app/middleware/circuit_breaker.py` | Circuit breaker for SQL/VS/LLM | 1 |
| `app/middleware/__init__.py` | Package marker | 1 |
| `platform/__init__.py` | stdlib shadow fix + V3→V4 finder | 1 |
| `platform/v4/__init__.py` | Package marker | 1 |
| `platform/v4/core/` (all 12 files) | Agent controller, router, decomposer, guards, assembler, context, cost, provenance, current_effective_filter | 12 |
| `platform/v4/tools/` (26 tool files + base.py + registry.py + __init__.py) | All tool implementations | 29 |
| `platform/v4/tools/clause_existence/` (5 sub-modules + __init__) | Clause existence pipeline | 6 |
| `platform/v4/services/` (13 active files) | vector_search, retrieval, provider, citation_validator, answer_grounding, sql_helpers, rate_query_templates, text_utils, recall_boost, polling, concepts, telemetry_writer | 13 |
| `platform/v4/services/verification/` (3 files) | citation_verifier, evidence_gate | 3 |
| `platform/v4/config/` (all 6 files) | settings, tool_policies, table_whitelist, workspace_config, taxonomies | 6 |
| `platform/v4/data/` (5 active files) | schema_context_builder, session_repo, telemetry_repo, feedback_repo | 5 |
| `platform/v4/runtime/databricks_llm_client.py` | LLM REST client | 1 |
| `platform/v4/runtime/notebook_entry.py` | NotebookRuntime, init_runtime | 1 |
| `platform/v4/runtime/__init__.py` | Package marker | 1 |
| `platform/v4/contracts/` (all 8 files) | Type definitions (agent_types, tool_types, etc.) | 8 |
| `platform/v4/presentation/` (5 files) | report_builder, html_renderer, excel_export, report_validator | 5 |
| `app.yaml` | Databricks App manifest | 1 |
| `requirements.txt` | Python dependencies | 1 |
| `.databricksignore` | Deployment exclusions | 1 |
| `.gitignore` | VCS exclusions | 1 |

**Total confirmed active runtime files: ~100**

### 3.2 Deployed/Generated Frontend Artifacts

| Path | Role |
|---|---|
| `app/static/index.html` | Vite-built React SPA entry |
| `app/static/assets/index-B8LL3Jxg.js` | Bundled JS (hashed filename) |
| `app/static/assets/index-BeP-Lfd3.css` | Bundled CSS (hashed filename) |

### 3.3 Frontend Source (development only, excluded from deploy)

| Path | Role | Files |
|---|---|---|
| `frontend/src/main.tsx` | React entry point | 1 |
| `frontend/src/App.tsx` | Router/layout | 1 |
| `frontend/src/pages/` | 8 page components (ChatPageV2, ProviderExplorerV2, etc.) | 8 |
| `frontend/src/hooks/` | Custom React hooks | TBD |
| `frontend/src/services/` | API client services | TBD |
| `frontend/src/types/` | TypeScript type definitions | TBD |
| `frontend/src/styles/` | CSS/Tailwind styles | TBD |
| `frontend/package.json`, `vite.config.ts`, etc. | Build configuration | 7 |

### 3.4 Development-Only / Build Tools

| Path | Role | Classification |
|---|---|---|
| `build_and_deploy.py` | Frontend build + Databricks Apps deploy script | Development-only |
| `conftest.py` | pytest shared fixtures and markers | Development-only |
| `uv` | Shell script (likely uv package manager bootstrap) | Development-only |
| `README.md` | Project documentation | Documentation |

### 3.5 Test/Evaluation Assets

| Path | Files | Classification |
|---|---|---|
| `platform/v4/tests/` (37 test files) | Unit tests for tools, services, adapters | Test (excluded from deploy) |
| `tests/pipeline/` (5 test files + fixtures) | Pipeline unit tests for src/ modules | Test (excluded from deploy) |
| `Contract_Intelligence_Comprehensive_Test_Suite` (notebook, 132 cells) | Integration/regression test suite | Evaluation |

### 3.6 Documentation

| Path | Files |
|---|---|
| `docs/` (8 files) | Architecture, data model, ER diagram, roadmap, business overview |
| `platform/v4/README.md` | Platform layer README |
| `Chat Sessions/session_dc18b5f4.md` | Exported demo session |

### 3.7 Pipeline / Ingestion (out of scope, excluded from deploy)

| Path | Files | Classification |
|---|---|---|
| `pipeline/` (26 files) | DDL, state engine, chunking, retrieval, evaluation notebooks | OCR/ingestion out-of-scope |
| `pipelines/service_category_normalization` | Recent normalization notebook | Development-only pipeline |

### 3.8 OCR/Extraction Library (out of scope)

| Path | Files | Classification |
|---|---|---|
| `src/validation.py` | Contract extraction validation rules | OCR/ingestion out-of-scope |
| `src/chunking.py` | Legal text chunking logic | OCR/ingestion out-of-scope |
| `src/json_repair.py` | LLM JSON output repair | OCR/ingestion out-of-scope |
| `src/__init__.py` | Package marker | OCR/ingestion out-of-scope |

---

## 4. Dead / Duplicate / Likely-Dead Code Register

| # | Path | Symbol | Evidence | References | Confidence | Removal Risk | Action |
|---|---|---|---|---|---|---|---|
| D-1 | `platform/v4/tools/amendment_chain.py` | `AmendmentChainTool` | NOT registered in `_build_registry()`. Zero imports from any runtime path. Only referenced in architecture docs. | docs only | **HIGH** (95%) | LOW — no runtime callers | **Quarantine** |
| D-2 | `platform/v4/runtime/api_entry.py` | `V4Api` class | Only self-references and doc mentions. `main.py` does NOT import it — uses inline logic instead. `init_runtime_api()` in notebook_entry.py is also unused by main.py. | self + docs | **HIGH** (90%) | LOW — main.py has its own init | **Archive** |
| D-3 | `platform/v4/runtime/async_bridge.py` | `run_sync()` | Only self-references and doc mentions. `main.py` uses `asyncio.to_thread()` + `ThreadPoolExecutor` directly. | self + docs | **HIGH** (90%) | LOW — functionality duplicated in main.py | **Archive** |
| D-4 | `platform/v4/runtime/notebook_stream_handler.py` | `NotebookStreamHandler` | Only self-references and doc mentions. `main.py` implements streaming via `_stream_generator()` directly. `stream_ask()` in NotebookRuntime yields dicts without this handler. | self + docs | **HIGH** (90%) | LOW — streaming is self-contained in notebook_entry + main.py | **Archive** |
| D-5 | `platform/v4/adapters/notebook_compat_adapter.py` | `NotebookCompatAdapter` | Only exported in `adapters/__init__.py`. Not imported by notebook_entry.py or any runtime file. | __init__.py only | **HIGH** (92%) | LOW — not in any call chain | **Quarantine** |
| D-6 | `platform/v4/services/tier_service.py` | `TierService` | Self-referencing only. Not imported by any other file in platform/v4/. | none external | **HIGH** (95%) | LOW — no callers | **Quarantine** |
| D-7 | `platform/v4/core/planning.py` | `Planner`, `Plan`, `PlannedStep` | Exported in `core/__init__.py` but NEVER imported by `agent_controller.py` (which uses `QuestionDecomposer` + `DecompositionPlan` instead). | core/__init__.py only | **HIGH** (90%) | LOW — agent uses decomposer not planner | **Quarantine** |
| D-8 | `platform/v4/data/query_cache_repo.py` | `QueryCacheRepo`, `CacheEntry` | Exported in `data/__init__.py`. Referenced in `config/settings.py` (table name) and `config/table_whitelist.py` (table listed). But NOT wired in `main.py` or `notebook_entry.py`. Never instantiated at runtime. | __init__.py, settings | **MEDIUM** (80%) | LOW — table exists but repo unused | **Investigate** — may be intended future use |
| D-9 | `platform/v4/presentation/report_enrichment.py` | `ReportEnrichment` | Not called from `main.py`, `notebook_entry.py`, or `agent_controller.py`. Only referenced by sibling presentation files. `response_assembler.py` imports `report_builder` but NOT `report_enrichment`. | presentation/__init__.py | **MEDIUM** (75%) | LOW — may be called by report_builder indirectly | **Investigate** |
| D-10 | `platform/v4/runtime/notebook_entry.py:134` | `init_runtime_api()` | Defined but never called. `main.py:233` explicitly documents it "replicates init_runtime_api() logic but uses WarehouseSpark". The actual init path calls `init_runtime()` directly. | main.py comment | **HIGH** (95%) | NONE — dead function, not dead file | **Document as legacy** |
| D-11 | `platform/v4/adapters/legacy_branch_adapter.py` | `LegacyBranchAdapter` | Instantiated in `NotebookRuntime.__init__()` (line 320) but explicitly NOT registered in tool registry (comment at line 663-671: "P4D-DISP-1: Legacy branch tool registration REMOVED"). Only used for `.is_ready` status check. | notebook_entry.py:320, 529, 669 | **MEDIUM** (70%) | LOW — instantiated but functionally inert | **Retain** — minimal cost, provides status info |

---

## 5. Frontend Source → Build Relationship

```
frontend/
├── src/main.tsx           ─┐
├── src/App.tsx             │
├── src/pages/ (8 pages)    │  npm run build
├── src/hooks/              ├─────────────────→  app/static/
├── src/services/           │                     ├── index.html
├── src/types/              │                     └── assets/
├── vite.config.ts          │                         ├── index-B8LL3Jxg.js
├── tailwind.config.js      │                         └── index-BeP-Lfd3.css
├── package.json           ─┘
└── package-lock.json

.databricksignore excludes: frontend/src/, frontend/public/, all config files
Deployed: ONLY app/static/ reaches the Databricks App container
build_and_deploy.py orchestrates: npm ci → npm run build → databricks apps deploy
```

---

## 6. OCR / Ingestion Inventory (out of scope)

These are explicitly excluded from the deployed app via `.databricksignore`:

| Path | Purpose | Deployed? |
|---|---|---|
| `src/validation.py` | Extraction validation functions (page-count, field completeness) | NO |
| `src/chunking.py` | Legal document chunking (is_quality_chunk, merge_short_chunks) | NO |
| `src/json_repair.py` | LLM JSON output repair (truncation, bracket matching) | NO |
| `pipeline/00_config.py` | Pipeline configuration constants | NO |
| `pipeline/01_execute_ddl.py` | Table DDL creation | NO |
| `pipeline/02_state_engine.py` | Extraction state tracking | NO |
| `pipeline/03_reimbursement_migration.py` | Rate migration logic | NO |
| `pipeline/04_legal_chunking.py` | Chunking pipeline | NO |
| `pipeline/05_retrieval_engine.py` | VS index build | NO |
| `pipeline/07_citation_verification.py` | Citation verification pipeline | NO |
| `pipeline/08_intelligence.py` | Intelligence layer build | NO |
| `pipeline/11_evaluation_harness.py` | Evaluation harness | NO |
| `pipeline/12_gold_annotation.py` – `pipeline/20_clause_classification.py` | Various pipeline notebooks | NO |
| `pipeline/run_platform_modules_orchestrator` | Pipeline orchestrator | NO |
| `pipeline/step_0_3_vs_rebuild` | VS rebuild notebook | NO |
| `pipelines/service_category_normalization` | Service category normalization | NO |

---

## 7. Unresolved References

| # | Reference | Where | Issue | Impact |
|---|---|---|---|---|
| U-1 | `logger.warning(...)` at main.py:45 | Pre-warm import block | `logger` not yet defined (defined at line 109). Would crash on pre-warm failure. | LOW — only triggers on import failure in cold start race |
| U-2 | `init_runtime_api()` docstring in notebook_entry.py:146-147 | Shows usage from app/main.py | Stale documentation — main.py no longer calls this function | LOW — misleading for developers |
| U-3 | Architecture doc lists `amendment_chain` as registered tool | `docs/CONTRACT_INTELLIGENCE_V4_APPLICATION_ARCHITECTURE.md:215,1005` | Tool exists but is NOT registered in runtime | MEDIUM — doc/code mismatch |
| U-4 | `_V3Finder` in `platform/__init__.py` | Redirects `platform.v3.*` → `platform.v4.*` | No evidence of any `platform.v3` imports remaining in codebase | LOW — safety net, costs nothing |

---

## 8. Key Architectural Observations

**8.1 `main.py` duplicates init logic rather than calling `init_runtime_api()`**

The Databricks App container does not have `databricks-connect` (per requirements.txt). So `init_runtime_api()` (which uses `DatabricksSession`) cannot work in the deployed container. `main.py` correctly uses `WarehouseSpark` (Statement Execution API) instead. However, `init_runtime_api()` remains in the codebase as dead code — it was the intended path before the WarehouseSpark approach was adopted.

**8.2 LegacyBranchAdapter is instantiated but functionally inert**

It's created with `dispatch_fn=None` (line 320, since `init_runtime()` is always called with `dispatch_fn=None` from main.py). Its only runtime visibility is `self.branch_adapter.is_ready` in `status()`. The adapter's `is_ready` property returns `True` only if `dispatch_fn is not None`, so it always returns `False` in current deployment.

**8.3 `agent_controller.py` is extremely large (~5000+ lines)**

Contains what appears to be multiple versions of the `run()` method or similar logic (multiple `_maybe_decompose` definitions at lines 4049, 5797, 8187). This needs deeper analysis in a subsequent report to determine if there's duplicated controller logic.

**8.4 Module shadowing fix is complex but necessary**

The `platform/` package shadows Python's stdlib `platform` module. The fix in `platform/__init__.py` + two fix blocks in `main.py` (lines 18-46 and 279-317) ensures both work. This is fragile but functional.

---

## 9. Updated Issue Ledger

| Finding ID | Severity | Category | Status | Title | Evidence | Impact | Recommendation |
|---|---|---|---|---|---|---|---|
| F-001 | LOW | LIVENESS | CONFIRMED | `amendment_chain.py` tool not registered | Not in `_build_registry()`, zero imports | Users cannot access amendment chain tool despite docs claiming it exists | Register or remove; update docs |
| F-002 | LOW | LIVENESS | CONFIRMED | 6 dead runtime files (api_entry, async_bridge, notebook_stream_handler, notebook_compat_adapter, tier_service, planning) | grep analysis shows zero external imports | Code confusion for developers | Quarantine/archive |
| F-003 | LOW | CONSISTENCY | CONFIRMED | Architecture doc lists `amendment_chain` as live tool | docs/...ARCHITECTURE.md:215 | Misleading documentation for evaluation users/developers | Update docs |
| F-004 | LOW | CORRECTNESS | HYPOTHESIS | `logger` reference before definition at main.py:45 | Line 45 uses `logger`, defined at line 109 | Would produce NameError on pre-warm import failure | Move logger definition above pre-warm block |
| F-005 | MEDIUM | LIVENESS | CONFIRMED | `QueryCacheRepo` defined but never wired | Not instantiated in main.py or notebook_entry.py | Query caching not operational (performance, not correctness) | Investigate intent; wire or remove |
| F-006 | MEDIUM | CONSISTENCY | HYPOTHESIS | `agent_controller.py` may contain duplicated method bodies | Multiple `_maybe_decompose` at lines 4049, 5797, 8187 | Potential shadowing or version confusion | Deep-read in Report 3 |
| F-007 | LOW | LIVENESS | CONFIRMED | `LegacyBranchAdapter` instantiated but permanently inert | dispatch_fn=None, .is_ready always False | Misleading status report | Document or remove from status dict |

---

## 10. Summary Statistics

| Category | Count |
|---|---|
| Total files in repository | ~210 |
| Confirmed active runtime (deployed) | ~100 |
| Frontend source (dev-only) | ~16 |
| Tests (excluded from deploy) | ~45 |
| Pipeline/OCR (out of scope, excluded) | ~30 |
| Documentation | ~10 |
| Dead/likely-dead runtime files | 6-9 |
| Registered tools | 25 |
| Unregistered tool files | 1 (`amendment_chain.py`) |
| REST API endpoints in main.py | ~15+ (health, query, sessions, providers, report, concepts, export, documents, alerts, deadlines, compliance, status/metrics, startup-status) |

---

*End of Report 2*