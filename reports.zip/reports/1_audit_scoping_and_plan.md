# Contract Intelligence V4 — Audit Scoping & Plan

**Report**: 1 of N  
**Date**: 2026-07-26  
**Author**: Genie Code (automated audit assistant)  
**Status**: SCOPING COMPLETE — awaiting approval to begin detailed analysis

---

## 1. Objective

Conduct a comprehensive, evidence-based review of the Contract Intelligence V4 application to:

1. **Validate correctness** — verify that structured data, query logic, tool behavior, routing, and answer generation produce trustworthy results for evaluation users.
2. **Assess completeness** — identify gaps in coverage (providers, clause types, rate categories, temporal logic) that could mislead users.
3. **Identify active vs. dead/duplicated code** — determine which files, modules, and paths are live in the current execution flow versus legacy/orphaned.
4. **Make the system understandable** — produce a clear map of how questions flow from user input to grounded, cited answers.
5. **Statistical/data-science validation** — go beyond unit-test PASS/FAIL to measure answer quality distributions, confidence calibration, citation fidelity, and data-model internal consistency.
6. **Create an issue register and roadmap** — separate confirmed defects from hypotheses, rank by impact on evaluation-user trust, and propose a remediation sequence.

This is NOT a production-readiness exercise. Enterprise hardening (HA, RBAC, DR, SLA monitoring) is out of scope unless it directly prevents trustworthy answers or safe evaluation use.

---

## 2. In-Scope Areas

### 2.1 Application Runtime (correctness, routing, answer quality)

| Area | Key Files | What to Validate |
|---|---|---|
| Agent Controller & ReAct loop | `platform/v4/core/agent_controller.py` | Step budget, tool dispatch, error recovery, loop termination |
| Question Router | `platform/v4/core/question_router.py` | Category classification accuracy, routing to correct tool |
| Question Decomposer | `platform/v4/core/question_decomposer.py` | Multi-part question handling, sub-question quality |
| Tool Registry & 25+ tools | `platform/v4/tools/` (all files) | Input validation, SQL generation correctness, output schema consistency |
| Hallucination Guard | `platform/v4/core/hallucination_guard.py` | False-positive/negative rate, bypass conditions |
| Answer Validator | `platform/v4/core/answer_validator.py` | Grounding enforcement, unsupported-claim detection |
| Response Assembler | `platform/v4/core/response_assembler.py` | Citation attachment, confidence assignment, formatting |
| Context Manager | `platform/v4/core/context_manager.py` | Session continuity, multi-turn memory, context window management |
| Current-Effective Filter | `platform/v4/core/current_effective_filter.py` | Temporal logic for current vs. superseded rates/docs |
| Provenance | `platform/v4/core/provenance.py` | Source-document traceability |

### 2.2 Data Model (29-31 production tables in `dev_adb.raw`)

| Domain | Tables | Key Risks |
|---|---|---|
| Rates | `tbl_contract_rates_all` | Temporal logic, supersession correctness, rate_unit taxonomy, numeric plausibility |
| Documents | `tbl_contract_documents_master`, `tbl_contract_hierarchy` | Status classification, amendment ordering, FK integrity |
| Vector Search | `tbl_vs_unified_ready` | Chunk coverage, is_current flag accuracy, embedding freshness |
| Clauses | `tbl_contract_clauses` | Category coverage, clause text fidelity, provider linkage |
| DOFR | `tbl_dofr_matrix_extracted` | Boolean responsibility columns, service category normalization |
| Delegation | `tbl_delegation_matrix` | Function taxonomy, provider coverage |
| Compliance | `tbl_compliance_tracking` | Status distribution, regulation coverage |
| Risk/Alerts | `tbl_contract_risk_scores`, `tbl_alert_queue` | Score derivation logic, alert priority accuracy |
| Financial | `tbl_financial_exposure`, `tbl_repricing_scenarios` | Exposure calculations, scenario plausibility |
| Dimensions | `dim_provider_canonical`, `dim_health_system`, `tbl_provider_system_membership`, `tbl_service_areas` | Referential integrity, canonical ID coverage |
| Provenance | `tbl_extraction_provenance`, `fact_supersession` | Extraction lineage, supersession audit trail |
| Temporal | `tbl_contract_deadlines`, `tbl_contract_notifications` | Deadline accuracy, notification-to-deadline linkage |
| Telemetry | `tbl_agent_sessions`, `fact_retrieval_telemetry` | Session quality metrics, retrieval performance |

### 2.3 Services Layer

| Service | File | What to Validate |
|---|---|---|
| Vector Search Service | `platform/v4/services/vector_search_service.py` | Query construction, filter logic, score thresholds |
| Retrieval Service | `platform/v4/services/retrieval_service.py` | Recall boost, hybrid search strategy |
| Provider Service | `platform/v4/services/provider_service.py` | Name resolution, fuzzy matching, canonical ID |
| Citation Validator | `platform/v4/services/citation_validator.py` | Citation accuracy, source verification |
| Answer Grounding | `platform/v4/services/answer_grounding.py` | Evidence sufficiency checks |
| SQL Helpers | `platform/v4/services/sql_helpers.py` | Injection prevention, query construction safety |
| Rate Query Templates | `platform/v4/services/rate_query_templates.py` | Template correctness, parameter binding |

### 2.4 Configuration & Policies

| File | What to Validate |
|---|---|
| `platform/v4/config/settings.py` | Model names, timeouts, budget limits, thresholds |
| `platform/v4/config/table_whitelist.py` | Whitelist completeness vs. actual tables |
| `platform/v4/config/tool_policies.py` | Tool-level guards, cost limits |
| `platform/v4/config/taxonomies.py` | Enum definitions match live data |

### 2.5 API Gateway & Frontend Integration

| Component | Files | What to Validate |
|---|---|---|
| FastAPI main | `app/main.py` | Endpoint coverage, error handling, streaming, lifespan init |
| SQL client | `app/sql_client.py` | Connection management, query execution |
| Middleware | `app/middleware/` | PII redaction, NaN handling, rate limiting |
| Frontend build | `frontend/` | Build integrity, API contract alignment |

### 2.6 Test Suite Validation

| Component | Location | What to Validate |
|---|---|---|
| Comprehensive test notebook | `Contract_Intelligence_Comprehensive_Test_Suite` (132 cells) | Known-fact accuracy, judge criteria quality, coverage gaps |
| Unit tests | `platform/v4/tests/` (37 test files) | Coverage, mock vs. live boundaries, assertion quality |
| Pipeline tests | `tests/pipeline/` | Pipeline validation coverage |

### 2.7 Code Liveness Analysis

Determine for each module whether it is:
- **ACTIVE**: Called in the live request path
- **ACTIVE-SUPPORT**: Called by tests, monitoring, or pipeline but not user requests
- **DEAD**: Not imported or called anywhere
- **DUPLICATED**: Functionality overlaps with another active module

---

## 3. Out-of-Scope Areas

| Area | Reason |
|---|---|
| OCR pipeline (`Contract_Codification_Pipeline/`) | Upstream ingestion; assume structured data exists |
| PDF parsing & document extraction | Same — upstream |
| Production hardening (HA, DR, multi-region) | Not needed for controlled evaluation |
| Enterprise RBAC / fine-grained permissions | Not needed for controlled evaluation |
| SLA monitoring / alerting infrastructure | Not needed for controlled evaluation |
| Performance optimization / cost reduction | Unless it directly causes timeouts or wrong answers |
| Data migration / re-ingestion | Unless current data is corrupt |
| Frontend UX polish | Unless it prevents evaluation users from understanding answers |
| Client data export or external sharing | Prohibited by policy |

---

## 4. Documents & Repository Areas to Inspect

### 4.1 Architecture & Data Model Documentation

| Document | Path | Purpose |
|---|---|---|
| Business Overview | `docs/CONTRACT_INTELLIGENCE_V4_BUSINESS_OVERVIEW.md` | Business context, user personas, value proposition |
| Application Architecture | `docs/CONTRACT_INTELLIGENCE_V4_APPLICATION_ARCHITECTURE.md` | 5-layer stack, file map, tool arsenal, validation stack |
| Strategic Response & Roadmap | `docs/CONTRACT_INTELLIGENCE_STRATEGIC_RESPONSE_AND_ROADMAP.md` | Meeting context, provisioning, productionalization plan |
| Data Model Production State | `docs/DATA_MODEL_PRODUCTION_STATE.md` | 31 production tables, audit state, known exceptions |
| Data Model Complete State | `docs/DATA_MODEL_COMPLETE_STATE.md` | Full schema including excluded tables |
| ER Diagram | `docs/ER_DIAGRAM.md` | Relationship map |
| Table Inventory Grouped | `docs/TABLE_INVENTORY_GROUPED.md` | Grouped table reference |
| Data SLO | `docs/DATA_SLO.md` | Quality targets |

### 4.2 Prior Audit Notebooks (Phase 0–4)

| Phase | Notebook ID | Key Findings to Verify |
|---|---|---|
| Phase 0 | `2609828668019380` | PDF inventory, OCR checkpoint, JSON extract schema validation |
| Phase 1 | `2609828668019386` | Core table structural validation |
| Phase 2 | `4434698321219714` | Deep data quality, duplicate removal, rate taxonomy |
| Phase 3 | `4434698321219854` | Cross-table integrity, supersession logic |
| Phase 4 | `4434698321219862` | Debt closure, regression sentinels, VS search validation |

### 4.3 Core Application Code (Priority Order)

1. `platform/v4/core/agent_controller.py` — the brain
2. `platform/v4/tools/registry.py` — tool dispatch
3. `platform/v4/tools/rate_query.py` — most business-critical tool
4. `platform/v4/tools/sql_query.py` — general SQL execution
5. `platform/v4/tools/clause_existence_tool.py` — clause detection
6. `platform/v4/tools/passage_search.py` — vector retrieval
7. `platform/v4/core/hallucination_guard.py` — trust layer
8. `platform/v4/core/response_assembler.py` — final answer construction
9. `platform/v4/services/vector_search_service.py` — retrieval engine
10. `platform/v4/config/settings.py` — all tunable parameters
11. `app/main.py` — API gateway and lifespan

### 4.4 Adapters & Legacy Interfaces

- `platform/v4/adapters/legacy_branch_adapter.py` — potential dead code
- `platform/v4/adapters/notebook_compat_adapter.py` — potential dead code
- `src/` directory (`validation.py`, `chunking.py`, `json_repair.py`) — potentially from older version

### 4.5 Pipeline Code (for liveness analysis only)

- `pipeline/` — 25+ files covering DDL, state engine, chunking, retrieval, evaluation
- `pipelines/service_category_normalization` — recent normalization pipeline

---

## 5. Progress Ledger Format

All findings will be tracked in subsequent reports using this structure:

```
| Finding ID | Severity | Category | Status | Title | Evidence | Impact | Recommendation |
|---|---|---|---|---|---|---|---|
| F-001 | CRITICAL/HIGH/MEDIUM/LOW | CORRECTNESS/COMPLETENESS/LIVENESS/UX/CONSISTENCY | CONFIRMED/HYPOTHESIS/RESOLVED | Short title | File:line or query | User-facing impact | Action |
```

**Severity definitions:**
- **CRITICAL**: Produces wrong answers visible to evaluation users, or data corruption risk
- **HIGH**: Significant correctness/completeness gap, but not every query affected
- **MEDIUM**: Quality or consistency issue that reduces trust but doesn't produce wrong answers
- **LOW**: Code cleanliness, documentation gap, or minor inconsistency

**Status definitions:**
- **CONFIRMED**: Verified with at least two independent evidence points
- **HYPOTHESIS**: Suspected from code reading; needs live verification
- **RESOLVED**: Previously identified, now fixed (tracked for completeness)
- **BY-DESIGN**: Intentional behavior documented in DATA_MODEL_PRODUCTION_STATE.md

---

## 6. Blocking Ambiguity

### 6.1 Questions Requiring Clarification Before Detailed Analysis

| # | Question | Why It Matters | Default Assumption If Unanswered |
|---|---|---|---|
| 1 | Which LLM model is currently active in production? (`JUDGE_MODEL` in test suite = `databricks-claude-sonnet-4-6`; architecture doc says Claude Sonnet 4.6) | Model capabilities affect routing strategy and hallucination patterns | Assume `databricks-claude-sonnet-4-6` is the production model |
| 2 | Is the Databricks App currently deployed and serving users, or is this a dev-only environment? | Affects whether we can observe live telemetry vs. must rely on test-suite simulation | Assume dev environment with historical telemetry in `tbl_agent_sessions` |
| 3 | Are the 37 unit test files in `platform/v4/tests/` currently passing? | Determines baseline stability | Will attempt to run and verify |
| 4 | Is the `src/` directory (`validation.py`, `chunking.py`, `json_repair.py`) actively used by the V4 runtime, or is it legacy from V3? | Affects dead-code determination | Treat as potentially dead; verify via import tracing |
| 5 | The test suite references `_lifespan_init` — is this the same init path used in deployed mode? | Test fidelity vs. production behavior | Assume yes; verify in `app/main.py` |

### 6.2 No Hard Blockers Identified

All ambiguities have reasonable default assumptions. Detailed analysis can proceed.

---

## 7. Planned Analysis Sequence

| Phase | Focus | Deliverable |
|---|---|---|
| A | Code liveness analysis — trace imports from `app/main.py` through platform/v4 | Active/dead/duplicated module map |
| B | Agent controller & routing deep-read | Routing accuracy assessment, tool dispatch correctness |
| C | Rate query tool + SQL template validation | SQL correctness for most business-critical answers |
| D | Data model spot-checks (live queries) | Verify Phase 4 sentinel state, check for drift since 2026-07-20 |
| E | Hallucination guard & validation stack | Trust layer effectiveness assessment |
| F | Test suite coverage analysis | Gap identification, known-fact accuracy |
| G | Cross-cutting: confidence calibration, citation fidelity | Statistical quality metrics |
| H | Issue register consolidation | Final ranked findings with roadmap |

---

## 8. Prior Audit Summary (Input, Not Truth)

The prior audit (Phases 0–4, with Phase 9 prompt defining deep-audit expectations) established:

- **Phase 0**: 10,518 files in volume, 597 provider folders, JSON extracts covering 10,350 files
- **Phase 1**: Core table structural validation
- **Phase 2**: 88,596 duplicate rates removed, rate_unit taxonomy standardized, temporal logic established
- **Phase 3**: Cross-table integrity, supersession chain validation, FK orphan policies
- **Phase 4**: All 8 regression sentinels PASS, 18-table row counts verified, 7 DEBT items from Phase 3 addressed
- **Phase 9 prompt**: Defines 11 mandatory audit axes for every table, table-specific deep checks

**Key findings from prior audit that affect current review:**
1. Rate temporal logic (current/superseded) was re-labeled on 2026-07-20 — verify this is correctly reflected
2. 121,403 NULL `superseded_by` rows are by-design (terminal versions)
3. `responsible_party` column removed from DOFR; three boolean columns are canonical
4. NON_COMPLIANT count = 0 in compliance table (confirmed, not a defect)
5. `is_latest_version` column confirmed absent from production tables
6. 22 NULL `bonus_pct` rows in quality_performance are genuine data gaps (external input needed)

Each of these will be independently verified in the detailed analysis phases.

---

## 9. Conventions

- **No code modifications** will be made during this audit
- **All findings cite exact files, classes, functions, and line numbers** where applicable
- **LLM self-confidence ≠ statistical confidence** — successful SQL execution or high confidence scores are not proof of correctness
- **Reports are numbered sequentially** (1, 2, 3...) in `/reports/`
- **Each report is self-contained** but references prior reports for context

---

*End of Report 1*