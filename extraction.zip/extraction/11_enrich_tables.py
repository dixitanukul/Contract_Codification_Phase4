# Databricks notebook source
# DBTITLE 1,Enrich Tables Overview
# MAGIC %md
# MAGIC # 11 — Post-Build Data Quality Enrichment
# MAGIC **Applies 13 idempotent DQ steps across all base tables after initial build.**
# MAGIC
# MAGIC | # | Step | Tables Affected |
# MAGIC |---|------|----------------|
# MAGIC | 1 | effective_date → DATE | rates, documents, clauses, services |
# MAGIC | 2 | doc_category + amendment_depth | documents_master |
# MAGIC | 3 | reimbursement_pct normalized 0-100 | rates_all |
# MAGIC | 4 | STRING → DOUBLE/BOOLEAN casts | rates, financial_protections |
# MAGIC | 5 | is_latest_version computed | rates, clauses, services |
# MAGIC | 6 | canonical_provider_id added | all 8 base tables |
# MAGIC | 7 | rate_count backfilled | documents_master |
# MAGIC | 8 | Null dates recovered from metadata | documents_master |
# MAGIC | 9 | Empty columns dropped | all tables |
# MAGIC | 10 | v6_coverage_pct normalized 0.0–1.0 | documents_master |
# MAGIC | 11 | has_full_clause_text repaired | documents_master |
# MAGIC | 12 | Pre-1990 hallucinated dates nulled | rates, documents |
# MAGIC | 13 | Typed auxiliary columns (_int, _parsed) | rates, financial_protections |
# MAGIC
# MAGIC **Dependency:** All base tables + `dim_provider_canonical` must exist first.  
# MAGIC **Run after:** `10_build_documents`  
# MAGIC **Run before:** `12_build_genie`

# COMMAND ----------

# DBTITLE 1,Load Shared Config
# MAGIC %run ./_config

# COMMAND ----------

# DBTITLE 1,13-Step Post-Build Data Quality Enrichment
# ═══════════════════════════════════════════════════════════════════════════════
# STEP 11c-enrich: POST-BUILD DATA QUALITY ENRICHMENT
#   Runs AFTER all base tables + dim_provider_canonical are built.
#   Applies production-grade fixes to every base table in one pass:
#     1. Parse effective_date STRING → DATE (all tables)
#     2. Compute doc_category + amendment_depth + doc_role (documents_master)
#     3. Normalize reimbursement_pct to 0-100 scale (financial_protections)
#     4. Cast STRING factors to DOUBLE/BOOLEAN (regional_factors, financial_protections)
#     5. Compute is_latest_version (financial_protections, codes_events, services_quality)
#     6. Add canonical_provider_id to all 8 base tables (via dim_provider_canonical)
#     7. Backfill rate_count from actual rates data (documents_master)
#     8. [V7] Backfill null effective_date_parsed in rates from documents_master
#     9. [V7] Drop empty columns from documents_master (columns 100% null)
#   DEPENDENCY: Step 11c-resolve (dim_provider_canonical must exist)
#   IDEMPOTENT: Safe to re-run — uses ADD COLUMN IF NOT EXISTS + MERGE
# ═══════════════════════════════════════════════════════════════════════════════
import time

print("\n" + "═"*80)
print("  ▶ STEP 11c-enrich: POST-BUILD DATA QUALITY ENRICHMENT")
print("═"*80)

SCHEMA = "dev_adb.raw"
t0 = time.time()

# ─── Helper: Add column safely ───
def add_col(table, col, dtype):
    try:
        spark.sql(f"ALTER TABLE {table} ADD COLUMN {col} {dtype}")
    except Exception as e:
        if "already exists" not in str(e).lower() and "FIELDS_ALREADY_EXISTS" not in str(e):
            raise

# ─── Helper: Multi-format date parser SQL ───
DATE_PARSE_EXPR = """COALESCE(
  TRY_TO_DATE({col}, 'yyyy-MM-dd'),
  TRY_TO_DATE({col}, 'MM/dd/yyyy'),
  TRY_TO_DATE({col}, 'MMMM dd, yyyy'),
  TRY_TO_DATE({col}, 'MMMM d, yyyy'),
  TRY_TO_DATE({col}, 'MMM dd, yyyy'),
  TRY_TO_DATE({col}, 'MMM d, yyyy'),
  TRY_TO_DATE({col}, 'MMMM dd yyyy'),
  TRY_TO_DATE({col}, 'MM-dd-yyyy'),
  TRY_CAST({col} AS DATE)
)"""

# ═══════════════════════════════════════════════════════════════════════════════
# 1. PARSE EFFECTIVE_DATE → DATE across all tables with date columns
# ═══════════════════════════════════════════════════════════════════════════════
print("\n  ── 1/9: Parsing effective_date → DATE ──")

date_tables = [
    (f"{SCHEMA}.tbl_contract_documents_master", ["effective_date", "expiration_date"]),
    (f"{SCHEMA}.tbl_contract_rates_all", ["effective_date"]),
    (f"{SCHEMA}.tbl_contract_regional_factors", ["effective_date"]),
    (f"{SCHEMA}.tbl_contract_financial_protections", ["effective_date"]),
]

for table, cols in date_tables:
    tname = table.split('.')[-1]
    for col in cols:
        parsed_col = f"{col}_parsed"
        add_col(table, parsed_col, "DATE")
        expr = DATE_PARSE_EXPR.format(col=col)
        spark.sql(f"UPDATE {table} SET {parsed_col} = {expr} WHERE {col} IS NOT NULL")
    print(f"    ✅ {tname}: {len(cols)} date column(s) parsed")

# ═══════════════════════════════════════════════════════════════════════════════
# 2. COMPUTE doc_category + amendment_depth + doc_role (documents_master)
# ═══════════════════════════════════════════════════════════════════════════════
print("\n  ── 2/9: Computing doc_category + amendment_depth ──")

dm = f"{SCHEMA}.tbl_contract_documents_master"
for col, dtype in [('doc_category', 'STRING'), ('amendment_depth', 'INT')]:
    add_col(dm, col, dtype)

spark.sql(f"""
UPDATE {dm}
SET 
  doc_category = CASE
    WHEN document_type ILIKE '%BaseAgmt%' THEN 'base_agreement'
    WHEN document_type ILIKE '%Amend%' AND document_type NOT ILIKE '%CM%' THEN 'amendment'
    WHEN document_type ILIKE '%CM%' THEN 'cover_memo'
    WHEN document_type ILIKE '%Settlement%' OR amendment_order = 900 THEN 'settlement'
    WHEN document_type ILIKE '%LRA%' OR document_type ILIKE '%ACO%' OR amendment_order = 500 THEN 'lra_aco'
    WHEN amendment_order = 800 THEN 'letter_of_agreement'
    ELSE 'other'
  END,
  amendment_depth = CASE WHEN amendment_order BETWEEN 0 AND 99 THEN CAST(amendment_order AS INT) ELSE NULL END,
  doc_role = CASE
    WHEN document_type ILIKE '%BaseAgmt%' THEN 'base_agreement'
    WHEN document_type ILIKE '%Amend%' AND document_type NOT ILIKE '%CM%' THEN 'amendment'
    WHEN document_type ILIKE '%CM%' THEN 'cover_memo'
    WHEN document_type ILIKE '%Settlement%' OR amendment_order = 900 THEN 'settlement'
    WHEN document_type ILIKE '%LRA%' OR document_type ILIKE '%ACO%' OR amendment_order = 500 THEN 'lra_aco'
    WHEN amendment_order = 800 THEN 'letter_of_agreement'
    ELSE 'other'
  END
""")
print("    ✅ doc_category, amendment_depth, doc_role populated")

# ═══════════════════════════════════════════════════════════════════════════════
# 3. NORMALIZE reimbursement_pct_numeric → 0-100 scale
# ═══════════════════════════════════════════════════════════════════════════════
print("\n  ── 3/9: Normalizing reimbursement_pct ──")

fp = f"{SCHEMA}.tbl_contract_financial_protections"
add_col(fp, "reimbursement_pct_normalized", "DOUBLE")

spark.sql(f"""
UPDATE {fp}
SET reimbursement_pct_normalized = CASE
  WHEN reimbursement_pct_numeric > 0 AND reimbursement_pct_numeric <= 1.0 THEN ROUND(reimbursement_pct_numeric * 100, 2)
  WHEN reimbursement_pct_numeric > 1 AND reimbursement_pct_numeric <= 100 THEN ROUND(reimbursement_pct_numeric, 2)
  WHEN reimbursement_pct_numeric > 100 THEN NULL
  ELSE reimbursement_pct_numeric
END
WHERE reimbursement_pct_numeric IS NOT NULL
""")
print("    ✅ reimbursement_pct_normalized (0-100 scale)")

# ═══════════════════════════════════════════════════════════════════════════════
# 4. CAST type mismatches: STRING → DOUBLE/BOOLEAN
# ═══════════════════════════════════════════════════════════════════════════════
print("\n  ── 4/9: Casting type mismatches ──")

rf = f"{SCHEMA}.tbl_contract_regional_factors"
for col, dtype in [('outpatient_surgical_factor_num','DOUBLE'), ('practice_expense_factor_num','DOUBLE'),
                   ('malpractice_factor_num','DOUBLE'), ('is_latest_version_bool','BOOLEAN')]:
    add_col(rf, col, dtype)

spark.sql(f"""
UPDATE {rf} SET
  outpatient_surgical_factor_num = TRY_CAST(outpatient_surgical_factor AS DOUBLE),
  practice_expense_factor_num = TRY_CAST(practice_expense_factor AS DOUBLE),
  malpractice_factor_num = TRY_CAST(malpractice_factor AS DOUBLE),
  is_latest_version_bool = TRY_CAST(is_latest_version AS BOOLEAN)
""")

add_col(fp, "has_stop_loss_bool", "BOOLEAN")
spark.sql(f"UPDATE {fp} SET has_stop_loss_bool = TRY_CAST(has_stop_loss AS BOOLEAN) WHERE has_stop_loss IS NOT NULL")
print("    ✅ regional factors cast to DOUBLE, booleans cast")

# ═══════════════════════════════════════════════════════════════════════════════
# 5. COMPUTE is_latest_version (3 tables where it was NULL)
# ═══════════════════════════════════════════════════════════════════════════════
print("\n  ── 5/9: Computing is_latest_version ──")

spark.sql(f"""
CREATE OR REPLACE TEMP VIEW v_latest_docs AS
SELECT provider_id, source_filename
FROM (
  SELECT provider_id, source_filename,
    ROW_NUMBER() OVER (
      PARTITION BY provider_id 
      ORDER BY CASE WHEN amendment_order < 100 THEN amendment_order ELSE 0 END DESC,
        effective_date_parsed DESC NULLS LAST
    ) AS rn
  FROM {dm}
) WHERE rn = 1
""")

for table in [fp, f"{SCHEMA}.tbl_contract_codes_events", f"{SCHEMA}.tbl_contract_services_quality"]:
    tname = table.split('.')[-1]
    spark.sql(f"""
    UPDATE {table} t
    SET is_latest_version = CASE 
      WHEN EXISTS (SELECT 1 FROM v_latest_docs ld WHERE ld.provider_id = t.provider_id AND ld.source_filename = t.source_filename)
      THEN 'true' ELSE 'false'
    END
    """)
    print(f"    ✅ {tname}: is_latest_version populated")

# ═══════════════════════════════════════════════════════════════════════════════
# 6. ADD canonical_provider_id to all 8 base tables
# ═══════════════════════════════════════════════════════════════════════════════
print("\n  ── 6/9: Adding canonical_provider_id ──")

base_tables = [
    f"{SCHEMA}.tbl_contract_documents_master",
    f"{SCHEMA}.tbl_contract_rates_all",
    f"{SCHEMA}.tbl_contract_regional_factors",
    f"{SCHEMA}.tbl_contract_financial_protections",
    f"{SCHEMA}.tbl_contract_clauses_terms",
    f"{SCHEMA}.tbl_contract_codes_events",
    f"{SCHEMA}.tbl_contract_parties",
    f"{SCHEMA}.tbl_contract_services_quality",
]

for table in base_tables:
    tname = table.split('.')[-1]
    add_col(table, "canonical_provider_id", "STRING")
    spark.sql(f"""
    MERGE INTO {table} t
    USING {SCHEMA}.dim_provider_canonical c ON t.provider_id = c.provider_id
    WHEN MATCHED THEN UPDATE SET t.canonical_provider_id = c.primary_provider_id
    """)
    print(f"    ✅ {tname}")

# ═══════════════════════════════════════════════════════════════════════════════
# 7. BACKFILL rate_count from actual rates data
# ═══════════════════════════════════════════════════════════════════════════════
print("\n  ── 7/9: Backfilling rate_count from actual rates ──")

spark.sql(f"""
MERGE INTO {dm} d
USING (
  SELECT source_filename, COUNT(*) AS actual_rate_count
  FROM {SCHEMA}.tbl_contract_rates_all
  GROUP BY source_filename
) r
ON d.source_filename = r.source_filename
WHEN MATCHED THEN UPDATE SET d.rate_count = r.actual_rate_count
""")
# Set to 0 where no rates exist (unmatched docs)
spark.sql(f"UPDATE {dm} SET rate_count = 0 WHERE rate_count IS NULL")
rate_stats = spark.sql(f"""
  SELECT SUM(rate_count) as total_rates,
         SUM(CASE WHEN rate_count > 0 THEN 1 ELSE 0 END) as docs_with_rates
  FROM {dm}
""").collect()[0]
print(f"    ✅ rate_count backfilled: {rate_stats['total_rates']:,} rates across {rate_stats['docs_with_rates']:,} documents")

# ═══════════════════════════════════════════════════════════════════════════════
# 8. [V7] BACKFILL null effective_date_parsed in rates from documents_master
#    Rates with NULL dates inherit the document's effective_date
# ═══════════════════════════════════════════════════════════════════════════════
print("\n  ── 8/9: [V7] Backfilling null effective_date_parsed in rates ──")

rates_tbl = f"{SCHEMA}.tbl_contract_rates_all"
before_null_dates = spark.sql(f"SELECT COUNT(*) FROM {rates_tbl} WHERE effective_date_parsed IS NULL").collect()[0][0]

spark.sql(f"""
MERGE INTO {rates_tbl} r
USING (
  SELECT source_filename, effective_date_parsed AS doc_date
  FROM {dm}
  WHERE effective_date_parsed IS NOT NULL
) d
ON r.source_filename = d.source_filename AND r.effective_date_parsed IS NULL
WHEN MATCHED THEN UPDATE SET r.effective_date_parsed = d.doc_date
""")

after_null_dates = spark.sql(f"SELECT COUNT(*) FROM {rates_tbl} WHERE effective_date_parsed IS NULL").collect()[0][0]
print(f"    ✅ Null dates: {before_null_dates:,} → {after_null_dates:,} (recovered {before_null_dates - after_null_dates:,})")

# ═══════════════════════════════════════════════════════════════════════════════
# 9. [V7] DROP 100%-null columns from documents_master
#    Removes schema bloat — columns that had zero data across all extractions.
#    Safe: if future extractions populate these fields, Step 11c will re-add them.
# ═══════════════════════════════════════════════════════════════════════════════
print("\n  ── 9/9: [V7] Dropping empty columns from documents_master ──")

from pyspark.sql import functions as F

dm_df = spark.table(dm)
total_rows = dm_df.count()

# Identify columns that are 100% null
empty_cols = []
for col_name in dm_df.columns:
    null_ct = dm_df.filter(F.col(col_name).isNull()).count()
    if null_ct == total_rows:
        empty_cols.append(col_name)

if empty_cols:
    # Keep only populated columns
    keep_cols = [c for c in dm_df.columns if c not in empty_cols]
    dm_df.select(keep_cols).write.mode("overwrite").option("overwriteSchema", "true").saveAsTable(dm)
    print(f"    ✅ Dropped {len(empty_cols)} empty columns, kept {len(keep_cols)}")
    print(f"    Dropped: {', '.join(empty_cols[:10])}{'...' if len(empty_cols)>10 else ''}")
else:
    print("    ✅ No empty columns found (all populated)")

# ═══════════════════════════════════════════════════════════════════════════════
elapsed = time.time() - t0
print(f"\n  ✅ POST-BUILD ENRICHMENT COMPLETE ({elapsed:.0f}s)")
print(f"    • Dates parsed across 4 tables")
print(f"    • doc_category/amendment_depth computed")
print(f"    • reimbursement_pct normalized to 0-100")
print(f"    • Type casts applied (DOUBLE/BOOLEAN)")
print(f"    • is_latest_version computed for 3 tables")
print(f"    • canonical_provider_id added to all 8 base tables")
print(f"    • rate_count backfilled from actual rates")
print(f"    • [V7] Null dates recovered from document metadata")
print(f"    • [V7] Empty columns dropped from documents_master")

# ═══════════════════════════════════════════════════════════════════════════════
# 10. [V8] Normalize v6_coverage_pct to 0.0–1.0 scale
# ═══════════════════════════════════════════════════════════════════════════════
print("\n  ── 10/13: v6_coverage_pct normalization ──")
spark.sql(f"""
    UPDATE {SCHEMA}.tbl_contract_documents_master
    SET v6_coverage_pct = v6_coverage_pct / 100.0
    WHERE v6_coverage_pct > 1.0
""")
print("    ✅ v6_coverage_pct normalized to 0.0–1.0 scale")

# ═══════════════════════════════════════════════════════════════════════════════
# 11. [V8] Fix has_full_clause_text (TRUE where clauses exist with >100 chars)
# ═══════════════════════════════════════════════════════════════════════════════
print("  ── 11/13: has_full_clause_text repair ──")
spark.sql(f"""
    UPDATE {SCHEMA}.tbl_contract_documents_master d
    SET has_full_clause_text = TRUE
    WHERE EXISTS (
        SELECT 1 FROM {SCHEMA}.tbl_contract_clauses_terms c
        WHERE c.source_filename = d.source_filename AND LENGTH(c.content_text) > 100
    )
""")
print("    ✅ has_full_clause_text updated based on actual clause content")

# ═══════════════════════════════════════════════════════════════════════════════
# 12. [V8] Null out pre-1990 hallucinated dates
# ═══════════════════════════════════════════════════════════════════════════════
print("  ── 12/13: Pre-1990 date hallucination cleanup ──")
for _tbl in [f"{SCHEMA}.tbl_contract_documents_master", f"{SCHEMA}.tbl_contract_rates_all"]:
    spark.sql(f"UPDATE {_tbl} SET effective_date_parsed = NULL WHERE effective_date_parsed < '1990-01-01'")
print("    ✅ Pre-1990 dates nulled (raw strings preserved for audit)")

# ═══════════════════════════════════════════════════════════════════════════════
# 13. [V8] Add typed _int columns for exhibit/section counts + supersedes date
# ═══════════════════════════════════════════════════════════════════════════════
print("  ── 13/13: Typed auxiliary columns ──")
_dm = f"{SCHEMA}.tbl_contract_documents_master"
for _col, _dtype in [('exhibits_replaced_count_int', 'INT'), ('exhibits_added_count_int', 'INT'),
                     ('sections_modified_count_int', 'INT'), ('supersedes_effective_date_parsed', 'DATE')]:
    add_col(_dm, _col, _dtype)

spark.sql(f"""UPDATE {_dm} SET
    exhibits_replaced_count_int = TRY_CAST(REGEXP_EXTRACT(exhibits_replaced_count, '(\\d+)', 1) AS INT),
    exhibits_added_count_int = TRY_CAST(REGEXP_EXTRACT(exhibits_added_count, '(\\d+)', 1) AS INT),
    sections_modified_count_int = TRY_CAST(REGEXP_EXTRACT(sections_modified_count, '(\\d+)', 1) AS INT),
    supersedes_effective_date_parsed = TRY_CAST(supersedes_effective_date AS DATE)
""")
print("    ✅ _int columns + supersedes_effective_date_parsed populated")

print(f"\n  {'═'*60}")
print(f"  ✅ STEP 11c-enrich COMPLETE in {time.time()-t0:.1f}s")
print(f"    13 DQ enrichments applied across all base tables:")
print(f"    • effective_date → DATE (4 tables)")
print(f"    • doc_category + amendment_depth computed")
print(f"    • reimbursement_pct normalized 0-100")
print(f"    • STRING → DOUBLE/BOOLEAN casts applied")
print(f"    • is_latest_version computed (3 tables)")
print(f"    • canonical_provider_id added (8 tables)")
print(f"    • rate_count backfilled from actual rates")
print(f"    • [V7] Null dates recovered from document metadata")
print(f"    • [V7] Empty columns dropped from documents_master")
print(f"    • [V8] v6_coverage_pct normalized to 0.0-1.0")
print(f"    • [V8] has_full_clause_text repaired")
print(f"    • [V8] Pre-1990 hallucinated dates nulled")
print(f"    • [V8] Typed auxiliary columns added")
print("═"*80)