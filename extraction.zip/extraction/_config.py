# Databricks notebook source
# DBTITLE 1,Pipeline Shared Configuration
# ═══════════════════════════════════════════════════════════════════════════════
# SHARED CONFIG — imported by all extraction notebooks via %run ./_config
# Sets: paths, widgets, logging, NEW_FILES_FOUND flag
# KEEP THIS LIGHTWEIGHT — no heavy I/O. Notebooks handle their own data loading.
# ═══════════════════════════════════════════════════════════════════════════════
import os, sys, json, re, time
from datetime import datetime, timezone

# ─── PATHS ───
BASE_DIR = "/Workspace/Users/adixit01@blueshieldca.com/Contract_Codification_Pipeline/data"
OUTPUT_DIR = f"{BASE_DIR}/json_extract"
DATA_DIR = "/Volumes/prod_adb/default/ext-data-volume-stmlz/Health_Plan_Ops_Transformation/Provider_Contracts"
CHECKPOINT_DIR = f"{BASE_DIR}/checkpoints"
STEP1_FILE = f"{CHECKPOINT_DIR}/step1_parsed_v2.parquet"
STEP2_FILE = f"{CHECKPOINT_DIR}/step2_with_metadata_v2.parquet"

os.makedirs(OUTPUT_DIR, exist_ok=True)
os.makedirs(CHECKPOINT_DIR, exist_ok=True)

# ─── WIDGETS ───
dbutils.widgets.text("force_rebuild", "true", "Force rebuild even if no new files")
dbutils.widgets.text("run_mode", "full", "Run mode: full or sample")
dbutils.widgets.text("num_providers", "5", "Number of providers to sample (sample mode)")

# ─── LOGGING ───
class PipelineLogger:
    def __init__(self, name="pipeline"):
        self.name = name
    def info(self, msg):
        print(f"  [{self.name}] {msg}")
    def warning(self, msg):
        print(f"  [WARN][{self.name}] {msg}")
    def error(self, msg):
        print(f"  [ERROR][{self.name}] {msg}")

pipe_log = PipelineLogger("extraction")

# ─── EXTRACTION QUALITY CONSTANTS ───
PAGE_MARKER = '\n\n--- PAGE_BREAK ---\n\n'       # Separator between pages in full_text
MAX_EMPTY_PAGE_RATIO = 0.15                       # Send to Tier 2 if >15% of pages are empty
MIN_GOOD_CHARS = 500                              # Minimum total chars for Tier 1 acceptance
MIN_CHARS_PER_PAGE = 100                          # Minimum avg chars/page for Tier 1 acceptance
EMPTY_PAGE_THRESHOLD = 50                         # Pages with fewer chars than this are "empty"

def actual_text_length(full_text):
    """Text length excluding page markers (for accurate quality checks)."""
    return len((full_text or '').replace(PAGE_MARKER, '\n\n'))

# ─── LIGHTWEIGHT STATE (no parquet reads — those block on shared compute) ───
file_registry = {}
already_parsed = set()

# Determine NEW_FILES_FOUND from json_extract count vs checkpoint existence
# This is fast — just checks if checkpoint file exists
NEW_FILES_FOUND = not os.path.exists(STEP1_FILE) or (dbutils.widgets.get("force_rebuild") == "true")

pipe_log.info(f"Config loaded | BASE_DIR={BASE_DIR} | force={dbutils.widgets.get('force_rebuild')} | NEW_FILES_FOUND={NEW_FILES_FOUND}")