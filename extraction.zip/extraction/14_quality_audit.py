# Databricks notebook source
# DBTITLE 1,Quality Audit Overview
# MAGIC %md
# MAGIC # 14 — Extraction Quality Audit (LLM-Based)
# MAGIC **Compares raw PDF text against extracted JSON using Claude Sonnet 4.5 to find extraction gaps.**
# MAGIC
# MAGIC | Feature | Description |
# MAGIC |---------|-------------|
# MAGIC | Method | LLM reads PDF text + extracted JSON, reports every missing/wrong field |
# MAGIC | Granularity | Per-gap detail (one row per issue per file) |
# MAGIC | Output | 2 Delta tables: `tbl_extraction_quality_audit` + `tbl_extraction_quality_gaps` |
# MAGIC | Mode | MERGE/UPSERT — re-running on same files updates; previous results preserved |
# MAGIC
# MAGIC **Parameters:**
# MAGIC
# MAGIC | Parameter | Options | Description |
# MAGIC |-----------|---------|-------------|
# MAGIC | `audit_mode` | all, single, sample, providers | Which files to audit |
# MAGIC | `target_file` | filename | Single-file mode target |
# MAGIC | `target_providers` | comma-sep IDs | Provider-mode filter |
# MAGIC | `sample_size` | integer | Random sample count |
# MAGIC
# MAGIC **Run after:** `13_build_serving` (or independently for ad-hoc auditing)  
# MAGIC **Run before:** `15_gap_filler`

# COMMAND ----------

# DBTITLE 1,Load Shared Config
# MAGIC %run ./_config

# COMMAND ----------

# DBTITLE 1,Audit-Specific Configuration and Widgets
# ═══════════════════════════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════════
import os, re, json, time, requests
import pandas as pd
from collections import defaultdict
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed

dbutils.widgets.dropdown("audit_mode", "sample", ["all", "single", "sample", "providers"], "Audit Mode")
dbutils.widgets.text("target_file", "", "Target File (single mode)")
dbutils.widgets.text("target_providers", "", "Provider IDs (comma-sep, providers mode)")
dbutils.widgets.text("sample_size", "20", "Sample Size (sample mode)")

SCHEMA = "dev_adb.raw"
AUDIT_TABLE = f"{SCHEMA}.tbl_extraction_quality_audit"

# LLM Configuration (same model used for extraction)
WORKSPACE_URL = spark.conf.get("spark.databricks.workspaceUrl")
MODEL_ENDPOINT = f"https://{WORKSPACE_URL}/serving-endpoints/databricks-claude-sonnet-4-5/invocations"
TOKEN = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiToken().get()

audit_mode = dbutils.widgets.get("audit_mode")
target_file = dbutils.widgets.get("target_file")
target_providers = dbutils.widgets.get("target_providers")
sample_size = int(dbutils.widgets.get("sample_size"))

print("═" * 80)
print("  ▶ EXTRACTION QUALITY AUDIT — LLM-Based Contextual Comparison")
print(f"  Mode: {audit_mode} | Sample: {sample_size} | Target: {target_file or target_providers or '(auto)'}")
print(f"  Model: databricks-claude-sonnet-4-5")
print(f"  Output: {AUDIT_TABLE}")
print("═" * 80)

# COMMAND ----------

# DBTITLE 1,LLM Audit Prompt - Issue Taxonomy
# ═══════════════════════════════════════════════════════════════════════════════
# STEP 1: LLM AUDIT PROMPT — The exact logic used manually
# ═══════════════════════════════════════════════════════════════════════════════

AUDIT_PROMPT = """You are a contract extraction quality auditor. You will be given:
1. The RAW PDF TEXT of a healthcare provider contract
2. The EXTRACTED JSON that an LLM produced from that PDF

Your job: Compare them section-by-section. For EACH section in the JSON, verify its content against the PDF.
Also scan the PDF for content that should have been extracted but wasn't.

For every gap you find, report it in the structured JSON format below.

CRITICAL INSTRUCTIONS:
- You MUST list EVERY gap individually in the gaps[] array. Do NOT summarize or consolidate.
- If there are 50 gaps, list all 50. If there are 100, list all 100.
- Do NOT set total_gaps_found to a number higher than the actual gaps[] array length.
- Be exhaustive. It is better to list too many gaps than too few.
- Each missing rate, each missing code, each empty field = its OWN gap entry.

Check:
- Are all dollar amounts from the PDF captured in the right rate fields?
- Are dates correct and complete (effective, expiration, execution)?
- Are percentages captured (rate escalations, withhold %, stop-loss %)?
- Are medical/revenue codes captured and correctly classified?
- Are all parties, signatories, and their details (NPI, Tax ID) captured?
- Are exhibit/schedule references complete?
- Is tabular content (rate tables, DOFR matrices, regional factors) fully captured row-by-row?
- Are excluded services, carve-outs, and exceptions listed?
- Are termination conditions, notice periods, and dispute mechanisms captured?
- Are regulatory references (laws, accreditation bodies) enumerated?
- Is the full_clause_text present for key clauses?
- Are there any hallucinated values in the JSON that DON'T exist in the PDF?

Return your analysis as a JSON object with this structure:
```json
{
  "total_hallucinations": <int>,
  "sections_analyzed": <int>,
  "gaps": [
    {
      "section": "<extracted_content key or sub-key like 'outpatient_rates.emergency_services'>",
      "severity": "HIGH|MEDIUM|LOW",
      "gap_type": "missing_value|missing_rows|misclassification|hallucination|truncation|empty_field",
      "description": "<what's in PDF but not in JSON, or what's wrong>",
      "pdf_evidence": "<brief quote or pattern from PDF proving the gap>",
      "json_field": "<specific field path that should contain it>",
      "count": <number of missing items if applicable, else 1>
    }
  ],
  "strengths": ["<things the extraction got right>"],
  "summary": "<2-3 sentence overall assessment>"
}
```

SEVERITY GUIDELINES:
- HIGH: Missing dollar amounts, rates, percentages that affect payment calculations. Missing entire rate tables or service categories. Hallucinated values.
- MEDIUM: Missing codes, NPI/TaxID, dates, operational terms, incomplete rows in tables, missing excluded services lists.
- LOW: Missing administrative details, OCR artifacts, minor formatting issues, empty fields where PDF also lacks content.

Be specific. Don't just say "some rates are missing" — say "15 Max Payment caps ($8K-$94K) in Exhibit C outpatient schedule not captured in outpatient_rates".
Only report genuine gaps. If the JSON correctly excludes something (e.g., insurance limits aren't rates), don't flag it.
"""


def _repair_truncated_json(text):
    """
    Attempt to close a truncated JSON object.
    Same logic as extraction pipeline — handles max_tokens cutoff.
    """
    text = text.strip()
    if text.startswith('```'):
        text = re.sub(r'^```(?:json)?\n?', '', text)
        text = re.sub(r'\n?```$', '', text)
    
    # Try parsing as-is first
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    
    # Count open brackets/braces and close them
    open_braces = text.count('{') - text.count('}')
    open_brackets = text.count('[') - text.count(']')
    
    # If we're inside a string, close it
    # Find if last quote is unmatched
    in_string = False
    escaped = False
    for ch in text:
        if escaped:
            escaped = False
            continue
        if ch == '\\':
            escaped = True
            continue
        if ch == '"':
            in_string = not in_string
    
    if in_string:
        text += '"'
    
    # Remove trailing comma if present
    text = re.sub(r',\s*$', '', text)
    
    # Close open brackets then braces
    text += ']' * open_brackets
    text += '}' * open_braces
    
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        # Last resort: try to find the last complete gap entry
        # Find the last valid JSON by truncating at last complete object
        for i in range(len(text) - 1, 0, -1):
            if text[i] == '}':
                candidate = text[:i+1]
                # Try closing remaining brackets
                ob = candidate.count('[') - candidate.count(']')
                candidate += ']' * ob
                ob2 = candidate.count('{') - candidate.count('}')
                candidate += '}' * ob2
                try:
                    return json.loads(candidate)
                except:
                    continue
        raise ValueError("Could not repair truncated JSON")


def build_audit_payload(full_text, extracted_content, validation):
    """
    Build the LLM prompt payload. Manages token budget:
    - full_text: truncate to 120K chars (~41K tokens) if needed
    - extracted_content: full JSON (typically 10-50K chars)
    - max_tokens: 65536 (matches extraction pipeline, prevents truncation)
    """
    # Truncate PDF text if too long (keep within ~130K token budget)
    max_pdf_chars = 120_000
    pdf_text = full_text[:max_pdf_chars]
    if len(full_text) > max_pdf_chars:
        pdf_text += f"\n\n[... TRUNCATED at {max_pdf_chars} chars. Original: {len(full_text)} chars ...]\n"
    
    # Build the user message
    user_message = f"""## RAW PDF TEXT:\n{pdf_text}\n\n## EXTRACTED JSON (extracted_content):\n{json.dumps(extracted_content, indent=2, default=str)}\n\n## VALIDATION METADATA:\n{json.dumps(validation, indent=2, default=str)}\n\nNow perform the quality audit. Return ONLY the JSON object, no other text. List ALL gaps individually — do not truncate or consolidate."""
    
    return {
        "messages": [
            {"role": "system", "content": AUDIT_PROMPT},
            {"role": "user", "content": user_message}
        ],
        "max_tokens": 65536,
        "temperature": 0.1
    }


def call_llm(payload, timeout=600):
    """Call the LLM endpoint and return parsed JSON response.
    Uses 600s timeout (10 min) to allow full 65K token output generation.
    Includes JSON repair for truncated responses.
    """
    headers = {
        "Authorization": f"Bearer {TOKEN}",
        "Content-Type": "application/json"
    }
    
    resp = requests.post(MODEL_ENDPOINT, headers=headers, json=payload, timeout=timeout)
    resp.raise_for_status()
    
    result = resp.json()
    content = result['choices'][0]['message']['content']
    finish_reason = result['choices'][0].get('finish_reason', 'stop')
    
    # Check if output was truncated
    was_truncated = (finish_reason == 'length')
    
    # Parse JSON (with repair if truncated)
    content = content.strip()
    if content.startswith('```'):
        content = re.sub(r'^```(?:json)?\n?', '', content)
        content = re.sub(r'\n?```$', '', content)
    
    try:
        parsed = json.loads(content)
    except json.JSONDecodeError:
        # Attempt repair (handles truncation at max_tokens boundary)
        parsed = _repair_truncated_json(content)
    
    # Flag if truncated so we know gaps[] may be incomplete
    parsed['_was_truncated'] = was_truncated
    parsed['_finish_reason'] = finish_reason
    
    return parsed


def audit_file_with_llm(fname):
    """
    Full LLM-based audit for one file.
    Returns structured gap analysis with computed score.
    """
    fpath = os.path.join(OUTPUT_DIR, fname)
    with open(fpath, 'r') as f:
        data = json.load(f)
    
    full_text = data.get('full_text', '')
    meta = data.get('file_metadata', {})
    extracted = data.get('extracted_content', {})
    validation = data.get('validation', {})
    
    # Build and send LLM request
    payload = build_audit_payload(full_text, extracted, validation)
    audit_result = call_llm(payload)
    
    # --- COMPUTE SCORE FROM GAPS (not LLM's subjective rating) ---
    gaps = audit_result.get('gaps', [])
    high_count = sum(1 for g in gaps if g.get('severity') == 'HIGH')
    med_count = sum(1 for g in gaps if g.get('severity') == 'MEDIUM')
    low_count = sum(1 for g in gaps if g.get('severity') == 'LOW')
    
    # Formula: Start at 100, deduct per gap severity
    # HIGH = -5 points, MEDIUM = -2 points, LOW = -0.5 points
    # Floor at 0
    computed_score = max(0, round(100 - (high_count * 5) - (med_count * 2) - (low_count * 0.5)))
    
    audit_result['overall_quality_score'] = computed_score
    audit_result['total_gaps_found'] = len(gaps)  # Always use array length, never LLM's guess
    
    # Attach file metadata
    audit_result['filename'] = fname
    audit_result['provider_id'] = meta.get('provider_id', '')
    audit_result['provider_name'] = meta.get('provider_name', '')
    audit_result['document_type'] = meta.get('document_type', '')
    audit_result['num_pages'] = meta.get('num_pages', 0)
    audit_result['text_length'] = len(full_text)
    audit_result['content_bucket'] = validation.get('content_bucket', '')
    
    # Token usage and truncation info
    audit_result['input_chars'] = len(payload['messages'][1]['content'])
    audit_result['was_truncated'] = audit_result.pop('_was_truncated', False)
    audit_result['finish_reason'] = audit_result.pop('_finish_reason', 'stop')
    
    return audit_result


print("  ✅ LLM audit engine loaded (v2 — full capture)")
print(f"     Endpoint: {MODEL_ENDPOINT[:60]}...")
print(f"     max_tokens: 65,536 (4× previous — prevents gap truncation)")
print(f"     JSON repair: enabled (handles edge-case truncation)")
print(f"     Scoring: computed from gaps (HIGH=-5, MEDIUM=-2, LOW=-0.5)")
print(f"     Budget: ~120K chars PDF + full JSON = ~80K tokens input")
print(f"     Response: up to 65K tokens output = ~190K chars gap list")

# COMMAND ----------

# DBTITLE 1,File Selection for Audit
# ═══════════════════════════════════════════════════════════════════════════════
# STEP 2: SELECT FILES FOR AUDIT
# ═══════════════════════════════════════════════════════════════════════════════

import random

json_files = sorted([f for f in os.listdir(OUTPUT_DIR) if f.endswith('.json')])

if audit_mode == 'single' and target_file:
    audit_files = [target_file]

elif audit_mode == 'providers' and target_providers:
    # Filter all files matching the given provider IDs (comma-separated)
    pids = [p.strip() for p in target_providers.split(',') if p.strip()]
    audit_files = [f for f in json_files if any(f.startswith(pid + '_') for pid in pids)]
    
    # Show breakdown
    from collections import Counter
    provider_counts = Counter()
    for f in audit_files:
        pid = f.split('_')[0]
        name_parts = []
        for p in f.split('_')[1:]:
            if p.isdigit() and len(p) > 6:
                break
            name_parts.append(p)
        provider_counts[f"{pid} ({' '.join(name_parts)})"] += 1
    
    print(f"  Provider-based selection ({len(pids)} provider IDs):")
    for prov, cnt in sorted(provider_counts.items(), key=lambda x: -x[1]):
        print(f"    {prov}: {cnt} files")

elif audit_mode == 'sample':
    # Stratified sample: pick across doc types and sizes
    file_meta = []
    for fname in json_files:
        fpath = os.path.join(OUTPUT_DIR, fname)
        fsize = os.path.getsize(fpath)
        parts = fname.replace('.json', '').split('_')
        doc_type = parts[-2] if len(parts) >= 3 else 'Unknown'
        file_meta.append({'filename': fname, 'size_kb': fsize/1024, 'doc_type': doc_type})
    
    df_meta = pd.DataFrame(file_meta)
    
    small = df_meta[df_meta['size_kb'] < 20]['filename'].tolist()
    medium = df_meta[(df_meta['size_kb'] >= 20) & (df_meta['size_kb'] < 100)]['filename'].tolist()
    large = df_meta[df_meta['size_kb'] >= 100]['filename'].tolist()
    
    n = sample_size
    n_small = max(2, int(n * 0.2))
    n_medium = max(2, int(n * 0.4))
    n_large = max(2, n - n_small - n_medium)
    
    random.seed(42)
    audit_files = (
        random.sample(small, min(n_small, len(small))) +
        random.sample(medium, min(n_medium, len(medium))) +
        random.sample(large, min(n_large, len(large)))
    )
    
    print(f"  Stratified sample: {len(audit_files)} files")
    print(f"    Small (<20KB):   {min(n_small, len(small))} files")
    print(f"    Medium (20-100): {min(n_medium, len(medium))} files")
    print(f"    Large (>100KB):  {min(n_large, len(large))} files")
    
else:  # all
    audit_files = json_files

print(f"\n  📂 Files selected for LLM audit: {len(audit_files)}")
print(f"  💰 Estimated cost: ~${len(audit_files) * 0.24:.0f} (input) + ~${len(audit_files) * 0.12:.0f} (output) = ~${len(audit_files) * 0.36:.0f} total")
print(f"  ⏱️  Estimated time: ~{len(audit_files) * 91 / 60:.0f} min (serial) / ~{len(audit_files) * 91 / 60 / 3:.0f} min (3 workers)")

# COMMAND ----------

# DBTITLE 1,Execute LLM Audit
# ═══════════════════════════════════════════════════════════════════════════════
# STEP 3: RUN LLM AUDIT
# ═══════════════════════════════════════════════════════════════════════════════

print(f"\n  ▶ Starting LLM audit of {len(audit_files)} files...")
print(f"  {'='*70}")

audit_results = []
errors = []
t_start = time.time()

def safe_audit(fname):
    """Wrapper with error handling and retries."""
    for attempt in range(2):  # 1 retry
        try:
            result = audit_file_with_llm(fname)
            return result
        except requests.exceptions.Timeout:
            if attempt == 0:
                time.sleep(5)
                continue
            return {'filename': fname, 'error': 'TIMEOUT', 'overall_quality_score': None, 'gaps': []}
        except json.JSONDecodeError as e:
            return {'filename': fname, 'error': f'JSON_PARSE: {str(e)[:100]}', 'overall_quality_score': None, 'gaps': []}
        except Exception as e:
            return {'filename': fname, 'error': f'{type(e).__name__}: {str(e)[:100]}', 'overall_quality_score': None, 'gaps': []}

# Run with 3 concurrent workers (matches extraction pipeline pattern)
with ThreadPoolExecutor(max_workers=3) as executor:
    futures = {executor.submit(safe_audit, f): f for f in audit_files}
    for future in as_completed(futures):
        result = future.result()
        audit_results.append(result)
        
        fname = result.get('filename', '?')
        score = result.get('overall_quality_score', '?')
        n_gaps = result.get('total_gaps_found', len(result.get('gaps', [])))
        error = result.get('error', '')
        
        if error:
            print(f"    ❌ {fname[:50]} — ERROR: {error}")
            errors.append(result)
        else:
            icon = '✅' if score and score >= 80 else ('🟡' if score and score >= 60 else '🔴')
            print(f"    {icon} {fname[:50]:<52} Score: {score:>3}/100 | Gaps: {n_gaps}")

elapsed = time.time() - t_start
print(f"\n  {'='*70}")
print(f"  ✅ LLM audit complete: {len(audit_results)} files in {elapsed:.0f}s")
print(f"     Successful: {len(audit_results) - len(errors)} | Errors: {len(errors)}")
print(f"     Avg time: {elapsed/len(audit_files):.1f}s per file")

# COMMAND ----------

# DBTITLE 1,Build Results DataFrame and Summary
# ═══════════════════════════════════════════════════════════════════════════════
# STEP 4: BUILD RESULTS TABLE
# ═══════════════════════════════════════════════════════════════════════════════

# Flatten results into two DataFrames:
# 1. File-level summary (one row per file)
# 2. Gap-level detail (one row per gap per file)

# ── File-level summary ──
file_rows = []
for r in audit_results:
    gaps = r.get('gaps', [])
    high_count = sum(1 for g in gaps if g.get('severity') == 'HIGH')
    med_count = sum(1 for g in gaps if g.get('severity') == 'MEDIUM')
    low_count = sum(1 for g in gaps if g.get('severity') == 'LOW')
    
    file_rows.append({
        'filename': r.get('filename', ''),
        'provider_id': r.get('provider_id', ''),
        'provider_name': r.get('provider_name', ''),
        'document_type': r.get('document_type', ''),
        'num_pages': r.get('num_pages', 0),
        'text_length': r.get('text_length', 0),
        'content_bucket': r.get('content_bucket', ''),
        # Score computed from gaps: 100 - (HIGH*5 + MEDIUM*2 + LOW*0.5)
        'overall_quality_score': r.get('overall_quality_score', 
            max(0, round(100 - (high_count * 5) - (med_count * 2) - (low_count * 0.5)))),
        'total_gaps_found': len(gaps),  # Always actual array length
        'total_hallucinations': r.get('total_hallucinations', 0),
        'sections_analyzed': r.get('sections_analyzed', 0),
        'high_gaps': high_count,
        'medium_gaps': med_count,
        'low_gaps': low_count,
        'strengths': json.dumps(r.get('strengths', [])),
        'summary': r.get('summary', ''),
        'error': r.get('error', ''),
        'input_chars': r.get('input_chars', 0),
        'was_truncated': r.get('was_truncated', False),
        'finish_reason': r.get('finish_reason', ''),
        'audit_timestamp': datetime.utcnow().isoformat(),
    })

df_files = pd.DataFrame(file_rows)

# ── Gap-level detail ──
gap_rows = []
for r in audit_results:
    for gap in r.get('gaps', []):
        gap_rows.append({
            'filename': r.get('filename', ''),
            'provider_name': r.get('provider_name', ''),
            'document_type': r.get('document_type', ''),
            'section': gap.get('section', ''),
            'severity': gap.get('severity', ''),
            'gap_type': gap.get('gap_type', ''),
            'description': gap.get('description', ''),
            'pdf_evidence': gap.get('pdf_evidence', ''),
            'json_field': gap.get('json_field', ''),
            'count': gap.get('count', 1),
            'audit_timestamp': datetime.utcnow().isoformat(),
        })

df_gaps = pd.DataFrame(gap_rows) if gap_rows else pd.DataFrame()

# ── Summary ──
print("═" * 80)
print("  📊 AUDIT RESULTS SUMMARY")
print("═" * 80)

scores = df_files['overall_quality_score'].dropna()
if len(scores) > 0:
    print(f"\n  Quality Score Distribution (computed: 100 - HIGH*5 - MED*2 - LOW*0.5):")
    print(f"    Mean:   {scores.mean():.1f}/100")
    print(f"    Median: {scores.median():.1f}/100")
    print(f"    Min:    {scores.min():.1f}/100")
    print(f"    Max:    {scores.max():.1f}/100")
    print(f"    Unique scores: {scores.nunique()} (should vary per file)")

# Truncation check
truncated = df_files[df_files['was_truncated'] == True]
if len(truncated) > 0:
    print(f"\n  ⚠️  TRUNCATED RESPONSES: {len(truncated)} files hit max_tokens")
    print(f"     These may have incomplete gap lists (JSON repair applied)")
    for _, row in truncated.iterrows():
        print(f"       {row['filename'][:55]} — {row['total_gaps_found']} gaps captured")
else:
    print(f"\n  ✅ No truncation detected — all gap lists are complete")

if len(df_gaps) > 0:
    print(f"\n  Gap Analysis:")
    print(f"    Total gaps found: {len(df_gaps):,}")
    print(f"    HIGH severity: {len(df_gaps[df_gaps['severity']=='HIGH']):,}")
    print(f"    MEDIUM severity: {len(df_gaps[df_gaps['severity']=='MEDIUM']):,}")
    print(f"    LOW severity: {len(df_gaps[df_gaps['severity']=='LOW']):,}")
    
    print(f"\n  Most common gap types:")
    for gt, count in df_gaps['gap_type'].value_counts().head(10).items():
        print(f"    {gt:<25} {count:>4}")
    
    print(f"\n  Most affected sections:")
    for sec, count in df_gaps['section'].value_counts().head(10).items():
        print(f"    {sec:<40} {count:>4}")

print(f"\n  🔴 Files with most HIGH-severity gaps:")
for _, row in df_files.nlargest(10, 'high_gaps').iterrows():
    if row['high_gaps'] > 0:
        print(f"    {row['high_gaps']:>2} HIGH gaps | Score: {row['overall_quality_score']}/100 | {row['filename'][:55]}")

display(df_files[['filename', 'overall_quality_score', 'total_gaps_found', 
                  'high_gaps', 'medium_gaps', 'low_gaps', 'was_truncated', 'summary']].sort_values('overall_quality_score'))

# COMMAND ----------

# DBTITLE 1,Write Audit Results to Delta (MERGE)
# ═══════════════════════════════════════════════════════════════════════════════
# STEP 5: WRITE TO DELTA TABLES (MERGE/UPSERT by filename)
# ═══════════════════════════════════════════════════════════════════════════════
# Uses Delta MERGE so that:
#   - If a file was already audited, its row is UPDATED with latest results
#   - If a file is new, it's INSERTED
#   - Previously audited files NOT in this run are left untouched
# This means you can run on 1 file, 20 files, or all 3,510 — table always
# holds the latest audit per filename without losing other results.

import numpy as np
from delta.tables import DeltaTable

GAP_TABLE = f"{SCHEMA}.tbl_extraction_quality_gaps"

# ───────────────────────────────────────────────────────────────────────────────
# 1. CLEAN DATA TYPES
# ───────────────────────────────────────────────────────────────────────────────
int_cols = ['overall_quality_score', 'total_gaps_found', 'total_hallucinations',
            'sections_analyzed', 'num_pages', 'text_length', 'input_chars',
            'high_gaps', 'medium_gaps', 'low_gaps']
for col in int_cols:
    if col in df_files.columns:
        df_files[col] = pd.to_numeric(df_files[col], errors='coerce').fillna(0).astype(int)

str_cols = ['filename', 'provider_id', 'provider_name', 'document_type', 
            'content_bucket', 'strengths', 'summary', 'error', 
            'audit_timestamp', 'finish_reason']
for col in str_cols:
    if col in df_files.columns:
        df_files[col] = df_files[col].fillna('')

# Ensure was_truncated is bool
if 'was_truncated' in df_files.columns:
    df_files['was_truncated'] = df_files['was_truncated'].astype(bool)

# ───────────────────────────────────────────────────────────────────────────────
# 2. MERGE FILE-LEVEL TABLE (upsert by filename)
# ───────────────────────────────────────────────────────────────────────────────
sdf_files = spark.createDataFrame(df_files)

# Create table if not exists (first-time run)
if not spark.catalog.tableExists(AUDIT_TABLE):
    sdf_files.write.saveAsTable(AUDIT_TABLE)
    print(f"  ✅ Created {AUDIT_TABLE} with {len(df_files):,} rows")
else:
    # MERGE: match on filename, update all columns if matched, insert if new
    target = DeltaTable.forName(spark, AUDIT_TABLE)
    
    target.alias('t').merge(
        sdf_files.alias('s'),
        "t.filename = s.filename"
    ).whenMatchedUpdateAll(
    ).whenNotMatchedInsertAll(
    ).execute()
    
    print(f"  ✅ MERGED {len(df_files):,} rows into {AUDIT_TABLE} (upsert by filename)")

# Show total rows in table now
total_audit_rows = spark.sql(f"SELECT COUNT(*) as n FROM {AUDIT_TABLE}").collect()[0]['n']
print(f"     Table now has {total_audit_rows:,} total rows")

# ───────────────────────────────────────────────────────────────────────────────
# 3. MERGE GAP-LEVEL TABLE (delete old gaps for file, insert new ones)
# ───────────────────────────────────────────────────────────────────────────────
# For gaps: can't do a simple MERGE because one file has many gap rows.
# Strategy: DELETE all existing gaps for the audited filenames, then INSERT new ones.
if len(df_gaps) > 0:
    df_gaps['count'] = pd.to_numeric(df_gaps['count'], errors='coerce').fillna(1).astype(int)
    for col in ['filename', 'provider_name', 'document_type', 'section', 'severity', 
                'gap_type', 'description', 'pdf_evidence', 'json_field', 'audit_timestamp']:
        if col in df_gaps.columns:
            df_gaps[col] = df_gaps[col].fillna('')
    
    sdf_gaps = spark.createDataFrame(df_gaps)
    
    if not spark.catalog.tableExists(GAP_TABLE):
        sdf_gaps.write.saveAsTable(GAP_TABLE)
        print(f"  ✅ Created {GAP_TABLE} with {len(df_gaps):,} rows")
    else:
        # Get list of filenames we just audited
        audited_filenames = df_files['filename'].tolist()
        # Escape single quotes in filenames
        escaped = [f.replace("'", "''") for f in audited_filenames]
        # Build IN clause (chunk if >500 to avoid SQL limit)
        chunk_size = 500
        for i in range(0, len(escaped), chunk_size):
            chunk = escaped[i:i+chunk_size]
            in_list = ", ".join([f"'{f}'" for f in chunk])
            spark.sql(f"DELETE FROM {GAP_TABLE} WHERE filename IN ({in_list})")
        
        # Insert fresh gaps
        sdf_gaps.write.mode('append').saveAsTable(GAP_TABLE)
        print(f"  ✅ MERGED gaps: deleted old + inserted {len(df_gaps):,} new rows for {len(audited_filenames)} files")
    
    total_gap_rows = spark.sql(f"SELECT COUNT(*) as n FROM {GAP_TABLE}").collect()[0]['n']
    print(f"     Table now has {total_gap_rows:,} total gap rows")
else:
    print(f"  ⚠️  No gaps found (or all files errored)")

# ───────────────────────────────────────────────────────────────────────────────
# 4. TABLE COMMENTS
# ───────────────────────────────────────────────────────────────────────────────
spark.sql(f"""COMMENT ON TABLE {AUDIT_TABLE} IS 
    'LLM-based extraction quality audit (v2). One row per file with computed score, 
     gap counts by severity, truncation flag. MERGE by filename keeps latest audit. 
     Score formula: 100 - (HIGH*5 + MEDIUM*2 + LOW*0.5).'""")

if spark.catalog.tableExists(GAP_TABLE):
    spark.sql(f"""COMMENT ON TABLE {GAP_TABLE} IS 
        'Individual extraction gaps found by LLM audit. One row per gap. 
         DELETE+INSERT by filename on each run ensures latest gaps only. 
         Includes section, severity, gap_type, description, PDF evidence.'""")

print(f"\n  📊 Usage:")
print(f"     -- Re-run single file (won't lose other results):")
print(f"     audit_mode='single', target_file='<filename>.json'")
print(f"")
print(f"     -- Query worst files:")
print(f"     SELECT * FROM {AUDIT_TABLE} ORDER BY overall_quality_score ASC")
print(f"")
print(f"     -- All HIGH gaps:")
print(f"     SELECT * FROM {GAP_TABLE} WHERE severity = 'HIGH' ORDER BY filename")

# COMMAND ----------

# DBTITLE 1,Detailed Gap Report for Worst Files
# ═══════════════════════════════════════════════════════════════════════════════
# STEP 6: DETAILED GAP REPORT FOR WORST FILES
# ═══════════════════════════════════════════════════════════════════════════════

GAP_TABLE = f"{SCHEMA}.tbl_extraction_quality_gaps"

print("═" * 80)
print("  🔍 DETAILED GAP REPORT — Per File")
print("═" * 80)

# Show full gap details for each audited file
for r in sorted(audit_results, key=lambda x: x.get('overall_quality_score', 999)):
    if r.get('error'):
        continue
    
    fname = r.get('filename', '?')
    score = r.get('overall_quality_score', '?')
    gaps = r.get('gaps', [])
    strengths = r.get('strengths', [])
    summary = r.get('summary', '')
    
    print(f"\n  {'='*76}")
    print(f"  FILE: {fname}")
    print(f"  Provider: {r.get('provider_name', '?')} | Type: {r.get('document_type', '?')} | Pages: {r.get('num_pages', '?')}")
    print(f"  SCORE: {score}/100 | Gaps: {len(gaps)} (HIGH: {sum(1 for g in gaps if g.get('severity')=='HIGH')}, "
          f"MED: {sum(1 for g in gaps if g.get('severity')=='MEDIUM')}, "
          f"LOW: {sum(1 for g in gaps if g.get('severity')=='LOW')})")
    print(f"  Summary: {summary}")
    
    if strengths:
        print(f"\n  ✅ Strengths:")
        for s in strengths[:5]:
            print(f"     • {s}")
    
    if gaps:
        # Group by severity
        for sev in ['HIGH', 'MEDIUM', 'LOW']:
            sev_gaps = [g for g in gaps if g.get('severity') == sev]
            if sev_gaps:
                icon = {"HIGH": "🔴", "MEDIUM": "🟡", "LOW": "🟢"}[sev]
                print(f"\n  {icon} {sev} SEVERITY GAPS ({len(sev_gaps)}):")
                for g in sev_gaps:
                    print(f"     [{g.get('gap_type', '?')}] {g.get('section', '?')}")
                    print(f"       {g.get('description', '')}")
                    if g.get('pdf_evidence'):
                        print(f"       PDF evidence: \"{g['pdf_evidence'][:100]}\"")
                    if g.get('count', 1) > 1:
                        print(f"       Count: {g['count']} items")

print(f"\n{'='*80}")
print(f"  ═══ LLM-BASED QUALITY AUDIT COMPLETE ═══")
print(f"  File-level: {AUDIT_TABLE}")
print(f"  Gap-level:  {GAP_TABLE}")
print(f"{'='*80}")