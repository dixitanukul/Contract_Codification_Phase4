# Databricks notebook source
# DBTITLE 1,Reprocess Missing Pages - Overview
# MAGIC %md
# MAGIC # 02a — Reprocess Files with Missing Pages
# MAGIC **One-time cleanup: removes affected files from checkpoints so 02_ocr_extraction re-routes them through Tier 2.**
# MAGIC
# MAGIC | What | Detail |
# MAGIC |------|--------|
# MAGIC | Root Cause | Quality gate used AVERAGE chars/page — mixed-content PDFs passed despite 50-95% empty pages |
# MAGIC | Fix Applied | 02_ocr_extraction now uses per-page empty ratio (>15% → Tier 2) |
# MAGIC | This Notebook | Cleans checkpoints so affected files are re-discovered and re-extracted |
# MAGIC
# MAGIC **Run ONCE after code fixes are applied, BEFORE re-running the pipeline.**
# MAGIC
# MAGIC | Step | Action |
# MAGIC |------|--------|
# MAGIC | 1 | Identify affected files from step1 checkpoint |
# MAGIC | 2 | Backup current checkpoints |
# MAGIC | 3 | Remove affected files from step1 + step2 |
# MAGIC | 4 | Backup corresponding JSON files |
# MAGIC | 5 | Print summary — ready for pipeline re-run |

# COMMAND ----------

# DBTITLE 1,Load Config and Identify Affected Files
# MAGIC %run ./_config

# COMMAND ----------

# DBTITLE 1,Identify and Cleanup Affected Files
# ═══════════════════════════════════════════════════════════════════════════════
# STEP 1: Identify files with >15% empty pages (the quality gate bug victims)
# ═══════════════════════════════════════════════════════════════════════════════
import os, shutil
import pandas as pd
from datetime import datetime

print("═" * 80)
print("  ▶ REPROCESS: Identify files with missing pages (quality gate bug victims)")
print("═" * 80)

assert os.path.exists(STEP1_FILE), f"Step1 checkpoint not found: {STEP1_FILE}"
step1_df = pd.read_parquet(STEP1_FILE)

# Only look at pypdf-extracted files (Tier 2 files are fine)
pypdf_df = step1_df[step1_df['extraction_method'] == 'pypdf'].copy()

affected = []
for _, row in pypdf_df.iterrows():
    text = row['full_text'] or ''
    num_pages = int(row['num_pages'])
    if num_pages < 2:
        continue
    # Use old separator (these files don't have PAGE_BREAK markers yet)
    pages = text.split('\n\n')
    empty = sum(1 for p in pages if len(p.strip()) < EMPTY_PAGE_THRESHOLD)
    ratio = empty / max(num_pages, 1)
    if ratio > MAX_EMPTY_PAGE_RATIO:
        affected.append(row['filename'])

print(f"\n  Found {len(affected):,} affected files (>{MAX_EMPTY_PAGE_RATIO*100:.0f}% empty pages)")
print(f"  Total files in checkpoint: {len(step1_df):,}")
print(f"  Files unaffected: {len(step1_df) - len(affected):,}")

# ═══ STEP 2: Backup current checkpoints ═══
timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
backup_s1 = f"{STEP1_FILE}.backup_{timestamp}"
backup_s2 = f"{STEP2_FILE}.backup_{timestamp}"

shutil.copy2(STEP1_FILE, backup_s1)
print(f"\n  💾 Backed up step1 → {backup_s1}")
if os.path.exists(STEP2_FILE):
    shutil.copy2(STEP2_FILE, backup_s2)
    print(f"  💾 Backed up step2 → {backup_s2}")

# ═══ STEP 3: Remove affected files from step1 + step2 checkpoints ═══
step1_clean = step1_df[~step1_df['filename'].isin(affected)]
step1_clean.to_parquet(STEP1_FILE, index=False)
print(f"\n  ✅ Step1 cleaned: {len(step1_df):,} → {len(step1_clean):,} ({len(affected):,} removed)")

if os.path.exists(STEP2_FILE):
    step2_df = pd.read_parquet(STEP2_FILE)
    step2_clean = step2_df[~step2_df['filename'].isin(affected)]
    step2_clean.to_parquet(STEP2_FILE, index=False)
    print(f"  ✅ Step2 cleaned: {len(step2_df):,} → {len(step2_clean):,} ({len(step2_df) - len(step2_clean):,} removed)")

# ═══ STEP 4: Backup corresponding JSON files (rename, don't delete) ═══
json_backed_up = 0
for fname in affected:
    json_name = os.path.splitext(fname)[0] + '.json'
    json_path = os.path.join(OUTPUT_DIR, json_name)
    if os.path.exists(json_path):
        backup_path = json_path + '.bak_missing_pages'
        if not os.path.exists(backup_path):  # Don't overwrite existing backups
            os.rename(json_path, backup_path)
            json_backed_up += 1

print(f"  ✅ JSON backups: {json_backed_up:,} files renamed to .bak_missing_pages")

# ═══ STEP 5: Also clean up May-25 error JSONs (connection failures) ═══
# These 222 files have extraction_error but no content — will be retried by 05
error_jsons_cleaned = 0
for fname in os.listdir(OUTPUT_DIR):
    if not fname.endswith('.json') or fname.startswith('_'):
        continue
    fpath = os.path.join(OUTPUT_DIR, fname)
    try:
        with open(fpath, 'r') as f:
            doc = json.load(f)
        if doc.get('extraction_error') and not doc.get('extracted_content'):
            backup_path = fpath + '.bak_error'
            if not os.path.exists(backup_path):
                os.rename(fpath, backup_path)
                error_jsons_cleaned += 1
    except Exception:
        pass

if error_jsons_cleaned:
    print(f"  ✅ Error JSONs backed up: {error_jsons_cleaned:,} (will be retried by 05_llm_extraction)")

# ═══ SUMMARY ═══
print(f"\n  {'='*78}")
print(f"  ✅ REPROCESSING PREP COMPLETE")
print(f"     {len(affected):,} files removed from checkpoints")
print(f"     {json_backed_up:,} JSON files backed up")
print(f"     Next: Run 02_ocr_extraction → these files will be auto-discovered")
print(f"            and routed to Tier 2 (ai_parse_document) for full OCR")
print(f"     Then: Run 03 → 05 → 06 → 08-13 to rebuild tables")
print(f"  {'='*78}")