# Databricks notebook source
# DBTITLE 1,Gap Filler Overview
# MAGIC %md
# MAGIC # 15 — Extraction Gap Filler (Targeted Re-Extraction)
# MAGIC **Uses audit results to surgically re-extract only the missing data from each PDF.**
# MAGIC 
# MAGIC | Feature | Description |
# MAGIC |---------|-------------|
# MAGIC | Method | Reads existing JSON + known gaps → targeted LLM prompt for ONLY missing fields |
# MAGIC | Merge | Deep-merges new extractions into existing JSON (preserves all prior work) |
# MAGIC | Backup | Creates backup of original JSON before overwrite |
# MAGIC | Validation | Before/after comparison shows improvements per file |
# MAGIC 
# MAGIC **Parameters:**
# MAGIC 
# MAGIC | Parameter | Options | Description |
# MAGIC |-----------|---------|-------------|
# MAGIC | `mode` | all, single, sample, providers | Which files to gap-fill |
# MAGIC | `target_file` | filename | Single-file mode target |
# MAGIC | `target_providers` | comma-sep IDs | Provider-mode filter |
# MAGIC | `sample_size` | integer | Random sample count |
# MAGIC 
# MAGIC **Run after:** `14_quality_audit` (needs gap results in `tbl_extraction_quality_gaps`)  
# MAGIC **Run before:** Re-run `06_validation` → `13_build_serving` to rebuild tables with filled data

# COMMAND ----------

# DBTITLE 1,Load Shared Config
%run ./_config

# COMMAND ----------

# DBTITLE 1,Gap Filler Configuration and Widgets
# ═══════════════════════════════════════════════════════════════════════════════
# EXTRACTION GAP FILLER — Configuration
# ═══════════════════════════════════════════════════════════════════════════════
# Option A from quality audit: Take existing JSON + PDF, send targeted
# prompt for ONLY the missing sections, merge results back.
# ═══════════════════════════════════════════════════════════════════════════════

import os, re, json, time, shutil, requests
import pandas as pd
import numpy as np
from datetime import datetime, timezone
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from delta.tables import DeltaTable

# --- Widgets ---
dbutils.widgets.dropdown("mode", "sample", ["all", "single", "sample", "providers"], "Run Mode")
dbutils.widgets.text("target_file", "", "Target File (single mode)")
dbutils.widgets.text("target_providers", "129105716,195412048,129083117,129112153,129141116,197789982,129126497", "Provider IDs (providers mode)")
dbutils.widgets.text("sample_size", "10", "Sample Size")

# --- Paths ---
BASE_DIR = "/Workspace/Users/adixit01@blueshieldca.com/Contract_Codification_Pipeline"
OUTPUT_DIR = f"{BASE_DIR}/json_extract"
BACKUP_DIR = f"{BASE_DIR}/json_extract_backup"

# --- Delta Tables ---
SCHEMA = "dev_adb.raw"
AUDIT_TABLE = f"{SCHEMA}.tbl_extraction_quality_audit"
GAP_TABLE = f"{SCHEMA}.tbl_extraction_quality_gaps"
GAPFILL_LOG_TABLE = f"{SCHEMA}.tbl_extraction_gapfill_log"

# --- LLM Configuration (REST API, NOT ai_query) ---
WORKSPACE_URL = spark.conf.get("spark.databricks.workspaceUrl")
MODEL_ENDPOINT = f"https://{WORKSPACE_URL}/serving-endpoints/databricks-claude-sonnet-4-5/invocations"
TOKEN = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiToken().get()
MAX_TOKENS = 65536
MAX_PDF_CHARS = 120_000
MAX_WORKERS = 3

# --- Read widget values ---
mode = dbutils.widgets.get("mode")
target_file = dbutils.widgets.get("target_file")
target_providers = dbutils.widgets.get("target_providers")
sample_size = int(dbutils.widgets.get("sample_size"))

print("═" * 80)
print("  ▶ EXTRACTION GAP FILLER — Option A: Targeted Fill of Missing Data")
print(f"  Mode: {mode} | Sample: {sample_size}")
print(f"  Model: databricks-claude-sonnet-4-5 (REST API)")
print(f"  max_tokens: {MAX_TOKENS:,} | Workers: {MAX_WORKERS}")
print(f"  Source: {GAP_TABLE} (audit gaps)")
print(f"  Output: {GAPFILL_LOG_TABLE}")
print("═" * 80)

# COMMAND ----------

# DBTITLE 1,Gap-Fill Prompt and LLM Functions
# ═══════════════════════════════════════════════════════════════════════════════
# STEP 2: GAP-FILL PROMPT + LLM ENGINE
# ═══════════════════════════════════════════════════════════════════════════════

GAP_FILL_PROMPT = """You are a contract extraction specialist performing a TARGETED gap-fill.

You will receive:
1. RAW PDF TEXT of a healthcare provider contract
2. EXISTING extracted JSON (what was already captured in a prior extraction pass)
3. LIST OF KNOWN GAPS found by a quality audit (specific missing items with PDF evidence)

Your job: Extract ONLY the missing data identified in the gaps list.
Do NOT re-extract data that already exists in the JSON.
Do NOT modify or contradict existing extracted values.

RETURN a JSON object using the SAME schema structure as the existing extraction,
but containing ONLY the newly-extracted content for the missing sections/fields.

KEY INSTRUCTIONS:

1. MULTI-NETWORK RATES (EPN, Tandem, CalPERS, Medicare Advantage):
   - These are in separate Exhibits (E, G, H) with their own rate schedules
   - Create rate objects with an added "network" field: "EPN", "Tandem", "CalPERS", "Medicare_Advantage"
   - Use the SAME structure as Commercial rates: rate_description, rate_amount, rate_numeric, effective_date, revenue_codes

2. OUTPATIENT SERVICES (often in Exhibit C Section II):
   - emergency_services: levels 1-5, multipliers, "not to exceed" caps, revenue codes (045x)
   - infusion_therapy: per-visit rates, revenue codes (026x, 028x, 033x, 094x)
   - radiology_pathology: conversion factors, multipliers, "% of Allowed Charges not to exceed $X"
   - clinical_laboratory: fee schedule multipliers, revenue codes (030x)
   - pharmaceuticals: AWP rates, mark-up percentages, revenue codes (063x)
   - observation_services: hourly rates, carve-out rules

3. EXCEPTION PROVISIONS (Exhibit C Section I.F / II.K):
   - implants: device type, threshold amount, max_payment, qualifying revenue/CPT codes, inpatient vs outpatient
   - exception_drugs: HCPCS codes, AWP-based pricing, threshold
   - blood_products: rate methodology
   - Each device/drug = its own row with all fields populated

4. CHARGEMASTER / MAPI:
   - MAPI percentages by service category from Exhibit D Schedule 1
   - IC/OR weights and percentages
   - Charge Master Modification Allowance percentage

5. KEY DEFINITIONS & EXCLUDED SERVICES:
   - key_definitions: term and definition pairs
   - excluded_services: list of services NOT covered
   - disallowed_charges: specific charge types that won't be paid

6. PROVIDER IDENTIFIERS:
   - NPI, Tax ID (TIN), PIN from Exhibit A
   - Execution date from signature blocks

For each gap in the list, find the corresponding data in the PDF and extract it.
If the PDF genuinely doesn't contain the data for a gap, skip that gap (don't hallucinate).

Return ONLY a valid JSON object with the extracted gap-fill content. No other text.
"""


def _repair_truncated_json(text):
    """Attempt to close a truncated JSON object (max_tokens cutoff)."""
    text = text.strip()
    if text.startswith('```'):
        text = re.sub(r'^```(?:json)?\n?', '', text)
        text = re.sub(r'\n?```$', '', text)
    
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    
    # Count open brackets/braces
    in_string = False
    escaped = False
    for ch in text:
        if escaped:
            escaped = False
            continue
        if ch == '\\':
            escaped = True
            continue
        if ch == '"':
            in_string = not in_string
    
    if in_string:
        text += '"'
    
    text = re.sub(r',\s*$', '', text)
    
    open_brackets = text.count('[') - text.count(']')
    open_braces = text.count('{') - text.count('}')
    text += ']' * open_brackets
    text += '}' * open_braces
    
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        # Last resort: find last complete object
        for i in range(len(text) - 1, 0, -1):
            if text[i] == '}':
                candidate = text[:i+1]
                ob = candidate.count('[') - candidate.count(']')
                candidate += ']' * ob
                ob2 = candidate.count('{') - candidate.count('}')
                candidate += '}' * ob2
                try:
                    return json.loads(candidate)
                except:
                    continue
        raise ValueError("Could not repair truncated JSON")


def call_llm(payload, timeout=600):
    """Call LLM via REST API. Returns parsed JSON with truncation flag."""
    headers = {
        "Authorization": f"Bearer {TOKEN}",
        "Content-Type": "application/json"
    }
    
    resp = requests.post(MODEL_ENDPOINT, headers=headers, json=payload, timeout=timeout)
    resp.raise_for_status()
    
    result = resp.json()
    content = result['choices'][0]['message']['content']
    finish_reason = result['choices'][0].get('finish_reason', 'stop')
    was_truncated = (finish_reason == 'length')
    
    # Parse JSON
    content = content.strip()
    if content.startswith('```'):
        content = re.sub(r'^```(?:json)?\n?', '', content)
        content = re.sub(r'\n?```$', '', content)
    
    try:
        parsed = json.loads(content)
    except json.JSONDecodeError:
        parsed = _repair_truncated_json(content)
    
    return parsed, was_truncated, finish_reason


def build_gapfill_payload(full_text, existing_json, gaps_for_file):
    """
    Build the gap-fill prompt payload.
    - full_text: raw PDF text (truncated to MAX_PDF_CHARS)
    - existing_json: current extracted_content dict
    - gaps_for_file: list of gap dicts from the audit table
    """
    pdf_text = full_text[:MAX_PDF_CHARS]
    if len(full_text) > MAX_PDF_CHARS:
        pdf_text += f"\n\n[TRUNCATED at {MAX_PDF_CHARS} chars. Original: {len(full_text)} chars]"
    
    # Format gaps into a clear numbered list
    gaps_text = "\n".join([
        f"{i+1}. [{g['severity']}] {g['section']} — {g['gap_type']}: {g['description']}"
        f"\n   PDF evidence: \"{g.get('pdf_evidence', 'N/A')}\""
        for i, g in enumerate(gaps_for_file)
    ])
    
    user_message = f"""## RAW PDF TEXT:
{pdf_text}

## EXISTING EXTRACTED JSON (extracted_content):
{json.dumps(existing_json, indent=2, default=str)}

## KNOWN GAPS TO FILL ({len(gaps_for_file)} gaps):
{gaps_text}

Extract ONLY the missing data listed above. Return a JSON object with the same schema structure containing ONLY the new content. Do not duplicate existing data."""
    
    return {
        "messages": [
            {"role": "system", "content": GAP_FILL_PROMPT},
            {"role": "user", "content": user_message}
        ],
        "max_tokens": MAX_TOKENS,
        "temperature": 0.1
    }


def merge_extraction(existing, gap_fill):
    """
    Deep-merge gap_fill results into existing extraction.
    Rules:
    - For arrays: append new items (dedup by rate_description+effective_date+network)
    - For empty strings/None: fill with gap_fill value
    - For dicts: recursively merge
    - NEVER overwrite existing valid data
    Returns: (merged_dict, stats)
    """
    stats = {'fields_filled': 0, 'items_appended': 0, 'skipped_duplicates': 0}
    
    def _dedup_key(item):
        """Generate dedup key for rate/row items."""
        if isinstance(item, dict):
            parts = [
                str(item.get('rate_description', item.get('description', item.get('term', '')))).lower().strip(),
                str(item.get('effective_date', '')).strip(),
                str(item.get('network', 'standard')).lower().strip(),
            ]
            return '|'.join(parts)
        return str(item)
    
    def _merge(base, fill):
        if fill is None:
            return base
        
        if isinstance(base, dict) and isinstance(fill, dict):
            merged = dict(base)
            for key, fill_val in fill.items():
                if key not in merged:
                    # New key entirely
                    merged[key] = fill_val
                    stats['fields_filled'] += 1
                elif merged[key] is None or merged[key] == '' or merged[key] == [] or merged[key] == {}:
                    # Existing key is empty — fill it
                    merged[key] = fill_val
                    stats['fields_filled'] += 1
                elif isinstance(merged[key], list) and isinstance(fill_val, list):
                    # Array: append non-duplicate items
                    existing_keys = {_dedup_key(item) for item in merged[key]}
                    for new_item in fill_val:
                        new_key = _dedup_key(new_item)
                        if new_key not in existing_keys and new_key != '||standard':
                            merged[key].append(new_item)
                            existing_keys.add(new_key)
                            stats['items_appended'] += 1
                        else:
                            stats['skipped_duplicates'] += 1
                elif isinstance(merged[key], dict) and isinstance(fill_val, dict):
                    # Nested dict: recurse
                    merged[key] = _merge(merged[key], fill_val)
                else:
                    # Existing has valid data — don't overwrite
                    pass
            return merged
        
        # Base is empty/None, fill has data
        if (base is None or base == '' or base == [] or base == {}) and fill:
            stats['fields_filled'] += 1
            return fill
        
        return base
    
    merged = _merge(existing, gap_fill)
    return merged, stats


print("  ✅ Gap-fill engine loaded")
print(f"     Prompt: {len(GAP_FILL_PROMPT)} chars")
print(f"     Merge strategy: append arrays (dedup by description+date+network), fill empty fields")
print(f"     JSON repair: enabled for truncation edge cases")

# COMMAND ----------

# DBTITLE 1,File Selection Based on Audit Gaps
# ═══════════════════════════════════════════════════════════════════════════════
# STEP 3: SELECT FILES FOR GAP-FILL (prioritized by worst score)
# ═══════════════════════════════════════════════════════════════════════════════

# Get all audited files with their gap counts
df_audit = spark.sql(f"""
    SELECT filename, overall_quality_score, total_gaps_found, high_gaps, medium_gaps, low_gaps
    FROM {AUDIT_TABLE}
    WHERE total_gaps_found > 0
    ORDER BY overall_quality_score ASC
""").toPandas()

# Apply mode filter
if mode == 'single' and target_file:
    df_selected = df_audit[df_audit['filename'] == target_file]

elif mode == 'providers' and target_providers:
    pids = [p.strip() for p in target_providers.split(',') if p.strip()]
    mask = df_audit['filename'].apply(lambda f: any(f.startswith(pid + '_') for pid in pids))
    df_selected = df_audit[mask]

elif mode == 'sample':
    df_selected = df_audit.head(sample_size)  # worst-scoring first

else:  # all
    df_selected = df_audit

# Get the actual gaps for selected files
selected_filenames = df_selected['filename'].tolist()

if selected_filenames:
    # Build query to get gaps for selected files
    escaped = [f.replace("'", "''") for f in selected_filenames]
    # Chunk to avoid SQL IN clause limits
    all_gaps = []
    chunk_size = 200
    for i in range(0, len(escaped), chunk_size):
        chunk = escaped[i:i+chunk_size]
        in_list = ", ".join([f"'{f}'" for f in chunk])
        chunk_gaps = spark.sql(f"""
            SELECT filename, section, severity, gap_type, description, pdf_evidence, json_field, count
            FROM {GAP_TABLE}
            WHERE filename IN ({in_list})
            ORDER BY filename, 
                CASE severity WHEN 'HIGH' THEN 1 WHEN 'MEDIUM' THEN 2 ELSE 3 END
        """).toPandas()
        all_gaps.append(chunk_gaps)
    
    df_all_gaps = pd.concat(all_gaps, ignore_index=True) if all_gaps else pd.DataFrame()
    
    # Group gaps by filename for easy lookup
    gaps_by_file = {}
    for fname, grp in df_all_gaps.groupby('filename'):
        gaps_by_file[fname] = grp.to_dict('records')
else:
    df_all_gaps = pd.DataFrame()
    gaps_by_file = {}

# Summary
total_gaps_to_fill = len(df_all_gaps)
total_high = len(df_all_gaps[df_all_gaps['severity'] == 'HIGH']) if len(df_all_gaps) > 0 else 0
total_med = len(df_all_gaps[df_all_gaps['severity'] == 'MEDIUM']) if len(df_all_gaps) > 0 else 0

print(f"\n  📂 Files selected for gap-fill: {len(df_selected)}")
print(f"  🔍 Total gaps to address: {total_gaps_to_fill:,} (HIGH: {total_high:,}, MEDIUM: {total_med:,})")
print(f"  💰 Estimated cost: ~${len(df_selected) * 0.24:.0f} (input) + ~${len(df_selected) * 0.12:.0f} (output) = ~${len(df_selected) * 0.36:.0f}")
print(f"  ⏱️  Estimated time: ~{len(df_selected) * 80 / 60:.0f} min (serial) / ~{len(df_selected) * 80 / 60 / MAX_WORKERS:.0f} min ({MAX_WORKERS} workers)")

if len(df_selected) > 0:
    print(f"\n  Score distribution of selected files:")
    print(f"    Min: {df_selected['overall_quality_score'].min()} | "
          f"Median: {df_selected['overall_quality_score'].median():.0f} | "
          f"Max: {df_selected['overall_quality_score'].max()}")
    print(f"\n  Top 5 worst files (most gaps):")
    for _, row in df_selected.nlargest(5, 'total_gaps_found').iterrows():
        print(f"    {row['total_gaps_found']:>3} gaps | Score: {row['overall_quality_score']:>3} | {row['filename'][:55]}")

# COMMAND ----------

# DBTITLE 1,Run Targeted Gap-Fill Extraction
# ═══════════════════════════════════════════════════════════════════════════════
# STEP 4: RUN GAP-FILL EXTRACTION
# ═══════════════════════════════════════════════════════════════════════════════

def gapfill_one_file(fname):
    """
    Gap-fill a single file:
    1. Load existing JSON
    2. Get gaps for this file from audit
    3. Build targeted prompt
    4. Call LLM
    5. Merge results into existing extraction
    Returns result dict with stats.
    """
    t0 = time.time()
    result = {
        'filename': fname,
        'status': 'success',
        'error': '',
        'gaps_targeted': 0,
        'gaps_high_targeted': 0,
        'fields_filled': 0,
        'items_appended': 0,
        'skipped_duplicates': 0,
        'was_truncated': False,
        'elapsed_sec': 0,
    }
    
    try:
        # 1. Load existing JSON
        fpath = os.path.join(OUTPUT_DIR, fname)
        with open(fpath, 'r') as f:
            data = json.load(f)
        
        full_text = data.get('full_text', '')
        existing_content = data.get('extracted_content', {})
        
        # 2. Get gaps for this file
        file_gaps = gaps_by_file.get(fname, [])
        if not file_gaps:
            result['status'] = 'skipped_no_gaps'
            result['elapsed_sec'] = time.time() - t0
            return result
        
        result['gaps_targeted'] = len(file_gaps)
        result['gaps_high_targeted'] = sum(1 for g in file_gaps if g.get('severity') == 'HIGH')
        
        # 3. Build payload
        payload = build_gapfill_payload(full_text, existing_content, file_gaps)
        
        # 4. Call LLM
        gap_fill_content, was_truncated, finish_reason = call_llm(payload)
        result['was_truncated'] = was_truncated
        
        # 5. Merge results
        merged_content, merge_stats = merge_extraction(existing_content, gap_fill_content)
        result['fields_filled'] = merge_stats['fields_filled']
        result['items_appended'] = merge_stats['items_appended']
        result['skipped_duplicates'] = merge_stats['skipped_duplicates']
        
        # Store merged content back into data for saving later
        data['extracted_content'] = merged_content
        data['gap_fill_metadata'] = {
            'gap_fill_timestamp': datetime.now(timezone.utc).isoformat(),
            'gaps_targeted': len(file_gaps),
            'fields_filled': merge_stats['fields_filled'],
            'items_appended': merge_stats['items_appended'],
            'was_truncated': was_truncated,
        }
        
        # Store the full updated data for saving in Step 5
        result['_updated_data'] = data
        
    except Exception as e:
        result['status'] = 'error'
        result['error'] = str(e)[:500]
    
    result['elapsed_sec'] = time.time() - t0
    return result


# --- Run with ThreadPoolExecutor ---
print(f"\n  ▶ Starting gap-fill for {len(selected_filenames)} files...")
print("  " + "=" * 70)

gapfill_results = []
start_time = time.time()

with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
    futures = {executor.submit(gapfill_one_file, fname): fname 
               for fname in selected_filenames}
    
    for future in as_completed(futures):
        r = future.result()
        gapfill_results.append(r)
        
        # Progress indicator
        fname_short = r['filename'][:50]
        if r['status'] == 'success':
            filled = r['fields_filled'] + r['items_appended']
            icon = "✅" if filled > 10 else "🟡" if filled > 0 else "⚪"
            print(f"    {icon} {fname_short:<52} +{filled:>3} items | {r['gaps_targeted']} gaps | {r['elapsed_sec']:.0f}s")
        elif r['status'] == 'skipped_no_gaps':
            print(f"    ⏭️  {fname_short:<52} skipped (no gaps)")
        else:
            print(f"    ❌ {fname_short:<52} ERROR: {r['error'][:60]}")

elapsed_total = time.time() - start_time

# Summary
success_count = sum(1 for r in gapfill_results if r['status'] == 'success')
error_count = sum(1 for r in gapfill_results if r['status'] == 'error')
total_filled = sum(r['fields_filled'] for r in gapfill_results)
total_appended = sum(r['items_appended'] for r in gapfill_results)
total_truncated = sum(1 for r in gapfill_results if r['was_truncated'])

print(f"\n  {'=' * 70}")
print(f"  ✅ Gap-fill complete: {success_count} files in {elapsed_total:.0f}s")
print(f"     Errors: {error_count} | Truncated: {total_truncated}")
print(f"     Fields filled: {total_filled:,} | Items appended: {total_appended:,}")
print(f"     Total new data points: {total_filled + total_appended:,}")
print(f"     Avg time: {elapsed_total/max(len(gapfill_results),1):.1f}s per file")

# COMMAND ----------

# DBTITLE 1,Save Updated JSONs and Log Results
# ═══════════════════════════════════════════════════════════════════════════════
# STEP 5: SAVE UPDATED JSONs + WRITE GAP-FILL LOG TO DELTA
# ═══════════════════════════════════════════════════════════════════════════════

# --- 1. Create backup directory ---
os.makedirs(BACKUP_DIR, exist_ok=True)

# --- 2. Save updated JSONs (backup original first) ---
saved_count = 0
backup_count = 0

for r in gapfill_results:
    if r['status'] != 'success' or '_updated_data' not in r:
        continue
    
    fname = r['filename']
    src_path = os.path.join(OUTPUT_DIR, fname)
    bak_path = os.path.join(BACKUP_DIR, fname)
    
    # Backup original (only if not already backed up from a prior run)
    if not os.path.exists(bak_path):
        shutil.copy2(src_path, bak_path)
        backup_count += 1
    
    # Write updated JSON
    with open(src_path, 'w') as f:
        json.dump(r['_updated_data'], f, indent=2, default=str)
    saved_count += 1
    
    # Free memory
    del r['_updated_data']

print(f"  ✅ Saved {saved_count:,} updated JSON files to {OUTPUT_DIR}")
print(f"  📦 Backed up {backup_count:,} originals to {BACKUP_DIR}")

# --- 3. Write gap-fill log to Delta ---
log_rows = []
for r in gapfill_results:
    log_rows.append({
        'filename': r['filename'],
        'status': r['status'],
        'gaps_targeted': r['gaps_targeted'],
        'gaps_high_targeted': r['gaps_high_targeted'],
        'fields_filled': r['fields_filled'],
        'items_appended': r['items_appended'],
        'skipped_duplicates': r['skipped_duplicates'],
        'total_new_data': r['fields_filled'] + r['items_appended'],
        'was_truncated': r['was_truncated'],
        'elapsed_sec': round(r['elapsed_sec'], 1),
        'error': r['error'],
        'gapfill_timestamp': datetime.now(timezone.utc).isoformat(),
    })

df_log = pd.DataFrame(log_rows)

# Ensure types
df_log['was_truncated'] = df_log['was_truncated'].astype(bool)
int_cols = ['gaps_targeted', 'gaps_high_targeted', 'fields_filled', 'items_appended', 
            'skipped_duplicates', 'total_new_data']
for col in int_cols:
    df_log[col] = df_log[col].astype(int)

sdf_log = spark.createDataFrame(df_log)

# MERGE by filename (upsert)
if not spark.catalog.tableExists(GAPFILL_LOG_TABLE):
    sdf_log.write.saveAsTable(GAPFILL_LOG_TABLE)
    print(f"  ✅ Created {GAPFILL_LOG_TABLE} with {len(df_log):,} rows")
else:
    target = DeltaTable.forName(spark, GAPFILL_LOG_TABLE)
    target.alias('t').merge(
        sdf_log.alias('s'),
        "t.filename = s.filename"
    ).whenMatchedUpdateAll(
    ).whenNotMatchedInsertAll(
    ).execute()
    print(f"  ✅ MERGED {len(df_log):,} rows into {GAPFILL_LOG_TABLE}")

total_log_rows = spark.sql(f"SELECT COUNT(*) as n FROM {GAPFILL_LOG_TABLE}").collect()[0]['n']
print(f"     Table now has {total_log_rows:,} total rows")

# --- 4. Summary ---
print(f"\n  📊 Gap-Fill Summary:")
print(f"     Files processed: {len(df_log):,}")
print(f"     Successful: {len(df_log[df_log['status']=='success']):,}")
print(f"     Total new data points added: {df_log['total_new_data'].sum():,}")
print(f"     Avg new data per file: {df_log[df_log['status']=='success']['total_new_data'].mean():.1f}")

# COMMAND ----------

# DBTITLE 1,Validation - Before vs After Comparison
# ═══════════════════════════════════════════════════════════════════════════════
# STEP 6: VALIDATION — Compare Before vs After
# ═══════════════════════════════════════════════════════════════════════════════

import random

def validate_file(fname):
    """
    Compare before (backup) vs after (updated) for a single file.
    Returns stats dict.
    """
    updated_path = os.path.join(OUTPUT_DIR, fname)
    backup_path = os.path.join(BACKUP_DIR, fname)
    
    stats = {'filename': fname}
    
    # Load updated
    with open(updated_path) as f:
        updated = json.load(f)
    updated_ec = updated.get('extracted_content', {})
    
    # Load backup (original)
    if os.path.exists(backup_path):
        with open(backup_path) as f:
            original = json.load(f)
        original_ec = original.get('extracted_content', {})
    else:
        # No backup = not gap-filled yet
        original_ec = updated_ec
    
    # --- Metric 1: Rate count ---
    def count_rates(ec):
        total = 0
        for key in ['inpatient_rates', 'outpatient_rates']:
            section = ec.get(key, {})
            if isinstance(section, dict):
                for sub_key, sub_val in section.items():
                    if isinstance(sub_val, list):
                        total += len(sub_val)
        return total
    
    stats['rates_before'] = count_rates(original_ec)
    stats['rates_after'] = count_rates(updated_ec)
    stats['rates_added'] = stats['rates_after'] - stats['rates_before']
    
    # --- Metric 2: Empty sections ---
    def count_empty_sections(ec):
        empty = 0
        for key, val in ec.items():
            if val is None or val == '' or val == [] or val == {}:
                empty += 1
            elif isinstance(val, dict):
                for sub_key, sub_val in val.items():
                    if sub_val is None or sub_val == '' or sub_val == [] or sub_val == {}:
                        empty += 1
        return empty
    
    stats['empty_before'] = count_empty_sections(original_ec)
    stats['empty_after'] = count_empty_sections(updated_ec)
    stats['sections_filled'] = stats['empty_before'] - stats['empty_after']
    
    # --- Metric 3: rate_numeric coverage ---
    def rate_numeric_coverage(ec):
        total = 0
        with_numeric = 0
        for key in ['inpatient_rates', 'outpatient_rates']:
            section = ec.get(key, {})
            if isinstance(section, dict):
                for sub_key, sub_val in section.items():
                    if isinstance(sub_val, list):
                        for item in sub_val:
                            if isinstance(item, dict):
                                total += 1
                                if item.get('rate_numeric') is not None and item.get('rate_numeric') != '':
                                    with_numeric += 1
        return (with_numeric, total)
    
    num_before, tot_before = rate_numeric_coverage(original_ec)
    num_after, tot_after = rate_numeric_coverage(updated_ec)
    stats['rate_numeric_before'] = f"{num_before}/{tot_before}" if tot_before > 0 else "0/0"
    stats['rate_numeric_after'] = f"{num_after}/{tot_after}" if tot_after > 0 else "0/0"
    stats['rate_numeric_pct_before'] = round(num_before / max(tot_before, 1) * 100, 1)
    stats['rate_numeric_pct_after'] = round(num_after / max(tot_after, 1) * 100, 1)
    
    # --- Metric 4: Regional factors count ---
    stats['regional_before'] = len(original_ec.get('regional_factors', []))
    stats['regional_after'] = len(updated_ec.get('regional_factors', []))
    
    # --- Metric 5: Exception provisions ---
    def count_exceptions(ec):
        ep = ec.get('exception_provisions', {})
        if isinstance(ep, dict):
            return sum(len(v) for v in ep.values() if isinstance(v, list))
        return 0
    
    stats['exceptions_before'] = count_exceptions(original_ec)
    stats['exceptions_after'] = count_exceptions(updated_ec)
    
    return stats


# --- Run validation on all gap-filled files ---
filled_files = [r['filename'] for r in gapfill_results if r['status'] == 'success']

print("═" * 80)
print("  📊 VALIDATION — Before vs After Gap-Fill")
print("═" * 80)

if filled_files:
    val_results = [validate_file(f) for f in filled_files]
    df_val = pd.DataFrame(val_results)
    
    # Aggregate stats
    print(f"\n  Files validated: {len(df_val)}")
    print(f"\n  {'Metric':<30} {'Before':<12} {'After':<12} {'Improvement'}")
    print(f"  {'-'*70}")
    print(f"  {'Total rates':<30} {df_val['rates_before'].sum():<12,} {df_val['rates_after'].sum():<12,} +{df_val['rates_added'].sum():,}")
    print(f"  {'Empty sections':<30} {df_val['empty_before'].sum():<12,} {df_val['empty_after'].sum():<12,} -{df_val['sections_filled'].sum():,} filled")
    print(f"  {'Regional factors':<30} {df_val['regional_before'].sum():<12,} {df_val['regional_after'].sum():<12,} +{df_val['regional_after'].sum() - df_val['regional_before'].sum():,}")
    print(f"  {'Exception provisions':<30} {df_val['exceptions_before'].sum():<12,} {df_val['exceptions_after'].sum():<12,} +{df_val['exceptions_after'].sum() - df_val['exceptions_before'].sum():,}")
    print(f"  {'Avg rate_numeric coverage':<30} {df_val['rate_numeric_pct_before'].mean():.1f}%{'':<7} {df_val['rate_numeric_pct_after'].mean():.1f}%")
    
    # Top improved files
    df_val['total_improvement'] = df_val['rates_added'] + df_val['sections_filled']
    print(f"\n  Top 10 most-improved files:")
    for _, row in df_val.nlargest(10, 'total_improvement').iterrows():
        print(f"    +{row['total_improvement']:>3} improvements | "
              f"+{row['rates_added']} rates, {row['sections_filled']} sections filled | "
              f"{row['filename'][:50]}")
    
    # Files with no improvement (gap-fill didn't help)
    no_improve = df_val[df_val['total_improvement'] == 0]
    if len(no_improve) > 0:
        print(f"\n  ⚠️  {len(no_improve)} files had zero improvement (LLM couldn't find the data in PDF)")
    
    print(f"\n  {'=' * 70}")
    print(f"  ✅ Gap-fill pipeline complete.")
    print(f"  Next: Re-run the Extraction Quality Audit on these files to measure new scores.")
    print(f"  Expected improvement: 70% → 85-90% average quality score.")
else:
    print("  ⚠️  No files were gap-filled. Check Step 4 for errors.")
