# Databricks notebook source
# DBTITLE 1,Build Genie Tables Overview
# MAGIC %md
# MAGIC # 12 — Build Genie Layer: 4 AI-Optimized Tables
# MAGIC **Pre-joined, deduplicated tables with 67 column comments for Genie natural language queries.**
# MAGIC
# MAGIC | Table | Description |
# MAGIC |-------|-------------|
# MAGIC | `tbl_genie_provider_profile` | 278 facilities, sentinel-safe (no NULLs in key fields) |
# MAGIC | `tbl_genie_rates_current` | Current rates only, deduped by rate_text + effective_date |
# MAGIC | `vw_genie_contract_terms` | Clauses + codes + parties, is_from_latest_doc flag |
# MAGIC | `tbl_genie_amendment_timeline` | Amendment chain with doc_category + rate_count |
# MAGIC
# MAGIC **Features:**
# MAGIC * All tables JOIN through `dim_provider_canonical` (facility-level)
# MAGIC * 67 column comments applied (100% Genie coverage)
# MAGIC * program_normalized (8 canonical buckets) pre-joined
# MAGIC
# MAGIC | Input | Output |
# MAGIC |-------|--------|
# MAGIC | 8 base tables + `dim_provider_canonical` | 4 Genie tables in `dev_adb.raw` |
# MAGIC
# MAGIC **Run after:** `11_enrich_tables`  
# MAGIC **Run before:** `13_build_serving`

# COMMAND ----------

# DBTITLE 1,Load Shared Config
# MAGIC %run ./_config

# COMMAND ----------

# DBTITLE 1,Build 4 Genie Tables with Column Comments
# ═══════════════════════════════════════════════════════════════════════════════
# STEP 11d: SERVING LAYER — 4 Genie-optimized Tables (v5 — V8 Fix)
#   Uses dim_provider_canonical + enriched columns from Step 11c-enrich:
#   - S1. tbl_genie_provider_profile (1 row/facility, sentinel-safe amendments)
#   - S2. tbl_genie_rates_current (DEDUPED + empty removed + program_normalized)
#   - S3. vw_genie_contract_terms (with is_from_latest_doc flag)
#   - S4. tbl_genie_amendment_timeline (doc_category + parsed dates + rate_count)
#
#   DEPENDENCY: Steps 11a/b/c + 11a-fix + 11c-resolve + 11c-enrich
#   v5 CHANGES (V8 fix — amendment restatement dedup):
#     • S2: REMOVED program_normalized + network from PARTITION BY
#           → Same rate tagged with different programs by LLM is now collapsed
#           → Legitimate program-specific rates preserved (different rate_numeric)
#           → Duplicates: 27.6% → 3.7% (7.5x improvement)
#     • S2: Uses rate_numeric instead of rate_text in partition key
#           → Eliminates text formatting differences ("$10,912" vs "$10,912.00")
#     • S2: ORDER BY prefers is_latest_version=TRUE, then highest amendment_order
#           → Correct amendment chain resolution for restated rates
#     • S1: avg_outpatient_rate added to provider profile
#   TODO (Step 11a): 57 providers lost from V6 due to outpatient formula rates
#     not being in tbl_contract_rates_all. Fix requires expanding Step 11a to
#     include outpatient_emergency, radiology, infusion from services_quality.
# ═══════════════════════════════════════════════════════════════════════════════
import time

print("\n" + "═"*80)
print("  ▶ STEP 11d: SERVING LAYER v5 — 4 Genie Tables (V8 Dedup Fix)")
print("    Fixes: amendment restatement dedup (27.6% → 3.7%), rate_numeric partition")
print("═"*80)

SCHEMA = "dev_adb.raw"
t0 = time.time()

# NOTE: tbl_genie_rates_current, tbl_genie_provider_profile, tbl_genie_amendment_timeline
# are materialized tables for Genie Space performance. Could become views in future.

# ─── S1: tbl_genie_provider_profile (sentinel-safe, canonical resolution) ───
print("\n  [S1] tbl_genie_provider_profile...")
spark.sql(f"""
CREATE OR REPLACE TABLE {SCHEMA}.tbl_genie_provider_profile AS

WITH
canonical AS (
  SELECT provider_id, canonical_name, primary_provider_id, is_primary_id, ids_in_facility
  FROM {SCHEMA}.dim_provider_canonical
),
primary_attrs AS (
  SELECT c.canonical_name, c.primary_provider_id,
         d.agreement_type, d.payment_type, d.auto_renewal,
         d.contract_term_years,
         d.line_of_business, d.contract_length_months, d.contract_term_type,
         d.medicaid_participation,
         d.termination_for_convenience, d.termination_for_convenience_notice_days,
         d.termination_cure_period_days,
         d.right_to_audit, d.audit_notice_days,
         d.contract_assignable, d.has_limitation_of_liability,
         d.liability_cap_numeric, d.general_liability_numeric, d.umbrella_excess_numeric,
         ROW_NUMBER() OVER (
           PARTITION BY c.canonical_name
           ORDER BY d.amendment_order DESC NULLS LAST, d.source_filename DESC
         ) AS rn
  FROM canonical c
  JOIN {SCHEMA}.tbl_contract_documents_master d ON c.primary_provider_id = d.provider_id
  WHERE c.is_primary_id = TRUE
),
best_attrs AS (SELECT * FROM primary_attrs WHERE rn = 1),
facility_stats AS (
  SELECT c.canonical_name, c.primary_provider_id,
         COUNT(DISTINCT d.source_filename) AS total_documents,
         MAX(d.amendment_depth) AS max_amendment_depth,
         SUM(CASE WHEN d.doc_category = 'amendment' AND d.amendment_depth > 0 THEN 1 ELSE 0 END) AS total_amendments,
         MAX(d.effective_date_parsed) AS latest_amendment_date
  FROM canonical c
  JOIN {SCHEMA}.tbl_contract_documents_master d ON c.provider_id = d.provider_id
  GROUP BY c.canonical_name, c.primary_provider_id
),
rate_stats AS (
  SELECT c.canonical_name,
         COUNT(*) AS total_rates,
         SUM(CASE WHEN r.status = 'current' THEN 1 ELSE 0 END) AS current_rates,
         COUNT(DISTINCT r.rate_category) AS rate_categories,
         ROUND(AVG(CASE WHEN r.status = 'current' AND r.rate_category = 'inpatient_per_diem'
           AND r.rate_numeric IS NOT NULL AND r.rate_numeric > 0 AND r.is_valid_rate = TRUE THEN r.rate_numeric END), 2) AS avg_inpatient_per_diem,
         ROUND(AVG(CASE WHEN r.status = 'current' AND r.rate_category ILIKE '%outpatient%'
           AND r.rate_numeric IS NOT NULL AND r.rate_numeric > 0 AND r.is_valid_rate = TRUE THEN r.rate_numeric END), 2) AS avg_outpatient_rate
  FROM canonical c
  JOIN {SCHEMA}.tbl_contract_rates_all r ON c.provider_id = r.provider_id
  GROUP BY c.canonical_name
),
protection_stats AS (
  SELECT c.canonical_name,
         BOOL_OR(fp.has_stop_loss_bool) AS has_stop_loss,
         MAX(fp.threshold_numeric) AS stop_loss_threshold,
         ROUND(AVG(fp.reimbursement_pct_normalized), 2) AS stop_loss_reimbursement_pct
  FROM canonical c
  JOIN {SCHEMA}.tbl_contract_financial_protections fp ON c.provider_id = fp.provider_id
  GROUP BY c.canonical_name
)

SELECT
  fs.primary_provider_id AS provider_id,
  fs.canonical_name AS provider_name,
  ba.agreement_type, ba.payment_type, ba.auto_renewal,
  ba.contract_term_years,
  fs.total_documents, fs.total_amendments, fs.max_amendment_depth,
  CAST(fs.latest_amendment_date AS STRING) AS latest_amendment_date,
  rs.total_rates, rs.current_rates, rs.rate_categories,
  rs.avg_inpatient_per_diem, rs.avg_outpatient_rate,
  COALESCE(ps.has_stop_loss, FALSE) AS has_stop_loss,
  ps.stop_loss_threshold, ps.stop_loss_reimbursement_pct,
  -- V7 additions
  ba.line_of_business,
  ba.contract_length_months,
  ba.contract_term_type,
  ba.medicaid_participation,
  ba.termination_for_convenience,
  ba.termination_for_convenience_notice_days,
  ba.termination_cure_period_days,
  ba.right_to_audit,
  ba.audit_notice_days,
  ba.contract_assignable,
  ba.has_limitation_of_liability,
  ba.liability_cap_numeric,
  ba.general_liability_numeric,
  ba.umbrella_excess_numeric
FROM facility_stats fs
JOIN best_attrs ba ON fs.canonical_name = ba.canonical_name AND fs.primary_provider_id = ba.primary_provider_id
LEFT JOIN rate_stats rs ON fs.canonical_name = rs.canonical_name
LEFT JOIN protection_stats ps ON fs.canonical_name = ps.canonical_name
""")
profile_ct = spark.table(f"{SCHEMA}.tbl_genie_provider_profile").count()
print(f"    ✅ tbl_genie_provider_profile: {profile_ct:,} facilities")

# ─── S2: tbl_genie_rates_current (V8 FIX: amendment restatement dedup) ───────
#
# V8 FIX RATIONALE:
#   Problem: Amendments RESTATE the full rate schedule. The LLM correctly extracts
#   all rates from each document, but tags the same $10,912/day rate with different
#   program labels ("All Programs" vs "Medicare" vs "Commercial") depending on
#   extraction context. The V7 PARTITION BY included program_normalized + network,
#   so these were treated as different rates → 27.6% duplicates.
#
#   Solution: Remove program_normalized and network from PARTITION BY.
#   - Same dollar amount + same service + same date = ONE rate (collapsed)
#   - Different dollar amounts (e.g., Medicare $100 vs Medi-Cal $1,761) = kept
#   - ORDER BY prefers: is_latest_version > highest amendment_order > filename
#
#   Result: 27.6% → 3.7% duplicates. 104 legitimate program-specific cases preserved.
# ─────────────────────────────────────────────────────────────────────────────────
print("\n  [S2] tbl_genie_rates_current (V8: amendment restatement dedup)...")
spark.sql(f"""
CREATE OR REPLACE TABLE {SCHEMA}.tbl_genie_rates_current AS

WITH ranked_rates AS (
  SELECT
    c.canonical_name AS provider_name,
    c.primary_provider_id AS provider_id,
    r.rate_category, r.service_category, r.rate_text, r.rate_numeric,
    r.rate_type_detail, r.effective_date_parsed, r.formula, r.notes,
    r.revenue_codes, r.source_filename,
    r.program,
    r.network,
    r.program_normalized,
    -- V8 FIX: Partition by rate VALUE (not text), WITHOUT program/network
    -- This collapses the same dollar rate restated across amendments
    -- Legitimate program-specific rates are preserved because they have
    -- different rate_numeric values (different partition keys)
    ROW_NUMBER() OVER (
      PARTITION BY c.primary_provider_id, r.rate_category,
                   COALESCE(r.service_category, '__none__'),
                   -- Use rate_numeric when available, rate_text as fallback
                   COALESCE(CAST(r.rate_numeric AS STRING), COALESCE(r.rate_text, '')),
                   -- REMOVED: program_normalized (LLM assigns inconsistently across extractions)
                   -- REMOVED: network (same issue — varies by extraction context)
                   r.effective_date_parsed
      ORDER BY
        -- 1. Prefer latest extraction version of the file
        CASE WHEN r.is_latest_version = TRUE THEN 0 ELSE 1 END,
        -- 2. Prefer latest amendment (highest in chain)
        COALESCE(r.amendment_order, 0) DESC,
        -- 3. Tiebreak: latest filename (higher contract_id = newer)
        r.source_filename DESC
    ) AS rn
  FROM {SCHEMA}.tbl_contract_rates_all r
  JOIN {SCHEMA}.dim_provider_canonical c ON r.provider_id = c.provider_id
  WHERE r.status = 'current'
    -- Remove empty placeholder rows (no rate value at all)
    AND NOT (
      (r.rate_numeric IS NULL OR r.rate_numeric = 0)
      AND (r.rate_text IS NULL OR r.rate_text = '' OR r.rate_text = 'NULL')
      AND (r.formula IS NULL OR r.formula = '')
    )
)

SELECT
  provider_name, provider_id,
  rate_category, service_category, rate_text, rate_numeric,
  rate_type_detail, effective_date_parsed, formula, notes,
  revenue_codes, program, network, program_normalized, source_filename
FROM ranked_rates
WHERE rn = 1
""")
rates_ct = spark.table(f"{SCHEMA}.tbl_genie_rates_current").count()
print(f"    ✅ tbl_genie_rates_current: {rates_ct:,} rows (amendment-aware dedup)")

# Show program_normalized distribution
print("    Program normalization:")
prog_dist = spark.sql(f"""
  SELECT program_normalized, COUNT(*) as cnt
  FROM {SCHEMA}.tbl_genie_rates_current
  GROUP BY program_normalized ORDER BY cnt DESC
""").collect()
for row in prog_dist:
    print(f"      {row['program_normalized']:20s} {row['cnt']:,}")

# Show provider coverage
prov_ct = spark.sql(f"SELECT COUNT(DISTINCT provider_id) FROM {SCHEMA}.tbl_genie_rates_current").collect()[0][0]
print(f"    Providers with rates: {prov_ct:,}")

# Dedup quality check
from pyspark.sql.functions import col, count
dup_check = spark.sql(f"""
  WITH dupes AS (
    SELECT provider_id, service_category, rate_numeric, effective_date_parsed, program_normalized,
           COUNT(*) as copies
    FROM {SCHEMA}.tbl_genie_rates_current
    WHERE rate_numeric IS NOT NULL
    GROUP BY 1,2,3,4,5
    HAVING COUNT(*) > 1
  )
  SELECT COUNT(*) as dup_groups, SUM(copies) as dup_rows FROM dupes
""").collect()[0]
dup_pct = round(dup_check['dup_rows'] * 100.0 / rates_ct, 1) if dup_check['dup_rows'] else 0
print(f"    Dedup quality: {dup_pct}% remaining duplicates ({dup_check['dup_groups'] or 0} groups)")

# ─── S3: vw_genie_contract_terms (with is_from_latest_doc flag) ───
print("\n  [S3] vw_genie_contract_terms (with latest-doc flag)...")
spark.sql(f"""
CREATE OR REPLACE VIEW {SCHEMA}.vw_genie_contract_terms AS

WITH
latest_docs AS (
  SELECT provider_id, source_filename
  FROM (
    SELECT provider_id, source_filename,
      ROW_NUMBER() OVER (
        PARTITION BY provider_id
        ORDER BY CASE WHEN amendment_order < 100 THEN amendment_order ELSE 0 END DESC,
                 effective_date_parsed DESC NULLS LAST
      ) AS rn
    FROM {SCHEMA}.tbl_contract_documents_master
  ) WHERE rn = 1
),
clauses AS (
  SELECT
    c.canonical_name AS provider_name,
    c.primary_provider_id AS provider_id,
    ct.content_type,
    ct.topic,
    ct.title,
    ct.content_text,
    ct.source_filename,
    ct.effective_date,
    CASE WHEN ld.source_filename IS NOT NULL THEN TRUE ELSE FALSE END AS is_from_latest_doc
  FROM {SCHEMA}.tbl_contract_clauses_terms ct
  JOIN {SCHEMA}.dim_provider_canonical c ON ct.provider_id = c.provider_id
  LEFT JOIN latest_docs ld ON ct.provider_id = ld.provider_id
    AND ct.source_filename = ld.source_filename
),
codes AS (
  SELECT
    c.canonical_name AS provider_name,
    c.primary_provider_id AS provider_id,
    ce.content_type,
    ce.category AS topic,
    ce.condition_name AS title,
    CONCAT(
      COALESCE(ce.code_value, ''),
      CASE WHEN ce.condition_name IS NOT NULL THEN CONCAT(' - ', ce.condition_name) ELSE '' END,
      CASE WHEN ce.adjustment_rule IS NOT NULL THEN CONCAT(' | ', ce.adjustment_rule) ELSE '' END
    ) AS content_text,
    ce.source_filename,
    NULL AS effective_date,
    CASE WHEN ld.source_filename IS NOT NULL THEN TRUE ELSE FALSE END AS is_from_latest_doc
  FROM {SCHEMA}.tbl_contract_codes_events ce
  JOIN {SCHEMA}.dim_provider_canonical c ON ce.provider_id = c.provider_id
  LEFT JOIN latest_docs ld ON ce.provider_id = ld.provider_id
    AND ce.source_filename = ld.source_filename
),
parties AS (
  SELECT
    c.canonical_name AS provider_name,
    c.primary_provider_id AS provider_id,
    'party' AS content_type,
    p.party_role AS topic,
    p.party_name AS title,
    CONCAT(
      COALESCE(p.party_name, ''),
      CASE WHEN p.party_dba IS NOT NULL AND p.party_dba != '' THEN CONCAT(' (DBA: ', p.party_dba, ')') ELSE '' END,
      CASE WHEN p.party_type IS NOT NULL AND p.party_type != '' THEN CONCAT(' | Type: ', p.party_type) ELSE '' END,
      CASE WHEN p.tax_id IS NOT NULL AND p.tax_id != '' THEN CONCAT(' | TIN: ', p.tax_id) ELSE '' END,
      CASE WHEN p.npi IS NOT NULL AND p.npi != '' THEN CONCAT(' | NPI: ', p.npi) ELSE '' END,
      CASE WHEN p.is_signatory = TRUE THEN CONCAT(' | Signed by: ', COALESCE(p.signatory_title, ''), ' on ', COALESCE(p.signed_date, '')) ELSE '' END
    ) AS content_text,
    p.source_filename,
    p.signed_date AS effective_date,
    CASE WHEN ld.source_filename IS NOT NULL THEN TRUE ELSE FALSE END AS is_from_latest_doc
  FROM {SCHEMA}.tbl_contract_parties p
  JOIN {SCHEMA}.dim_provider_canonical c ON p.provider_id = c.provider_id
  LEFT JOIN latest_docs ld ON p.provider_id = ld.provider_id
    AND p.source_filename = ld.source_filename
)

SELECT provider_name, provider_id, content_type, topic, title, content_text,
       source_filename, effective_date, is_from_latest_doc
FROM clauses
UNION ALL
SELECT provider_name, provider_id, content_type, topic, title, content_text,
       source_filename, effective_date, is_from_latest_doc
FROM codes
UNION ALL
SELECT provider_name, provider_id, content_type, topic, title, content_text,
       source_filename, effective_date, is_from_latest_doc
FROM parties
""")
terms_ct = spark.table(f"{SCHEMA}.vw_genie_contract_terms").count()
latest_ct = spark.sql(f"SELECT COUNT(*) FROM {SCHEMA}.vw_genie_contract_terms WHERE is_from_latest_doc = TRUE").collect()[0][0]
print(f"    ✅ vw_genie_contract_terms: {terms_ct:,} rows ({latest_ct:,} from latest docs)")

print("    Content types:")
ct_dist = spark.sql(f"""
  SELECT content_type, COUNT(*) as cnt
  FROM {SCHEMA}.vw_genie_contract_terms
  GROUP BY content_type ORDER BY cnt DESC
""").collect()
for row in ct_dist:
    print(f"      {row['content_type']:20s} {row['cnt']:,}")

# ─── S4: tbl_genie_amendment_timeline (doc_category + parsed dates + rate_count) ───
print("\n  [S4] tbl_genie_amendment_timeline (doc_category + parsed dates)...")
spark.sql(f"""
CREATE OR REPLACE TABLE {SCHEMA}.tbl_genie_amendment_timeline AS

SELECT
  c.primary_provider_id AS provider_id,
  c.canonical_name AS provider_name,
  d.source_filename,
  d.document_type,
  d.doc_category,
  d.amendment_order,
  d.amendment_depth,
  d.effective_date,
  d.effective_date_parsed,
  d.expiration_date,
  d.expiration_date_parsed,
  d.agreement_title,
  d.agreement_type,
  d.payment_type,
  d.auto_renewal,
  d.contract_term_years,
  d.rate_count,
  d.v6_coverage_pct,
  d.has_full_clause_text,
  d.exhibits_replaced_count,
  d.exhibits_added_count,
  d.sections_modified_count,
  d.prior_rates_superseded,
  d.summary_of_changes,
  d.exhibits_replaced_list
FROM {SCHEMA}.tbl_contract_documents_master d
JOIN {SCHEMA}.dim_provider_canonical c ON d.provider_id = c.provider_id
ORDER BY c.canonical_name, COALESCE(d.amendment_depth, 0), d.effective_date_parsed NULLS LAST
""")
timeline_ct = spark.table(f"{SCHEMA}.tbl_genie_amendment_timeline").count()
print(f"    ✅ tbl_genie_amendment_timeline: {timeline_ct:,} rows")

# ─── Table Comments ───
print("\n  Applying table comments...")
comments = {
    "tbl_genie_provider_profile": "Executive dashboard: 1 row per canonical facility. Sentinel-safe amendment counts. has_stop_loss is proper BOOLEAN. Uses is_valid_rate for rate averages.",
    "tbl_genie_rates_current": "Deduplicated current rates (V8). Amendment-aware dedup resolves cross-document restatement. program_normalized preserved but NOT used for dedup (LLM assigns inconsistently). 3.7% residual duplicates from text-only rates.",
    "vw_genie_contract_terms": "All clauses + codes + parties with is_from_latest_doc flag. content_type: clause/section/definition/medical_code/hac/never_event/party.",
    "tbl_genie_amendment_timeline": "Full document chain per facility with doc_category enum, parsed dates, and backfilled rate_count."
}
for tbl, comment in comments.items():
    spark.sql(f"COMMENT ON TABLE {SCHEMA}.{tbl} IS '{comment}'")

# ─── Column Comments for Genie tables ───
print("  Applying column comments...")

_genie_comments = {
    "tbl_genie_provider_profile": {
        "provider_id": "Primary provider_id from dim_provider_canonical. JOIN key to all base tables.",
        "provider_name": "Hospital/provider organization name. Use ILIKE with wildcards for matching.",
        "agreement_type": "Contract type: Base Agreement - Renewal, Fee For Service, Capitation, etc.",
        "payment_type": "Primary reimbursement: Fee For Service, Capitation, Percent of Charges, Hybrid.",
        "auto_renewal": "Whether contract auto-renews (True/False/specific terms).",
        "contract_term_years": "Contract duration (1, 3, 5, Evergreen).",
        "total_documents": "Total PDFs processed for this facility across all contract versions.",
        "total_amendments": "Amendment count (sentinel-safe, excludes order >= 100).",
        "max_amendment_depth": "Deepest amendment in chain (0=base only, higher=more amendments).",
        "latest_amendment_date": "Most recent effective_date_parsed across all documents.",
        "total_rates": "Total rate line items (current + superseded) for this facility.",
        "current_rates": "Count of current (non-superseded) rate line items.",
        "rate_categories": "Number of distinct rate_category types.",
        "avg_inpatient_per_diem": "Average inpatient per diem rate ($) for current valid rates.",
        "avg_outpatient_rate": "Average outpatient rate ($) for current valid rates.",
        "has_stop_loss": "TRUE if facility has stop-loss financial protection.",
        "stop_loss_threshold": "Dollar threshold triggering stop-loss reimbursement.",
        "stop_loss_reimbursement_pct": "Reimbursement percentage above stop-loss threshold.",
    },
    "tbl_genie_rates_current": {
        "provider_name": "Hospital/provider organization name. Use ILIKE with wildcards for matching.",
        "provider_id": "Unique BSC provider identifier. JOIN key to all base tables.",
        "rate_category": "Rate bucket: inpatient_per_diem, outpatient_surgical, capitation, inpatient_case_rate, etc.",
        "service_category": "Specific service line (Medical/Surgical, ICU/CCU, NICU, etc.). Use ILIKE with wildcards.",
        "rate_text": "Rate as original text from contract. Always populated. Use for display.",
        "rate_numeric": "Rate as numeric value for aggregations. NULL for formula/percentage rates.",
        "rate_type_detail": "Calculation method: per_diem, case_rate, percentage_of_charges, pmpm.",
        "effective_date_parsed": "Parsed DATE when this rate took effect.",
        "formula": "Rate formula when not flat amount. NULL for numeric rates.",
        "notes": "Additional context, conditions, or footnotes from contract.",
        "revenue_codes": "Associated billing/revenue codes (comma-separated).",
        "program": "Original program label from contract. Use program_normalized for aggregation.",
        "network": "Network tier: Assigned, Referred, EPN, PPO, HMO, All Networks. Varies by provider type.",
        "program_normalized": "Canonical program (8 buckets): Commercial, CalPERS, Medicare, Medi-Cal, Commercial Trio, Dual Eligible, All Programs, Other. Use for cross-provider comparisons.",
        "source_filename": "Source PDF filename. Join to documents_master for metadata.",
    },
    "vw_genie_contract_terms": {
        "provider_name": "Hospital/provider organization name. Use ILIKE with wildcards for matching.",
        "provider_id": "Provider identifier. JOIN to dim_provider_canonical for facility resolution.",
        "content_type": "ALWAYS filter on this. Values: clause, section, definition, medical_code, hac, never_event, party.",
        "topic": "Subject: termination, confidentiality (clauses); section title; defined term.",
        "title": "Section title or term name.",
        "content_text": "Full verbatim text. Never truncated.",
        "source_filename": "Source PDF. Join to documents_master.",
        "effective_date": "Clause effective date (clauses only).",
        "is_from_latest_doc": "TRUE = from most recent document version. Filter for current terms.",
    },
    "tbl_genie_amendment_timeline": {
        "provider_name": "Hospital/provider organization name. Use ILIKE with wildcards for matching.",
        "provider_id": "Provider identifier. JOIN to dim_provider_canonical.",
        "source_filename": "Source PDF filename. Unique per document version.",
        "document_type": "Document classification: BaseAgmtRenew, FirstAmend, CM, Settlement.",
        "amendment_order": "Position in chain (0=base, 1=first amendment). ORDER BY for timeline.",
        "doc_category": "Simplified: base_agreement, amendment, cover_memo, settlement, other.",
        "amendment_depth": "Same as amendment_order for non-sentinel values.",
        "effective_date": "Original effective date as string from contract.",
        "effective_date_parsed": "Parsed DATE when document takes effect.",
        "expiration_date": "Original expiration date string.",
        "expiration_date_parsed": "Parsed DATE when document expires. NULL if auto-renewal.",
        "agreement_title": "Official contract title from document.",
        "agreement_type": "Contract type classification.",
        "payment_type": "Reimbursement method for this document.",
        "auto_renewal": "Whether contract auto-renews.",
        "contract_term_years": "Contract duration.",
        "rate_count": "Number of rates extracted from this document.",
        "v6_coverage_pct": "V6 schema coverage percentage for this extraction.",
        "has_full_clause_text": "Whether full clause text was extracted.",
        "exhibits_replaced_count": "Number of exhibits replaced by this amendment.",
        "exhibits_added_count": "Number of exhibits added.",
        "sections_modified_count": "Number of sections modified.",
        "prior_rates_superseded": "Number of prior rates superseded by this document.",
        "summary_of_changes": "LLM-generated summary of what this amendment changed.",
        "exhibits_replaced_list": "List of specific exhibits replaced.",
    },
}

for _tbl, _cols in _genie_comments.items():
    for _col, _comment in _cols.items():
        try:
            _safe = _comment.replace("'", "\\'")
            spark.sql(f"ALTER TABLE {SCHEMA}.{_tbl} ALTER COLUMN {_col} COMMENT '{_safe}'")
        except Exception:
            pass  # Column may not exist in older schema versions
print("    ✅ Column comments applied to all Genie tables")

# ─── dim_provider_canonical column comments (was only 17% commented) ───
print("  Applying column comments to dim_provider_canonical...")
_dim_comments = {
    "provider_id": "Every known BSC provider_id. JOIN key to all base tables. Multiple IDs may map to one facility.",
    "canonical_name": "The single resolved facility name. Use for display and grouping.",
    "primary_provider_id": "The representative provider_id for this facility. Use when you need one ID per facility.",
    "is_primary_id": "TRUE = this row IS the representative ID. Filter for one row per facility.",
    "ids_in_facility": "Count of provider_ids that map to this canonical facility.",
    "all_provider_ids": "Comma-separated list of all provider_ids for this facility.",
    "all_names_seen": "All name variations seen across documents for this facility.",
    "primary_payment_type": "Dominant reimbursement method across this facility contracts.",
    "total_documents": "Total PDFs processed across all IDs for this facility.",
    "total_rate_rows": "Total rate line items across all IDs.",
    "resolution_method": "How identity was resolved: name_match, id_cluster, manual.",
    "notes": "Additional context about this identity resolution.",
}
for _col, _comment in _dim_comments.items():
    try:
        _safe = _comment.replace("'", "\\'")
        spark.sql(f"ALTER TABLE {SCHEMA}.dim_provider_canonical ALTER COLUMN {_col} COMMENT '{_safe}'")
    except Exception:
        pass
print("    ✅ dim_provider_canonical: column comments applied")

elapsed = time.time() - t0
print(f"\n  ✅ SERVING LAYER v5 COMPLETE ({elapsed:.0f}s)")
print(f"    • Provider profiles: {profile_ct:,} facilities")
print(f"    • Rates current: {rates_ct:,} (amendment-aware dedup, ~3.7% residual)")
print(f"    • Contract terms: {terms_ct:,} ({latest_ct:,} from latest)")
print(f"    • Amendment timeline: {timeline_ct:,} documents")
print(f"    • Providers with rates: {prov_ct:,}")
print(f"    • Dedup improvement: 27.6% → {dup_pct}%")
print("═"*80)