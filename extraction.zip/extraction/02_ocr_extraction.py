# Databricks notebook source
# DBTITLE 1,OCR Extraction Overview
# MAGIC %md
# MAGIC # 02 — OCR Text Extraction (2-Tier)
# MAGIC **Extracts text from PDFs using pypdf (Tier 1) and ai_parse_document (Tier 2).**
# MAGIC
# MAGIC | Tier | Tool | Handles | Speed |
# MAGIC |------|------|---------|-------|
# MAGIC | 1 | pypdf (14 processes) | ~82% of files | ~5x parallel via ProcessPoolExecutor |
# MAGIC | 2 | ai_parse_document | Scanned/complex PDFs | Paid API, batch of 25 |
# MAGIC
# MAGIC | Input | Output |
# MAGIC |-------|--------|
# MAGIC | `file_registry` dict (from 01) | `checkpoints/step1_parsed_v2.parquet` |
# MAGIC | `valid_files` list (from 01) | Text for each PDF (full_text column) |
# MAGIC
# MAGIC **Run after:** `01_file_discovery`  
# MAGIC **Run before:** `03_metadata_parsing`

# COMMAND ----------

# DBTITLE 1,Load Shared Config
# MAGIC %run ./_config

# COMMAND ----------

# DBTITLE 1,Install Dependencies
# MAGIC %pip install pypdf -q

# COMMAND ----------

# DBTITLE 1,State Bootstrap for Job Runs
# ═══ STATE BOOTSTRAP FOR JOB RUNS ═══
# When running as a Lakeflow job task, each notebook starts with a fresh kernel.
# This cell reconstructs all state that would normally be inherited from 01_file_discovery.
import os, time, random, math, warnings, logging, shutil
import pandas as pd
import numpy as np
import io
from pyspark.sql.types import StructType, StructField, StringType, BinaryType
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor, as_completed

# ── Step-specific config (mirrors 01_file_discovery) ──
SAMPLE_MODE        = dbutils.widgets.get("run_mode") == "sample"
NUM_PROVIDERS      = int(dbutils.widgets.get("num_providers") or '5')
PYPDF_WORKERS      = 14
PYPDF_TIMEOUT      = 30
AI_BATCH_SIZE      = 25
AI_CONCURRENCY     = 20
# MIN_GOOD_CHARS, MIN_CHARS_PER_PAGE, MAX_EMPTY_PAGE_RATIO, EMPTY_PAGE_THRESHOLD
# are now defined in _config (shared across all notebooks)
LOCAL_PDF_DIR      = "/local_disk0/tmp/provider_contracts"

try:
    from pypdf import PdfReader
    HAS_PYPDF = True
    warnings.filterwarnings('ignore', module='pypdf')
    logging.getLogger('pypdf').setLevel(logging.ERROR)
except ImportError:
    HAS_PYPDF = False
    pipe_log.warning("pypdf not installed — starting from Tier 2")

# ── Rebuild file_registry from checkpoint written by 01_file_discovery ──
REGISTRY_CACHE = f"{CHECKPOINT_DIR}/file_registry_v2.parquet"
if not os.path.exists(REGISTRY_CACHE):
    raise FileNotFoundError(
        f"file_registry_v2.parquet not found at {REGISTRY_CACHE}. "
        "Ensure 01_file_discovery completed successfully before running this task."
    )
_reg_df = pd.read_parquet(REGISTRY_CACHE)
file_registry = {
    r['filename']: {
        'path': r['path'],
        'provider_folder': r['provider_folder'],
        'file_size_bytes': int(r['file_size_bytes'])
    }
    for _, r in _reg_df.iterrows()
}
# Prefer local SSD paths if prefetch completed
for fname, meta in file_registry.items():
    local_path = os.path.join(LOCAL_PDF_DIR, meta['provider_folder'] or '', fname)
    if os.path.exists(local_path):
        file_registry[fname]['path'] = local_path

pipe_log.info(f"Bootstrap: loaded {len(file_registry):,} files from registry cache")

# ── Rebuild already_parsed and existing_df from step1 checkpoint ──
already_parsed = set()
existing_df = None
if os.path.exists(STEP1_FILE):
    try:
        existing_df = pd.read_parquet(STEP1_FILE)
        for col, default in [('extraction_method', 'unknown'), ('provider_folder', None),
                              ('file_size_bytes', 0), ('ocr_pages_processed', 0)]:
            if col not in existing_df.columns:
                existing_df[col] = default
        already_parsed = set(existing_df['filename'])
        pipe_log.info(f"Bootstrap: {len(already_parsed):,} files already parsed (resuming)")
    except Exception:
        existing_df = None

# ── Reconstruct valid_files and empty_files ──
all_filenames = sorted(file_registry.keys())
if SAMPLE_MODE:
    from collections import defaultdict
    folder_to_files = defaultdict(list)
    for fname, meta in file_registry.items():
        folder_key = meta['provider_folder'] or '__ROOT__'
        folder_to_files[folder_key].append(fname)
    all_folders = sorted(folder_to_files.keys())
    random.seed(42)
    selected_folders = random.sample(all_folders, min(NUM_PROVIDERS, len(all_folders)))
    all_filenames = []
    for folder in selected_folders:
        all_filenames.extend(sorted(folder_to_files[folder]))

valid_files = [f for f in all_filenames if f not in already_parsed and file_registry[f]['file_size_bytes'] > 0]
empty_files  = [f for f in all_filenames if f not in already_parsed and file_registry[f]['file_size_bytes'] == 0]
NEW_FILES_FOUND = len(valid_files) > 0 or len(empty_files) > 0

mode = f"SAMPLE({NUM_PROVIDERS} providers)" if SAMPLE_MODE else "FULL"
print(f"  📊 Bootstrap complete | Mode: {mode} | Queued: {len(valid_files):,} | Cached: {len(already_parsed):,} | Empty: {len(empty_files):,}")

# COMMAND ----------

# DBTITLE 1,pypdf Extraction Function (Process-Safe)
def _pypdf_extract_proc(fname, path, provider_folder, file_size_bytes, timeout_sec):
    """Process-safe pypdf extraction with per-page timeout enforcement.
    
    Called by ProcessPoolExecutor — each invocation runs in a separate OS process,
    bypassing the GIL for true CPU parallelism. The internal timeout checks after
    each page and bails out if elapsed > timeout_sec.
    """
    import time
    from pypdf import PdfReader
    start = time.time()
    try:
        reader = PdfReader(path)
        if reader.is_encrypted:
            try:
                reader.decrypt('')
            except Exception:
                return {'filename': fname, 'path': path, 'num_pages': 0,
                        'full_text': '', 'text_length': 0, 'parse_error': 'encrypted_pdf',
                        'provider_folder': provider_folder, 'file_size_bytes': file_size_bytes}
        pages_text = []
        page_char_counts = []
        for page in reader.pages:
            if time.time() - start > timeout_sec:
                return {'filename': fname, 'path': path, 'num_pages': len(reader.pages),
                        'full_text': '\n\n--- PAGE_BREAK ---\n\n'.join(pages_text),
                        'text_length': sum(page_char_counts),
                        'page_char_counts': page_char_counts,
                        'empty_page_count': sum(1 for c in page_char_counts if c < 50),
                        'parse_error': f'timeout_{timeout_sec}s',
                        'provider_folder': provider_folder, 'file_size_bytes': file_size_bytes}
            text = page.extract_text() or ''
            pages_text.append(text)
            page_char_counts.append(len(text))
        full_text = '\n\n--- PAGE_BREAK ---\n\n'.join(pages_text)
        return {'filename': fname, 'path': path, 'num_pages': len(reader.pages),
                'full_text': full_text, 'text_length': sum(page_char_counts),
                'page_char_counts': page_char_counts,
                'empty_page_count': sum(1 for c in page_char_counts if c < 50),
                'parse_error': None,
                'provider_folder': provider_folder, 'file_size_bytes': file_size_bytes}
    except Exception as e:
        return {'filename': fname, 'path': path, 'num_pages': 0,
                'full_text': '', 'text_length': 0, 'parse_error': f'pypdf error: {e}',
                'provider_folder': provider_folder, 'file_size_bytes': file_size_bytes}



# COMMAND ----------

# DBTITLE 1,Tier 1 - pypdf Multiprocess Extraction
all_results = []

# Process empty files
for f in empty_files:
    m = file_registry[f]
    all_results.append({'filename': f, 'path': m['path'], 'parse_error': 'Empty file',
        'num_pages': 0, 'full_text': '', 'text_length': 0, 'extraction_method': 'empty',
        'provider_folder': m['provider_folder'], 'file_size_bytes': 0, 'ocr_pages_processed': 0})

# ═══ TIER 1: pypdf (ProcessPoolExecutor — bypasses GIL for true parallelism) ═══
ocr_candidates_df = pd.DataFrame()
if valid_files and HAS_PYPDF:
    print(f"\n  ── Tier 1: pypdf ({len(valid_files):,} files, {PYPDF_WORKERS} processes, {PYPDF_TIMEOUT}s timeout)")
    t0 = time.time()
    _tier1_timeout_count = 0

    _tier1_args = [(fname, file_registry[fname]['path'], file_registry[fname]['provider_folder'],
                    file_registry[fname]['file_size_bytes'], PYPDF_TIMEOUT) for fname in valid_files]

    pypdf_results = []
    with ProcessPoolExecutor(max_workers=min(PYPDF_WORKERS, len(valid_files))) as ex:
        futures = {ex.submit(_pypdf_extract_proc, *args): args[0] for args in _tier1_args}
        done_count = 0
        for fut in as_completed(futures):
            result = fut.result()
            pypdf_results.append(result)
            if result.get('parse_error') and 'timeout' in str(result.get('parse_error', '')):
                _tier1_timeout_count += 1
            done_count += 1
            if done_count % 500 == 0:
                elapsed = time.time() - t0
                rate = done_count / elapsed
                eta_min = (len(valid_files) - done_count) / rate / 60 if rate > 0 else 0
                print(f"     Tier 1 progress: {done_count:,}/{len(valid_files):,} ({rate:.1f} files/s, ETA {eta_min:.0f}m, timeouts: {_tier1_timeout_count})")

    pypdf_df = pd.DataFrame(pypdf_results)
    # ═══ FIXED QUALITY GATE: per-page empty ratio check (not just average) ═══
    # Old logic used only average chars/page which missed mixed-content PDFs
    # (e.g. 151-page doc with 7 text pages + 144 scanned → avg=110 → PASSED!)
    pypdf_df['empty_page_count'] = pypdf_df['page_char_counts'].apply(
        lambda counts: sum(1 for c in (counts or []) if c < EMPTY_PAGE_THRESHOLD))
    pypdf_df['empty_page_ratio'] = pypdf_df['empty_page_count'] / pypdf_df['num_pages'].clip(lower=1)

    too_short_total = pypdf_df['text_length'].fillna(0) < MIN_GOOD_CHARS
    too_many_empty = pypdf_df['empty_page_ratio'] > MAX_EMPTY_PAGE_RATIO
    too_low_avg = (pypdf_df['text_length'].fillna(0) / pypdf_df['num_pages'].clip(lower=1)) < MIN_CHARS_PER_PAGE
    needs_ocr_mask = too_short_total | too_many_empty | too_low_avg

    _empty_routed = too_many_empty.sum()
    good_df = pypdf_df[~needs_ocr_mask].copy()
    good_df['extraction_method'] = 'pypdf'
    good_df['ocr_pages_processed'] = 0
    # Drop page_char_counts before saving (not parquet-friendly as list)
    good_df = good_df.drop(columns=['page_char_counts', 'empty_page_count', 'empty_page_ratio'], errors='ignore')
    all_results.extend(good_df.to_dict('records'))
    ocr_candidates_df = pypdf_df[needs_ocr_mask].copy()
    print(f"     ✅ Tier 1 done: {len(good_df):,} OK, {len(ocr_candidates_df):,} → Tier 2 (timeouts: {_tier1_timeout_count}, empty-page-routed: {_empty_routed}) ({time.time()-t0:.1f}s)")

    # ─── CHECKPOINT: Save Tier 1 results immediately ───
    if all_results:
        _t1_df = pd.DataFrame(all_results)
        _t1_combined = pd.concat([existing_df, _t1_df], ignore_index=True).drop_duplicates('filename', keep='last') if existing_df is not None else _t1_df
        _t1_combined = _t1_combined.loc[:, ~_t1_combined.columns.duplicated()]  # Fix: remove duplicate columns before parquet save
        _t1_combined.to_parquet(STEP1_FILE, index=False)
        existing_df = _t1_combined
        already_parsed = set(_t1_combined['filename'])
        print(f"     💾 Tier 1 checkpoint saved: {len(_t1_combined):,} files")


# COMMAND ----------

# DBTITLE 1,Tier 2 - ai_parse_document for Failed/Scanned PDFs
# ═══ TIER 2: ai_parse_document (scanned/complex PDFs) ═══
# Replaces pytesseract OCR which was too slow (150+ hrs for 1,246 files).
# ai_parse_document is Spark-distributed, batched, and produces higher quality
# output for scanned documents.
if len(ocr_candidates_df) > 0:
    ai_filenames = ocr_candidates_df['filename'].tolist()
    # Build lookup of pypdf partial text (used as fallback if ai_parse fails)
    _pypdf_partial = dict(zip(ocr_candidates_df['filename'],
                              zip(ocr_candidates_df['text_length'].fillna(0).astype(int),
                                  ocr_candidates_df['full_text'].fillna(''))))
    
    print(f"\n  ── Tier 2: ai_parse_document ({len(ai_filenames):,} files, batch={AI_BATCH_SIZE}, concurrency={AI_CONCURRENCY})")
    ai_filenames.sort(key=lambda f: file_registry[f]['file_size_bytes'])
    t_ai = time.time()

    binary_schema = StructType([StructField('filename', StringType()), StructField('content', BinaryType())])
    def _read_binary(fname):
        with open(file_registry[fname]['path'], 'rb') as fh:
            return (fname, fh.read())

    num_batches = math.ceil(len(ai_filenames) / AI_BATCH_SIZE)
    ai_ok = ai_fallback = ai_empty = 0

    for bi in range(num_batches):
        batch = ai_filenames[bi * AI_BATCH_SIZE : (bi + 1) * AI_BATCH_SIZE]
        with ThreadPoolExecutor(max_workers=min(8, len(batch))) as ex:
            batch_data = list(ex.map(_read_binary, batch))

        n_parts = min(len(batch), AI_CONCURRENCY)
        spark.createDataFrame(batch_data, schema=binary_schema).repartition(n_parts).createOrReplaceTempView("batch_pdfs")

        batch_results = spark.sql("""
            WITH raw AS (SELECT filename, ai_parse_document(content) AS p FROM batch_pdfs),
            parsed AS (
                SELECT filename,
                       try_cast(p:error_status AS STRING) AS parse_error,
                       try_cast(p:document:pages AS ARRAY<VARIANT>) AS pages,
                       try_cast(p:document:elements AS ARRAY<VARIANT>) AS elements
                FROM raw),
            page_aware AS (
                SELECT filename,
                       parse_error,
                       size(pages) AS num_pages,
                       concat_ws('',
                           transform(
                               sequence(0, size(pages) - 1),
                               page_idx -> concat(
                                   CASE WHEN page_idx > 0 THEN '\n\n--- PAGE_BREAK ---\n\n' ELSE '' END,
                                   concat_ws('\n\n',
                                       transform(
                                           filter(elements, e -> try_cast(e:bbox[0]:page_id AS INT) = page_idx),
                                           e -> try_cast(e:content AS STRING)
                                       )
                                   )
                               )
                           )
                       ) AS full_text
                FROM parsed)
            SELECT *, length(full_text) AS text_length FROM page_aware
        """).toPandas()

        for _, row in batch_results.iterrows():
            fname = row['filename']
            m = file_registry[fname]
            ai_len = int(row['text_length'] or 0)
            pypdf_len, pypdf_text = _pypdf_partial.get(fname, (0, ''))
            base = {'provider_folder': m['provider_folder'], 'file_size_bytes': m['file_size_bytes'],
                    'ocr_pages_processed': int(row['num_pages'] or 0)}

            if ai_len > pypdf_len:
                # ai_parse_document produced better text
                result = row.to_dict(); result['path'] = m['path']; result.update(base)
                result['extraction_method'] = 'ai_parse_document'
                ai_ok += 1
            elif pypdf_len > 0:
                # pypdf partial text is better (ai_parse failed or returned less)
                result = {'filename': fname, 'path': m['path'],
                    'num_pages': int(ocr_candidates_df[ocr_candidates_df['filename']==fname]['num_pages'].iloc[0]) if fname in ocr_candidates_df['filename'].values else 0,
                    'full_text': pypdf_text, 'text_length': pypdf_len,
                    'parse_error': None, 'extraction_method': 'pypdf_partial', **base}
                ai_fallback += 1
            else:
                # Both empty — keep ai_parse result anyway
                result = row.to_dict(); result['path'] = m['path']; result.update(base)
                result['extraction_method'] = 'ai_parse_document'
                ai_empty += 1
            all_results.append(result)

        print(f"     Tier 2 batch {bi+1}/{num_batches}: {len(batch)} files (ai_ok:{ai_ok} fallback:{ai_fallback} empty:{ai_empty})")

        # Checkpoint after each batch
        if all_results:
            _ckpt_df = pd.DataFrame(all_results)
            _combined = pd.concat([existing_df, _ckpt_df], ignore_index=True).drop_duplicates('filename', keep='last') if existing_df is not None else _ckpt_df
            _combined.to_parquet(STEP1_FILE, index=False)
            print(f"     💾 Checkpoint saved: {len(_combined):,} total files (batch {bi+1}/{num_batches})")

    print(f"     ✅ Tier 2 done: {ai_ok} ai_parse, {ai_fallback} pypdf_fallback, {ai_empty} empty ({time.time()-t_ai:.1f}s)")
else:
    pipe_log.info("No Tier 2 needed — all files passed Tier 1")

# ═══ SAVE FINAL CHECKPOINT ═══
if all_results:
    new_df = pd.DataFrame(all_results)
    combined = pd.concat([existing_df, new_df], ignore_index=True).drop_duplicates('filename', keep='last') if existing_df is not None else new_df
    combined = combined.loc[:, ~combined.columns.duplicated()]  # Fix: remove duplicate columns before parquet save
    combined.to_parquet(STEP1_FILE, index=False)
    print(f"\n  ═{'='*78}═")
    print(f"  ✅ STEP 1 COMPLETE: {len(combined):,} files saved to checkpoint")
    for m, c in combined['extraction_method'].value_counts().items():
        print(f"     {m:30s} {c:>6,} ({c/len(combined)*100:.1f}%)")
    print(f"  ═{'='*78}═")
else:
    print("\n  ✅ Step 1: No new files to process (all cached)")

# COMMAND ----------

# DBTITLE 1,Post-Extraction Validation & Auto-Requeue
# ═══════════════════════════════════════════════════════════════════════════════
# POST-EXTRACTION VALIDATION: Detect files that still have too many empty pages
# If any slip through (shouldn't happen with new gate), auto-requeue for next run.
# ═══════════════════════════════════════════════════════════════════════════════
final_df = pd.read_parquet(STEP1_FILE)
pypdf_files = final_df[final_df['extraction_method'] == 'pypdf']

suspect = []
for _, row in pypdf_files.iterrows():
    text = row['full_text'] or ''
    num_pages = int(row['num_pages'])
    if num_pages < 2:
        continue
    pages = text.split(PAGE_MARKER) if PAGE_MARKER in text else text.split('\n\n')
    empty = sum(1 for p in pages if len(p.strip()) < EMPTY_PAGE_THRESHOLD)
    ratio = empty / max(num_pages, 1)
    if ratio > MAX_EMPTY_PAGE_RATIO:
        suspect.append(row['filename'])

if suspect:
    pipe_log.warning(f"⚠️ {len(suspect)} files have >{MAX_EMPTY_PAGE_RATIO*100:.0f}% empty pages after extraction!")
    pipe_log.warning(f"   Auto-requeuing for Tier 2 on next run...")
    final_df = final_df[~final_df['filename'].isin(suspect)]
    final_df.to_parquet(STEP1_FILE, index=False)
    pipe_log.info(f"   Removed {len(suspect)} files from checkpoint — will be re-extracted via Tier 2")
else:
    pipe_log.info("✅ Post-extraction validation passed: no files with excessive empty pages")