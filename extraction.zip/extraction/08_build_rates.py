# Databricks notebook source
# DBTITLE 1,Build Rates Overview
# MAGIC %md
# MAGIC # 08 — Build Base Layer: Rates Domain
# MAGIC **Builds 3 rate tables directly from JSON files (zero intermediate dependencies).**
# MAGIC
# MAGIC | Table | Rows (typical) | Description |
# MAGIC |-------|---------------|-------------|
# MAGIC | `tbl_contract_rates_all` | ~68K | All rates: inpatient, outpatient, capitation, case |
# MAGIC | `tbl_contract_regional_factors` | ~2K | County-level geographic adjustments |
# MAGIC | `tbl_contract_financial_protections` | ~1.5K | Stop-loss, outlier, risk corridor |
# MAGIC
# MAGIC **Post-processing (11a-fix):**
# MAGIC * Rate status supersession via amendment_order
# MAGIC * Program/network NULL defaults (Commercial / All Networks)
# MAGIC * Program normalization (148 variants → 8 canonical buckets)
# MAGIC * Zero-current safety net (every provider gets ≥1 current rate)
# MAGIC
# MAGIC | Input | Output |
# MAGIC |-------|--------|
# MAGIC | `json_extract/*.json` | 3 Delta tables in `dev_adb.raw` |
# MAGIC
# MAGIC **Run after:** `07_consolidation`  
# MAGIC **Run before:** `09_build_terms`

# COMMAND ----------

# DBTITLE 1,Load Shared Config
# MAGIC %run ./_config

# COMMAND ----------

# DBTITLE 1,Build Rates Tables from JSON
# ═══════════════════════════════════════════════════════════════════════════════
# STEP 11a: BUILD BASE LAYER FROM JSON — Rates Domain
#   Reads directly from json_extract/ — ZERO dependency on json_consolidated
#   on any source tables. Builds:
#     - tbl_contract_rates_all (core rates + extended + capitation)
#     - tbl_contract_regional_factors (county multipliers)
#     - tbl_contract_financial_protections (stop-loss + exceptions)
#
#   JSON paths:
#     json_extract → inpatient_rates, outpatient_rates, capitation_table,
#                     regional_factors, stop_loss_reinsurance, exception_provisions
#
#   V8 FIX: Expanded make_rate_row to extract cap_amount, cap_numeric,
#           conversion_factor, conversion_factor_numeric from outpatient dicts.
#           Recovers +170 formula/cap rates across 39 providers that were
#           previously missed due to non-standard field naming.
# ═══════════════════════════════════════════════════════════════════════════════
import os, json, time
import pandas as pd
import numpy as np

print("\n" + "═"*80)
print("  ▶ STEP 11a: BASE LAYER FROM JSON — Rates Domain")
print("    No source table dependencies. Reads JSON directly.")
print("    V8: Expanded outpatient extraction (cap_amount, conversion_factor, formula)")
print("═"*80)

SCHEMA = "dev_adb.raw"
t0 = time.time()

# ─── Load JSON files (reads from json_extract only — consolidated removed) ───
# ═══ VERSION DE-DUPLICATION (replaces removed 07_consolidation) ═══
from collections import defaultdict

def dedup_extraction_versions(docs_dict):
    """Keep highest version per (provider_id, contract_id, doc_type, effective_date)."""
    groups = defaultdict(list)
    for fname, doc in docs_dict.items():
        fm = doc.get('file_metadata', {})
        co = (doc.get('extracted_content') or {}).get('contract_overview', {}) or {}
        key = (fm.get('provider_id', ''), fm.get('contract_id', ''),
               fm.get('document_type', ''), co.get('effective_date', ''))
        groups[key].append(fname)

    keep = set()
    for key, fnames in groups.items():
        if len(fnames) == 1:
            keep.add(fnames[0])
        else:
            best = max(fnames, key=lambda fn: int(re.search(r'_v(\d+)', fn).group(1)) if re.search(r'_v(\d+)', fn) else 0)
            keep.add(best)

    removed = len(docs_dict) - len(keep)
    if removed > 0:
        print(f"  Version dedup: removed {removed} duplicate extractions")
    return {k: v for k, v in docs_dict.items() if k in keep}

try:
    _ = individual_docs
    print(f"  ✅ Reusing {len(individual_docs)} individual docs from memory")
except NameError:
    OUTPUT_DIR = f"{BASE_DIR}/json_extract"

    individual_docs = {}
    for jf in sorted(f for f in os.listdir(OUTPUT_DIR) if f.endswith('.json') and not f.startswith('_')):
        with open(os.path.join(OUTPUT_DIR, jf)) as f:
            doc = json.load(f)
        # Skip quarantined files
        if doc.get('validation', {}).get('quarantined'):
            continue
        individual_docs[jf] = doc

    individual_docs = dedup_extraction_versions(individual_docs)
    print(f"  📄 Loaded {len(individual_docs)} individual JSONs (quarantined/duplicates excluded)")

# ─── Utility functions ───
def safe_str(val, max_len=None):
    if val is None: return None
    s = str(val) if not isinstance(val, str) else val
    return s[:max_len] if max_len and len(s) > max_len else s

def safe_float(val):
    if val is None: return None
    try: return float(val)
    except (ValueError, TypeError): return None

def sanitize_for_spark(df):
    for col in df.columns:
        if df[col].dtype == 'object':
            non_null = df[col].dropna()
            if len(non_null) == 0: continue
            types = set(type(v).__name__ for v in non_null.head(50))
            if types != {'str'}:
                df[col] = df[col].apply(lambda x: str(x) if x is not None and not (isinstance(x, float) and pd.isna(x)) else None)
    return df

def write_base_table(rows, table_name):
    from pyspark.sql.types import NullType
    from pyspark.sql.functions import lit
    df = sanitize_for_spark(pd.DataFrame(rows))
    sdf = spark.createDataFrame(df)
    # FIX: Cast NullType (void) columns — Spark optimizer crashes on these in SQL queries
    for field in sdf.schema.fields:
        if isinstance(field.dataType, NullType):
            target_type = "double" if '_numeric' in field.name else "string"
            sdf = sdf.withColumn(field.name, lit(None).cast(target_type))
    sdf.write.mode("overwrite").option("overwriteSchema", "true").saveAsTable(f"{SCHEMA}.{table_name}")
    return len(rows)

# ═══════════════════════════════════════════════════════════════════════════════
# TABLE 2: tbl_contract_rates_all
#   Source 2: json_extract/inpatient_rates + outpatient_rates (extended)
#   Source 3: json_extract/capitation_table (PMPM rates)
# ═══════════════════════════════════════════════════════════════════════════════
print("\n  Building tbl_contract_rates_all from JSON...")
rows_rates = []

# Source 1 removed — json_consolidated no longer exists.
# All rates come from Source 2 (individual docs) and Source 3 (capitation).

# Source 2: Extended rates from inpatient_rates + outpatient_rates
for jf, doc in individual_docs.items():
    fm = doc.get('file_metadata', {})
    ec = doc.get('extracted_content', {}) or {}
    eff_date = (ec.get('contract_overview', {}) or {}).get('effective_date')

    def make_rate_row(category, item, rate_key='rate', numeric_key='rate_numeric'):
        """Build a rate row from a rate item dict.
        
        V8 FIX: Expanded field lookup order for rate_text and rate_numeric
        to handle non-standard outpatient structures:
          - emergency_services uses cap_amount/cap_numeric
          - radiology_pathology uses conversion_factor/conversion_factor_numeric
          - infusion_therapy uses per_visit_rate
          - some items use percentage_of_charges
        """
        # V8: Expanded rate_text extraction chain
        # Tries: rate → case_rate → per_visit_rate → percentage_of_charges → cap_amount → conversion_factor
        rate_text_val = (item.get(rate_key) 
                        or item.get('case_rate') 
                        or item.get('per_visit_rate') 
                        or item.get('percentage_of_charges')
                        or item.get('cap_amount')           # V8: emergency caps
                        or item.get('conversion_factor')    # V8: radiology formulas
                        or '')
        
        # V8: Expanded rate_numeric extraction chain
        # Tries: rate_numeric → stop_loss_numeric → cap_numeric → conversion_factor_numeric
        rate_numeric_val = (item.get(numeric_key) 
                          or item.get('rate_numeric') 
                          or item.get('stop_loss_numeric')
                          or item.get('cap_numeric')                  # V8: emergency cap value
                          or item.get('conversion_factor_numeric'))    # V8: radiology conversion factor
        
        # V8: Enhanced formula construction for radiology/pathology rates
        formula_val = item.get('formula', '')
        if not formula_val and item.get('conversion_factor'):
            # Build formula from components for radiology_pathology
            parts = []
            if item.get('conversion_factor'): parts.append(f"CF={item['conversion_factor']}")
            if item.get('multiplier'): parts.append(f"Multiplier={item['multiplier']}")
            formula_val = ' x '.join(parts) if parts else ''
        
        return {
            'provider_id': fm.get('provider_id'),
            'provider_name': fm.get('provider_name'),
            'source_filename': fm.get('source_filename'),
            'document_type': fm.get('document_type'),
            'rate_category': category,
            'service_category': safe_str(item.get('service', item.get('tier', item.get('service_or_tier', item.get('procedure', ''))))),
            'rate_type_detail': safe_str(item.get('rate_type_detail', item.get('type', item.get('rate_type', '')))),
            'rate_text': safe_str(rate_text_val),
            'rate_numeric': safe_float(rate_numeric_val),
            'revenue_codes': safe_str(item.get('revenue_codes', ''), 500),
            'effective_date': item.get('effective_date', eff_date),
            'program': safe_str(item.get('program', '')),
            'network': safe_str(item.get('network', '')),
            'formula': safe_str(formula_val, 500),
            'notes': safe_str(item.get('notes', item.get('included_services', item.get('included_days', ''))), 500),
            'amendment_order': None,
            'status': None,
            'superseded_by': None,
            'superseded_date': None,
            'is_latest_version': None,
            'source_table': f'json_extract/{category}',
        }

    # Inpatient rates (per_diem_rates, case_rates, other_inpatient_rates)
    ip_rates = ec.get('inpatient_rates', {})
    if isinstance(ip_rates, dict):
        for sub_cat, items in ip_rates.items():
            category = f'inpatient_{sub_cat}'
            if isinstance(items, list):
                for item in items:
                    if isinstance(item, dict):
                        rows_rates.append(make_rate_row(category, item))
            elif isinstance(items, dict) and items:
                rows_rates.append(make_rate_row(category, items))

    # Outpatient rates (surgical_tiers, emergency_services, infusion, therapy, radiology)
    op_rates = ec.get('outpatient_rates', {})
    if isinstance(op_rates, dict):
        for sub_cat, items in op_rates.items():
            category = f'outpatient_{sub_cat}'
            if isinstance(items, list):
                for item in items:
                    if isinstance(item, dict):
                        rows_rates.append(make_rate_row(category, item))
            elif isinstance(items, dict) and items:
                # Single-item dicts (e.g., emergency_services is one rate per doc)
                rows_rates.append(make_rate_row(category, items))

# Source 3: Capitation rates from capitation_table
for jf, doc in individual_docs.items():
    fm = doc.get('file_metadata', {})
    ec = doc.get('extracted_content', {}) or {}
    cap = ec.get('capitation_table', {})
    if not isinstance(cap, dict):
        continue
    supplemental = safe_str(cap.get('supplemental_payments', ''), 1000)
    if isinstance(cap.get('supplemental_payments'), list):
        supplemental = json.dumps(cap.get('supplemental_payments', []))
    retro_rules = safe_str(cap.get('retroactive_adjustment_rules', ''), 1000)

    for rate_list_key in ['rates_by_category', 'multi_year_rates']:
        for r in (cap.get(rate_list_key, []) or []):
            if not isinstance(r, dict):
                continue
            rows_rates.append({
                'provider_id': fm.get('provider_id'),
                'provider_name': fm.get('provider_name'),
                'source_filename': fm.get('source_filename'),
                'document_type': fm.get('document_type'),
                'rate_category': 'capitation',
                'service_category': safe_str(r.get('aid_category', r.get('category', ''))),
                'rate_type_detail': 'pmpm' if r.get('pmpm', False) else 'pct_of_cms_capitation',
                'rate_text': safe_str(r.get('rate')),
                'rate_numeric': safe_float(r.get('rate_numeric')),
                'revenue_codes': None,
                'effective_date': safe_str(r.get('effective_date', '')),
                'program': safe_str(r.get('program', '')),
                'network': None,
                'formula': f"supplemental: {supplemental or 'N/A'} | retro_rules: {retro_rules or 'N/A'}",
                'notes': safe_str(r.get('year', '')),
                'amendment_order': None,
                'status': None,
                'superseded_by': None,
                'superseded_date': None,
                'is_latest_version': None,
                'source_table': 'json_extract/capitation_table',
            })

write_base_table(rows_rates, 'tbl_contract_rates_all')
print(f"  ✅ tbl_contract_rates_all: {len(rows_rates):,} rows")

# ═══════════════════════════════════════════════════════════════════════════════
# TABLE 3: tbl_contract_regional_factors
#   Source: json_extract → extracted_content.regional_factors
# ═══════════════════════════════════════════════════════════════════════════════
print("  Building tbl_contract_regional_factors from JSON...")
rows_rf = []
for jf, doc in individual_docs.items():
    fm = doc.get('file_metadata', {})
    ec = doc.get('extracted_content', {}) or {}
    rf = ec.get('regional_factors', [])
    if not isinstance(rf, list):
        continue
    for item in rf:
        if not isinstance(item, dict):
            continue
        rows_rf.append({
            'provider_id': fm.get('provider_id'),
            'provider_name': fm.get('provider_name'),
            'source_filename': fm.get('source_filename'),
            'document_type': fm.get('document_type'),
            'county': safe_str(item.get('county', '')),
            'outpatient_surgical_factor': safe_str(item.get('outpatient_surgical_factor', item.get('factor', ''))),
            'practice_expense_factor': safe_str(item.get('practice_expense_factor', '')),
            'malpractice_factor': safe_str(item.get('malpractice_factor', '')),
            'effective_date': item.get('effective_date', (ec.get('contract_overview', {}) or {}).get('effective_date')),
            'exhibit_reference': safe_str(item.get('exhibit_reference', '')),
            'is_latest_version': True,
        })

if rows_rf:
    write_base_table(rows_rf, 'tbl_contract_regional_factors')
print(f"  ✅ tbl_contract_regional_factors: {len(rows_rf):,} rows")

# ═══════════════════════════════════════════════════════════════════════════════
# TABLE 4: tbl_contract_financial_protections
#   Sources: json_extract → stop_loss_reinsurance + exception_provisions
# ═══════════════════════════════════════════════════════════════════════════════
print("  Building tbl_contract_financial_protections from JSON...")
rows_fp = []

# Source 1: Stop-loss (key: stop_loss_reinsurance)
for jf, doc in individual_docs.items():
    fm = doc.get('file_metadata', {})
    ec = doc.get('extracted_content', {}) or {}
    sl = ec.get('stop_loss_reinsurance', {})
    if not isinstance(sl, dict) or not sl.get('has_stop_loss'):
        continue

    eff_date = (ec.get('contract_overview', {}) or {}).get('effective_date')
    rows_fp.append({
        'provider_id': fm.get('provider_id'),
        'provider_name': fm.get('provider_name'),
        'source_filename': fm.get('source_filename'),
        'document_type': fm.get('document_type'),
        'protection_type': 'stop_loss',
        'sub_type': 'per_diem_stop_loss',
        'has_stop_loss': True,
        'threshold_text': safe_str(sl.get('per_diem_attachment_level', '')),
        'threshold_numeric': safe_float(sl.get('per_diem_attachment_numeric')),
        'reimbursement_pct_text': safe_str(sl.get('per_diem_stop_loss_rate', '')),
        'reimbursement_pct_numeric': safe_float(sl.get('per_diem_stop_loss_numeric')),
        'aggregate_cap': safe_str(sl.get('aggregate_cap', ''), 500),
        'corridor': safe_str(sl.get('corridor', ''), 500),
        'reinsurance_details': safe_str(sl.get('reinsurance_details', ''), 1000),
        'revenue_codes': safe_str(sl.get('implant_revenue_codes', ''), 500),
        'case_rate_terms': safe_str(sl.get('case_rate_stop_loss', ''), 1000),
        'effective_date': eff_date,
        'exhibit_reference': safe_str(sl.get('exhibit_reference', '')),
        'is_latest_version': None,
        'source_table': 'json_extract/stop_loss_reinsurance',
    })

# Source 2: Exception provisions (implants, drugs, carve-outs)
for jf, doc in individual_docs.items():
    fm = doc.get('file_metadata', {})
    ec = doc.get('extracted_content', {}) or {}
    ep = ec.get('exception_provisions', {})
    if not isinstance(ep, dict):
        continue

    base = {
        'provider_id': fm.get('provider_id'),
        'provider_name': fm.get('provider_name'),
        'source_filename': fm.get('source_filename'),
        'document_type': fm.get('document_type'),
    }

    for exc_type in ['implants', 'exception_drugs']:
        exc = ep.get(exc_type, {})
        if isinstance(exc, dict) and any(v for v in exc.values() if v):
            rows_fp.append({**base,
                'protection_type': 'exception',
                'sub_type': exc_type,
                'has_stop_loss': None,
                'threshold_text': safe_str(exc.get('threshold_amount', '')),
                'threshold_numeric': safe_float(exc.get('threshold_numeric')),
                'reimbursement_pct_text': safe_str(exc.get('reimbursement_percentage', '')),
                'reimbursement_pct_numeric': None,
                'aggregate_cap': None,
                'corridor': None,
                'reinsurance_details': None,
                'revenue_codes': safe_str(exc.get('revenue_codes', '')),
                'case_rate_terms': safe_str(exc.get('description', '')),
                'effective_date': None,
                'exhibit_reference': None,
                'is_latest_version': None,
                'source_table': 'json_extract/exception_provisions',
            })

    for oe in (ep.get('other_exceptions', []) or []):
        if isinstance(oe, dict):
            rows_fp.append({**base,
                'protection_type': 'exception',
                'sub_type': safe_str(oe.get('exception_type', 'other')),
                'has_stop_loss': None,
                'threshold_text': safe_str(oe.get('threshold', '')),
                'threshold_numeric': None,
                'reimbursement_pct_text': safe_str(oe.get('reimbursement', '')),
                'reimbursement_pct_numeric': None,
                'aggregate_cap': None,
                'corridor': None,
                'reinsurance_details': None,
                'revenue_codes': safe_str(oe.get('revenue_codes', '')),
                'case_rate_terms': safe_str(oe.get('description', ''), 1000),
                'effective_date': None,
                'exhibit_reference': None,
                'is_latest_version': None,
                'source_table': 'json_extract/exception_provisions',
            })

if rows_fp:
    write_base_table(rows_fp, 'tbl_contract_financial_protections')
print(f"  ✅ tbl_contract_financial_protections: {len(rows_fp):,} rows")

print(f"\n  Rates Domain complete: {time.time()-t0:.1f}s")
print(f"  📁 Source: json_extract/ (ZERO table dependencies)")

# COMMAND ----------

# DBTITLE 1,Rate Status Fix - Supersession and Program Normalization
# ═══════════════════════════════════════════════════════════════════════════════
# STEP 11a-FIX: Post-processing for tbl_contract_rates_all
#   1. Fill NULL status using amendment_order supersession logic
#   2. Default program='Commercial' and network='All Networks' where NULL
#   3. [V7] Normalize rate_category (merge duplicate variants)
#   4. [V7] Remove empty placeholder rows (no rate data at all)
#   5. [V7] Add program_normalized (148 raw → 8 canonical buckets)
#   6. [V7] Add is_valid_rate flag (FALSE for negative/zero rates)
#   Runs as SQL overwrite — safe and idempotent.
# ═══════════════════════════════════════════════════════════════════════════════
from pyspark.sql import functions as F
from pyspark.sql.window import Window
import time

print("\n" + "═"*80)
print("  ▶ STEP 11a-FIX: Rate Status, Defaults & V7 Optimizations")
print("═"*80)

SCHEMA = "dev_adb.raw"
t0 = time.time()

# Read the just-built rates table
rates_df = spark.table(f"{SCHEMA}.tbl_contract_rates_all")
before_count = rates_df.count()
before_null = rates_df.filter(F.col("status").isNull()).count()
print(f"  Before: {before_count:,} rows, {before_null:,} with NULL status")

# ─── 1. Fill NULL status using amendment_order supersession ───
# Build amendment_order lookup from documents_master
dm_df = spark.table(f"{SCHEMA}.tbl_contract_documents_master").select(
    "provider_id", "source_filename", "amendment_order"
)

# Join to get amendment_order for each rate row
rates_with_order = rates_df.join(
    dm_df.withColumnRenamed("amendment_order", "doc_order"),
    on=["provider_id", "source_filename"],
    how="left"
)

# Compute max amendment_order per provider
w = Window.partitionBy("provider_id")
rates_with_order = rates_with_order.withColumn(
    "max_order", F.max("doc_order").over(w)
)

# ─── SCOPE-AWARE SUPERSESSION ───
# Read amendment scope classification (if state engine has run)
try:
    scope_df = spark.table(f"{SCHEMA}.tbl_v2_amendment_registry").select(
        "source_filename", "scope_type"
    )
    rates_with_scope = rates_with_order.join(scope_df, on="source_filename", how="left")
    has_scope = True
except Exception:
    rates_with_scope = rates_with_order.withColumn("scope_type", F.lit(None))
    has_scope = False

if has_scope:
    # FULL_REPLACEMENT: find max order per provider that is full replacement
    full_replace = rates_with_scope.filter(
        F.col("scope_type") == "FULL_REPLACEMENT"
    ).groupBy("provider_id").agg(F.max("doc_order").alias("full_replace_order"))

    rates_with_scope = rates_with_scope.join(full_replace, on="provider_id", how="left")

    rates_fixed = rates_with_scope.withColumn(
        "status",
        F.when(F.col("status").isNotNull(), F.col("status"))
         .when(
            (F.col("full_replace_order").isNotNull()) &
            (F.col("doc_order") < F.col("full_replace_order")) &
            (F.col("scope_type") != "FULL_REPLACEMENT"),
            F.lit("superseded")
         ).when(
            F.col("scope_type") == "TERM_EXTENSION",
            F.lit("current")
         ).when(
            F.col("doc_order") == F.col("max_order"), F.lit("current")
         ).otherwise(F.lit("superseded"))
    ).drop("scope_type", "full_replace_order")
else:
    # Fallback: original amendment_order logic (first run before state engine)
    rates_fixed = rates_with_scope.withColumn(
        "status",
        F.when(F.col("status").isNotNull(), F.col("status"))
         .when(F.col("doc_order") == F.col("max_order"), F.lit("current"))
         .otherwise(F.lit("superseded"))
    ).drop("scope_type")

rates_fixed = rates_fixed.withColumn(
    "is_latest_version",
    F.when(F.col("is_latest_version").isNotNull(), F.col("is_latest_version"))
     .when(F.col("status") == "current", F.lit(True))
     .otherwise(F.lit(False))
)

# ─── 2. Apply program/network defaults ───
rates_fixed = rates_fixed.withColumn(
    "program",
    F.when((F.col("program").isNull()) | (F.col("program") == ""), F.lit("Commercial"))
     .otherwise(F.col("program"))
).withColumn(
    "network",
    F.when((F.col("network").isNull()) | (F.col("network") == ""), F.lit("All Networks"))
     .otherwise(F.col("network"))
)

# ─── 3. [V7] Normalize rate_category — merge duplicate variants ───
# inpatient_per_diem_rates → inpatient_per_diem (same data, singular form)
# inpatient_case_rates → inpatient_case_rate (same data, singular form)
rates_fixed = rates_fixed.withColumn(
    "rate_category",
    F.when(F.col("rate_category") == "inpatient_per_diem_rates", F.lit("inpatient_per_diem"))
     .when(F.col("rate_category") == "inpatient_case_rates", F.lit("inpatient_case_rate"))
     .otherwise(F.col("rate_category"))
)
print("  ✓ rate_category normalized (merged _rates variants)")

# ─── 4. [V7] Remove empty placeholder rows ───
# Rows where rate_text is empty/null AND rate_numeric is null AND formula is empty
# contribute zero information — they are extraction placeholders
before_filter = rates_fixed.count()
rates_fixed = rates_fixed.filter(
    ~(
        ((F.col("rate_text").isNull()) | (F.col("rate_text") == "") | (F.col("rate_text") == "NULL"))
        & (F.col("rate_numeric").isNull())
        & ((F.col("formula").isNull()) | (F.col("formula") == ""))
    )
)
after_filter = rates_fixed.count()
placeholders_removed = before_filter - after_filter
print(f"  ✓ Removed {placeholders_removed:,} empty placeholder rows")

# ─── 5. [V7] Add program_normalized (148 raw variants → 8 canonical buckets) ───
rates_fixed = rates_fixed.withColumn(
    "program_normalized",
    F.when(F.lower(F.col("program")).like("%medi-cal%") | F.lower(F.col("program")).like("%healthy families%") | F.lower(F.col("program")).like("%lihp%"), F.lit("Medi-Cal"))
     .when(F.lower(F.col("program")).like("%medicare%") & F.lower(F.col("program")).like("%medi-cal%"), F.lit("Dual Eligible"))
     .when(F.lower(F.col("program")).like("%cal medi%connect%"), F.lit("Dual Eligible"))
     .when(F.lower(F.col("program")).like("%medicare%"), F.lit("Medicare"))
     .when(F.lower(F.col("program")).like("%calpers%") | F.lower(F.col("program")).like("%cal pers%") | F.lower(F.col("program")).like("%pers%"), F.lit("CalPERS"))
     .when(F.lower(F.col("program")).isin("all", "all programs", "all applicable", "all benefit programs", "all applicable benefit programs"), F.lit("All Programs"))
     .when(F.lower(F.col("program")).like("%trio%"), F.lit("Commercial Trio"))
     .when(
        F.lower(F.col("program")).like("%commercial%") | F.lower(F.col("program")).like("%hmo%") |
        F.lower(F.col("program")).like("%ppo%") | F.lower(F.col("program")).like("%epo%") |
        F.lower(F.col("program")).like("%pos%") | F.lower(F.col("program")).like("%ifp%") |
        F.lower(F.col("program")).like("%epn%") | F.lower(F.col("program")).like("%aco%") |
        F.lower(F.col("program")).like("%tandem%") | F.lower(F.col("program")).like("%value network%") |
        F.lower(F.col("program")).like("%save net%"),
        F.lit("Commercial")
     )
     .otherwise(F.lit("Other"))
)
print("  ✓ program_normalized added (148 variants → 8 buckets)")

# ─── 6. [V7] Add is_valid_rate flag ───
# FALSE for negative rates, zero rates, or clearly erroneous values
# Preserves data — only flags, never deletes
rates_fixed = rates_fixed.withColumn(
    "is_valid_rate",
    F.when(F.col("rate_numeric").isNull(), F.lit(True))  # NULL = formula/pct rate, valid
     .when(F.col("rate_numeric") < 0, F.lit(False))
     .when(F.col("rate_numeric") == 0, F.lit(False))
     .otherwise(F.lit(True))
)
print("  ✓ is_valid_rate flag added")

# ─── Write final result ───
final_cols = [c for c in rates_df.columns]  # original columns
# Add V7 columns
v7_cols = ["program_normalized", "is_valid_rate"]
all_cols = final_cols + [c for c in v7_cols if c not in final_cols]
rates_fixed.select(all_cols).write.mode("overwrite").option("overwriteSchema", "true").saveAsTable(f"{SCHEMA}.tbl_contract_rates_all")

# ─── Verify ───
after_df = spark.table(f"{SCHEMA}.tbl_contract_rates_all")
after_count = after_df.count()
after_null = after_df.filter(F.col("status").isNull()).count()
status_counts = {r.status: r.cnt for r in after_df.groupBy("status").agg(F.count("*").alias("cnt")).collect()}
prog_norm_dist = {r.program_normalized: r.cnt for r in after_df.groupBy("program_normalized").agg(F.count("*").alias("cnt")).orderBy(F.desc("cnt")).collect()}

print(f"\n  Results:")
print(f"    Rows: {before_count:,} → {after_count:,} (removed {before_count - after_count:,} placeholders)")
print(f"    NULL status: {before_null:,} → {after_null:,}")
print(f"    Status: {status_counts}")
print(f"    Program normalized: {prog_norm_dist}")
print(f"    Invalid rates flagged: {after_df.filter(F.col('is_valid_rate') == False).count():,}")
# ─── 7. [V8] Zero-current-rate safety net ───
# Some providers end up with ALL rates superseded when LLM pre-sets status.
# Promote latest document's rates to 'current' for affected providers.
print("  ── Applying zero-current-rate safety net ──")
_zero_current = spark.sql(f"""
    SELECT provider_id FROM {SCHEMA}.tbl_contract_rates_all
    GROUP BY provider_id
    HAVING SUM(CASE WHEN status = 'current' THEN 1 ELSE 0 END) = 0
""").collect()
if _zero_current:
    _promoted = 0
    for _zr in _zero_current:
        _pid = _zr['provider_id']
        _latest = spark.sql(f"""
            SELECT r.source_filename
            FROM {SCHEMA}.tbl_contract_rates_all r
            JOIN {SCHEMA}.tbl_contract_documents_master d ON r.source_filename = d.source_filename
            WHERE r.provider_id = '{_pid}'
            ORDER BY d.amendment_order DESC, d.effective_date_parsed DESC NULLS LAST
            LIMIT 1
        """).collect()
        if _latest:
            _fn = _latest[0]['source_filename'].replace("'", "''")
            spark.sql(f"""UPDATE {SCHEMA}.tbl_contract_rates_all SET status = 'current'
                WHERE provider_id = '{_pid}' AND source_filename = '{_fn}'""")
            _promoted += 1
    print(f"  ✓ Promoted rates for {_promoted} providers (had zero current)")
else:
    print("  ✓ All providers have current rates — no action needed")

print(f"  ✅ Step 11a-fix complete in {time.time()-t0:.1f}s")