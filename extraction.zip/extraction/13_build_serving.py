# Databricks notebook source
# DBTITLE 1,Build Serving Tables Overview
# MAGIC %md
# MAGIC # 13 — Build Normalized Serving Layer: 12 Tables
# MAGIC **Type-separated, pre-joined tables for dashboards and downstream analytics.**
# MAGIC 
# MAGIC | # | Table | Description |
# MAGIC |---|-------|-------------|
# MAGIC | 1 | `dim_service_category` | 26 service lines (reference) |
# MAGIC | 2 | `tbl_serving_rate_card` | Inpatient per diem, 25 service lines |
# MAGIC | 3 | `tbl_serving_stop_loss` | 1 row per facility |
# MAGIC | 4 | `tbl_serving_amendment_history` | Parsed dates, computed order |
# MAGIC | 5 | `tbl_serving_parties` | Deduplicated, artifacts removed |
# MAGIC | 6 | `tbl_serving_regional_factors` | Type-separated, county-level |
# MAGIC | 7 | `tbl_serving_provider_summary` | Executive profile, 278 facilities |
# MAGIC | 8 | `dim_network` | 185 raw → 12 canonical network mappings |
# MAGIC | 9 | `tbl_serving_capitation_card` | PMPM rates by age/gender band |
# MAGIC | 10 | `tbl_serving_case_rate_card` | Transplant, cardiac, complex |
# MAGIC | 11 | `tbl_serving_outpatient_card` | Surgical, therapy, infusion |
# MAGIC | 12 | `tbl_serving_services_coverage` | DOFR + quality, deduped |
# MAGIC 
# MAGIC **Dependency:** Genie tables (Step 11d) must exist first.  
# MAGIC **Run after:** `12_build_genie`  
# MAGIC **Final notebook in the pipeline.**

# COMMAND ----------

# DBTITLE 1,Load Shared Config
%run ./_config

# COMMAND ----------

# DBTITLE 1,Build 12 Normalized Serving Tables
# ═══════════════════════════════════════════════════════════════════════════════
# STEP 11e: NORMALIZED SERVING LAYER (12 tables) — v3 (V7 Optimized)
#   All tables JOIN through dim_provider_canonical for facility-level dedup
#   DEPENDENCY: Step 11d (Genie tables must exist first)
#   RAW TABLES: NEVER modified — serving tables are additive only
#   v3 CHANGES (V7 optimization):
#     • Tables 1-7: Existing (unchanged)
#     • Table 8:  dim_network (189 raw variants → 12 canonical networks)
#     • Table 9:  tbl_serving_capitation_card (PMPM rates, 62 providers)
#     • Table 10: tbl_serving_case_rate_card (case rates, 100 providers)
#     • Table 11: tbl_serving_outpatient_card (outpatient rates, 128 providers)
#     • Table 12: tbl_serving_services_coverage (DOFR + quality + services)
#     • Table 7 enhanced: provider_summary now includes outpatient avg + rate categories
# ═══════════════════════════════════════════════════════════════════════════════
import time

print("\n" + "═"*80)
print("  ▶ STEP 11e: NORMALIZED SERVING LAYER v3 — 12 Tables (V7 Optimized)")
print("    New: capitation, case rate, outpatient, services, dim_network")
print("    Raw tables: UNTOUCHED (zero data loss)")
print("═"*80)

SCHEMA = "dev_adb.raw"
t0 = time.time()

# ═══════════════════════════════════════════════════════════════════════════════
# 1/12: dim_service_category (25 inpatient service lines)
# ═══════════════════════════════════════════════════════════════════════════════
print("\n  [1/12] dim_service_category...")
spark.sql(f"""
CREATE OR REPLACE TABLE {SCHEMA}.dim_service_category (
  service_category_id INT, service_line STRING, category_group STRING,
  sort_order INT, match_pattern STRING
) COMMENT '25 service lines for inpatient normalization.'
""")
spark.sql(f"""
INSERT OVERWRITE {SCHEMA}.dim_service_category VALUES
  (1,'Medical/Surgical/Peds','Inpatient',1,'%Medical/Surgical%'),
  (2,'ICU/CCU/PICU','Inpatient',2,'%ICU/CCU%'),
  (3,'Intermediate ICU','Inpatient',3,'%Intermediate ICU%'),
  (4,'NICU Level IV','Inpatient',4,'%NICU%Level%IV%'),
  (5,'NICU Level III','Inpatient',5,'%NICU%Level%III%'),
  (6,'NICU Level II','Inpatient',6,'%NICU%Level%II%'),
  (7,'NICU Level I','Inpatient',7,'%NICU%Level%I%'),
  (8,'Coronary Surgery','Inpatient',8,'%Coronary%'),
  (9,'PTCA','Inpatient',9,'%PTCA%'),
  (10,'Cardiac Catheterization','Inpatient',10,'%Cardiac Cath%'),
  (11,'Acute Rehabilitation','Inpatient',11,'%Acute Rehab%'),
  (12,'Trauma','Inpatient',12,'%Trauma%'),
  (13,'ER Admissions','Inpatient',13,'%ER Admission%'),
  (14,'Psychiatric','Inpatient',14,'%Psychiatric%'),
  (15,'Transplant','Inpatient',15,'%Transplant%'),
  (16,'Telemetry/DOU','Inpatient',16,'%Telemetry%'),
  (17,'Subacute Care Level III','Subacute',17,'%Sub_cute%III%'),
  (18,'Subacute Care Level II','Subacute',18,'%Sub_cute%II%'),
  (19,'Subacute Care Level I','Subacute',19,'%Sub_cute%Level%I%'),
  (20,'Subacute Care Other','Subacute',20,'%Sub_cute%'),
  (21,'Maternity/Obstetrics','Inpatient',21,'%Maternity%'),
  (22,'Obstetrics','Inpatient',22,'%Obstetric%'),
  (23,'Boarder Baby','Inpatient',23,'%Boarder Baby%'),
  (24,'Administrative Day','Inpatient',24,'%Administrative Day%'),
  (25,'Substance Abuse','Inpatient',25,'%Substance Abuse%'),
  (99,'Other Inpatient','Inpatient',99,'%')
""")
print("    ✓ 26 rows")

# ═══════════════════════════════════════════════════════════════════════════════
# 2/12: tbl_serving_rate_card (inpatient per diem, 25 service lines)
# ═══════════════════════════════════════════════════════════════════════════════
print("  [2/12] tbl_serving_rate_card...")
spark.sql(f"""
CREATE OR REPLACE TABLE {SCHEMA}.tbl_serving_rate_card
COMMENT 'Inpatient per diem rate card. 25 service lines, 12 networks. is_current=TRUE for latest.'
AS
WITH base AS (
  SELECT provider_name, provider_id, rate_category,
    service_category AS service_category_raw,
    CASE
      WHEN service_category ILIKE '%Medical/Surgical%' OR service_category ILIKE '%Med/Surg%' THEN 'Medical/Surgical/Peds'
      WHEN service_category ILIKE '%ICU/CCU%' OR service_category ILIKE '%PICU%' THEN 'ICU/CCU/PICU'
      WHEN service_category ILIKE '%NICU%' AND (service_category ILIKE '%IV%' OR service_category ILIKE '%Level 4%') THEN 'NICU Level IV'
      WHEN service_category ILIKE '%NICU%' AND (service_category ILIKE '%III%' OR service_category ILIKE '%Level 3%') THEN 'NICU Level III'
      WHEN service_category ILIKE '%NICU%' AND (service_category ILIKE '%II%' OR service_category ILIKE '%Level 2%') THEN 'NICU Level II'
      WHEN service_category ILIKE '%NICU%' OR service_category ILIKE '%Neonatal%' THEN 'NICU Level I'
      WHEN service_category ILIKE '%Coronary%' THEN 'Coronary Surgery'
      WHEN service_category ILIKE '%PTCA%' THEN 'PTCA'
      WHEN service_category ILIKE '%Cardiac Cath%' THEN 'Cardiac Catheterization'
      WHEN service_category ILIKE '%Acute Rehab%' THEN 'Acute Rehabilitation'
      WHEN service_category ILIKE '%Telemetry%' OR service_category ILIKE '%DOU%' THEN 'Telemetry/DOU'
      WHEN service_category ILIKE '%Sub%cute%' THEN 'Subacute Care Other'
      WHEN service_category ILIKE '%Maternity%' OR service_category ILIKE '%Delivery%' THEN 'Maternity/Obstetrics'
      WHEN service_category ILIKE '%Psychiatric%' THEN 'Psychiatric'
      WHEN service_category ILIKE '%Boarder Baby%' THEN 'Boarder Baby'
      WHEN service_category IS NULL OR service_category = '' THEN 'Unknown'
      ELSE 'Other Inpatient'
    END AS service_line,
    network, program_normalized AS program, rate_text, rate_numeric,
    'per_diem' AS rate_type, effective_date_parsed, source_filename, formula, notes
  FROM {SCHEMA}.tbl_genie_rates_current
  WHERE rate_category = 'inpatient_per_diem'
    AND rate_numeric IS NOT NULL AND rate_numeric > 100
),
ranked AS (
  SELECT *, ROW_NUMBER() OVER (
    PARTITION BY provider_name, service_line, network
    ORDER BY effective_date_parsed DESC NULLS LAST, rate_numeric DESC
  ) AS rn FROM base
)
SELECT provider_name, provider_id, rate_category, service_category_raw,
  service_line, network, program, rate_text, rate_numeric, rate_type,
  effective_date_parsed, source_filename, formula, notes,
  CASE WHEN rn = 1 THEN TRUE ELSE FALSE END AS is_current
FROM ranked
""")
cnt = spark.sql(f"SELECT COUNT(*), SUM(CASE WHEN is_current THEN 1 ELSE 0 END) FROM {SCHEMA}.tbl_serving_rate_card").collect()[0]
print(f"    ✓ {cnt[0]:,} rows ({cnt[1]:,} current)")

# ═══════════════════════════════════════════════════════════════════════════════
# 3/12: tbl_serving_stop_loss (1 per facility)
# ═══════════════════════════════════════════════════════════════════════════════
print("  [3/12] tbl_serving_stop_loss...")
spark.sql(f"""
CREATE OR REPLACE TABLE {SCHEMA}.tbl_serving_stop_loss
COMMENT 'One stop-loss per facility (highest threshold).'
AS
WITH ranked AS (
  SELECT c.canonical_name AS provider_name, c.primary_provider_id AS provider_id,
    f.protection_type, f.sub_type, f.threshold_text, f.threshold_numeric,
    f.reimbursement_pct_text, f.reimbursement_pct_normalized,
    f.aggregate_cap, f.effective_date, f.exhibit_reference, f.source_filename,
    ROW_NUMBER() OVER (PARTITION BY c.canonical_name ORDER BY f.threshold_numeric DESC NULLS LAST) AS rn
  FROM {SCHEMA}.tbl_contract_financial_protections f
  JOIN {SCHEMA}.dim_provider_canonical c ON f.provider_id = c.provider_id
  WHERE f.protection_type = 'stop_loss' AND f.threshold_numeric IS NOT NULL AND f.threshold_numeric > 1000
)
SELECT provider_name, provider_id, protection_type, sub_type,
  threshold_text, threshold_numeric, reimbursement_pct_text, reimbursement_pct_normalized,
  aggregate_cap, effective_date, exhibit_reference, source_filename
FROM ranked WHERE rn = 1
""")
print(f"    ✓ {spark.table(f'{SCHEMA}.tbl_serving_stop_loss').count()} facilities")

# ═══════════════════════════════════════════════════════════════════════════════
# 4/12: tbl_serving_amendment_history (with rate_count + doc_category)
# ═══════════════════════════════════════════════════════════════════════════════
print("  [4/12] tbl_serving_amendment_history...")
spark.sql(f"""
CREATE OR REPLACE TABLE {SCHEMA}.tbl_serving_amendment_history
COMMENT 'Unified amendment timeline. Includes rate_count, doc_category, sentinel detection.'
AS
SELECT
  t.provider_name, t.provider_id, t.document_type, t.amendment_order,
  CASE WHEN t.amendment_order >= 100 THEN TRUE ELSE FALSE END AS is_sentinel,
  t.effective_date_parsed,
  DENSE_RANK() OVER (PARTITION BY t.provider_name
    ORDER BY t.effective_date_parsed NULLS LAST
  ) AS amendment_order_computed,
  t.doc_category AS document_category,
  t.summary_of_changes, t.source_filename,
  t.rate_count, t.v6_coverage_pct
FROM {SCHEMA}.tbl_genie_amendment_timeline t
""")
print(f"    ✓ {spark.table(f'{SCHEMA}.tbl_serving_amendment_history').count():,} rows")

# ═══════════════════════════════════════════════════════════════════════════════
# 5/12: tbl_serving_parties (deduplicated, artifacts removed)
# ═══════════════════════════════════════════════════════════════════════════════
print("  [5/12] tbl_serving_parties...")
spark.sql(f"""
CREATE OR REPLACE TABLE {SCHEMA}.tbl_serving_parties
COMMENT 'Deduplicated parties per facility. Signature artifacts removed.'
AS
WITH valid_parties AS (
  SELECT c.canonical_name AS provider_name, c.primary_provider_id AS provider_id,
    p.party_name, p.party_role, p.signatory_title, p.tax_id, p.npi, p.source_filename,
    ROW_NUMBER() OVER (
      PARTITION BY c.canonical_name, UPPER(TRIM(p.party_name)), p.party_role
      ORDER BY CASE WHEN p.tax_id IS NOT NULL AND p.tax_id != '' THEN 0 ELSE 1 END,
        CASE WHEN p.npi IS NOT NULL AND p.npi != '' THEN 0 ELSE 1 END,
        p.source_filename DESC
    ) AS rn
  FROM {SCHEMA}.tbl_contract_parties p
  JOIN {SCHEMA}.dim_provider_canonical c ON p.provider_id = c.provider_id
  WHERE p.party_name NOT ILIKE '%[Signature%' AND p.party_name NOT ILIKE '%signature present%'
    AND LENGTH(TRIM(COALESCE(p.party_name,''))) > 2
)
SELECT provider_name, provider_id, party_name, party_role,
  signatory_title, tax_id, npi, source_filename
FROM valid_parties WHERE rn = 1
""")
print(f"    ✓ {spark.table(f'{SCHEMA}.tbl_serving_parties').count():,} rows")

# ═══════════════════════════════════════════════════════════════════════════════
# 6/12: tbl_serving_regional_factors (county-level, type-separated)
# ═══════════════════════════════════════════════════════════════════════════════
print("  [6/12] tbl_serving_regional_factors...")
spark.sql(f"""
CREATE OR REPLACE TABLE {SCHEMA}.tbl_serving_regional_factors
COMMENT 'Geographic adjustment factors by county. factor_type separates multipliers from pct.'
AS
SELECT c.canonical_name AS provider_name, c.primary_provider_id AS provider_id,
  rf.county,
  TRY_CAST(rf.outpatient_surgical_factor AS DOUBLE) AS geo_surgical_factor,
  TRY_CAST(rf.practice_expense_factor AS DOUBLE) AS geo_practice_factor,
  TRY_CAST(rf.malpractice_factor AS DOUBLE) AS geo_malpractice_factor,
  CASE WHEN TRY_CAST(rf.outpatient_surgical_factor AS DOUBLE) > 10 THEN 'pct_of_charges'
       ELSE 'geographic_multiplier' END AS factor_type,
  rf.effective_date, rf.source_filename
FROM {SCHEMA}.tbl_contract_regional_factors rf
JOIN {SCHEMA}.dim_provider_canonical c ON rf.provider_id = c.provider_id
WHERE rf.county IS NOT NULL
""")
print(f"    ✓ {spark.table(f'{SCHEMA}.tbl_serving_regional_factors').count():,} rows")

# ═══════════════════════════════════════════════════════════════════════════════
# 7/12: tbl_serving_provider_summary (V7: enriched with outpatient + rate categories)
# ═══════════════════════════════════════════════════════════════════════════════
print("  [7/12] tbl_serving_provider_summary...")
spark.sql(f"""
CREATE OR REPLACE TABLE {SCHEMA}.tbl_serving_provider_summary
COMMENT 'Unified provider profile. One row per facility. Includes rates, identity, contract metadata.'
AS
WITH facility_base AS (
  SELECT canonical_name AS provider_name, primary_provider_id AS provider_id,
    ids_in_facility, facility_total_docs AS total_documents
  FROM {SCHEMA}.dim_provider_canonical WHERE is_primary_id = TRUE
),
genie_attrs AS (
  SELECT provider_name, agreement_type, payment_type, auto_renewal, contract_term_years,
    avg_outpatient_rate, rate_categories, current_rates
  FROM {SCHEMA}.tbl_genie_provider_profile
),
payment AS (
  SELECT provider_name,
    CASE
      WHEN payment_type ILIKE '%Fee For Service%' OR payment_type ILIKE '%Fee Schedule%' THEN 'Fee For Service'
      WHEN payment_type ILIKE '%Capitation%' OR payment_type ILIKE '%Risk%sharing%' THEN 'Capitation'
      WHEN payment_type ILIKE '%Settlement%' THEN 'Settlement'
      WHEN payment_type ILIKE '%Percentage%' THEN 'Percentage of Charges'
      WHEN payment_type ILIKE '%Bundled%' OR payment_type ILIKE '%Episodes%' THEN 'Bundled/Case Rate'
      ELSE 'Fee For Service'
    END AS payment_type_normalized
  FROM genie_attrs WHERE payment_type IS NOT NULL
),
amendments AS (
  SELECT provider_name, COUNT(*) AS total_amendments, MAX(effective_date_parsed) AS latest_amendment_date
  FROM {SCHEMA}.tbl_serving_amendment_history
  WHERE NOT is_sentinel AND document_category = 'amendment'
  GROUP BY provider_name
),
rates AS (
  SELECT c.canonical_name AS provider_name,
    ROUND(AVG(r.rate_numeric), 2) AS avg_inpatient_per_diem
  FROM {SCHEMA}.tbl_contract_rates_all r
  JOIN {SCHEMA}.dim_provider_canonical c ON r.provider_id = c.provider_id
  WHERE r.status = 'current'
    AND r.rate_category = 'inpatient_per_diem'
    AND r.rate_numeric BETWEEN 100 AND 50000
  GROUP BY c.canonical_name
),
stoploss AS (
  SELECT provider_name, TRUE AS has_stop_loss, threshold_numeric AS max_stop_loss_threshold
  FROM {SCHEMA}.tbl_serving_stop_loss
),
identity AS (
  SELECT provider_name, FIRST(party_name) AS legal_name, FIRST(tax_id) AS tax_id, FIRST(npi) AS npi
  FROM {SCHEMA}.tbl_serving_parties
  WHERE party_role = 'provider' AND tax_id IS NOT NULL AND tax_id != ''
  GROUP BY provider_name
)
SELECT fb.provider_name, fb.provider_id, fb.ids_in_facility, fb.total_documents,
  COALESCE(pay.payment_type_normalized, 'Unknown') AS payment_type_normalized,
  ga.agreement_type, ga.auto_renewal, ga.contract_term_years,
  am.total_amendments, am.latest_amendment_date,
  r.avg_inpatient_per_diem, ga.avg_outpatient_rate, ga.rate_categories, ga.current_rates,
  COALESCE(sl.has_stop_loss, FALSE) AS has_stop_loss, sl.max_stop_loss_threshold,
  id.legal_name, id.tax_id, id.npi
FROM facility_base fb
LEFT JOIN genie_attrs ga ON fb.provider_name = ga.provider_name
LEFT JOIN payment pay ON fb.provider_name = pay.provider_name
LEFT JOIN amendments am ON fb.provider_name = am.provider_name
LEFT JOIN rates r ON fb.provider_name = r.provider_name
LEFT JOIN stoploss sl ON fb.provider_name = sl.provider_name
LEFT JOIN identity id ON fb.provider_name = id.provider_name
""")
print(f"    ✓ {spark.table(f'{SCHEMA}.tbl_serving_provider_summary').count()} rows (1 per facility)")

# ═══════════════════════════════════════════════════════════════════════════════
# 8/12: [V7] dim_network (189 raw network variants → 12 canonical)
# ═══════════════════════════════════════════════════════════════════════════════
print("  [8/12] dim_network...")
spark.sql(f"""
CREATE OR REPLACE TABLE {SCHEMA}.dim_network
COMMENT '189 raw network values mapped to 12 canonical network tiers. JOIN on raw_network = network.'
AS
SELECT DISTINCT network AS raw_network,
  CASE
    WHEN network ILIKE '%All%' OR network = 'All Networks' THEN 'All Networks'
    WHEN network ILIKE '%Referred%' THEN 'Referred'
    WHEN network ILIKE '%Assigned%' THEN 'Assigned'
    WHEN network ILIKE '%EPN%' THEN 'EPN'
    WHEN network ILIKE '%Tandem%' THEN 'Tandem'
    WHEN network ILIKE '%PPO%' AND network NOT ILIKE '%HMO%' THEN 'PPO'
    WHEN network ILIKE '%HMO%' AND network NOT ILIKE '%PPO%' THEN 'HMO'
    WHEN network ILIKE '%HMO%' AND network ILIKE '%PPO%' THEN 'HMO/PPO'
    WHEN network ILIKE '%POS%' THEN 'POS'
    WHEN network ILIKE '%IFP%' OR network ILIKE '%Value Network%' THEN 'Value Network'
    WHEN network ILIKE '%Standard%' OR network ILIKE '%Blue Shield Standard%' THEN 'Standard'
    WHEN network ILIKE '%CalPERS%' OR network ILIKE '%Preferred%' THEN 'CalPERS/Preferred'
    ELSE 'Other'
  END AS canonical_network
FROM {SCHEMA}.tbl_contract_rates_all
WHERE network IS NOT NULL
""")
print(f"    ✓ {spark.table(f'{SCHEMA}.dim_network').count()} network mappings")

# ═══════════════════════════════════════════════════════════════════════════════
# 9/12: [V7] tbl_serving_capitation_card (PMPM rates by age/gender band)
# ═══════════════════════════════════════════════════════════════════════════════
print("  [9/12] tbl_serving_capitation_card...")
spark.sql(f"""
CREATE OR REPLACE TABLE {SCHEMA}.tbl_serving_capitation_card
COMMENT 'Capitation PMPM rates by provider, age/gender band, and program. One row per unique rate.'
AS
SELECT
  provider_name, provider_id,
  service_category AS age_gender_band,
  rate_text, rate_numeric AS pmpm_rate,
  program_normalized AS program,
  network,
  effective_date_parsed,
  source_filename
FROM {SCHEMA}.tbl_genie_rates_current
WHERE rate_category = 'capitation'
  AND rate_numeric IS NOT NULL AND rate_numeric > 0
""")
cnt = spark.sql(f"SELECT COUNT(*), COUNT(DISTINCT provider_id) FROM {SCHEMA}.tbl_serving_capitation_card").collect()[0]
print(f"    ✓ {cnt[0]:,} rows, {cnt[1]} providers")

# ═══════════════════════════════════════════════════════════════════════════════
# 10/12: [V7] tbl_serving_case_rate_card (transplant, cardiac, complex)
# ═══════════════════════════════════════════════════════════════════════════════
print("  [10/12] tbl_serving_case_rate_card...")
spark.sql(f"""
CREATE OR REPLACE TABLE {SCHEMA}.tbl_serving_case_rate_card
COMMENT 'Inpatient case rates (transplant, cardiac, complex procedures). Fixed per-admission.'
AS
SELECT
  provider_name, provider_id,
  service_category AS procedure_category,
  rate_text, rate_numeric AS case_rate,
  rate_type_detail,
  program_normalized AS program,
  network,
  effective_date_parsed,
  source_filename
FROM {SCHEMA}.tbl_genie_rates_current
WHERE rate_category = 'inpatient_case_rate'
  AND rate_numeric IS NOT NULL AND rate_numeric > 0
""")
cnt = spark.sql(f"SELECT COUNT(*), COUNT(DISTINCT provider_id) FROM {SCHEMA}.tbl_serving_case_rate_card").collect()[0]
print(f"    ✓ {cnt[0]:,} rows, {cnt[1]} providers")

# ═══════════════════════════════════════════════════════════════════════════════
# 11/12: [V7] tbl_serving_outpatient_card (surgical, therapy, infusion)
# ═══════════════════════════════════════════════════════════════════════════════
print("  [11/12] tbl_serving_outpatient_card...")
spark.sql(f"""
CREATE OR REPLACE TABLE {SCHEMA}.tbl_serving_outpatient_card
COMMENT 'Outpatient rates: surgical tiers, therapy, infusion, radiology. Includes formula rates.'
AS
SELECT
  provider_name, provider_id,
  rate_category AS outpatient_type,
  service_category,
  rate_text, rate_numeric,
  rate_type_detail,
  formula,
  program_normalized AS program,
  network,
  effective_date_parsed,
  source_filename
FROM {SCHEMA}.tbl_genie_rates_current
WHERE rate_category LIKE 'outpatient%'
  AND (rate_numeric IS NOT NULL OR (formula IS NOT NULL AND formula != ''))
""")
cnt = spark.sql(f"SELECT COUNT(*), COUNT(DISTINCT provider_id) FROM {SCHEMA}.tbl_serving_outpatient_card").collect()[0]
print(f"    ✓ {cnt[0]:,} rows, {cnt[1]} providers")

# ═══════════════════════════════════════════════════════════════════════════════
# 12/12: [V7] tbl_serving_services_coverage (DOFR + quality + covered services)
# ═══════════════════════════════════════════════════════════════════════════════
print("  [12/12] tbl_serving_services_coverage...")
spark.sql(f"""
CREATE OR REPLACE TABLE {SCHEMA}.tbl_serving_services_coverage
COMMENT 'Covered services, quality programs, and DOFR from latest documents. Previously only in base layer.'
AS
WITH deduped AS (
  SELECT c.canonical_name AS provider_name, c.primary_provider_id AS provider_id,
    sq.item_type, sq.category, sq.item_name, sq.delegated_to,
    sq.oversight_requirements, sq.reporting_frequency, sq.program_type,
    sq.source_filename,
    ROW_NUMBER() OVER (
      PARTITION BY c.canonical_name, sq.item_type, sq.item_name
      ORDER BY sq.source_filename DESC
    ) AS rn
  FROM {SCHEMA}.tbl_contract_services_quality sq
  JOIN {SCHEMA}.dim_provider_canonical c ON sq.provider_id = c.provider_id
  WHERE sq.is_latest_version = 'true'
)
SELECT provider_name, provider_id, item_type, category, item_name,
  delegated_to, oversight_requirements, reporting_frequency, program_type, source_filename
FROM deduped WHERE rn = 1
""")
cnt = spark.sql(f"SELECT COUNT(*), COUNT(DISTINCT provider_id) FROM {SCHEMA}.tbl_serving_services_coverage").collect()[0]
print(f"    ✓ {cnt[0]:,} rows, {cnt[1]} providers")

# ═══════════════════════════════════════════════════════════════════════════════
# SUMMARY
# ═══════════════════════════════════════════════════════════════════════════════
elapsed = time.time() - t0
print(f"\n  {'='*60}")
print(f"  ✅ STEP 11e v3 COMPLETE in {elapsed:.1f}s")
all_tables = [
    'dim_service_category', 'tbl_serving_rate_card', 'tbl_serving_stop_loss',
    'tbl_serving_amendment_history', 'tbl_serving_parties',
    'tbl_serving_regional_factors', 'tbl_serving_provider_summary',
    'dim_network', 'tbl_serving_capitation_card', 'tbl_serving_case_rate_card',
    'tbl_serving_outpatient_card', 'tbl_serving_services_coverage'
]
for tbl in all_tables:
    c = spark.sql(f"SELECT COUNT(*) FROM {SCHEMA}.{tbl}").collect()[0][0]
    print(f"     {tbl:40s} {c:>7,} rows")
print(f"  {'='*60}")
