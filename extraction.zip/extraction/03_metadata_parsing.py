# Databricks notebook source
# DBTITLE 1,Metadata Parsing Overview
# MAGIC %md
# MAGIC # 03 — Filename Metadata Parsing
# MAGIC **Parses provider_id, provider_name, contract_id, document_type, version from filenames.**
# MAGIC
# MAGIC | Input | Output |
# MAGIC |-------|--------|
# MAGIC | `checkpoints/step1_parsed_v2.parquet` | `checkpoints/step2_with_metadata_v2.parquet` |
# MAGIC
# MAGIC Filename pattern: `providerID_providerName_contractID_docType_version.pdf`
# MAGIC
# MAGIC **Run after:** `02_ocr_extraction`  
# MAGIC **Run before:** `05_llm_extraction`

# COMMAND ----------

# DBTITLE 1,Load Shared Config
# MAGIC %run ./_config

# COMMAND ----------

# DBTITLE 1,Parse Filename Metadata and Build Checkpoint
# ═══════════════════════════════════════════════════════════════════════════════
# STEP 2: Filename Metadata Extraction
#   Parse provider_id, contract_id, document_type, version from filenames.
#   Output: step2_with_metadata_v2.parquet
# ═══════════════════════════════════════════════════════════════════════════════
import os, re
import pandas as pd
import numpy as np

print("\n" + "═"*80)
print("  ▶ STEP 2: FILENAME METADATA EXTRACTION")
print("    Parsing provider_id, contract_id, document_type, version from filenames")
print("═"*80)

def parse_filename(filename):
    """Parse provider_id, provider_name, contract_id, document_type, version from filename."""
    base = os.path.splitext(filename)[0]
    # FIX: Allow digit-starting doc_types (e.g. 21AmendCM, 13AmendCM, 3rdAmend)
    m = re.match(r'^(\d+)_(.+?)_(\d+)_([A-Za-z0-9][A-Za-z0-9()]+(?:_[A-Za-z0-9][A-Za-z0-9()]*)*)_(v\d+)$', base)
    if m:
        return {'provider_id': m[1], 'provider_name': m[2].replace('_',' '),
                'contract_id': m[3], 'document_type': m[4], 'version': m[5]}
    parts = base.split('_')
    return {'provider_id': parts[0] if parts else None,
            'provider_name': '_'.join(parts[1:-2]).replace('_',' ') if len(parts) > 3 else filename,
            'contract_id': None, 'document_type': None,
            'version': parts[-1] if parts and parts[-1].startswith('v') else None}

# Staleness check — regenerate if STEP1_FILE is newer
_step2_stale = not os.path.exists(STEP2_FILE) or os.path.getmtime(STEP2_FILE) < os.path.getmtime(STEP1_FILE)

if os.path.exists(STEP2_FILE) and not _step2_stale:
    step2_df = pd.read_parquet(STEP2_FILE)
    print(f"  ✅ Checkpoint loaded ({len(step2_df)} rows, up-to-date)")
else:
    step1_df = pd.read_parquet(STEP1_FILE)
    step1_valid = step1_df[step1_df['text_length'].fillna(0) > 0].copy().reset_index(drop=True)
    step1_valid = step1_valid.loc[:, ~step1_valid.columns.duplicated()]  # Fix: remove duplicate columns from upstream checkpoint
    print(f"  📄 Processing {len(step1_valid)} files from Step 1...")
    if os.path.exists(STEP2_FILE):
        existing_step2 = pd.read_parquet(STEP2_FILE)
        new_files = step1_valid[~step1_valid['filename'].isin(existing_step2['filename'])]
        if len(new_files) > 0:
            new_parsed = pd.concat([new_files, new_files['filename'].apply(parse_filename).apply(pd.Series)], axis=1)
            step2_df = pd.concat([existing_step2, new_parsed], ignore_index=True)
            print(f"  🔄 Incremental: {len(new_files)} new + {len(existing_step2)} existing = {len(step2_df)} total")
        else:
            step2_df = existing_step2
            print(f"  ✅ Checkpoint current ({len(step2_df)} rows, no new files)")
    else:
        step2_df = pd.concat([step1_valid, step1_valid['filename'].apply(parse_filename).apply(pd.Series)], axis=1)
        # Ensure parsed metadata columns exist even if step1_valid was empty
        for col in ['provider_id', 'provider_name', 'contract_id', 'document_type', 'version']:
            if col not in step2_df.columns:
                step2_df[col] = None
        print(f"  🆕 Fresh parse: {len(step2_df)} files with metadata extracted")
    step2_df = step2_df.loc[:, ~step2_df.columns.duplicated()]  # Fix: ensure no duplicate columns before parquet write
    step2_df.to_parquet(STEP2_FILE, index=False)

# Summary
print(f"\n  ═{'='*78}═")
print(f"  ✅ STEP 2 COMPLETE: {len(step2_df)} files")
if 'provider_id' in step2_df.columns:
    print(f"     provider_id null: {step2_df['provider_id'].isna().sum()} | doc_type null: {step2_df.get('document_type', pd.Series(dtype='object')).isna().sum()}")
print(f"     Output: {STEP2_FILE}")
print(f"  ═{'='*78}═")